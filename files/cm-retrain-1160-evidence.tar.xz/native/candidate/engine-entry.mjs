globalThis.localStorage={getItem:()=>null,setItem:()=>{},removeItem:()=>{}};
export const engine=await import("/home/runner/work/ballpark-hero/ballpark-hero/src/lib/clubManager.ts");
export const positions=await import("/home/runner/work/ballpark-hero/ballpark-hero/src/lib/positionFit.ts");