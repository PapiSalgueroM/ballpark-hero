globalThis.localStorage={getItem:()=>null,setItem:()=>{},removeItem:()=>{}};
export const engine=await import("/home/runner/work/_temp/retrain-1160.1SGjwa/base-root/src/lib/clubManager.ts");
export const positions=await import("/home/runner/work/_temp/retrain-1160.1SGjwa/base-root/src/lib/positionFit.ts");