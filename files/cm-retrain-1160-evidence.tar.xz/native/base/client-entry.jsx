import React from 'react';
import {createRoot} from 'react-dom/client';
import {TrainingScreen} from "/home/runner/work/_temp/retrain-1160.ecXt3K/base-root/src/components/club-manager/TrainingScreen.tsx";
import {startRetraining} from "/home/runner/work/_temp/retrain-1160.ecXt3K/base-root/src/lib/clubManager.ts";
export function mount(fixture){
 let current=JSON.parse(JSON.stringify(fixture)), calls=[], planCalls=[], stopCalls=[];
 const view=createRoot(document.getElementById('fixture-root'));
 function render(){view.render(<TrainingScreen career={current} onSetPlan={plan=>planCalls.push(plan)} onStopRetrain={id=>stopCalls.push(id)} onRetrain={(id,to)=>{
  calls.push({id,to}); const next=startRetraining(current,id,to); if(next){current=next;render();}
 }}/>);}
 window.__retrain1160={snapshot:()=>({career:JSON.parse(JSON.stringify(current)),calls:JSON.parse(JSON.stringify(calls)),planCalls:JSON.parse(JSON.stringify(planCalls)),stopCalls:[...stopCalls]})};
 render();
}