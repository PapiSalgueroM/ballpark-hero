globalThis.localStorage={getItem:()=>null,setItem:()=>{},removeItem:()=>{}};
export const engine=await import("/home/runner/work/_temp/skills-1153.FoQeKs/base-root/src/lib/clubManager.ts");
export const xp=await import("/home/runner/work/_temp/skills-1153.FoQeKs/base-root/src/lib/clubManagerXp.ts");