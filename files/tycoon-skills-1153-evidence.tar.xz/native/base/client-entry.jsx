import React from 'react';
import {createRoot} from 'react-dom/client';
import {XpScreen} from "/home/runner/work/_temp/skills-1153.FoQeKs/base-root/src/components/club-manager/XpScreen.tsx";
import {spendSkillPoint,pointsFree,xpOf} from "/home/runner/work/_temp/skills-1153.FoQeKs/base-root/src/lib/clubManagerXp.ts";
export function mount(fixture){
 let current=JSON.parse(JSON.stringify(fixture)), calls=[];
 const view=createRoot(document.getElementById('fixture-root'));
 function render(){view.render(<XpScreen career={current} onSpendPoint={tree=>{
  calls.push(tree); const next=spendSkillPoint(current,tree); if(next){current=next;render();}
 }}/>);}
 window.__skills1153={snapshot:()=>({career:JSON.parse(JSON.stringify(current)),free:pointsFree(xpOf(current)),calls:[...calls]})};
 render();
}