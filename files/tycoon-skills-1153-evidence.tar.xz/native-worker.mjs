import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';

const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const save = (file, value) => fs.writeFileSync(file, JSON.stringify(value, null, 2));
const clone = value => JSON.parse(JSON.stringify(value));

async function main() {
  assert.equal(process.env.GITHUB_ACTIONS, 'true', 'Remote-only worker');
  const root = process.cwd(), out = path.join(process.env.E, 'native');
  const require = createRequire(path.join(root, 'package.json'));
  const { chromium } = require('playwright'), { build } = require('esbuild');
  const epoch = Date.UTC(2026, 0, 1, 12);
  const core = ['src/components/club-manager/XpScreen.tsx', 'src/lib/clubManager.ts', 'src/lib/clubManagerXp.ts', 'src/lib/gmXp.ts'];
  const trees = ['tactics', 'recruitment', 'negotiation', 'youth', 'manManagement', 'finance', 'media'];
  const treeLabels = ['Tactics', 'Recruitment', 'Negotiation', 'Youth', 'Man Management', 'Finance', 'Media'];
  const servers = [], variants = [], results = [];
  fs.mkdirSync(out, { recursive: true });
  save(path.join(out, 'partial-summary.json'), { executionComplete: false, results });
  const executable = chromium.executablePath();
  assert(executable.startsWith(process.env.PLAYWRIGHT_BROWSERS_PATH + path.sep));
  const browser = await chromium.launch({ headless: true, executablePath: executable });
  save(path.join(out, 'browser-runtime.json'), { version: browser.version(), executablePath: executable, executableSha256: hash(fs.readFileSync(executable)), privateCache: process.env.PLAYWRIGHT_BROWSERS_PATH });
  let careerTemplate;
  try {
    for (const [variant, sourceRoot] of [['candidate', root], ['base', process.env.BASE_ROOT]]) {
      const variantOut = path.join(out, variant), browserDir = path.join(variantOut, 'browser');
      fs.mkdirSync(browserDir, { recursive: true });
      const engineEntry = `globalThis.localStorage={getItem:()=>null,setItem:()=>{},removeItem:()=>{}};
export const engine=await import(${JSON.stringify(sourceRoot + '/src/lib/clubManager.ts')});
export const xp=await import(${JSON.stringify(sourceRoot + '/src/lib/clubManagerXp.ts')});`;
      const clientEntry = `import React from 'react';
import {createRoot} from 'react-dom/client';
import {XpScreen} from ${JSON.stringify(sourceRoot + '/src/components/club-manager/XpScreen.tsx')};
import {spendSkillPoint,pointsFree,xpOf} from ${JSON.stringify(sourceRoot + '/src/lib/clubManagerXp.ts')};
export function mount(fixture){
 let current=JSON.parse(JSON.stringify(fixture)), calls=[];
 const view=createRoot(document.getElementById('fixture-root'));
 function render(){view.render(<XpScreen career={current} onSpendPoint={tree=>{
  calls.push(tree); const next=spendSkillPoint(current,tree); if(next){current=next;render();}
 }}/>);}
 window.__skills1153={snapshot:()=>({career:JSON.parse(JSON.stringify(current)),free:pointsFree(xpOf(current)),calls:[...calls]})};
 render();
}`;
      const bindBuild = (result, outfile, virtualName, virtualBytes, requiredCore) => {
        const metadata = result.metafile, mapPath = outfile + '.map';
        save(outfile + '.metafile.json', metadata);
        const nodeRoot = fs.realpathSync(path.join(root, 'node_modules')) + path.sep;
        const inputRows = Object.entries(metadata.inputs).map(([input, info]) => {
          const resolved = path.resolve(sourceRoot, input);
          const virtual = !fs.existsSync(resolved) && resolved === path.resolve(sourceRoot, virtualName);
          assert(virtual || fs.statSync(resolved).isFile(), 'Actual regular bundle input: ' + input);
          const file = virtual ? resolved : fs.realpathSync(resolved);
          const bytes = virtual ? Buffer.from(virtualBytes) : fs.readFileSync(file);
          assert.equal(info.bytes, bytes.length, 'Actual input bytes: ' + input);
          return { input, file, virtual, bytes: bytes.length, sha256: hash(bytes) };
        });
        assert.equal(inputRows.filter(row => row.virtual).length, 1, 'Only the exact retained stdin entry is virtual');
        save(outfile + '.inputs.json', inputRows);
        const consumed = new Map(inputRows.map(row => [row.file, row]));
        const packageSources = new Map(), mapProviders = [];
        const retainedDir = path.join(variantOut, 'dependency-maps');
        fs.mkdirSync(retainedDir, { recursive: true });
        for (const input of inputRows) {
          if (input.virtual || !input.file.startsWith(nodeRoot)) continue;
          const bytes = fs.readFileSync(input.file);
          assert.equal(hash(bytes), input.sha256);
          const refs = [...bytes.toString('utf8').matchAll(/^[\t ]*\/\/[#@]\s*sourceMappingURL=(\S+)[\t ]*\r?$/gm)];
          const references = [...new Set(refs.map(row => row[1]))];
          assert(references.length <= 1, 'At most one unique actual consumed package map reference');
          if (!references.length) continue;
          const reference = references[0];
          assert(!/^(?:\w+:|\/)/.test(reference), 'Actual relative installed package map reference');
          const mapFile = fs.realpathSync(path.resolve(path.dirname(input.file), reference));
          assert(mapFile.startsWith(nodeRoot) && fs.statSync(mapFile).isFile(), 'Provider map stays inside held installed packages');
          const raw = fs.readFileSync(mapFile), published = JSON.parse(raw);
          assert(Array.isArray(published.sources));
          assert(published.sourcesContent === undefined || Array.isArray(published.sourcesContent));
          if (published.sourcesContent !== undefined) assert.equal(published.sources.length, published.sourcesContent.length);
          assert(published.sourceRoot === undefined || typeof published.sourceRoot === 'string');
          const mapSha256 = hash(raw), retained = path.join(retainedDir, mapSha256 + '.map');
          const inputRetained = path.join(retainedDir, input.sha256 + '.input');
          fs.writeFileSync(retained, raw); fs.writeFileSync(inputRetained, bytes);
          const proof = { input: input.file, inputSha256: input.sha256, sourceMappingURL: reference, mapFile, mapSha256, retained, inputRetained };
          mapProviders.push(proof);
          for (let index = 0; index < published.sources.length; index++) {
            assert.equal(typeof published.sources[index], 'string');
            const name = path.resolve(path.dirname(mapFile), published.sourceRoot ?? '', published.sources[index]);
            let content, contentProof;
            if (typeof published.sourcesContent?.[index] === 'string') {
              content = Buffer.from(published.sourcesContent[index]);
              contentProof = { contentKind: 'published sourcesContent' };
            } else {
              if (!name.startsWith(nodeRoot) || !fs.existsSync(name)) continue;
              const sourceFile = fs.realpathSync(name);
              assert(sourceFile === name && sourceFile.startsWith(nodeRoot) && fs.statSync(sourceFile).isFile(), 'Map-named installed original source remains inside held packages');
              content = fs.readFileSync(sourceFile);
              const sourceRetained = path.join(retainedDir, hash(content) + '.source');
              fs.writeFileSync(sourceRetained, content);
              contentProof = { contentKind: 'published map named installed source', sourceFile, sourceRetained, sourceSha256: hash(content) };
            }
            const contentHash = hash(content);
            packageSources.set(name + '\0' + contentHash, { ...proof, index, ...contentProof });
          }
        }
        save(outfile + '.providers.json', mapProviders);
        const map = JSON.parse(fs.readFileSync(mapPath)), bindings = [], seen = new Set();
        assert.equal(map.sources.length, map.sourcesContent.length);
        for (let i = 0; i < map.sources.length; i++) {
          assert.equal(typeof map.sourcesContent[i], 'string');
          const file = path.resolve(path.dirname(mapPath), map.sources[i]);
          const actualHash = hash(Buffer.from(map.sourcesContent[i]));
          const input = consumed.get(file);
          if (!input) {
            assert(file.startsWith(nodeRoot), 'Missing app/core/entry mapped sources fail closed: ' + file);
            const provider = packageSources.get(file + '\0' + actualHash);
            assert(provider, 'Dependency original must match a consumed actual package map: ' + file);
            bindings.push({ source: map.sources[i], file, sha256: actualHash, virtual: false, kind: 'consumed package map original', provider });
            continue;
          }
          assert.equal(actualHash, input.sha256, 'Actual consumed emitted source content: ' + file);
          for (const source of requiredCore) if (file === path.join(sourceRoot, source)) seen.add(source);
          bindings.push({ source: map.sources[i], file, sha256: actualHash, virtual: input.virtual, kind: input.virtual ? 'retained stdin entry' : 'actual consumed input' });
        }
        assert.deepEqual([...seen].sort(), [...requiredCore].sort(), 'All actual core bodies bound');
        const js = fs.readFileSync(outfile);
        assert(js.toString().includes('//# sourceMappingURL=' + path.basename(mapPath)));
        const record = { js: outfile, jsSha256: hash(js), map: mapPath, mapSha256: hash(fs.readFileSync(mapPath)), inputRows, bindings, requiredCore, mapProviders };
        save(outfile + '.bindings.json', record); return record;
      };
      fs.writeFileSync(path.join(variantOut, 'engine-entry.mjs'), engineEntry);
      const engineFile = path.join(variantOut, 'actual-engine.mjs');
      const engineBuild = await build({ absWorkingDir: sourceRoot, stdin: { contents: engineEntry, sourcefile: '1153-engine-entry.mjs', resolveDir: sourceRoot, loader: 'js' }, outfile: engineFile, bundle: true, platform: 'node', format: 'esm', sourcemap: true, metafile: true, alias: { '@': path.join(sourceRoot, 'src') }, tsconfig: path.join(sourceRoot, 'tsconfig.app.json') });
      const engineBinding = bindBuild(engineBuild, engineFile, '1153-engine-entry.mjs', engineEntry, core.slice(1));
      const { engine, xp } = await import(pathToFileURL(engineFile).href);
      assert.deepEqual(xp.SKILL_TREES, trees);
      assert.deepEqual(trees.map(tree => xp.TREE_INFO[tree].label), treeLabels);
      assert.equal(xp.MAX_TREE_POINTS, 5);
      if (!careerTemplate) {
        const RealDate = globalThis.Date, originalRandom = Math.random;
        let seed = 1153;
        try {
          globalThis.Date = class extends RealDate { constructor(...args) { super(...(args.length ? args : [epoch])); } static now() { return epoch; } };
          Math.random = () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 4294967296; };
          careerTemplate = clone(engine.startCareer('Sunderland'));
        } finally { globalThis.Date = RealDate; Math.random = originalRandom; }
        assert(careerTemplate && typeof careerTemplate === 'object');
        save(path.join(out, 'actual-start-career-template.json'), careerTemplate);
      }
      fs.writeFileSync(path.join(variantOut, 'client-entry.jsx'), clientEntry);
      const clientFile = path.join(browserDir, 'fixture.js');
      const clientBuild = await build({ absWorkingDir: sourceRoot, stdin: { contents: clientEntry, sourcefile: '1153-client-entry.jsx', resolveDir: sourceRoot, loader: 'jsx' }, outfile: clientFile, bundle: true, platform: 'browser', format: 'esm', sourcemap: true, metafile: true, alias: { '@': path.join(sourceRoot, 'src') }, tsconfig: path.join(sourceRoot, 'tsconfig.app.json') });
      const clientBinding = bindBuild(clientBuild, clientFile, '1153-client-entry.jsx', clientEntry, core);
      const dist = path.join(root, 'dist'), css = [];
      const builtIndexFile = path.join(variantOut, 'built-index.html');
      const builtIndex = fs.readFileSync(path.join(dist, 'index.html'), 'utf8');
      fs.writeFileSync(builtIndexFile, builtIndex);
      const knownExternalFontHref = 'https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap';
      const classifyStylesheet = href => href === knownExternalFontHref ? 'held external font declaration' : href && href.startsWith('/assets/') && href.endsWith('.css') ? 'local application CSS' : 'unsupported stylesheet';
      const stylesheetRefs = text => [...text.matchAll(/<link\b[^>]*>/g)].filter(tag => /\brel=["']stylesheet["']/.test(tag[0])).map(tag => {
        const href = tag[0].match(/\bhref=["']([^"']+)["']/)?.[1] ?? null;
        return { tag: tag[0], href, classification: classifyStylesheet(href) };
      });
      const references = stylesheetRefs(builtIndex);
      save(path.join(variantOut, 'stylesheet-refs.json'), references);
      const sourceIndex = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
      assert.equal(stylesheetRefs(sourceIndex).filter(row => row.href === knownExternalFontHref).length, 1, 'One exact held font declaration exists in the original source');
      const selectApplicationCss = refs => {
        assert(refs.every(row => classifyStylesheet(row.href) !== 'unsupported stylesheet'), 'Every stylesheet is the exact held font declaration or local application CSS');
        const selected = refs.filter(row => classifyStylesheet(row.href) === 'local application CSS');
        assert(selected.length > 0, 'Actual built application CSS is required');
        return selected;
      };
      const selected = selectApplicationCss(references);
      assert.equal(references.filter(row => row.href === knownExternalFontHref).length, 1, 'One exact held font declaration exists in the actual built index');
      const controlReferences = references.map(row => row.href === knownExternalFontHref ? { ...row, href: 'https://invalid.example/unknown.css', classification: classifyStylesheet('https://invalid.example/unknown.css') } : { ...row });
      assert.equal(controlReferences.filter(row => row.classification === 'unsupported stylesheet').length, 1, 'The copied unknown stylesheet control changes one actual declaration');
      let controlFailure;
      try { selectApplicationCss(controlReferences); } catch (error) { controlFailure = error; }
      assert(controlFailure instanceof assert.AssertionError);
      assert.equal(controlFailure.message, 'Every stylesheet is the exact held font declaration or local application CSS');
      assert.deepEqual(controlReferences.filter(row => row.classification === 'local application CSS'), selected, 'The copied control keeps the real local CSS baseline');
      const cssSelection = { builtIndex: builtIndexFile, builtIndexSha256: hash(Buffer.from(builtIndex)), sourceIndexSha256: hash(Buffer.from(sourceIndex)), knownExternalFontHref, references, selected, controlReferences, intendedFailure: { name: controlFailure.name, message: controlFailure.message, actual: controlFailure.actual, expected: controlFailure.expected } };
      save(path.join(variantOut, 'stylesheet-selection.json'), cssSelection);
      const assertCssBytes = bytes => assert(bytes.length > 0, 'Selected application CSS has positive bytes');
      for (const row of selected) {
        const href = row.href;
        const bytes = fs.readFileSync(path.join(dist, href.slice(1)));
        assertCssBytes(bytes);
        css.push({ url: href, sha256: hash(bytes), bytes: bytes.length });
      }
      assert(css.length > 0, 'Actual built application CSS used by the component fixture');
      const emptyCss = Buffer.alloc(0), emptyCssFile = path.join(variantOut, 'empty-css-control.css');
      fs.writeFileSync(emptyCssFile, emptyCss);
      assert.notEqual(hash(emptyCss), css[0].sha256, 'The copied empty CSS control changes the actual selected payload');
      let emptyCssFailure;
      try { assertCssBytes(emptyCss); } catch (error) { emptyCssFailure = error; }
      assert(emptyCssFailure instanceof assert.AssertionError);
      assert.equal(emptyCssFailure.message, 'Selected application CSS has positive bytes');
      const cssByteControl = { baseline: css[0], controlledFile: emptyCssFile, controlledBytes: emptyCss.length, controlledSha256: hash(emptyCss), intendedFailure: { name: emptyCssFailure.name, message: emptyCssFailure.message, actual: emptyCssFailure.actual, expected: emptyCssFailure.expected } };
      save(path.join(variantOut, 'css-byte-control.json'), cssByteControl);
      const html = `<!doctype html><html class="dark"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">${css.map(c => `<link rel="stylesheet" href="${c.url}">`).join('')}</head><body class="bg-background text-foreground"><main id="fixture-root" class="mx-auto max-w-2xl p-4"></main><script type="module">import{mount}from'/fixture.js';mount(window.__skillsFixture);</script></body></html>`;
      fs.writeFileSync(path.join(browserDir, 'index.html'), html);
      save(path.join(variantOut, 'fixture-build.json'), { scope: 'Actual XpScreen direct component, not ClubManager route or saves', engine: engineBinding, client: clientBinding, css, cssSelection, cssByteControl, htmlSha256: hash(Buffer.from(html)) });
      const records = [], payloadDir = path.join(variantOut, 'served-payloads'); fs.mkdirSync(payloadDir);
      const server = http.createServer((req, res) => {
        try {
          assert.equal(req.method, 'GET');
          const requestPath = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
          const source = requestPath === '/' ? 'component-fixture' : ['/fixture.js', '/fixture.js.map'].includes(requestPath) ? 'component-bundle' : 'candidate-dist';
          const file = source === 'component-fixture' ? path.join(browserDir, 'index.html') : source === 'component-bundle' ? path.join(browserDir, requestPath.slice(1)) : path.resolve(dist, requestPath.slice(1));
          assert(source !== 'candidate-dist' || file.startsWith(dist + path.sep));
          const bytes = fs.readFileSync(file), sha256 = hash(bytes);
          fs.writeFileSync(path.join(payloadDir, sha256), bytes);
          records.push({ method: req.method, url: requestPath, file, source, sha256, bytes: bytes.length });
          save(path.join(variantOut, 'served.json'), records);
          const ext = path.extname(file);
          res.writeHead(200, { 'Content-Type': ({ '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.woff2': 'font/woff2', '.json': 'application/json' })[ext] || 'application/octet-stream', 'Cache-Control': 'no-store' }); res.end(bytes);
        } catch (error) { records.push({ method: req.method, url: req.url, error: String(error) }); save(path.join(variantOut, 'served.json'), records); res.writeHead(404); res.end('Unavailable'); }
      });
      await new Promise(resolve => server.listen(0, '127.0.0.1', resolve)); servers.push(server);
      const origin = 'http://127.0.0.1:' + server.address().port;
      const cases = variant === 'candidate' ? [[320, 'tactics'], [1280, 'tactics'], [320, 'finance'], [1280, 'finance'], [320, 'zero'], [320, 'full']] : [[320, 'duplicate'], [1280, 'duplicate']];
      for (const [width, action] of cases) {
        const name = variant + '-' + width + '-' + action, dir = path.join(out, name); fs.mkdirSync(dir);
        const fixture = clone(careerTemplate), block = xp.defaultXp();
        block.xp = action === 'zero' ? 0 : xp.xpForLevel(action === 'full' ? 8 : 3);
        if (action === 'full') block.points.tactics = xp.MAX_TREE_POINTS;
        fixture.managerXp = block;
        assert(xp.isValidXp(block)); assert.equal(xp.pointsFree(block), action === 'zero' ? 0 : 2);
        assert.deepEqual(Object.keys(block.points).sort(), [...trees].sort());
        assert(trees.every(tree => block.points[tree] === (action === 'full' && tree === 'tactics' ? 5 : 0)));
        save(path.join(dir, 'actual-engine-fixture.json'), fixture);
        const row = { name, variant, width, action, fixtureSha256: hash(fs.readFileSync(path.join(dir, 'actual-engine-fixture.json'))), status: 'failed', pageErrors: [], localFailures: [], localRequests: [], blocked: [], sockets: [], checks: {} };
        let context, page;
        const snapshot = async stage => {
          const board = page.locator('[data-cm-xp]');
          const data = await board.evaluate(el => ({ html: el.outerHTML, text: el.innerText, rows: [...el.querySelectorAll('.grid > div')].map((node, index) => ({ index, text: node.innerText, className: node.className, button: { text: node.querySelector('button').textContent, className: node.querySelector('button').className, label: node.querySelector('button').getAttribute('aria-label'), title: node.querySelector('button').title, disabled: node.querySelector('button').disabled } })) }));
          data.aria = await board.ariaSnapshot(); data.state = await page.evaluate(() => window.__skills1153.snapshot());
          data.geometry = await board.evaluate(el => { const r = el.getBoundingClientRect(); return { x: r.x, width: r.width, documentWidth: document.documentElement.scrollWidth, viewportWidth: innerWidth }; });
          data.clock = await page.evaluate(() => ({ dateNow: Date.now(), performanceNow: performance.now() }));
          save(path.join(dir, stage + '.json'), data); await board.screenshot({ path: path.join(dir, stage + '.png') }); return data;
        };
        const assertNamed = async (tree, have = 0, full = false) => {
          const text = full ? 'Full' : `Spend a point (${have}/5)`;
          const name = text + ': ' + treeLabels[trees.indexOf(tree)];
          const button = page.getByRole('button', { name, exact: true });
          assert.equal(await button.count(), 1, 'Exactly one native skill button named ' + name);
          assert.equal(await button.textContent(), text); return button;
        };
        try {
          context = await browser.newContext({ viewport: { width, height: 900 } });
          await context.routeWebSocket('**/*', socket => { row.sockets.push(socket.url()); socket.close(); });
          await context.route('**/*', async route => {
            const request = route.request(), url = request.url();
            if (!url.startsWith(origin + '/')) { row.blocked.push({ url, method: request.method() }); await route.abort(); return; }
            row.localRequests.push({ url: new URL(url).pathname, method: request.method() });
            if (request.method() !== 'GET') { row.localFailures.push({ url, error: 'Unexpected local write' }); await route.abort(); return; }
            await route.continue();
          });
          await context.addInitScript(fixture => { window.__skillsFixture = fixture; }, fixture);
          page = await context.newPage(); await page.clock.install({ time: epoch - 1000 }); await page.clock.pauseAt(epoch);
          page.on('pageerror', error => row.pageErrors.push({ name: error.name, message: error.message, stack: error.stack }));
          page.on('requestfailed', request => { if (request.url().startsWith(origin + '/')) row.localFailures.push({ url: request.url(), error: request.failure() }); });
          page.on('response', response => { if (response.url().startsWith(origin + '/') && response.status() >= 400) row.localFailures.push({ url: response.url(), status: response.status() }); });
          await page.goto(origin, { waitUntil: 'networkidle' }); await page.locator('[data-cm-xp]').waitFor();
          row.before = await snapshot('before'); assert.equal(row.before.rows.length, 7);
          assert.deepEqual(row.before.state.career, fixture); assert.equal(row.before.state.calls.length, 0);
          assert.equal(row.before.state.free, action === 'zero' ? 0 : 2);
          if (action === 'duplicate') {
            assert.equal(await page.getByRole('button', { name: 'Spend a point (0/5)', exact: true }).count(), 7);
            let intendedFailure;
            try { await assertNamed('tactics'); } catch (error) { intendedFailure = error; }
            assert(intendedFailure); assert.equal(intendedFailure.name, 'AssertionError'); assert.equal(intendedFailure.actual, 0); assert.equal(intendedFailure.expected, 1);
            assert(intendedFailure.message.includes('Exactly one native skill button named Spend a point (0/5): Tactics'));
            row.intendedNameFailure = { name: intendedFailure.name, message: intendedFailure.message, actual: intendedFailure.actual, expected: intendedFailure.expected };
            assert(row.before.rows.every(r => r.button.label === null && r.button.text === 'Spend a point (0/5)' && !r.button.disabled));
            row.checks = { duplicateNames: 7, desiredNamedActionCount: 0, intendedNameAssertionFailed: true, unrelatedFullStateBaselinePassed: true };
          } else {
            for (const tree of trees) await assertNamed(tree, action === 'full' && tree === 'tactics' ? 5 : 0, action === 'full' && tree === 'tactics');
            if (action === 'zero' || action === 'full') {
              const target = await assertNamed('tactics', action === 'full' ? 5 : 0, action === 'full');
              assert(await target.isDisabled());
              assert.equal(xp.spendSkillPoint(fixture, 'tactics'), null, 'Held helper refuses the disabled spend');
              if (action === 'zero') assert(row.before.rows.every(r => r.button.disabled));
              else assert(await (await assertNamed('finance')).isEnabled());
              row.after = await snapshot('after'); assert.deepEqual(row.after.state, row.before.state);
              row.checks = { disabledTarget: true, allSevenDisabled: action === 'zero', fullTree: action === 'full', heldHelperRefused: true, completeStateUnchanged: true };
            } else {
              const button = await assertNamed(action); assert(await button.isEnabled());
              await button.focus(); assert(await button.evaluate(el => el === document.activeElement)); await button.press('Enter');
              await page.getByRole('button', { name: 'Spend a point (1/5): ' + treeLabels[trees.indexOf(action)], exact: true }).waitFor();
              row.after = await snapshot('after');
              const expected = xp.spendSkillPoint(row.before.state.career, action); assert(expected); assert.notDeepEqual(expected, row.before.state.career);
              save(path.join(dir, 'expected-held-helper-state.json'), expected);
              row.expectedStateSha256 = hash(fs.readFileSync(path.join(dir, 'expected-held-helper-state.json')));
              assert.deepEqual(row.after.state.career, expected); assert.deepEqual(row.after.state.calls, [action]);
              assert.equal(row.after.state.free, 1); assert.equal(row.after.state.career.managerXp.points[action], 1);
              for (const tree of trees) if (tree !== action) assert.equal(row.after.state.career.managerXp.points[tree], row.before.state.career.managerXp.points[tree]);
              assert.equal(row.after.state.career.managerXp.xp, row.before.state.career.managerXp.xp);
              assert.equal(row.after.clock.dateNow, epoch); assert.equal(row.after.clock.performanceNow, row.before.clock.performanceNow);
              for (const tree of trees) await assertNamed(tree, tree === action ? 1 : 0);
              row.checks = { actualEnter: true, actionCalls: 1, intendedTree: action, freeBefore: 2, freeAfter: 1, selectedBefore: 0, selectedAfter: 1, otherTreesHeld: true, xpHeld: true, fullHeldHelperStateEqual: true };
            }
          }
          assert(row.before.geometry.documentWidth <= width);
          const requested = new Set(row.localRequests.filter(r => r.method === 'GET').map(r => r.url));
          assert(requested.has('/fixture.js'), 'Case loaded actual component bundle');
          for (const style of css) assert(requested.has(style.url), 'Case loaded actual built application CSS');
          row.status = 'passed';
        } catch (error) { row.error = { name: error.name, message: error.message, stack: error.stack }; }
        finally {
          if (context) try { await context.close(); } catch (error) { row.closeError = String(error); row.status = 'failed'; }
          if (row.pageErrors.length || row.localFailures.length) row.status = 'failed';
          save(path.join(dir, 'result.json'), row); results.push(row);
          save(path.join(out, 'partial-summary.json'), { executionComplete: false, results });
        }
      }
      assert(records.every(r => !r.error));
      for (const row of results.filter(r => r.variant === variant)) for (const request of row.localRequests) assert(records.some(r => r.url === request.url && r.method === request.method && !r.error));
      variants.push({ variant, engineBinding, clientBinding, servedRecords: records.length });
    }
    for (const width of [320, 1280]) {
      const base = results.find(r => r.name === 'base-' + width + '-duplicate'), candidate = results.find(r => r.name === 'candidate-' + width + '-tactics');
      assert(base && candidate);
      const visible = data => data.rows.map(({ button, ...row }) => ({ ...row, button: { text: button.text, className: button.className, title: button.title, disabled: button.disabled } }));
      assert.deepEqual(visible(candidate.before), visible(base.before)); assert.deepEqual(candidate.before.state, base.before.state);
      assert.equal(candidate.before.geometry.width, base.before.geometry.width); assert.equal(candidate.before.geometry.documentWidth, base.before.geometry.documentWidth);
    }
    assert.equal(results.filter(r => r.variant === 'candidate').length, 6); assert.equal(results.filter(r => r.variant === 'base').length, 2);
    assert(results.every(r => r.status === 'passed'));
  } finally {
    await browser.close();
    for (const server of servers) await new Promise((resolve, reject) => server.close(error => error ? reject(error) : resolve()));
  }
  save(path.join(out, 'summary.json'), { executionComplete: true, healthy: 6, effectiveBaseControls: 2, variants, results, scope: 'Direct actual XpScreen component and actual held XP helper, not ClubManager route or save persistence' });
  console.log('Native1153 PASS: six actual candidate component cases and two untouched-parent name controls. Native Enter spent the named tree only, with full held-helper consequences, zero/full refusals and all seven current names.');
}
main().catch(error => { console.error(error); process.exitCode = 1; });
