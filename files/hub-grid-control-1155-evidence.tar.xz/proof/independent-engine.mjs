var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};

// src/lib/captaincy.ts
var CAPTAIN_MIN_AGE, CAPTAIN_MIN_RATING;
var init_captaincy = __esm({
  "src/lib/captaincy.ts"() {
    CAPTAIN_MIN_AGE = 24;
    CAPTAIN_MIN_RATING = 76;
  }
});

// src/lib/uclTieRule.ts
function uclTieOutcome(tie, awayGoalsRule) {
  const l1 = tie.leg1 ?? { homeGoals: 0, awayGoals: 0 };
  const l2 = tie.leg2 ?? { homeGoals: 0, awayGoals: 0 };
  const homeAgg = l1.homeGoals + l2.homeGoals;
  const awayAgg = l1.awayGoals + l2.awayGoals;
  if (homeAgg !== awayAgg) {
    return { homeAgg, awayAgg, winner: homeAgg > awayAgg ? "home" : "away", byAwayGoals: false };
  }
  if (awayGoalsRule) {
    const homeAway = l2.homeGoals;
    const awayAway = l1.awayGoals;
    if (homeAway !== awayAway) {
      return { homeAgg, awayAgg, winner: homeAway > awayAway ? "home" : "away", byAwayGoals: true };
    }
  }
  return { homeAgg, awayAgg, winner: null, byAwayGoals: false };
}
var init_uclTieRule = __esm({
  "src/lib/uclTieRule.ts"() {
  }
});

// src/lib/intlFormatHistory.ts
function periodsOf(competition) {
  return INTL_FORMAT_PERIODS.filter((p) => p.competition === competition).sort((a, b) => a.from - b.from);
}
function periodInForce(competition, year) {
  const rows = periodsOf(competition);
  let found = rows[0];
  for (const r of rows) if (r.from <= year) found = r;
  return found;
}
function playedPeriod(period) {
  if (period.playable) return period;
  const target = INTL_FORMAT_PERIODS.find((p) => p.id === period.playedAs);
  return target && target.playable ? target : period;
}
function wcFieldMixFor(year) {
  let found = WC_FIELD_MIXES[0];
  for (const m of WC_FIELD_MIXES) if (m.from <= year) found = m;
  return found;
}
var INTL_FORMAT_PERIODS, WC_FIELD_MIXES;
var init_intlFormatHistory = __esm({
  "src/lib/intlFormatHistory.ts"() {
    INTL_FORMAT_PERIODS = [
      /* ── World Cup ── */
      {
        id: "wc-24",
        competition: "WC",
        from: 1986,
        to: 1994,
        teams: 24,
        groups: 6,
        groupSize: 4,
        thirdsThrough: 4,
        firstKnockout: "R16",
        playable: true,
        sources: ["tesFormats", "rs90", "rs94", "fh90", "fh94"]
      },
      {
        id: "wc-32",
        competition: "WC",
        from: 1998,
        to: 2022,
        teams: 32,
        groups: 8,
        groupSize: 4,
        thirdsThrough: 0,
        firstKnockout: "R16",
        playable: true,
        sources: ["tesFormats", "rs98", "fh98", "rs02", "fh02"]
      },
      {
        id: "wc-48",
        competition: "WC",
        from: 2026,
        to: null,
        teams: 48,
        groups: 12,
        groupSize: 4,
        thirdsThrough: 8,
        firstKnockout: "R32",
        playable: true,
        sources: ["tesFormats", "ofc2026"]
      },
      /* ── European Championship ── */
      {
        id: "euro-8",
        competition: "UEFA",
        from: 1984,
        to: 1992,
        teams: 8,
        groups: 2,
        groupSize: 4,
        thirdsThrough: 0,
        firstKnockout: "SF",
        playable: true,
        sources: ["fhEuro", "rsEuro", "rs92e"]
      },
      {
        id: "euro-16",
        competition: "UEFA",
        from: 1996,
        to: 2012,
        teams: 16,
        groups: 4,
        groupSize: 4,
        thirdsThrough: 0,
        firstKnockout: "QF",
        playable: true,
        sources: ["fhEuro", "rsEuro", "rs96e"]
      },
      {
        id: "euro-24",
        competition: "UEFA",
        from: 2016,
        to: null,
        teams: 24,
        groups: 6,
        groupSize: 4,
        thirdsThrough: 4,
        firstKnockout: "R16",
        playable: true,
        sources: ["fhEuro", "rsEuro", "rs16e"]
      },
      /* ── Copa America ── */
      {
        id: "copa-1991",
        competition: "CONMEBOL",
        from: 1991,
        to: 1991,
        teams: 10,
        groups: 2,
        groupSize: 5,
        thirdsThrough: 0,
        firstKnockout: null,
        playable: false,
        playedAs: "copa-12",
        /* Both sources give the ten teams in two groups. Only RSSSF details what
           came after (the top two of each into a final group of four, with no
           final), so the note does not lean on that; the row is unplayable
           either way. */
        note: "All ten CONMEBOL sides in two groups of five, then a final stage the game cannot play.",
        sources: ["rs91sa", "fhCopa"]
      },
      {
        id: "copa-12",
        competition: "CONMEBOL",
        from: 1993,
        to: 2015,
        teams: 12,
        groups: 3,
        groupSize: 4,
        thirdsThrough: 2,
        firstKnockout: "QF",
        playable: true,
        guestsFrom: "CONCACAF",
        note: "Two invited guests made it twelve. The game draws them from Concacaf, as in 1993, when the guests were Mexico and the USA.",
        sources: ["rs93sa", "fhCopa", "sky2015"]
      },
      {
        id: "copa-centenario",
        competition: "CONMEBOL",
        from: 2016,
        to: 2016,
        teams: 16,
        groups: 4,
        groupSize: 4,
        thirdsThrough: 0,
        firstKnockout: "QF",
        playable: true,
        guestsFrom: "CONCACAF",
        sources: ["rs16sa", "si2016"]
      },
      {
        id: "copa-2019",
        competition: "CONMEBOL",
        from: 2019,
        to: 2019,
        teams: 12,
        groups: 3,
        groupSize: 4,
        thirdsThrough: 2,
        firstKnockout: "QF",
        playable: true,
        guestsFrom: "AFC",
        note: "The two guests were Japan and Qatar.",
        sources: ["rs19sa", "cbs2019", "bes2019"]
      },
      {
        id: "copa-2021",
        competition: "CONMEBOL",
        from: 2021,
        to: 2021,
        teams: 10,
        groups: 2,
        groupSize: 5,
        thirdsThrough: 0,
        firstKnockout: "QF",
        playable: false,
        playedAs: "copa-2019",
        note: "No guests: two groups of five, and the top four of each went through to the quarter-finals. No game year lands on 2021, so the game never reaches this row; its 2020 Copa is the 2019 shape.",
        sources: ["rs21sa", "si2021"]
      },
      {
        id: "copa-16",
        competition: "CONMEBOL",
        from: 2024,
        to: null,
        teams: 16,
        groups: 4,
        groupSize: 4,
        thirdsThrough: 0,
        firstKnockout: "QF",
        playable: true,
        guestsFrom: "CONCACAF",
        sources: ["rs24sa", "nbc2024"]
      },
      /* ── Africa Cup of Nations ── */
      {
        id: "afcon-12",
        competition: "CAF",
        from: 1992,
        to: 1994,
        teams: 12,
        groups: 4,
        groupSize: 3,
        thirdsThrough: 0,
        firstKnockout: "QF",
        playable: true,
        sources: ["rs92a", "fhAfcon"]
      },
      {
        id: "afcon-16",
        competition: "CAF",
        from: 1996,
        to: 2017,
        teams: 16,
        groups: 4,
        groupSize: 4,
        thirdsThrough: 0,
        firstKnockout: "QF",
        playable: true,
        note: "Built for sixteen; the 1996 finals ran with fifteen after Nigeria withdrew.",
        sources: ["rs96a", "fhAfcon", "tn2017"]
      },
      {
        id: "afcon-24",
        competition: "CAF",
        from: 2019,
        to: null,
        teams: 24,
        groups: 6,
        groupSize: 4,
        thirdsThrough: 4,
        firstKnockout: "R16",
        playable: true,
        sources: ["rs19a", "conv2019"]
      },
      /* ── AFC Asian Cup ── */
      {
        id: "asian-8",
        competition: "AFC",
        from: 1992,
        to: 1992,
        teams: 8,
        groups: 2,
        groupSize: 4,
        thirdsThrough: 0,
        firstKnockout: "SF",
        playable: true,
        sources: ["rs92as", "iwf1992"]
      },
      {
        id: "asian-12",
        competition: "AFC",
        from: 1996,
        to: 2e3,
        teams: 12,
        groups: 3,
        groupSize: 4,
        thirdsThrough: 2,
        firstKnockout: "QF",
        playable: true,
        sources: ["rs96as", "rs00as", "iwf1996", "gtfAsian"]
      },
      {
        id: "asian-16",
        competition: "AFC",
        from: 2004,
        to: 2015,
        teams: 16,
        groups: 4,
        groupSize: 4,
        thirdsThrough: 0,
        firstKnockout: "QF",
        playable: true,
        sources: ["rs04as", "iwf2004", "gtfAsian"]
      },
      {
        id: "asian-24",
        competition: "AFC",
        from: 2019,
        to: null,
        teams: 24,
        groups: 6,
        groupSize: 4,
        thirdsThrough: 4,
        firstKnockout: "R16",
        playable: true,
        sources: ["rs19as", "gtfAsian"]
      },
      /* ── Concacaf Gold Cup ── */
      {
        id: "gold-8",
        competition: "CONCACAF",
        from: 1991,
        to: 1993,
        teams: 8,
        groups: 2,
        groupSize: 4,
        thirdsThrough: 0,
        firstKnockout: "SF",
        playable: true,
        sources: ["rs91gc", "concGrowth"]
      },
      {
        id: "gold-1996",
        competition: "CONCACAF",
        from: 1996,
        to: 1996,
        teams: 9,
        groups: 3,
        groupSize: 3,
        thirdsThrough: 0,
        firstKnockout: "SF",
        playable: false,
        playedAs: "gold-8",
        note: "Nine teams in three groups of three, with the three group winners and the best runner up in the semi-finals.",
        sources: ["rs96gc", "concGrowth"]
      },
      {
        id: "gold-12-threes",
        competition: "CONCACAF",
        from: 2e3,
        to: 2003,
        teams: 12,
        groups: 4,
        groupSize: 3,
        thirdsThrough: 0,
        firstKnockout: "QF",
        playable: true,
        sources: ["rs00gc", "concGrowth"]
      },
      {
        id: "gold-12-fours",
        competition: "CONCACAF",
        from: 2005,
        to: 2017,
        teams: 12,
        groups: 3,
        groupSize: 4,
        thirdsThrough: 2,
        firstKnockout: "QF",
        playable: true,
        sources: ["rs05gc", "concGrowth", "mls2017"]
      },
      {
        id: "gold-16",
        competition: "CONCACAF",
        from: 2019,
        to: null,
        teams: 16,
        groups: 4,
        groupSize: 4,
        thirdsThrough: 0,
        firstKnockout: "QF",
        playable: true,
        sources: ["rs19gc", "concGrowth", "mnufc"]
      },
      /* ── OFC Nations Cup ── */
      {
        id: "ofc-gap",
        competition: "OFC",
        from: 1981,
        to: 1995,
        teams: 0,
        groups: 0,
        groupSize: 0,
        thirdsThrough: 0,
        firstKnockout: null,
        playable: false,
        playedAs: "ofc-6",
        note: "No Nations Cup was played between the 1980 and 1996 editions. The game still runs one on its own calendar, in the nearest verified shape.",
        /* RSSSF: "A second edition took place in 1980, then the tournament was
           discontinued. In 1996 it reappeared"; the OFC's own 1996 page: "After
           sixteen years in the wilderness ... returned for its third edition in
           1996". Both read 2026-10-06. */
        sources: ["rsOfc", "ofc1996"]
      },
      {
        id: "ofc-1996",
        competition: "OFC",
        from: 1996,
        to: 1996,
        teams: 4,
        groups: 0,
        groupSize: 0,
        thirdsThrough: 0,
        firstKnockout: "SF",
        playable: false,
        playedAs: "ofc-6",
        note: "Four nations, with semi-finals and a final all played over two legs.",
        sources: ["rs96oc", "ofc1996"]
      },
      {
        id: "ofc-6",
        competition: "OFC",
        from: 1998,
        to: 2e3,
        teams: 6,
        groups: 2,
        groupSize: 3,
        thirdsThrough: 0,
        firstKnockout: "SF",
        playable: true,
        sources: ["rs98oc", "rs00oc", "ofc1998", "ofc2000"]
      },
      {
        id: "ofc-8-2002",
        competition: "OFC",
        from: 2002,
        to: 2002,
        teams: 8,
        groups: 2,
        groupSize: 4,
        thirdsThrough: 0,
        firstKnockout: "SF",
        playable: true,
        sources: ["rs02oc", "ofc2002"]
      },
      {
        id: "ofc-2004",
        competition: "OFC",
        from: 2004,
        to: 2004,
        teams: 6,
        groups: 1,
        groupSize: 6,
        thirdsThrough: 0,
        firstKnockout: null,
        playable: false,
        playedAs: "ofc-8-2002",
        note: "Six nations in one round robin group, then a two legged final between the top two.",
        sources: ["rs04oc", "ofc2004"]
      },
      {
        id: "ofc-2008",
        competition: "OFC",
        from: 2008,
        to: 2008,
        teams: 4,
        groups: 1,
        groupSize: 4,
        thirdsThrough: 0,
        firstKnockout: null,
        playable: false,
        playedAs: "ofc-8",
        note: "Four nations playing each other home and away over most of a year, with no final.",
        sources: ["rsOfc", "ofc2008"]
      },
      {
        id: "ofc-8",
        competition: "OFC",
        from: 2012,
        to: null,
        teams: 8,
        groups: 2,
        groupSize: 4,
        thirdsThrough: 0,
        firstKnockout: "SF",
        playable: true,
        sources: ["rs12oc", "rs16oc", "rs24oc", "ofc2012", "ofc2016", "ofc2024"]
      }
    ];
    WC_FIELD_MIXES = [
      {
        from: 1990,
        kind: "finalists",
        open: 0,
        places: { UEFA: 14, CAF: 2, AFC: 2, CONMEBOL: 4, CONCACAF: 2, OFC: 0 },
        sources: ["rs90", "fh90"]
      },
      {
        from: 1994,
        kind: "finalists",
        open: 0,
        places: { UEFA: 13, CAF: 3, AFC: 2, CONMEBOL: 4, CONCACAF: 2, OFC: 0 },
        sources: ["rs94", "fh94"]
      },
      {
        /* 1998 and 2002 finished with the same mix, checked edition by edition. */
        from: 1998,
        kind: "finalists",
        open: 0,
        places: { UEFA: 15, CAF: 5, AFC: 4, CONMEBOL: 5, CONCACAF: 3, OFC: 0 },
        sources: ["rs98", "fh98", "rs02", "fh02"]
      },
      {
        from: 2006,
        kind: "allocation",
        open: 3,
        places: { UEFA: 13, CAF: 5, AFC: 4, CONMEBOL: 4, CONCACAF: 3, OFC: 0 },
        sources: ["arxivSlots", "atrSlots"]
      },
      {
        /* The 2026 allocation the engine already used (WC_SLOTS in
           soccerInternational.ts): CONCACAF's three host places plus its three
           direct places make six, and two inter-confederation play-off places. */
        from: 2026,
        kind: "allocation",
        open: 2,
        places: { UEFA: 16, CAF: 9, AFC: 8, CONMEBOL: 6, CONCACAF: 6, OFC: 1 },
        sources: ["arxivSlots", "si2017"]
      }
    ];
  }
});

// src/lib/soccerInternational.ts
function confederationOf(nation) {
  return NATION_CONFED[nation] ?? "UEFA";
}
function nationsIn(conf) {
  return CONFED_POOL[conf];
}
function fifaPointsOf(nation) {
  return FIFA_POINTS[nation] ?? UNLISTED_POINTS;
}
function fifaRankOf(nation) {
  const i = RANK_ORDER.indexOf(nation);
  return i < 0 ? RANK_ORDER.length + 1 : i + 1;
}
function nationStrength(nation) {
  const forced = STRENGTH_OVERRIDE.get(nation);
  if (forced !== void 0) return forced;
  const pts = fifaPointsOf(nation);
  return Math.round(clamp(60 + (pts - 1300) / 700 * 32, 55, 95) * 10) / 10;
}
function isWorldCupYear(year) {
  return year % 4 === 2;
}
function isContinentalYear(year) {
  return year % 4 === 0;
}
function formatInForce(base, competition, year) {
  const row = playedPeriod(periodInForce(competition, year));
  const mix = competition === "WC" ? wcFieldMixFor(year) : null;
  const key = `${row.id}|${mix ? mix.from : ""}`;
  const cached = FORMAT_CACHE.get(key);
  if (cached) return cached;
  const finalists = competition === "CONMEBOL" ? Math.min(CONFED_MEMBERS.CONMEBOL, row.teams) : row.teams;
  const fmt = {
    ...base,
    teams: row.teams,
    groups: row.groups,
    thirdsThrough: row.thirdsThrough,
    finalists,
    periodId: row.id,
    firstRound: row.firstKnockout ?? void 0,
    ...mix ? { fieldMix: { places: { ...mix.places }, open: mix.open } } : {},
    ...row.guestsFrom ? { guestsFrom: row.guestsFrom } : {}
  };
  FORMAT_CACHE.set(key, fmt);
  return fmt;
}
function tournamentForYear(nation, year) {
  if (isWorldCupYear(year)) return formatInForce(WORLD_CUP, "WC", year);
  if (isContinentalYear(year)) {
    const conf = confederationOf(nation);
    return formatInForce(CONTINENTAL[conf], conf, year);
  }
  return null;
}
function poisson(mean) {
  const l = Math.exp(-Math.max(0.05, mean));
  let k = 0, p = 1;
  do {
    k++;
    p *= Math.random();
  } while (p > l && k < 12);
  return k - 1;
}
function toHistoryEntry(t, eligible = true) {
  return {
    year: t.year,
    short: t.short,
    nation: t.nation,
    champion: t.champion,
    myResult: eligible ? t.myResult : "",
    apps: t.playerApps,
    goals: t.playerGoals
  };
}
function simMatch(strA, strB, knockout, bonusA = 0, bonusB = 0) {
  const d = (strA - strB) / 10;
  const a = poisson(Math.max(0.2, 1.35 * Math.exp(0.26 * d) + bonusA));
  const b = poisson(Math.max(0.2, 1.35 * Math.exp(-0.26 * d) + bonusB));
  if (knockout && a === b) {
    const diff = (strA - strB) / 100;
    return { a, b, pens: true, aWins: Math.random() < 0.5 + clamp(diff, -0.25, 0.25) * 0.4 };
  }
  return { a, b, pens: false, aWins: a > b };
}
function positionGroup(pos) {
  if (pos === "GK") return "GK";
  if (ATTACKERS.includes(pos)) return "ATT";
  if (MIDFIELDERS.includes(pos)) return "MID";
  return "DEF";
}
function playerMatchStats(form, teamGoals) {
  const grp = positionGroup(form.position);
  const quality = clamp((form.overall - 68) / 28, 0, 1.2);
  const share = grp === "ATT" ? 0.55 : grp === "MID" ? 0.25 : grp === "DEF" ? 0.12 : 0;
  let goals = 0;
  for (let i = 0; i < teamGoals; i++) if (Math.random() < share * (0.6 + quality * 0.6)) goals++;
  let assists = 0;
  const aShare = grp === "ATT" ? 0.2 : grp === "MID" ? 0.3 : grp === "DEF" ? 0.12 : 0.02;
  for (let i = 0; i < teamGoals - goals; i++) if (Math.random() < aShare * (0.6 + quality * 0.6)) assists++;
  const rating = clamp(
    6.2 + quality * 0.9 + goals * 0.55 + assists * 0.3 + (Math.random() - 0.45) * 1.1,
    4,
    10
  );
  return { goals, assists, rating: Math.round(rating * 10) / 10 };
}
function playerLift(form) {
  if (!form) return 0;
  const grp = positionGroup(form.position);
  const weight = grp === "ATT" ? 1 : grp === "MID" ? 0.7 : grp === "DEF" ? 0.35 : 0.3;
  return clamp((form.overall - 74) / 24, 0, 1) * 0.65 * weight;
}
function throughPerGroup(conf, finalists) {
  const members = CONFED_MEMBERS[conf];
  const share = Math.min(1, finalists / members);
  return clamp(Math.round(6 * share), 1, 5);
}
function finalistsFor(fmt, conf) {
  if (fmt.kind === "World Cup") {
    const mix = fmt.fieldMix ?? { places: WC_SLOTS, open: WC_PLAYOFF_SLOTS };
    return mix.places[conf] + mix.open / 6;
  }
  return fmt.finalists;
}
function drawQualifyingGroup(nation, conf) {
  const pool = nationsIn(conf).filter((n) => n !== nation);
  const ranked = [...pool].sort((a, b) => fifaRankOf(a) - fifaRankOf(b));
  const potSize = Math.max(1, Math.ceil(ranked.length / 6));
  const group = [nation];
  const allRanked = [...nationsIn(conf)].sort((a, b) => fifaRankOf(a) - fifaRankOf(b));
  const myPot = Math.min(5, Math.floor(allRanked.indexOf(nation) / Math.max(1, Math.ceil(allRanked.length / 6))));
  for (let pot = 0; pot < 6; pot++) {
    if (pot === myPot) continue;
    const slice = ranked.slice(pot * potSize, (pot + 1) * potSize).filter((n) => !group.includes(n));
    if (!slice.length) continue;
    group.push(slice[Math.floor(Math.random() * slice.length)]);
  }
  const rest = shuffle(pool.filter((n) => !group.includes(n)));
  while (group.length < 6 && rest.length) group.push(rest.pop());
  return group;
}
function blankTable(nations) {
  return nations.map((n) => ({ nation: n, played: 0, won: 0, drawn: 0, lost: 0, gf: 0, ga: 0, points: 0 }));
}
function applyResult(table, home, away, hg, ag) {
  const h = table.find((r) => r.nation === home);
  const a = table.find((r) => r.nation === away);
  if (!h || !a) return;
  h.played++;
  a.played++;
  h.gf += hg;
  h.ga += ag;
  a.gf += ag;
  a.ga += hg;
  if (hg > ag) {
    h.won++;
    a.lost++;
    h.points += 3;
  } else if (hg < ag) {
    a.won++;
    h.lost++;
    a.points += 3;
  } else {
    h.drawn++;
    a.drawn++;
    h.points++;
    a.points++;
  }
}
function sortTable(table) {
  return [...table].sort((x, y) => y.points - x.points || y.gf - y.ga - (x.gf - x.ga) || y.gf - x.gf || fifaRankOf(x.nation) - fifaRankOf(y.nation));
}
function runQualifying(nation, fmt, form) {
  const conf = confederationOf(nation);
  const automatic = fmt.kind === "Continental" && fmt.finalists >= CONFED_MEMBERS[conf];
  const group = drawQualifyingGroup(nation, conf);
  const table = blankTable(group);
  const lift = playerLift(form);
  for (let i = 0; i < group.length; i++) {
    for (let j = 0; j < group.length; j++) {
      if (i === j) continue;
      const home = group[i], away = group[j];
      const r = simMatch(
        nationStrength(home) + 3,
        nationStrength(away),
        false,
        home === nation ? lift : 0,
        away === nation ? lift : 0
      );
      applyResult(table, home, away, r.a, r.b);
    }
  }
  const sorted = sortTable(table);
  const myPosition = sorted.findIndex((r) => r.nation === nation) + 1;
  const through = automatic ? 6 : throughPerGroup(conf, finalistsFor(fmt, conf));
  return {
    confederation: conf,
    table: sorted,
    myPosition,
    through,
    qualified: automatic || myPosition <= through,
    automatic
  };
}
function pickField(pool, n, forced) {
  const out = [];
  if (forced && pool.includes(forced)) out.push(forced);
  const rest = pool.filter((p) => !out.includes(p));
  const weighted = rest.map((nation) => ({ nation, w: 1 / Math.sqrt(fifaRankOf(nation)) * (0.55 + Math.random()) })).sort((a, b) => b.w - a.w);
  for (const w of weighted) {
    if (out.length >= n) break;
    out.push(w.nation);
  }
  return out.slice(0, n);
}
function buildField(fmt, nation, qualified) {
  const forced = qualified ? nation : null;
  if (fmt.kind === "World Cup") {
    const field2 = [];
    const myConf = confederationOf(nation);
    const mix = fmt.fieldMix ?? { places: WC_SLOTS, open: WC_PLAYOFF_SLOTS };
    for (const conf2 of Object.keys(WC_SLOTS)) {
      const slots = mix.places[conf2];
      const picked = pickField(nationsIn(conf2), slots, conf2 === myConf ? forced : null);
      field2.push(...picked);
    }
    const leftovers = Object.keys(WC_SLOTS).flatMap((c) => nationsIn(c)).filter((n) => !field2.includes(n));
    const stillOut = forced && !field2.includes(forced) ? forced : null;
    field2.push(...pickField(leftovers, mix.open, stillOut));
    if (forced && !field2.includes(forced) && NATION_CONFED[forced]) {
      let weakest = 0;
      for (let i = 1; i < field2.length; i++) {
        if (fifaRankOf(field2[i]) > fifaRankOf(field2[weakest])) weakest = i;
      }
      field2[weakest] = forced;
    }
    let filler2 = 1;
    while (field2.length < fmt.teams) field2.push(`Invitational XI ${filler2++}`);
    return field2.slice(0, fmt.teams);
  }
  const conf = fmt.confederation ?? confederationOf(nation);
  if (conf === "CONMEBOL") {
    const home = pickField(nationsIn("CONMEBOL"), Math.min(10, fmt.teams), forced);
    const guests = pickField(nationsIn(fmt.guestsFrom ?? "CONCACAF"), fmt.teams - home.length, null);
    return [...home, ...guests];
  }
  const field = pickField(nationsIn(conf), fmt.teams, forced);
  let filler = 1;
  while (field.length < fmt.teams) field.push(`Invitational XI ${filler++}`);
  return field;
}
function firstRoundFor(n) {
  if (n >= 32) return "R32";
  if (n >= 16) return "R16";
  if (n >= 8) return "QF";
  return "SF";
}
function simulateTournament(nation, fmt, year, qualifying, squad, form) {
  const qualified = qualifying.qualified;
  const inSquad = qualified && !!squad?.called;
  const myForm = inSquad ? form : null;
  const field = buildField(fmt, nation, qualified);
  const strength = {};
  for (const t of field) strength[t] = nationStrength(t);
  if (inSquad && form) strength[nation] = Math.min(93, strength[nation] + playerLift(form) * 4);
  const matches = [];
  const lift = playerLift(myForm);
  const seeded = [...field].sort((a, b) => strength[b] - strength[a]);
  const pots = [];
  for (let p = 0; p < 4; p++) pots.push(shuffle(seeded.slice(p * fmt.groups, (p + 1) * fmt.groups)));
  const groups = [];
  for (let g = 0; g < fmt.groups; g++) groups.push(pots.map((pot) => pot[g]).filter(Boolean));
  const tables = [];
  for (let g = 0; g < groups.length; g++) {
    const grp = groups[g];
    const table = blankTable(grp);
    const label = `Group ${String.fromCharCode(65 + g)}`;
    for (let i = 0; i < grp.length; i++) {
      for (let j = i + 1; j < grp.length; j++) {
        const home = grp[i], away = grp[j];
        const r = simMatch(
          strength[home],
          strength[away],
          false,
          home === nation ? lift : 0,
          away === nation ? lift : 0
        );
        applyResult(table, home, away, r.a, r.b);
        if (inSquad && (home === nation || away === nation) && myForm) {
          const mine = home === nation ? r.a : r.b;
          const ps = playerMatchStats(myForm, mine);
          matches.push({
            round: label,
            home,
            away,
            homeGoals: r.a,
            awayGoals: r.b,
            pens: false,
            playerGoals: ps.goals,
            playerAssists: ps.assists,
            playerRating: ps.rating
          });
        }
      }
    }
    tables.push(sortTable(table));
  }
  const myGroupIdx = groups.findIndex((g) => g.includes(nation));
  const groupTable = myGroupIdx >= 0 ? tables[myGroupIdx] : [];
  const through = [];
  for (const t of tables) through.push(...t.slice(0, 2).map((r) => r.nation));
  if (fmt.thirdsThrough > 0) {
    const thirds = tables.map((t) => t[2]).filter(Boolean);
    const best = [...thirds].sort((x, y) => y.points - x.points || y.gf - y.ga - (x.gf - x.ga) || y.gf - x.gf);
    through.push(...best.slice(0, fmt.thirdsThrough).map((r) => r.nation));
  }
  const koField = shuffle(through);
  const bracket = [];
  const first = fmt.firstRound ?? firstRoundFor(koField.length);
  let roundIdx = KO_ORDER.indexOf(first);
  let current = koField.slice(0, 2 ** (KO_ORDER.length - roundIdx));
  while (current.length >= 2 && roundIdx < KO_ORDER.length) {
    const round = KO_ORDER[roundIdx];
    const next = [];
    for (let i = 0; i * 2 + 1 < current.length; i++) {
      const home = current[i * 2], away = current[i * 2 + 1];
      const mine = home === nation || away === nation;
      const r = simMatch(
        strength[home] ?? 70,
        strength[away] ?? 70,
        true,
        home === nation ? lift : 0,
        away === nation ? lift : 0
      );
      const winner = r.aWins ? home : away;
      bracket.push({
        round,
        slot: i,
        home,
        away,
        homeGoals: r.a,
        awayGoals: r.b,
        pens: r.pens,
        winner,
        mine
      });
      if (mine && inSquad && myForm) {
        const myGoals = home === nation ? r.a : r.b;
        const ps = playerMatchStats(myForm, myGoals);
        matches.push({
          round,
          home,
          away,
          homeGoals: r.a,
          awayGoals: r.b,
          pens: r.pens,
          playerGoals: ps.goals,
          playerAssists: ps.assists,
          playerRating: ps.rating
        });
      }
      next.push(winner);
    }
    current = next;
    roundIdx++;
    if (current.length === 1) break;
  }
  const finalTie = bracket.find((t) => t.round === "F");
  const champion = finalTie?.winner ?? current[0] ?? field[0];
  const runnerUp = finalTie ? finalTie.winner === finalTie.home ? finalTie.away : finalTie.home : "";
  let myResult;
  if (!qualified) myResult = "Did Not Qualify";
  else if (!inSquad) myResult = "Not Selected";
  else if (champion === nation) myResult = "Winner";
  else {
    const myTies = bracket.filter((t) => t.mine);
    if (!myTies.length) myResult = "Group Stage";
    else {
      const last = myTies[myTies.length - 1];
      myResult = last.winner === nation ? "Runner-up" : EXIT_LABEL[last.round];
    }
  }
  const playerApps = matches.length;
  const playerGoals = matches.reduce((s, m) => s + m.playerGoals, 0);
  const playerAssists = matches.reduce((s, m) => s + m.playerAssists, 0);
  const playerAvgRating = playerApps ? Math.round(matches.reduce((s, m) => s + m.playerRating, 0) / playerApps * 10) / 10 : 0;
  const goldenBoot = playerGoals >= (fmt.kind === "World Cup" ? 6 : 5);
  const bestPlayer = playerApps >= 4 && playerAvgRating >= 7.6 && (myResult === "Winner" || myResult === "Runner-up" || myResult === "Semi-final");
  return {
    year,
    name: fmt.name,
    short: fmt.short,
    kind: fmt.kind,
    confederation: fmt.confederation,
    nation,
    teams: fmt.teams,
    qualifying,
    qualified,
    squad,
    groupTable,
    bracket,
    champion,
    runnerUp,
    groupLabel: myGroupIdx >= 0 ? `Group ${String.fromCharCode(65 + myGroupIdx)}` : void 0,
    thirdsThrough: fmt.thirdsThrough,
    myResult,
    matches,
    playerApps,
    playerGoals,
    playerAssists,
    playerAvgRating,
    goldenBoot,
    bestPlayer
  };
}
function offYearCaps(form) {
  if (!form) return 0;
  return rnd(5, 9);
}
var CONFED_MEMBERS, NATION_CONFED, CONFED_POOL, FIFA_POINTS, UNLISTED_POINTS, RANK_ORDER, STRENGTH_OVERRIDE, WORLD_CUP, CONTINENTAL, FORMAT_CACHE, WC_SLOTS, WC_PLAYOFF_SLOTS, rnd, shuffle, clamp, ATTACKERS, MIDFIELDERS, SQUAD_PLACES, KO_ORDER, EXIT_LABEL;
var init_soccerInternational = __esm({
  "src/lib/soccerInternational.ts"() {
    init_intlFormatHistory();
    CONFED_MEMBERS = {
      UEFA: 55,
      CONMEBOL: 10,
      CAF: 54,
      AFC: 47,
      CONCACAF: 41,
      OFC: 11
    };
    NATION_CONFED = {
      // UEFA
      Albania: "UEFA",
      Armenia: "UEFA",
      Austria: "UEFA",
      Azerbaijan: "UEFA",
      Belarus: "UEFA",
      Belgium: "UEFA",
      "Bosnia & Herzegovina": "UEFA",
      Bulgaria: "UEFA",
      Croatia: "UEFA",
      Cyprus: "UEFA",
      "Czech Republic": "UEFA",
      Denmark: "UEFA",
      England: "UEFA",
      Estonia: "UEFA",
      "Faroe Islands": "UEFA",
      Finland: "UEFA",
      France: "UEFA",
      Georgia: "UEFA",
      Germany: "UEFA",
      Greece: "UEFA",
      Hungary: "UEFA",
      Iceland: "UEFA",
      Ireland: "UEFA",
      Israel: "UEFA",
      Italy: "UEFA",
      Kazakhstan: "UEFA",
      Kosovo: "UEFA",
      Latvia: "UEFA",
      Liechtenstein: "UEFA",
      Lithuania: "UEFA",
      Luxembourg: "UEFA",
      Malta: "UEFA",
      Moldova: "UEFA",
      Montenegro: "UEFA",
      Netherlands: "UEFA",
      "North Macedonia": "UEFA",
      "Northern Ireland": "UEFA",
      Norway: "UEFA",
      Poland: "UEFA",
      Portugal: "UEFA",
      Romania: "UEFA",
      Russia: "UEFA",
      Scotland: "UEFA",
      Serbia: "UEFA",
      Slovakia: "UEFA",
      Slovenia: "UEFA",
      Spain: "UEFA",
      Sweden: "UEFA",
      Switzerland: "UEFA",
      Turkey: "UEFA",
      Ukraine: "UEFA",
      Wales: "UEFA",
      // CONMEBOL
      Argentina: "CONMEBOL",
      Bolivia: "CONMEBOL",
      Brazil: "CONMEBOL",
      Chile: "CONMEBOL",
      Colombia: "CONMEBOL",
      Ecuador: "CONMEBOL",
      Paraguay: "CONMEBOL",
      Peru: "CONMEBOL",
      Uruguay: "CONMEBOL",
      Venezuela: "CONMEBOL",
      // CAF
      Algeria: "CAF",
      Angola: "CAF",
      Benin: "CAF",
      "Burkina Faso": "CAF",
      Cameroon: "CAF",
      "Cape Verde": "CAF",
      Comoros: "CAF",
      Congo: "CAF",
      "DR Congo": "CAF",
      Egypt: "CAF",
      Ethiopia: "CAF",
      Gabon: "CAF",
      Ghana: "CAF",
      Guinea: "CAF",
      "Guinea-Bissau": "CAF",
      "Ivory Coast": "CAF",
      Kenya: "CAF",
      Liberia: "CAF",
      Libya: "CAF",
      Madagascar: "CAF",
      Mali: "CAF",
      Morocco: "CAF",
      Mozambique: "CAF",
      Nigeria: "CAF",
      Senegal: "CAF",
      "Sierra Leone": "CAF",
      "South Africa": "CAF",
      Tanzania: "CAF",
      "The Gambia": "CAF",
      Togo: "CAF",
      Tunisia: "CAF",
      Uganda: "CAF",
      Zambia: "CAF",
      Zimbabwe: "CAF",
      // AFC
      Australia: "AFC",
      Bahrain: "AFC",
      China: "AFC",
      India: "AFC",
      Indonesia: "AFC",
      Iran: "AFC",
      Iraq: "AFC",
      Japan: "AFC",
      Jordan: "AFC",
      Kuwait: "AFC",
      Lebanon: "AFC",
      "North Korea": "AFC",
      Oman: "AFC",
      Philippines: "AFC",
      Qatar: "AFC",
      "Saudi Arabia": "AFC",
      "South Korea": "AFC",
      Tajikistan: "AFC",
      Thailand: "AFC",
      "United Arab Emirates": "AFC",
      Uzbekistan: "AFC",
      Vietnam: "AFC",
      // Both play Asian Cup and AFC World Cup qualifying, both are inside the
      // published world top 100, so both are here as opponents.
      Syria: "AFC",
      Palestine: "AFC",
      // CONCACAF
      Canada: "CONCACAF",
      "Costa Rica": "CONCACAF",
      Cuba: "CONCACAF",
      "Cura\xE7ao": "CONCACAF",
      "Dominican Republic": "CONCACAF",
      "El Salvador": "CONCACAF",
      Guatemala: "CONCACAF",
      Haiti: "CONCACAF",
      Honduras: "CONCACAF",
      Jamaica: "CONCACAF",
      Mexico: "CONCACAF",
      Panama: "CONCACAF",
      Suriname: "CONCACAF",
      "Trinidad and Tobago": "CONCACAF",
      USA: "CONCACAF",
      /* OFC. New Zealand is the only Oceanian side the player picker offers, but
         a confederation of one cannot run a qualifying group, so the other ten
         full members are here as opponents. List and count from
         en.wikipedia.org/wiki/Oceania_Football_Confederation (11 full members),
         read August 2026. */
      "New Zealand": "OFC",
      "New Caledonia": "OFC",
      Tahiti: "OFC",
      Fiji: "OFC",
      "Solomon Islands": "OFC",
      "Papua New Guinea": "OFC",
      Vanuatu: "OFC",
      Samoa: "OFC",
      "American Samoa": "OFC",
      "Cook Islands": "OFC",
      Tonga: "OFC"
    };
    CONFED_POOL = {
      UEFA: [],
      CONMEBOL: [],
      CAF: [],
      AFC: [],
      CONCACAF: [],
      OFC: []
    };
    for (const [nation, conf] of Object.entries(NATION_CONFED)) CONFED_POOL[conf].push(nation);
    FIFA_POINTS = {
      Spain: 1995.88,
      Argentina: 1970.37,
      France: 1948.97,
      England: 1922.83,
      Brazil: 1804.92,
      Morocco: 1803.99,
      Portugal: 1787.85,
      Belgium: 1778.36,
      Netherlands: 1775.54,
      Mexico: 1754.3,
      Colombia: 1739.89,
      Germany: 1726.22,
      Croatia: 1723.05,
      Switzerland: 1710.88,
      Italy: 1704.73,
      USA: 1690.33,
      Japan: 1673.68,
      Senegal: 1653.43,
      Norway: 1651.29,
      Uruguay: 1634.7,
      Denmark: 1619.47,
      Iran: 1609.85,
      Austria: 1598.82,
      Egypt: 1597.04,
      Ecuador: 1592.59,
      Nigeria: 1585.02,
      Turkey: 1582.54,
      Australia: 1581.51,
      Algeria: 1576.8,
      Canada: 1571.34,
      "Ivory Coast": 1565.47,
      "South Korea": 1558.72,
      Ukraine: 1549.29,
      Paraguay: 1542.48,
      Russia: 1529.6,
      Poland: 1526.18,
      Sweden: 1525.58,
      Wales: 1516.95,
      Hungary: 1506.39,
      Serbia: 1502.13,
      "DR Congo": 1495.48,
      Scotland: 1491.22,
      Cameroon: 1481.24,
      Panama: 1478.41,
      Slovakia: 1473.66,
      Greece: 1473.19,
      Venezuela: 1469.18,
      "Czech Republic": 1467.26,
      Chile: 1458.2,
      Peru: 1457.69,
      "Costa Rica": 1456.03,
      Romania: 1455.89,
      Mali: 1455.59,
      "South Africa": 1451.24,
      Ireland: 1441.1,
      // listed as Republic of Ireland
      Slovenia: 1441.09,
      Tunisia: 1426.58,
      "Saudi Arabia": 1425.52,
      Qatar: 1411.06,
      Uzbekistan: 1409.73,
      "Bosnia & Herzegovina": 1408.93,
      "Burkina Faso": 1406.99,
      Iraq: 1404.17,
      "Cape Verde": 1402.97,
      // listed as Cabo Verde
      Ghana: 1387,
      Honduras: 1378.97,
      Albania: 1376.03,
      "United Arab Emirates": 1370.47,
      "North Macedonia": 1369.16,
      "Northern Ireland": 1365.3,
      Jamaica: 1357.84,
      Georgia: 1355.26,
      Jordan: 1350.41,
      Iceland: 1342.77,
      Finland: 1341.92,
      Israel: 1333.9,
      Bolivia: 1326,
      Kosovo: 1319.12,
      Oman: 1306.9,
      Montenegro: 1301.98,
      Guinea: 1295.6,
      "Cura\xE7ao": 1285.64,
      Syria: 1283.05,
      Gabon: 1272.51,
      Bulgaria: 1271.68,
      "New Zealand": 1269.8,
      Angola: 1265.58,
      Haiti: 1264.58,
      Uganda: 1264.09,
      Thailand: 1256.73,
      Zambia: 1255.82,
      China: 1254.81,
      // listed as China PR
      Bahrain: 1254.41,
      Benin: 1252.17,
      Palestine: 1243.71,
      Belarus: 1242.88,
      Guatemala: 1238.74,
      Luxembourg: 1232.82,
      Vietnam: 1230.67,
      "El Salvador": 1225.34
    };
    UNLISTED_POINTS = 1180;
    RANK_ORDER = Object.entries(FIFA_POINTS).sort((a, b) => b[1] - a[1]).map((e) => e[0]);
    STRENGTH_OVERRIDE = /* @__PURE__ */ new Map();
    WORLD_CUP = {
      name: "World Cup",
      short: "World Cup",
      kind: "World Cup",
      confederation: null,
      teams: 48,
      groups: 12,
      thirdsThrough: 8,
      finalists: 48
    };
    CONTINENTAL = {
      UEFA: {
        name: "European Championship",
        short: "Euros",
        kind: "Continental",
        confederation: "UEFA",
        teams: 24,
        groups: 6,
        thirdsThrough: 4,
        finalists: 24
      },
      CONMEBOL: {
        name: "Copa Am\xE9rica",
        short: "Copa Am\xE9rica",
        kind: "Continental",
        confederation: "CONMEBOL",
        teams: 16,
        groups: 4,
        thirdsThrough: 0,
        finalists: 10
      },
      CAF: {
        name: "Africa Cup of Nations",
        short: "AFCON",
        kind: "Continental",
        confederation: "CAF",
        teams: 24,
        groups: 6,
        thirdsThrough: 4,
        finalists: 24
      },
      AFC: {
        name: "Asian Cup",
        short: "Asian Cup",
        kind: "Continental",
        confederation: "AFC",
        teams: 24,
        groups: 6,
        thirdsThrough: 4,
        finalists: 24
      },
      CONCACAF: {
        name: "Gold Cup",
        short: "Gold Cup",
        kind: "Continental",
        confederation: "CONCACAF",
        teams: 16,
        groups: 4,
        thirdsThrough: 0,
        finalists: 16
      },
      OFC: {
        name: "OFC Nations Cup",
        short: "Nations Cup",
        kind: "Continental",
        confederation: "OFC",
        teams: 8,
        groups: 2,
        thirdsThrough: 0,
        finalists: 8
      }
    };
    FORMAT_CACHE = /* @__PURE__ */ new Map();
    WC_SLOTS = {
      UEFA: 16,
      CAF: 9,
      AFC: 8,
      CONMEBOL: 6,
      CONCACAF: 6,
      OFC: 1
    };
    WC_PLAYOFF_SLOTS = 2;
    rnd = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
    shuffle = (arr) => {
      const a = [...arr];
      for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
      }
      return a;
    };
    clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
    ATTACKERS = ["ST", "CAM", "LW", "RW"];
    MIDFIELDERS = ["CM", "CDM"];
    SQUAD_PLACES = {
      GK: 3,
      DEF: 9,
      MID: 8,
      ATT: 6
    };
    KO_ORDER = ["R32", "R16", "QF", "SF", "F"];
    EXIT_LABEL = {
      R32: "Round of 32",
      R16: "Round of 16",
      QF: "Quarter-final",
      SF: "Semi-final",
      F: "Runner-up"
    };
  }
});

// src/lib/clubManagerUclGroups.ts
function miniLeague(run, pairs) {
  const line = /* @__PURE__ */ new Map();
  for (const r of run) {
    let pts = 0;
    let gd = 0;
    let gf = 0;
    let away = 0;
    for (const o of run) {
      if (o.club === r.club) continue;
      const atHome = pairs[`${r.club}|${o.club}`];
      const atTheirs = pairs[`${o.club}|${r.club}`];
      if (!atHome || !atTheirs) return null;
      pts += atHome[0] > atHome[1] ? 3 : atHome[0] === atHome[1] ? 1 : 0;
      pts += atTheirs[1] > atTheirs[0] ? 3 : atTheirs[0] === atTheirs[1] ? 1 : 0;
      gd += atHome[0] - atHome[1] + (atTheirs[1] - atTheirs[0]);
      gf += atHome[0] + atTheirs[1];
      away += atTheirs[1];
    }
    line.set(r.club, { pts, gd, gf, away });
  }
  return line;
}
function byOverall(run) {
  return [...run].sort((a, b) => b.gf - b.ga - (a.gf - a.ga) || b.gf - a.gf || a.club.localeCompare(b.club));
}
function orderHeadToHead(run, pairs, full) {
  const line = miniLeague(run, pairs);
  if (!line) return byOverall(run);
  const key = (r) => {
    const h = line.get(r.club);
    return full ? [h.pts, h.gd, h.gf, h.away] : [h.pts, h.gd, h.away];
  };
  const cmp = (a, b) => {
    const ka = key(a);
    const kb = key(b);
    for (let i2 = 0; i2 < ka.length; i2++) if (ka[i2] !== kb[i2]) return kb[i2] - ka[i2];
    return a.club.localeCompare(b.club);
  };
  const sorted = [...run].sort(cmp);
  const same = (a, b) => {
    const ka = key(a);
    const kb = key(b);
    return ka.every((v, i2) => v === kb[i2]);
  };
  const out = [];
  let i = 0;
  while (i < sorted.length) {
    let j = i + 1;
    while (j < sorted.length && same(sorted[j], sorted[i])) j += 1;
    const sub = sorted.slice(i, j);
    if (sub.length === 1) out.push(sub[0]);
    else if (full && sub.length < run.length) out.push(...orderHeadToHead(sub, pairs, full));
    else out.push(...byOverall(sub));
    i = j;
  }
  return out;
}
function sortedUclGroupTable(rows, rule, pairs) {
  const byPts = [...rows].sort((a, b) => b.pts - a.pts || a.club.localeCompare(b.club));
  const out = [];
  let i = 0;
  while (i < byPts.length) {
    let j = i + 1;
    while (j < byPts.length && byPts[j].pts === byPts[i].pts) j += 1;
    const run = byPts.slice(i, j);
    if (run.length === 1) out.push(run[0]);
    else if (rule === "leaguePhase") out.push(...byOverall(run));
    else out.push(...orderHeadToHead(run, pairs ?? {}, rule === "h2hFull"));
    i = j;
  }
  return out;
}
function countWaitingLevelRuns(sorted, pairs) {
  let waiting = 0;
  for (let i = 0; i < sorted.length; ) {
    let j = i + 1;
    while (j < sorted.length && sorted[j].pts === sorted[i].pts) j += 1;
    const run = sorted.slice(i, j);
    if (run.length > 1) {
      let complete = true;
      for (let a = 0; a < run.length && complete; a += 1) {
        for (let b = a + 1; b < run.length; b += 1) {
          const x = run[a].club;
          const y = run[b].club;
          if (!pairs?.[`${x}|${y}`] || !pairs?.[`${y}|${x}`]) {
            complete = false;
            break;
          }
        }
      }
      if (!complete) waiting += 1;
    }
    i = j;
  }
  return waiting;
}
function uclGroupFootnote(rows, rule, pairs) {
  if (rule === "leaguePhase") {
    return "Level on points splits on goal difference, then goals scored.";
  }
  const sorted = sortedUclGroupTable(rows, rule, pairs);
  const waiting = countWaitingLevelRuns(sorted, pairs);
  const pending = waiting === 0 ? "" : ` ${waiting} level ${waiting === 1 ? "group has games" : "groups have games"} still to play between them, so ${waiting === 1 ? "it splits" : "they split"} on goal difference for now.`;
  const steps = rule === "h2hFull" ? "points, then goal difference, then goals, then away goals" : "points, then goal difference, then away goals";
  return `Level on points splits on the games between the level clubs first (${steps}) once they have met twice, then overall goal difference, then goals scored.${pending}`;
}
var init_clubManagerUclGroups = __esm({
  "src/lib/clubManagerUclGroups.ts"() {
  }
});

// src/data/clubRivalries.ts
var SC_CLUB_CANON, CLUB_RIVALRIES;
var init_clubRivalries = __esm({
  "src/data/clubRivalries.ts"() {
    SC_CLUB_CANON = {
      "Man City": "Manchester City",
      "Man United": "Manchester United",
      "Athletic Bilbao": "Athletic Club",
      "Atletico Madrid": "Atl\xE9tico Madrid",
      "Dortmund": "Borussia Dortmund",
      "Frankfurt": "Eintracht Frankfurt",
      "Leipzig": "RB Leipzig",
      "Leverkusen": "Bayer Leverkusen",
      "Hertha Berlin": "Hertha BSC",
      "Vitoria Guimaraes": "Vit\xF3ria Guimar\xE3es",
      "Sao Paulo": "S\xE3o Paulo",
      "Gremio": "Gr\xEAmio",
      "Chivas": "Guadalajara",
      "Club America": "Am\xE9rica",
      "Pumas": "Pumas UNAM",
      "Al Hilal": "Al-Hilal",
      "Al Nassr": "Al-Nassr",
      "Al Ittihad": "Al-Ittihad",
      "Al Ahli": "Al-Ahli",
      "Al Shabab": "Al-Shabab",
      "Fenerbahce": "Fenerbah\xE7e",
      "Besiktas": "Be\u015Fikta\u015F",
      /* Round 1013's clubs that the shared table names under another spelling
         (scripts/lib/careerClubPool.mjs NAME_ALIASES has the same two, the other
         way round; simCareerDerbies section 1 holds the two maps together). */
      "Deportivo": "Deportivo La Coru\xF1a",
      "Atletico Mineiro": "Atl\xE9tico Mineiro"
    };
    CLUB_RIVALRIES = [
      // England
      { a: "Arsenal", b: "Tottenham", name: "North London derby", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "ESPN", title: "North London derby: History, stats for Tottenham-Arsenal", url: "https://www.espn.com/soccer/story/_/id/41247087/north-london-derby-history-stats-tottenham-arsenal" },
        { publisher: "Goal", title: "Arsenal vs Tottenham: Everything you need to know about the north London derby", url: "https://www.goal.com/en-us/news/north-london-derby-arsenal-tottenham-everything-you-need-to-know-/65ysonfwoofz1nhaq82x7nkoc" }
      ] },
      { a: "Liverpool", b: "Everton", name: "Merseyside derby", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Liverpool FC", title: "Which grounds have Merseyside derbies been played at?", url: "https://www.liverpoolfc.com/news/which-grounds-have-merseyside-derbies-been-played" },
        { publisher: "The Analyst", title: "Goodison Park's Final Derby: 130 Years of Merseyside Rivalry in Numbers", url: "https://theanalyst.com/articles/everton-vs-liverpool-merseyside-derby-goodison-park" }
      ] },
      { a: "Manchester City", b: "Manchester United", name: "Manchester derby", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Sports Illustrated", title: "Man Utd vs. Man City: Complete Head-to-Head Record", url: "https://www.si.com/soccer/manchester-city-vs-manchester-united-complete-head-to-head-record" },
        { publisher: "The Sporting News (on Yahoo Sports)", title: "Man United vs. Man City history, head to head: All-time records in Manchester derby", url: "https://sports.yahoo.com/articles/man-united-vs-man-city-185000803.html" }
      ] },
      { a: "Liverpool", b: "Manchester United", name: "North West derby", kind: "rivalry", checked: "2026-10-05", sources: [
        { publisher: "FBref", title: "North West Derby History Liverpool vs. Manchester United Historical Head-to-Head", url: "https://fbref.com/en/stathead/matchup/teams/822bd0ba/19538871/North-West-Derby-Liverpool-vs-Manchester-United-History" },
        { publisher: "Goal", title: "Are Liverpool the biggest rivals for Manchester United?", url: "https://www.goal.com/en-us/news/are-liverpool-the-biggest-rivals-for-manchester-united/pw1pwl5czf3w1k2gfl2l39fha" }
      ] },
      { a: "Crystal Palace", b: "Brighton", name: "M23 derby", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Football Ground Guide", title: "Brighton vs. Crystal Palace rivalry: M23 derby origin, history and head-to-head record", url: "https://footballgroundguide.com/news/brighton-vs-crystal-palace-rivalry-m23-derby-origin-history-and-head-to-head-record.html" },
        { publisher: "NationalWorld", title: "Why are Brighton and Crystal Palace rivals? M23 derby explained", url: "https://www.nationalworld.com/sport/football/why-are-brighton-and-crystal-palace-rivals-m23-derby-explained-ahead-of-premier-league-clash-3398190" }
      ] },
      { a: "Chelsea", b: "Tottenham", name: "London derby", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Chelsea FC", title: "Tottenham vs Chelsea: Fixture history and London derby record up for grabs", url: "https://www.chelseafc.com/en/news/article/tottenham-vs-chelsea-fixture-history-and-london-derby-record-up-for-grabs" },
        { publisher: "Goal", title: "Tottenham vs Chelsea London derby: History, games and players who played for both clubs", url: "https://www.goal.com/en/news/tottenham-vs-chelsea-london-derby-history-games--players-who-played-for-both-clubs/xajnbyec4o2s1at4t59jly1c7" }
      ] },
      { a: "Arsenal", b: "Chelsea", name: "London derby", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Sky Sports", title: "Arsenal 2-1 Chelsea: comeback win for champions in pulsating London derby", url: "https://www.skysports.com/football/news/11095/13571847/arsenal-2-1-chelsea-kai-havertz-and-martin-odegaard-secure-comeback-win-for-champions-in-pulsating-london-derby" },
        { publisher: "ESPN", title: "Title hopes of Chelsea, Arsenal make for wildly entertaining London derby draw", url: "https://www.espn.com/soccer/story/_/id/47153486/chelseaarsenal-premier-league-title-hopes-make-wildly-entertaining-london-derby" }
      ] },
      { a: "Chelsea", b: "Fulham", name: "West London derby", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "90min", title: "West London derby: Teams involved, most wins and memorable matches", url: "https://www.90min.com/posts/west-london-derby-teams-involved-most-wins-memorable-matches" },
        { publisher: "West London Sport", title: "The Rich History of the West London Derby: Fulham vs. Chelsea", url: "https://www.westlondonsport.com/sport/the-rich-history-of-the-west-london-derby-fulham-vs-chelsea" }
      ] },
      { a: "Brentford", b: "Fulham", name: "West London derby", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Brentford FC", title: "Match report: Brentford 0 Fulham 0, a west London derby", url: "https://www.brentfordfc.com/en/news/article/match-reports-brentford-0-fulham-0-premier-league-18-04-2026" },
        { publisher: "Sky Sports", title: "Fulham 3-1 Brentford: Cottagers win third straight west London derby", url: "https://www.skysports.com/football/news/11661/13432900/fulham-3-1-brentford-harry-wilson-stars-again-as-cottagers-win-third-straight-west-london-derby" }
      ] },
      { a: "West Ham", b: "Tottenham", name: "London derby", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Goal", title: "West Ham v Tottenham: A most unusual rivalry", url: "https://www.goal.com/en/news/west-ham-v-tottenham-a-most-unusual-rivalry/bltd05f5aded655b431" },
        { publisher: "Bleacher Report", title: "West Ham United Vs. Tottenham Hotspur: A Brief History of the London Rivalry", url: "https://bleacherreport.com/articles/639764-west-ham-united-vs-tottenham-hotspur-a-rivalry-written-in-history-and-violence" }
      ] },
      { a: "Aston Villa", b: "Wolves", name: "West Midlands derby", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Sky Sports", title: "Aston Villa 3-1 Wolves: late show settles West Midlands Premier League derby", url: "https://www.skysports.com/football/news/11661/13217321/aston-villa-3-1-wolves-jhon-duran-strikes-again-as-late-show-settles-west-midlands-premier-league-derby" },
        { publisher: "NBC Sports", title: "Wolves 2-0 Aston Villa: 20th-place Wolves get Midlands derby win", url: "https://www.nbcsports.com/soccer/news/wolves-vs-aston-villa-recap-final-score-video-highlights-analysis" }
      ] },
      { a: "Newcastle", b: "Sunderland", name: "Tyne-Wear derby", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "My Football Facts", title: "Tyne-Wear Derby: Head-to-Head History and Overview", url: "https://www.myfootballfacts.com/premier-league/tyne-wear-derby-head-to-head-history-overview-newcastle-united-vs-sunderland/" },
        { publisher: "Sports Mole", title: "Newcastle vs. Sunderland: Head-to-head record and past meetings in Tyne-Wear derby", url: "https://www.sportsmole.co.uk/football/sunderland/tyne-wear-derby/head-to-head/sunderland-vs-newcastle-head-to-head-record-and-past-meetings_587719.html" }
      ] },
      { a: "Wolves", b: "West Brom", name: "Black Country derby", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Wolves", title: "Old Gold: ten moments that define the Black Country derby", url: "https://www.wolves.co.uk/news/features/20240124-old-gold-ten-moments-that-define-the-black-country-derby/" },
        { publisher: "Shropshire Star", title: "Last 5 Black Country derbies as Wolves-West Brom dates revealed", url: "https://www.shropshirestar.com/sport/football/wolverhampton-wanderers/last-5-black-country-derbies-as-wolves-west-brom-dates-revealed-8760918" }
      ] },
      { a: "West Ham", b: "Millwall", name: "Dockers derby", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "beIN Sports", title: "West Ham Relegated From Premier League as the Dockers Derby Returns After 14 Years", url: "https://www.beinsports.com/en-us/soccer/premier-league/articles/west-ham-relegated-from-premier-league-as-the-dockers-derby-returns-after-14-years-2026-05-24" },
        { publisher: "GiveMeSport", title: "West Ham United vs Millwall: Biggest rivalries in world football", url: "https://www.givemesport.com/west-ham-united-vs-millwall-biggest-rivalries-in-world-football-here-is-what-you-need-to-know/" }
      ] },
      { a: "Norwich City", b: "Ipswich Town", name: "East Anglian derby", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Pink Un", title: "Decade of East Anglian Derby dominance for Norwich", url: "https://www.pinkun.com/sport/norwich-city/decade-of-east-nglian-erby-dominance-for-norwich-6500712" },
        { publisher: "Flashscore", title: "Derby Week: Ipswich Town vs Norwich City, the duel for East Anglian pride", url: "https://www.flashscoreusa.com/news/soccer-championship-derby-week-ipswich-town-vs-norwich-city-the-duel-for-east-anglian-pride/lYZz0AQr/" }
      ] },
      { a: "Manchester United", b: "Leeds United", name: "Roses rivalry", kind: "rivalry", checked: "2026-10-05", sources: [
        { publisher: "The Yorkshire Post", title: "Roses rivalry? Leeds United motivated enough even without Manchester United task, says Daniel Farke", url: "https://www.yorkshirepost.co.uk/sport/football/leeds-united/roses-rivalry-leeds-united-motivated-enough-even-without-manchester-united-task-says-daniel-farke-6570391" },
        { publisher: "NBC Sports", title: "Leeds-Manchester United Roses rivalry preview: Premier League Matchweek 33", url: "https://www.nbcsports.com/watch/soccer/premier-league/previewing-sundays-leeds-man-united-rivalry-clash" }
      ] },
      // Spain
      { a: "Real Madrid", b: "Barcelona", name: "El Clasico", kind: "rivalry", checked: "2026-10-05", sources: [
        { publisher: "beIN Sports", title: "Everything You Need to Know About El Clasico Between Real Madrid and Barcelona", url: "https://www.beinsports.com/en-us/soccer/la-liga/articles/everything-you-need-to-know-about-el-cl%C3%A1sico-between-real-madrid-and-barcelona-2025-10-21" },
        { publisher: "The Sporting News (on Yahoo Sports)", title: "Real Madrid vs. Barcelona history: El Clasico all-time head to head", url: "https://ca.sports.yahoo.com/news/real-madrid-vs-barcelona-history-100900932.html" }
      ] },
      { a: "Real Madrid", b: "Atl\xE9tico Madrid", name: "Madrid derby", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "LaLiga", title: "El Derbi de Madrid", url: "https://www.laliga.com/en-GB/partidazos/el-derbi-de-madrid" },
        { publisher: "90min", title: "Real Madrid vs Atletico Madrid: Spain's ferocious capital derby", url: "https://www.90min.com/posts/real-madrid-vs-atletico-madrid-spain-ferocious-capital-derby" }
      ] },
      { a: "Sevilla", b: "Real Betis", name: "El Gran Derbi", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "LaLiga", title: "Sevilla FC vs Real Betis head-to-head record: who has won more times?", url: "https://www.laliga.com/en-GB/news/el-gran-derbi-a-history-of-real-betis-vs-sevilla-fc" },
        { publisher: "Football Espana", title: "El Gran Derbi: A history of Sevilla and Real Betis", url: "https://www.football-espana.net/2022/02/26/el-gran-derbi-a-history-of-sevilla-real-betis" }
      ] },
      { a: "Athletic Club", b: "Real Sociedad", name: "Basque derby", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "LaLiga", title: "Derby stats and curiosities of the Basque derby", url: "https://www.laliga.com/en-GB/news/derby-stats-and-curiosities-of-the-basque-derby" },
        { publisher: "Football Espana", title: "Athletic Club vs Real Sociedad: A history of the Basque Derby", url: "https://www.football-espana.net/2024/01/13/athletic-club-vs-real-sociedad-a-history-of-the-basque-derby" }
      ] },
      { a: "Barcelona", b: "Girona", name: "Catalan derby", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "FC Barcelona", title: "FC Barcelona 4-1 Girona FC: Derby victory", url: "https://www.fcbarcelona.com/en/news/4241205/fc-barcelona-4-1-girona-fc-derby-victory" },
        { publisher: "Catalan News", title: "Barca wins against Girona with last minute goal at Catalan derby in Montjuic", url: "https://www.catalannews.com/sports/item/barca-girona-game-league-18-october-2025-catalan-derby" }
      ] },
      { a: "Barcelona", b: "Espanyol", name: "Barcelona derby", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "LaLiga", title: "FC Barcelona vs. RCD Espanyol: LALIGA Derby Statistics", url: "https://www.laliga.com/en-GB/news/statistics-fc-barcelona-rcd-espanyol" },
        { publisher: "My Football Facts", title: "Barcelona Derby Head-to-Head: Barcelona vs Espanyol History and Stats", url: "https://www.myfootballfacts.com/top-leagues/la-liga/barcelona-derby-head-to-head-barcelona-vs-espanyol-history-stats/" }
      ] },
      { a: "Celta Vigo", b: "Deportivo La Coru\xF1a", name: "Galician derby", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "The National", title: "Galician derby glory over Celta Vigo offers Deportivo La Coruna ray of light", url: "https://www.thenationalnews.com/sport/galician-derby-glory-over-celta-vigo-offers-deportivo-la-coruna-ray-of-light-1.470302" },
        { publisher: "Sportskeeda", title: "The Galician Derby: Celta Vigo take on relegated Deportivo La Coruna", url: "https://www.sportskeeda.com/football/the-galician-derby-the-last-one-for-a-while-as-celta-vigo-take-on-relegated-deportivo-la-coruna-1" }
      ] },
      { a: "Valencia", b: "Levante", name: "Valencia derby", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "elDiario.es", title: "Cinco datos y curiosidades historicas del derbi valenciano de futbol", url: "https://www.eldiario.es/spin/deportes/cinco-datos-curiosidades-historicas-derbi-valenciano-futbol-valencia-levante-laliga-pm_1_12785107.html" },
        { publisher: "7 Televalencia", title: "Vuelve el Valencia-Levante: los datos de un derbi de primera", url: "https://7televalencia.com/vuelve-valencia-levante-derbi-valenciano/" }
      ] },
      // Italy
      { a: "AC Milan", b: "Inter Milan", name: "Derby della Madonnina", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Inter", title: "Inter vs AC Milan: origins, heroes and records from the derby", url: "https://www.inter.it/en/news/inter-ac-milan-origins-heroes-records-guide-derby" },
        { publisher: "Flashscore", title: "AC Milan - Inter: The most memorable matches from Derby della Madonnina history", url: "https://www.flashscore.com/news/ac-milan-inter-the-most-memorable-matches-from-derby-della-madonnina-history/zLW83mht/" }
      ] },
      { a: "Juventus", b: "Torino", name: "Derby della Mole", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Juventus", title: "Great Juventus moments in the Derby Della Mole", url: "https://www.juventus.com/en/news/articles/great-moments-juventus-derby-della-mole" },
        { publisher: "My Football Facts", title: "Derby della Mole Head-to-Head", url: "https://www.myfootballfacts.com/top-leagues/serie%20a/derby-della-mole-head-to-head-torino-vs-juventus-history-stats/" }
      ] },
      { a: "Juventus", b: "Inter Milan", name: "Derby d'Italia", kind: "rivalry", checked: "2026-10-05", sources: [
        { publisher: "ESPN", title: "Derby d'Italia: The infamous Inter-Juventus rivalry", url: "https://www.espn.com/soccer/story/_/id/37389114/infamous-inter-juventus-rivalry" },
        { publisher: "90min", title: "Inter vs Juventus: The Rivalry at the Heart of Italian Football", url: "https://www.90min.com/posts/inter-vs-juventus-the-rivalry-at-the-heart-of-italian-football-01e9fsbz2cn0" }
      ] },
      { a: "Roma", b: "Napoli", name: "Derby del Sole", kind: "rivalry", checked: "2026-10-05", sources: [
        { publisher: "FBref", title: "Derby del Sole History Napoli vs. Roma Historical Head-to-Head", url: "https://fbref.com/en/stathead/matchup/teams/d48ad4ff/cf74a709/Derby-del-Sole-Napoli-vs-Roma-History" },
        { publisher: "La Gazzetta Italiana", title: "Calcio: Derby Del Sole", url: "https://www.lagazzettaitaliana.com/sports/9949-calcio-derby-del-sole" }
      ] },
      { a: "Bologna", b: "Fiorentina", name: "Derby dell'Appennino", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Quotidiano Sportivo", title: "Bologna-Fiorentina 1-2, the Apennine derby goes to Fiorentina", url: "https://sport.quotidiano.net/en/calcio/bologna/bologna-fiorentina-1-2-derby-appennino-viola-fa06aad1" },
        { publisher: "Il Primato Nazionale", title: "Bologna-Fiorentina, il derby dell'Appennino", url: "https://www.ilprimatonazionale.it/sport/bologna-fiorentina-il-derby-appennino-243568" }
      ] },
      { a: "Roma", b: "Lazio", name: "Derby della Capitale", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "World Football Index (on OneFootball)", title: "A Brief History Of The Derby Della Capitale Ahead Of Roma vs Lazio Clash", url: "https://onefootball.com/en/news/a-brief-history-of-the-derby-della-capitale-ahead-of-roma-vs-lazio-clash-28891985" },
        { publisher: "My Football Facts", title: "Derby della Capitale Head-to-Head", url: "https://www.myfootballfacts.com/top-leagues/serie-a/derby-della-capitale-head-to-head-as-roma-vs-lazio-history-stats" }
      ] },
      // Germany
      { a: "Bayern Munich", b: "Borussia Dortmund", name: "Der Klassiker", kind: "rivalry", checked: "2026-10-05", sources: [
        { publisher: "Bundesliga", title: "Borussia Dortmund vs. Bayern Munich: The top 5 matches in Der Klassiker history", url: "https://www.bundesliga.com/en/bundesliga/news/bayern-munich-vs-borussia-dortmund-top-5-matches-in-klassiker-history-reus-lewandowski-3242" },
        { publisher: "FourFourTwo", title: "Why Borussia Dortmund vs Bayern Munich matters: a brief history of Der Klassiker", url: "https://www.fourfourtwo.com/features/bayern-munich-borussia-dortmund-bundesliga-der-klassiker-history-rivalry-derby-head-to-head-statistics-title-wins" }
      ] },
      { a: "Borussia Dortmund", b: "Schalke 04", name: "Revierderby", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Bundesliga", title: "Get set for the return of the Revierderby between Borussia Dortmund and Schalke", url: "https://www.bundesliga.com/en/bundesliga/news/revierderby-return-borussia-dortmund-schalke-2026-27-37946" },
        { publisher: "ESPN", title: "Schalke's Bundesliga return revives Revierderby, arguably the biggest and most genuine rivalry in Germany", url: "https://www.espn.com/soccer/story/_/id/37631994/schalke-bundesliga-return-revives-revierderby-arguably-biggest-most-genuine-rivalry-germany" }
      ] },
      { a: "Werder Bremen", b: "Hamburg", name: "Nordderby", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Bundesliga", title: "Hamburg vs. Werder Bremen: A history of the Nordderby", url: "https://www.bundesliga.com/en/2bundesliga/news/hamburg-vs-werder-bremen-a-history-of-the-nordderby-19024" },
        { publisher: "Deichstube", title: "Werder Bremen gegen HSV: Kurios, spektakulaer, historisch", url: "https://www.deichstube.de/news/werder-bremen-gegen-hsv-legendaerste-nordderby-momente-spiele-geschichte-svw-hamburger-sv-bundesliga-zr-94264632.html" }
      ] },
      { a: "Hertha BSC", b: "Union Berlin", name: "Berlin derby", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Union Berlin", title: "Derby Day in Berlin", url: "https://www.fc-union-berlin.de/en/news/derby-day-in-berlin-VZXKG" },
        { publisher: "Bundesliga", title: "The biggest soccer derbies and rivalries in the Bundesliga: Klassiker, Revierderby and more", url: "https://www.bundesliga.com/en/bundesliga/news/biggest-soccer-derbies-in-germany-klassiker-revierderby-oldest-rivalries-7578" }
      ] },
      { a: "K\xF6ln", b: "Gladbach", name: "Rhine derby", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Bundesliga", title: "The biggest soccer derbies and rivalries in the Bundesliga: Klassiker, Revierderby and more", url: "https://www.bundesliga.com/en/bundesliga/news/biggest-soccer-derbies-in-germany-klassiker-revierderby-oldest-rivalries-7578" },
        { publisher: "Bulinews", title: "FC Koln vs. Borussia Monchengladbach preview: Rhine derby bragging rights up for grabs", url: "https://bulinews.com/koln-borussia-monchengladbach-preview-rhine-derby-bragging-rights-for-grabs" }
      ] },
      { a: "Stuttgart", b: "Karlsruhe", name: "Baden-W\xFCrttemberg derby", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Goal", title: "KSC gegen VfB, Baden gegen Schwaben: Woher kommt die Rivalitaet?", url: "https://www.goal.com/de/meldungen/ksc-gegen-vfb-baden-gegen-schwaben-woher-kommt-die-rivalit%C3%A4t/blt0b058609d87c06f4" },
        { publisher: "Karlsruher SC", title: "Matchfacts: Alles Wissenswerte zum 50. baden-wuerttembergischen Derby", url: "https://www.ksc.de/profis/saison/news/show/article/matchfacts-alles-wissenswerte-zum-50-baden-wuerttembergischen-derby/" }
      ] },
      // France
      { a: "PSG", b: "Marseille", name: "Le Classique", kind: "rivalry", checked: "2026-10-05", sources: [
        { publisher: "beIN Sports", title: "PSG vs Marseille: The History Behind Le Classique", url: "https://www.beinsports.com/en-us/soccer/ligue-1/articles/psg-vs-marseille-the-history-behind-le-classique-2026-09-17" },
        { publisher: "France 24", title: "'Le Classique', French football's fallen icon", url: "https://www.france24.com/en/20190316-classique-french-football-psg-marseille-ligue-1" }
      ] },
      { a: "Monaco", b: "Nice", name: "Cote d'Azur derby", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "AS Monaco", title: "The 100th Cote d'Azur derby is Monegasque!", url: "https://www.asmonaco.com/en/news/the-100th-cote-dazur-derby-is-monegasque" },
        { publisher: "Flashscore", title: "Nice take derby spoils against Monaco as Laborde nets winner in tempestuous affair", url: "https://www.flashscore.com/news/nice-monaco-report-2024-10-27/AFauaJ7F/" }
      ] },
      { a: "Lyon", b: "Marseille", name: "Choc des Olympiques", kind: "rivalry", checked: "2026-10-05", sources: [
        { publisher: "FBref", title: "Choc des Olympiques History Lyon vs. Marseille Historical Head-to-Head", url: "https://fbref.com/en/stathead/matchup/teams/d53c0b06/5725cc7b/Choc-des-Olympiques-Lyon-vs-Marseille-History" },
        { publisher: "My Football Facts", title: "Choc des Olympiques Head-to-Head", url: "https://www.myfootballfacts.com/top-leagues/ligue-1/choc-des-olympiques-head-to-head-lyon-vs-marseille-history-stats/" }
      ] },
      { a: "Lille", b: "Lens", name: "Derby du Nord", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Departement du Nord", title: "Lille-Lens : les grands moments du derby du Nord", url: "https://info.lenord.fr/lille-lens--les-grands-moments-du-derby-du-nord" },
        { publisher: "Foot Sur 7", title: "Derby du Nord Lens-Lille : bilan, records et matchs legendaires", url: "https://www.foot-sur7.fr/784150-derby-du-nord-lens-lille-bilan" }
      ] },
      { a: "Nantes", b: "Rennes", name: "Breton derby", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "ici (France Bleu)", title: "Football en Bretagne : 20 ans de rivalites au plus haut niveau", url: "https://www.ici.fr/sports/football/football-en-bretagne-20-ans-de-rivalite-au-plus-haut-niveau-1659537960" },
        { publisher: "Foot Sur 7", title: "Derby Nantes-Rennes : bilan, records et matchs legendaires", url: "https://www.foot-sur7.fr/784043-derby-nantes-rennes-bilan" }
      ] },
      // Portugal
      { a: "Benfica", b: "Sporting CP", name: "Lisbon derby", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "SL Benfica", title: "Rivalry as old as the derby itself", url: "https://www.slbenfica.pt/en-us/agora/noticias/2018-2019/08/24/futebol-benfica-historico-sporting-liga-nos-3-jornada-estadio-da-luz" },
        { publisher: "Portugoal", title: "Lisbon derby between Eagles and Lions: a century of passion between Benfica and Sporting", url: "https://portugoal.net/classics-topmenu/3772-lisbon-derby-between-eagles-and-lions-a-century-of-passion-between-benfica-and-sporting" }
      ] },
      { a: "Benfica", b: "Porto", name: "O Classico", kind: "rivalry", checked: "2026-10-05", sources: [
        { publisher: "My Football Facts", title: "O Classico Head-to-Head: Benfica vs FC Porto History and Stats", url: "https://www.myfootballfacts.com/top-leagues/liga-portugal/o-classico-head-to-head-benfica-vs-fc-porto-history-stats/" },
        { publisher: "90min", title: "Benfica vs Porto: A Classic Rivalry Between Portugal's Two Most Decorated Clubs", url: "https://www.90min.com/posts/benfica-vs-porto-a-classic-rivalry-between-portugal-s-two-most-decorated-clubs-01e9bbx5ynpb" }
      ] },
      { a: "Porto", b: "Sporting CP", name: "O Classico", kind: "rivalry", checked: "2026-10-05", sources: [
        { publisher: "My Football Facts", title: "O Classico Head-to-Head: FC Porto vs Sporting CP", url: "https://www.myfootballfacts.com/top-leagues/liga-portugal/o-classico-head-to-head-fc-porto-vs-sporting-cp-history-stats/" },
        { publisher: "Football Ground Guide", title: "Porto vs. Sporting rivalry: Origin, history, head-to-head record", url: "https://footballgroundguide.com/news/porto-vs-sporting-rivalry-origin-history-head-to-head-record.html" }
      ] },
      { a: "Braga", b: "Vit\xF3ria Guimar\xE3es", name: "Minho derby", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "A Bola", title: "SC Braga-V. Guimaraes: o derbi minhoto esta de volta!", url: "https://www.abola.pt/futebol/jogo/sc-braga-vitoria-de-guimaraes-11216284/liveblog" },
        { publisher: "Publico", title: "No derby do Minho, Vitoria e Sp. Braga acabaram como comecaram", url: "https://www.publico.pt/2025/02/16/desporto/noticia/derby-minho-vitoria-sp-braga-acabaram-comecaram-2122773" }
      ] },
      // Brazil
      { a: "Corinthians", b: "Palmeiras", name: "Derby Paulista", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Corinthians", title: "Historico do Derby: Corinthians x Palmeiras", url: "https://www.corinthians.com.br/noticias/historico-do-derby-corinthians-x-palmeiras" },
        { publisher: "Gazeta Esportiva", title: "Relembre 12 grandes partidas da historia do Derby Paulista", url: "https://www.gazetaesportiva.com/fotos/100-anos-de-derbys-veja-os-10-maiores-da-historia/" }
      ] },
      { a: "Corinthians", b: "S\xE3o Paulo", name: "Majestoso", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Lance!", title: "Ha 90 anos, Corinthians e Sao Paulo jogavam o primeiro Majestoso", url: "https://www.lance.com.br/futebol-nacional/anos-corinthians-sao-paulo-jogavam-primeiro-majestoso.html" },
        { publisher: "Jovem Pan", title: "Sao Paulo x Corinthians: os tabus que marcaram a historia do Majestoso", url: "https://jovempan.com.br/esportes/futebol/sao-paulo-x-corinthians-os-tabus-que-marcaram-a-historia-do-majestoso/" }
      ] },
      { a: "Palmeiras", b: "S\xE3o Paulo", name: "Choque-Rei", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Sao Paulo FC", title: "Choque-Rei: 300 jogos de historia", url: "https://www.saopaulofc.net/choque-rei-300-jogos-de-historia/" },
        { publisher: "Lance!", title: "Choque-Rei: de onde vem o apelido de Palmeiras x Sao Paulo", url: "https://www.lance.com.br/futebol-nacional/choque-rei-de-onde-vem-o-apelido-de-palmeiras-sao-paulo.html" }
      ] },
      { a: "Santos", b: "S\xE3o Paulo", name: "San-Sao", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Santos FC", title: "Neste seculo o San domina o Sao", url: "https://www.santosfc.com.br/neste-seculo-o-san-domina-o-sao/" },
        { publisher: "Lance!", title: "Sao Paulo x Santos: quem venceu mais o San-Sao?", url: "https://www.lance.com.br/lancepedia/sao-paulo-santos-quem-venceu-mais-classicos.html" }
      ] },
      { a: "Santos", b: "Corinthians", name: "Classico Alvinegro", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Goal", title: "Corinthians x Santos: Quem venceu mais vezes o Classico Alvinegro?", url: "https://www.goal.com/br/listas/corinthians-x-santos-quem-venceu-mais-vezes-classico-alvinegro/blt3cae65fc39880b5c" },
        { publisher: "Terra", title: "Corinthians x Santos: confira o retrospecto do classico alvinegro", url: "https://www.terra.com.br/esportes/corinthians/corinthians-x-santos-confira-o-retrospecto-do-classico-alvinegro,b9a5ffe3060665179b8c64d6feba7de8fu2dsuny.html" }
      ] },
      { a: "Santos", b: "Palmeiras", name: "Classico da Saudade", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Palmeiras", title: "Trofeu Classico da Saudade", url: "https://www.palmeiras.com.br/lightbox_galeria/trofeu-classico-da-saudade-2024/" },
        { publisher: "Lance!", title: "Palmeiras x Santos: quem venceu mais o Classico da Saudade?", url: "https://www.lance.com.br/lancepedia/palmeiras-santos-quem-venceu-mais-classicos.html" }
      ] },
      { a: "Flamengo", b: "Botafogo", name: "Classico da Rivalidade", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Lance!", title: "Classico da Rivalidade: apelido do jogo entre Botafogo x Flamengo", url: "https://www.lance.com.br/futebol-nacional/classico-da-rivalidade-de-onde-vem-o-apelido-de-botafogo-flamengo.html" },
        { publisher: "Band", title: "Botafogo x Flamengo: origem e curiosidades do Classico da Rivalidade", url: "https://www.band.com.br/esportes/botafogo-x-flamengo-origem-e-curiosidades-do-classico-da-rivalidade-202510141804" }
      ] },
      { a: "Flamengo", b: "Fluminense", name: "Fla-Flu", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Fluminense", title: "Tricolor sai vencedor do primeiro Fla-Flu, em 1912", url: "https://www.fluminense.com.br/noticia/tricolor-sai-vencedor-do-primeiro-fla-flu-em-1912" },
        { publisher: "Goal", title: "Flamengo x Fluminense: quem venceu mais, artilharia e curiosidades do Fla-Flu", url: "https://www.goal.com/br/not%C3%ADcias/as-curiosidades-do-fla-flu-quem-mais-venceu-maior-goleada-artilheiros/pd32feyxtmut1x4m6eu7bnpkb" }
      ] },
      { a: "Flamengo", b: "Vasco da Gama", name: "Classico dos Milhoes", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Flamengo", title: "BuzzFla: Lembrancas do Classico dos Milhoes", url: "https://www.flamengo.com.br/noticias/futebol/buzzfla--lembrancas-do-classico-dos-milhoes" },
        { publisher: "Lance!", title: "Flamengo x Vasco: quem venceu mais o Classico dos Milhoes?", url: "https://www.lance.com.br/lancepedia/flamengo-vasco-uem-venceu-mais-classicos.html" }
      ] },
      { a: "Botafogo", b: "Fluminense", name: "Classico Vovo", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Fluminense", title: "115 anos da goleada historica do Flu no Classico Vovo", url: "https://www.fluminense.com.br/noticia/115-anos-da-goleada-historica-do-flu-no-classico-vovo" },
        { publisher: "Lance!", title: "Botafogo x Fluminense: quem venceu mais o Classico Vovo?", url: "https://www.lance.com.br/lancepedia/botafogo-fluminense-quem-venceu-mais-classicos.html" }
      ] },
      { a: "Fluminense", b: "Vasco da Gama", name: "Classico dos Gigantes", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Lance!", title: "Classico dos Gigantes: o apelido do jogo de Fluminense x Vasco", url: "https://www.lance.com.br/lancepedia/classico-dos-milhoes-de-onde-vem-o-apelido-de-fluminense-vasco.html" },
        { publisher: "Terra", title: "Classico de Gigantes: Fluminense e Vasco, grandes rivais!", url: "https://www.terra.com.br/amp/story/esportes/classico-de-gigantes-fluminense-e-vasco-grandes-rivais,00f9b51fb4dadd78e08567c818e72ddfabnwigq1.html" }
      ] },
      { a: "Gr\xEAmio", b: "Internacional", name: "Gre-Nal", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Internacional", title: "Lista de todos os GreNais da historia", url: "https://internacional.com.br/clube/grenais" },
        { publisher: "Sportbuzz", title: "Gremio e Internacional: conheca algumas curiosidades do Gre-nal", url: "https://sportbuzz.com.br/futebol/2021/08/24/gremio-e-internacional-conheca-algumas-curiosidades-do-gre-nal/" }
      ] },
      { a: "Cruzeiro", b: "Atl\xE9tico Mineiro", name: "Classico Mineiro", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Olympics.com", title: "Cruzeiro x Atletico-MG: relembre o historico dos rivais em classicos no seculo", url: "https://www.olympics.com/pt/noticias/cruzeiro-atletico-mg-relembre-o-historico-dos-rivais-em-classicos-no-seculo" },
        { publisher: "VAVEL Brasil", title: "Cruzeiro x Atletico: relembre momentos do classico mineiro", url: "https://www.vavel.com/br/futebol/2026/08/25/serie-a/1269060-cruzeiro-x-atletico-relembre-momentos-do-classico-mineiro.html" }
      ] },
      // Mexico: the five clasicos Round 883 two-sourced for Club Manager, re-read.
      { a: "Am\xE9rica", b: "Guadalajara", name: "Clasico Nacional", kind: "rivalry", checked: "2026-10-05", sources: [
        { publisher: "Mediotiempo", title: "Que antiguedad tiene cada clasico del futbol mexicano?", url: "https://www.mediotiempo.com/futbol/liga-mx/que-antiguedad-tiene-cada-clasico-del-futbol-mexicano" },
        { publisher: "Goal", title: "En Mexico, cuantos clasicos de futbol existen?", url: "https://www.goal.com/es-mx/noticias/cuantos-clasicos-hay-mexico/ivx26cjdwgz41e0g2mkym9sgy" }
      ] },
      { a: "Am\xE9rica", b: "Cruz Azul", name: "Clasico Joven", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Mediotiempo", title: "Que antiguedad tiene cada clasico del futbol mexicano?", url: "https://www.mediotiempo.com/futbol/liga-mx/que-antiguedad-tiene-cada-clasico-del-futbol-mexicano" },
        { publisher: "Goal", title: "En Mexico, cuantos clasicos de futbol existen?", url: "https://www.goal.com/es-mx/noticias/cuantos-clasicos-hay-mexico/ivx26cjdwgz41e0g2mkym9sgy" }
      ] },
      { a: "Am\xE9rica", b: "Pumas UNAM", name: "Clasico Capitalino", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Mediotiempo", title: "Que antiguedad tiene cada clasico del futbol mexicano?", url: "https://www.mediotiempo.com/futbol/liga-mx/que-antiguedad-tiene-cada-clasico-del-futbol-mexicano" },
        { publisher: "Goal", title: "En Mexico, cuantos clasicos de futbol existen?", url: "https://www.goal.com/es-mx/noticias/cuantos-clasicos-hay-mexico/ivx26cjdwgz41e0g2mkym9sgy" }
      ] },
      { a: "Monterrey", b: "Tigres UANL", name: "Clasico Regio", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Mediotiempo", title: "Que antiguedad tiene cada clasico del futbol mexicano?", url: "https://www.mediotiempo.com/futbol/liga-mx/que-antiguedad-tiene-cada-clasico-del-futbol-mexicano" },
        { publisher: "Goal", title: "En Mexico, cuantos clasicos de futbol existen?", url: "https://www.goal.com/es-mx/noticias/cuantos-clasicos-hay-mexico/ivx26cjdwgz41e0g2mkym9sgy" }
      ] },
      { a: "Guadalajara", b: "Atlas", name: "Clasico Tapatio", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "Mediotiempo", title: "Que antiguedad tiene cada clasico del futbol mexicano?", url: "https://www.mediotiempo.com/futbol/liga-mx/que-antiguedad-tiene-cada-clasico-del-futbol-mexicano" },
        { publisher: "Goal", title: "En Mexico, cuantos clasicos de futbol existen?", url: "https://www.goal.com/es-mx/noticias/cuantos-clasicos-hay-mexico/ivx26cjdwgz41e0g2mkym9sgy" }
      ] },
      // Argentina: stored, never played until a league cadence is verified.
      { a: "Boca Juniors", b: "River Plate", name: "Superclasico", kind: "derby", checked: "2026-10-05", sources: [
        { publisher: "ESPN", title: "River Plate vs. Boca Juniors, a rivalry rooted in Argentine culture and history", url: "https://www.espn.com/soccer/story/_/id/37412978/river-plate-vs-boca-juniors-rivalry-rooted-argentine-culture-history" },
        { publisher: "World Soccer", title: "Football's Greatest Rivalries: River Plate v Boca Juniors", url: "https://www.worldsoccer.com/world-soccer-latest/footballs-greatest-rivalries-river-plate-v-boca-juniors-366649" }
      ] }
    ];
  }
});

// src/lib/managerOffers.ts
var init_managerOffers = __esm({
  "src/lib/managerOffers.ts"() {
  }
});

// src/lib/soccerCareerEngine.ts
init_captaincy();

// src/lib/uclFormatHistory.ts
var UCL_FORMAT_PERIODS = [
  {
    id: "european-cup",
    from: 1955,
    to: 1990,
    name: "European Cup",
    title: "Straight knockout, home and away",
    stage: "knockout",
    groups: 0,
    secondGroupStage: false,
    roundOf16: false,
    koLegs: 2,
    entrants: "Sixteen invited clubs in the first season, then the champions of each national league.",
    path: "Every round before the final was a two legged tie decided on aggregate, and the final was one match at a venue fixed in advance.",
    notes: [
      "The first edition, 1955-56, was won by Real Madrid, 4-3 against Reims at the Parc des Princes in Paris.",
      "Three times in this era the final landed on a finalist's own ground: Real Madrid won at the Bernabeu in 1957, Inter won at San Siro in 1965, and Roma lost to Liverpool on penalties at the Stadio Olimpico in 1984.",
      "The 1974 final is the only one ever replayed: Bayern Munich and Atletico Madrid drew 1-1 after extra time in Brussels, and Bayern won the replay 4-0 two days later at the same ground."
    ],
    sources: ["wp5556", "rs5556", "wp1957", "rs5657", "wplist", "rs6465", "rs8384", "wp1974", "rs7374", "wpucl", "smglossary", "wp9192"]
  },
  {
    id: "first-groups",
    from: 1991,
    to: 1991,
    name: "European Cup",
    title: "The first group stage",
    stage: "groups",
    groups: 2,
    secondGroupStage: false,
    roundOf16: false,
    koLegs: null,
    entrants: "Thirty two clubs entered the first round; eight survived two knockout rounds.",
    path: "The eight survivors were split into two groups of four, played home and away, and the two group winners met in the final with no semi-finals.",
    notes: [
      "Barcelona beat Sampdoria 1-0 after extra time at Wembley, the first final reached through a group."
    ],
    sources: ["wp9192", "rs9192"]
  },
  {
    id: "renamed",
    from: 1992,
    to: 1992,
    name: "Champions League",
    title: "Renamed, same shape",
    stage: "groups",
    groups: 2,
    secondGroupStage: false,
    roundOf16: false,
    koLegs: null,
    entrants: "Eight clubs in two groups of four after the knockout rounds.",
    path: "The two group winners went straight to the final again.",
    notes: [
      "The Champions League name arrived this season, at first only for the group stage. Marseille beat Milan 1-0 in Munich."
    ],
    sources: ["wp9293", "rs9293", "smglossary"]
  },
  {
    id: "one-leg-semis",
    from: 1993,
    to: 1993,
    name: "Champions League",
    title: "Semi-finals return, as single matches",
    stage: "groups",
    groups: 2,
    secondGroupStage: false,
    roundOf16: false,
    koLegs: 1,
    entrants: "Eight clubs in two groups of four after the knockout rounds.",
    path: "The top two of each group went to one off semi-finals, each hosted by a group winner, and the winners met in the final.",
    notes: [
      "Milan beat Barcelona 4-0 in Athens."
    ],
    sources: ["wp9394", "rs9394"]
  },
  {
    id: "four-groups",
    from: 1994,
    to: 1996,
    name: "Champions League",
    title: "Sixteen clubs, four groups, quarter-finals",
    stage: "groups",
    groups: 4,
    secondGroupStage: false,
    roundOf16: false,
    koLegs: 2,
    entrants: "Sixteen clubs in the group stage.",
    path: "Four groups of four, the top two of each into two legged quarter-finals and semi-finals, then a one match final.",
    notes: [
      "Ajax beat Milan 1-0 in Vienna in the first season of this shape, 1994-95, and the shape held for three seasons."
    ],
    sources: ["wp9495", "rs9495", "wp9596", "rs9596", "wp9697", "rs9697", "wp9798"]
  },
  {
    id: "six-groups",
    from: 1997,
    to: 1998,
    name: "Champions League",
    title: "Twenty four clubs, six groups, runners-up let in",
    stage: "groups",
    groups: 6,
    secondGroupStage: false,
    roundOf16: false,
    koLegs: 2,
    entrants: "Twenty four clubs in the group stage, including the runners-up of eight domestic leagues for the first time.",
    path: "Six groups of four; the six winners and the two best runners-up went to the quarter-finals.",
    notes: [
      "This is where the champions only competition ended, and the name stopped being literally true.",
      "Real Madrid beat Juventus 1-0 in Amsterdam in 1998, and Manchester United came from a goal down in stoppage time to beat Bayern Munich 2-1 in Barcelona in 1999."
    ],
    sources: ["wp9798", "rs9798", "wp9899", "rs9899"]
  },
  {
    id: "two-group-stages",
    from: 1999,
    to: 2002,
    name: "Champions League",
    title: "Thirty two clubs and a second group stage",
    stage: "groups",
    groups: 8,
    secondGroupStage: true,
    roundOf16: false,
    koLegs: 2,
    entrants: "Thirty two clubs in the first group stage, with up to four from the strongest leagues.",
    path: "Eight groups of four, the top two into a second group stage of four groups of four, and the top two of those into the quarter-finals.",
    notes: [
      "Third placed clubs from the first stage dropped into the UEFA Cup.",
      "Real Madrid beat Valencia 3-0 in Paris in the first season of this format, and the double group stage ran for four seasons."
    ],
    sources: ["wp9900", "rs9900", "rs0001", "rs0102", "rs0203", "wp0304"]
  },
  {
    id: "eight-groups-r16",
    from: 2003,
    to: 2023,
    name: "Champions League",
    title: "Thirty two clubs, eight groups, a round of 16",
    stage: "groups",
    groups: 8,
    secondGroupStage: false,
    roundOf16: true,
    koLegs: 2,
    knockoutException: "The 2019-20 quarter-finals and semi-finals were single matches.",
    entrants: "Thirty two clubs in the group stage.",
    path: "Eight groups of four, the top two into a round of 16, then two legged quarter-finals and semi-finals and a one match final.",
    notes: [
      "Porto beat Monaco 3-0 in Gelsenkirchen in the first season of this shape, and it lasted 21 seasons.",
      "The 2019-20 season finished as a one city tournament in Lisbon: single match quarter-finals and semi-finals behind closed doors, and Bayern Munich beat Paris Saint-Germain 1-0 in the final.",
      "Away goals stopped counting double from 2021-22, so a tie level after two legs now goes to extra time and then penalties."
    ],
    sources: ["wp0304", "rs0304", "uefanew", "wpucl", "wp1920", "rs1920", "uefa2020", "uefaaway", "wpaway"]
  },
  {
    id: "league-phase",
    from: 2024,
    to: null,
    name: "Champions League",
    title: "Thirty six clubs in one league table",
    stage: "leaguePhase",
    groups: 0,
    secondGroupStage: false,
    roundOf16: true,
    koLegs: 2,
    entrants: "Thirty six clubs.",
    path: "One table: each club plays eight different opponents, four at home and four away. The top eight go straight to the round of 16, ninth to 24th play a two legged knockout play-off for the other eight places, and 25th and below are out, with no drop into the Europa League.",
    notes: [
      "UEFA calls it the league phase. From the play-offs to the semi-finals the ties are two legged, and the final is still one match at a venue picked well in advance."
    ],
    sources: ["uefanew", "wpucl", "smglossary"]
  }
];
var UCL_AWAY_GOALS = {
  /** The year UEFA introduced it, in the Cup Winners' Cup. */
  introduced: 1965,
  /** Starting year of the last season it applied. Typed here and exported
   *  from the engine as UCL_AWAY_GOALS_LAST_YEAR; the harness holds them equal. */
  lastSeason: 2020,
  text: "UEFA first used the away goals rule in 1965, in the Cup Winners' Cup, and for most of this competition's life a tie level on aggregate went to whichever side had scored more away from home. It was abolished in every UEFA club competition from 2021-22. A tie level after two legs now goes to extra time and then penalties, and a goal scored away in extra time counts the same as one at home.",
  sources: ["uefaaway", "wpaway"]
};
function periodFor(year) {
  return UCL_FORMAT_PERIODS.find((p) => year >= p.from && (p.to === null || year <= p.to)) ?? UCL_FORMAT_PERIODS[0];
}

// src/lib/soccerCareerEngine.ts
init_uclTieRule();

// src/lib/soccerCareerContinental.ts
init_soccerInternational();

// src/lib/careerIdentity.ts
var PERSONALITY_BOUND = { min: 0.75, max: 1.75 };
var bound = (v) => Math.max(PERSONALITY_BOUND.min, Math.min(PERSONALITY_BOUND.max, v));
function personalityOf(id, sport) {
  return sport.personalities.find((p) => p.id === id);
}
function agentOf(id, sport) {
  return sport.agents.find((a) => a.id === id);
}
function personalityMult(id, kind, sport) {
  const p = personalityOf(id, sport);
  if (!p) return 1;
  return bound(kind === "followers" ? p.followerMult : p.sponsorMult);
}
function agentWage(id, sport) {
  return agentOf(id, sport)?.wageMult ?? 1;
}
function agentIncomeCut(id, sport) {
  return agentOf(id, sport)?.incomeCut ?? 0;
}
function agentTransferCut(id, sport) {
  if (!id) return sport.noAgentTransferCut;
  return agentOf(id, sport)?.transferCut ?? sport.noAgentTransferCut;
}

// src/lib/soccerCareerLife.ts
var PERSONALITIES = [
  {
    id: "showman",
    name: "The Showman",
    emoji: "\u{1F3AD}",
    blurb: "Cameras find you. You find them first.",
    perk: "Followers grow 60% faster, sponsors pay 25% more, scandals hit harder",
    followerMult: 1.6,
    sponsorMult: 1.25
  },
  {
    id: "iceman",
    name: "Ice Cold",
    emoji: "\u{1F9CA}",
    blurb: "No celebration. No panic. No comment.",
    perk: "Sponsors trust you, drama slides off, slower follower growth",
    followerMult: 0.9,
    sponsorMult: 1.05
  },
  {
    id: "hothead",
    name: "The Hothead",
    emoji: "\u{1F30B}",
    blurb: "Plays angry. Lives angrier.",
    perk: "Exclusive chaos events and fear-factor edges, riskier sponsor money",
    followerMult: 1.15,
    sponsorMult: 0.9
  },
  {
    id: "professor",
    name: "The Professor",
    emoji: "\u{1F4D0}",
    blurb: "Watches film on the team bus. For fun.",
    perk: "Respected by managers and brands, fewer viral moments",
    followerMult: 0.85,
    sponsorMult: 1.1
  },
  {
    id: "enigma",
    name: "The Enigma",
    emoji: "\u{1F0CF}",
    blurb: "Nobody, including you, knows what happens next.",
    perk: "Wildcard bonuses, cult following, chaos both ways",
    followerMult: 1.25,
    sponsorMult: 1
  }
];
function personalityFollowerMult(id) {
  return personalityMult(id, "followers", SOCCER_IDENTITY);
}
function personalitySponsorMult(id) {
  return personalityMult(id, "sponsors", SOCCER_IDENTITY);
}
var AGENTS = [
  {
    id: "cousin",
    name: "Cousin Ricky",
    emoji: "\u{1F9E2}",
    blurb: "Family discount. Family-grade paperwork.",
    wageMult: 0.95,
    incomeCut: 0,
    transferCut: 0.03
  },
  {
    id: "shark",
    name: "Marco De Luca",
    emoji: "\u{1F988}",
    blurb: "Mid-table clubs fear his ringtone.",
    wageMult: 1.1,
    incomeCut: 0.05,
    transferCut: 0.08
  },
  {
    id: "super",
    name: "Zara Blackwood",
    emoji: "\u{1F451}",
    blurb: "Has three club presidents on speed dial. Uses all three.",
    wageMult: 1.25,
    incomeCut: 0.1,
    transferCut: 0.12
  },
  {
    id: "self",
    name: "No Agent",
    emoji: "\u{1F91D}",
    blurb: "You negotiate for yourself.",
    wageMult: 1,
    incomeCut: 0,
    transferCut: 0
  }
];
var SOCCER_IDENTITY = {
  personalities: PERSONALITIES,
  agents: AGENTS,
  noAgentTransferCut: 0.1,
  beats: { personalityAge: 18, agentAge: 19 }
};
function agentWageMult(id) {
  return agentWage(id, SOCCER_IDENTITY);
}
function agentIncomeCutRate(id) {
  return agentIncomeCut(id, SOCCER_IDENTITY);
}
function agentTransferCutRate(id) {
  return agentTransferCut(id, SOCCER_IDENTITY);
}

// src/lib/careerEras.ts
var rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
var pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
var S = (name, nationality, position, club, g0, g1, power) => ({ name, nationality, position, club, baseGoals: [g0, g1], power });
var ERA_DEFS = [
  {
    from: 1990,
    to: 1994,
    stars: [
      S("Marco van Basten", "Netherlands", "ST", "AC Milan", 19, 32, 10),
      S("Ruud Gullit", "Netherlands", "CAM", "AC Milan", 10, 20, 8),
      S("Frank Rijkaard", "Netherlands", "CDM", "AC Milan", 4, 10, 7),
      S("Lothar Matth\xE4us", "Germany", "CM", "Bayern Munich", 8, 16, 9),
      S("Roberto Baggio", "Italy", "CAM", "Juventus", 15, 25, 10),
      S("Hristo Stoichkov", "Bulgaria", "ST", "Barcelona", 16, 28, 9),
      S("Rom\xE1rio", "Brazil", "ST", "PSV", 22, 34, 9),
      S("Gabriel Batistuta", "Argentina", "ST", "Fiorentina", 18, 28, 7),
      S("J\xFCrgen Klinsmann", "Germany", "ST", "Monaco", 15, 25, 7),
      S("Dennis Bergkamp", "Netherlands", "ST", "Ajax", 12, 22, 7),
      S("George Weah", "Liberia", "ST", "PSG", 14, 24, 8),
      S("Paolo Maldini", "Italy", "CB", "AC Milan", 1, 4, 8),
      S("Franco Baresi", "Italy", "CB", "AC Milan", 0, 3, 7),
      S("Eric Cantona", "France", "ST", "Man United", 14, 22, 8),
      S("Ryan Giggs", "Wales", "LW", "Man United", 8, 15, 6),
      S("Gheorghe Hagi", "Romania", "CAM", "Brescia", 8, 15, 7),
      S("Peter Schmeichel", "Denmark", "GK", "Man United", 0, 0, 7),
      S("Alan Shearer", "England", "ST", "Blackburn Rovers", 22, 34, 7),
      S("Matthias Sammer", "Germany", "CB", "Dortmund", 4, 8, 7),
      S("Ra\xED", "Brazil", "CAM", "Sao Paulo", 8, 16, 5)
    ],
    topClubs: ["AC Milan", "Barcelona", "Juventus", "Man United", "Real Madrid", "Inter Milan", "Ajax", "Marseille", "Bayern Munich", "Benfica"],
    uclExtras: ["Porto", "PSG", "Parma", "Sampdoria", "Red Star Belgrade", "Steaua Bucharest"],
    leagues: {
      "Premier League": ["Man United", "Arsenal", "Blackburn Rovers", "Newcastle", "Leeds United", "Liverpool"],
      "La Liga": ["Barcelona", "Real Madrid", "Atletico Madrid", "Deportivo", "Valencia"],
      "Bundesliga": ["Bayern Munich", "Dortmund", "Werder Bremen", "Kaiserslautern", "Stuttgart"],
      "Serie A": ["AC Milan", "Juventus", "Inter Milan", "Napoli", "Sampdoria", "Lazio"],
      "Ligue 1": ["Marseille", "PSG", "Monaco", "Nantes", "Bordeaux"],
      /* Round 302: the leagues the owner named join the title race feed, each
         window listing the clubs that actually contested that half decade
         (champions first, verified against season records). MLS is absent
         before 1995 because the league first kicked off in 1996, and K League
         joins from 2010 when its club identities settled into the names the
         game uses; simCareerEras pins both exemptions. */
      "Primeira Liga": ["Porto", "Benfica", "Sporting CP"],
      "Eredivisie": ["Ajax", "PSV", "Feyenoord"],
      "Scottish Premiership": ["Rangers", "Celtic", "Aberdeen"],
      "Brasileirao": ["Sao Paulo", "Palmeiras", "Flamengo", "Corinthians"],
      "Saudi Pro League": ["Al Shabab", "Al Nassr", "Al Hilal"]
    },
    rivalFirsts: ["Stefan", "Dario", "Gianluca", "Patrik", "Emile", "Dejan", "Tomas", "Brian", "Oliver", "Marcelo", "Iv\xE1n", "Predrag", "Davor", "Nwankwo", "Marcel", "Youri", "Ariel", "Christophe", "Darko", "Kenneth"]
  },
  {
    from: 1995,
    to: 1999,
    stars: [
      S("Ronaldo", "Brazil", "ST", "Inter Milan", 25, 40, 10),
      S("Zinedine Zidane", "France", "CAM", "Juventus", 8, 16, 10),
      S("George Weah", "Liberia", "ST", "AC Milan", 16, 26, 9),
      S("Matthias Sammer", "Germany", "CB", "Dortmund", 4, 9, 8),
      S("Alessandro Del Piero", "Italy", "ST", "Juventus", 15, 25, 8),
      S("Rivaldo", "Brazil", "LW", "Barcelona", 18, 28, 9),
      S("Davor \u0160uker", "Croatia", "ST", "Real Madrid", 16, 26, 7),
      S("Michael Owen", "England", "ST", "Liverpool", 15, 24, 8),
      S("David Beckham", "England", "RW", "Man United", 6, 12, 8),
      S("Lu\xEDs Figo", "Portugal", "RW", "Barcelona", 8, 14, 8),
      S("Dennis Bergkamp", "Netherlands", "CAM", "Arsenal", 12, 20, 8),
      S("Gabriel Batistuta", "Argentina", "ST", "Fiorentina", 18, 28, 7),
      S("Roberto Carlos", "Brazil", "LB", "Real Madrid", 4, 8, 7),
      S("Ra\xFAl", "Spain", "ST", "Real Madrid", 16, 25, 7),
      S("Andriy Shevchenko", "Ukraine", "ST", "Dynamo Kyiv", 18, 28, 7),
      S("Eric Cantona", "France", "ST", "Man United", 12, 18, 6),
      S("Paolo Maldini", "Italy", "CB", "AC Milan", 1, 3, 7),
      S("Oliver Kahn", "Germany", "GK", "Bayern Munich", 0, 0, 7),
      S("Christian Vieri", "Italy", "ST", "Inter Milan", 16, 26, 6),
      S("Jaap Stam", "Netherlands", "CB", "PSV", 1, 3, 6)
    ],
    topClubs: ["Juventus", "AC Milan", "Real Madrid", "Man United", "Bayern Munich", "Barcelona", "Dortmund", "Ajax", "Inter Milan", "Arsenal"],
    uclExtras: ["Parma", "Lazio", "PSG", "Porto", "Newcastle", "Valencia"],
    leagues: {
      "Premier League": ["Man United", "Arsenal", "Newcastle", "Liverpool", "Chelsea", "Leeds United"],
      "La Liga": ["Real Madrid", "Barcelona", "Atletico Madrid", "Valencia", "Deportivo"],
      "Bundesliga": ["Bayern Munich", "Dortmund", "Kaiserslautern", "Leverkusen"],
      "Serie A": ["Juventus", "AC Milan", "Inter Milan", "Lazio", "Parma", "Fiorentina"],
      "Ligue 1": ["PSG", "Monaco", "Marseille", "Lyon", "Bordeaux"],
      "Primeira Liga": ["Porto", "Benfica", "Sporting CP"],
      "Eredivisie": ["Ajax", "PSV", "Feyenoord"],
      "Scottish Premiership": ["Rangers", "Celtic", "Hearts"],
      "Brasileirao": ["Corinthians", "Vasco da Gama", "Gremio", "Botafogo"],
      "Saudi Pro League": ["Al Hilal", "Al Ittihad", "Al Nassr"],
      "MLS": ["DC United", "Chicago Fire", "LA Galaxy"]
    },
    rivalFirsts: ["Stefan", "Dario", "Gianluca", "Patrik", "Emile", "Dejan", "Tomas", "Brian", "Oliver", "Marcelo", "Iv\xE1n", "Predrag", "Davor", "Nwankwo", "Marcel", "Youri", "Ariel", "Christophe", "Darko", "Kenneth"]
  },
  {
    from: 2e3,
    to: 2004,
    stars: [
      S("Zinedine Zidane", "France", "CAM", "Real Madrid", 8, 15, 10),
      S("Lu\xEDs Figo", "Portugal", "RW", "Real Madrid", 8, 14, 9),
      S("Michael Owen", "England", "ST", "Liverpool", 16, 26, 8),
      S("Ronaldo", "Brazil", "ST", "Real Madrid", 20, 30, 9),
      S("Pavel Nedv\u011Bd", "Czech Republic", "CAM", "Juventus", 10, 18, 8),
      S("Andriy Shevchenko", "Ukraine", "ST", "AC Milan", 20, 30, 9),
      S("Ronaldinho", "Brazil", "CAM", "Barcelona", 15, 25, 9),
      S("Thierry Henry", "France", "ST", "Arsenal", 24, 34, 9),
      S("Oliver Kahn", "Germany", "GK", "Bayern Munich", 0, 0, 8),
      S("Ra\xFAl", "Spain", "ST", "Real Madrid", 16, 26, 8),
      S("Rivaldo", "Brazil", "CAM", "Barcelona", 14, 24, 7),
      S("David Beckham", "England", "RW", "Man United", 5, 10, 7),
      S("Roberto Carlos", "Brazil", "LB", "Real Madrid", 4, 8, 7),
      S("Ruud van Nistelrooy", "Netherlands", "ST", "Man United", 22, 32, 8),
      S("Francesco Totti", "Italy", "CAM", "Roma", 14, 22, 7),
      S("Paolo Maldini", "Italy", "CB", "AC Milan", 1, 3, 6),
      S("Deco", "Portugal", "CM", "Porto", 8, 14, 7),
      S("Steven Gerrard", "England", "CM", "Liverpool", 8, 14, 7),
      S("Frank Lampard", "England", "CM", "Chelsea", 10, 18, 7),
      S("Samuel Eto'o", "Cameroon", "ST", "Mallorca", 16, 26, 6),
      S("Alessandro Nesta", "Italy", "CB", "AC Milan", 0, 3, 6)
    ],
    topClubs: ["Real Madrid", "Bayern Munich", "AC Milan", "Porto", "Barcelona", "Man United", "Juventus", "Arsenal", "Liverpool", "Inter Milan"],
    uclExtras: ["Valencia", "Deportivo", "Leeds United", "Lazio", "PSV", "Monaco"],
    leagues: {
      "Premier League": ["Man United", "Arsenal", "Chelsea", "Liverpool", "Newcastle", "Leeds United"],
      "La Liga": ["Real Madrid", "Barcelona", "Valencia", "Deportivo", "Atletico Madrid"],
      "Bundesliga": ["Bayern Munich", "Dortmund", "Leverkusen", "Werder Bremen", "Stuttgart"],
      "Serie A": ["Juventus", "AC Milan", "Inter Milan", "Roma", "Lazio"],
      "Ligue 1": ["Lyon", "Monaco", "PSG", "Marseille", "Bordeaux"],
      "Primeira Liga": ["Porto", "Sporting CP", "Boavista", "Benfica"],
      "Eredivisie": ["PSV", "Ajax", "Feyenoord"],
      "Scottish Premiership": ["Celtic", "Rangers", "Hearts"],
      "Brasileirao": ["Santos", "Cruzeiro", "Vasco da Gama", "Sao Paulo"],
      "Saudi Pro League": ["Al Ittihad", "Al Hilal", "Al Shabab"],
      "MLS": ["LA Galaxy", "San Jose Earthquakes", "DC United"]
    },
    rivalFirsts: ["Fernando", "Diego", "Andr\xE9s", "Wesley", "Robin", "Arjen", "Franck", "Ricardo", "Milan", "Dimitar", "Emmanuel", "Obafemi", "Landon", "Gonzalo", "Sergio", "Karim", "Cesc", "Theo", "Mikel", "Klaas"]
  },
  {
    from: 2005,
    to: 2009,
    stars: [
      S("Ronaldinho", "Brazil", "CAM", "Barcelona", 18, 26, 10),
      S("Fabio Cannavaro", "Italy", "CB", "Real Madrid", 0, 3, 8),
      S("Kak\xE1", "Brazil", "CAM", "AC Milan", 15, 25, 9),
      S("Cristiano Ronaldo", "Portugal", "RW", "Man United", 24, 42, 10),
      S("Lionel Messi", "Argentina", "RW", "Barcelona", 23, 38, 10),
      S("Thierry Henry", "France", "ST", "Barcelona", 18, 28, 8),
      S("Samuel Eto'o", "Cameroon", "ST", "Barcelona", 20, 30, 8),
      S("Fernando Torres", "Spain", "ST", "Liverpool", 18, 28, 8),
      S("Steven Gerrard", "England", "CM", "Liverpool", 10, 18, 8),
      S("Frank Lampard", "England", "CM", "Chelsea", 12, 20, 8),
      S("Xavi", "Spain", "CM", "Barcelona", 4, 10, 8),
      S("Andr\xE9s Iniesta", "Spain", "CM", "Barcelona", 4, 9, 8),
      S("Wayne Rooney", "England", "ST", "Man United", 14, 26, 8),
      S("Zlatan Ibrahimovi\u0107", "Sweden", "ST", "Inter Milan", 16, 26, 8),
      S("Gianluigi Buffon", "Italy", "GK", "Juventus", 0, 0, 8),
      S("Didier Drogba", "Ivory Coast", "ST", "Chelsea", 15, 28, 8),
      S("Franck Rib\xE9ry", "France", "LW", "Bayern Munich", 10, 18, 7),
      S("David Villa", "Spain", "ST", "Valencia", 18, 28, 7),
      S("Andrea Pirlo", "Italy", "CM", "AC Milan", 4, 9, 7),
      S("John Terry", "England", "CB", "Chelsea", 1, 4, 6)
    ],
    topClubs: ["Barcelona", "AC Milan", "Liverpool", "Man United", "Chelsea", "Real Madrid", "Inter Milan", "Bayern Munich", "Arsenal", "Juventus"],
    uclExtras: ["Lyon", "Porto", "Sevilla", "Valencia", "Roma", "PSV"],
    leagues: {
      "Premier League": ["Man United", "Chelsea", "Arsenal", "Liverpool", "Tottenham", "Everton"],
      "La Liga": ["Barcelona", "Real Madrid", "Valencia", "Sevilla", "Villarreal"],
      "Bundesliga": ["Bayern Munich", "Werder Bremen", "Stuttgart", "Wolfsburg", "Dortmund"],
      "Serie A": ["Inter Milan", "AC Milan", "Juventus", "Roma", "Fiorentina"],
      "Ligue 1": ["Lyon", "Marseille", "Bordeaux", "PSG", "Monaco"],
      "Primeira Liga": ["Porto", "Benfica", "Sporting CP"],
      "Eredivisie": ["PSV", "Ajax", "AZ Alkmaar", "Feyenoord"],
      "Scottish Premiership": ["Celtic", "Rangers", "Aberdeen"],
      "Brasileirao": ["Sao Paulo", "Corinthians", "Flamengo", "Internacional"],
      "Saudi Pro League": ["Al Hilal", "Al Ittihad", "Al Shabab"],
      "MLS": ["LA Galaxy", "Houston Dynamo", "Columbus Crew"]
    },
    rivalFirsts: ["Fernando", "Diego", "Andr\xE9s", "Wesley", "Robin", "Arjen", "Franck", "Ricardo", "Milan", "Dimitar", "Emmanuel", "Obafemi", "Landon", "Gonzalo", "Sergio", "Karim", "Cesc", "Theo", "Mikel", "Klaas"]
  },
  {
    from: 2010,
    to: 2014,
    stars: [
      S("Lionel Messi", "Argentina", "RW", "Barcelona", 35, 55, 10),
      S("Cristiano Ronaldo", "Portugal", "ST", "Real Madrid", 35, 55, 10),
      S("Xavi", "Spain", "CM", "Barcelona", 4, 10, 8),
      S("Andr\xE9s Iniesta", "Spain", "CM", "Barcelona", 4, 9, 9),
      S("Neymar", "Brazil", "LW", "Santos", 15, 28, 8),
      S("Zlatan Ibrahimovi\u0107", "Sweden", "ST", "PSG", 20, 32, 8),
      S("Wayne Rooney", "England", "ST", "Man United", 15, 27, 7),
      S("Franck Rib\xE9ry", "France", "LW", "Bayern Munich", 10, 18, 9),
      S("Arjen Robben", "Netherlands", "RW", "Bayern Munich", 12, 20, 8),
      S("Radamel Falcao", "Colombia", "ST", "Atletico Madrid", 22, 32, 7),
      S("Gareth Bale", "Wales", "RW", "Tottenham", 14, 22, 8),
      S("Luis Su\xE1rez", "Uruguay", "ST", "Liverpool", 22, 32, 8),
      S("Robert Lewandowski", "Poland", "ST", "Dortmund", 20, 30, 8),
      S("Sergio Ag\xFCero", "Argentina", "ST", "Man City", 20, 30, 8),
      S("Manuel Neuer", "Germany", "GK", "Bayern Munich", 0, 0, 9),
      S("Thomas M\xFCller", "Germany", "CAM", "Bayern Munich", 12, 22, 8),
      S("Sergio Ramos", "Spain", "CB", "Real Madrid", 3, 6, 7),
      S("Yaya Tour\xE9", "Ivory Coast", "CM", "Man City", 12, 20, 7),
      S("Eden Hazard", "Belgium", "LW", "Chelsea", 12, 18, 7),
      S("Andrea Pirlo", "Italy", "CM", "Juventus", 3, 7, 7),
      S("James Rodr\xEDguez", "Colombia", "CAM", "Porto", 10, 16, 6)
    ],
    topClubs: ["Barcelona", "Real Madrid", "Bayern Munich", "Chelsea", "Inter Milan", "Man United", "Dortmund", "Atletico Madrid", "Man City", "Juventus"],
    uclExtras: ["PSG", "Liverpool", "Porto", "Napoli", "Sevilla", "AC Milan"],
    leagues: {
      "Premier League": ["Man United", "Man City", "Chelsea", "Arsenal", "Liverpool", "Tottenham"],
      "La Liga": ["Barcelona", "Real Madrid", "Atletico Madrid", "Valencia", "Sevilla"],
      "Bundesliga": ["Bayern Munich", "Dortmund", "Leverkusen", "Schalke"],
      "Serie A": ["Juventus", "AC Milan", "Inter Milan", "Napoli", "Roma"],
      "Ligue 1": ["PSG", "Marseille", "Lyon", "Monaco", "Lille"],
      "Primeira Liga": ["Porto", "Benfica", "Braga", "Sporting CP"],
      "Eredivisie": ["Ajax", "Twente", "PSV", "Feyenoord"],
      "Scottish Premiership": ["Celtic", "Rangers", "Aberdeen"],
      "Brasileirao": ["Fluminense", "Corinthians", "Cruzeiro", "Sao Paulo"],
      "Saudi Pro League": ["Al Hilal", "Al Nassr", "Al Shabab"],
      "MLS": ["LA Galaxy", "Sporting Kansas City", "Real Salt Lake"],
      "K League 1": ["FC Seoul", "Jeonbuk Motors", "Pohang Steelers", "Ulsan HD"]
    },
    rivalFirsts: ["Eden", "Isco", "Paulo", "Romelu", "Memphis", "Alexis", "\xC1ngel", "Edinson", "Mario", "Marco", "Antoine", "Ousmane", "Leroy", "Kingsley", "Dele", "Raheem", "Thiago", "Ciro", "James", "Granit"]
  },
  {
    from: 2015,
    to: 2019,
    stars: [
      S("Lionel Messi", "Argentina", "RW", "Barcelona", 30, 50, 10),
      S("Cristiano Ronaldo", "Portugal", "ST", "Real Madrid", 28, 48, 10),
      S("Neymar", "Brazil", "LW", "PSG", 18, 30, 8),
      S("Luis Su\xE1rez", "Uruguay", "ST", "Barcelona", 24, 40, 8),
      S("Antoine Griezmann", "France", "ST", "Atletico Madrid", 16, 26, 8),
      S("Kylian Mbapp\xE9", "France", "ST", "PSG", 18, 33, 9),
      S("Mohamed Salah", "Egypt", "RW", "Liverpool", 20, 32, 9),
      S("Kevin De Bruyne", "Belgium", "CAM", "Man City", 8, 16, 9),
      S("Eden Hazard", "Belgium", "LW", "Chelsea", 12, 21, 8),
      S("Luka Modri\u0107", "Croatia", "CM", "Real Madrid", 3, 8, 9),
      S("Robert Lewandowski", "Poland", "ST", "Bayern Munich", 25, 40, 9),
      S("Sergio Ag\xFCero", "Argentina", "ST", "Man City", 18, 28, 7),
      S("Harry Kane", "England", "ST", "Tottenham", 22, 32, 8),
      S("Sadio Man\xE9", "Senegal", "LW", "Liverpool", 16, 26, 8),
      S("Virgil van Dijk", "Netherlands", "CB", "Liverpool", 2, 6, 9),
      S("Gareth Bale", "Wales", "RW", "Real Madrid", 10, 18, 7),
      S("Paulo Dybala", "Argentina", "CAM", "Juventus", 12, 22, 7),
      S("N'Golo Kant\xE9", "France", "CDM", "Chelsea", 2, 5, 8),
      S("Raheem Sterling", "England", "LW", "Man City", 15, 25, 7),
      S("Alisson Becker", "Brazil", "GK", "Liverpool", 0, 0, 7)
    ],
    topClubs: ["Real Madrid", "Barcelona", "Bayern Munich", "Liverpool", "Atletico Madrid", "Juventus", "Man City", "PSG", "Tottenham", "Ajax"],
    uclExtras: ["Roma", "Monaco", "Napoli", "Dortmund", "Sevilla", "Porto"],
    leagues: {
      "Premier League": ["Man City", "Liverpool", "Chelsea", "Tottenham", "Arsenal", "Man United"],
      "La Liga": ["Barcelona", "Real Madrid", "Atletico Madrid", "Sevilla", "Valencia"],
      "Bundesliga": ["Bayern Munich", "Dortmund", "Leipzig", "Leverkusen"],
      "Serie A": ["Juventus", "Napoli", "Roma", "Inter Milan", "AC Milan"],
      "Ligue 1": ["PSG", "Monaco", "Lyon", "Marseille", "Lille"],
      "Primeira Liga": ["Benfica", "Porto", "Sporting CP"],
      "Eredivisie": ["PSV", "Ajax", "Feyenoord"],
      "Scottish Premiership": ["Celtic", "Rangers", "Aberdeen"],
      "Brasileirao": ["Palmeiras", "Corinthians", "Flamengo", "Santos"],
      "Saudi Pro League": ["Al Hilal", "Al Nassr", "Al Ahli"],
      "MLS": ["Seattle Sounders", "Toronto FC", "Atlanta United", "Portland Timbers"],
      "K League 1": ["Jeonbuk Motors", "FC Seoul", "Ulsan HD"]
    },
    rivalFirsts: ["Eden", "Isco", "Paulo", "Romelu", "Memphis", "Alexis", "\xC1ngel", "Edinson", "Mario", "Marco", "Antoine", "Ousmane", "Leroy", "Kingsley", "Dele", "Raheem", "Thiago", "Ciro", "James", "Granit"]
  },
  {
    from: 2020,
    to: 2024,
    stars: [
      S("Lionel Messi", "Argentina", "RW", "PSG", 16, 30, 10),
      S("Robert Lewandowski", "Poland", "ST", "Barcelona", 30, 48, 10),
      S("Karim Benzema", "France", "ST", "Real Madrid", 22, 40, 10),
      S("Kylian Mbapp\xE9", "France", "ST", "PSG", 25, 42, 9),
      S("Erling Haaland", "Norway", "ST", "Man City", 28, 48, 9),
      S("Kevin De Bruyne", "Belgium", "CAM", "Man City", 7, 15, 8),
      S("Mohamed Salah", "Egypt", "RW", "Liverpool", 18, 30, 8),
      S("Vin\xEDcius Jr", "Brazil", "LW", "Real Madrid", 15, 26, 9),
      S("Jude Bellingham", "England", "CAM", "Dortmund", 12, 23, 8),
      S("Rodri", "Spain", "CDM", "Man City", 4, 10, 9),
      S("Luka Modri\u0107", "Croatia", "CM", "Real Madrid", 2, 6, 7),
      S("Harry Kane", "England", "ST", "Tottenham", 25, 40, 8),
      S("Neymar", "Brazil", "LW", "PSG", 12, 22, 7),
      S("Lautaro Mart\xEDnez", "Argentina", "ST", "Inter Milan", 18, 28, 7),
      S("Bukayo Saka", "England", "RW", "Arsenal", 12, 22, 7),
      S("Phil Foden", "England", "CAM", "Man City", 12, 20, 7),
      S("Federico Valverde", "Uruguay", "CM", "Real Madrid", 5, 12, 7),
      S("Antoine Griezmann", "France", "CAM", "Atletico Madrid", 12, 20, 7),
      S("Virgil van Dijk", "Netherlands", "CB", "Liverpool", 2, 5, 7),
      S("Thibaut Courtois", "Belgium", "GK", "Real Madrid", 0, 0, 7)
    ],
    topClubs: ["Real Madrid", "Man City", "Bayern Munich", "Chelsea", "Liverpool", "PSG", "Inter Milan", "Barcelona", "Arsenal", "Dortmund"],
    uclExtras: ["Atletico Madrid", "Napoli", "Benfica", "Porto", "AC Milan", "Ajax"],
    leagues: {
      "Premier League": ["Man City", "Liverpool", "Arsenal", "Chelsea", "Man United", "Tottenham"],
      "La Liga": ["Real Madrid", "Barcelona", "Atletico Madrid", "Sevilla", "Real Sociedad"],
      "Bundesliga": ["Bayern Munich", "Dortmund", "Leipzig", "Leverkusen"],
      "Serie A": ["Inter Milan", "AC Milan", "Napoli", "Juventus", "Atalanta"],
      "Ligue 1": ["PSG", "Marseille", "Monaco", "Lille", "Lyon"],
      "Primeira Liga": ["Porto", "Sporting CP", "Benfica", "Braga"],
      "Eredivisie": ["Ajax", "PSV", "Feyenoord"],
      "Scottish Premiership": ["Celtic", "Rangers", "Hearts"],
      "Brasileirao": ["Palmeiras", "Flamengo", "Atletico Mineiro", "Botafogo"],
      "Saudi Pro League": ["Al Hilal", "Al Ittihad", "Al Nassr"],
      "MLS": ["LAFC", "Columbus Crew", "LA Galaxy", "Inter Miami"],
      "K League 1": ["Ulsan HD", "Jeonbuk Motors", "Pohang Steelers"]
    },
    rivalFirsts: ["Kylian", "Erling", "Jude", "Bukayo", "Lamine", "Jamal", "Florian", "Pablo", "Jules", "Aur\xE9lien", "Eduardo", "Rasmus", "Cole", "Alejandro", "Xavi", "Kenan", "Arda", "Endrick", "Mathys", "Kobbie"]
  },
  {
    from: 2025,
    to: 2029,
    stars: [
      S("Kylian Mbapp\xE9", "France", "ST", "Real Madrid", 28, 45, 10),
      S("Erling Haaland", "Norway", "ST", "Man City", 28, 46, 9),
      S("Jude Bellingham", "England", "CAM", "Real Madrid", 12, 24, 9),
      S("Vin\xEDcius Jr", "Brazil", "LW", "Real Madrid", 16, 28, 9),
      S("Lamine Yamal", "Spain", "RW", "Barcelona", 14, 28, 10),
      S("Florian Wirtz", "Germany", "CAM", "Liverpool", 10, 22, 8),
      S("Jamal Musiala", "Germany", "CAM", "Bayern Munich", 10, 20, 8),
      S("Bukayo Saka", "England", "RW", "Arsenal", 12, 24, 8),
      S("Pedri", "Spain", "CM", "Barcelona", 4, 12, 8),
      S("Rodri", "Spain", "CDM", "Barcelona", 3, 9, 8),
      S("Federico Valverde", "Uruguay", "CM", "Real Madrid", 6, 12, 7),
      S("Harry Kane", "England", "ST", "Bayern Munich", 24, 38, 8),
      S("Mohamed Salah", "Egypt", "RW", "Trabzonspor", 16, 28, 7),
      S("Phil Foden", "England", "CAM", "Man City", 10, 20, 7),
      S("Declan Rice", "England", "CDM", "Arsenal", 4, 10, 7),
      S("Raphinha", "Brazil", "RW", "Barcelona", 14, 26, 8),
      S("Endrick", "Brazil", "ST", "Real Madrid", 12, 24, 7),
      S("Nico Williams", "Spain", "LW", "Athletic Bilbao", 10, 20, 7),
      S("D\xE9sir\xE9 Dou\xE9", "France", "LW", "PSG", 8, 18, 7),
      S("Kobbie Mainoo", "England", "CM", "Man United", 3, 10, 6),
      S("Gianluigi Donnarumma", "Italy", "GK", "Man City", 0, 0, 7),
      S("Ousmane Demb\xE9l\xE9", "France", "LW", "PSG", 14, 28, 9)
    ],
    topClubs: ["Real Madrid", "Man City", "Barcelona", "Bayern Munich", "Arsenal", "Liverpool", "PSG", "Inter Milan", "Leverkusen", "Chelsea"],
    uclExtras: ["Newcastle", "Atletico Madrid", "Napoli", "Benfica", "Dortmund", "Juventus"],
    leagues: {
      "Premier League": ["Man City", "Arsenal", "Liverpool", "Chelsea", "Man United", "Newcastle"],
      "La Liga": ["Real Madrid", "Barcelona", "Atletico Madrid", "Athletic Bilbao", "Girona"],
      "Bundesliga": ["Bayern Munich", "Leverkusen", "Dortmund", "Leipzig"],
      "Serie A": ["Inter Milan", "Napoli", "AC Milan", "Juventus", "Atalanta"],
      "Ligue 1": ["PSG", "Monaco", "Marseille", "Lille", "Lyon"],
      "Primeira Liga": ["Sporting CP", "Benfica", "Porto"],
      "Eredivisie": ["PSV", "Ajax", "Feyenoord"],
      "Scottish Premiership": ["Celtic", "Rangers", "Aberdeen"],
      "Brasileirao": ["Flamengo", "Palmeiras", "Botafogo", "Cruzeiro"],
      "Saudi Pro League": ["Al Ittihad", "Al Hilal", "Al Nassr"],
      "MLS": ["Inter Miami", "LAFC", "Columbus Crew", "Seattle Sounders"],
      "K League 1": ["Jeonbuk Motors", "Ulsan HD", "Pohang Steelers"]
    },
    rivalFirsts: ["Kylian", "Erling", "Jude", "Bukayo", "Lamine", "Jamal", "Florian", "Pablo", "Jules", "Aur\xE9lien", "Eduardo", "Rasmus", "Cole", "Alejandro", "Xavi", "Kenan", "Arda", "Endrick", "Mathys", "Kobbie"]
  }
];
function eraDefFor(year) {
  if (year <= ERA_DEFS[0].to) return ERA_DEFS[0];
  for (const def of ERA_DEFS) {
    if (year >= def.from && year <= def.to) return def;
  }
  return ERA_DEFS[ERA_DEFS.length - 1];
}
function getEraStars(year) {
  return eraDefFor(year).stars;
}
function getEraTopClubs(year) {
  return eraDefFor(year).topClubs;
}
function getEraLeagueClubs(year) {
  return eraDefFor(year).leagues;
}
function getEraUclOpponents(year) {
  const def = eraDefFor(year);
  return [...def.topClubs, ...def.uclExtras];
}
var RIVAL_LASTS = ["Silva", "Fern\xE1ndez", "M\xFCller", "Santos", "Rossi", "Andersen", "Johansson", "L\xF3pez", "Mart\xEDnez", "Hern\xE1ndez", "Dubois", "Weber", "Petrov", "Nielsen", "Eriksen", "Moreno", "Torres", "Schmidt", "Costa", "Bernard", "Okafor", "Diallo", "van den Berg", "Kova\u010D", "Ferreira"];
var RIVAL_NAME_COLLISIONS = /* @__PURE__ */ new Set([
  "Iv\xE1n L\xF3pez",
  "Fernando Torres",
  "Diego L\xF3pez",
  "Diego Costa",
  "Andr\xE9s Fern\xE1ndez",
  "Sergio Fern\xE1ndez",
  "Theo Hern\xE1ndez",
  "Paulo Costa",
  "Paulo Ferreira",
  "\xC1ngel L\xF3pez",
  "Marco Rossi",
  "Thiago Silva",
  "Florian M\xFCller",
  "Pablo L\xF3pez",
  "Pablo Hern\xE1ndez",
  "Xavi Hern\xE1ndez",
  "Xavi Torres",
  // Round 876: the 2026 window re-bake put a real Thiago Fernández in Club Manager.
  "Thiago Fern\xE1ndez",
  // Round 883: Liga MX brought a real Iván Moreno and Sergio Hernández into Club Manager.
  "Iv\xE1n Moreno",
  "Sergio Hern\xE1ndez",
  // Round 902: the 2005-06 era's Ligue 1 brought a real Eduardo Costa (at Espanyol after that summer).
  // Round 901: the 2010-11 big five brought a real Ricardo Costa (Valencia) and Eduardo Costa (Monaco).
  "Ricardo Costa",
  "Eduardo Costa"
]);
function getEraRivalName(year) {
  const first = pick(eraDefFor(year).rivalFirsts);
  const start = Math.floor(Math.random() * RIVAL_LASTS.length);
  for (let i = 0; i < RIVAL_LASTS.length; i++) {
    const name = `${first} ${RIVAL_LASTS[(start + i) % RIVAL_LASTS.length]}`;
    if (!RIVAL_NAME_COLLISIONS.has(name)) return name;
  }
  return `${first} ${RIVAL_LASTS[start]}`;
}
var CLUB_FOUNDED_AFTER = {
  "Leipzig": 2010,
  "RB Leipzig": 2010,
  "Inter Miami": 2020,
  "LAFC": 2018,
  "Los Angeles FC": 2018,
  "New York City FC": 2015,
  "Austin FC": 2021,
  "Charlotte FC": 2022,
  // Round 54 club expansion: keep the new-world clubs out of eras where they
  // did not exist yet (or were not professional outfits yet).
  "Toronto FC": 2006,
  "Vancouver Whitecaps": 2011,
  "Melbourne Victory": 2004,
  "Wellington Phoenix": 2007,
  "Auckland FC": 2024,
  "Mumbai City": 2014,
  "Buriram United": 2012,
  "Hanoi FC": 2006,
  "Al Duhail": 2009,
  "Shanghai Port": 2005,
  "Sheriff Tiraspol": 1997,
  "Beijing Guoan": 1992,
  /* Round 302 league depth pass. MLS kicked off in 1996, so its two founding
     era clubs date from there (a gap this table had all along for LA Galaxy),
     and the newer franchises from their own first seasons. */
  "LA Galaxy": 1996,
  "Columbus Crew": 1996,
  "Seattle Sounders": 2007,
  "Atlanta United": 2017,
  /* Round 1013: the club played as Bragantino until Red Bull's rebrand for
     the 2020 season (Planet Football's Red Bull in Brazil piece, and Lance!'s
     2020 badge and kit launch, read 2026-10-05). Same rule as RB Leipzig: the
     name did not exist before then. */
  "Red Bull Bragantino": 2020
};
var ERA_TIER_RULES = [
  { name: "Man City", until: 2008, tier: 4 },
  { name: "Man City", until: 2010, tier: 2 },
  { name: "Chelsea", until: 1996, tier: 3 },
  { name: "Chelsea", until: 2003, tier: 2 },
  { name: "PSG", until: 2011, tier: 2 },
  { name: "Arsenal", until: 1996, tier: 2 },
  { name: "Liverpool", until: 2e3, tier: 2 },
  { name: "AC Milan", until: 2011, tier: 1 },
  { name: "Napoli", until: 1992, tier: 2 },
  { name: "Napoli", until: 2010, tier: 4 },
  { name: "Newcastle", from: 2007, until: 2021, tier: 3 },
  { name: "Tottenham", until: 2009, tier: 3 },
  { name: "Atletico Madrid", until: 2010, tier: 3 },
  { name: "Dortmund", until: 1993, tier: 3 },
  { name: "Dortmund", until: 2002, tier: 1 },
  { name: "Monaco", until: 2004, tier: 2 },
  { name: "Marseille", until: 1993, tier: 1 },
  { name: "Al Hilal", until: 2022, tier: 4 },
  { name: "Al Nassr", until: 2022, tier: 4 },
  { name: "Leipzig", until: 2015, tier: 4 },
  // Round 54: era-honest tiers for the expansion clubs
  { name: "Girona", until: 2022, tier: 4 },
  { name: "Al Ittihad", until: 2022, tier: 4 },
  { name: "Brighton", until: 2016, tier: 4 },
  { name: "Brighton", until: 2021, tier: 3 },
  { name: "Wolves", until: 2017, tier: 4 },
  { name: "Zenit", until: 2006, tier: 4 },
  { name: "Shakhtar Donetsk", until: 1999, tier: 4 },
  /* Round 1013: Forest were relegated in 1999 and came back up through the
     2022 Championship play-off final, so 1999-00 to 2021-22 were spent
     outside the top flight (ESPN's 29 May 2022 match report and Sports
     Illustrated the same day, "the first time since 1999"). Their tier 2 is
     Club Manager's 2026 XI and would otherwise apply in every era. The two
     earlier second tier seasons, 1993-94 (Division One runners up) and
     1997-98 (Division One champions), get one season rules of their own
     (rsssf's Football League tables for both seasons and Wikipedia's list
     of the club's seasons, read 2026-10-05). */
  { name: "Nottingham Forest", from: 1993, until: 1993, tier: 4 },
  { name: "Nottingham Forest", from: 1997, until: 1997, tier: 4 },
  { name: "Nottingham Forest", from: 1999, until: 2021, tier: 4 }
];
function adjustClubsForYear(clubs, year) {
  return clubs.filter((c) => {
    const founded = CLUB_FOUNDED_AFTER[c.name];
    return founded === void 0 || year >= founded;
  }).map((c) => {
    for (const rule of ERA_TIER_RULES) {
      if (rule.name !== c.name) continue;
      if (rule.from !== void 0 && year < rule.from) continue;
      if (rule.until !== void 0 && year > rule.until) continue;
      if (c.tier === rule.tier) return c;
      return { ...c, tier: rule.tier };
    }
    return c;
  });
}
var INJ_MINOR = ["Bruised ribs", "Ankle knock", "Dead leg", "Tight calf", "Twisted ankle", "Hip knock"];
var INJ_MODERATE = ["Hamstring tear", "Groin strain", "MCL sprain", "Metatarsal fracture", "Dislocated shoulder", "Calf tear", "High ankle sprain"];
var INJ_SEVERE = ["ACL rupture", "Achilles tendon rupture", "Broken leg", "Back stress fracture", "Ruptured quad"];
function rollSeasonInjury(chance) {
  if (Math.random() >= chance) return null;
  const sev = Math.random();
  if (sev < 0.15) return { name: pick(INJ_SEVERE), weeks: rand(14, 30), severe: true };
  if (sev < 0.5) return { name: pick(INJ_MODERATE), weeks: rand(5, 10), severe: false };
  return { name: pick(INJ_MINOR), weeks: rand(2, 4), severe: false };
}
var BDOR_WIN_MIN_GOALS = 30;
function rollPotential(startingOvr) {
  const r = Math.random();
  let pot;
  if (r < 0.5) pot = rand(70, 79);
  else if (r < 0.8) pot = rand(78, 84);
  else if (r < 0.93) pot = rand(84, 89);
  else if (r < 0.985) pot = rand(89, 93);
  else pot = rand(93, 97);
  return Math.min(99, Math.max(pot, startingOvr + 6));
}
var PHONE_POOL = [
  {
    id: "mum_call",
    from: "Mum",
    emoji: "\u2764\uFE0F",
    phase: "any",
    text: "Hi love, haven't heard from you in weeks. Everything ok? Call me when you can.",
    choices: [
      { label: "Call her tonight", reply: "Calling you after training, promise. Love you", karma: 8, morale: 6 },
      { label: "Leave it on read", reply: "", karma: -6, morale: -2 }
    ]
  },
  {
    id: "kid_dm",
    from: "Fan DM",
    emoji: "\u{1F9D2}",
    phase: "any",
    text: "ur my favorite player ever. im in hospital and my dream is a signed shirt. no worries if not",
    choices: [
      { label: "Send a signed shirt and visit", reply: "Shirt is on the way and I'm coming to see you next week. Stay strong", karma: 12, popularity: 6, cash: -0.1 },
      { label: "Send the shirt", reply: "On its way little legend", karma: 6, popularity: 3 },
      { label: "Ignore it", reply: "", karma: -8 }
    ]
  },
  {
    id: "agent_boots",
    from: "Agent",
    emoji: "\u{1F4BC}",
    phase: "any",
    text: "Boot deal on the table. Decent money but the brand got caught using sweatshops last year. Your call.",
    choices: [
      { label: "Take the money", reply: "Money is money. Send the contract", karma: -7, cash: 1.5 },
      { label: "Turn it down publicly", reply: "Not wearing that. And I'm saying why", karma: 9, popularity: 4 },
      { label: "Quietly decline", reply: "Pass on this one. Keep it quiet", karma: 4 }
    ]
  },
  {
    id: "teammate_benched",
    from: "Teammate",
    emoji: "\u{1F624}",
    phase: "pro",
    text: "Gaffer benched me again bro. Thinking of asking away in January. You think I should go?",
    choices: [
      { label: "Be honest with him", reply: "You deserve minutes mate. If he won't give them, go get them somewhere", karma: 6, morale: 2 },
      { label: "Tell him to stop whining", reply: "Train harder then. Nobody owes you a shirt", karma: -5 },
      { label: "Dodge the question", reply: "Tough one bro. Sleep on it", karma: -1 }
    ]
  },
  {
    id: "granny_scam",
    from: "Unknown",
    emoji: "\u{1F3A3}",
    phase: "any",
    text: "CONGRATULATIONS! You won 2 MILLION. Just send account details plus a small release fee to claim.",
    choices: [
      { label: "Report and warn fans", reply: "Posting this so nobody falls for it. Stay safe out there", karma: 7, popularity: 3 },
      { label: "Delete it", reply: "", karma: 1 },
      { label: "Reply as a joke and string them along", reply: "Amazing news!! My account number is 1-2-3-GET-A-JOB", karma: 2, popularity: 2 }
    ]
  },
  {
    id: "kitman_fine",
    from: "Kit man",
    emoji: "\u{1F9FA}",
    phase: "pro",
    text: "You left the away kit at the hotel AGAIN. Club wants to fine you. I can cover for you this once.",
    choices: [
      { label: "Own it, pay the fine", reply: "My fault Tony. I'll pay it. Pint on me too", karma: 7, cash: -0.05 },
      { label: "Let him cover for you", reply: "You're a legend. I owe you", karma: -5, morale: 2 }
    ]
  },
  {
    id: "charity_gala",
    from: "Foundation",
    emoji: "\u{1F397}\uFE0F",
    phase: "pro",
    minAge: 19,
    text: "We're hosting a children's hospital gala Friday. Would mean the world if you came. Press will be there.",
    choices: [
      { label: "Go and donate", reply: "Count me in. And put me down for a donation", karma: 10, popularity: 5, cash: -0.5 },
      { label: "Go for the cameras only", reply: "I'll swing by for an hour", karma: 2, popularity: 3 },
      { label: "Skip it", reply: "Can't make it, good luck", karma: -6 }
    ]
  },
  {
    id: "old_coach",
    from: "Youth coach",
    emoji: "\u{1F474}",
    phase: "pro",
    text: "Watched you play last weekend. Still remember you at 12 refusing to pass. Proud of you kid.",
    choices: [
      { label: "Thank him properly", reply: "Everything started with you coach. Tickets for you whenever you want, for life", karma: 8, morale: 5 },
      { label: "Thumbs up emoji", reply: "\u{1F44D}", karma: -3 }
    ]
  },
  {
    id: "party_final",
    from: "Promoter",
    emoji: "\u{1F389}",
    phase: "pro",
    minAge: 18,
    text: "Biggest party of the year Saturday night. VIP table with your name on it. Cup final is Sunday btw.",
    choices: [
      { label: "Stay home and rest", reply: "Final tomorrow. Another time", karma: 6, morale: 2 },
      { label: "Go but leave early", reply: "One hour max, then I'm gone", karma: -3, popularity: 2 },
      { label: "Full send", reply: "Save me the good seat", karma: -9, popularity: 4, morale: 3 }
    ]
  },
  {
    id: "rookie_advice",
    from: "Academy kid",
    emoji: "\u{1F331}",
    phase: "pro",
    minAge: 21,
    text: "Just got promoted to first team training. Any advice? Kinda terrified honestly.",
    choices: [
      { label: "Take him under your wing", reply: "Come in early tomorrow, we'll do finishing drills together. You'll be fine", karma: 9, morale: 3 },
      { label: "One line of advice", reply: "First ball, first tackle, win it. Rest follows", karma: 4 },
      { label: "Big time him", reply: "Earn it like I did", karma: -7 }
    ]
  },
  {
    id: "journalist_leak",
    from: "Journalist",
    emoji: "\u{1F4F0}",
    phase: "pro",
    text: "I know the dressing room fell out with the manager. Give me the inside story, I'll keep you anonymous.",
    choices: [
      { label: "Keep it in house", reply: "Nothing to tell. Dressing room stays in the dressing room", karma: 8, morale: 2 },
      { label: "Leak it", reply: "Ok but this NEVER came from me", karma: -10, popularity: 3 }
    ]
  },
  {
    id: "barber_cut",
    from: "Barber",
    emoji: "\u{1F488}",
    phase: "any",
    text: "New style idea for you. Bold. Might break the internet, might get you fined by the boss. You in?",
    choices: [
      { label: "Send it", reply: "Chair. Tomorrow. Do your worst", karma: 2, popularity: 4 },
      { label: "Keep it classic", reply: "Usual trim mate, big game week", karma: 1 }
    ]
  },
  {
    id: "lost_wallet",
    from: "Groundskeeper",
    emoji: "\u{1F45B}",
    phase: "any",
    text: "Found a wallet in the car park with 800 quid inside. No ID. What do I do with it?",
    choices: [
      { label: "Hand it to reception", reply: "Reception, mate. Someone's having a bad day", karma: 6 },
      { label: "Finders keepers", reply: "That's the football gods paying you. Keep it", karma: -6 }
    ]
  },
  {
    id: "ex_club_message",
    from: "Old teammate",
    emoji: "\u{1FAC2}",
    phase: "pro",
    minAge: 22,
    text: "Club legends match at your first club next month. They're asking if you'd come back and play 45 minutes.",
    choices: [
      { label: "Play the full 90", reply: "45? I'm playing the whole thing. That badge made me", karma: 8, popularity: 4, morale: 3 },
      { label: "Politely decline", reply: "Season's too heavy, give everyone my love", karma: -2 }
    ]
  },
  {
    id: "crypto_bro",
    from: "School friend",
    emoji: "\u{1FA99}",
    phase: "pro",
    minAge: 19,
    text: "Bro I need you to promote my new coin BallerCoin to your followers. It's guaranteed 100x. Family discount.",
    choices: [
      { label: "Hard pass", reply: "Not putting my fans into that. Look after yourself", karma: 7 },
      { label: "Promote it", reply: "Sending the post now. We better get rich", karma: -11, cash: 0.8, popularity: -3 }
    ]
  },
  {
    id: "training_extra",
    from: "Fitness coach",
    emoji: "\u{1F3CB}\uFE0F",
    phase: "any",
    text: "Optional double sessions next month. Brutal but they work. Most of the squad is dodging them.",
    choices: [
      { label: "Sign up", reply: "Put my name down. First one in, last one out", karma: 5, morale: -2 },
      { label: "Skip them", reply: "Rest is part of training too coach", karma: -3, morale: 2 }
    ]
  },
  {
    id: "youth_bully",
    from: "Academy mate",
    emoji: "\u{1F97A}",
    phase: "youth",
    text: "The older lads keep hiding my boots and binning my kit. Coach says toughen up. Don't know what to do.",
    choices: [
      { label: "Stand up for him", reply: "Sit with me at lunch. If they touch your stuff again they deal with me", karma: 10, morale: 2 },
      { label: "Stay out of it", reply: "Rough mate. Keep your head down", karma: -6 }
    ]
  },
  {
    id: "youth_homework",
    from: "Tutor",
    emoji: "\u{1F4DA}",
    phase: "youth",
    text: "You've missed three sessions. The academy requires passing grades to keep your registration. Tonight, 6pm?",
    choices: [
      { label: "Show up", reply: "I'll be there. Sorry, no excuses", karma: 6 },
      { label: "Blow it off for extra shooting", reply: "Football is my exam", karma: -4 }
    ]
  },
  {
    id: "youth_poach",
    from: "Stranger",
    emoji: "\u{1F576}\uFE0F",
    phase: "youth",
    text: "I represent players. Ditch the academy's advisor, sign with me quietly, I'll get your family paid NOW.",
    choices: [
      { label: "Tell the academy", reply: "Reported you to the club. Don't message me again", karma: 8 },
      { label: "Meet him in secret", reply: "Where and when?", karma: -8, cash: 0.05 }
    ]
  },
  {
    id: "nutrition_cheat",
    from: "Nutritionist",
    emoji: "\u{1F957}",
    phase: "any",
    text: "Your body fat crept up. I'm putting you on the strict plan. No takeaways for eight weeks. Confirm?",
    choices: [
      { label: "Commit fully", reply: "Locked in. Hide the menus", karma: 5, morale: -1 },
      { label: "Secret cheat days", reply: "Confirmed \u{1F607} (orders kebab)", karma: -4, morale: 3 }
    ]
  },
  {
    id: "grandad_game",
    from: "Grandad",
    emoji: "\u{1F9D3}",
    phase: "any",
    text: "Never miss you on the telly. My hip's too dodgy for the stadium now. One day take the trophy round mine eh?",
    choices: [
      { label: "Visit with your shirt", reply: "Coming round Sunday with a shirt and biscuits. Put the kettle on", karma: 9, morale: 5 },
      { label: "Promise vaguely", reply: "One day grandad, promise", karma: 1 }
    ]
  },
  {
    id: "referee_apology",
    from: "Referee assoc.",
    emoji: "\u{1F7E8}",
    phase: "pro",
    text: "Your comments about Saturday's officiating went viral. We'd welcome a public clarification.",
    choices: [
      { label: "Apologize properly", reply: "I was out of order. Refs have the hardest job in football. Apologies", karma: 6, popularity: -1 },
      { label: "Double down", reply: "I said what I said", karma: -7, popularity: 5 }
    ]
  },
  {
    id: "stadium_worker",
    from: "Steward",
    emoji: "\u{1F9BA}",
    phase: "pro",
    text: "30 years at this club, retiring Saturday. Would you sign my hi-vis after the game? Means a lot.",
    choices: [
      { label: "Sign it and get the squad to", reply: "I'll get the whole squad on it. Thanks for everything", karma: 9, popularity: 3 },
      { label: "If there's time", reply: "If I can, busy day", karma: -2 }
    ]
  },
  {
    id: "diving_tip",
    from: "Veteran",
    emoji: "\u{1F3AD}",
    phase: "pro",
    maxAge: 24,
    text: "Kid, lesson one. In the box, feel contact, go down. Refs give it every time. That's how you win games.",
    choices: [
      { label: "Refuse to dive", reply: "I stay on my feet. I score them properly", karma: 8 },
      { label: "Take the advice", reply: "Noted. Whatever wins", karma: -8 }
    ]
  },
  {
    id: "hometown_pitch",
    from: "Council",
    emoji: "\u{1F3D7}\uFE0F",
    phase: "pro",
    minAge: 20,
    text: "The pitch you grew up on is closing without funding. 200 kids play there weekly. Sponsorship would save it.",
    choices: [
      { label: "Fund it and rename it", reply: "I'll cover it. Name it after my old coach, not me", karma: 12, popularity: 5, cash: -1.2 },
      { label: "Fund it quietly", reply: "Invoice my foundation. No press", karma: 10, cash: -1.2 },
      { label: "Share a fundraiser", reply: "Posting the link, let's all chip in", karma: 4, popularity: 1 }
    ]
  },
  {
    id: "team_fine_pot",
    from: "Captain",
    emoji: "\u{1F37A}",
    phase: "pro",
    text: "End of season squad night out, fines pot pays. You're 400 in the pot for late gym arrivals. Coming?",
    choices: [
      { label: "Pay up and go", reply: "Fair cop. First round's the fine pot anyway", karma: 4, morale: 4, cash: -0.01 },
      { label: "Dispute the fines", reply: "The gym clock is WRONG and I have evidence", karma: -3, morale: 1 }
    ]
  },
  {
    id: "kids_camp",
    from: "Community team",
    emoji: "\u26BD",
    phase: "any",
    text: "Summer kids camp needs a surprise guest coach for a morning. No fee, just chaos and juice boxes.",
    choices: [
      { label: "Do the full morning", reply: "I'm in. Someone else does the juice run though", karma: 8, popularity: 3, morale: 3 },
      { label: "Send signed balls instead", reply: "Can't make it, sending a box of signed balls", karma: 3 }
    ]
  },
  {
    id: "tax_scheme",
    from: "Financial advisor",
    emoji: "\u{1F3DD}\uFE0F",
    phase: "pro",
    minAge: 21,
    text: "New structure for your image rights. Runs through three islands. Technically legal. Probably. Saves millions.",
    choices: [
      { label: "Keep it clean", reply: "Pay what I owe where I earn it. Not risking my name", karma: 8 },
      { label: "Do the scheme", reply: "If it's legal, file it", karma: -9, cash: 2 }
    ]
  },
  {
    id: "injury_teammate",
    from: "Teammate",
    emoji: "\u{1F3E5}",
    phase: "pro",
    text: "ACL gone. Nine months. Sitting in this hospital bed wondering if I'll ever be the same, honestly.",
    choices: [
      { label: "Visit weekly", reply: "I'm there every week bro. Rehab buddies. You're coming back stronger", karma: 10, morale: 2 },
      { label: "Send a message", reply: "Gutted for you. Speedy recovery brother", karma: 3 },
      { label: "Read it later", reply: "", karma: -6 }
    ]
  },
  {
    id: "boot_kid_swap",
    from: "Ballkid",
    emoji: "\u{1F45F}",
    phase: "pro",
    text: "You gave me your boots after the match!! My mum says I have to check you actually meant it??",
    choices: [
      { label: "Meant it, keep them", reply: "All yours. Score goals in them", karma: 7, popularity: 2 },
      { label: "Ask for them back", reply: "Actually those are my lucky pair... sorry kid", karma: -9, popularity: -3 }
    ]
  },
  {
    id: "podcast_invite",
    from: "Podcast",
    emoji: "\u{1F399}\uFE0F",
    phase: "pro",
    minAge: 20,
    text: "Come on the show. Fans love unfiltered. We WILL ask about your manager, your rival and your contract.",
    choices: [
      { label: "Go and stay classy", reply: "I'll come on. Keeping club stuff in house though", karma: 5, popularity: 3 },
      { label: "Go and spill everything", reply: "Unfiltered? You'll get unfiltered", karma: -6, popularity: 6 },
      { label: "Decline", reply: "Not my thing, good luck with the show", karma: 1 }
    ]
  },
  {
    id: "penalty_gift",
    from: "Rival striker",
    emoji: "\u{1F91D}",
    phase: "pro",
    minAge: 22,
    text: "You're one goal off the golden boot and we've got a dead rubber Sunday. Win a pen, I won't complain. Us strikers stick together.",
    choices: [
      { label: "Win it fair", reply: "If I get the boot I'm getting it properly. Respect though", karma: 7 },
      { label: "Take the free pen", reply: "Say less. Drinks on me if it lands", karma: -8 }
    ]
  },
  {
    id: "documentary",
    from: "Streaming service",
    emoji: "\u{1F3AC}",
    phase: "pro",
    minAge: 23,
    text: "All access documentary on your season. Big fee. Cameras everywhere including the bad days.",
    choices: [
      { label: "Do it honestly", reply: "Deal, but you show the real thing, not a highlight reel", karma: 5, popularity: 6, cash: 1 },
      { label: "Decline", reply: "Dressing room stays sacred. Pass", karma: 3 }
    ]
  },
  {
    id: "matchday_nerves",
    from: "Sports psych",
    emoji: "\u{1F9E0}",
    phase: "any",
    text: "Noticed you've been quiet before big games. My door is open Thursday if you want to talk it through.",
    choices: [
      { label: "Book the session", reply: "Thursday works. Cheers doc", karma: 5, morale: 5 },
      { label: "Tough it out", reply: "I'm fine. Just focused", karma: -2 }
    ]
  },
  {
    id: "old_boots_museum",
    from: "Club museum",
    emoji: "\u{1F3DB}\uFE0F",
    phase: "pro",
    minAge: 26,
    text: "We'd love your debut boots for the club museum display. Fans keep asking about you.",
    choices: [
      { label: "Donate with a note", reply: "They're yours. I'll write the story that goes with them", karma: 6, popularity: 3 },
      { label: "Keep them", reply: "Those stay with me forever, sorry", karma: 0 }
    ]
  }
];
function pickPhoneTexts(age, phase, usedIds, count) {
  const used = new Set(usedIds);
  const fits = PHONE_POOL.filter(
    (t) => !used.has(t.id) && (t.phase === "any" || t.phase === phase) && (t.minAge === void 0 || age >= t.minAge) && (t.maxAge === void 0 || age <= t.maxAge)
  );
  const out = [];
  const pool = [...fits];
  while (out.length < count && pool.length > 0) {
    const i = Math.floor(Math.random() * pool.length);
    out.push(pool[i]);
    pool.splice(i, 1);
  }
  return out;
}

// src/lib/soccerCareerContinental.ts
init_clubManagerUclGroups();
var CLUB_COUNTRY_CONFED = {
  UAE: "AFC",
  Malaysia: "AFC",
  Monaco: "UEFA"
};
function clubConfederation(country) {
  return CLUB_COUNTRY_CONFED[country] ?? confederationOf(country);
}
var CONTINENTAL_SIMPLIFIED = "Played here as a straight knockout from the quarter-finals: two legs a tie and a final of one match or two legs by season, extra time and penalties when level, no group stage and no away goals.";
var RSSSF_LIB = 'RSSSF, "Copa Libertadores de America", https://www.rsssf.org/sacups/copalib.html, read 2026-10-03: every final two legs to 2018, then one match (Flamengo 2-1 River Plate in Lima, 2019)';
var RSSSF_CONCACAF = 'RSSSF, "CONCACAF Cup/Champions League", https://www.rsssf.org/tablesc/ca1.html, read 2026-10-03: finals of two legs in 1990 and 1991, one match or a final round from 1992 to 2000, 2001 "tournament abandoned", one match in 2002 (Pachuca 1-0 Morelia, final 18 September, https://www.rsssf.org/tablesc/cacups02.html), two legs from 2002/03 to 2019, one match in 2020 (Tigres 2-1 Los Angeles FC) and 2021 (Monterrey 1-0 America), two legs in 2022 and 2023, one match from 2024';
var CONCACAF_SITE = 'CONCACAF, "Champions Cup", https://www.concacaf.com/champions-cup/, read 2026-10-03: the 2026 edition under the Champions Cup name';
var RSSSF_ASIA = `RSSSF, "Asian Champions' Cup", https://www.rsssf.org/tablesa/as1.html, read 2026-10-03: merged into a Champions League from 2002-03; one match finals from 1991 to 2002, two legs 2003 to 2008 (Al-Ain v BEC Tero Sasana, 11 October 2003, the second leg), one match 2009 to 2012, two legs 2013 to 2019 (Urawa v Al-Hilal, 24 November 2019, the second leg), one match 2020 and 2021, two legs in the 2022 edition (6 May 2023, the second leg) and 2023-24 (25 May 2024), one match from 2024-25 (Al-Ahli v Kawasaki Frontale, 3 May 2025)`;
var AFC_SITE = 'AFC, "AFC Champions League Elite", https://www.the-afc.com/en/club/afc_champions_league_elite.html, read 2026-10-03: the 2026/27 edition and its league stage under that name';
var RSSSF_AFRICA = `RSSSF, "African Champions' Cup", https://www.rsssf.org/tablesa/af1.html, read 2026-10-03: a Champions League format from 1997, two legged finals every year except the three listed as one match, 2020 (Al-Ahly 2-1 Zamalek), 2021 (Al-Ahly 3-0 Kaizer Chiefs) and 2022 (Wydad 2-0 Al-Ahly)`;
var CONMEBOL_FINAL = 'CONMEBOL, "La CONMEBOL Libertadores se definira en final unica a partir de 2019", https://www.conmebol.com/noticias/la-conmebol-libertadores-se-definira-en-final-unica-partir-de-2019-con-mayores-beneficios-los-clubes/, 23 February 2018, read 2026-10-05: a single final from 2019, and 2018 the last final played home and away';
var SKY_LIB = 'Sky Sports, "Copa Libertadores: Flamengo beat River Plate with late goals", https://www.skysports.com/football/news/11095/11868761/copa-libertadores-flamengo-beat-river-plate-with-late-goals, 23 November 2019, read 2026-10-05: the Copa Libertadores final in Lima, the first at a neutral venue';
var CONCACAF_EVOLUTION = 'CONCACAF, "The evolution of CONCACAF club competitions", https://www.concacaf.com/competitions/champions-cup/news/the-evolution-of-concacaf-club-competitions, 1 February 2018, read 2026-10-05: the Champions Cup from 1962, its era closing with the 2008 final (Pachuca 3-2 on aggregate), and the first Champions League in 2008/09 (Atlante 2-0 on aggregate)';
var CONCACAF_HISTORY = 'CONCACAF, "The Champions Cup history: 2000-2024", https://www.concacaf.com/champions-cup/news/the-champions-cup-history-2000-2024/, 3 February 2025, read 2026-10-05: a one match final in 2000, the 2001 tournament canceled, finals on aggregate in 2003, 2004, 2005, 2022 (Seattle 5-2 Pumas) and 2023 (Leon 3-1 LAFC)';
var CONCACAF_2024 = 'CONCACAF, "2024 Concacaf Champions Cup: All You Need to Know", https://www.concacaf.com/news/2024-concacaf-champions-cup-all-you-need-to-know-x5951, 6 June 2023, read 2026-10-05: "Beginning with the 2024 edition, the Concacaf Champions Cup will replace the Champions League", and a final of one match';
var FOX_CONCACAF = 'FOX Sports, "CONCACAF Champions League tweaking name of competition, set to expand", https://www.foxsports.com/stories/soccer/concacaf-champions-league-tweaking-name-of-competition-set-to-expand, 6 June 2023, read 2026-10-05: the CONCACAF Champions Cup from 2024 on, Champions Cup the original name from 1962, renamed Champions League "15 years ago", that is 2008';
var CONCACAF_CCL_FINALS = 'CONCACAF, "CCL Final: All-Time Results & Scorers", https://www.concacaf.com/competitions/champions-cup/news/ccl-final-all-time-results-scorers, 6 February 2018, read 2026-10-05: the Champions League finals of 2008/09 to 2012/13, each over two legs';
var AFC_2003 = `AFC, "Dawn of a new era: A look back at the 2003 ACL final", https://www.the-afc.com/en/club/afc_champions_league/news/dawn_of_a_new_era_a_look_back_at_the_2003_acl_final.html, 28 October 2021, read 2026-10-05: the Asian Club Championship, Cup Winners' Cup and Super Cup merged into the AFC Champions League, whose first final, in 2003, was two legs`;
var NATIONAL_2024 = 'The National, "Al Ain defeat Yokohama F Marinos to lift Asian Champions League crown for second time", https://www.thenationalnews.com/sport/football/2024/05/25/al-ain-defeat-yokohama-f-marinos-to-lift-asian-champions-league-crown-for-second-time/, 25 May 2024, read 2026-10-05: the AFC Champions League, the 2003 side winning the inaugural rebranded Champions League, and the 2024 final over two legs (6-3 on aggregate)';
var AFC_ELITE_DEBUT = 'AFC, "AFC Champions League Elite unveils top-class lineup for inaugural season", https://www.the-afc.com/en/club/afc_champions_league_elite/news/afc_champions_league_elite_unveils_top-class_lineup_for_inaugural_season.html, 27 June 2024, read 2026-10-05: the maiden AFC Champions League Elite from August 2024';
var ESPN_ELITE_SOURCE = { url: "https://www.espn.com/soccer/story/_/id/41270886/new-afc-champions-league-format-explained/" };
var ESPN_ELITE = 'ESPN, "The new AFC Champions League format explained", ' + ESPN_ELITE_SOURCE.url + ", 15 September 2024, read 2026-10-05: the AFC Champions League Elite from 2024-25, in place of the AFC Champions League, every tie from the quarter-finals one match";
var CAF_HISTORY = 'CAF, "All you need to know about past winners of the CAF Champions League", https://www.cafonline.com/caf-champions-league/news/all-you-need-to-know-about-past-winners-of-the-caf-champions-league/, 7 May 2026, read 2026-10-05: first contested in 1964 as the African Cup of Champions Clubs, rebranded in 1997, and the 2025/26 final over two legs';
var SUPERSPORT_CAF = 'SuperSport, "CAF Champions League: All You Need to Know", https://supersport.com/football/caf-champions-league/news/57ab7006-ead3-4091-a51f-ab1f1724317a/caf-champions-league-all-you-need-to-know, 20 November 2024, read 2026-10-05: the CAF Champions League, formerly called the African Cup of Champions Clubs';
var SUPERSPORT_CAF_AZ = 'SuperSport, "A-Z of the CAF Champions League", https://supersport.com/football/news/04c766a9-295a-49a9-8028-609aaeb82941/a-z-of-the-caf-champions-league, 20 November 2024, read 2026-10-05: the Champions League format from 1997, before it a knockout with every tie over two legs, and now a final over two legs';
var CONTINENTAL_PERIODS = [
  { id: "lib-two-leg-final", cup: "libertadores", confederation: "CONMEBOL", from: 1900, to: 2018, name: "Copa Libertadores", finalLegs: 2, sources: [RSSSF_LIB, CONMEBOL_FINAL, SKY_LIB] },
  { id: "lib-one-final", cup: "libertadores", confederation: "CONMEBOL", from: 2019, to: null, name: "Copa Libertadores", finalLegs: 1, sources: [RSSSF_LIB, CONMEBOL_FINAL, SKY_LIB] },
  { id: "concacaf-champions-cup-to-1991", cup: "concacaf", confederation: "CONCACAF", from: 1900, to: 1991, name: "CONCACAF Champions Cup", finalLegs: 2, sources: [RSSSF_CONCACAF, CONCACAF_EVOLUTION, FOX_CONCACAF] },
  { id: "concacaf-champions-cup-1992-2000", cup: "concacaf", confederation: "CONCACAF", from: 1992, to: 2e3, name: "CONCACAF Champions Cup", finalLegs: 1, sources: [RSSSF_CONCACAF, CONCACAF_EVOLUTION, FOX_CONCACAF, CONCACAF_HISTORY] },
  { id: "concacaf-champions-cup-2002", cup: "concacaf", confederation: "CONCACAF", from: 2002, to: 2002, name: "CONCACAF Champions Cup", finalLegs: 1, sources: [RSSSF_CONCACAF, CONCACAF_EVOLUTION, FOX_CONCACAF, CONCACAF_HISTORY] },
  { id: "concacaf-champions-cup-2003-2007", cup: "concacaf", confederation: "CONCACAF", from: 2003, to: 2007, name: "CONCACAF Champions Cup", finalLegs: 2, sources: [RSSSF_CONCACAF, CONCACAF_EVOLUTION, FOX_CONCACAF, CONCACAF_HISTORY] },
  { id: "concacaf-champions-league", cup: "concacaf", confederation: "CONCACAF", from: 2008, to: 2018, name: "CONCACAF Champions League", finalLegs: 2, sources: [RSSSF_CONCACAF, CONCACAF_EVOLUTION, CONCACAF_CCL_FINALS, FOX_CONCACAF] },
  { id: "concacaf-champions-league-2019-2020", cup: "concacaf", confederation: "CONCACAF", from: 2019, to: 2020, name: "CONCACAF Champions League", finalLegs: 1, sources: [RSSSF_CONCACAF, CONCACAF_EVOLUTION, FOX_CONCACAF] },
  { id: "concacaf-champions-league-2021-2022", cup: "concacaf", confederation: "CONCACAF", from: 2021, to: 2022, name: "CONCACAF Champions League", finalLegs: 2, sources: [RSSSF_CONCACAF, CONCACAF_HISTORY, CONCACAF_2024, FOX_CONCACAF] },
  { id: "concacaf-champions-cup", cup: "concacaf", confederation: "CONCACAF", from: 2023, to: null, name: "CONCACAF Champions Cup", finalLegs: 1, sources: [RSSSF_CONCACAF, CONCACAF_SITE, CONCACAF_2024, FOX_CONCACAF] },
  { id: "asian-club-championship", cup: "afc", confederation: "AFC", from: 1900, to: 2001, name: "Asian Club Championship", finalLegs: 1, sources: [RSSSF_ASIA, AFC_2003] },
  { id: "afc-champions-league-2002-2008", cup: "afc", confederation: "AFC", from: 2002, to: 2008, name: "AFC Champions League", finalLegs: 2, sources: [RSSSF_ASIA, AFC_2003, NATIONAL_2024] },
  { id: "afc-champions-league-2009-2012", cup: "afc", confederation: "AFC", from: 2009, to: 2012, name: "AFC Champions League", finalLegs: 1, sources: [RSSSF_ASIA, AFC_2003, NATIONAL_2024] },
  { id: "afc-champions-league-2013-2019", cup: "afc", confederation: "AFC", from: 2013, to: 2019, name: "AFC Champions League", finalLegs: 2, sources: [RSSSF_ASIA, AFC_2003, NATIONAL_2024] },
  { id: "afc-champions-league-2020-2021", cup: "afc", confederation: "AFC", from: 2020, to: 2021, name: "AFC Champions League", finalLegs: 1, sources: [RSSSF_ASIA, AFC_2003, NATIONAL_2024] },
  { id: "afc-champions-league-2022-2023", cup: "afc", confederation: "AFC", from: 2022, to: 2023, name: "AFC Champions League", finalLegs: 2, sources: [RSSSF_ASIA, AFC_2003, NATIONAL_2024, ESPN_ELITE] },
  { id: "afc-champions-league-elite", cup: "afc", confederation: "AFC", from: 2024, to: null, name: "AFC Champions League Elite", finalLegs: 1, sources: [RSSSF_ASIA, AFC_SITE, AFC_ELITE_DEBUT, ESPN_ELITE] },
  { id: "african-cup-of-champions", cup: "caf", confederation: "CAF", from: 1900, to: 1996, name: "African Cup of Champions Clubs", finalLegs: 2, sources: [RSSSF_AFRICA, CAF_HISTORY, SUPERSPORT_CAF, SUPERSPORT_CAF_AZ] },
  { id: "caf-champions-league", cup: "caf", confederation: "CAF", from: 1997, to: 2018, name: "CAF Champions League", finalLegs: 2, sources: [RSSSF_AFRICA, CAF_HISTORY, SUPERSPORT_CAF, SUPERSPORT_CAF_AZ] },
  { id: "caf-champions-league-2019-2021", cup: "caf", confederation: "CAF", from: 2019, to: 2021, name: "CAF Champions League", finalLegs: 1, sources: [RSSSF_AFRICA, CAF_HISTORY, SUPERSPORT_CAF] },
  { id: "caf-champions-league-from-2022", cup: "caf", confederation: "CAF", from: 2022, to: null, name: "CAF Champions League", finalLegs: 2, sources: [RSSSF_AFRICA, CAF_HISTORY, SUPERSPORT_CAF, SUPERSPORT_CAF_AZ] }
];
function clubCupFor(country, year) {
  const confederation = clubConfederation(country);
  if (confederation === "UEFA") return { cup: "ucl", confederation, period: null };
  const period = CONTINENTAL_PERIODS.find((p) => p.confederation === confederation && year >= p.from && (p.to === null || year <= p.to));
  return period ? { cup: period.cup, confederation, period } : null;
}
var CONTINENTAL_LADDER = ["QF", "SF", "Final"];
function continentalOpponents(clubs, confederation, year, exclude) {
  return adjustClubsForYear(clubs, year).filter((c) => c.name !== exclude && clubConfederation(c.country) === confederation).filter((c) => !(c.country === "Australia" && year < 2007)).map((c) => c.name);
}
var LEAGUE_PHASE = { clubs: 36, games: 8, direct: 8, playoffTo: 24 };
var UCL_THREE_POINTS_FROM = 1995;
function ladderFor(entrants) {
  if (entrants >= 16) return ["R16", "QF", "SF", "Final"];
  if (entrants >= 8) return ["QF", "SF", "Final"];
  if (entrants >= 4) return ["SF", "Final"];
  return ["Final"];
}
function tiebreakFor(year) {
  if (year >= 2024) return "leaguePhase";
  if (year >= 2015 && year <= 2020) return "h2hFull";
  if (year >= 2005 && year <= 2010) return "h2hAway";
  return "leaguePhase";
}
function firstStageShape(year) {
  const period = periodFor(year);
  const pointsForWin = year >= UCL_THREE_POINTS_FROM ? 3 : 2;
  const tiebreak = tiebreakFor(year);
  if (period.stage === "leaguePhase") {
    return {
      kind: "leaguePhase",
      stages: 1,
      games: LEAGUE_PHASE.games,
      groups: 0,
      advance: "leaguePhase",
      ladder: ladderFor(16),
      pointsForWin,
      tiebreak,
      curve: "league"
    };
  }
  if (period.stage === "groups" && period.groups > 0) {
    if (period.koLegs === null) {
      return {
        kind: "groups",
        stages: 1,
        games: 6,
        groups: period.groups,
        advance: "winner",
        ladder: ladderFor(period.groups),
        pointsForWin,
        tiebreak,
        curve: "winner2"
      };
    }
    if (period.secondGroupStage) {
      return {
        kind: "groups",
        stages: 2,
        games: 6,
        groups: period.groups,
        advance: "top2",
        ladder: ladderFor(period.groups / 2 * 2),
        pointsForWin,
        tiebreak,
        curve: "twice_3"
      };
    }
    const both = period.groups * 2;
    const entrants = 2 ** Math.floor(Math.log2(both));
    if (entrants < both) {
      return {
        kind: "groups",
        stages: 1,
        games: 6,
        groups: period.groups,
        advance: "winnerOrBestRunnerUp",
        ladder: ladderFor(entrants),
        pointsForWin,
        tiebreak,
        curve: "best6_3"
      };
    }
    return {
      kind: "groups",
      stages: 1,
      games: 6,
      groups: period.groups,
      advance: "top2",
      ladder: ladderFor(entrants),
      pointsForWin,
      tiebreak,
      curve: pointsForWin === 2 ? "top2_2" : "top2_3"
    };
  }
  return {
    kind: "none",
    stages: 0,
    games: 0,
    groups: 0,
    advance: "top2",
    ladder: period.roundOf16 ? ladderFor(16) : ladderFor(8),
    pointsForWin,
    tiebreak,
    curve: null
  };
}
var UCL_BASE_LAMBDA = 1.32;
var UCL_HOME_EDGE = 0.18;
var OPPONENT_SPREAD = 0.8;
var clampTo = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
function poissonGoals(lambda, rng) {
  const L = Math.exp(-Math.max(0.05, lambda));
  let k = 0;
  let p = 1;
  do {
    k += 1;
    p *= rng();
  } while (p > L && k < 12);
  return k - 1;
}
function gauss(rng) {
  const u = 1 - rng();
  const v = rng();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}
function playMatch(sHome, sAway, rng) {
  const d = (sHome - sAway) / 2;
  const hg = poissonGoals(clampTo(UCL_BASE_LAMBDA + d + UCL_HOME_EDGE, 0.25, 3.4), rng);
  const ag = poissonGoals(clampTo(UCL_BASE_LAMBDA - d - UCL_HOME_EDGE, 0.25, 3.4), rng);
  return [hg, ag];
}
var GROUP_ROUNDS = [
  [[0, 1], [2, 3]],
  [[3, 0], [1, 2]],
  [[0, 2], [3, 1]],
  [[1, 0], [3, 2]],
  [[0, 3], [2, 1]],
  [[2, 0], [1, 3]]
];
var emptyRow = (club) => ({ club, w: 0, d: 0, l: 0, gf: 0, ga: 0, pts: 0 });
function record(rows, h, a, hg, ag, win) {
  const H = rows[h];
  const A = rows[a];
  H.gf += hg;
  H.ga += ag;
  A.gf += ag;
  A.ga += hg;
  if (hg > ag) {
    H.w += 1;
    A.l += 1;
    H.pts += win;
  } else if (hg < ag) {
    A.w += 1;
    H.l += 1;
    A.pts += win;
  } else {
    H.d += 1;
    A.d += 1;
    H.pts += 1;
    A.pts += 1;
  }
}
var POINTS_LINE = "Two points for a win in this table.";
var OWN_TIEBREAK_LINE = "Level on points splits on goal difference, then goals scored. That is this game's order: the real tiebreak for this season isn't in our records yet.";
function playGroup(names, strengths, shape, rng, playerGoals, label) {
  const rows = names.map(emptyRow);
  const pairs = {};
  const games = [];
  GROUP_ROUNDS.forEach((round, md) => {
    for (const [h, a] of round) {
      const [hg, ag] = playMatch(strengths[h], strengths[a], rng);
      record(rows, h, a, hg, ag, shape.pointsForWin);
      pairs[`${names[h]}|${names[a]}`] = [hg, ag];
      if (h === 0 || a === 0) {
        const home = h === 0;
        const goalsFor = home ? hg : ag;
        games.push({
          matchday: md + 1,
          opponent: names[home ? a : h],
          home,
          goalsFor,
          goalsAgainst: home ? ag : hg,
          playerGoals: Math.min(playerGoals(), goalsFor)
        });
      }
    }
  });
  const table = sortedUclGroupTable(rows, shape.tiebreak, pairs);
  const position = table.findIndex((r) => r.club === names[0]) + 1;
  const ruleLine = shape.tiebreak === "leaguePhase" ? OWN_TIEBREAK_LINE : uclGroupFootnote(rows, shape.tiebreak, pairs);
  const footnote = ruleLine + (shape.pointsForWin === 2 ? ` ${POINTS_LINE}` : "");
  return { label, games, position, of: 4, table, myRow: table[position - 1], footnote };
}
function bestRunnerUp(mine, shape, rng) {
  const others = [];
  for (let g = 1; g < shape.groups; g++) {
    const names = [0, 1, 2, 3].map((i) => `g${g}c${i}`);
    const strengths = names.map(() => gauss(rng) * OPPONENT_SPREAD);
    const stage = playGroup(names, strengths, { ...shape, tiebreak: "leaguePhase" }, rng, () => 0, "");
    others.push(stage.table[1]);
  }
  const key = (r) => [r.pts, r.gf - r.ga, r.gf];
  let better = 0;
  for (const o of others) {
    const a = key(o);
    const b = key(mine);
    let cmp = 0;
    for (let i = 0; i < 3 && cmp === 0; i++) cmp = a[i] - b[i];
    if (cmp > 0 || cmp === 0 && rng() < 0.5) better += 1;
  }
  const places = 2 ** Math.floor(Math.log2(shape.groups * 2)) - shape.groups;
  return better < places;
}
function playLeaguePhase(myName, oppNames, myStrength, shape, rng, playerGoals) {
  const n = LEAGUE_PHASE.clubs;
  const strengths = [myStrength];
  for (let i = 1; i < n; i++) strengths.push(gauss(rng) * OPPONENT_SPREAD);
  const ring = Array.from({ length: n }, (_, i) => i);
  for (let i = n - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [ring[i], ring[j]] = [ring[j], ring[i]];
  }
  const me = ring.indexOf(0);
  const half = LEAGUE_PHASE.games / 2;
  const names = Array.from({ length: n }, (_, i) => `lp${i}`);
  for (let k = 1; k <= half; k++) {
    names[ring[(me + k) % n]] = oppNames[2 * (k - 1)] ?? `lp${ring[(me + k) % n]}`;
    names[ring[(me - k + n) % n]] = oppNames[2 * (k - 1) + 1] ?? `lp${ring[(me - k + n) % n]}`;
  }
  names[0] = myName;
  const rows = names.map(emptyRow);
  const mine = /* @__PURE__ */ new Map();
  for (let p = 0; p < n; p++) {
    for (let k = 1; k <= half; k++) {
      const h = ring[p];
      const a = ring[(p + k) % n];
      const [hg, ag] = playMatch(strengths[h], strengths[a], rng);
      record(rows, h, a, hg, ag, shape.pointsForWin);
      if (h === 0) mine.set(k, [hg, ag]);
      if (a === 0) mine.set(-k, [hg, ag]);
    }
  }
  const games = [];
  for (let k = 1; k <= half; k++) {
    for (const side of [k, -k]) {
      const [hg, ag] = mine.get(side);
      const home = side > 0;
      const opp = ring[(me + side + n) % n];
      const goalsFor = home ? hg : ag;
      games.push({
        matchday: games.length + 1,
        opponent: names[opp],
        home,
        goalsFor,
        goalsAgainst: home ? ag : hg,
        playerGoals: Math.min(playerGoals(), goalsFor)
      });
    }
  }
  const table = sortedUclGroupTable(rows, "leaguePhase");
  const position = table.findIndex((r) => r.club === myName) + 1;
  return {
    label: "League phase",
    games,
    position,
    of: n,
    myRow: table[position - 1],
    cutoffs: { direct: table[LEAGUE_PHASE.direct - 1].pts, playoff: table[LEAGUE_PHASE.playoffTo - 1].pts },
    footnote: uclGroupFootnote(rows, "leaguePhase")
  };
}
function playFirstStage(shape, myName, myStrength, oppNames, rng, playerGoals = () => 0) {
  if (shape.kind === "leaguePhase") {
    const stage = playLeaguePhase(myName, oppNames, myStrength, shape, rng, playerGoals);
    const through2 = stage.position <= LEAGUE_PHASE.direct;
    const playoff = !through2 && stage.position <= LEAGUE_PHASE.playoffTo;
    return { kind: "leaguePhase", stages: [stage], through: through2, playoff };
  }
  const stages = [];
  let through = false;
  for (let s = 0; s < Math.max(1, shape.stages); s++) {
    const names = [myName, ...[0, 1, 2].map((i) => oppNames[s * 3 + i] ?? `Group club ${s * 3 + i + 1}`)];
    const strengths = [myStrength, ...[0, 1, 2].map(() => gauss(rng) * OPPONENT_SPREAD)];
    const stage = playGroup(names, strengths, shape, rng, playerGoals, s === 0 ? "Group stage" : "Second group stage");
    stages.push(stage);
    if (shape.advance === "winner") through = stage.position === 1;
    else if (shape.advance === "winnerOrBestRunnerUp") {
      through = stage.position === 1 || stage.position === 2 && bestRunnerUp(stage.myRow, shape, rng);
      if (stage.position === 2 && !through) stage.runnerUpOut = true;
    } else through = stage.position <= 2;
    if (!through) break;
  }
  return { kind: "groups", stages, through };
}
function isStageRow(x) {
  if (!x || typeof x !== "object") return false;
  const r = x;
  return typeof r.club === "string" && ["w", "d", "l", "gf", "ga", "pts"].every((k) => Number.isFinite(r[k]));
}
function isFirstStageResult(x) {
  if (!x || typeof x !== "object") return false;
  const r = x;
  if (r.kind !== "groups" && r.kind !== "leaguePhase" || typeof r.through !== "boolean" || !Array.isArray(r.stages)) return false;
  return r.stages.every((st) => !!st && typeof st === "object" && typeof st.label === "string" && typeof st.footnote === "string" && Number.isFinite(st.position) && Number.isFinite(st.of) && isStageRow(st.myRow) && (st.table === void 0 || Array.isArray(st.table) && st.table.every(isStageRow)) && Array.isArray(st.games) && st.games.every((g) => !!g && typeof g === "object" && typeof g.opponent === "string" && Number.isFinite(g.matchday) && Number.isFinite(g.goalsFor) && Number.isFinite(g.goalsAgainst)));
}
function firstStageOpponentCount(shape) {
  if (shape.kind === "leaguePhase") return LEAGUE_PHASE.games;
  return shape.kind === "groups" ? 3 * shape.stages : 0;
}
function uclProbit(p) {
  const a = [-39.69683028665376, 220.9460984245205, -275.9285104469687, 138.357751867269, -30.66479806614716, 2.506628277459239];
  const b = [-54.47609879822406, 161.5858368580409, -155.6989798598866, 66.80131188771972, -13.28068155288572];
  const c = [-0.007784894002430293, -0.3223964580411365, -2.400758277161838, -2.549732539343734, 4.374664141464968, 2.938163982698783];
  const d = [0.007784695709041462, 0.3224671290700398, 2.445134137142996, 3.754408661907416];
  const pl = 0.02425;
  const q = Math.min(Math.max(p, 1e-9), 1 - 1e-9);
  if (q < pl) {
    const x2 = Math.sqrt(-2 * Math.log(q));
    return (((((c[0] * x2 + c[1]) * x2 + c[2]) * x2 + c[3]) * x2 + c[4]) * x2 + c[5]) / ((((d[0] * x2 + d[1]) * x2 + d[2]) * x2 + d[3]) * x2 + 1);
  }
  if (q > 1 - pl) {
    const x2 = Math.sqrt(-2 * Math.log(1 - q));
    return -(((((c[0] * x2 + c[1]) * x2 + c[2]) * x2 + c[3]) * x2 + c[4]) * x2 + c[5]) / ((((d[0] * x2 + d[1]) * x2 + d[2]) * x2 + d[3]) * x2 + 1);
  }
  const x = q - 0.5;
  const r = x * x;
  return (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * x / (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1);
}
function normCdf(x) {
  const z = Math.abs(x) / Math.SQRT2;
  const t = 1 / (1 + 0.3275911 * z);
  const y = 1 - ((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-z * z);
  return x >= 0 ? (1 + y) / 2 : (1 - y) / 2;
}
var FIRST_STAGE_LIFT = 1;
var MAX_ENTRY = 0.98;
function firstStageTarget(knockoutTarget, reachKnockout) {
  return Math.min(0.97, Math.max(normCdf(uclProbit(knockoutTarget) + FIRST_STAGE_LIFT), reachKnockout / MAX_ENTRY));
}
var GRID_FROM = -1.5;
var GRID_STEP = 0.125;
var GRID_POINTS = 37;
var PASS_GRID = Array.from({ length: GRID_POINTS }, (_, i) => GRID_FROM + i * GRID_STEP);
var PASS_CURVES = {
  winner2: [63e-4, 95e-4, 0.0115, 0.0169, 0.0237, 0.034, 0.048, 0.0598, 0.078, 0.1012, 0.1285, 0.1633, 0.1905, 0.2314, 0.2729, 0.3189, 0.3694, 0.4182, 0.4688, 0.5158, 0.5605, 0.6217, 0.6683, 0.7107, 0.7459, 0.7769, 0.8158, 0.844, 0.8742, 0.8918, 0.9103, 0.9274, 0.9402, 0.9524, 0.9604, 0.9701, 0.9715],
  top2_2: [0.0511, 0.0641, 0.0862, 0.1072, 0.1358, 0.1691, 0.2086, 0.2436, 0.2884, 0.3432, 0.3972, 0.4477, 0.501, 0.5538, 0.6129, 0.6583, 0.7084, 0.7528, 0.7946, 0.8327, 0.8647, 0.8902, 0.9182, 0.9331, 0.9496, 0.9637, 0.9721, 0.9826, 0.9849, 0.9894, 0.9929, 0.9951, 0.996, 0.998, 0.9983, 0.9988, 0.9992],
  top2_3: [0.0562, 0.0706, 0.0896, 0.1155, 0.1413, 0.1772, 0.2117, 0.2591, 0.2964, 0.3396, 0.3911, 0.456, 0.4955, 0.5547, 0.6028, 0.6547, 0.7064, 0.745, 0.7873, 0.8331, 0.8542, 0.8809, 0.9105, 0.9275, 0.9473, 0.9619, 0.9683, 0.9773, 0.9841, 0.9885, 0.9917, 0.9939, 0.9954, 0.9974, 0.9977, 0.9987, 0.9993],
  best6_3: [0.0117, 0.0169, 0.0232, 0.0332, 0.0452, 0.0563, 0.0762, 0.0998, 0.1277, 0.158, 0.1983, 0.2412, 0.2841, 0.3325, 0.3876, 0.4434, 0.4899, 0.5508, 0.6095, 0.663, 0.7083, 0.7508, 0.7904, 0.836, 0.8576, 0.8833, 0.9132, 0.9311, 0.9443, 0.9595, 0.968, 0.9742, 0.9815, 0.9861, 0.9891, 0.9909, 0.9945],
  twice_3: [26e-4, 45e-4, 7e-3, 0.012, 0.0194, 0.029, 0.0433, 0.0629, 0.0844, 0.1157, 0.1544, 0.2028, 0.2522, 0.3085, 0.3645, 0.433, 0.5017, 0.5685, 0.6313, 0.6899, 0.7431, 0.7884, 0.8369, 0.8718, 0.8968, 0.924, 0.9411, 0.9578, 0.9708, 0.9782, 0.9855, 0.9886, 0.9911, 0.994, 0.9959, 0.9971, 0.9982],
  league: [0.0753, 0.1039, 0.141, 0.1756, 0.2283, 0.2868, 0.3396, 0.4102, 0.4769, 0.5498, 0.6142, 0.6806, 0.7397, 0.7905, 0.8387, 0.8817, 0.9101, 0.9365, 0.9548, 0.97, 0.9806, 0.9871, 0.9909, 0.9947, 0.9976, 0.9985, 0.9993, 0.9995, 0.9995, 0.9999, 0.9999, 1, 1, 1, 1, 1, 1]
};
var LEAGUE_TOP8 = [4e-4, 12e-4, 19e-4, 36e-4, 53e-4, 95e-4, 0.0137, 0.0226, 0.0328, 0.0493, 0.0665, 0.0938, 0.1288, 0.1697, 0.2161, 0.2692, 0.3297, 0.388, 0.4597, 0.522, 0.5988, 0.656, 0.7183, 0.7699, 0.8166, 0.8532, 0.8841, 0.9122, 0.9329, 0.9517, 0.9634, 0.9719, 0.9818, 0.986, 0.9896, 0.991, 0.9928];
function interp(row, s) {
  if (s <= PASS_GRID[0]) return row[0];
  const last = PASS_GRID.length - 1;
  if (s >= PASS_GRID[last]) return row[last];
  const i = Math.min(last - 1, Math.floor((s - GRID_FROM) / GRID_STEP));
  const f = (s - PASS_GRID[i]) / GRID_STEP;
  return row[i] + (row[i + 1] - row[i]) * f;
}
function stagePassChance(curve, s, playoffWin) {
  if (curve === "league") {
    const top8 = interp(LEAGUE_TOP8, s);
    return top8 + (interp(PASS_CURVES.league, s) - top8) * playoffWin;
  }
  return interp(PASS_CURVES[curve], s);
}
function solveStageStrength(curve, target, playoffWin) {
  let lo = PASS_GRID[0];
  let hi = PASS_GRID[PASS_GRID.length - 1];
  for (let i = 0; i < 40; i++) {
    const mid = (lo + hi) / 2;
    if (stagePassChance(curve, mid, playoffWin) < target) lo = mid;
    else hi = mid;
  }
  return (lo + hi) / 2;
}

// src/data/soccerCareerClubPool.ts
var CAREER_CLUB_POOL = [
  { id: "cm-bournemouth", name: "Bournemouth", country: "England", tier: 4, color: "#da291c", league: "Premier League" },
  { id: "cm-coventry-city", name: "Coventry City", country: "England", tier: 4, color: "#66b2e8", league: "Premier League" },
  { id: "cm-hull-city", name: "Hull City", country: "England", tier: 4, color: "#f5a12d", league: "Premier League" },
  { id: "cm-ipswich-town", name: "Ipswich Town", country: "England", tier: 4, color: "#2450a3", league: "Premier League" },
  { id: "cm-leeds-united", name: "Leeds United", country: "England", tier: 4, color: "#ffcd00", league: "Premier League" },
  { id: "cm-nottingham-forest", name: "Nottingham Forest", country: "England", tier: 2, color: "#dd0000", league: "Premier League" },
  { id: "cm-sunderland", name: "Sunderland", country: "England", tier: 4, color: "#eb172b", league: "Premier League" },
  { id: "cm-birmingham-city", name: "Birmingham City", country: "England", tier: 4, color: "#2966b0", league: "Championship" },
  { id: "cm-blackburn-rovers", name: "Blackburn Rovers", country: "England", tier: 4, color: "#009ee0", league: "Championship" },
  { id: "cm-bolton-wanderers", name: "Bolton Wanderers", country: "England", tier: 4, color: "#263c7e", league: "Championship" },
  { id: "cm-bristol-city", name: "Bristol City", country: "England", tier: 4, color: "#e21a23", league: "Championship" },
  { id: "cm-burnley", name: "Burnley", country: "England", tier: 4, color: "#8b2a4a", league: "Championship" },
  { id: "cm-cardiff-city", name: "Cardiff City", country: "Wales", tier: 4, color: "#0070b5", league: "Championship" },
  { id: "cm-charlton-athletic", name: "Charlton Athletic", country: "England", tier: 4, color: "#d4021d", league: "Championship" },
  { id: "cm-derby-county", name: "Derby County", country: "England", tier: 4, color: "#d8d8d8", league: "Championship" },
  { id: "cm-lincoln-city", name: "Lincoln City", country: "England", tier: 4, color: "#e30613", league: "Championship" },
  { id: "cm-middlesbrough", name: "Middlesbrough", country: "England", tier: 4, color: "#e21a23", league: "Championship" },
  { id: "cm-millwall", name: "Millwall", country: "England", tier: 4, color: "#25457a", league: "Championship" },
  { id: "cm-portsmouth", name: "Portsmouth", country: "England", tier: 4, color: "#2450a3", league: "Championship" },
  { id: "cm-preston-north-end", name: "Preston North End", country: "England", tier: 4, color: "#b9c4d1", league: "Championship" },
  { id: "cm-qpr", name: "QPR", country: "England", tier: 4, color: "#1d5ba4", league: "Championship" },
  { id: "cm-sheffield-united", name: "Sheffield United", country: "England", tier: 4, color: "#ee2737", league: "Championship" },
  { id: "cm-southampton", name: "Southampton", country: "England", tier: 4, color: "#d71920", league: "Championship" },
  { id: "cm-stoke-city", name: "Stoke City", country: "England", tier: 4, color: "#e03a3e", league: "Championship" },
  { id: "cm-swansea-city", name: "Swansea City", country: "Wales", tier: 4, color: "#c8c8c8", league: "Championship" },
  { id: "cm-watford", name: "Watford", country: "England", tier: 4, color: "#fbee23", league: "Championship" },
  { id: "cm-west-brom", name: "West Brom", country: "England", tier: 4, color: "#3a5da8", league: "Championship" },
  { id: "cm-wrexham", name: "Wrexham", country: "Wales", tier: 4, color: "#ce1126", league: "Championship" },
  { id: "cm-alaves", name: "Alaves", country: "Spain", tier: 4, color: "#0761af", league: "La Liga" },
  { id: "cm-deportivo", name: "Deportivo", country: "Spain", tier: 4, color: "#0068b3", league: "La Liga" },
  { id: "cm-elche", name: "Elche", country: "Spain", tier: 4, color: "#1a9349", league: "La Liga" },
  { id: "cm-espanyol", name: "Espanyol", country: "Spain", tier: 4, color: "#007fc8", league: "La Liga" },
  { id: "cm-getafe", name: "Getafe", country: "Spain", tier: 4, color: "#1265b3", league: "La Liga" },
  { id: "cm-levante", name: "Levante", country: "Spain", tier: 4, color: "#9c2743", league: "La Liga" },
  { id: "cm-malaga", name: "Malaga", country: "Spain", tier: 4, color: "#29a5dd", league: "La Liga" },
  { id: "cm-osasuna", name: "Osasuna", country: "Spain", tier: 4, color: "#d91a21", league: "La Liga" },
  { id: "cm-racing-santander", name: "Racing Santander", country: "Spain", tier: 4, color: "#009e49", league: "La Liga" },
  { id: "cm-rayo-vallecano", name: "Rayo Vallecano", country: "Spain", tier: 4, color: "#e53027", league: "La Liga" },
  { id: "cm-valencia", name: "Valencia", country: "Spain", tier: 4, color: "#ee7f24", league: "La Liga" },
  { id: "cm-athletico-paranaense", name: "Athletico Paranaense", country: "Brazil", tier: 4, color: "#c8102e", league: "Brasileirao" },
  { id: "cm-fluminense", name: "Fluminense", country: "Brazil", tier: 4, color: "#7a1e3a", league: "Brasileirao" },
  { id: "cm-bahia", name: "Bahia", country: "Brazil", tier: 4, color: "#0057b8", league: "Brasileirao" },
  { id: "cm-atletico-mineiro", name: "Atletico Mineiro", country: "Brazil", tier: 4, color: "#2b2b2b", league: "Brasileirao" },
  { id: "cm-coritiba", name: "Coritiba", country: "Brazil", tier: 4, color: "#0a7040", league: "Brasileirao" },
  { id: "cm-red-bull-bragantino", name: "Red Bull Bragantino", country: "Brazil", tier: 4, color: "#d9d9d9", league: "Brasileirao" },
  { id: "cm-vitoria", name: "Vitoria", country: "Brazil", tier: 4, color: "#d02128", league: "Brasileirao" },
  { id: "cm-mirassol", name: "Mirassol", country: "Brazil", tier: 4, color: "#f5d800", league: "Brasileirao" },
  { id: "cm-vasco-da-gama", name: "Vasco da Gama", country: "Brazil", tier: 4, color: "#2b2b2b", league: "Brasileirao" },
  { id: "cm-internacional", name: "Internacional", country: "Brazil", tier: 4, color: "#d02128", league: "Brasileirao" },
  { id: "cm-remo", name: "Remo", country: "Brazil", tier: 4, color: "#12294a", league: "Brasileirao" },
  { id: "cm-chapecoense", name: "Chapecoense", country: "Brazil", tier: 4, color: "#0a7040", league: "Brasileirao" }
];

// src/lib/soccerCareerLeague.ts
init_clubRivalries();

// src/data/careerLeagueSeasons.ts
var CAREER_LEAGUE_SEASONS = {
  "Premier League": {
    1990: { name: "First Division", size: 20, clubs: ["Arsenal", "Liverpool", "Crystal Palace", "Leeds United", "Man City", "Man United", "Nottingham Forest", "Everton", "Tottenham", "Chelsea", "QPR", "Sheffield United", "Southampton", "Norwich City", "Coventry City", "Aston Villa", "Sunderland", "Derby County"], others: ["wimbledon", "luton town"] },
    1991: { name: "First Division", size: 22, clubs: ["Leeds United", "Man United", "Arsenal", "Man City", "Liverpool", "Aston Villa", "Nottingham Forest", "Sheffield United", "Crystal Palace", "QPR", "Everton", "Chelsea", "Tottenham", "Southampton", "Norwich City", "Coventry City", "West Ham"], others: ["sheffield wednesday", "wimbledon", "oldham athletic", "luton town", "notts county"] },
    1992: { name: "Premier League", size: 22, clubs: ["Man United", "Aston Villa", "Norwich City", "Blackburn Rovers", "QPR", "Liverpool", "Tottenham", "Man City", "Arsenal", "Chelsea", "Everton", "Sheffield United", "Coventry City", "Ipswich Town", "Leeds United", "Southampton", "Crystal Palace", "Middlesbrough", "Nottingham Forest"], others: ["sheffield wednesday", "wimbledon", "oldham athletic"] },
    1993: { name: "Premier League", size: 22, clubs: ["Man United", "Blackburn Rovers", "Newcastle", "Arsenal", "Leeds United", "Liverpool", "QPR", "Aston Villa", "Coventry City", "Norwich City", "West Ham", "Chelsea", "Tottenham", "Man City", "Everton", "Southampton", "Ipswich Town", "Sheffield United"], others: ["wimbledon", "sheffield wednesday", "oldham athletic", "swindon town"] },
    1994: { name: "Premier League", size: 22, clubs: ["Blackburn Rovers", "Man United", "Nottingham Forest", "Liverpool", "Leeds United", "Newcastle", "Tottenham", "QPR", "Southampton", "Chelsea", "Arsenal", "West Ham", "Everton", "Coventry City", "Man City", "Aston Villa", "Crystal Palace", "Norwich City", "Ipswich Town"], others: ["wimbledon", "sheffield wednesday", "leicester city"] },
    1995: { name: "Premier League", size: 20, clubs: ["Man United", "Newcastle", "Liverpool", "Aston Villa", "Arsenal", "Everton", "Blackburn Rovers", "Tottenham", "Nottingham Forest", "West Ham", "Chelsea", "Middlesbrough", "Leeds United", "Coventry City", "Southampton", "Man City", "QPR", "Bolton Wanderers"], others: ["wimbledon", "sheffield wednesday"] },
    1996: { name: "Premier League", size: 20, clubs: ["Man United", "Newcastle", "Arsenal", "Liverpool", "Aston Villa", "Chelsea", "Tottenham", "Leeds United", "Derby County", "Blackburn Rovers", "West Ham", "Everton", "Southampton", "Coventry City", "Sunderland", "Middlesbrough", "Nottingham Forest"], others: ["sheffield wednesday", "wimbledon", "leicester city"] },
    1997: { name: "Premier League", size: 20, clubs: ["Arsenal", "Man United", "Liverpool", "Chelsea", "Leeds United", "Blackburn Rovers", "Aston Villa", "West Ham", "Derby County", "Coventry City", "Southampton", "Newcastle", "Tottenham", "Everton", "Bolton Wanderers", "Crystal Palace"], others: ["leicester city", "wimbledon", "sheffield wednesday", "barnsley"] },
    1998: { name: "Premier League", size: 20, clubs: ["Man United", "Arsenal", "Chelsea", "Leeds United", "West Ham", "Aston Villa", "Liverpool", "Derby County", "Middlesbrough", "Tottenham", "Newcastle", "Everton", "Coventry City", "Southampton", "Charlton Athletic", "Blackburn Rovers", "Nottingham Forest"], others: ["leicester city", "sheffield wednesday", "wimbledon"] },
    1999: { name: "Premier League", size: 20, clubs: ["Man United", "Arsenal", "Leeds United", "Liverpool", "Chelsea", "Aston Villa", "Sunderland", "West Ham", "Tottenham", "Newcastle", "Middlesbrough", "Everton", "Coventry City", "Southampton", "Derby County", "Watford"], others: ["leicester city", "bradford city", "wimbledon", "sheffield wednesday"] },
    2e3: { name: "Premier League", size: 20, clubs: ["Man United", "Arsenal", "Liverpool", "Leeds United", "Ipswich Town", "Chelsea", "Sunderland", "Aston Villa", "Charlton Athletic", "Southampton", "Newcastle", "Tottenham", "Middlesbrough", "West Ham", "Everton", "Derby County", "Man City", "Coventry City"], others: ["leicester city", "bradford city"] },
    2001: { name: "Premier League", size: 20, clubs: ["Arsenal", "Liverpool", "Man United", "Newcastle", "Leeds United", "Chelsea", "West Ham", "Aston Villa", "Tottenham", "Blackburn Rovers", "Southampton", "Middlesbrough", "Fulham", "Charlton Athletic", "Everton", "Bolton Wanderers", "Sunderland", "Ipswich Town", "Derby County"], others: ["leicester city"] },
    2002: { name: "Premier League", size: 20, clubs: ["Man United", "Arsenal", "Newcastle", "Chelsea", "Liverpool", "Blackburn Rovers", "Everton", "Southampton", "Man City", "Tottenham", "Middlesbrough", "Charlton Athletic", "Birmingham City", "Fulham", "Leeds United", "Aston Villa", "Bolton Wanderers", "West Ham", "West Brom", "Sunderland"], others: [] },
    2003: { name: "Premier League", size: 20, clubs: ["Arsenal", "Chelsea", "Man United", "Liverpool", "Newcastle", "Aston Villa", "Charlton Athletic", "Bolton Wanderers", "Fulham", "Birmingham City", "Middlesbrough", "Southampton", "Portsmouth", "Tottenham", "Blackburn Rovers", "Man City", "Everton", "Leeds United", "Wolves"], others: ["leicester city"] },
    2004: { name: "Premier League", size: 20, clubs: ["Chelsea", "Arsenal", "Man United", "Everton", "Liverpool", "Bolton Wanderers", "Middlesbrough", "Man City", "Tottenham", "Aston Villa", "Charlton Athletic", "Birmingham City", "Fulham", "Newcastle", "Blackburn Rovers", "Portsmouth", "West Brom", "Crystal Palace", "Norwich City", "Southampton"], others: [] },
    2005: { name: "Premier League", size: 20, clubs: ["Chelsea", "Man United", "Liverpool", "Arsenal", "Tottenham", "Blackburn Rovers", "Newcastle", "Bolton Wanderers", "West Ham", "Everton", "Fulham", "Charlton Athletic", "Middlesbrough", "Man City", "Aston Villa", "Portsmouth", "Birmingham City", "West Brom", "Sunderland"], others: ["wigan athleitc|wigan athletic"] },
    2006: { name: "Premier League", size: 20, clubs: ["Man United", "Chelsea", "Liverpool", "Arsenal", "Tottenham", "Everton", "Bolton Wanderers", "Portsmouth", "Blackburn Rovers", "Aston Villa", "Middlesbrough", "Newcastle", "Man City", "West Ham", "Fulham", "Sheffield United", "Charlton Athletic", "Watford"], others: ["reading", "wigan athletic"] },
    2007: { name: "Premier League", size: 20, clubs: ["Man United", "Chelsea", "Arsenal", "Liverpool", "Everton", "Aston Villa", "Blackburn Rovers", "Portsmouth", "Man City", "West Ham", "Tottenham", "Newcastle", "Middlesbrough", "Sunderland", "Bolton Wanderers", "Fulham", "Birmingham City", "Derby County"], others: ["wigan athletic", "reading"] },
    2008: { name: "Premier League", size: 20, clubs: ["Man United", "Liverpool", "Chelsea", "Arsenal", "Everton", "Aston Villa", "Fulham", "Tottenham", "West Ham", "Man City", "Stoke City", "Bolton Wanderers", "Portsmouth", "Blackburn Rovers", "Sunderland", "Hull City", "Newcastle", "Middlesbrough", "West Brom"], others: ["wigan athletic"] },
    2009: { name: "Premier League", size: 20, clubs: ["Chelsea", "Man United", "Arsenal", "Tottenham", "Man City", "Aston Villa", "Liverpool", "Everton", "Birmingham City", "Blackburn Rovers", "Stoke City", "Fulham", "Sunderland", "Bolton Wanderers", "Wolves", "West Ham", "Burnley", "Hull City", "Portsmouth"], others: ["wigan athletic"] },
    2010: { name: "Premier League", size: 20, clubs: ["Man United", "Chelsea", "Man City", "Arsenal", "Tottenham", "Liverpool", "Everton", "Fulham", "Aston Villa", "Sunderland", "West Brom", "Newcastle", "Stoke City", "Bolton Wanderers", "Blackburn Rovers", "Wolves", "Birmingham City", "West Ham"], others: ["wigan athletic", "blackpool"] },
    2011: { name: "Premier League", size: 20, clubs: ["Man City", "Man United", "Arsenal", "Tottenham", "Newcastle", "Chelsea", "Everton", "Liverpool", "Fulham", "West Brom", "Swansea City", "Norwich City", "Sunderland", "Stoke City", "Aston Villa", "QPR", "Bolton Wanderers", "Blackburn Rovers", "Wolves"], others: ["wigan athletic"] },
    2012: { name: "Premier League", size: 20, clubs: ["Man United", "Man City", "Chelsea", "Arsenal", "Tottenham", "Everton", "Liverpool", "West Brom", "Swansea City", "West Ham", "Norwich City", "Fulham", "Stoke City", "Southampton", "Aston Villa", "Newcastle", "Sunderland", "QPR"], others: ["wigan athletic", "reading"] },
    2013: { name: "Premier League", size: 20, clubs: ["Man City", "Liverpool", "Chelsea", "Arsenal", "Everton", "Tottenham", "Man United", "Southampton", "Stoke City", "Newcastle", "Crystal Palace", "Swansea City", "West Ham", "Sunderland", "Aston Villa", "Hull City", "West Brom", "Norwich City", "Fulham", "Cardiff City"], others: [] },
    2014: { name: "Premier League", size: 20, clubs: ["Chelsea", "Man City", "Arsenal", "Man United", "Tottenham", "Liverpool", "Southampton", "Swansea City", "Stoke City", "Crystal Palace", "Everton", "West Ham", "West Brom", "Newcastle", "Sunderland", "Aston Villa", "Hull City", "Burnley", "QPR"], others: ["leicester city"] },
    2015: { name: "Premier League", size: 20, clubs: ["Arsenal", "Tottenham", "Man City", "Man United", "Southampton", "West Ham", "Liverpool", "Stoke City", "Chelsea", "Everton", "Swansea City", "Watford", "West Brom", "Crystal Palace", "Bournemouth", "Sunderland", "Newcastle", "Norwich City", "Aston Villa"], others: ["leicester city"] },
    2016: { name: "Premier League", size: 20, clubs: ["Chelsea", "Tottenham", "Man City", "Liverpool", "Arsenal", "Man United", "Everton", "Southampton", "Bournemouth", "West Brom", "West Ham", "Stoke City", "Crystal Palace", "Swansea City", "Burnley", "Watford", "Hull City", "Middlesbrough", "Sunderland"], others: ["leicester city"] },
    2017: { name: "Premier League", size: 20, clubs: ["Man City", "Man United", "Tottenham", "Liverpool", "Chelsea", "Arsenal", "Burnley", "Everton", "Newcastle", "Crystal Palace", "Bournemouth", "West Ham", "Watford", "Brighton", "Southampton", "Swansea City", "Stoke City", "West Brom"], others: ["leicester city", "huddersfield town"] },
    2018: { name: "Premier League", size: 20, clubs: ["Man City", "Liverpool", "Chelsea", "Tottenham", "Arsenal", "Man United", "Wolves", "Everton", "West Ham", "Watford", "Crystal Palace", "Newcastle", "Bournemouth", "Burnley", "Southampton", "Brighton", "Cardiff City", "Fulham"], others: ["leicester city", "huddersfield town"] },
    2019: { name: "Premier League", size: 20, clubs: ["Liverpool", "Man City", "Man United", "Chelsea", "Tottenham", "Wolves", "Arsenal", "Sheffield United", "Burnley", "Southampton", "Everton", "Newcastle", "Crystal Palace", "Brighton", "West Ham", "Aston Villa", "Bournemouth", "Watford", "Norwich City"], others: ["leicester city"] },
    2020: { name: "Premier League", size: 20, clubs: ["Man City", "Man United", "Liverpool", "Chelsea", "West Ham", "Tottenham", "Arsenal", "Leeds United", "Everton", "Aston Villa", "Newcastle", "Wolves", "Crystal Palace", "Southampton", "Brighton", "Burnley", "Fulham", "West Brom", "Sheffield United"], others: ["leicester city"] },
    2021: { name: "Premier League", size: 20, clubs: ["Man City", "Liverpool", "Chelsea", "Tottenham", "Arsenal", "Man United", "West Ham", "Brighton", "Wolves", "Newcastle", "Crystal Palace", "Brentford", "Aston Villa", "Southampton", "Everton", "Leeds United", "Burnley", "Watford", "Norwich City"], others: ["leicester city"] },
    2022: { name: "Premier League", size: 20, clubs: ["Man City", "Arsenal", "Man United", "Newcastle", "Liverpool", "Brighton", "Aston Villa", "Tottenham", "Brentford", "Fulham", "Crystal Palace", "Chelsea", "Wolves", "West Ham", "Bournemouth", "Nottingham Forest", "Everton", "Leeds United", "Southampton"], others: ["leicester city"] },
    2023: { name: "Premier League", size: 20, clubs: ["Man City", "Arsenal", "Liverpool", "Aston Villa", "Tottenham", "Chelsea", "Newcastle", "Man United", "West Ham", "Crystal Palace", "Brighton", "Bournemouth", "Fulham", "Wolves", "Everton", "Brentford", "Nottingham Forest", "Burnley", "Sheffield United"], others: ["luton town"] },
    2024: { name: "Premier League", size: 20, clubs: ["Liverpool", "Arsenal", "Man City", "Chelsea", "Newcastle", "Aston Villa", "Nottingham Forest", "Brighton", "Bournemouth", "Brentford", "Fulham", "Crystal Palace", "Everton", "West Ham", "Man United", "Wolves", "Tottenham", "Ipswich Town", "Southampton"], others: ["leicester city"] },
    2025: { name: "Premier League", size: 20, clubs: ["Arsenal", "Man City", "Man United", "Aston Villa", "Liverpool", "Bournemouth", "Sunderland", "Brighton", "Brentford", "Chelsea", "Fulham", "Newcastle", "Everton", "Leeds United", "Crystal Palace", "Nottingham Forest", "Tottenham", "West Ham", "Burnley", "Wolves"], others: [] }
  },
  "Championship": {
    1990: { name: "Second Division", size: 24, clubs: ["West Ham", "Millwall", "Brighton", "Middlesbrough", "Bristol City", "Newcastle", "Wolves", "Ipswich Town", "Charlton Athletic", "Portsmouth", "Blackburn Rovers", "Watford", "West Brom", "Hull City"], others: ["oldham athletic", "sheffield wednesday", "notts county", "barnsley", "oxford united", "bristol rovers", "port vale", "plymouth argyle", "swindon town", "leicester city"] },
    1991: { name: "Second Division", size: 24, clubs: ["Ipswich Town", "Middlesbrough", "Derby County", "Blackburn Rovers", "Charlton Athletic", "Portsmouth", "Watford", "Wolves", "Millwall", "Bristol City", "Sunderland", "Newcastle", "Brighton"], others: ["leicester city", "cambridge united", "swindon town", "southend united", "bristol rovers", "tranmere rovers", "barnsley", "grimsby town", "oxford united", "plymouth argyle", "port vale"] },
    1992: { name: "First Division", size: 24, clubs: ["Newcastle", "West Ham", "Portsmouth", "Millwall", "Derby County", "Wolves", "Charlton Athletic", "Bristol City", "Watford", "Birmingham City", "Sunderland", "Brentford"], others: ["tranmere rovers", "swindon town", "leicester city", "grimsby town", "peterborough united", "barnsley", "oxford united", "notts county", "southend united", "luton town", "cambridge united", "bristol rovers"] },
    1993: { name: "First Division", size: 24, clubs: ["Crystal Palace", "Nottingham Forest", "Millwall", "Derby County", "Wolves", "Middlesbrough", "Stoke City", "Charlton Athletic", "Sunderland", "Bristol City", "Bolton Wanderers", "Portsmouth", "Watford", "West Brom", "Birmingham City"], others: ["leicester city", "tranmere rovers", "notts county", "southend united", "grimsby town", "barnsley", "luton town", "oxford united", "peterborough united"] },
    1994: { name: "First Division", size: 24, clubs: ["Middlesbrough", "Bolton Wanderers", "Wolves", "Watford", "Sheffield United", "Derby County", "Stoke City", "Millwall", "Charlton Athletic", "Portsmouth", "West Brom", "Sunderland", "Burnley", "Bristol City"], others: ["reading", "tranmere rovers", "barnsley", "grimsby town", "southend united", "oldham athletic", "luton town", "port vale", "swindon town", "notts county"] },
    1995: { name: "First Division", size: 24, clubs: ["Sunderland", "Derby County", "Crystal Palace", "Stoke City", "Charlton Athletic", "Ipswich Town", "Sheffield United", "West Brom", "Birmingham City", "Norwich City", "Wolves", "Portsmouth", "Millwall", "Watford"], others: ["leicester city", "huddersfield town", "barnsley", "port vale", "tranmere rovers", "southend united", "grimsby town", "oldham athletic", "reading", "luton town"] },
    1996: { name: "First Division", size: 24, clubs: ["Bolton Wanderers", "Wolves", "Ipswich Town", "Sheffield United", "Crystal Palace", "Portsmouth", "QPR", "Birmingham City", "Stoke City", "Norwich City", "Man City", "Charlton Athletic", "West Brom"], others: ["barnsley", "port vale", "tranmere rovers", "oxford united", "reading", "swindon town", "huddersfield town", "bradford city", "grimsby town", "oldham athletic", "southend united"] },
    1997: { name: "First Division", size: 24, clubs: ["Nottingham Forest", "Middlesbrough", "Sunderland", "Charlton Athletic", "Ipswich Town", "Sheffield United", "Birmingham City", "Wolves", "West Brom", "Norwich City", "Portsmouth", "QPR", "Man City", "Stoke City"], others: ["stockport county", "crewe alexandra", "oxford united", "bradford city", "tranmere rovers", "huddersfield town", "bury", "swindon town", "port vale", "reading"] },
    1998: { name: "First Division", size: 24, clubs: ["Sunderland", "Ipswich Town", "Birmingham City", "Watford", "Bolton Wanderers", "Wolves", "Sheffield United", "Norwich City", "West Brom", "Crystal Palace", "Portsmouth", "QPR", "Bristol City"], others: ["bradford city", "huddersfield town", "grimsby town", "barnsley", "tranmere rovers", "stockport county", "swindon town", "crewe alexandra", "port vale", "bury", "oxford united"] },
    1999: { name: "First Division", size: 24, clubs: ["Charlton Athletic", "Man City", "Ipswich Town", "Birmingham City", "Bolton Wanderers", "Wolves", "Fulham", "QPR", "Blackburn Rovers", "Norwich City", "Nottingham Forest", "Crystal Palace", "Sheffield United", "Portsmouth", "West Brom"], others: ["barnsley", "huddersfield town", "tranmere rovers", "stockport county", "crewe alexandra", "grimsby town", "walsall", "port vale", "swindon town"] },
    2e3: { name: "First Division", size: 24, clubs: ["Fulham", "Blackburn Rovers", "Bolton Wanderers", "Preston North End", "Birmingham City", "West Brom", "Burnley", "Watford", "Sheffield United", "Nottingham Forest", "Wolves", "Norwich City", "Portsmouth", "Crystal Palace", "QPR"], others: ["wimbledon", "gillingham", "crewe alexandra", "barnsley", "sheffield wednesday", "grimsby town", "stockport county", "huddersfield town", "tranmere rovers"] },
    2001: { name: "First Division", size: 24, clubs: ["Man City", "West Brom", "Wolves", "Millwall", "Birmingham City", "Norwich City", "Burnley", "Preston North End", "Crystal Palace", "Coventry City", "Sheffield United", "Watford", "Nottingham Forest", "Portsmouth"], others: ["wimbledon", "gillingham", "bradford city", "walsall", "grimsby town", "sheffield wednesday", "rotherham united", "crewe alexandra", "barnsley", "stockport county"] },
    2002: { name: "First Division", size: 24, clubs: ["Portsmouth", "Sheffield United", "Wolves", "Nottingham Forest", "Ipswich Town", "Norwich City", "Millwall", "Preston North End", "Watford", "Crystal Palace", "Burnley", "Derby County", "Coventry City", "Stoke City", "Brighton"], others: ["leicester city", "reading", "wimbledon|milton keynes dons", "gillingham", "rotherham united", "walsall", "bradford city", "sheffield wedsnesday|sheffield wednesday", "grimsby town"] },
    2003: { name: "First Division", size: 24, clubs: ["Norwich City", "West Brom", "Sunderland", "West Ham", "Ipswich Town", "Crystal Palace", "Sheffield United", "Millwall", "Stoke City", "Coventry City", "Cardiff City", "Nottingham Forest", "Preston North End", "Watford", "Burnley", "Derby County"], others: ["wigan athletic", "reading", "rotherham united", "crewe alexandra", "gillingham", "walsall", "bradford city", "wimbledon|milton keynes dons"] },
    2004: { name: "Championship", size: 24, clubs: ["Sunderland", "Ipswich Town", "Derby County", "Preston North End", "West Ham", "Sheffield United", "Wolves", "Millwall", "QPR", "Stoke City", "Burnley", "Leeds United", "Cardiff City", "Watford", "Coventry City", "Brighton", "Nottingham Forest"], others: ["wigan athletic", "reading", "leicester city", "plymouth argyle", "crewe alexandra", "gillingham", "rotherham united"] },
    2005: { name: "Championship", size: 24, clubs: ["Sheffield United", "Watford", "Preston North End", "Leeds United", "Crystal Palace", "Wolves", "Coventry City", "Norwich City", "Cardiff City", "Southampton", "Stoke City", "Ipswich Town", "Burnley", "Hull City", "Derby County", "QPR", "Millwall", "Brighton"], others: ["reading", "luton town", "plymouth argyle", "leicester city", "sheffield wednesday", "crewe alexandra"] },
    2006: { name: "Championship", size: 24, clubs: ["Sunderland", "Birmingham City", "Derby County", "West Brom", "Wolves", "Southampton", "Preston North End", "Stoke City", "Crystal Palace", "Cardiff City", "Ipswich Town", "Burnley", "Norwich City", "Coventry City", "QPR", "Hull City", "Leeds United"], others: ["sheffield wednesday", "colchester united", "plymouth argyle", "leicester city", "barnsley", "southend united", "luton town"] },
    2007: { name: "Championship", size: 24, clubs: ["West Brom", "Stoke City", "Hull City", "Bristol City", "Crystal Palace", "Watford", "Wolves", "Ipswich Town", "Sheffield United", "Charlton Athletic", "Cardiff City", "Burnley", "QPR", "Preston North End", "Norwich City", "Southampton", "Coventry City"], others: ["plymouth argyle", "sheffield wednesday", "barnsley", "blackpool", "leicester city", "scunthorpe united", "colchester united"] },
    2008: { name: "Championship", size: 24, clubs: ["Wolves", "Birmingham City", "Sheffield United", "Burnley", "Preston North End", "Cardiff City", "Swansea City", "Ipswich Town", "Bristol City", "QPR", "Watford", "Crystal Palace", "Coventry City", "Derby County", "Nottingham Forest", "Norwich City", "Southampton", "Charlton Athletic"], others: ["reading", "sheffield wednesday", "doncaster rovers", "blackpool", "barnsley", "plymouth argyle"] },
    2009: { name: "Championship", size: 24, clubs: ["Newcastle", "West Brom", "Nottingham Forest", "Cardiff City", "Swansea City", "Sheffield United", "Bristol City", "Middlesbrough", "QPR", "Derby County", "Ipswich Town", "Watford", "Preston North End", "Coventry City", "Crystal Palace"], others: ["leicester city", "blackpool", "reading", "doncaster rovers", "barnsley", "scunthorpe united", "sheffield wednesday", "plymouth argyle", "peterborough united"] },
    2010: { name: "Championship", size: 24, clubs: ["QPR", "Norwich City", "Swansea City", "Cardiff City", "Nottingham Forest", "Leeds United", "Burnley", "Millwall", "Hull City", "Middlesbrough", "Ipswich Town", "Watford", "Bristol City", "Portsmouth", "Coventry City", "Derby County", "Crystal Palace", "Preston North End", "Sheffield United"], others: ["reading", "leicester city", "barnsley", "doncaster rovers", "scunthorpe united"] },
    2011: { name: "Championship", size: 24, clubs: ["Southampton", "West Ham", "Birmingham City", "Cardiff City", "Middlesbrough", "Hull City", "Brighton", "Watford", "Derby County", "Burnley", "Leeds United", "Ipswich Town", "Millwall", "Crystal Palace", "Nottingham Forest", "Bristol City", "Portsmouth", "Coventry City"], others: ["reading", "blackpool", "leicester city", "peterborough united", "barnsley", "doncaster rovers"] },
    2012: { name: "Championship", size: 24, clubs: ["Cardiff City", "Hull City", "Watford", "Brighton", "Crystal Palace", "Bolton Wanderers", "Nottingham Forest", "Charlton Athletic", "Derby County", "Burnley", "Birmingham City", "Leeds United", "Ipswich Town", "Middlesbrough", "Blackburn Rovers", "Millwall", "Wolves", "Bristol City"], others: ["leicester city", "blackpool", "sheffield wednesday", "huddersfield town", "barnsley", "peterborough united"] },
    2013: { name: "Championship", size: 24, clubs: ["Burnley", "Derby County", "QPR", "Brighton", "Blackburn Rovers", "Ipswich Town", "Bournemouth", "Nottingham Forest", "Middlesbrough", "Watford", "Bolton Wanderers", "Leeds United", "Charlton Athletic", "Millwall", "Birmingham City"], others: ["leicester city", "wigan athletic", "reading", "sheffield wednesday", "huddersfield town", "blackpool", "doncaster rovers", "barnsley", "yeovil town"] },
    2014: { name: "Championship", size: 24, clubs: ["Bournemouth", "Watford", "Norwich City", "Middlesbrough", "Brentford", "Ipswich Town", "Wolves", "Derby County", "Blackburn Rovers", "Birmingham City", "Cardiff City", "Charlton Athletic", "Nottingham Forest", "Leeds United", "Fulham", "Bolton Wanderers", "Brighton", "Millwall"], others: ["sheffield wednesday", "huddersfield town", "reading", "rotherham united", "wigan athletic", "blackpool"] },
    2015: { name: "Championship", size: 24, clubs: ["Burnley", "Middlesbrough", "Brighton", "Hull City", "Derby County", "Ipswich Town", "Cardiff City", "Brentford", "Birmingham City", "Preston North End", "QPR", "Leeds United", "Wolves", "Blackburn Rovers", "Nottingham Forest", "Bristol City", "Fulham", "Charlton Athletic", "Bolton Wanderers"], others: ["sheffield wednesday", "reading", "huddersfield town", "rotherham united", "milton keynes dons"] },
    2016: { name: "Championship", size: 24, clubs: ["Newcastle", "Brighton", "Fulham", "Leeds United", "Norwich City", "Derby County", "Brentford", "Preston North End", "Cardiff City", "Aston Villa", "Wolves", "Ipswich Town", "Bristol City", "QPR", "Birmingham City", "Nottingham Forest", "Blackburn Rovers"], others: ["reading", "sheffield wednesday", "huddersfield town", "barnsley", "burton albion", "wigan athletic", "rotherham united"] },
    2017: { name: "Championship", size: 24, clubs: ["Wolves", "Cardiff City", "Fulham", "Aston Villa", "Middlesbrough", "Derby County", "Preston North End", "Millwall", "Brentford", "Sheffield United", "Bristol City", "Ipswich Town", "Leeds United", "Norwich City", "QPR", "Nottingham Forest", "Hull City", "Birmingham City", "Bolton Wanderers", "Sunderland"], others: ["sheffield wednesday", "reading", "barnsley", "burton albion"] },
    2018: { name: "Championship", size: 24, clubs: ["Norwich City", "Sheffield United", "Leeds United", "West Brom", "Aston Villa", "Derby County", "Middlesbrough", "Bristol City", "Nottingham Forest", "Swansea City", "Brentford", "Hull City", "Preston North End", "Blackburn Rovers", "Stoke City", "Birmingham City", "QPR", "Millwall", "Bolton Wanderers", "Ipswich Town"], others: ["sheffield wednesday", "wigan athletic", "reading", "rotherham united"] },
    2019: { name: "Championship", size: 24, clubs: ["Leeds United", "West Brom", "Brentford", "Fulham", "Cardiff City", "Swansea City", "Nottingham Forest", "Millwall", "Preston North End", "Derby County", "Blackburn Rovers", "Bristol City", "QPR", "Stoke City", "Middlesbrough", "Birmingham City", "Charlton Athletic", "Hull City"], others: ["reading", "sheffield wednesday", "huddersfield town", "luton town", "barnsley", "wigan athletic"] },
    2020: { name: "Championship", size: 24, clubs: ["Norwich City", "Watford", "Brentford", "Swansea City", "Bournemouth", "Cardiff City", "QPR", "Middlesbrough", "Millwall", "Preston North End", "Stoke City", "Blackburn Rovers", "Coventry City", "Nottingham Forest", "Birmingham City", "Bristol City", "Derby County"], others: ["barnsley", "reading", "luton town", "huddersfield town", "wycombe wanderers", "rotherham united", "sheffield wednesday"] },
    2021: { name: "Championship", size: 24, clubs: ["Fulham", "Bournemouth", "Nottingham Forest", "Sheffield United", "Middlesbrough", "Blackburn Rovers", "Millwall", "West Brom", "QPR", "Coventry City", "Preston North End", "Stoke City", "Swansea City", "Bristol City", "Cardiff City", "Hull City", "Birmingham City", "Derby County"], others: ["huddersfield town", "luton town", "blackpool", "reading", "peterborough united", "barnsley"] },
    2022: { name: "Championship", size: 24, clubs: ["Burnley", "Sheffield United", "Middlesbrough", "Coventry City", "Sunderland", "Blackburn Rovers", "Millwall", "West Brom", "Swansea City", "Watford", "Preston North End", "Norwich City", "Bristol City", "Hull City", "Stoke City", "Birmingham City", "QPR", "Cardiff City"], others: ["luton town", "huddersfield town", "rotherham united", "reading", "blackpool", "wigan athletic"] },
    2023: { name: "Championship", size: 24, clubs: ["Ipswich Town", "Leeds United", "Southampton", "West Brom", "Norwich City", "Hull City", "Middlesbrough", "Coventry City", "Preston North End", "Bristol City", "Cardiff City", "Millwall", "Swansea City", "Watford", "Sunderland", "Stoke City", "QPR", "Blackburn Rovers", "Birmingham City"], others: ["leicester city", "sheffield wednesday", "plymouth argyle", "huddersfield town", "rotherham united"] },
    2024: { name: "Championship", size: 24, clubs: ["Leeds United", "Burnley", "Sheffield United", "Sunderland", "Coventry City", "Bristol City", "Blackburn Rovers", "Millwall", "West Brom", "Middlesbrough", "Swansea City", "Norwich City", "Watford", "QPR", "Portsmouth", "Stoke City", "Derby County", "Preston North End", "Hull City", "Cardiff City"], others: ["sheffield wednesday", "oxford united", "luton town", "plymouth argyle"] },
    2025: { name: "Championship", size: 24, clubs: ["Coventry City", "Ipswich Town", "Millwall", "Southampton", "Middlesbrough", "Hull City", "Wrexham", "Derby County", "Norwich City", "Birmingham City", "Swansea City", "Bristol City", "Sheffield United", "Preston North End", "QPR", "Watford", "Stoke City", "Portsmouth", "Charlton Athletic", "Blackburn Rovers", "West Brom"], others: ["oxford united", "leicester city", "sheffield wednesday"] }
  },
  "La Liga": {
    1990: { name: "La Liga", size: 20, clubs: ["Barcelona", "Atletico Madrid", "Real Madrid", "Osasuna", "Valencia", "Sevilla", "Athletic Bilbao", "Real Sociedad", "Espanyol", "Real Betis"], others: ["sporting de gijon|sporting gijon", "real oviedo", "real valladolid", "logrones", "real burgos|burgos", "tenerife", "mallorca", "real zaragoza", "cadiz", "castellon"] },
    1991: { name: "La Liga", size: 20, clubs: ["Barcelona", "Real Madrid", "Atletico Madrid", "Valencia", "Real Sociedad", "Sevilla", "Athletic Bilbao", "Osasuna", "Espanyol", "Deportivo"], others: ["real zaragoza", "albacete", "sporting de gijon|sporting gijon", "real burgos|burgos", "logrones", "real oviedo", "tenerife", "cadiz", "real valladolid", "mallorca"] },
    1992: { name: "La Liga", size: 20, clubs: ["Barcelona", "Real Madrid", "Deportivo", "Valencia", "Atletico Madrid", "Sevilla", "Athletic Bilbao", "Osasuna", "Celta Vigo", "Real Sociedad", "Rayo Vallecano", "Espanyol"], others: ["tenerife", "real zaragoza", "sporting de gijon|sporting gijon", "logrones", "real oviedo", "albacete", "cadiz", "real burgos|burgos"] },
    1993: { name: "La Liga", size: 20, clubs: ["Barcelona", "Deportivo", "Real Madrid", "Athletic Bilbao", "Sevilla", "Valencia", "Racing Santander", "Real Sociedad", "Atletico Madrid", "Celta Vigo", "Rayo Vallecano", "Osasuna"], others: ["real zaragoza", "real oviedo", "tenerife", "albacete", "sporting de gijon|sporting gijon", "logrones", "real valladolid", "ue lleida|lleida"] },
    1994: { name: "La Liga", size: 20, clubs: ["Real Madrid", "Deportivo", "Real Betis", "Barcelona", "Sevilla", "Espanyol", "Athletic Bilbao", "Valencia", "Real Sociedad", "Racing Santander", "Celta Vigo", "Atletico Madrid"], others: ["real zaragoza", "real oviedo", "tenerife", "compostela", "albacete", "sporting de gijon|sporting gijon", "real valladolid", "logrones"] },
    1995: { name: "La Liga", size: 22, clubs: ["Atletico Madrid", "Valencia", "Barcelona", "Espanyol", "Real Madrid", "Real Sociedad", "Real Betis", "Deportivo", "Celta Vigo", "Sevilla", "Athletic Bilbao", "Racing Santander", "Rayo Vallecano"], others: ["tenerife", "compostela", "real zaragoza", "real oviedo", "real valladolid", "sporting de gijon|sporting gijon", "albacete", "merida cp|merida ad", "salamanca"] },
    1996: { name: "La Liga", size: 22, clubs: ["Real Madrid", "Barcelona", "Deportivo", "Real Betis", "Atletico Madrid", "Athletic Bilbao", "Real Sociedad", "Valencia", "Espanyol", "Racing Santander", "Celta Vigo", "Rayo Vallecano", "Sevilla"], others: ["real valladolid", "tenerife", "compostela", "real zaragoza", "sporting de gijon|sporting gijon", "real oviedo", "extremadura", "hercules", "logrones"] },
    1997: { name: "La Liga", size: 20, clubs: ["Barcelona", "Athletic Bilbao", "Real Sociedad", "Real Madrid", "Celta Vigo", "Atletico Madrid", "Real Betis", "Valencia", "Espanyol", "Deportivo", "Racing Santander"], others: ["mallorca", "real valladolid", "real zaragoza", "salamanca", "tenerife", "compostela", "real oviedo", "merida cp|merida ad", "sporting de gijon|sporting gijon"] },
    1998: { name: "La Liga", size: 20, clubs: ["Barcelona", "Real Madrid", "Valencia", "Celta Vigo", "Deportivo", "Espanyol", "Athletic Bilbao", "Real Sociedad", "Real Betis", "Atletico Madrid", "Racing Santander", "Alaves", "Villarreal"], others: ["mallorca", "real zaragoza", "real valladolid", "real oviedo", "extremadura", "tenerife", "salamanca"] },
    1999: { name: "La Liga", size: 20, clubs: ["Deportivo", "Barcelona", "Valencia", "Real Madrid", "Alaves", "Celta Vigo", "Rayo Vallecano", "Athletic Bilbao", "Malaga", "Real Sociedad", "Espanyol", "Racing Santander", "Real Betis", "Atletico Madrid", "Sevilla"], others: ["real zaragoza", "real valladolid", "mallorca", "real oviedo", "numancia"] },
    2e3: { name: "La Liga", size: 20, clubs: ["Real Madrid", "Deportivo", "Barcelona", "Valencia", "Celta Vigo", "Villarreal", "Malaga", "Espanyol", "Alaves", "Athletic Bilbao", "Real Sociedad", "Rayo Vallecano", "Osasuna", "Racing Santander"], others: ["mallorca", "las palmas", "real valladolid", "real zaragoza", "real oviedo", "numancia soria|numancia"] },
    2001: { name: "La Liga", size: 20, clubs: ["Valencia", "Deportivo", "Real Madrid", "Barcelona", "Celta Vigo", "Real Betis", "Alaves", "Athletic Bilbao", "Sevilla", "Malaga", "Rayo Vallecano", "Real Sociedad", "Espanyol", "Villarreal", "Osasuna"], others: ["real valladolid", "mallorca palma de m|mallorca", "las palmas", "tenerife santa cruz|tenerife", "real zaragoza"] },
    2002: { name: "La Liga", size: 20, clubs: ["Real Madrid", "Real Sociedad", "Deportivo", "Celta Vigo", "Valencia", "Barcelona", "Athletic Bilbao", "Real Betis", "Sevilla", "Atletico Madrid", "Osasuna", "Malaga", "Villarreal", "Racing Santander", "Espanyol", "Alaves", "Rayo Vallecano"], others: ["mallorca palma de m|mallorca", "real valladolid", "recreativo huelva"] },
    2003: { name: "La Liga", size: 20, clubs: ["Valencia", "Barcelona", "Deportivo", "Real Madrid", "Athletic Bilbao", "Sevilla", "Atletico Madrid", "Villarreal", "Real Betis", "Malaga", "Osasuna", "Real Sociedad", "Espanyol", "Racing Santander", "Celta Vigo"], others: ["mallorca palma de m|mallorca", "real zaragoza", "albacete balompie|albacete", "real valladolid", "real murcia"] },
    2004: { name: "La Liga", size: 20, clubs: ["Barcelona", "Real Madrid", "Villarreal", "Real Betis", "Espanyol", "Sevilla", "Valencia", "Deportivo", "Athletic Bilbao", "Malaga", "Atletico Madrid", "Getafe", "Real Sociedad", "Osasuna", "Racing Santander", "Levante"], others: ["real zaragoza", "mallorca palma de m|mallorca", "numancia soria|numancia", "albacete balompie|albacete"] },
    2005: { name: "La Liga", size: 20, clubs: ["Barcelona", "Real Madrid", "Valencia", "Osasuna", "Sevilla", "Celta Vigo", "Villarreal", "Deportivo", "Getafe", "Atletico Madrid", "Athletic Bilbao", "Real Betis", "Espanyol", "Real Sociedad", "Racing Santander", "Alaves", "Malaga"], others: ["real zaragoza", "mallorca palma de m|mallorca", "cadiz"] },
    2006: { name: "La Liga", size: 20, clubs: ["Real Madrid", "Barcelona", "Sevilla", "Valencia", "Villarreal", "Atletico Madrid", "Getafe", "Racing Santander", "Espanyol", "Deportivo", "Osasuna", "Levante", "Real Betis", "Athletic Bilbao", "Celta Vigo", "Real Sociedad"], others: ["real zaragoza", "recreativo de huelva|recreativo huelva", "mallorca palma de m|mallorca", "club gimnastic de tarragona|gimnastic de tarragona"] },
    2007: { name: "La Liga", size: 20, clubs: ["Real Madrid", "Villarreal", "Barcelona", "Atletico Madrid", "Sevilla", "Racing Santander", "Deportivo", "Valencia", "Athletic Bilbao", "Espanyol", "Real Betis", "Getafe", "Osasuna", "Levante"], others: ["mallorca palma de m|mallorca", "almeria", "real valladolid", "recreativo de huelva|recreativo huelva", "real zaragoza", "real murcia"] },
    2008: { name: "La Liga", size: 20, clubs: ["Barcelona", "Real Madrid", "Sevilla", "Atletico Madrid", "Villarreal", "Valencia", "Deportivo", "Malaga", "Espanyol", "Racing Santander", "Athletic Bilbao", "Osasuna", "Getafe", "Real Betis"], others: ["mallorca palma de m|mallorca", "almeria", "sporting de gijon|sporting gijon", "real valladolid", "numancia soria|numancia", "recreativo de huelva|recreativo huelva"] },
    2009: { name: "La Liga", size: 20, clubs: ["Barcelona", "Real Madrid", "Valencia", "Sevilla", "Getafe", "Villarreal", "Athletic Bilbao", "Atletico Madrid", "Deportivo", "Espanyol", "Osasuna", "Racing Santander", "Malaga"], others: ["mallorca palma de m|mallorca", "almeria", "real zaragoza", "sporting de gijon|sporting gijon", "real valladolid", "tenerife", "xerez"] },
    2010: { name: "La Liga", size: 20, clubs: ["Barcelona", "Real Madrid", "Valencia", "Villarreal", "Sevilla", "Athletic Bilbao", "Atletico Madrid", "Espanyol", "Osasuna", "Malaga", "Racing Santander", "Real Sociedad", "Levante", "Getafe", "Deportivo"], others: ["sporting de gijon|sporting gijon", "real zaragoza", "mallorca palma de m|mallorca", "hercules alicante|hercules", "almeria"] },
    2011: { name: "La Liga", size: 20, clubs: ["Real Madrid", "Barcelona", "Valencia", "Malaga", "Atletico Madrid", "Levante", "Osasuna", "Sevilla", "Athletic Bilbao", "Getafe", "Real Sociedad", "Real Betis", "Espanyol", "Rayo Vallecano", "Villarreal", "Racing Santander"], others: ["mallorca palma de m|mallorca", "real zaragoza", "granada", "sporting de gijon|sporting gijon"] },
    2012: { name: "La Liga", size: 20, clubs: ["Barcelona", "Real Madrid", "Atletico Madrid", "Real Sociedad", "Valencia", "Malaga", "Real Betis", "Rayo Vallecano", "Sevilla", "Getafe", "Levante", "Athletic Bilbao", "Espanyol", "Osasuna", "Celta Vigo", "Deportivo"], others: ["real valladolid", "granada", "mallorca palma de m|mallorca", "real zaragoza"] },
    2013: { name: "La Liga", size: 20, clubs: ["Atletico Madrid", "Barcelona", "Real Madrid", "Athletic Bilbao", "Sevilla", "Villarreal", "Real Sociedad", "Valencia", "Celta Vigo", "Levante", "Malaga", "Rayo Vallecano", "Getafe", "Espanyol", "Elche", "Osasuna", "Real Betis"], others: ["granada", "almeria", "real valladolid"] },
    2014: { name: "La Liga", size: 20, clubs: ["Barcelona", "Real Madrid", "Atletico Madrid", "Valencia", "Sevilla", "Villarreal", "Athletic Bilbao", "Celta Vigo", "Malaga", "Espanyol", "Rayo Vallecano", "Real Sociedad", "Elche", "Levante", "Getafe", "Deportivo"], others: ["granada", "eibar", "almeria", "cordoba"] },
    2015: { name: "La Liga", size: 20, clubs: ["Barcelona", "Real Madrid", "Atletico Madrid", "Villarreal", "Athletic Bilbao", "Celta Vigo", "Sevilla", "Malaga", "Real Sociedad", "Real Betis", "Valencia", "Espanyol", "Deportivo", "Rayo Vallecano", "Getafe", "Levante"], others: ["las palmas", "eibar", "granada", "sporting de gijon|sporting gijon"] },
    2016: { name: "La Liga", size: 20, clubs: ["Real Madrid", "Barcelona", "Atletico Madrid", "Sevilla", "Villarreal", "Real Sociedad", "Athletic Bilbao", "Espanyol", "Alaves", "Malaga", "Valencia", "Celta Vigo", "Real Betis", "Deportivo", "Osasuna"], others: ["eibar", "las palmas", "leganes", "sporting de gijon|sporting gijon", "granada"] },
    2017: { name: "La Liga", size: 20, clubs: ["Barcelona", "Atletico Madrid", "Real Madrid", "Valencia", "Villarreal", "Real Betis", "Sevilla", "Getafe", "Girona", "Espanyol", "Real Sociedad", "Celta Vigo", "Alaves", "Levante", "Athletic Bilbao", "Deportivo", "Malaga"], others: ["eibar", "leganes", "las palmas"] },
    2018: { name: "La Liga", size: 20, clubs: ["Barcelona", "Atletico Madrid", "Real Madrid", "Valencia", "Getafe", "Sevilla", "Espanyol", "Athletic Bilbao", "Real Sociedad", "Real Betis", "Alaves", "Villarreal", "Levante", "Celta Vigo", "Girona", "Rayo Vallecano"], others: ["eibar", "leganes", "real valladolid", "huesca"] },
    2019: { name: "La Liga", size: 20, clubs: ["Real Madrid", "Barcelona", "Atletico Madrid", "Sevilla", "Villarreal", "Real Sociedad", "Getafe", "Valencia", "Osasuna", "Athletic Bilbao", "Levante", "Real Betis", "Alaves", "Celta Vigo", "Espanyol"], others: ["granada", "real valladolid", "eibar", "leganes", "mallorca palma de m|mallorca"] },
    2020: { name: "La Liga", size: 20, clubs: ["Atletico Madrid", "Real Madrid", "Barcelona", "Sevilla", "Real Sociedad", "Real Betis", "Villarreal", "Celta Vigo", "Athletic Bilbao", "Osasuna", "Valencia", "Levante", "Getafe", "Alaves", "Elche"], others: ["granada", "cadiz", "huesca", "real valladolid", "eibar"] },
    2021: { name: "La Liga", size: 20, clubs: ["Real Madrid", "Barcelona", "Atletico Madrid", "Sevilla", "Real Betis", "Real Sociedad", "Villarreal", "Athletic Bilbao", "Valencia", "Osasuna", "Celta Vigo", "Rayo Vallecano", "Elche", "Espanyol", "Getafe", "Levante", "Alaves"], others: ["mallorca palma de m|mallorca", "cadiz", "granada"] },
    2022: { name: "La Liga", size: 20, clubs: ["Barcelona", "Real Madrid", "Atletico Madrid", "Real Sociedad", "Villarreal", "Real Betis", "Osasuna", "Athletic Bilbao", "Girona", "Rayo Vallecano", "Sevilla", "Celta Vigo", "Getafe", "Valencia", "Espanyol", "Elche"], others: ["mallorca palma de m|mallorca", "cadiz", "almeria", "real valladolid"] },
    2023: { name: "La Liga", size: 20, clubs: ["Real Madrid", "Barcelona", "Girona", "Atletico Madrid", "Athletic Bilbao", "Real Sociedad", "Real Betis", "Villarreal", "Valencia", "Alaves", "Osasuna", "Getafe", "Celta Vigo", "Sevilla", "Rayo Vallecano"], others: ["mallorca palma de m|mallorca", "las palmas", "cadiz", "almeria", "granada"] },
    2024: { name: "La Liga", size: 20, clubs: ["Barcelona", "Real Madrid", "Atletico Madrid", "Athletic Bilbao", "Villarreal", "Real Betis", "Celta Vigo", "Rayo Vallecano", "Osasuna", "Real Sociedad", "Valencia", "Getafe", "Espanyol", "Alaves", "Girona", "Sevilla"], others: ["mallorca palma de m|mallorca", "leganes", "las palmas", "real valladolid"] },
    2025: { name: "La Liga", size: 20, clubs: ["Barcelona", "Real Madrid", "Villarreal", "Atletico Madrid", "Real Betis", "Celta Vigo", "Getafe", "Rayo Vallecano", "Valencia", "Real Sociedad", "Espanyol", "Athletic Bilbao", "Sevilla", "Alaves", "Elche", "Levante", "Osasuna", "Girona"], others: ["mallorca palma de m|mallorca", "real oviedo"] }
  },
  "Serie A": {
    1990: { name: "Serie A", size: 18, clubs: ["AC Milan", "Inter Milan", "Torino", "Juventus", "Napoli", "Roma", "Atalanta", "Fiorentina", "Bologna"], others: ["sampdoria", "genoa", "parma", "lazio|lazio roma", "bari", "cagliari", "lecce", "pisa", "cesena"] },
    1991: { name: "Serie A", size: 18, clubs: ["AC Milan", "Juventus", "Torino", "Napoli", "Roma", "Inter Milan", "Atalanta", "Fiorentina"], others: ["sampdoria", "parma", "foggia", "lazio|lazio roma", "cagliari", "genoa", "bari", "verona|hellas verona", "cremonese", "ascoli"] },
    1992: { name: "Serie A", size: 18, clubs: ["AC Milan", "Inter Milan", "Juventus", "Atalanta", "Torino", "Roma", "Napoli", "Fiorentina"], others: ["parma", "lazio|lazio roma", "cagliari", "sampdoria", "foggia", "genoa", "udinese", "brescia", "ancona", "pescara"] },
    1993: { name: "Serie A", size: 18, clubs: ["AC Milan", "Juventus", "Napoli", "Roma", "Torino", "Inter Milan", "Atalanta"], others: ["sampdoria", "lazio|lazio roma", "parma", "foggia", "cremonese", "genoa", "cagliari", "reggiana", "piacenza", "udinese", "lecce"] },
    1994: { name: "Serie A", size: 18, clubs: ["Juventus", "AC Milan", "Roma", "Inter Milan", "Napoli", "Fiorentina", "Torino"], others: ["lazio|lazio roma", "parma", "sampdoria", "cagliari", "bari", "cremonese", "genoa", "padova", "foggia", "reggiana", "brescia"] },
    1995: { name: "Serie A", size: 18, clubs: ["AC Milan", "Juventus", "Fiorentina", "Roma", "Inter Milan", "Napoli", "Atalanta", "Torino"], others: ["lazio|lazio roma", "parma", "sampdoria", "vicenza", "cagliari", "udinese", "piacenza", "bari", "cremonese", "padova"] },
    1996: { name: "Serie A", size: 18, clubs: ["Juventus", "Inter Milan", "Bologna", "Fiorentina", "Atalanta", "AC Milan", "Roma", "Napoli"], others: ["parma", "lazio|lazio roma", "udinese", "sampdoria", "vicenza", "piacenza", "cagliari", "perugia", "verona|hellas verona", "reggiana"] },
    1997: { name: "Serie A", size: 18, clubs: ["Juventus", "Inter Milan", "Roma", "Fiorentina", "Bologna", "AC Milan", "Atalanta", "Napoli"], others: ["udinese", "parma", "lazio|lazio roma", "sampdoria", "bari", "empoli", "piacenza", "vicenza", "brescia", "lecce"] },
    1998: { name: "Serie A", size: 18, clubs: ["AC Milan", "Fiorentina", "Roma", "Juventus", "Inter Milan", "Bologna"], others: ["lazio|lazio roma", "parma", "udinese", "bari", "venezia", "cagliari", "piacenza", "perugia", "salernitana sport", "sampdoria", "vicenza", "empoli"] },
    1999: { name: "Serie A", size: 18, clubs: ["Juventus", "AC Milan", "Inter Milan", "Roma", "Fiorentina", "Bologna", "Torino"], others: ["lazio|lazio roma", "parma", "udinese", "hellas verona", "perugia", "reggina", "lecce", "bari", "venezia", "cagliari", "piacenza"] },
    2e3: { name: "Serie A", size: 18, clubs: ["Roma", "Juventus", "Inter Milan", "AC Milan", "Atalanta", "Fiorentina", "Bologna", "Napoli"], others: ["lazio|lazio roma", "parma", "brescia", "perugia", "udinese", "lecce", "reggina", "hellas verona", "vicenza", "bari"] },
    2001: { name: "Serie A", size: 18, clubs: ["Juventus", "Roma", "Inter Milan", "AC Milan", "Bologna", "Atalanta", "Torino", "Fiorentina"], others: ["chievo verona", "lazio|lazio roma", "perugia", "parma", "piacenza", "brescia", "udinese", "hellas verona", "lecce", "venezia"] },
    2002: { name: "Serie A", size: 18, clubs: ["Juventus", "Inter Milan", "AC Milan", "Roma", "Bologna", "Atalanta", "Torino"], others: ["lazio|lazio roma", "parma", "udinese", "chievo verona", "brescia", "perugia", "modena", "empoli", "reggina", "piacenza", "como"] },
    2003: { name: "Serie A", size: 18, clubs: ["AC Milan", "Roma", "Juventus", "Inter Milan", "Bologna"], others: ["parma", "lazio|lazio roma", "udinese", "uc sampdoria|sampdoria", "chievo verona", "lecce", "brescia", "siena", "reggina", "perugia", "modena", "empoli", "ancona"] },
    2004: { name: "Serie A", size: 20, clubs: ["Juventus", "AC Milan", "Inter Milan", "Roma", "Fiorentina", "Bologna", "Atalanta"], others: ["udinese", "uc sampdoria|sampdoria", "citta di palermo|palermo", "messina pfc|messina", "livorno", "lazio|lazio roma", "lecce", "cagliari", "reggina", "siena", "chievo verona", "parma", "brescia"] },
    2005: { name: "Serie A", size: 20, clubs: ["Inter Milan", "Roma", "AC Milan", "Fiorentina", "Juventus"], others: ["chievo verona", "citta di palermo|palermo", "livorno", "empoli", "parma", "ascoli", "udinese", "uc sampdoria|sampdoria", "reggina", "cagliari", "siena", "lazio|lazio roma", "messina pfc|messina", "lecce", "treviso|treviso fbc"] },
    2006: { name: "Serie A", size: 20, clubs: ["Inter Milan", "Roma", "AC Milan", "Fiorentina", "Atalanta", "Torino"], others: ["lazio|lazio roma", "citta di palermo|palermo", "empoli", "uc sampdoria|sampdoria", "udinese", "livorno", "parma", "catania", "reggina", "siena", "cagliari", "chievo verona", "ascoli", "messina pfc|messina"] },
    2007: { name: "Serie A", size: 20, clubs: ["Inter Milan", "Roma", "Juventus", "Fiorentina", "AC Milan", "Napoli", "Atalanta", "Torino"], others: ["uc sampdoria|sampdoria", "udinese", "genoa", "citta di palermo|palermo", "lazio|lazio roma", "siena", "cagliari", "reggina", "catania", "empoli", "parma", "livorno"] },
    2008: { name: "Serie A", size: 20, clubs: ["Inter Milan", "Juventus", "AC Milan", "Fiorentina", "Roma", "Atalanta", "Napoli", "Bologna", "Torino"], others: ["genoa", "udinese", "citta di palermo|palermo", "cagliari", "lazio|lazio roma", "uc sampdoria|sampdoria", "siena", "catania", "chievo verona", "reggina", "lecce"] },
    2009: { name: "Serie A", size: 20, clubs: ["Inter Milan", "Roma", "AC Milan", "Napoli", "Juventus", "Fiorentina", "Bologna", "Atalanta"], others: ["uc sampdoria|sampdoria", "citta di palermo|palermo", "parma", "genoa", "bari", "lazio|lazio roma", "catania", "cagliari", "udinese", "chievo verona", "siena", "livorno"] },
    2010: { name: "Serie A", size: 20, clubs: ["AC Milan", "Inter Milan", "Napoli", "Roma", "Juventus", "Fiorentina", "Bologna"], others: ["udinese", "lazio|lazio roma", "citta di palermo|palermo", "genoa", "chievo verona", "parma", "catania", "cagliari", "cesena", "lecce", "uc sampdoria|sampdoria", "brescia", "bari"] },
    2011: { name: "Serie A", size: 20, clubs: ["Juventus", "AC Milan", "Napoli", "Inter Milan", "Roma", "Bologna", "Atalanta", "Fiorentina"], others: ["udinese", "lazio|lazio roma", "parma", "chievo verona", "catania", "siena", "cagliari", "citta di palermo|palermo", "genoa", "lecce", "novara", "cesena"] },
    2012: { name: "Serie A", size: 20, clubs: ["Juventus", "Napoli", "AC Milan", "Fiorentina", "Roma", "Inter Milan", "Bologna", "Atalanta", "Torino"], others: ["udinese", "lazio|lazio roma", "catania", "parma", "cagliari", "chievo verona", "uc sampdoria|sampdoria", "genoa", "citta di palermo|palermo", "siena", "delfino pescara|pescara"] },
    2013: { name: "Serie A", size: 20, clubs: ["Juventus", "Roma", "Napoli", "Fiorentina", "Inter Milan", "Torino", "AC Milan", "Atalanta", "Bologna"], others: ["parma", "lazio|lazio roma", "hellas verona", "uc sampdoria|sampdoria", "udinese", "genoa", "cagliari", "chievo verona", "sassuolo", "catania", "livorno"] },
    2014: { name: "Serie A", size: 20, clubs: ["Juventus", "Roma", "Fiorentina", "Napoli", "Inter Milan", "Torino", "AC Milan", "Atalanta"], others: ["lazio|lazio roma", "genoa", "uc sampdoria|sampdoria", "citta di palermo|palermo", "sassuolo", "hellas verona", "chievo verona", "empoli", "udinese", "cagliari", "cesena", "parma"] },
    2015: { name: "Serie A", size: 20, clubs: ["Juventus", "Napoli", "Roma", "Inter Milan", "Fiorentina", "AC Milan", "Torino", "Atalanta", "Bologna"], others: ["sassuolo", "lazio|lazio roma", "chievo verona", "empoli", "genoa", "uc sampdoria|sampdoria", "citta di palermo|palermo", "udinese", "carpi", "frosinone", "hellas verona"] },
    2016: { name: "Serie A", size: 20, clubs: ["Juventus", "Roma", "Napoli", "Atalanta", "AC Milan", "Inter Milan", "Fiorentina", "Torino", "Bologna"], others: ["lazio|lazio roma", "uc sampdoria|sampdoria", "cagliari", "sassuolo", "udinese", "chievo verona", "genoa", "crotone", "empoli", "citta di palermo|palermo", "delfino pescara|pescara"] },
    2017: { name: "Serie A", size: 20, clubs: ["Juventus", "Napoli", "Roma", "Inter Milan", "AC Milan", "Atalanta", "Fiorentina", "Torino", "Bologna"], others: ["lazio|lazio roma", "uc sampdoria|sampdoria", "sassuolo", "genoa", "chievo verona", "udinese", "cagliari", "spal ferrara", "crotone", "hellas verona", "benevento"] },
    2018: { name: "Serie A", size: 20, clubs: ["Juventus", "Napoli", "Atalanta", "Inter Milan", "AC Milan", "Roma", "Torino", "Bologna", "Fiorentina"], others: ["lazio|lazio roma", "uc sampdoria|sampdoria", "sassuolo", "udinese", "spal ferrara", "parma", "cagliari", "genoa", "empoli", "frosinone", "chievo verona"] },
    2019: { name: "Serie A", size: 20, clubs: ["Juventus", "Inter Milan", "Atalanta", "Roma", "AC Milan", "Napoli", "Fiorentina", "Bologna", "Torino"], others: ["lazio|lazio roma", "sassuolo", "hellas verona", "parma", "udinese", "cagliari", "uc sampdoria|sampdoria", "genoa", "lecce", "brescia", "spal ferrara"] },
    2020: { name: "Serie A", size: 20, clubs: ["Inter Milan", "AC Milan", "Atalanta", "Juventus", "Napoli", "Roma", "Bologna", "Fiorentina", "Torino"], others: ["lazio|lazio roma", "sassuolo", "uc sampdoria|sampdoria", "hellas verona", "genoa", "udinese", "spezia", "cagliari", "benevento", "crotone", "parma"] },
    2021: { name: "Serie A", size: 20, clubs: ["AC Milan", "Inter Milan", "Napoli", "Juventus", "Roma", "Fiorentina", "Atalanta", "Torino", "Bologna"], others: ["lazio|lazio roma", "hellas verona", "sassuolo", "udinese", "empoli", "uc sampdoria|sampdoria", "spezia", "salernitana", "cagliari", "genoa", "venezia"] },
    2022: { name: "Serie A", size: 20, clubs: ["Napoli", "Inter Milan", "AC Milan", "Atalanta", "Roma", "Juventus", "Fiorentina", "Bologna", "Torino"], others: ["lazio|lazio roma", "monza", "udinese", "sassuolo", "empoli", "salernitana", "lecce", "spezia", "hellas verona", "cremonese", "uc sampdoria|sampdoria"] },
    2023: { name: "Serie A", size: 20, clubs: ["Inter Milan", "AC Milan", "Juventus", "Atalanta", "Bologna", "Roma", "Fiorentina", "Torino", "Napoli"], others: ["lazio|lazio roma", "genoa", "monza", "hellas verona", "lecce", "udinese", "cagliari", "empoli", "frosinone", "sassuolo", "salernitana"] },
    2024: { name: "Serie A", size: 20, clubs: ["Napoli", "Inter Milan", "Atalanta", "Juventus", "Roma", "Fiorentina", "AC Milan", "Bologna", "Torino"], others: ["lazio", "como", "udinese", "genoa", "hellas verona", "cagliari", "parma", "lecce", "empoli", "venezia", "monza"] },
    2025: { name: "Serie A", size: 20, clubs: ["Inter Milan", "Napoli", "Roma", "AC Milan", "Juventus", "Atalanta", "Bologna", "Torino", "Fiorentina"], others: ["como", "lazio", "udinese", "sassuolo", "parma", "cagliari", "genoa", "lecce", "cremonese", "hellas verona", "pisa"] }
  },
  "Bundesliga": {
    1990: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Werder Bremen", "Frankfurt", "Stuttgart", "Leverkusen", "Dortmund", "Hertha Berlin"], others: ["kaiserslautern", "hamburger", "koln", "borussia monchengladbach|borussia m gladbach", "wattenscheid|sg wattenscheid", "fortuna dusseldorf", "karlsruher", "bochum", "nurnberg", "st pauli", "bayer uerdingen"] },
    1991: { name: "Bundesliga", size: 20, clubs: ["Stuttgart", "Dortmund", "Frankfurt", "Leverkusen", "Werder Bremen", "Bayern Munich"], others: ["koln", "kaiserslautern", "nurnberg", "karlsruher", "schalke", "hamburger", "borussia monchengladbach|borussia m gladbach", "dynamo dresden", "bochum", "wattenscheid|sg wattenscheid", "stuttgarter kickers", "hansa rostock", "msv duisburg", "fortuna dusseldorf"] },
    1992: { name: "Bundesliga", size: 18, clubs: ["Werder Bremen", "Bayern Munich", "Frankfurt", "Dortmund", "Leverkusen", "Stuttgart"], others: ["karlsruher", "kaiserslautern", "borussia monchengladbach|borussia m gladbach", "schalke", "hamburger", "koln", "wattenscheid|sg wattenscheid", "nurnberg", "dynamo dresden", "bochum", "bayer uerdingen", "saarbrucken"] },
    1993: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Dortmund", "Leverkusen", "Frankfurt", "Stuttgart", "Werder Bremen"], others: ["kaiserslautern", "karlsruher", "msv duisburg", "borussia monchengladbach|borussia m gladbach", "koln", "dynamo dresden", "hamburger", "schalke", "freiburg", "nurnberg", "wattenscheid|sg wattenscheid", "leipzig"] },
    1994: { name: "Bundesliga", size: 18, clubs: ["Dortmund", "Werder Bremen", "Bayern Munich", "Leverkusen", "Frankfurt", "Stuttgart"], others: ["freiburg", "kaiserslautern", "borussia monchengladbach|borussia m gladbach", "karlsruher", "koln", "schalke", "hamburger", "tsv munchen", "bayer uerdingen", "bochum", "msv duisburg", "dynamo dresden"] },
    1995: { name: "Bundesliga", size: 18, clubs: ["Dortmund", "Bayern Munich", "Werder Bremen", "Stuttgart", "Leverkusen", "Frankfurt"], others: ["schalke", "borussia monchengladbach|borussia m gladbach", "hamburger", "hansa rostock", "karlsruher", "tsv munchen", "freiburg", "koln", "fortuna dusseldorf", "st pauli", "kaiserslautern", "kfc uerdingen"] },
    1996: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Leverkusen", "Dortmund", "Stuttgart", "Werder Bremen"], others: ["bochum", "karlsruher", "tsv munchen", "msv duisburg", "koln", "borussia monchengladbach|borussia m gladbach", "schalke", "hamburger", "hansa rostock", "arminia bielefeld|dsc arminia bielefeld", "fortuna dusseldorf", "freiburg", "st pauli"] },
    1997: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Leverkusen", "Stuttgart", "Werder Bremen", "Dortmund", "Hertha Berlin"], others: ["kaiserslautern", "schalke", "hansa rostock", "msv duisburg", "hamburger", "bochum", "tsv munchen", "wolfsburg", "borussia monchengladbach|borussia m gladbach", "karlsruher", "koln", "arminia bielefeld|dsc arminia bielefeld"] },
    1998: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Leverkusen", "Hertha Berlin", "Dortmund", "Stuttgart", "Werder Bremen", "Frankfurt"], others: ["kaiserslautern", "wolfsburg", "hamburger", "msv duisburg", "schalke", "tsv munchen", "freiburg", "hansa rostock", "nurnberg", "bochum", "borussia monchengladbach|borussia m gladbach"] },
    1999: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Leverkusen", "Hertha Berlin", "Stuttgart", "Werder Bremen", "Dortmund", "Frankfurt"], others: ["hamburger", "tsv munchen", "kaiserslautern", "wolfsburg", "unterhaching", "freiburg", "schalke", "hansa rostock", "ssv ulm", "dsc arminia bielefeld", "msv duisburg"] },
    2e3: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Dortmund", "Leverkusen", "Hertha Berlin", "Werder Bremen", "Stuttgart", "Frankfurt"], others: ["schalke", "freiburg", "kaiserslautern", "wolfsburg", "koln", "tsv munchen", "hansa rostock", "hamburger", "energie cottbus", "unterhaching", "bochum"] },
    2001: { name: "Bundesliga", size: 18, clubs: ["Dortmund", "Leverkusen", "Bayern Munich", "Hertha Berlin", "Werder Bremen", "Stuttgart"], others: ["schalke", "kaiserslautern", "tsv munchen", "wolfsburg", "hamburger", "borussia monchengladbach|borussia m gladbach", "energie cottbus", "hansa rostock", "nurnberg", "freiburg", "koln", "sankt pauli|st pauli"] },
    2002: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Stuttgart", "Dortmund", "Hertha Berlin", "Werder Bremen", "Leverkusen"], others: ["hamburger", "schalke", "wolfsburg", "bochum", "tsv munchen", "hannover", "borussia monchengladbach|borussia m gladbach", "hansa rostock", "kaiserslautern", "dsc arminia bielefeld", "nurnberg", "energie cottbus"] },
    2003: { name: "Bundesliga", size: 18, clubs: ["Werder Bremen", "Bayern Munich", "Leverkusen", "Stuttgart", "Dortmund", "Hertha Berlin", "Frankfurt"], others: ["bochum", "schalke gelsenkirchen|schalke", "hamburger", "hansa rostock", "wolfsburg", "borussia monchengladbach|borussia m gladbach", "freiburg", "hannover", "kaiserslautern", "tsv munchen", "koln"] },
    2004: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Werder Bremen", "Hertha Berlin", "Stuttgart", "Leverkusen", "Dortmund"], others: ["schalke gelsenkirchen|schalke", "hamburger", "wolfsburg", "hannover", "mainz", "kaiserslautern", "dsc arminia bielefeld", "nurnberg", "borussia monchengladbach|borussia m gladbach", "bochum", "hansa rostock", "freiburg"] },
    2005: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Werder Bremen", "Leverkusen", "Hertha Berlin", "Dortmund", "Stuttgart", "Frankfurt"], others: ["hamburger", "schalke gelsenkirchen|schalke", "nurnberg", "borussia monchengladbach|borussia m gladbach", "mainz", "hannover", "dsc arminia bielefeld", "wolfsburg", "kaiserslautern", "koln", "msv duisburg"] },
    2006: { name: "Bundesliga", size: 18, clubs: ["Stuttgart", "Werder Bremen", "Bayern Munich", "Leverkusen", "Dortmund", "Hertha Berlin", "Frankfurt"], others: ["schalke gelsenkirchen|schalke", "nurnberg", "hamburger", "bochum", "hannover", "dsc arminia bielefeld", "energie cottbus", "wolfsburg", "mainz", "tsv alemannia aachen|alemannia aachen", "borussia monchengladbach|borussia m gladbach"] },
    2007: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Werder Bremen", "Stuttgart", "Leverkusen", "Frankfurt", "Hertha Berlin", "Dortmund"], others: ["schalke gelsenkirchen|schalke", "hamburger", "wolfsburg", "hannover", "karlsruher", "bochum", "energie cottbus", "dsc arminia bielefeld", "nurnberg", "hansa rostock", "msv duisburg"] },
    2008: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Stuttgart", "Hertha Berlin", "Dortmund", "Leverkusen", "Werder Bremen", "Frankfurt"], others: ["wolfsburg", "hamburger", "hoffenheim", "schalke gelsenkirchen|schalke", "hannover", "koln", "bochum", "borussia monchengladbach|borussia m gladbach", "energie cottbus", "karlsruher", "dsc arminia bielefeld"] },
    2009: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Werder Bremen", "Leverkusen", "Dortmund", "Stuttgart", "Frankfurt", "Hertha Berlin"], others: ["schalke gelsenkirchen|schalke", "hamburger", "wolfsburg", "mainz", "hoffenheim", "borussia monchengladbach|borussia m gladbach", "koln", "freiburg", "hannover", "nurnberg", "bochum"] },
    2010: { name: "Bundesliga", size: 18, clubs: ["Dortmund", "Leverkusen", "Bayern Munich", "Stuttgart", "Werder Bremen", "Frankfurt"], others: ["hannover", "mainz", "nurnberg", "kaiserslautern", "hamburger", "freiburg", "koln", "hoffenheim", "schalke", "wolfsburg", "borussia m gladbach", "st pauli"] },
    2011: { name: "Bundesliga", size: 18, clubs: ["Dortmund", "Bayern Munich", "Leverkusen", "Stuttgart", "Werder Bremen", "Hertha Berlin"], others: ["schalke gelsenkirchen|schalke", "borussia monchengladbach|borussia m gladbach", "hannover", "wolfsburg", "nurnberg", "hoffenheim", "freiburg", "mainz", "augsburg", "hamburger", "koln", "kaiserslautern"] },
    2012: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Dortmund", "Leverkusen", "Frankfurt", "Stuttgart", "Werder Bremen"], others: ["schalke gelsenkirchen|schalke", "freiburg", "hamburger", "borussia monchengladbach|borussia m gladbach", "hannover", "nurnberg", "wolfsburg", "mainz", "augsburg", "hoffenheim", "fortuna dusseldorf", "greuther furth"] },
    2013: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Dortmund", "Leverkusen", "Hertha Berlin", "Werder Bremen", "Frankfurt", "Stuttgart"], others: ["schalke gelsenkirchen|schalke", "wolfsburg", "borussia monchengladbach|borussia m gladbach", "mainz", "augsburg", "hoffenheim", "hannover", "freiburg", "hamburger", "nurnberg", "eintracht braunschweig"] },
    2014: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Leverkusen", "Dortmund", "Frankfurt", "Werder Bremen", "Stuttgart", "Hertha Berlin"], others: ["wolfsburg", "borussia monchengladbach|borussia m gladbach", "augsburg", "schalke gelsenkirchen|schalke", "hoffenheim", "mainz", "koln", "hannover", "hamburger", "freiburg", "paderborn"] },
    2015: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Dortmund", "Leverkusen", "Hertha Berlin", "Werder Bremen", "Frankfurt", "Stuttgart"], others: ["borussia monchengladbach|borussia m gladbach", "schalke gelsenkirchen|schalke", "mainz", "wolfsburg", "koln", "hamburger", "ingolstadt", "augsburg", "darmstadt", "hoffenheim", "hannover"] },
    2016: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Leipzig", "Dortmund", "Hertha Berlin", "Werder Bremen", "Frankfurt", "Leverkusen"], others: ["hoffenheim", "koln", "freiburg", "borussia monchengladbach|borussia m gladbach", "schalke gelsenkirchen|schalke", "augsburg", "hamburger", "mainz", "wolfsburg", "ingolstadt", "darmstadt"] },
    2017: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Dortmund", "Leverkusen", "Leipzig", "Stuttgart", "Frankfurt", "Hertha Berlin", "Werder Bremen"], others: ["schalke gelsenkirchen|schalke", "hoffenheim", "borussia monchengladbach|borussia m gladbach", "augsburg", "hannover", "mainz", "freiburg", "wolfsburg", "hamburger", "koln"] },
    2018: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Dortmund", "Leipzig", "Leverkusen", "Frankfurt", "Werder Bremen", "Hertha Berlin", "Stuttgart"], others: ["borussia monchengladbach|borussia m gladbach", "wolfsburg", "hoffenheim", "fortuna dusseldorf", "mainz", "freiburg", "schalke gelsenkirchen|schalke", "augsburg", "hannover", "nurnberg"] },
    2019: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Dortmund", "Leipzig", "Leverkusen", "Frankfurt", "Hertha Berlin", "Werder Bremen"], others: ["borussia monchengladbach|borussia m gladbach", "hoffenheim", "wolfsburg", "freiburg", "union berlin", "schalke gelsenkirchen|schalke", "mainz", "koln", "augsburg", "fortuna dusseldorf", "paderborn"] },
    2020: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Leipzig", "Dortmund", "Frankfurt", "Leverkusen", "Stuttgart", "Hertha Berlin", "Werder Bremen"], others: ["wolfsburg", "union berlin", "borussia monchengladbach|borussia m gladbach", "freiburg", "hoffenheim", "mainz", "augsburg", "dsc arminia bielefeld", "koln", "schalke gelsenkirchen|schalke"] },
    2021: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Dortmund", "Leverkusen", "Leipzig", "Frankfurt", "Stuttgart", "Hertha Berlin"], others: ["union berlin", "freiburg", "koln", "mainz", "hoffenheim", "borussia monchengladbach|borussia m gladbach", "wolfsburg", "bochum", "augsburg", "dsc arminia bielefeld", "greuther furth"] },
    2022: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Dortmund", "Leipzig", "Leverkusen", "Frankfurt", "Werder Bremen", "Stuttgart", "Hertha Berlin"], others: ["union berlin", "freiburg", "wolfsburg", "mainz", "borussia monchengladbach", "koln|cologne", "hoffenheim", "bochum", "augsburg", "schalke gelsenkirchen|schalke"] },
    2023: { name: "Bundesliga", size: 18, clubs: ["Leverkusen", "Stuttgart", "Bayern Munich", "Leipzig", "Dortmund", "Frankfurt", "Werder Bremen"], others: ["hoffenheim", "heidenheim", "freiburg", "augsburg", "wolfsburg", "mainz", "borussia monchengladbach", "union berlin", "bochum", "koln|cologne", "darmstadt"] },
    2024: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Leverkusen", "Frankfurt", "Dortmund", "Leipzig", "Werder Bremen", "Stuttgart"], others: ["freiburg", "mainz", "borussia monchengladbach", "wolfsburg", "augsburg", "union berlin", "sankt pauli|st pauli", "hoffenheim", "heidenheim", "holstein kiel", "bochum"] },
    2025: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Dortmund", "Leipzig", "Stuttgart", "Leverkusen", "Frankfurt", "Werder Bremen"], others: ["hoffenheim", "freiburg", "augsburg", "mainz", "union berlin", "borussia monchengladbach", "hamburger|hamburg", "koln|cologne", "wolfsburg", "heidenheim", "sankt pauli|st pauli"] }
  },
  "Ligue 1": {
    1990: { name: "Division 1", size: 20, clubs: ["Marseille", "Monaco", "Lyon", "Lille", "PSG", "Nice", "Nantes"], others: ["auxerre", "cannes", "montpellier", "caen", "bordeaux", "brest", "metz", "st etienne|saint etienne", "toulon", "nancy", "sochaux", "toulouse", "rennes"] },
    1991: { name: "Division 1", size: 20, clubs: ["Marseille", "Monaco", "PSG", "Nantes", "Lille", "Lyon"], others: ["auxerre", "caen", "montpellier", "le havre", "lens", "st etienne|saint etienne", "toulouse", "metz", "toulon", "nimes", "sochaux", "rennes", "cannes", "nancy"] },
    1992: { name: "Division 1", size: 20, clubs: ["Marseille", "PSG", "Monaco", "Nantes", "Strasbourg", "Lyon", "Lille"], others: ["bordeaux", "auxerre", "st etienne|saint etienne", "lens", "montpellier", "caen", "metz", "toulouse", "le havre", "sochaux", "valenciennes", "toulon", "nimes"] },
    1993: { name: "Division 1", size: 20, clubs: ["PSG", "Marseille", "Nantes", "Lyon", "Monaco", "Strasbourg", "Lille"], others: ["auxerre", "bordeaux|girondins de bordeaux", "cannes|a s cannes", "montpellier|montpellier herault", "lens", "st etienne|saint etienne", "metz", "sochaux|sochaux montbeliard", "caen|stade malherbe caen", "le havre|havre", "martigues|f c martigues", "toulouse", "angers"] },
    1994: { name: "Division 1", size: 20, clubs: ["Nantes", "Lyon", "PSG", "Monaco", "Strasbourg", "Lille", "Nice"], others: ["auxerre", "lens", "bordeaux|girondins de bordeaux", "metz", "cannes|a s cannes", "martigues|f c martigues", "le havre|havre", "rennes|stade rennais", "bastia|s c bastiais", "montpellier|montpellier herault", "st etienne|saint etienne", "caen|stade malherbe caen", "sochaux|sochaux montbeliard"] },
    1995: { name: "Division 1", size: 20, clubs: ["PSG", "Monaco", "Nantes", "Strasbourg", "Lyon", "Nice", "Lille"], others: ["auxerre", "metz", "lens", "montpellier|montpellier herault", "rennes|stade rennais", "guingamp|en avant guingamp", "le havre|havre", "cannes|a s cannes", "bastia|s c bastiais", "bordeaux|girondins de bordeaux", "gueugnon|f c gueugnon", "st etienne|saint etienne", "martigues|f c martigues"] },
    1996: { name: "Division 1", size: 20, clubs: ["Monaco", "PSG", "Nantes", "Lyon", "Strasbourg", "Marseille", "Lille", "Nice"], others: ["bordeaux|girondins de bordeaux", "metz", "auxerre", "bastia|s c bastiais", "montpellier|montpellier herault", "guingamp|en avant guingamp", "lens", "le havre|havre", "cannes|a s cannes", "rennes|stade rennais", "caen|stade malherbe caen", "nancy|nancy lorraine"] },
    1997: { name: "Division 1", size: 18, clubs: ["Monaco", "Marseille", "Lyon", "PSG", "Nantes", "Strasbourg"], others: ["lens", "metz", "girondins de bordeaux", "auxerre", "bastia|s c bastiais", "le havre|havre", "montpellier hsc|montpellier herault", "stade rennais", "toulouse", "en avant guingamp", "berrichonne chateauroux|chateauroux", "cannes|a s cannes"] },
    1998: { name: "Division 1", size: 18, clubs: ["Marseille", "Lyon", "Monaco", "Nantes", "PSG", "Strasbourg"], others: ["girondins de bordeaux", "stade rennais", "lens", "montpellier hsc|montpellier herault", "metz", "nancy lorraine", "bastia|s c bastiais", "auxerre", "havre", "lorient", "sochaux montbeliard", "toulouse"] },
    1999: { name: "Division 1", size: 18, clubs: ["Monaco", "PSG", "Lyon", "Strasbourg", "Nantes", "Marseille"], others: ["girondins de bordeaux", "lens", "saint etienne", "cs sedan ardennes|c s sedan ardennes", "auxerre", "bastia|s c bastiais", "metz", "stade rennais", "atac troyes|estac troyes", "nancy lorraine", "havre", "montpellier hsc|montpellier herault"] },
    2e3: { name: "Division 1", size: 18, clubs: ["Nantes", "Lyon", "Lille", "PSG", "Monaco", "Marseille", "Strasbourg"], others: ["girondins de bordeaux", "cs sedan ardennes|c s sedan ardennes", "stade rennais", "es troyes|estac troyes", "bastia|s c bastiais", "en avant guingamp", "metz", "auxerre", "lens", "toulouse", "saint etienne"] },
    2001: { name: "Division 1", size: 18, clubs: ["Lyon", "PSG", "Lille", "Marseille", "Nantes", "Monaco"], others: ["lens", "auxerre", "girondins de bordeaux", "es troyes|estac troyes", "sochaux montbeliard", "bastia|s c bastiais", "stade rennais", "montpellier hsc|montpellier herault", "cs sedan ardennes|c s sedan ardennes", "en avant guingamp", "metz", "lorient"] },
    2002: { name: "Ligue 1", size: 20, clubs: ["Lyon", "Monaco", "Marseille", "Nantes", "Nice", "PSG", "Strasbourg", "Lille"], others: ["girondins bordeaux|girondins de bordeaux|bordeaux", "sochaux montbeliard|sochaux", "auxerre", "en avant guingamp|guingamp", "lens", "bastia|s c bastiais", "stade rennais", "montpellier hsc|montpellier herault|montpellier", "ajaccio", "le havre|havre", "cs sedan ardennes|c s sedan ardennes|sedan", "es troyes|estac troyes|troyes"] },
    2003: { name: "Ligue 1", size: 20, clubs: ["Lyon", "PSG", "Monaco", "Nantes", "Marseille", "Lille", "Nice", "Strasbourg"], others: ["auxerre", "sochaux montbeliard|sochaux", "lens", "stade rennais", "girondins bordeaux|girondins de bordeaux|bordeaux", "metz", "ajaccio", "toulouse", "bastia|s c bastiais", "en avant guingamp|guingamp", "le mans uc72|le mans", "montpellier hsc|montpellier herault|montpellier"] },
    2004: { name: "Ligue 1", size: 20, clubs: ["Lyon", "Lille", "Monaco", "Marseille", "PSG", "Strasbourg", "Nice", "Nantes"], others: ["stade rennais", "saint etienne", "lens", "auxerre", "sochaux montbeliard|sochaux", "toulouse", "ajaccio", "girondins bordeaux|girondins de bordeaux|bordeaux", "metz", "stade malherbe caen|caen", "bastia|s c bastiais", "istres|f c istres ouest provence"] },
    2005: { name: "Ligue 1", size: 20, clubs: ["Lyon", "Lille", "Marseille", "Nice", "PSG", "Monaco", "Nantes", "Strasbourg"], others: ["girondins bordeaux|girondins de bordeaux|bordeaux", "lens", "auxerre", "stade rennais", "le mans uc|le mans", "nancy lorraine", "saint etienne", "sochaux montbeliard|sochaux", "toulouse", "es troyes|estac troyes|troyes", "ajaccio", "metz"] },
    2006: { name: "Ligue 1", size: 20, clubs: ["Lyon", "Marseille", "Monaco", "Lille", "PSG", "Nice", "Nantes"], others: ["toulouse", "stade rennais", "lens", "girondins bordeaux|girondins de bordeaux|bordeaux", "sochaux montbeliard|sochaux", "auxerre", "saint etienne", "le mans uc|le mans", "nancy lorraine", "lorient", "valenciennes", "es troyes|estac troyes|troyes", "cs sedan ardennes|c s sedan ardennes|sedan"] },
    2007: { name: "Ligue 1", size: 20, clubs: ["Lyon", "Marseille", "Lille", "Nice", "Monaco", "PSG", "Strasbourg"], others: ["girondins bordeaux|girondins de bordeaux|bordeaux", "nancy lorraine", "saint etienne", "stade rennais", "le mans uc|le mans", "lorient", "sm caen|stade malherbe caen|caen", "valenciennes", "sochaux montbeliard|sochaux", "auxerre", "toulouse", "lens", "metz"] },
    2008: { name: "Ligue 1", size: 20, clubs: ["Marseille", "Lyon", "Lille", "PSG", "Nice", "Monaco", "Nantes"], others: ["girondins bordeaux|girondins de bordeaux|bordeaux", "toulouse", "stade rennais", "auxerre", "lorient", "valenciennes", "grenoble foot|grenoble", "sochaux montbeliard|sochaux", "nancy lorraine", "le mans uc|le mans", "saint etienne", "sm caen|stade malherbe caen|caen", "le havre|havre"] },
    2009: { name: "Ligue 1", size: 20, clubs: ["Marseille", "Lyon", "Lille", "Monaco", "PSG", "Nice"], others: ["auxerre", "montpellier herault|montpellier", "girondins bordeaux|girondins de bordeaux|bordeaux", "lorient", "stade rennais", "valenciennes", "lens", "nancy lorraine", "toulouse", "sochaux montbeliard|sochaux", "saint etienne", "le mans uc|le mans", "boulogne sur mer co|u s boulogne cote d opale|boulogne", "grenoble foot|grenoble"] },
    2010: { name: "Ligue 1", size: 20, clubs: ["Lille", "Marseille", "Lyon", "PSG", "Nice", "Monaco"], others: ["sochaux montbeliard|sochaux", "stade rennais", "girondins bordeaux|girondins de bordeaux|bordeaux", "toulouse", "auxerre", "saint etienne", "lorient", "valenciennes", "nancy lorraine", "montpellier herault|montpellier", "sm caen|stade malherbe caen|caen", "stade brestois|brest", "lens", "arles avignon|a c arles avignon|arles"] },
    2011: { name: "Ligue 1", size: 20, clubs: ["PSG", "Lille", "Lyon", "Marseille", "Nice"], others: ["montpellier herault|montpellier", "girondins bordeaux|girondins de bordeaux|bordeaux", "stade rennais", "saint etienne", "toulouse", "evian thonon gaillard|evian thonon gaillard f c", "nancy lorraine", "valenciennes", "sochaux montbeliard|sochaux", "stade brestois|brest", "ajaccio", "lorient", "sm caen|stade malherbe caen|caen", "dijon fco", "auxerre"] },
    2012: { name: "Ligue 1", size: 20, clubs: ["PSG", "Marseille", "Lyon", "Nice", "Lille"], others: ["saint etienne", "girondins bordeaux|girondins de bordeaux|bordeaux", "lorient", "montpellier herault|montpellier", "toulouse", "valenciennes", "bastia|s c bastiais", "stade rennais", "stade de reims", "sochaux montbeliard|sochaux", "evian thonon gaillard|evian thonon gaillard f c", "ajaccio", "nancy lorraine", "es troyes|estac troyes|troyes", "stade brestois|brest"] },
    2013: { name: "Ligue 1", size: 20, clubs: ["PSG", "Monaco", "Lille", "Lyon", "Marseille", "Nantes", "Nice"], others: ["saint etienne", "girondins bordeaux|girondins de bordeaux|bordeaux", "lorient", "toulouse", "bastia|s c bastiais", "stade de reims", "stade rennais", "evian thonon gaillard|evian thonon gaillard f c", "montpellier herault|montpellier", "en avant guingamp|guingamp", "sochaux montbeliard|sochaux", "valenciennes", "ajaccio"] },
    2014: { name: "Ligue 1", size: 20, clubs: ["PSG", "Lyon", "Monaco", "Marseille", "Lille", "Nice", "Nantes"], others: ["saint etienne", "girondins bordeaux|girondins de bordeaux|bordeaux", "montpellier herault|montpellier", "stade rennais", "en avant guingamp|guingamp", "bastia|s c bastiais", "sm caen|stade malherbe caen|caen", "stade de reims", "lorient", "toulouse", "evian thonon gaillard|evian thonon gaillard f c", "metz", "lens"] },
    2015: { name: "Ligue 1", size: 20, clubs: ["PSG", "Lyon", "Monaco", "Nice", "Lille", "Marseille", "Nantes"], others: ["saint etienne", "sm caen|stade malherbe caen|caen", "stade rennais", "angers", "bastia|s c bastiais", "girondins bordeaux|girondins de bordeaux|bordeaux", "montpellier herault|montpellier", "lorient", "en avant guingamp|guingamp", "toulouse", "stade de reims", "gazelec ajaccio fco|gazelec ajaccio|gfc ajaccio", "es troyes|estac troyes|troyes"] },
    2016: { name: "Ligue 1", size: 20, clubs: ["Monaco", "PSG", "Nice", "Lyon", "Marseille", "Nantes", "Lille"], others: ["girondins bordeaux|girondins de bordeaux|bordeaux", "saint etienne", "stade rennais", "en avant guingamp|guingamp", "angers", "toulouse", "metz", "montpellier herault|montpellier", "dijon fco", "sm caen|stade malherbe caen|caen", "lorient", "nancy lorraine", "bastia|s c bastiais"] },
    2017: { name: "Ligue 1", size: 20, clubs: ["PSG", "Monaco", "Lyon", "Marseille", "Nice", "Nantes", "Strasbourg", "Lille"], others: ["stade rennais", "girondins bordeaux|girondins de bordeaux|bordeaux", "saint etienne", "montpellier herault|montpellier", "dijon fco", "en avant guingamp|guingamp", "amiens", "angers", "sm caen|stade malherbe caen|caen", "toulouse", "es troyes|estac troyes|troyes", "metz"] },
    2018: { name: "Ligue 1", size: 20, clubs: ["PSG", "Lille", "Lyon", "Marseille", "Nice", "Strasbourg", "Nantes", "Monaco"], others: ["saint etienne", "montpellier herault|montpellier", "stade de reims", "nimes olympique|nimes", "stade rennais", "angers", "girondins bordeaux|girondins de bordeaux|bordeaux", "amiens", "toulouse", "dijon fco", "sm caen|stade malherbe caen|caen", "en avant guingamp|guingamp"] },
    2019: { name: "Ligue 1", size: 20, clubs: ["PSG", "Marseille", "Lille", "Nice", "Lyon", "Monaco", "Strasbourg", "Nantes"], others: ["stade rennais", "stade de reims", "montpellier herault|montpellier", "angers", "girondins bordeaux|girondins de bordeaux|bordeaux", "stade brestois|brest", "metz", "dijon fco", "saint etienne", "nimes olympique|nimes", "amiens", "toulouse"] },
    2020: { name: "Ligue 1", size: 20, clubs: ["Lille", "PSG", "Monaco", "Lyon", "Marseille", "Nice", "Strasbourg", "Nantes"], others: ["stade rennais|rennes", "lens", "montpellier herault|montpellier", "metz", "saint etienne|st etienne", "girondins bordeaux|bordeaux", "angers", "stade de reims|reims", "lorient", "stade brestois|brest", "nimes olympique|nimes", "dijon fco|dijon"] },
    2021: { name: "Ligue 1", size: 20, clubs: ["PSG", "Marseille", "Monaco", "Nice", "Strasbourg", "Lyon", "Nantes", "Lille"], others: ["stade rennais", "lens", "stade brestois|brest", "stade de reims", "montpellier herault|montpellier", "angers", "es troyes|estac troyes|troyes", "lorient", "clermont foot auvergne|clermont foot", "saint etienne", "metz", "girondins bordeaux|girondins de bordeaux|bordeaux"] },
    2022: { name: "Ligue 1", size: 20, clubs: ["PSG", "Marseille", "Lille", "Monaco", "Lyon", "Nice", "Strasbourg", "Nantes"], others: ["lens", "stade rennais", "clermont foot auvergne|clermont foot", "lorient", "stade de reims", "montpellier herault|montpellier", "toulouse", "stade brestois|brest", "auxerre", "ajaccio", "es troyes|estac troyes|troyes", "angers"] },
    2023: { name: "Ligue 1", size: 18, clubs: ["PSG", "Monaco", "Lille", "Nice", "Lyon", "Marseille", "Strasbourg", "Nantes"], others: ["stade brestois|brest", "lens", "stade de reims", "stade rennais", "toulouse", "montpellier herault|montpellier", "le havre|havre athletic club", "metz", "lorient", "clermont foot auvergne|clermont foot"] },
    2024: { name: "Ligue 1", size: 18, clubs: ["PSG", "Marseille", "Monaco", "Nice", "Lille", "Lyon", "Strasbourg", "Nantes"], others: ["lens", "stade brestois|brest", "toulouse", "auxerre", "stade rennais", "angers", "le havre|havre athletic club", "stade de reims", "saint etienne", "montpellier herault|montpellier"] },
    2025: { name: "Ligue 1", size: 18, clubs: ["PSG", "Lille", "Lyon", "Marseille", "Monaco", "Strasbourg", "Nice", "Nantes"], others: ["lens", "stade rennais", "toulouse", "lorient", "paris", "stade brestois|brest", "angers", "le havre|havre athletic club", "auxerre", "metz"] }
  }
};

// src/lib/soccerCareerLeague.ts
var LEAGUE_SIZES = {
  "Premier League": [{ from: 1992, to: 1994, size: 22 }, { from: 1995, size: 20 }],
  "La Liga": [{ from: 1990, to: 1994, size: 20 }, { from: 1995, to: 1996, size: 22 }, { from: 1997, size: 20 }],
  "Bundesliga": [{ from: 1990, to: 1990, size: 18 }, { from: 1991, to: 1991, size: 20 }, { from: 1992, size: 18 }],
  "Serie A": [{ from: 1990, to: 2003, size: 18 }, { from: 2004, size: 20 }],
  "Ligue 1": [{ from: 1990, to: 1996, size: 20 }, { from: 1997, to: 2001, size: 18 }, { from: 2002, to: 2022, size: 20 }, { from: 2023, size: 18 }]
};
var DUGOUT_SIZES = {
  "Championship": [{ from: 2004, size: 24 }],
  /* Round 1040: Club Manager's Serie B is a manager's job now, so a Soccer
     Career dugout can be offered one. Only the 2026-27 season is read (20
     clubs: espn.com/soccer/standings/_/league/ita.2 and Sky Sport Italia's
     "Serie B 2026-27, le squadre del prossimo campionato", 2026-06-07, read
     2026-10-06), so no size is claimed before it. */
  "Serie B": [{ from: 2026, size: 20 }],
  /* The same for Ligue 2: 18 clubs in 2026-27 (espn.com/soccer/standings/
     _/league/fra.2 and Saint-Étienne's own Ligue 2 BKT table, asse.fr, both
     read 2026-10-06). */
  "Ligue 2": [{ from: 2026, size: 18 }],
  /* And the Segunda División: 22 clubs in 2026-27 (espn.com/soccer/standings/
     _/league/esp.2 and laliga.com's LALIGA HYPERMOTION table, both read
     2026-10-06). Club Manager plays 20 of them, but the dugout's table is
     the real league's size, the clubs it does not know unnamed. */
  "Segunda Divisi\xF3n": [{ from: 2026, size: 22 }]
};
function leagueSizeFor(league, year, dugout = false) {
  const ledger = year < LIST_SEASON ? CAREER_LEAGUE_SEASONS[league]?.[year] : void 0;
  if (ledger) return ledger.size;
  const windows = LEAGUE_SIZES[league] ?? (dugout ? DUGOUT_SIZES[league] : void 0);
  if (!windows) return null;
  for (const w of windows) {
    if (year >= w.from && (w.to === void 0 || year <= w.to)) return w.size;
  }
  return null;
}
function eliteInYear(elite, club, year) {
  if (!elite.includes(club)) return false;
  const [c] = adjustClubsForYear([{ id: club, name: club, country: "", tier: 1, color: "", league: "" }], year);
  return !!c && c.tier === 1;
}
function hashKey(key) {
  let h = 2166136261;
  for (let i = 0; i < key.length; i++) {
    h ^= key.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
function forkRng(key) {
  let a = hashKey(key) || 1;
  return () => {
    a = a + 1831565813 >>> 0;
    let t = a;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
function finishBand(tier, elite, size, rating) {
  const at = (share) => Math.round(share * size);
  let lo, hi;
  if (elite) {
    lo = 2;
    hi = Math.max(3, at(0.2));
  } else if (tier <= 1) {
    lo = 2;
    hi = at(0.4);
  } else if (tier === 2) {
    lo = at(0.25);
    hi = at(0.65);
  } else if (tier === 3) {
    lo = at(0.45);
    hi = size;
  } else {
    lo = at(0.65);
    hi = size;
  }
  const nudge = rating >= 7.5 ? -at(0.1) : rating < 6.3 ? at(0.1) : 0;
  lo = Math.min(size, Math.max(2, lo + nudge));
  hi = Math.min(size, Math.max(lo, hi + nudge));
  return [lo, hi];
}
function drawLeagueFinish(input) {
  const size = input.league === null ? null : leagueSizeFor(input.league, input.year);
  if (input.leagueTitle) return { leagueFinish: 1, ...size ? { leagueSize: size } : {} };
  if (!size) return {};
  const [lo, hi] = finishBand(input.tier, input.elite, size, input.rating);
  const rng = forkRng(input.seedKey);
  const finish = lo + Math.floor(rng() * (hi - lo + 1));
  return { leagueFinish: Math.min(size, Math.max(2, finish)), leagueSize: size };
}
var LIST_SEASON = 2026;
var foldName = (s) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
var clubKey = (name) => foldName(SC_CLUB_CANON[name] ?? name);
var IDENTITY_STOP = /* @__PURE__ */ new Set(["fc", "sc", "ac", "as", "ss", "us", "sv", "afc", "cf", "cfc", "vfl", "vfb", "tsg", "fsv", "spvgg", "calcio", "sco", "rc", "ogc", "aj", "sd", "ud", "cd", "rcd", "ca", "bsc"]);
function identityKey(name) {
  return name.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/ß/g, "ss").replace(/&/g, " and ").split(/[^a-z0-9]+/).filter((w) => w && !IDENTITY_STOP.has(w) && !/^\d+$/.test(w)).join(" ");
}
var MARKET_SPELLINGS = {
  "Gladbach": "Borussia Monchengladbach",
  "Karlsruhe": "Karlsruher SC",
  "Braunschweig": "Eintracht Braunschweig"
};
var ledgerIndex = null;
function ledgerByYear() {
  if (ledgerIndex) return ledgerIndex;
  const index = /* @__PURE__ */ new Map();
  for (const [key, years] of Object.entries(CAREER_LEAGUE_SEASONS)) {
    for (const [y, season2] of Object.entries(years)) {
      const year = Number(y);
      const byClub = index.get(year) ?? /* @__PURE__ */ new Map();
      for (const name of season2.clubs) {
        byClub.set(clubKey(name), { key, canon: name });
        byClub.set(`#${identityKey(name)}`, { key, canon: name });
      }
      for (const ids of season2.others) for (const id of ids.split("|")) byClub.set(`#${id}`, { key, canon: null });
      index.set(year, byClub);
    }
  }
  ledgerIndex = index;
  return index;
}
function ledgerMember(club, year) {
  const byClub = ledgerByYear().get(year);
  if (!byClub) return null;
  return byClub.get(clubKey(club)) ?? byClub.get(`#${identityKey(SC_CLUB_CANON[club] ?? MARKET_SPELLINGS[club] ?? club)}`) ?? null;
}
function ledgerLeague(key, year) {
  if (year >= LIST_SEASON) return null;
  const s = CAREER_LEAGUE_SEASONS[key]?.[year];
  return s ? { key, name: s.name, size: s.size, clubs: s.clubs, others: s.others } : null;
}
function clubLedgerSeason(club, year) {
  if (year >= LIST_SEASON) return null;
  const m = ledgerMember(club, year);
  const s = m ? ledgerLeague(m.key, year) : null;
  return s && m ? { ...s, canon: m.canon } : null;
}
function leagueKeyInYear(club, year) {
  if (year >= LIST_SEASON) return club.league || null;
  return clubLedgerSeason(club.name, year)?.key ?? null;
}

// src/lib/keyedRng.ts
function keyedRng(key) {
  let h = 2166136261;
  for (let i = 0; i < key.length; i += 1) {
    h ^= key.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  let a = h >>> 0;
  return () => {
    a = a + 1831565813 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

// src/lib/soccerCareerDerby.ts
init_clubRivalries();
var DERBY_CADENCE = {
  "Premier League": [{ from: 1990, meetings: 2 }],
  "La Liga": [{ from: 1990, meetings: 2 }],
  "Serie A": [{ from: 1990, meetings: 2 }],
  "Bundesliga": [{ from: 1990, meetings: 2 }],
  "Ligue 1": [{ from: 1990, to: 2018, meetings: 2 }, { from: 2020, meetings: 2 }],
  "Primeira Liga": [{ from: 1990, meetings: 2 }],
  "Brasileirao": [{ from: 2003, meetings: 2 }],
  "Liga MX": [{ from: 1996, to: 2018, meetings: 2 }, { from: 2020, meetings: 2 }]
};
function derbyMeetings(league, year) {
  const windows = DERBY_CADENCE[league];
  if (!windows) return null;
  for (const w of windows) {
    if (year >= w.from && (w.to === void 0 || year <= w.to)) return w.meetings;
  }
  return null;
}
function derbyLeague(club, league, year) {
  return leagueKeyInYear({ name: club, league }, year);
}
function canonClub(scName) {
  return SC_CLUB_CANON[scName] ?? scName;
}
function seasonDerbies(input) {
  const { club, year, clubs } = input;
  const league = derbyLeague(club, input.league, year);
  if (league === null || derbyMeetings(league, year) === null) return [];
  const canon = canonClub(club);
  const world = adjustClubsForYear(clubs, year);
  const detected = [];
  for (const row of CLUB_RIVALRIES) {
    if (row.a !== canon && row.b !== canon) continue;
    const other = row.a === canon ? row.b : row.a;
    const rival = world.find((c) => c.name !== club && canonClub(c.name) === other && derbyLeague(c.name, c.league, year) === league);
    if (!rival) continue;
    detected.push({ rival: rival.name, name: row.name, kind: row.kind });
  }
  return detected;
}
var DERBY_BASE_WIN = 0.36;
var DERBY_TIER_STEP = 0.1;
var DERBY_HOME = 0.06;
var DERBY_TITLE_NUDGE = 0.08;
var DERBY_P_MIN = 0.08;
var DERBY_P_MAX = 0.66;
var DERBY_DRAW = 0.27;
var clampN = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
function playDerbyMeeting(rng, myStr, theirStr, home, titleSeason) {
  const pWin = clampN(
    DERBY_BASE_WIN + DERBY_TIER_STEP * (myStr - theirStr) + (home ? DERBY_HOME : -DERBY_HOME) + (titleSeason ? DERBY_TITLE_NUDGE : 0),
    DERBY_P_MIN,
    DERBY_P_MAX
  );
  const r = rng();
  if (r < pWin || r >= pWin + DERBY_DRAW) {
    const top = 1 + Math.floor(rng() * 3);
    const low = Math.floor(rng() * top);
    return r < pWin ? { gf: top, ga: low } : { gf: low, ga: top };
  }
  const g = Math.floor(rng() * 3);
  return { gf: g, ga: g };
}
function clubStrength(clubs, name, year, elite) {
  const c = clubs.find((x) => x.name === name);
  const tier = c ? c.tier : 4;
  return 5 - tier + (eliteInYear(elite, name, year) ? 0.5 : 0);
}
function resolveSeasonDerbies(input) {
  const found = seasonDerbies(input);
  const league = derbyLeague(input.club, input.league, input.year);
  const meetings = league === null ? null : derbyMeetings(league, input.year);
  if (found.length === 0 || meetings === null) return [];
  const world = adjustClubsForYear(input.clubs, input.year);
  const myStr = clubStrength(world, input.club, input.year, input.elite);
  const isGK = input.position === "GK";
  const q = clampN(input.goals / Math.max(input.apps, 1) / 1.6, 0, 0.6);
  let goalsLeft = isGK ? 0 : Math.max(0, input.goals);
  const resolved = [];
  for (const d of found) {
    const rng = keyedRng(`${input.seedKey}|${d.rival}`);
    const theirStr = clubStrength(world, d.rival, input.year, input.elite);
    const homeFirst = rng() < 0.5;
    const list2 = [];
    for (let i = 0; i < meetings; i += 1) {
      const home = i % 2 === 0 === homeFirst;
      const played = rng() < input.leagueApps / 38;
      const { gf, ga } = playDerbyMeeting(rng, myStr, theirStr, home, input.leagueTitle);
      let goals = 0;
      let won = false;
      for (let k = 1; k <= gf; k += 1) {
        const mine = rng() < q;
        if (!played || !mine || goalsLeft <= 0) continue;
        goals += 1;
        goalsLeft -= 1;
        if (gf > ga && k === ga + 1) won = true;
      }
      const m = { home, gf, ga, played, goals };
      if (won) m.won = true;
      list2.push(m);
    }
    resolved.push({ rival: d.rival, name: d.name, kind: d.kind, meetings: list2 });
  }
  return resolved;
}
var KINDS = ["derby", "rivalry"];
var isCount = (v) => typeof v === "number" && Number.isInteger(v) && v >= 0 && v < 100;
function readMeeting(m) {
  if (!m || typeof m !== "object") return null;
  const o = m;
  if (typeof o.home !== "boolean" || typeof o.played !== "boolean") return null;
  if (!isCount(o.gf) || !isCount(o.ga) || !isCount(o.goals)) return null;
  if (o.won !== void 0 && o.won !== true) return null;
  const out = { home: o.home, gf: o.gf, ga: o.ga, played: o.played, goals: o.goals };
  if (o.won === true) out.won = true;
  return out;
}
function readSeasonDerbies(season2) {
  if (!season2 || typeof season2 !== "object") return [];
  const raw = season2.derbies;
  if (!Array.isArray(raw)) return [];
  const read = [];
  for (const d of raw) {
    if (!d || typeof d !== "object") return [];
    const o = d;
    if (typeof o.rival !== "string" || !o.rival || typeof o.name !== "string" || !o.name) return [];
    if (typeof o.kind !== "string" || !KINDS.includes(o.kind) || !Array.isArray(o.meetings) || o.meetings.length === 0) return [];
    const meetings = [];
    for (const m of o.meetings) {
      const ok = readMeeting(m);
      if (!ok) return [];
      meetings.push(ok);
    }
    read.push({ rival: o.rival, name: o.name, kind: o.kind, meetings });
  }
  return read;
}
function derbyRecord(derbies) {
  const r = { played: 0, w: 0, d: 0, l: 0, goals: 0, heroes: 0 };
  for (const x of derbies) {
    for (const m of x.meetings) {
      if (!m.played) continue;
      r.played += 1;
      if (m.gf > m.ga) r.w += 1;
      else if (m.gf < m.ga) r.l += 1;
      else r.d += 1;
      r.goals += m.goals;
      if (m.won) r.heroes += 1;
    }
  }
  return r;
}
function theName(name) {
  return /^(El|Der|Le|La|O|Il|Lo|Les) /.test(name) ? name : `the ${name}`;
}
function resultLetter(m) {
  return m.gf > m.ga ? "W" : m.gf < m.ga ? "L" : "D";
}
function derbyLogLine(d) {
  const parts = d.meetings.map((m) => `${resultLetter(m)} ${m.gf}-${m.ga} ${m.home ? "at home" : "away"}${m.played ? "" : " (you missed it)"}`);
  return `\u{1F525} ${d.name} against ${d.rival}: ${parts.join(", ")}.`;
}
var DERBY_WIN_POP = 2;
var DERBY_WIN_MORALE = 2;
var DERBY_LOSS_POP = -2;
var DERBY_LOSS_MORALE = -2;
var DERBY_HERO_POP = 2;
var DERBY_POP_MIN = -4;
var DERBY_POP_MAX = 6;
var DERBY_MORALE_MIN = -4;
var DERBY_MORALE_MAX = 4;
var DERBY_HELP_RULES = [
  "Derbies: if your club has a real rival in the same league, you meet them twice a season in the league. We only count a rivalry two separate sources back, in leagues and years where we checked how often the clubs meet, so some clubs have none yet.",
  `You play the derbies you are picked for, roughly in line with your league appearances. Each one you win adds ${DERBY_WIN_POP} popularity and ${DERBY_WIN_MORALE} morale, each one you lose takes ${-DERBY_LOSS_POP} off both, a draw changes nothing, the swing is capped every season and your rating is never touched.`,
  `Score the goal that puts you ahead for good in a derby win and the season counts as a Derby Hero season, worth ${DERBY_HERO_POP} more popularity. Example: at Arsenal you beat Tottenham 2-1 at home with the winner and draw 1-1 away, so that is +${DERBY_WIN_POP + DERBY_HERO_POP} popularity, +${DERBY_WIN_MORALE} morale and a Derby Hero.`
];
function applySeasonDerbies(s, season2) {
  const derbies = readSeasonDerbies(season2);
  if (derbies.length === 0) return;
  let pop = 0;
  let mor = 0;
  for (const d of derbies) {
    for (const m of d.meetings) {
      if (!m.played) continue;
      if (m.gf > m.ga) {
        pop += DERBY_WIN_POP;
        mor += DERBY_WIN_MORALE;
      } else if (m.gf < m.ga) {
        pop += DERBY_LOSS_POP;
        mor += DERBY_LOSS_MORALE;
      }
    }
    s.events.push(derbyLogLine(d));
    if (d.meetings.some((m) => m.won)) s.events.push(`\u{1F525} Your goal won ${theName(d.name)}. Derby Hero.`);
  }
  if (derbyRecord(derbies).heroes > 0) pop += DERBY_HERO_POP;
  pop = clampN(pop, DERBY_POP_MIN, DERBY_POP_MAX);
  mor = clampN(mor, DERBY_MORALE_MIN, DERBY_MORALE_MAX);
  s.popularity = clampN(s.popularity + pop, 0, 100);
  s.morale = clampN(s.morale + mor, 0, 100);
}

// src/lib/soccerCareerCup.ts
var DOMESTIC_CUPS = {
  England: [
    { from: 1990, to: 1997, kind: "NAMED", name: "FA Cup", legs: 1, decider: "replay" },
    { from: 1998, kind: "NAMED", name: "FA Cup", legs: 1, decider: "penalties" }
  ],
  Scotland: [{ from: 1990, kind: "NAMED", name: "Scottish Cup", legs: 1, decider: "penalties" }],
  Spain: [{ from: 1990, kind: "NAMED", name: "Copa del Rey", legs: 1, decider: "penalties" }],
  Italy: [
    { from: 1990, to: 2006, kind: "NAMED", name: "Coppa Italia", legs: 2, decider: "awayGoals" },
    { from: 2007, kind: "NAMED", name: "Coppa Italia", legs: 1, decider: "penalties" }
  ],
  Germany: [{ from: 1990, kind: "NAMED", name: "DFB-Pokal", legs: 1, decider: "penalties" }],
  France: [
    { from: 1990, to: 1990, kind: "NAMED", name: "Coupe de France", legs: 1, decider: "penalties" },
    { from: 1991, to: 1991, kind: "NONE", why: "stopped after the Furiani disaster in May 1992, no final and no winner" },
    { from: 1992, kind: "NAMED", name: "Coupe de France", legs: 1, decider: "penalties" }
  ],
  Netherlands: [
    { from: 1990, to: 2008, kind: "NAMED", name: "KNVB Cup", legs: 1, decider: "penalties" },
    { from: 2009, to: 2009, kind: "NAMED", name: "KNVB Cup", legs: 2 },
    { from: 2010, to: 2018, kind: "NAMED", name: "KNVB Cup", legs: 1, decider: "penalties" },
    { from: 2019, to: 2019, kind: "NONE", why: "the final was postponed and then cancelled, no winner was named" },
    { from: 2020, kind: "NAMED", name: "KNVB Cup", legs: 1, decider: "penalties" }
  ],
  Portugal: [
    { from: 1990, to: 1999, kind: "NAMED", name: "Ta\xE7a de Portugal", legs: 1, decider: "replay" },
    { from: 2e3, to: 2013, kind: "NAMED", name: "Ta\xE7a de Portugal", legs: 1, why: "no final was level after extra time, and the season the replay gave way to penalties is not two sourced" },
    { from: 2014, kind: "NAMED", name: "Ta\xE7a de Portugal", legs: 1, decider: "penalties" }
  ],
  Turkey: [
    { from: 1990, to: 1990, kind: "NAMED", name: "Federation Cup", legs: 1 },
    { from: 1991, to: 1991, kind: "NAMED", name: "Federation Cup", legs: 2 },
    { from: 1992, to: 1998, kind: "NAMED", name: "Turkish Cup", legs: 2 },
    { from: 1999, kind: "NAMED", name: "Turkish Cup", legs: 1, decider: "penalties" }
  ],
  Greece: [
    { from: 1990, to: 1991, kind: "NAMED", name: "Greek Cup", legs: 2 },
    { from: 1992, kind: "NAMED", name: "Greek Cup", legs: 1, decider: "penalties" }
  ],
  Belgium: [{ from: 1990, kind: "NAMED", name: "Belgian Cup", why: "one match finals in every season rest on one source, so no final score" }],
  Japan: [
    { from: 1990, to: 2019, kind: "NAMED", name: "Emperor's Cup", legs: 1, decider: "penalties" },
    { from: 2020, to: 2020, kind: "UNKNOWN", why: "the COVID edition: only the top two J1 clubs entered" },
    { from: 2021, to: 2025, kind: "NAMED", name: "Emperor's Cup", legs: 1, decider: "penalties" },
    { from: 2026, kind: "UNKNOWN", why: "the J.League moves to an autumn to spring season in 2026 and the 106th edition was not researched" }
  ],
  "South Korea": [
    { from: 1990, to: 1995, kind: "NONE", why: "the KFA founded the cup in 1996" },
    { from: 1996, to: 2023, kind: "NAMED", name: "Korean FA Cup", why: "the final's legs by season rest on one source, and a checker found that source contradicted, so no final score" },
    { from: 2024, kind: "UNKNOWN", why: "the rename to Korea Cup rests on one source" }
  ],
  Brazil: [
    { from: 1990, to: 2025, kind: "UNKNOWN", why: "entry went by state championship places, not division, and the Libertadores clubs were excused 2001 to 2012" },
    { from: 2026, kind: "NAMED", name: "Copa do Brasil", legs: 1, why: "all 20 Serie A clubs enter; whether extra time comes before penalties in the one match final is disputed" }
  ],
  USA: [
    { from: 1990, to: 1995, kind: "UNKNOWN", why: "no MLS before 1996" },
    { from: 1996, to: 1999, kind: "UNKNOWN", why: "only some MLS clubs entered" },
    { from: 2e3, to: 2001, kind: "NAMED", name: "U.S. Open Cup", legs: 1 },
    { from: 2002, to: 2002, kind: "UNKNOWN", why: "only some MLS clubs entered" },
    { from: 2003, to: 2006, kind: "NAMED", name: "U.S. Open Cup", legs: 1 },
    { from: 2007, to: 2011, kind: "UNKNOWN", why: "the top six MLS clubs entered and the rest qualified" },
    { from: 2012, to: 2019, kind: "NAMED", name: "U.S. Open Cup", legs: 1 },
    { from: 2020, to: 2021, kind: "NONE", why: "cancelled both years (COVID-19)" },
    { from: 2022, to: 2023, kind: "NAMED", name: "U.S. Open Cup", legs: 1 },
    { from: 2024, kind: "UNKNOWN", why: "from 2024 only some MLS clubs enter" }
  ],
  Canada: [
    { from: 1990, to: 2007, kind: "NONE", why: "the Canadian Championship began in 2008, and Canadian clubs cannot enter the U.S. Open Cup" },
    { from: 2008, to: 2010, kind: "UNKNOWN", why: "a round robin of three clubs, no final" },
    { from: 2011, to: 2019, kind: "NAMED", name: "Canadian Championship", legs: 2, decider: "awayGoals" },
    { from: 2020, to: 2020, kind: "UNKNOWN", why: "one final between the top Canadian MLS club and the CPL winner" },
    { from: 2021, to: 2021, kind: "NAMED", name: "Canadian Championship", legs: 1 },
    { from: 2022, to: 2023, kind: "NAMED", name: "Canadian Championship", why: "the one match finals of 2022 and 2023 rest on one source, so no final score" },
    { from: 2024, to: 2024, kind: "NAMED", name: "Canadian Championship", legs: 1, decider: "penalties" },
    { from: 2025, kind: "NAMED", name: "Canadian Championship", legs: 1, why: "a one match final; penalties are two sourced for 2024 only" }
  ],
  Mexico: [
    { from: 1990, to: 1996, kind: "UNKNOWN", why: "the Copa Mexico seasons of the early 1990s rest on one source" },
    { from: 1997, to: 2011, kind: "NONE", why: "no cup from 1997-98 until the Apertura 2012" },
    { from: 2012, to: 2019, kind: "UNKNOWN", why: "two editions a season, and clubs in continental play sat it out" },
    { from: 2020, kind: "NONE", why: "no cup since 2019-20; a return was announced in August 2026 with nothing confirmed" }
  ],
  Argentina: [
    { from: 1990, to: 1992, kind: "NONE", why: "no Copa Argentina between 1970 and 2011-12" },
    { from: 1993, to: 1993, kind: "UNKNOWN", why: "the AFA's Copa Centenario, a knockout cup for the first division clubs, ran from June 1993 to January 1994; whether it counts as that season's domestic cup was not researched" },
    { from: 1994, to: 2010, kind: "NONE", why: "no Copa Argentina between 1970 and 2011-12" },
    { from: 2011, kind: "UNKNOWN", why: "13 editions over 15 seasons across the switch to calendar years and the COVID break, so which season played which edition is not two sourced" }
  ],
  "New Zealand": [
    { from: 1990, to: 2025, kind: "UNKNOWN", why: "the New Zealand A-League clubs played the Australia Cup in some years, entry not researched by year" },
    { from: 2026, kind: "NONE", why: "Auckland FC and Wellington Phoenix enter no Australia Cup from 2026 and no other domestic cup" }
  ],
  "Saudi Arabia": [{ from: 1990, kind: "UNKNOWN", why: "every fact read rests on one source" }]
};
var CROSS_BORDER = {
  Wales: { leagues: ["Premier League", "Championship", "League One", "League Two"], association: "England" },
  Monaco: { leagues: ["Ligue 1", "Ligue 2"], association: "France" }
};
function cupAssociation(country, league) {
  const x = CROSS_BORDER[country];
  return x && x.leagues.includes(league) ? x.association : country;
}
function cupFor(association, year) {
  const windows = DOMESTIC_CUPS[association];
  if (!windows || windows.length === 0 || year < windows[0].from) return { kind: "UNKNOWN", association };
  let w = windows[windows.length - 1];
  for (const x of windows) {
    if (year >= x.from && (x.to === void 0 || year <= x.to)) {
      w = x;
      break;
    }
  }
  if (w.kind === "NAMED" && w.name) {
    return { kind: "NAMED", association, name: w.name, ...w.legs ? { legs: w.legs } : {}, ...w.decider ? { decider: w.decider } : {} };
  }
  return w.kind === "NONE" ? { kind: "NONE", association } : { kind: "UNKNOWN", association };
}
var WORLD_LEAGUE_ASSOCIATION = {
  "Premier League": "England",
  "La Liga": "Spain",
  "Bundesliga": "Germany",
  "Serie A": "Italy",
  "Ligue 1": "France",
  "Primeira Liga": "Portugal",
  "Eredivisie": "Netherlands",
  "Scottish Premiership": "Scotland",
  "Brasileirao": "Brazil",
  "Saudi Pro League": "Saudi Arabia",
  "MLS": "USA",
  "K League 1": "South Korea"
};
function worldLeagueOf(association) {
  for (const [lg, a] of Object.entries(WORLD_LEAGUE_ASSOCIATION)) if (a === association) return lg;
  return null;
}
function seasonPerformanceBoost(overall, rating) {
  return overall >= 85 && rating >= 7.5 ? 0.15 : overall >= 80 && rating >= 7 ? 0.1 : overall >= 75 && rating >= 6.8 ? 0.05 : 0;
}
function cupChanceFor(input) {
  const base = input.elite ? 0.35 : input.tier === 1 ? 0.2 : input.tier === 2 ? 0.15 : 0.05;
  return Math.min(0.6, base + input.performanceBoost);
}
var NAMED_STAGES = ["QF", "SF", "F"];
var TIE_LAMBDA_HI = 1.45;
var TIE_LAMBDA_LO = 1;
var EXTRA_TIME_SETTLES = 0.6;
function cupOpponentPool(association, year, club, clubs) {
  const seen = /* @__PURE__ */ new Set([club]);
  const out = [];
  for (const c of adjustClubsForYear(clubs, year)) {
    if (seen.has(c.name) || cupAssociation(c.country, c.league) !== association) continue;
    seen.add(c.name);
    out.push(c);
  }
  return out;
}
function drawCupRun(input) {
  const { status } = input;
  if (status.kind === "NONE") return null;
  const all = cupOpponentPool(status.association, input.year, input.club, input.clubs);
  const winner = input.worldWinner && all.some((c) => c.name === input.worldWinner) ? input.worldWinner : null;
  const pool = all.filter((c) => c.name !== winner);
  const named = Math.min(NAMED_STAGES.length, pool.length);
  if (status.kind === "UNKNOWN" ? named < NAMED_STAGES.length : named < 1) return null;
  const stages = ["early", ...NAMED_STAGES.slice(NAMED_STAGES.length - named)];
  const k = stages.length;
  const rng = keyedRng(`${input.seedKey}|cup`);
  const p = Math.pow(Math.min(0.999, Math.max(1e-3, input.chance)), 1 / k);
  let exit = k;
  if (!input.won) {
    let u = rng() * (1 - Math.pow(p, k));
    exit = k - 1;
    for (let i = 0; i < k; i++) {
      const w = Math.pow(p, i) * (1 - p);
      if (u < w) {
        exit = i;
        break;
      }
      u -= w;
    }
  }
  const opps = {};
  const left = pool.slice();
  for (let i = k - 1; i >= 1; i--) {
    if (i > exit) continue;
    if (stages[i] === "F" && exit === i && winner) {
      opps[i] = winner;
      continue;
    }
    const power = stages[i] === "F" ? 2 : stages[i] === "SF" ? 1.5 : 1;
    const weights = left.map((c) => Math.pow(1 / Math.max(1, c.tier), power));
    let u = rng() * weights.reduce((a, b) => a + b, 0);
    let j = 0;
    while (j < left.length - 1 && u >= weights[j]) {
      u -= weights[j];
      j++;
    }
    opps[i] = left[j].name;
    left.splice(j, 1);
  }
  const score2 = (won, legs, level) => {
    let a = 0, b = 0;
    for (let l = 0; l < legs; l++) {
      a += poissonGoals(TIE_LAMBDA_HI, rng);
      b += poissonGoals(TIE_LAMBDA_LO, rng);
    }
    let hi = Math.max(a, b), lo = Math.min(a, b);
    if (hi === lo && (!level || rng() < EXTRA_TIME_SETTLES)) hi += 1;
    return won ? [hi, lo] : [lo, hi];
  };
  const out = [];
  let final;
  for (let i = 0; i < k && i <= exit; i++) {
    const won = i < exit;
    const stage = stages[i];
    if (stage === "early") {
      out.push({ stage, won });
      continue;
    }
    if (stage !== "F") {
      const [f2, a2] = score2(won, 1, false);
      const home = rng() < 0.5;
      out.push({ stage, opp: opps[i], won, for: f2, against: a2, ...stage === "QF" ? { home } : {} });
      continue;
    }
    out.push({ stage, opp: opps[i], won });
    if (status.kind !== "NAMED" || !status.legs) continue;
    const legs = status.legs;
    const [f, a] = score2(won, legs, status.decider === "penalties");
    final = { for: f, against: a, legs };
    if (f === a) {
      const w = 3 + Math.floor(rng() * 3);
      const l = Math.max(0, w - 1 - (rng() < 0.4 ? 1 : 0));
      final.decidedBy = "penalties";
      final.pensFor = won ? w : l;
      final.pensAgainst = won ? l : w;
    }
    if (input.goals > 0 && f > 0) {
      const perGame = Math.min(0.8, input.goals / Math.max(1, input.apps));
      if (rng() < 1 - Math.pow(1 - perGame, legs)) final.scored = true;
    }
  }
  return { ...status.kind === "NAMED" ? { cup: status.name } : {}, stages: out, ...final ? { final } : {} };
}
var ORDER = ["early", "QF", "SF", "F"];
var goalsOk = (n) => typeof n === "number" && Number.isInteger(n) && n >= 0 && n <= 30;
var nameOk = (s) => typeof s === "string" && s.length > 0 && s.length <= 60;
function readCupRun(row) {
  if (!row || typeof row !== "object") return null;
  const r = row;
  const raw = r.cupRun;
  if (!raw || typeof raw !== "object" || !Array.isArray(raw.stages)) return null;
  const list2 = raw.stages;
  if (list2.length < 1 || list2.length > ORDER.length) return null;
  const stages = [];
  let last = -1;
  for (let i = 0; i < list2.length; i++) {
    const t = list2[i];
    if (!t || typeof t !== "object" || typeof t.won !== "boolean") return null;
    const at = ORDER.indexOf(t.stage);
    if (at <= last || i === 0 !== (at === 0)) return null;
    last = at;
    if (!t.won && i !== list2.length - 1) return null;
    const tie = { stage: t.stage, won: t.won };
    if (at > 0) {
      if (!nameOk(t.opp)) return null;
      tie.opp = t.opp;
    }
    if (t.stage === "QF" || t.stage === "SF") {
      if (!goalsOk(t.for) || !goalsOk(t.against) || t.for === t.against || t.for > t.against !== t.won) return null;
      Object.assign(tie, { for: t.for, against: t.against });
      if (t.stage === "QF") {
        if (typeof t.home !== "boolean") return null;
        tie.home = t.home;
      }
    }
    stages.push(tie);
  }
  const end = stages[stages.length - 1];
  const won = end.stage === "F" && end.won;
  if (won !== (r.domesticCup === true)) return null;
  const run = { stages };
  if (raw.cup !== void 0) {
    if (!nameOk(raw.cup)) return null;
    run.cup = raw.cup;
  }
  if (raw.final !== void 0) {
    const f = raw.final;
    if (!f || typeof f !== "object" || end.stage !== "F" || !goalsOk(f.for) || !goalsOk(f.against) || f.legs !== 1 && f.legs !== 2) return null;
    const final = { for: f.for, against: f.against, legs: f.legs };
    if (f.decidedBy !== void 0 || f.pensFor !== void 0 || f.pensAgainst !== void 0) {
      const { pensFor: pf, pensAgainst: pa } = f;
      if (f.decidedBy !== "penalties" || f.for !== f.against || !goalsOk(pf) || !goalsOk(pa) || pf === pa || pf > pa !== won) return null;
      Object.assign(final, { decidedBy: "penalties", pensFor: pf, pensAgainst: pa });
    } else if (f.for === f.against || f.for > f.against !== won) return null;
    if (f.scored === true) {
      if (f.for < 1) return null;
      final.scored = true;
    }
    run.final = final;
  }
  return run;
}
function cupTitle(name) {
  return name ?? "Domestic Cup";
}

// src/lib/soccerPhone.ts
var MAX_LINES = 6;
var MAX_THREADS = 8;
var MAX_FEED = 12;
var MAX_WORLD_NAMES = 28;
var MAX_SEEN = 8;
function nextSeed(s) {
  return s * 1664525 + 1013904223 >>> 0;
}
var Rng = class {
  constructor(s) {
    this.s = s;
    this.s = s >>> 0 || 1;
  }
  next() {
    this.s = nextSeed(this.s);
    return this.s / 4294967296;
  }
  get state() {
    return this.s;
  }
  int(lo, hi) {
    return lo + Math.floor(this.next() * (hi - lo + 1));
  }
  pick(arr) {
    return arr[Math.floor(this.next() * arr.length)];
  }
};
var clamp2 = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
var CONTACTS = [
  { id: "mum", name: "Mum", emoji: "\u2764\uFE0F", blurb: "Answers on the first ring" },
  { id: "dad", name: "Dad", emoji: "\u{1F9D4}", blurb: "Watched every minute you ever played" },
  { id: "grandad", name: "Grandad", emoji: "\u{1F9D3}", blurb: "Shouts at the telly on your behalf" },
  { id: "partner", name: "Your partner", emoji: "\u{1F49E}", blurb: "The one who sees the bad days" },
  { id: "bestmate", name: "Best mate", emoji: "\u{1F919}", blurb: "Knew you before any of this" },
  { id: "agent", name: "Your agent", emoji: "\u{1F4BC}", blurb: "Always half a deal ahead of you" },
  { id: "gaffer", name: "The gaffer", emoji: "\u{1F4CB}", blurb: "Picks the team, picks his words" },
  { id: "captain", name: "Club captain", emoji: "\u{1F981}", blurb: "Runs the dressing room" },
  { id: "roomie", name: "Away room mate", emoji: "\u{1F634}", blurb: "Snores, shares everything else" },
  { id: "physio", name: "Club physio", emoji: "\u{1FA79}", blurb: "Knows your body better than you" },
  { id: "fitness", name: "Fitness coach", emoji: "\u{1F3CB}\uFE0F", blurb: "Owns the sadistic clipboard" },
  { id: "youthcoach", name: "Old youth coach", emoji: "\u{1F474}", blurb: "Still calls you kid" },
  { id: "academy", name: "Academy kid", emoji: "\u{1F331}", blurb: "Looks at you the way you looked at someone" },
  { id: "kitman", name: "Kit man", emoji: "\u{1F9FA}", blurb: "Has seen forty years of you lot" },
  { id: "journo", name: "Journalist", emoji: "\u{1F4F0}", blurb: "Friendly until he is not" },
  { id: "natcoach", name: "Country manager", emoji: "\u{1F30D}", blurb: "Names the squad in March" },
  { id: "rival", name: "Rival", emoji: "\u{1FA9E}", blurb: "The name next to yours, forever" }
];
var CONTACT_BY_ID = Object.fromEntries(CONTACTS.map((c) => [c.id, c]));
function contactName(id, s) {
  if (id === "rival" && s.rival?.name) return s.rival.name;
  if (id === "natcoach") return `${s.nationality} manager`;
  return CONTACT_BY_ID[id]?.name ?? id;
}
function contactEmoji(id) {
  return CONTACT_BY_ID[id]?.emoji ?? "\u{1F4AC}";
}
function contactAvailable(id, s, phase) {
  switch (id) {
    case "partner":
      return !!s.hasRelationship || !!s.family?.isMarried;
    case "rival":
      return !!s.rival && !s.rival.retired;
    case "natcoach":
      return !!s.internationalCareer;
    case "gaffer":
    case "captain":
    case "roomie":
    case "physio":
    case "kitman":
      return phase === "pro";
    case "journo":
      return phase === "pro" && s.age >= 19;
    case "academy":
      return phase === "youth" || s.age >= 21;
    default:
      return true;
  }
}
var R = (label, say, back, warm = 6, extra = {}) => ({ label, say, back, warm, ...extra });
var B = (text2, ...replies) => ({ text: text2, replies });
var C = (id, contact, phase, beats, opts = {}) => ({ id, contact, phase, beats, starter: true, ...opts });
var CONVOS = [
  /* ── Mum ── */
  C("mum_checkin", "mum", "any", [
    B(
      "Just checking you are eating something other than chicken and rice. Are you?",
      R("Send her a photo of dinner", "Sending you a photo. There are vegetables on it. Two kinds", "TWO kinds. My son. Look at you", 8, { morale: 3 }),
      R("Be honest", "Chicken and rice. Every day. I have made peace with it", "You are a professional athlete not a prisoner. I am posting you a lasagne", 6, { morale: 2 }),
      R("Turn it round on her", "Are YOU eating properly is the question", "Do not do that. Answer the question", 4)
    ),
    B(
      "Right. Next thing. Are you sleeping? And do not say fine.",
      R("Tell her the truth", "Not brilliant. Head is loud after games", "Then ring me after games instead of lying in the dark. Any time. I mean it", 9, { morale: 5, perk: "calm" }),
      R("Say you are fine", "I am fine mum", "You said fine. I said do not say fine", 3),
      R("Make her laugh", "I sleep like a baby. Wake up every two hours crying", "Cheeky. Go to bed", 6, { morale: 2 })
    ),
    B(
      "One more thing and I will leave you alone. Sunday dinner. Yes or no.",
      R("Yes", "Yes. What time", "One o clock and do not be late like your father", 9, { morale: 5 }),
      R("Bring the whole squad", "Can I bring two of the lads? They live on their own", "Two? I will do a leg of lamb. Tell them to bring nothing", 10, { morale: 6, perk: "lift" }),
      R("Cannot", "Away game Sunday mum", "Then the Sunday after. I am writing it down", 4)
    )
  ]),
  C("mum_proud", "mum", "any", [
    B(
      "Your nan told the whole street about you again. She has a photo in her purse and everything.",
      R("Send something for nan", "Tell her I am sending a signed shirt for the purse photo wall", "She is going to cry. Then she is going to tell the street again", 9, { karma: 4, morale: 3 }),
      R("Be embarrassed", "Mum that is so embarrassing please stop her", "Absolutely not. Let the woman have this", 5),
      R("Leave it", "Ok", "Ok? That is all I get? Ok?", -2, { warm: -2 })
    ),
    B(
      "She asked if you are happy. Not doing well. Happy. I said I would ask properly.",
      R("Say yes and mean it", "Honestly? Yeah. Tired, but yeah", "Good. That is the only bit I actually worry about", 8, { morale: 4 }),
      R("Admit it is heavy", "Some weeks it is a lot mum", "Then come home for a weekend. The kettle works and nobody wants anything from you here", 9, { morale: 6, perk: "calm" }),
      R("Dodge it", "Ask me after Saturday", "That is not an answer and you know it", 2)
    ),
    B(
      "She wants to know if you will come to the street party when you next win something.",
      R("Say yes", "If we win anything I am coming home with it. Tell her to get the bunting", "The bunting has been in the loft for two years waiting", 10, { karma: 4, morale: 4 }),
      R("Say it is too much", "I would get mobbed mum", "You would get fed. Different thing", 5)
    )
  ]),
  C("mum_worry", "mum", "any", [
    B(
      "I saw what they were saying about you online. I know you say do not read it. I read it.",
      R("Tell her to stop reading", "Mum. Log off. Please. It is noise", "It is my son they are talking about. But fine. Logging off", 7, { morale: 2 }),
      R("Let her be angry", "Go on then. Say what you want to say", "I want to say they have never kicked a ball in their lives. There. Done", 8, { morale: 4 }),
      R("Laugh it off", "Half of them are twelve mum", "The other half are grown men which is worse", 6, { morale: 2 })
    ),
    B(
      "Promise me you are talking to someone about it. Not just me at midnight.",
      R("Promise properly", "I will talk to the club doc this week. Promise", "Good boy. Now go and win something", 9, { morale: 5, karma: 3, perk: "calm" }),
      R("Say you have got it", "I have got it. Really", "Hm. I am checking back in a month", 4)
    ),
    B(
      "And do me a favour. Do not read the comments before a game. Read them never actually.",
      R("Agree to delete the apps", "Deleting the apps til the end of the season", "That is my boy. Watch how much lighter you feel", 10, { morale: 6, perk: "calm" }),
      R("Half agree", "I will stop before games at least", "Half a promise. I will take it", 6, { morale: 2 })
    )
  ]),
  /* ── Dad ── */
  C("dad_analysis", "dad", "any", [
    B(
      "Watched it back three times. You were dropping too deep in the second half son. Coming to get the ball because you wanted a touch.",
      R("Take it on the chin", "You are right. I got frustrated and went looking for it", "That is all I wanted to hear. Stay high, they have to deal with you", 8, { perk: "sharp" }),
      R("Argue back", "There was nobody else showing for it. What was I meant to do", "Then let them lose it. Not your job to fix their bottle", 5),
      R("Tell him to relax", "Dad it is one game", "Three times I watched it. THREE", 3)
    ),
    B(
      "Anyway. Your mother says I am not allowed to send you notes at midnight anymore.",
      R("Tell him to keep sending", "Keep sending them. Nobody else tells me the truth", "Right. Notes continue. Do not tell her", 9, { morale: 4 }),
      R("Agree with mum", "She might have a point", "Traitor", 4)
    ),
    B(
      "Right. Last one. What are you actually working on this week. In training. Specifically.",
      R("Give him a real answer", "First touch away from pressure. Doing 200 a day on my own", "THAT is an answer. Two hundred a day. Good lad", 9, { perk: "sharp" }),
      R("Say you do not know", "Whatever the coaches put on honestly", "Then pick something yourself. Nobody built a career doing the group session", 7, { perk: "sharp" }),
      R("Tell him to leave it", "Dad. Enough for tonight", "Alright alright. Night son", 3)
    )
  ]),
  C("dad_firstboots", "dad", "any", [
    B(
      "Found your first pair of boots in the loft. Size 3. Held together with tape and hope.",
      R("Ask him to keep them", "Do not throw those out. Ever", "They are going in a box with your name on it. Already done", 9, { morale: 5 }),
      R("Ask for a photo", "Send me a photo of them", "Sent. Look at the state of the left one", 7, { morale: 3 }),
      R("Bin them", "Chuck them, I have got hundreds of pairs now", "You have got hundreds of pairs because of that pair", -1, { warm: -4 })
    ),
    B(
      "Your mother wants to know if you remember who paid for them.",
      R("Say thank you properly", "I know exactly who paid for them. And the petrol to every away game. Thank you", "Stop it. You will set me off", 10, { morale: 6, karma: 4 }),
      R("Joke about it", "The council?", "The COUNCIL. Right", 5)
    ),
    B(
      "She says put them in the cabinet with your medals. I said you have not got a cabinet.",
      R("Promise the cabinet", "Tell her I am building one. Boots go on the top shelf", "Top shelf. Above the medals. She will love that", 10, { morale: 5 }),
      R("Admit you have no medals yet", "I have not won anything yet dad", "Yet. That word is doing a lot of work and I like it", 8, { morale: 4, perk: "sharp" })
    )
  ]),
  C("dad_pressure", "dad", "pro", [
    B(
      "Lads at work keep asking me when you are going to a bigger club. I keep telling them to ask you.",
      R("Give him something to say", "Tell them my dad has no idea and neither do I. Which is true", "Perfect. That will shut them up for a week", 7),
      R("Be honest about it", "Honestly? I think about it every day dad", "Then think about it properly and stop letting other people think it for you", 8, { perk: "sharp" }),
      R("Get annoyed", "Tell them to mind their business", "They are just proud of you in a stupid way. That is all it is", 3)
    )
  ], { minAge: 20 }),
  /* ── Grandad ── */
  C("grandad_ticket", "grandad", "any", [
    B(
      "Still got my seat. Row H. Been in that row since 1974 and I am not moving for anybody.",
      R("Offer him the good seats", "I can get you in the family box. Heated. Cup of tea and everything", "Heated? Row H it is then. But tell your mother I considered it", 8, { morale: 4 }),
      R("Respect the row", "Row H forever. I would not dare move you", "Good lad. You understand", 9, { morale: 3 })
    ),
    B(
      "Here. When you score, do the thing. You know the thing.",
      R("Promise the celebration", "Next one is for you. Point at Row H", "I will have my hat off and everything", 10, { morale: 6, karma: 3 }),
      R("Play it down", "I do not really do celebrations grandad", "You will do this one", 5)
    ),
    B(
      "And bring your nan a scarf from the away end. She collects them. Do not ask me why.",
      R("Get her the scarf", "Away scarf, next trip. Consider it done", "She has 31 of them. You are keeping a woman happy here", 9, { morale: 4 }),
      R("Get her the whole lot", "I will get her one from every away ground this season", "Now you have started something. She will count them", 10, { morale: 6, karma: 3 })
    )
  ]),
  C("grandad_oldtimes", "grandad", "any", [
    B(
      "In my day the ball was heavier and the pitch was mud from November. You lot play on a carpet.",
      R("Wind him up", "And you walked to the ground uphill both ways", "Do not be clever. I have got photographs", 7, { morale: 3 }),
      R("Ask him about it", "What was the best player you ever saw live?", "Now that is a proper question. Get the kettle on, this takes a while", 9, { morale: 4 })
    )
  ]),
  /* ── Partner ── */
  C("partner_time", "partner", "any", [
    B(
      "You have been home four nights this month. I counted. I was not going to say anything but I counted.",
      R("Own it", "That is on me. Not the schedule, me. I will fix it", "Thank you for not arguing with the number", 9, { morale: 5, karma: 4 }),
      R("Explain the schedule", "Away trip, then internationals, then away again. It is the calendar not me", "I know what the calendar is. I asked about you", 3),
      R("Get defensive", "This is the job. You knew that", "I did. Does not make the house any less quiet", -3, { warm: -6, morale: -3 })
    ),
    B(
      "So what does fixing it actually look like. Be specific.",
      R("Make a real plan", "Two nights a week, phone in a drawer, no exceptions. Starting Tuesday", "Tuesday. I am holding you to it and I am putting it in the calendar", 10, { morale: 8, perk: "calm" }),
      R("Promise vaguely", "I will be around more, I promise", "That is not specific. But ok", 3)
    ),
    B(
      "Ok. And when you are home, actually be home. Not on the phone reading about yourself.",
      R("Agree", "Phone in the drawer. I mean it", "Then I will stop pretending I do not check it either", 10, { morale: 6, perk: "calm" }),
      R("Push back gently", "Some of that is work though", "Some of it. Not all of it. You know the difference", 5)
    )
  ], { needs: (s) => !!s.hasRelationship || !!s.family?.isMarried }),
  C("partner_afterloss", "partner", "pro", [
    B(
      "I watched it. Do you want me to say something nice or do you want me to leave it alone.",
      R("Ask to be left alone", "Leave it alone tonight. Tomorrow I will talk", "Ok. Food is in the oven. Not talking about it", 8, { morale: 4 }),
      R("Ask for something nice", "Say something nice. I am on the floor here", "You were the only one who kept running. I watched you the whole way", 9, { morale: 7 }),
      R("Snap at her", "Do not watch them if you are going to analyse them", "Right. Noted", -4, { warm: -8, morale: -4 })
    ),
    B(
      "For what it is worth, the version of you that comes home is the one I actually like.",
      R("Say it back", "That version only exists because of you. I know that", "Now you are just being nice because I made food", 10, { morale: 8 }),
      R("Deflect", "Give it a week and you will change your mind", "Stop it", 4)
    ),
    B(
      "Do you want me at the next one or would you rather I was not in the stand?",
      R("Want them there", "I look for you every time. Be there", "Then I am there. Front row, terrible singing", 10, { morale: 7 }),
      R("Ask them to skip it", "Skip this one. It is going to be horrible", "Ok. But I am watching it at home and shouting anyway", 6, { morale: 2 })
    )
  ], { needs: (s) => !!s.hasRelationship || !!s.family?.isMarried }),
  C("partner_move", "partner", "pro", [
    B(
      "If you moved clubs, would you actually ask me first. Genuine question.",
      R("Say yes and mean it", "You would be the first call. Before my agent. Before anyone", "Good. Because I would go anywhere with you, I just want to be asked", 10, { morale: 6, karma: 4 }),
      R("Be honest about the business", "Honestly these things move fast and sometimes there is no time", "Then make time. It is my life too", 4),
      R("Joke", "Depends where", "Wrong answer. Try again", 2)
    ),
    B(
      "Where would you actually go, if it was only up to you.",
      R("Somewhere you would win", "Somewhere I would win everything. That is the whole point", "Then go and win it. I will find a coffee shop I like", 9, { morale: 5, perk: "offer" }),
      R("Somewhere you would play", "Somewhere I would play every week. Sick of watching", "That is the most honest thing you have said all month", 9, { morale: 5, perk: "offer" }),
      R("Nowhere", "Nowhere. I like it here", "Then stay and stop scrolling transfer rumours at 1am", 7, { morale: 3 })
    )
  ], { minAge: 20, needs: (s) => !!s.hasRelationship || !!s.family?.isMarried }),
  /* ── Best mate from home ── */
  C("mate_fivea", "bestmate", "any", [
    B(
      "Five a side Thursday. Same cage. Lads still think they can mark you. Are you coming or are you too famous",
      R("Turn up", "I am coming and I am not going easy on anyone", "The cage is going to be RAMMED. Word will get out in an hour", 8, { morale: 5, popularity: 2 }),
      R("Send money for the pitch", "Cannot make it but I have paid for the pitch for the rest of the year", "Absolute scenes. You are a legend", 6, { karma: 4, cash: -0.01 }),
      R("Leave him hanging", "", "Right. Say no more", -4, { warm: -8, karma: -4 })
    ),
    B(
      "Serious question though. Are you alright? You have gone quiet with everyone.",
      R("Open up", "Bit lost if I am honest mate", "Then get in the cage Thursday. Nobody in there cares what you earn", 10, { morale: 7, perk: "calm" }),
      R("Keep it light", "I am fine. Busy", "Busy. Right. Thursday. I am not asking", 5)
    ),
    B(
      "Also everyone keeps asking me if you have changed. I keep saying no. Have you?",
      R("Ask him honestly", "You tell me. You would know before I would", "Bit. Not in a bad way. You are just tired all the time", 9, { morale: 4 }),
      R("Say no", "Not a chance. Same idiot", "Correct answer and mostly true", 8, { morale: 3 }),
      R("Get defensive", "Why, what have they been saying", "Nothing. Forget I said it", 2)
    )
  ]),
  C("mate_wedding", "bestmate", "pro", [
    B(
      "Getting married in June. You are best man. Not a question, an announcement.",
      R("Say yes immediately", "Obviously. Try and stop me", "Speech better be good. No football stories. Ok one football story", 10, { morale: 7, karma: 4 }),
      R("Check the fixtures", "Let me check the fixture list first mate", "Mate. June. YOU are the fixture list", 3),
      R("Say no", "I cannot commit to anything that far out", "Wow. Ok", -5, { warm: -10, karma: -6 })
    ),
    B(
      "One more thing. Do not turn up with security. It is a village hall.",
      R("Agree", "Just me and a suit. Promise", "Perfect. Uncle Ray will still ask you for a trial", 9, { morale: 4 }),
      R("Insist", "I have to bring one guy, that is the club rule", "Fine. Put him on the buffet, he will love it", 6)
    ),
    B(
      "Last thing. The speech. Are you actually going to do it or are you going to wing it.",
      R("Write it properly", "I have already started writing it. Two pages", "TWO PAGES. Mate. I am going to cry in front of my in laws", 10, { morale: 6, karma: 3 }),
      R("Wing it", "I will wing it. It will be fine", "Famous last words from a man who cannot do a post match interview", 5)
    )
  ], { minAge: 22 }),
  /* ── Agent ── */
  C("agent_interest", "agent", "pro", [
    B(
      "Two clubs have called this week. One is serious, one is fishing. Do you want the names or do you want me to handle it",
      R("Ask for the names", "Names. Now. I want to know who actually rates me", "Sending them. Do not screenshot this to anyone", 8, { perk: "offer" }),
      R("Let him handle it", "Handle it. Bring me something real or nothing at all", "That is how I like to work. Leave it with me", 7, { perk: "offer" }),
      R("Shut it down", "Not interested. I am happy here", "Noted. I will tell them the door is shut. For now", 5, { morale: 3 })
    ),
    B(
      "Before I go back to them. What actually matters to you. Money, minutes, or medals.",
      R("Minutes", "Minutes. I cannot develop watching", "Good. That narrows it and it is the right answer at your age", 9, { perk: "sharp" }),
      R("Medals", "Medals. I want to win things while I still can", "Then we are aiming higher and I am asking for less. Understood", 9, { perk: "offer" }),
      R("Money", "Money. I am not going to pretend otherwise", "Refreshing. I can absolutely work with that", 6, { karma: -3, cash: 0.4 })
    ),
    B(
      "Right. I am going to go and be annoying at somebody on your behalf. Anything you do NOT want?",
      R("No sideways moves", "Nothing sideways. If it is not a step up I am not moving", "Understood. That rules out two of them already", 9, { perk: "offer" }),
      R("Nowhere I would not play", "Nowhere that signs me to sit me on a bench", "Right. I will ask about minutes before I ask about money", 9, { perk: "offer" }),
      R("Leave it with him", "Surprise me", "Dangerous words to say to an agent", 5)
    )
  ], { minAge: 18 }),
  C("agent_contract", "agent", "pro", [
    B(
      "Your club want to open contract talks early. That is a good sign and also a trap. They want to lock you in cheap.",
      R("Play it patient", "Let them wait. I will let the season do the talking", "That is the play. Every goal from here is a pay rise", 8, { perk: "offer" }),
      R("Sign now for security", "I would rather have it done. Get me a fair deal now", "Safe. Boring. Honestly, not wrong either", 7, { morale: 4 }),
      R("Demand the world", "Tell them the number and watch their faces", "I will enjoy that meeting. It may not end well", 4, { karma: -3 })
    ),
    B(
      "One more thing and then I will leave you alone. Are you happy at this club, actually.",
      R("Yes", "Yeah. I would stay", "Then I negotiate like a man who does not want to leave. Costs us a bit. Worth it", 8, { morale: 5 }),
      R("No", "No. I have outgrown it", "Right. Then we are having a very different conversation in January", 7, { perk: "offer" })
    ),
    B(
      "One last thing, and I ask everybody this. What do you want people to say about you at 35.",
      R("That he was hard to play against", "That I was a nightmare to play against for fifteen years", "Then we build the career around that sentence. Good", 9, { perk: "sharp" }),
      R("That he won things", "That I won. Everything else is noise", "Then we go where the trophies are, even if the money is worse", 9, { perk: "offer" }),
      R("Never thought about it", "Genuinely no idea", "Think about it. It is the only question that decides the rest", 5)
    )
  ], { minAge: 19 }),
  C("agent_brand", "agent", "pro", [
    B(
      "Boot brand wants you. Small money now, big money if you kick on. Or we wait for a bigger name to notice.",
      R("Take the small deal", "Take it. Money now, and I want to be loyal to whoever backs me early", "Loyalty plays well and pays later. Signing it", 7, { cash: 0.3, popularity: 2 }),
      R("Wait it out", "Wait. I back myself", "So do I. Risky. I like it", 7, { perk: "spotlight" }),
      R("Ask what he would do", "What would you do if it was your career", "I would wait. But I would also stop pretending my agent knows your body better than you", 8, { morale: 3 })
    )
  ], { minAge: 19 }),
  /* ── The gaffer ── */
  C("gaffer_role", "gaffer", "pro", [
    B(
      "Come see me at the training ground tomorrow. Nothing bad. I want to tell you what I actually want from you.",
      R("Ask for more", "Before I come in. I want more minutes and I will earn them", "Good. I like being asked. Bring that attitude tomorrow", 8, { perk: "sharp" }),
      R("Just listen", "I will be there. I will listen", "That is the right answer more often than players think", 7, { perk: "sharp" }),
      R("Be wary", "Should I be worried", "If you were, I would not have texted. I would have let you find out", 5)
    ),
    B(
      "One thing I want you to think about tonight. When we lose the ball, what do you do first.",
      R("Win it back", "Win it back. Within five seconds. That is the answer you want", "It is the answer I want AND the right one. See you at nine", 9, { perk: "sharp" }),
      R("Get in shape", "Get back in shape and hold the line", "Boring. Correct. Also see you at nine", 8),
      R("Admit you switch off", "Honestly? Sometimes I stand there annoyed", "At least you know. We can fix knowing. We cannot fix pretending", 8, { morale: 3, perk: "sharp" })
    ),
    B(
      "Good. Bring one question with you tomorrow. Any question. I will answer it straight.",
      R("Ask about your role", "Am I in your best eleven or am I in the squad", "In it. Not nailed on. That is the honest answer and you can change it by Friday", 9, { morale: 4, perk: "sharp" }),
      R("Ask about the team", "What is the one thing holding this team back", "Nobody talks. Including you. Fix that and we go up the table", 9, { perk: "lift" }),
      R("No question", "I will just listen", "Then listen properly. Nine o clock", 5)
    )
  ]),
  C("gaffer_dropped", "gaffer", "pro", [
    B(
      "You are on the bench Saturday. I would rather you heard it from me tonight than from a team sheet.",
      R("Ask what to fix", "Tell me exactly what gets me back in", "Two things. Sprint back after you lose it, and stop taking the safe pass. Do that and you start next week", 9, { perk: "sharp", morale: 2 }),
      R("Take it quietly", "Understood. I will be ready if you need me", "That is the response of somebody who plays a lot of games for me", 8, { morale: 3 }),
      R("Kick off", "This is a joke and you know it", "It is my team. Cool down and come see me Monday", -3, { warm: -8, morale: -5 })
    ),
    B(
      "For what it is worth I was dropped at your age and I sulked for a month. Waste of a month.",
      R("Take the lesson", "Then I will skip the month", "Ha. Good. Nine o clock, extra finishing", 9, { perk: "sharp" }),
      R("Stay annoyed", "I am still not happy about it", "I would be worried if you were", 6)
    ),
    B(
      "Be honest with me. Do you still trust that I will play you when you deserve it?",
      R("Yes", "Yeah. You have never lied to me about it", "Then we are fine. Everything else is just Saturdays", 9, { morale: 5, perk: "lift" }),
      R("Not really", "Honestly, not at the minute", "Fair. I will earn it back the same way you will. See you at nine", 8, { morale: 3 })
    )
  ]),
  /* ── Captain ── */
  C("captain_standards", "captain", "pro", [
    B(
      "Quick word. Nothing heavy. Couple of the young lads are drifting and they watch you more than they watch me.",
      R("Set the tone", "I will be first in all week. Let them see it rather than hear it", "That is exactly why I asked you and not somebody louder", 9, { perk: "lift" }),
      R("Talk to them", "I will pull them both aside quietly", "Quietly is right. Nobody learns anything from being embarrassed", 8, { karma: 4 }),
      R("Not your job", "Not really my problem mate", "Fair enough. It becomes your problem in about three years", -2, { warm: -5 })
    ),
    B(
      "Team meal Thursday. Everyone. Phones in a box at the door.",
      R("In", "In. And I am paying", "Right lads, he is paying. This is now a big night", 9, { morale: 5, cash: -0.02, perk: "lift" }),
      R("In, but not paying", "I will be there. Not paying, I paid last time", "Correct and I respect the memory", 7, { morale: 3 }),
      R("Skip it", "Cannot do Thursday", "Every time mate", -3, { warm: -7 })
    ),
    B(
      "Good. One more. If I go down injured for a long one, who speaks up in there?",
      R("Say you will", "Me. I will do it", "That is the answer I was fishing for and you did not even flinch", 10, { morale: 6, perk: "lift" }),
      R("Name somebody else", "The keeper. Everyone listens to him", "He would hate it. He would also be brilliant at it", 7)
    )
  ]),
  C("captain_armband", "captain", "pro", [
    B(
      "I am moving on in the summer. Between us, I have told the gaffer you should have the armband.",
      R("Say you are ready", "I am ready. I have been ready", "That is what I told him. Do not make me look daft", 9, { morale: 7, perk: "lift" }),
      R("Be honest about doubts", "Honestly I do not know if the lads would follow me", "They already do. You just have not noticed", 9, { morale: 6 }),
      R("Turn it down", "Give it to someone who wants it. I just want to play", "Respect that. Rare, but I respect it", 6)
    ),
    B(
      "Whoever gets it, one bit of advice. The armband is not for the good days.",
      R("Ask what he means", "So what is it for", "The week after a hammering, when nobody wants to be first to speak. That is the job", 9, { morale: 4, perk: "lift" }),
      R("Say you know", "I know. I have watched you do it", "Then you already have it, plastic or not", 8, { morale: 4 })
    )
  ], { minAge: 24 }),
  /* ── Room mate ── */
  C("roomie_nerves", "roomie", "pro", [
    B(
      "You alright? You have been staring at the ceiling for an hour and it is 1am.",
      R("Admit the nerves", "Big one tomorrow. Head is going", "Same. Every time. Nobody says it out loud though so we all lie awake separately", 9, { morale: 5 }),
      R("Say it is nothing", "Nothing mate. Go to sleep", "You are a terrible liar. Night", 5),
      R("Put the light on", "Put the light on, we are talking", "Great. Now neither of us sleeps. Worth it though", 8, { morale: 4 })
    ),
    B(
      "Can I ask you something daft. Do you ever feel like you got lucky and they will find out?",
      R("Admit you feel it too", "Every week. Waiting to be found out", "Thank god. I thought it was just me", 10, { morale: 6, perk: "calm" }),
      R("Talk him out of it", "You are here because you are good. Full stop", "Coming from you that actually lands", 9, { morale: 4, perk: "lift" }),
      R("Laugh at him", "Yeah you did get lucky", "Wow. Lights off", -2, { warm: -6 })
    ),
    B(
      "Do you ever think about what we do after? Like actually after.",
      R("Talk about it", "All the time. Coaching maybe. Or nothing at all for a year", "See I want to open a cafe. Everyone laughs. You did not laugh", 9, { morale: 4, perk: "calm" }),
      R("Refuse to", "I do not let myself think about it", "Probably healthy. Probably not", 6)
    )
  ]),
  C("roomie_snacks", "roomie", "pro", [
    B(
      "Mate the hotel food is a war crime. I have found a chip shop 400 metres away. Are we doing this",
      R("Go", "Go. Nutritionist will never know", "He will absolutely know. Worth it", 7, { morale: 4, karma: -2 }),
      R("Refuse", "Not the night before a game. Bring me a banana", "A BANANA. You have changed", 6),
      R("Order in for the whole squad", "Do one better. I am ordering proper food for everyone", "You are going to be the most popular man in this hotel", 8, { morale: 5, cash: -0.01, perk: "lift" })
    )
  ]),
  /* ── Physio ── */
  C("physio_niggle", "physio", "pro", [
    B(
      "That hamstring. You have been guarding it for two weeks and you think I have not noticed.",
      R("Come clean", "It is tight. I did not want to say in case I got left out", "Thank you. Now I can actually help instead of guessing. In at eight", 10, { perk: "calm", morale: 3 }),
      R("Deny it", "It is fine. Honestly", "Then you will not mind me testing it in front of the gaffer tomorrow", -2, { warm: -6 }),
      R("Ask to manage it", "Can we manage it without me missing games", "Sometimes. If you are honest with me every single day. Deal?", 9, { perk: "calm" })
    ),
    B(
      "Last thing. How is the sleep and the stress. Both of those show up in soft tissue before they show up anywhere else.",
      R("Be honest", "Sleep is bad. Stress is worse", "Right. Then we treat that too. Half of my job is not legs", 10, { morale: 6, perk: "calm" }),
      R("Say it is fine", "All fine there", "Ok. But that box is ticked in pencil", 4)
    ),
    B(
      "One rule then and we are done. If something feels wrong on a Friday, you tell me on the Friday.",
      R("Agree to the rule", "Friday. Every time. Even if it is nothing", "That one rule will add years to your career. I am not exaggerating", 10, { perk: "calm", morale: 4 }),
      R("Push back", "I do not want to be the one always in the treatment room", "You will not be. You will be the one still playing at 34", 8, { perk: "calm" })
    )
  ]),
  /* ── Fitness coach ── */
  C("fitness_extra", "fitness", "any", [
    B(
      "Optional extras start Monday. 6am. Nobody has signed up yet which tells you everything.",
      R("Sign up", "Put my name down. First one in", "Good. Bring a bin. I am not joking", 8, { perk: "sharp", morale: -2 }),
      R("Ask what it does", "What does it actually give me", "Two more sprints in the last ten minutes. That is the difference between a goal and a photo of you jogging", 8, { perk: "sharp" }),
      R("Pass", "I need the rest more", "Fine. Rest is training too. But nobody ever got quicker resting", 3)
    ),
    B(
      "If you come, I want a target. Give me one number to chase.",
      R("Top speed", "Top speed. I want to be the quickest at this club", "Now we are talking. Twelve weeks", 9, { perk: "sharp" }),
      R("Games played", "I just want to finish a season without breaking down", "Best target anyone has given me all year", 9, { perk: "calm" })
    ),
    B(
      "Last thing. Bring somebody with you. Nobody sticks at 6am on their own.",
      R("Drag a teammate in", "I will drag one of the young lads in with me", "Two of you at 6am and by March half the squad is there. Watch", 10, { perk: "lift" }),
      R("Go alone", "I will be fine on my own", "You will last three weeks. Prove me wrong", 6)
    )
  ]),
  /* ── Old youth coach ── */
  C("youth_pride", "youthcoach", "any", [
    B(
      "Still got the team photo from your first season up on the wall. You are the small angry one at the front.",
      R("Ask about the others", "Who else from that photo is still playing?", "Two. One is at a non league club and loves it. One is a physio now. Everyone else has a proper job", 9, { morale: 4 }),
      R("Thank him", "You made me. I will say that for the rest of my life", "Get away with you. You made you. I just stopped you kicking people", 10, { morale: 6, karma: 4 }),
      R("Brush it off", "Long time ago that", "It is. And I still watch every week", 3)
    ),
    B(
      "Do me one favour. When a kid asks you for a photo, say yes. Even when you are tired.",
      R("Promise", "Always yes. Even when I am tired. Especially then", "Good lad. That is the whole lesson", 10, { karma: 6, popularity: 3 }),
      R("Be honest about it", "Some days I really do not want to", "Nobody does. Do it anyway. That is what the word professional means", 8, { karma: 3 })
    ),
    B(
      "And one day, when you are done, come and coach here. I am putting it in writing now.",
      R("Say yes", "When I am done I am coming straight back here", "I will hold this message up in about fifteen years", 10, { morale: 5, karma: 4 }),
      R("Cannot think that far", "I cannot even think about next season coach", "Then do not. I will keep the message anyway", 6)
    )
  ]),
  C("youth_return", "youthcoach", "pro", [
    B(
      "We have got a session Thursday for the under 12s. Twenty minutes of you would blow their minds. No cameras.",
      R("Do the whole session", "I will do the full session. And no cameras, agreed", "They are going to be unbearable for a month. Thank you", 10, { karma: 8, popularity: 3, morale: 4 }),
      R("Twenty minutes", "Twenty minutes is all I have got but I will be there", "Twenty minutes is twenty more than most", 8, { karma: 4, popularity: 2 }),
      R("Send kit instead", "Cannot do Thursday. Sending a full set of kit for them", "That will help. They would rather have you though", 5, { karma: 2, cash: -0.03 })
    )
  ], { minAge: 21 }),
  /* ── Academy kid ── */
  C("academy_firstteam", "academy", "any", [
    B(
      "Training with the first team tomorrow. I have been sick twice. Any advice",
      R("Give him the one rule", "First ball, first tackle, win it. Everything else follows", "First ball first tackle. Ok. Ok I can do that", 8, { karma: 4, perk: "lift" }),
      R("Offer to pick him up", "I will pick you up. We go in together", "Are you serious. I am not going to sleep now", 10, { karma: 8, morale: 4, perk: "lift" }),
      R("Tell him to relax", "You are there because you are good enough. Breathe", "Nobody has said that to me yet. Thank you", 8, { karma: 4 })
    ),
    B(
      "Last thing sorry. What if I am rubbish and they send me back",
      R("Tell him the truth", "You probably will be rubbish for a bit. Everybody is. Then you are not", "That is weirdly the most calming thing anyone has said", 9, { karma: 4, perk: "lift" }),
      R("Big him up", "You will not be rubbish. I have watched you", "You have WATCHED me? I need to sit down", 8, { morale: 3 })
    ),
    B(
      "If it goes ok tomorrow can I text you after? I have got nobody else to tell.",
      R("Yes, any time", "Text me after every session. I mean it", "You have no idea what that means. See you tomorrow", 10, { karma: 6, morale: 4, perk: "lift" }),
      R("Set a boundary", "Text me after big ones. I am not your dad", "Fair enough. Big ones only", 5)
    )
  ]),
  /* ── Kit man ── */
  C("kitman_shirt", "kitman", "pro", [
    B(
      "Lad in the laundry has been here 30 years and never asked a player for anything. He asked me to ask you for a shirt.",
      R("Sign one properly", "Get me the shirt from Saturday. I will write him something proper on it", "He is going to have that framed by Tuesday", 9, { karma: 6, morale: 3 }),
      R("Do one better", "Shirt, boots, and get him and his wife in the box for a game", "Right. Now you have made an old man cry in a laundry room", 10, { karma: 8, popularity: 3, cash: -0.01 }),
      R("Later", "Remind me after the international break", "Course. He has waited 30 years, he can wait a fortnight", -1, { warm: -3 })
    )
  ]),
  /* ── Journalist ── */
  C("journo_column", "journo", "pro", [
    B(
      "Doing a piece on players your age carrying clubs. Not a hit job. Ten minutes on the phone, you see quotes before print.",
      R("Do it properly", "Ten minutes, and I want to talk about the lads not just me", "That makes it a better piece anyway. Thursday?", 8, { popularity: 3, karma: 3 }),
      R("Decline politely", "Not for me at the minute. No hard feelings", "None at all. Door is open", 5),
      R("Use it", "I will do it if I can say what I actually think about the club", "Now THAT is a phone call. Thursday, and I am recording", 6, { popularity: 5, karma: -4 })
    ),
    B(
      "Off the record before we set it up. Are you happy there?",
      R("Nothing off the record", "There is no off the record with you lot. Ask me Thursday", "Fair. Genuinely fair. Thursday", 9, { karma: 5 }),
      R("Give him a hint", "Ask me again in January", "January. Noted. Loudly noted", 4, { karma: -3, popularity: 3 })
    ),
    B(
      "Fine. Then give me one line for the piece that is actually about football and not about you.",
      R("Praise a teammate", "Put in that our left back is the most underrated player in this league", "That is a lovely line and he will never forget it", 9, { karma: 5, perk: "lift" }),
      R("Praise the fans", "Say the away end has been the best thing about this season", "Cheap. True though. Using it", 8, { popularity: 4 }),
      R("Refuse", "I do not do lines. Watch the games", "Ha. Print that then", 4)
    )
  ], { minAge: 19 }),
  /* ── Country manager ── */
  C("nat_squad", "natcoach", "pro", [
    B(
      "Naming the squad Monday. Before I do I want to know where your head is, because your club season has been noisy.",
      R("Commit fully", "My head is fine. I will run through a wall for that shirt", "That is what I needed to hear. See you Monday", 9, { morale: 6, perk: "lift" }),
      R("Ask for honesty back", "Am I starting or am I making up the numbers", "You are in the squad. Starting is earned in the week, same as everyone", 8, { perk: "sharp" }),
      R("Ask to be left out", "I am running on empty. Leave me out this window", "Brave call. I would rather have you in March than broken in October", 7, { morale: 4, perk: "calm" })
    )
  ], { needs: (s) => !!s.internationalCareer }),
  C("nat_tournament", "natcoach", "pro", [
    B(
      "Long summer coming. I need players who will still be sprinting in the 85th minute of a semi final.",
      R("Volunteer for anything", "Put me anywhere. Left back if you need it", "I might hold you to that and you will regret typing it", 9, { morale: 5, perk: "lift" }),
      R("Be realistic", "I can give you 60 big minutes every game, not 90", "Honest. Useful. Most players lie to me about this", 9, { perk: "sharp" })
    )
  ], { needs: (s) => !!s.internationalCareer, minAge: 21 }),
  /* ── Rival ── */
  C("rival_respect", "rival", "pro", [
    B(
      "Good game. You were the best player on that pitch and I am only saying it once so screenshot it.",
      R("Give it back", "You were the reason it was close. Screenshot that", "Look at us. Two grown men being nice. Disgusting", 8, { morale: 4, popularity: 2 }),
      R("Stay cold", "Scoreboard said what it said", "Ha. There he is. See you in March", -2, { warm: -6, perk: "needle" }),
      R("Take the compliment", "Appreciated. Genuinely", "Do not get used to it", 6)
    ),
    B(
      "Serious for a second. Does it get to you, the comparison thing?",
      R("Admit it", "Every single week. You?", "Constantly. Nobody else understands it which is the annoying part", 9, { morale: 5 }),
      R("Deny it", "Not once. I do not think about you at all", "You replied in four seconds", 3, { perk: "needle" })
    ),
    B(
      "Alright. One promise. Whoever finishes with more, the other one turns up to the testimonial.",
      R("Shake on it", "Deal. And I will be the one clapping you off", "We will see. Good luck this season. Genuinely", 9, { morale: 4, popularity: 2 }),
      R("Refuse the deal", "I am not planning a testimonial. I am planning to keep going", "Terrifying. See you in March", 4, { perk: "needle" })
    )
  ], { needs: (s) => !!s.rival && !s.rival.retired }),
  C("rival_needle", "rival", "pro", [
    B(
      "Saw your interview. Bold from someone with fewer trophies than me.",
      R("Fire back", "Count them again in three years", "Oh it is ON. See you in the derby", 4, { popularity: 4, morale: 3, perk: "needle" }),
      R("Kill it with kindness", "You are right. Come and help me get some", "That is so annoying. I cannot even argue with that", 8, { karma: 4 }),
      R("Ignore the bait", "", "Silence. Interesting.", 1, { warm: 0 })
    ),
    B(
      "Between us though. Would you ever play in the same team as me.",
      R("Yes", "In a heartbeat. We would be unplayable", "We would be. Do not tell anyone I agreed", 8, { morale: 4 }),
      R("Never", "Never. I want to beat you, not carry you", "That is the correct answer and you know it", 3, { perk: "needle", popularity: 3 })
    )
  ], { needs: (s) => !!s.rival && !s.rival.retired }),
  /* ── second wave: more to say to the same people ── */
  C("mum_money", "mum", "pro", [
    B(
      "Somebody at the shop asked me what you earn. I told them to mind their own business.",
      R("Back her up", "Good. It is nobody's business but ours", "That is what I said. Then I told them anyway. Sorry", 8, { morale: 3 }),
      R("Offer to sort her out", "Mum, let me buy you something. Anything. Please", "I do not need anything. Ask me again next year and I might say a new sofa", 9, { morale: 5 }),
      R("Get annoyed", "People are so nosy", "They are proud. It comes out sideways", 5)
    ),
    B(
      "Do not let it change how you are with people. That is my only rule.",
      R("Promise", "Same me. Always. You would tell me if it was not", "I would tell you loudly and in front of everyone", 10, { karma: 5, morale: 4 }),
      R("Joke", "Too late, I am insufferable", "You are not. But keep checking", 6)
    ),
    B(
      "Right. Go and get some sleep. And ring your nan.",
      R("Ring nan now", "Ringing her now before I forget", "You are a good boy. Night love", 10, { morale: 5, karma: 3 }),
      R("Tomorrow", "I will ring her tomorrow", "Tomorrow. I am writing it down", 4)
    )
  ]),
  C("dad_debut", "dad", "pro", [
    B(
      "Do you remember your first proper game? I do. You were sick behind the dugout.",
      R("Own the memory", "I remember. And I still nearly am, every time", "Everybody is. The ones who say they are not are lying", 9, { morale: 4 }),
      R("Deny it", "That never happened", "I have a photograph of the bucket", 7, { morale: 3 })
    ),
    B(
      "Point is you did it anyway. That has always been the thing about you.",
      R("Take it in", "I needed to hear that this week actually", "Then I will say it more often instead of sending you diagrams", 10, { morale: 6, perk: "calm" }),
      R("Deflect", "Soft in your old age dad", "Very. Do not tell the lads at work", 6)
    )
  ], { minAge: 19 }),
  C("partner_home", "partner", "pro", [
    B(
      "I found a house. It is too big and it has a stupid bath and I love it.",
      R("Go and see it", "Send me the link. We are going Saturday", "SATURDAY. Right. I am ringing them now", 9, { morale: 6 }),
      R("Talk about the move risk", "What if we get moved in January though", "Then we rent it out and cry. Come and look at the bath", 7, { morale: 3 }),
      R("Shut it down", "Not while the contract situation is up in the air", "Ok. It will be gone but ok", 2, { warm: -3 })
    ),
    B(
      "Whatever we do, I do not want to live somewhere that only makes sense if you keep winning.",
      R("Agree completely", "Nothing we cannot keep if it all goes wrong. Agreed", "That is the most attractive thing you have ever said", 10, { morale: 6 }),
      R("Play it big", "I am going to keep winning", "Not what I asked. But ok", 4)
    )
  ], { minAge: 21, needs: (s) => !!s.hasRelationship || !!s.family?.isMarried }),
  C("captain_newsigning", "captain", "pro", [
    B(
      "New lad signed today. Speaks about nine words of the language and looks terrified. Sound familiar?",
      R("Take him under your wing", "I will sit with him at lunch. And drive him in", "That is why I texted you and not the group chat", 9, { karma: 5, perk: "lift" }),
      R("Do the basics", "I will make sure he knows where everything is", "Do that much and he sleeps tonight", 7, { karma: 3 }),
      R("Not interested", "He will figure it out like the rest of us did", "We did. It was horrible. That was the point", -2, { warm: -6 })
    ),
    B(
      "Get him in the five a side on Thursday. That is where anyone actually joins a team.",
      R("Sort it", "He is on my team Thursday. Sorted", "Good. He will be one of us by Friday", 9, { perk: "lift" }),
      R("Let somebody else", "Get one of the young lads to do it", "I asked you because they copy you", 5)
    )
  ]),
  C("roomie_contract", "roomie", "pro", [
    B(
      "They have not offered me a new deal. Six months left. I am pretending I am fine.",
      R("Be straight with him", "You are not fine and that is fair enough. What do you actually want?", "To stay. Obviously. But nobody has said a word to me", 9, { morale: 3 }),
      R("Offer to ask for him", "Want me to say something to the gaffer? Quietly", "Would you? I would never have asked", 10, { karma: 6, perk: "lift" }),
      R("Change the subject", "Early game tomorrow mate", "Yeah. Night", -3, { warm: -7 })
    ),
    B(
      "If it goes the other way, will you still answer my messages when I am at some other club?",
      R("Obviously", "You will not get rid of me. Wherever you end up", "Right. Now I am the one lying awake being soft", 10, { morale: 5 }),
      R("Be realistic", "We will see. People drift", "Brutal. Honest though", 4)
    )
  ]),
  C("physio_comeback", "physio", "pro", [
    B(
      "Four weeks in. I know you feel good. I know you want to play Saturday. Ask me anyway.",
      R("Ask properly", "Am I ready for Saturday, honestly", "No. Two more weeks and you get the rest of the season. Push it and you get neither", 10, { perk: "calm" }),
      R("Push for it", "I am playing Saturday whatever you say", "Then you are picking a fortnight over a season and I will write that down", -2, { warm: -6, morale: -3 }),
      R("Defer to him", "Whatever you say. I will not fight you on it", "Good. Nobody ever regrets that call", 9, { perk: "calm", morale: 3 })
    ),
    B(
      "While I have got you. Rehab is boring and you have got a whole week of it. Do you want a job?",
      R("Take the job", "Give me something to do or I will lose my mind", "Right. You are coaching the under 18s finishers this week", 9, { morale: 5, perk: "sharp" }),
      R("Just rest", "I am going to switch off completely for a week", "Also a real answer. Go and be a person", 8, { morale: 4 })
    )
  ], { minAge: 19 }),
  C("agent_loan", "agent", "pro", [
    B(
      "There is a loan on the table. Lower league, guaranteed starter, nobody watching. Old fashioned option.",
      R("Take the loan", "I will go. I need games more than I need the badge", "Best decision a young player can make and almost none of them make it", 9, { perk: "sharp" }),
      R("Ask what he thinks", "What does it actually do for me", "Thirty games. Men's football. Somebody kicking you every week. It makes you", 8, { perk: "sharp" }),
      R("Refuse", "I am not dropping down. I will fight for my place here", "Brave. Could go either way. I will tell them no", 6, { morale: 3 })
    ),
    B(
      "Whatever you pick, do not disappear on me for six months. I work better when you talk to me.",
      R("Agree", "I will ring you every month whether there is news or not", "You would be the first player who ever did. Deal", 10, { perk: "offer" }),
      R("Push back", "Ring me when there is something to say", "Fine. There will be less than you think", 3)
    )
  ], { minAge: 18, maxAge: 25 }),
  C("kitman_boots", "kitman", "pro", [
    B(
      "Your boots have been in the same bag since August and they smell like a crime. Want me to sort them?",
      R("Let him sort them", "Please. And whatever it costs I will double it", "It costs nothing. That is the job. But I will take the tea", 8, { morale: 3 }),
      R("Do it yourself", "I will do them tonight. My mess", "A player cleaning his own boots. I need a lie down", 9, { karma: 4 })
    ),
    B(
      "Forty years I have done this. You lot come and go. The polite ones I remember.",
      R("Ask about the old days", "Who was the best one you ever kitted out?", "Not telling you. But you are in the top ten and you are 22", 9, { morale: 4 }),
      R("Say thanks", "Thanks for everything you do. Genuinely", "Get out of my kit room before I get emotional", 9, { karma: 4, morale: 3 })
    )
  ]),
  C("nat_debut", "natcoach", "pro", [
    B(
      "First cap. I want you to enjoy it, and I want you to remember one thing when you walk out.",
      R("Ask what", "Go on. What is the one thing", "Everybody in that stadium already thinks you belong. Only you are arguing", 9, { morale: 7, perk: "calm" }),
      R("Say you are ready", "I have been ready since I was nine", "Then go and prove it and stop texting me", 8, { morale: 5 })
    ),
    B(
      "Your family are in the players' box. All of them. I checked.",
      R("Thank him", "That means more than the cap does. Thank you", "Now go and have the best night of your life", 10, { morale: 8 }),
      R("Get emotional", "You have properly got me now", "Good. Use it in the first twenty minutes", 9, { morale: 6 })
    )
  ], { needs: (s) => !!s.internationalCareer }),
  C("grandad_advice", "grandad", "any", [
    B(
      "Your father says you are worrying too much. He worries too much. Runs in the family.",
      R("Admit it", "I do worry. All the time", "Course you do. So did I. Then I got old and it stopped mattering", 9, { morale: 5, perk: "calm" }),
      R("Blame dad", "He is worse than me", "He is much worse than you. Do not tell him I said it", 8, { morale: 3 })
    ),
    B(
      "Here is my advice and then I am going for my nap. Play like you did in the garden.",
      R("Take it", "Like the garden. I will remember that on Saturday", "That is all it ever was. Everything else is people talking", 10, { morale: 6, perk: "sharp" }),
      R("Ask what he means", "What, terribly and with one boot on?", "Cheeky sod. Nap time", 7, { morale: 3 })
    )
  ]),
  C("mate_home", "bestmate", "any", [
    B(
      "Went past your old house today. New people have painted the door red. Thought you should know.",
      R("Ask for a photo", "Send me a picture. Red? Really?", "Bright red. Your mum would have something to say", 8, { morale: 4 }),
      R("Get nostalgic", "I can still see the wall we used as a goal", "It is still there. Still has the mark", 9, { morale: 5 })
    ),
    B(
      "Do you miss it? Genuinely. Or is that a stupid question when you live where you live.",
      R("Say you miss it", "Every day. It is not stupid at all", "Then come back for a weekend. Nobody will make a fuss", 10, { morale: 6, perk: "calm" }),
      R("Say no", "No. I wanted out and I got out", "Fair. You always did want more than this place", 6)
    )
  ]),
  C("fitness_recovery", "fitness", "pro", [
    B(
      "Your numbers dip badly in the last fifteen minutes. Not fitness. Recovery. What are you doing after games?",
      R("Admit nothing", "Honestly? Nothing. I go home and sit on my phone", "Right. Then we have found free minutes lying on the floor", 9, { perk: "sharp" }),
      R("Claim you do everything", "Ice bath, stretch, the lot", "Your numbers disagree and numbers do not lie to me", 4),
      R("Ask for a plan", "Write me a proper recovery week and I will follow it", "Sending it tonight. Follow it and you get twenty minutes back", 10, { perk: "sharp" })
    ),
    B(
      "Sleep is the whole thing by the way. Everything else is decoration.",
      R("Fix the sleep", "Phone out the bedroom starting tonight", "That one change is worth more than anything I can do to you in a gym", 10, { perk: "calm", morale: 4 }),
      R("Say you cannot", "I cannot sleep after night games. Never could", "Then we work on the after, not the sleep. Come see me", 8, { perk: "calm" })
    )
  ]),
  C("academy_advice", "academy", "pro", [
    B(
      "They released my mate today. He is 18. He has not stopped crying and I do not know what to say to him.",
      R("Tell him what to say", "Say nothing. Just sit with him. That is the whole job today", "That is what I did. I did not know if it was enough", 10, { karma: 6, morale: 3 }),
      R("Offer to help him", "Give me his name. I know people at three clubs who would look", "Are you serious? He will not believe this", 10, { karma: 8, perk: "lift" }),
      R("Be blunt", "It happens to nearly everyone. He will be fine", "Yeah. Suppose", 1, { warm: -4 })
    ),
    B(
      "Does it ever stop being scary? Like, at your level?",
      R("Tell the truth", "No. You just get better at carrying it", "Weirdly that helps", 9, { morale: 4 }),
      R("Lie kindly", "It gets easier. Promise", "Ok. I am holding you to that", 6)
    )
  ], { minAge: 21 }),
  C("journo_column2", "journo", "pro", [
    B(
      "Story doing the rounds that your dressing room has split. I am running something. Do you want a right of reply?",
      R("Kill it flat", "There is no split. Print that and I will stand behind it all season", "That is a strong denial and I will print it word for word", 8, { karma: 5, perk: "lift" }),
      R("Say nothing", "No comment", "No comment reads like yes to every reader alive. Your call", 4),
      R("Point him elsewhere", "Ask whoever fed you it what they want out of it", "Now THAT is a better story than the one I had", 6, { karma: -2, popularity: 3 })
    ),
    B(
      "Between us, who is actually briefing against you lot? You must know.",
      R("Refuse", "Even if I knew I would not tell you", "Correct answer. Annoying. Respect", 9, { karma: 6 }),
      R("Give him a name", "I have got an idea. Off the record", "Off the record does not exist but go on", 3, { karma: -6, popularity: 4 })
    )
  ], { minAge: 21 }),
  C("gaffer_captainask", "gaffer", "pro", [
    B(
      "Something I want your read on, not as a player. Who do the group actually listen to in there?",
      R("Name somebody honestly", "The keeper. Nobody argues with him", "That matches what I see. Thank you for not saying yourself", 9, { perk: "lift" }),
      R("Say yourself", "Me, when it matters", "Bold. Prove it Tuesday when I make you run the warm up", 7, { morale: 4 }),
      R("Dodge it", "Not sure I should be answering that", "Fair. Forget I asked", 4)
    ),
    B(
      "Second question and then I will let you eat. What do the players say about ME when I leave the room?",
      R("Tell him straight", "That you are honest and that you are hard work. Both", "That is the most useful sentence anyone has said to me this season", 10, { perk: "lift", morale: 4 }),
      R("Protect him", "Nothing bad", "Now I know it is bad", 3)
    )
  ], { minAge: 24 }),
  C("rival_national", "rival", "pro", [
    B(
      "Wild that we are in the same squad this week. Do we have to pretend to like each other in front of the press?",
      R("Play nice for the country", "For ten days, yes. Then back to normal", "Ten days. Then war. Deal", 8, { morale: 4, popularity: 2 }),
      R("Refuse", "I am not pretending anything", "Honestly? Same. See you at breakfast", 3, { perk: "needle" })
    ),
    B(
      "Room next to yours by the way. If you snore I am telling everyone.",
      R("Wind him up", "I will snore on purpose", "You are the worst. See you at training", 7, { morale: 3 }),
      R("Call a truce", "Truce for the tournament. Properly", "Truce. And if we win it nobody ever mentions this chat again", 9, { morale: 5, perk: "lift" })
    )
  ], { needs: (s) => !!s.rival && !s.rival.retired && !!s.internationalCareer })
];
var CONVO_BY_ID = Object.fromEntries(CONVOS.map((c) => [c.id, c]));
var COLD_WARM = [
  [
    "Did you get my last one? No rush.",
    "Still waiting on you. Not sulking. Just saying.",
    "Hello? Anyone in there?"
  ],
  [
    "Wow. I see how it is then.",
    "Right. Message received. Loud and clear.",
    "Cool. Glad we are close."
  ],
  [
    "The fame has really gotten to you.",
    "You have changed. Everyone says it and I keep defending you.",
    "I will stop texting. You clearly have people for that now."
  ]
];
var COLD_WORK = [
  [
    "Chasing this one. Let me know either way.",
    "Still need an answer on that when you get a sec.",
    "Bumping this up your inbox."
  ],
  [
    "Wow. I see how it is.",
    "Two months, nothing. Noted.",
    "I will assume that is a no then."
  ],
  [
    "The fame has really gotten to you.",
    "You were easier to deal with before all this.",
    "I will stop bothering you. Best of luck."
  ]
];
var WARM_CONTACTS = ["mum", "dad", "grandad", "partner", "bestmate", "youthcoach", "academy"];
var REL_FLOOR = 22;
function blankPhone() {
  return {
    threads: [],
    feed: [],
    world: null,
    clubs: {},
    rivalClub: null,
    seed: 1,
    offers: 0,
    perksTaken: 0
  };
}
function ensurePhone(s) {
  const p = s.phone;
  if (!p || typeof p !== "object") return blankPhone();
  const out = {
    threads: Array.isArray(p.threads) ? p.threads.filter((t) => t && Array.isArray(t.lines)) : [],
    feed: Array.isArray(p.feed) ? p.feed.filter((f) => typeof f === "string") : [],
    world: p.world && typeof p.world === "object" ? p.world : null,
    clubs: p.clubs && typeof p.clubs === "object" ? p.clubs : {},
    rivalClub: typeof p.rivalClub === "string" ? p.rivalClub : null,
    seed: typeof p.seed === "number" && p.seed > 0 ? p.seed : 1,
    offers: typeof p.offers === "number" ? p.offers : 0,
    perksTaken: typeof p.perksTaken === "number" ? p.perksTaken : 0
  };
  for (const t of out.threads) {
    if (typeof t.rel !== "number" || !Number.isFinite(t.rel)) t.rel = 50;
    t.rel = clamp2(Math.round(t.rel), 0, 100);
    if (typeof t.cold !== "number") t.cold = 0;
    if (!Array.isArray(t.seen)) t.seen = [];
    if (t.waiting === void 0) t.waiting = null;
    if (t.lastReplyYear === void 0) t.lastReplyYear = null;
    if (t.pending === void 0) t.pending = null;
  }
  return out;
}
function writePhone(s, p) {
  s.phone = p;
}
var yearOf = (s) => s.seasons.length > 0 ? s.seasons[s.seasons.length - 1].year : 2020;
function threadFor(p, id, s) {
  let t = p.threads.find((x) => x.c === id);
  if (t) {
    t.name = contactName(id, s);
    return t;
  }
  t = {
    id: `th_${id}`,
    c: id,
    name: contactName(id, s),
    emoji: contactEmoji(id),
    lines: [],
    rel: 50,
    pending: null,
    waiting: null,
    cold: 0,
    seen: [],
    lastReplyYear: null
  };
  p.threads.push(t);
  return t;
}
function pushLine(t, who, text2, year) {
  if (!text2) return;
  t.lines.push({ w: who, t: text2, y: year });
  if (t.lines.length > MAX_LINES) t.lines.splice(0, t.lines.length - MAX_LINES);
}
function trimThreads(p) {
  while (p.threads.length > MAX_THREADS) {
    let idx = p.threads.findIndex((t) => t.pending === null);
    if (idx === -1) idx = 0;
    p.threads.splice(idx, 1);
  }
}
function convoEligible(def, s, phase, t) {
  if (def.phase !== "any" && def.phase !== phase) return false;
  if (def.minAge !== void 0 && s.age < def.minAge) return false;
  if (def.maxAge !== void 0 && s.age > def.maxAge) return false;
  if (!contactAvailable(def.contact, s, phase)) return false;
  if (def.needs && !def.needs(s)) return false;
  if (t && t.seen.includes(def.id)) return false;
  return true;
}
function startConvo(t, def, year, override) {
  t.seen.push(def.id);
  if (t.seen.length > MAX_SEEN) t.seen.splice(0, t.seen.length - MAX_SEEN);
  pushLine(t, 0, override ?? def.beats[0].text, year);
  t.pending = { kind: "convo", convo: def.id, beat: 0 };
  t.waiting = year;
}
function pickConvo(s, p, t, phase) {
  const rng = new Rng(p.seed);
  const fits = CONVOS.filter((d) => d.contact === t.c && convoEligible(d, s, phase, t));
  p.seed = rng.state;
  if (fits.length === 0) return null;
  return fits[Math.floor(rng.next() * fits.length)];
}
function phoneSeasonTick(s, phase) {
  const p = ensurePhone(s);
  const year = yearOf(s);
  const rng = new Rng(p.seed || Math.floor(Math.random() * 4294967295) >>> 0 || 7);
  const BITE = [14, 9, 5];
  for (const t of p.threads) {
    if (t.pending && t.waiting !== null && t.waiting < year) {
      if (t.cold >= 3) {
        t.waiting = year;
        continue;
      }
      t.cold = Math.min(3, t.cold + 1);
      t.rel = clamp2(t.rel - BITE[t.cold - 1], REL_FLOOR, 100);
      const table = WARM_CONTACTS.includes(t.c) ? COLD_WARM : COLD_WORK;
      const stage = table[Math.min(t.cold, table.length) - 1];
      pushLine(t, 0, stage[rng.int(0, stage.length - 1)], year);
      t.waiting = year;
    }
  }
  const standing = standingOf(p);
  if (p.threads.length > 0) {
    const ceiling = 56 + Math.round(standing * 0.38);
    if (standing < 42 && s.morale > 46) s.morale = clamp2(Math.max(46, s.morale - 3), 0, 100);
    else if (standing > 60 && s.morale < ceiling) s.morale = clamp2(Math.min(ceiling, s.morale + 3), 0, 100);
    if (standing >= 70 && s.popularity < 70) s.popularity = clamp2(s.popularity + 1, 0, 100);
    else if (standing <= 30 && s.popularity > 40) s.popularity = clamp2(s.popularity - 1, 0, 100);
  }
  const waitingNow = p.threads.filter((t) => t.pending !== null).length;
  let want = Math.max(0, 2 - waitingNow);
  const candidates = CONTACTS.map((c) => c.id).filter((id) => contactAvailable(id, s, phase)).filter((id) => {
    const t = p.threads.find((x) => x.c === id);
    return !t || t.pending === null;
  });
  for (let i = candidates.length - 1; i > 0; i--) {
    const j = Math.floor(rng.next() * (i + 1));
    [candidates[i], candidates[j]] = [candidates[j], candidates[i]];
  }
  for (const id of candidates) {
    if (want <= 0) break;
    const t = threadFor(p, id, s);
    const def = pickConvo(s, p, t, phase);
    if (!def) {
      if (t.lines.length === 0) p.threads = p.threads.filter((x) => x !== t);
      continue;
    }
    startConvo(t, def, year);
    want -= 1;
  }
  p.seed = rng.state;
  trimThreads(p);
  writePhone(s, p);
}
function legacyContact(from) {
  const f = from.toLowerCase();
  if (f.includes("mum")) return "mum";
  if (f.includes("grandad")) return "grandad";
  if (f.includes("agent")) return "agent";
  if (f.includes("kit man")) return "kitman";
  if (f.includes("journal")) return "journo";
  if (f.includes("youth coach")) return "youthcoach";
  if (f.includes("academy")) return "academy";
  if (f.includes("captain") || f.includes("veteran")) return "captain";
  if (f.includes("physio") || f.includes("psych") || f.includes("nutrition")) return "physio";
  if (f.includes("fitness")) return "fitness";
  if (f.includes("teammate")) return "roomie";
  if (f.includes("rival")) return "rival";
  if (f.includes("school friend")) return "bestmate";
  return null;
}
var slug = (v) => v.toLowerCase().replace(/[^a-z0-9]+/g, "").slice(0, 14) || "x";
function mirrorLegacyMessage(s, msgId, from, text2, year) {
  const p = ensurePhone(s);
  const id = legacyContact(from);
  let t;
  if (id) {
    t = threadFor(p, id, s);
  } else {
    const tid = `th_x_${slug(from)}`;
    const found = p.threads.find((x) => x.id === tid);
    if (found) t = found;
    else {
      t = { id: tid, c: "other", name: from, emoji: "\u{1F4AC}", lines: [], rel: 50, pending: null, waiting: null, cold: 0, seen: [], lastReplyYear: null };
      p.threads.push(t);
    }
  }
  if (t.pending) return;
  pushLine(t, 0, text2, year);
  t.pending = { kind: "legacy", msgId };
  t.waiting = year;
  trimThreads(p);
  writePhone(s, p);
}
function standingOf(p) {
  if (p.threads.length === 0) return 50;
  const sum = p.threads.reduce((a, t) => a + t.rel, 0);
  return Math.round(sum / p.threads.length);
}
function phoneAppsSwing(s) {
  const p = s.phone;
  if (!p || !Array.isArray(p.threads) || p.threads.length === 0) return 0;
  const v = standingOf(p);
  if (v >= 76) return 3;
  if (v >= 64) return 2;
  if (v <= 24) return -3;
  if (v <= 36) return -2;
  return 0;
}
var ATTACKING = ["ST", "LW", "RW", "CAM"];
var LAST_REAL_YEAR = 2032;
function leagueOfClub(club, leagues) {
  for (const [name, clubs] of Object.entries(leagues)) if (clubs.includes(club)) return name;
  return null;
}
function leaguePhrase(name) {
  return /^(la |serie |ligue |eredivisie|primeira|liga )/i.test(name) ? name : `the ${name}`;
}
function pruneClubs(p) {
  const keys = Object.keys(p.clubs);
  if (keys.length <= MAX_WORLD_NAMES) return;
  const drop = keys.slice(0, keys.length - MAX_WORLD_NAMES);
  for (const k of drop) delete p.clubs[k];
}
function worldClubOf(s, name) {
  const p = s.phone;
  if (!p || !p.clubs) return null;
  return p.clubs[name] ?? null;
}
function worldSeasonTick(s, opts) {
  const p = ensurePhone(s);
  const rng = new Rng(p.seed || Math.floor(Math.random() * 4294967295) >>> 0 || 11);
  const { year } = opts;
  const topClubs = getEraTopClubs(year);
  const leagues = getEraLeagueClubs(year);
  const allClubs = Array.from(/* @__PURE__ */ new Set([...topClubs, ...Object.values(leagues).flat()]));
  const realNames = year <= LAST_REAL_YEAR;
  let stars;
  if (realNames) {
    stars = getEraStars(year).map((st) => ({ ...st, baseGoals: st.baseGoals }));
  } else {
    const seen = /* @__PURE__ */ new Set();
    stars = [];
    for (let i = 0; i < 14 && stars.length < 8; i++) {
      const name = getEraRivalName(year);
      if (seen.has(name)) continue;
      seen.add(name);
      stars.push({
        name,
        position: rng.next() < 0.45 ? "ST" : "CM",
        club: allClubs[Math.floor(rng.next() * allClubs.length)],
        baseGoals: [10, 26],
        power: rng.int(4, 9)
      });
    }
  }
  for (const st of stars) if (!p.clubs[st.name]) p.clubs[st.name] = st.club;
  const moves = [];
  const movers = stars.slice();
  for (let i = movers.length - 1; i > 0; i--) {
    const j = Math.floor(rng.next() * (i + 1));
    [movers[i], movers[j]] = [movers[j], movers[i]];
  }
  const wanted = rng.int(2, 4);
  const movedAlready = /* @__PURE__ */ new Set();
  for (const st of movers) {
    if (moves.length >= wanted) break;
    if (movedAlready.has(st.name)) continue;
    movedAlready.add(st.name);
    const from = p.clubs[st.name];
    if (!from) continue;
    const pool = rng.next() < 0.6 ? topClubs : allClubs;
    const dests = pool.filter((c) => c !== from && c !== s.currentClub);
    if (dests.length === 0) continue;
    const to = dests[Math.floor(rng.next() * dests.length)];
    const fee = Math.round((22 + st.power * 7 + rng.int(0, 34)) / 5) * 5;
    p.clubs[st.name] = to;
    moves.push({ who: st.name, from, to, fee });
  }
  const notMine = (clubs, won) => {
    if (won) return [s.currentClub];
    const rest = clubs.filter((c) => c !== s.currentClub);
    return rest.length ? rest : clubs;
  };
  const draw = (clubs) => clubs[Math.floor(rng.next() * clubs.length)];
  const leagueWinners = {};
  const cupWinners = {};
  const myLeague = leagueKeyInYear({ name: s.currentClub, league: s.currentLeague }, year) ?? (ledgerLeague(s.currentLeague, year) ? null : s.currentLeague);
  for (const [name, clubs] of Object.entries(leagues)) {
    const mine = name === myLeague;
    leagueWinners[name] = draw(notMine(clubs, mine && opts.playerLeagueTitle));
    const assoc = WORLD_LEAGUE_ASSOCIATION[name];
    if (assoc === void 0 || opts.playerCupAssociation === void 0) {
      cupWinners[name] = draw(notMine(clubs, mine && !!opts.playerCup));
      continue;
    }
    const entrants = clubs.filter((c) => {
      const a = opts.cupAssociationOf?.(c) ?? null;
      return a === null || a === assoc;
    });
    if (cupFor(assoc, year).kind === "NONE" || entrants.length === 0) {
      rng.next();
      continue;
    }
    cupWinners[name] = draw(notMine(entrants, assoc === opts.playerCupAssociation && !!opts.playerCup));
  }
  const ucl = draw(notMine(topClubs, opts.playerUcl));
  const forwards = stars.filter((st) => ATTACKING.includes(st.position));
  let topScorer = null;
  if (forwards.length > 0) {
    const st = forwards[Math.floor(rng.next() * forwards.length)];
    const club = p.clubs[st.name] ?? st.club;
    const goals = rng.int(st.baseGoals[0], st.baseGoals[1]);
    topScorer = { who: st.name, club, goals, league: leagueOfClub(club, leagues) ?? "the league" };
  }
  const t = s.lastTournament;
  const intl = t && t.year === year && t.champion ? { name: t.name, champion: t.champion } : null;
  const world = { year, ucl, leagues: leagueWinners, cups: cupWinners, moves, topScorer, intl };
  p.world = world;
  const items = [];
  for (const m of moves) {
    items.push(`\u{1F504} DONE DEAL. ${m.who} joins ${m.to} from ${m.from}. Fee around ${m.fee}m.`);
  }
  if (s.rival && !s.rival.retired && p.rivalClub && p.rivalClub !== s.rival.club) {
    items.push(`\u{1F504} ${s.rival.name} has left ${p.rivalClub} for ${s.rival.club}.`);
  }
  if (ucl !== s.currentClub) items.push(`\u2B50 ${ucl} are champions of Europe.`);
  const titles = Object.entries(leagueWinners).filter(([, club]) => club !== s.currentClub);
  for (const [lg, club] of titles.slice(0, 2)) {
    items.push(`\u{1F3C6} ${club} win ${leaguePhrase(lg)}.`);
  }
  if (topScorer && topScorer.club !== s.currentClub) {
    const where = topScorer.league === "the league" ? "his league" : leaguePhrase(topScorer.league);
    items.push(`\u{1F945} ${topScorer.who} finished top scorer in ${where} on ${topScorer.goals}.`);
  }
  if (intl) items.push(`\u{1F30D} ${intl.champion} win the ${intl.name}.`);
  p.feed = [...p.feed, ...items].slice(-MAX_FEED);
  p.rivalClub = s.rival && !s.rival.retired ? s.rival.club : null;
  p.seed = rng.state;
  pruneClubs(p);
  writePhone(s, p);
  return world;
}

// src/lib/careerMoney.ts
var MAX_HISTORY = 8;
var MAX_LEDGER = 12;
var CASH_FLOOR = 0.1;
var TRADE_FEE = 0.01;
var SAVINGS_RATE = 0.025;
var ASSETS = [
  {
    id: "ladder",
    name: "Steady Ladder Fund",
    emoji: "\u{1F4D7}",
    kind: "fund",
    blurb: "A bit of everything. Boring on purpose.",
    drift: 0.055,
    vol: 0.05,
    pull: 0.55,
    risk: "steady"
  },
  {
    id: "bricks",
    name: "Old Town Bricks",
    emoji: "\u{1F9F1}",
    kind: "property",
    blurb: "Flats above the shops back home.",
    drift: 0.04,
    vol: 0.11,
    pull: 0.4,
    risk: "steady"
  },
  {
    id: "cleats",
    name: "Cleatworks",
    emoji: "\u{1F45F}",
    kind: "share",
    blurb: "They make boots. Half the league wears them.",
    drift: 0.032,
    vol: 0.17,
    pull: 0.35,
    risk: "bumpy"
  },
  {
    id: "screens",
    name: "Matchday Screens",
    emoji: "\u{1F4FA}",
    kind: "share",
    blurb: "Sells the rights, sells the ads, sells the highlights.",
    drift: 0.025,
    vol: 0.22,
    pull: 0.32,
    risk: "bumpy"
  },
  {
    id: "spark",
    name: "SparkCoin",
    emoji: "\u26A1",
    kind: "coin",
    blurb: "A coin your mate's cousin made. Halves as often as it doubles.",
    drift: 0.01,
    vol: 0.5,
    pull: 0.25,
    risk: "wild"
  }
];
var ASSET_BY_ID = Object.fromEntries(ASSETS.map((a) => [a.id, a]));
var PAR = 100;
function nextSeed2(s) {
  return s * 1664525 + 1013904223 >>> 0;
}
var Rng2 = class {
  constructor(s) {
    this.s = s;
    this.s = s >>> 0 || 1;
  }
  next() {
    this.s = nextSeed2(this.s);
    return this.s / 4294967296;
  }
  get state() {
    return this.s;
  }
  int(lo, hi) {
    return lo + Math.floor(this.next() * (hi - lo + 1));
  }
  /** Roughly normal, mean 0, standard deviation 1. Three uniforms is plenty
   *  for a price shock and it costs nothing. */
  gauss() {
    return (this.next() + this.next() + this.next() - 1.5) / 0.5;
  }
};
var clamp3 = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
var r2 = (v) => Math.round(v * 100) / 100;
var r4 = (v) => Math.round(v * 1e4) / 1e4;
function seedFromName(name, salt) {
  const born = (name || "x").split("").reduce((h, c) => h * 31 + c.charCodeAt(0) >>> 0, 7);
  return born ^ salt * 2654435761;
}
function blankMoney(seed) {
  const price = {};
  const hist = {};
  const hold = {};
  const cost = {};
  for (const a of ASSETS) {
    price[a.id] = PAR;
    hist[a.id] = [PAR];
    hold[a.id] = 0;
    cost[a.id] = 0;
  }
  return {
    seed: seed >>> 0 || 1,
    vault: 0,
    hold,
    cost,
    price,
    hist,
    log: [],
    year: 0,
    age: 0,
    won: 0,
    lost: 0,
    cPlays: 0,
    cNet: 0,
    cYear: 0,
    cShut: false,
    aYear: 0,
    aBest: 0,
    aPlays: 0
  };
}
var num = (v, fallback) => typeof v === "number" && Number.isFinite(v) ? v : fallback;
function ensureMoney(s, sport) {
  const raw = s.money;
  const out = blankMoney(sport.seedOf(s));
  if (!raw || typeof raw !== "object") return out;
  out.seed = num(raw.seed, out.seed) >>> 0 || 1;
  out.vault = Math.max(0, r2(num(raw.vault, 0)));
  out.year = Math.round(num(raw.year, 0));
  out.age = Math.max(0, Math.round(num(raw.age, 0)));
  out.won = Math.max(0, r2(num(raw.won, 0)));
  out.lost = Math.max(0, r2(num(raw.lost, 0)));
  out.cPlays = Math.max(0, Math.round(num(raw.cPlays, 0)));
  out.cNet = r2(num(raw.cNet, 0));
  out.cYear = Math.round(num(raw.cYear, 0));
  out.cShut = raw.cShut === true;
  out.aYear = Math.round(num(raw.aYear, 0));
  out.aBest = clamp3(Math.round(num(raw.aBest, 0)), 0, 3);
  out.aPlays = Math.max(0, Math.round(num(raw.aPlays, 0)));
  for (const a of ASSETS) {
    const p = num(raw.price?.[a.id], PAR);
    out.price[a.id] = clamp3(r2(p), 1, PAR * 40);
    out.hold[a.id] = Math.max(0, r4(num(raw.hold?.[a.id], 0)));
    out.cost[a.id] = Math.max(0, r2(num(raw.cost?.[a.id], 0)));
    const h = Array.isArray(raw.hist?.[a.id]) ? raw.hist[a.id].filter((v) => typeof v === "number" && Number.isFinite(v)) : [];
    out.hist[a.id] = (h.length ? h : [out.price[a.id]]).slice(-MAX_HISTORY).map((v) => clamp3(r2(v), 1, PAR * 40));
  }
  const log2 = Array.isArray(raw.log) ? raw.log : [];
  out.log = log2.filter((e) => e && typeof e === "object" && typeof e.t === "string").slice(-MAX_LEDGER).map((e) => ({ y: Math.round(num(e.y, 0)), t: String(e.t).slice(0, 40), a: r2(num(e.a, 0)) }));
  return out;
}
function writeMoney(s, m) {
  s.money = m;
}
var cashOf = (s) => s.netWorth ?? 0;
function note(m, year, text2, amount) {
  m.log.push({ y: year, t: text2.slice(0, 40), a: r2(amount) });
  if (m.log.length > MAX_LEDGER) m.log.splice(0, m.log.length - MAX_LEDGER);
}
function holdingValue(m, id) {
  return r2((m.hold[id] ?? 0) * (m.price[id] ?? PAR) / PAR);
}
function moneyWealth(s, sport) {
  const m = ensureMoney(s, sport);
  let total = m.vault;
  for (const a of ASSETS) total += holdingValue(m, a.id);
  return r2(total);
}
function investedValue(m) {
  let total = 0;
  for (const a of ASSETS) total += holdingValue(m, a.id);
  return r2(total);
}
function anchorOf(def, age) {
  return PAR * Math.pow(1 + def.drift, age);
}
function moneySeasonTick(s, year, sport) {
  const m = ensureMoney(s, sport);
  const fmt = (v) => fmtMoney(v, sport.currency);
  const events = [];
  if (m.year === year) {
    writeMoney(s, m);
    return { events };
  }
  m.year = year;
  m.age += 1;
  const rng = new Rng2(m.seed);
  if (m.vault > 0) {
    const interest = r2(m.vault * SAVINGS_RATE);
    if (interest >= 0.01) {
      m.vault = r2(m.vault + interest);
      m.won = r2(m.won + interest);
      note(m, year, "Savings interest", interest);
    }
  }
  for (const def of ASSETS) {
    const anchor = anchorOf(def, m.age);
    const p = m.price[def.id] ?? PAR;
    const shocked = p * (1 + def.vol * rng.gauss());
    let next = shocked + def.pull * (anchor - shocked);
    next = clamp3(next, anchor * 0.18, anchor * 3.4);
    next = clamp3(r2(next), 3, PAR * 40);
    const before = p;
    m.price[def.id] = next;
    const h = m.hist[def.id] ?? [];
    h.push(next);
    if (h.length > MAX_HISTORY) h.splice(0, h.length - MAX_HISTORY);
    m.hist[def.id] = h;
    if ((m.hold[def.id] ?? 0) > 0 && events.length < 2) {
      const move = (next - before) / Math.max(before, 1);
      if (move >= 0.28) {
        events.push(`${def.emoji} ${def.name} jumped ${Math.round(move * 100)}%. Your stake is worth ${fmt(holdingValue(m, def.id))} now.`);
      } else if (move <= -0.25) {
        events.push(`${def.emoji} ${def.name} dropped ${Math.round(-move * 100)}%. Your stake is down to ${fmt(holdingValue(m, def.id))}.`);
      }
    }
  }
  if (cashOf(s) < CASH_FLOOR) {
    let need = r2(CASH_FLOOR - cashOf(s));
    if (m.vault > 0 && need > 0) {
      const take = Math.min(m.vault, need);
      m.vault = r2(m.vault - take);
      s.netWorth = r2(cashOf(s) + take);
      need = r2(need - take);
      note(m, year, "Savings covered the bills", -take);
      events.push(`\u{1F3E6} Bills came out of savings this season. ${fmt(take)} gone.`);
    }
    const order = ASSETS.slice().sort((a, b) => holdingValue(m, b.id) - holdingValue(m, a.id));
    for (const def of order) {
      if (need <= 0) break;
      const value = holdingValue(m, def.id);
      if (value <= 0.01) continue;
      const frac = Math.min(1, need / value);
      const got = sellUnits(m, def.id, frac, year, true);
      s.netWorth = r2(cashOf(s) + got);
      need = r2(need - got);
      events.push(`\u{1F4C9} Had to sell ${def.name} to cover the bills. ${fmt(got)} raised at a bad price.`);
    }
  }
  const buffer = m.vault + investedValue(m);
  const bill = Math.max(0.2, sport.billOf(s) || 0.2);
  if (cashOf(s) + buffer < bill * 0.75) {
    if (s.morale > 44) s.morale = clamp3(Math.max(44, s.morale - 3), 0, 100);
  } else if (buffer >= bill * 3 && s.morale < 64) {
    s.morale = clamp3(Math.min(64, s.morale + 2), 0, 100);
  }
  const w = sport.words.cards;
  if (m.cPlays >= 4 && m.cNet <= -0.12 && !m.cShut && m.cYear === year) {
    s.morale = clamp3(s.morale - 3, 0, 100);
    sport.shame(s);
    events.push(`\u{1F0CF} Somebody at home asked how much you have actually lost ${w.thatPlace}. You did not have a good answer.`);
  }
  if (m.cNet <= -0.5 && !m.cShut) {
    m.cShut = true;
    events.push(`\u{1F0CF} ${w.crewCap} have stopped dealing you in. Honestly, that is probably for the best.`);
  }
  m.seed = rng.state;
  writeMoney(s, m);
  return { events };
}
function sellUnits(m, id, frac, year, forced = false) {
  const held = m.hold[id] ?? 0;
  if (held <= 0) return 0;
  const f = clamp3(frac, 0, 1);
  const units = r4(held * f);
  if (units <= 0) return 0;
  const gross = units * (m.price[id] ?? PAR) / PAR;
  const cash = r2(gross * (1 - TRADE_FEE));
  const basis = r2((m.cost[id] ?? 0) * f);
  m.hold[id] = r4(held - units);
  m.cost[id] = r2(Math.max(0, (m.cost[id] ?? 0) - basis));
  if (m.hold[id] <= 1e-4) {
    m.hold[id] = 0;
    m.cost[id] = 0;
  }
  const profit = r2(cash - basis);
  if (profit >= 0) m.won = r2(m.won + profit);
  else m.lost = r2(m.lost - profit);
  const def = ASSET_BY_ID[id];
  note(m, year, `${forced ? "Forced sale" : "Sold"} ${def.name}`, cash);
  return cash;
}
function fmtMoney(v, currency) {
  const neg = v < 0;
  const a = Math.abs(v);
  const body = a >= 1e3 ? `${currency}${(a / 1e3).toFixed(2)}bn` : a >= 1 ? `${currency}${a.toFixed(1)}M` : `${currency}${Math.round(a * 1e3)}k`;
  return neg ? `-${body}` : body;
}

// src/lib/soccerMoney.ts
var clamp4 = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
var SOCCER_MONEY = {
  currency: "\u20AC",
  seedOf: (s) => seedFromName(s.playerName, s.seasons?.length ?? 0),
  yearOf: (s) => s.seasons.length > 0 ? s.seasons[s.seasons.length - 1].year : 2020,
  billOf: (s) => s.lifestyleCostPerYear,
  shame: (s) => {
    s.karma = clamp4((s.karma ?? 50) - 2, 0, 100);
  },
  words: {
    cards: {
      ledger: "Cards on the bus",
      crew: "the lads",
      crewCap: "The lads",
      where: "on the bus",
      thatPlace: "on that bus",
      next: "Next away trip."
    },
    arcade: { ledger: "Won the phone quiz", name: "the ball quiz" }
  }
};
function ensureMoney2(s) {
  return ensureMoney(s, SOCCER_MONEY);
}
function moneyWealth2(s) {
  return moneyWealth(s, SOCCER_MONEY);
}
function moneySeasonTick2(s, year) {
  return moneySeasonTick(s, year, SOCCER_MONEY);
}

// src/lib/careerInbox.ts
var clamp5 = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
function pickInboxTexts(pool, age, phase, usedIds, count, rng = Math.random) {
  const used = new Set(usedIds);
  const fits = pool.filter(
    (t) => !used.has(t.id) && (t.phase === "any" || t.phase === phase) && (t.minAge === void 0 || age >= t.minAge) && (t.maxAge === void 0 || age <= t.maxAge)
  );
  const out = [];
  const left = [...fits];
  while (out.length < count && left.length > 0) {
    const i = Math.floor(rng() * left.length);
    out.push(left[i]);
    left.splice(i, 1);
  }
  return out;
}
function pickBeatTexts(pool, calendar, beats, age, phase, usedIds, count, rng = Math.random) {
  const atBeat = (b) => pool.filter((t) => t.beat === b.id);
  const open = calendar.filter(
    (b) => beats.includes(b.id) && pickInboxTexts(atBeat(b), age, phase, usedIds, 1, () => 0).length > 0
  );
  const chosen = open.filter((b) => b.oneOff).slice(0, count);
  const rest = open.filter((b) => !b.oneOff);
  while (chosen.length < count && rest.length > 0) {
    const i = Math.floor(rng() * rest.length);
    chosen.push(rest[i]);
    rest.splice(i, 1);
  }
  chosen.sort((a, b) => calendar.indexOf(a) - calendar.indexOf(b));
  return chosen.map((b) => ({ def: pickInboxTexts(atBeat(b), age, phase, usedIds, 1, rng)[0], beat: b.id }));
}
function receiveInboxTexts(s, phase, sport, rng = Math.random, beats) {
  driftInboxMood(s, sport);
  return deliverInboxTexts(s, phase, sport, rng, beats);
}
function driftInboxMood(s, sport) {
  const mood = sport.moodOf(s);
  const next = mood > 50 ? mood - 2 : mood < 50 ? Math.min(50, mood + 2) : mood;
  if (next >= 70) {
    sport.addPopularity(s, 2);
    s.morale = clamp5(s.morale + 2, 0, 100);
  } else if (next <= 30) {
    sport.addPopularity(s, -2);
    s.morale = clamp5(s.morale - 1, 0, 100);
  }
  sport.setMood(s, next);
}
function deliverInboxTexts(s, phase, sport, rng = Math.random, beats) {
  const inbox = [...s.phoneInbox ?? []];
  const used = [...s.phoneUsedIds ?? []];
  const unanswered = inbox.filter((m) => m.answered === void 0).length;
  const want = Math.max(0, sport.wantPerSeason - unanswered);
  const year = sport.yearOf(s);
  const age = sport.ageOf(s);
  const fresh = [];
  const deliver = (def, beat) => {
    const msg = { id: `${def.id}-${year}`, defId: def.id, from: def.from, emoji: def.emoji, text: def.text, year, choices: def.choices, ...beat ? { beat } : {} };
    inbox.push(msg);
    fresh.push(msg);
    used.push(def.id);
  };
  if (beats === void 0) {
    for (const def of pickInboxTexts(sport.pool, age, phase, used, want, rng)) {
      deliver(def);
    }
  } else {
    for (const pick3 of pickBeatTexts(sport.pool, sport.calendar ?? [], beats, age, phase, used, want, rng)) {
      deliver(pick3.def, pick3.beat);
    }
  }
  while (inbox.length > sport.maxInbox) {
    const idx = inbox.findIndex((m) => m.answered !== void 0);
    if (idx === -1) break;
    inbox.splice(idx, 1);
  }
  s.phoneInbox = inbox;
  s.phoneUsedIds = used;
  return fresh;
}

// src/lib/careerRivalryEvents.ts
function rivalryEventPool(p, r, defs) {
  return defs.filter((d) => d.when(p, r)).map((d) => ({ id: d.id, emoji: d.emoji, title: d.title, description: d.description(p, r), consequence: d.consequence }));
}
function rollRivalryEvent(p, r, lastId, defs, rng = Math.random) {
  if (!r || r.retired) return null;
  if (rng() >= 0.5) return null;
  const pool = rivalryEventPool(p, r, defs).filter((e) => e.id !== lastId);
  if (pool.length === 0) return null;
  return pool[Math.floor(rng() * pool.length)];
}
function forcedRetirementEvent(p, r, lastId, defs, retirementEventId) {
  if (!r?.retired || lastId === retirementEventId) return null;
  return rivalryEventPool(p, r, defs).find((e) => e.id === retirementEventId) ?? null;
}

// src/lib/intlNames.ts
var NAME_FAMILIES = [
  {
    id: "anglo",
    firsts: ["Adam", "Craig", "Dean", "Eddie", "Grant", "Neil", "Ross", "Scott", "Shane", "Stuart", "Warren", "Wesley"],
    lasts: ["Ashcroft", "Baxter", "Chadwick", "Dunmore", "Garnett", "Hollis", "Kingsley", "Marlowe", "Prescott", "Radlett", "Stanhope", "Whitlock"]
  },
  {
    id: "hispanic",
    firsts: ["Agust\xEDn", "Bruno", "Cristian", "Dami\xE1n", "Ezequiel", "Facundo", "Ignacio", "Joaqu\xEDn", "Leandro", "Maxi", "Nahuel", "Tom\xE1s"],
    /* 'Ledesma' was here until the collision harness paired it with Cristian
       and matched a real player. The pools are ordinary names on purpose,
       and this is exactly the catch they exist for. */
    lasts: ["Arrieta", "Bengoechea", "Cardozo", "Duarte", "Escalante", "Gorosito", "Lombardero", "Maldonado", "Ocampo", "Quiroga", "Urribarri", "Vergara"]
    /* 'Quiroga' paired with Facundo is a real man of the 2005-06 Bundesliga:
       see REAL_PAIR_SWAPS below for why only that one pairing changed. */
  },
  {
    id: "iberian",
    firsts: ["Aitor", "Borja", "Curro", "Eneko", "Guillem", "\xCD\xF1igo", "Jorge", "Manu", "Nacho", "Oriol", "Rub\xE9n", "Unai"],
    lasts: ["Aguirregomezcorta", "Barrag\xE1n", "Cendoya", "Elizalde", "Gazta\xF1aga", "Herrezuelo", "Larra\xF1aga", "Mendiz\xE1bal", "Otxoa", "Puigdemont", "Sanchidri\xE1n", "Zubizarreta"]
  },
  {
    id: "lusophone",
    firsts: ["Alceu", "Bento", "Dinis", "Edmilson", "Firmino", "Gilmar", "H\xE9lder", "Ivaldo", "Juvenal", "Marcelinho", "Nivaldo", "Wanderson"],
    lasts: ["Albuquerque", "Bragan\xE7a", "Carvalhal", "Damasceno", "Est\xEAv\xE3o", "Furtado", "Guimar\xE3es", "Machado", "Nogueira", "Paiva", "Quaresma", "Vasconcelos"]
  },
  {
    id: "italic",
    firsts: ["Alessio", "Cristiano", "Daniele", "Emanuele", "Fabrizio", "Giacomo", "Leonardo", "Massimo", "Riccardo", "Samuele", "Tommaso", "Vincenzo"],
    lasts: ["Baldacci", "Cangiano", "Dell Orco", "Frascatore", "Gervasoni", "Lucarelli-Motta", "Mazzantini", "Pellegrino", "Quagliarulo", "Sanguinetti", "Trevisani", "Zambrotti"]
  },
  {
    id: "francophone",
    firsts: ["Alban", "Baptiste", "Corentin", "Damien", "\xC9mile", "Ga\xEBl", "Herv\xE9", "Lo\xEFc", "Maxence", "Nolan", "Sylvain", "Yann"],
    lasts: ["Beaumont", "Chauvet", "Delcourt", "Ferrand", "Guillory", "Lallemand", "Marchetti", "Noirot", "Peyrelade", "Rousselot", "Thibaudeau", "Vaugrenard"]
  },
  {
    id: "dutch",
    firsts: ["Bas", "Daan", "Ferdi", "Gijs", "Hidde", "Joris", "Koen", "Mees", "Rick", "Sem", "Thijs", "Wout"],
    lasts: ["Aalbers", "Boterman", "Doornbos", "Grevelink", "Heemskerk", "Kortenhorst", "Lindeboom", "Nieuwland", "Oosterveen", "Rijkaard-Veen", "Schuurmans", "Vlietstra"]
  },
  {
    id: "germanic",
    firsts: ["Andreas", "Bastian", "Dominik", "Fabian", "Hendrik", "Jannik", "Konstantin", "Lennart", "Marius", "Nico", "Simon", "Til"],
    lasts: ["Achenbach", "Bergmiller", "Dettmar", "Ehrensberger", "Gundlach", "Hollerbach", "Kirchg\xE4ssner", "Lindenau", "Osterkamp", "Reinhardt", "Steinbr\xFCck", "Wittgenstein"]
    /* 'Reinhardt' paired with Bastian or with Dominik is a real man of the
       2005-06 Bundesliga: see REAL_PAIR_SWAPS below. */
  },
  {
    id: "nordic",
    firsts: ["Anders", "Birger", "Eivind", "Gustav", "Halvor", "Jesper", "Kasper", "Mikkel", "Odd", "Rasmus", "Sindre", "Torbj\xF8rn"],
    lasts: ["Aasheim", "Bj\xF8rkli", "Dahlgren", "Engebretsen", "Fredheim", "Gr\xF8ndahl", "Hovland-Rud", "Kvamme", "Lysgaard", "Nordvik", "S\xE6terb\xF8", "Vangen"]
  },
  {
    id: "finnic",
    firsts: ["Aapo", "Eetu", "Hannu", "Ilkka", "Jarkko", "Kalle", "Lauri", "Mikko", "Olli", "Petteri", "Sauli", "V\xE4in\xF6"],
    lasts: ["Aaltonen", "Heiskanen", "Jokinen", "Karhunen", "Lehtoranta", "M\xE4kip\xE4\xE4", "Nurminen", "Pulkkinen", "Rautiainen", "Salminen", "Tuominen", "Virtanen"]
  },
  {
    id: "slavicEast",
    firsts: ["Anatoliy", "Bohdan", "Denys", "Hryhoriy", "Ihor", "Kyrylo", "Maksym", "Ostap", "Pavlo", "Ruslan", "Vadym", "Yevhen"],
    lasts: ["Bondarenko", "Chernyshov", "Dovzhenko", "Hrytsenko", "Kolisnyk", "Lytvynenko", "Melnychuk", "Ostapchuk", "Pryimachenko", "Serhiyenko", "Tkachuk", "Zabolotny"]
  },
  {
    id: "slavicWest",
    firsts: ["Bartosz", "Czes\u0142aw", "Dawid", "Grzegorz", "Jakub", "Krzysztof", "Ludv\xEDk", "Marek", "Ond\u0159ej", "Radek", "Tade\xE1\u0161", "Zden\u011Bk"],
    lasts: ["Bednarczyk", "Chmielewski", "Dvo\u0159\xE1\u010Dek", "Grabowiec", "Jaworowski", "Kucharczyk", "Malinowski", "Nowakowski", "Posp\xED\u0161il", "Sokolowski", "Vondr\xE1\u010Dek", "Zieli\u0144ski"]
  },
  {
    id: "balkan",
    firsts: ["Andrej", "Boris", "Dejan", "Filip", "Goran", "Hrvoje", "Kre\u0161imir", "Milo\u0161", "Nemanja", "Petar", "Stjepan", "Vedran"],
    lasts: ["Antunovi\u0107", "Bogdanovi\u0107", "Cvijanovi\u0107", "Dragojlovi\u0107", "Golubovi\u0107", "Jankovac", "Kraljevi\u0107", "Milovanovi\u0107", "Petkovi\u0107", "Radulovi\u0107", "Stanojevi\u0107", "Vukmirovi\u0107"]
  },
  {
    id: "albanian",
    firsts: ["Agron", "Besnik", "Dritan", "Endrit", "Fatmir", "Gentian", "Ilir", "Kreshnik", "Luan", "Naim", "Sokol", "Valon"],
    lasts: ["Bardhi-Leka", "\xC7elaj", "Dervishi", "Gjonaj", "Hoxhallari", "Kastrati", "Lleshi", "Mustafaj", "Nik\xE7i", "Prifti", "Shkodra", "Zeneli"]
  },
  {
    id: "hellenic",
    firsts: ["Alexandros", "Christos", "Dimosthenis", "Efstathios", "Grigoris", "Ioannis", "Kyriakos", "Lambros", "Nikiforos", "Panagiotis", "Stelios", "Thanasis"],
    lasts: ["Andreadis", "Blatsis", "Chatzigeorgiou", "Dimopoulos", "Fotiadis", "Kalantzis", "Liakopoulos", "Mavridis", "Papadatos", "Sarantopoulos", "Tsimikakis", "Vlachopoulos"]
  },
  {
    id: "magyar",
    firsts: ["\xC1kos", "Bence", "Csaba", "D\xE1vid", "Ferenc", "Gerg\u0151", "Imre", "Krist\xF3f", "Levente", "M\xE1rton", "S\xE1ndor", "Zsolt"],
    lasts: ["Bakonyi", "Cseke", "Domb\xF3v\xE1ri", "Erd\xE9lyi", "Guly\xE1s", "Halmosi-R\xE1cz", "Kecskem\xE9ti", "Lakatos", "Novodomszky", "P\xE1sztor", "Szentgy\xF6rgyi", "V\xE1mosi"]
  },
  {
    id: "romanian",
    firsts: ["Andrei", "Bogdan", "C\u0103t\u0103lin", "Dorin", "Emilian", "Florin", "Gheorghi\u021B\u0103", "Iulian", "Marius", "Octavian", "Sorin", "Vasile"],
    lasts: ["Antonescu", "Br\xE2ncoveanu", "Cernat", "Dobrescu", "Filimon", "Grigora\u0219", "Iord\u0103nescu-Dima", "Marinescu", "Nedelcu", "P\xE2rvulescu", "Stoenescu", "Vl\u0103du\u021B"]
  },
  {
    id: "turkic",
    firsts: ["Alparslan", "Berkay", "Cengiz", "Doruk", "Emirhan", "Furkan", "G\xF6rkem", "Kaan", "Mert", "Onur", "Serkan", "Yusuf"],
    lasts: ["Akbulut", "Bayraktaro\u011Flu", "Cebeci", "Demirkol", "Erdo\u011Fdu", "G\xFCltekin", "Kara\xE7ay", "\xD6zt\xFCrkmen", "Sar\u0131kaya", "Tosuno\u011Flu", "Uzunhasan", "Y\u0131ld\u0131r\u0131mlar"]
  },
  {
    id: "arabic",
    firsts: ["Adnan", "Bilal", "Fawzi", "Ghassan", "Hicham", "Jalal", "Khalil", "Marwan", "Nabil", "Rachid", "Sami", "Walid"],
    lasts: ["Belkacemi", "Bouzidi", "Chaouki", "Fakhouri", "Hamdani", "Jaziri", "Khelifi", "Mansouri", "Nasrallah", "Qassemi", "Sabbagh", "Zerrouki"]
  },
  {
    id: "persian",
    firsts: ["Amirhossein", "Bahram", "Dariush", "Farhad", "Hooman", "Kambiz", "Mehrdad", "Nima", "Parviz", "Ramin", "Siavash", "Vahid"],
    lasts: ["Bahmanyar", "Dehghanpour", "Esfandiari", "Fereydouni", "Golzadeh", "Hosseinzadeh", "Kermanshahi", "Mirzakhani", "Nourbakhsh", "Rahmatian", "Shahriari", "Vaziripour"]
  },
  {
    id: "hebrew",
    firsts: ["Amit", "Barak", "Doron", "Eitan", "Gilad", "Idan", "Lior", "Nadav", "Omri", "Ronen", "Shaked", "Yoav"],
    lasts: ["Ben-Harush", "Dagan", "Eliyahu", "Goldwasser", "Harpaz", "Kaplansky", "Lugassi", "Mizrachi-Tal", "Ovadia", "Peretz", "Shternberg", "Yaakobi"]
  },
  {
    id: "westAfricaFr",
    firsts: ["Abdoulaye", "Bakary", "Cheikh", "Djibril", "Fod\xE9", "Ibrahima", "Lamine", "Modou", "Ousseynou", "Seydou", "Thierno", "Youssouf"],
    lasts: ["Badiane", "Camara-Sylla", "Dembour\xE9", "Faye-Ndour", "Gassama-Ndoye", "Kanout\xE9", "Mbengue", "Ndao", "Ouedraogo", "Sagna-Diatta", "Tandia", "Zoungrana"]
    /* 'Gassama' became 'Gassama-Ndoye' in Round 899: paired with Lamine above
       it matched a real man, Lorient's defender of 2015-16, who joined the
       2015-16 era with Ligue 1. Same move as 'Zwane' below. */
  },
  {
    id: "westAfricaEn",
    firsts: ["Abiodun", "Chinedu", "Ebenezer", "Femi", "Godwin", "Ikechukwu", "Kwabena", "Nnamdi", "Obinna", "Sylvester", "Tunde", "Uche"],
    lasts: ["Adeyinka", "Boakye-Mensah", "Chukwuemeka", "Danquah", "Eboh", "Gyimah", "Ikpeba-Ola", "Nwachukwu", "Obeng", "Sarpong", "Uzoma", "Yeboah-Antwi"]
  },
  {
    id: "southernAfrica",
    firsts: ["Bongani", "Dumisani", "Fanuel", "Kagiso", "Lehlohonolo", "Mpho", "Nkosinathi", "Oscar", "Sipho", "Themba", "Vusimuzi", "Zwelakhe"],
    lasts: ["Dlamini-Zuma", "Khumalo-Sithole", "Letsoalo", "Mabaso", "Mokoena-Radebe", "Ndlovu-Mahlangu", "Nyathi", "Phiri-Banda", "Sibanda", "Tshabalala-Moloi", "Zondi", "Mthethwa"]
    /* 'Zwane' left this bank in Round 199: paired with Themba above it
       matched a real South African international. The wider harvest that
       caught it reads every real name shipped anywhere in src/data, not
       just the four sealed worlds Round 197 checked against. */
  },
  {
    id: "japanese",
    firsts: ["Akihiro", "Daigo", "Fumiya", "Hayato", "Kenta", "Masaya", "Naoki", "Ryosuke", "Shohei", "Tatsuya", "Yuji", "Zenta"],
    lasts: ["Fujisawa", "Hasegawa", "Ishibashi", "Kawaguchi-Mori", "Matsushima", "Nishizawa", "Okazaki-Ueda", "Sakamoto", "Tachibana", "Uchiyama", "Yamagishi", "Yokoyama"]
  },
  {
    id: "korean",
    firsts: ["Byung-ho", "Chang-min", "Dong-hyun", "Gi-tae", "Hyun-woo", "Jin-seok", "Kyung-min", "Min-chul", "Sang-hoon", "Tae-yang", "Woo-jin", "Yong-soo"],
    lasts: ["Bae", "Chun", "Do", "Gwak", "Hyun", "Jang", "Koo", "Moon", "Noh", "Sim", "Wi", "Yun"]
  },
  {
    id: "chinese",
    firsts: ["Chenglong", "Dawei", "Guohua", "Haoran", "Jianguo", "Kaiwen", "Lianjie", "Mingyu", "Peixin", "Ruiqi", "Tianyou", "Zhihao"],
    lasts: ["Bai", "Cui", "Duan", "Fang", "Geng", "Hou", "Kong", "Lou", "Mao", "Qiu", "Shen", "Tan"]
  },
  {
    id: "seAsian",
    firsts: ["Anucha", "Chalerm", "Kittipong", "Narong", "Phuwadon", "Sarawut", "Somchai", "Thanawat", "Duy", "Hoang", "Quang", "Tuan"],
    lasts: ["Bunnag", "Chaiyasit", "Jaidee", "Kwanjai", "Nakarin", "Phromsuwan", "Rattanakosin", "Sukhothai", "Dinh Bao", "Le Cong", "Nguyen Khac", "Tran Huu"]
  },
  {
    id: "caribbean",
    firsts: ["Andre", "Devon", "Everton", "Junior", "Kemar", "Lennox", "Nigel", "Omar", "Ricardo", "Shaquille", "Tarik", "Wendell"],
    lasts: ["Beckles", "Charlemagne", "Duncanson", "Ferdinand-Joseph", "Gayle-Brown", "Isidore", "Lafontant", "Mullings", "Pierre-Louis", "Ricketts", "Saint-Fleur", "Thelusma"]
  },
  {
    id: "caucasus",
    firsts: ["Avtandil", "Beka", "Davit", "Giorgi", "Irakli", "Levan", "Nika", "Otar", "Revaz", "Shota", "Vakhtang", "Zurab"],
    lasts: ["Abashidze", "Beridze", "Chkheidze", "Dolidze", "Gogichaishvili", "Javakhishvili", "Kobakhidze", "Lomtadze", "Meskhi-Tsulaia", "Ninidze", "Shengelia", "Tabatadze"]
  },
  {
    id: "baltic",
    firsts: ["Aivars", "Deivydas", "Edgars", "Gintaras", "Jaanus", "Kaarel", "Mantas", "Normunds", "Raivo", "Tauno", "Valdis", "\u017Dygimantas"],
    lasts: ["B\u0113rzi\u0146kalns", "Dauk\u0161ys", "Egl\u012Btis", "Grinbergs", "J\xF5gisoo", "Kaljurand", "Mikla\u0161evi\u010Dius", "Ozoli\u0146\u0161", "Petrauskis", "Rebane-Tamm", "Skujenieks", "Vaitkevi\u010Dius"]
  },
  {
    id: "eastAfrica",
    firsts: ["Baraka", "Ephrem", "Getachew", "Hamisi", "Juma", "Kipchoge", "Mulugeta", "Nasir", "Onyango", "Rashidi", "Tewodros", "Wafula"],
    lasts: ["Abebayehu", "Bekele-Girma", "Chelimo", "Kamau-Njoroge", "Lemma", "Mwangangi", "Nakabugo", "Odongo-Ochieng", "Rutayisire", "Ssemakula", "Tesfamariam", "Wanyonyi"]
  },
  {
    id: "southAsia",
    firsts: ["Aakash", "Bipin", "Dinesh", "Farhan", "Gurpreet", "Harshit", "Jeevan", "Kunal", "Nabeel", "Prabhat", "Rohit", "Vikram"],
    lasts: ["Bhattacharya", "Chandrasekar", "Dhanraj", "Gopalakrishnan", "Hariharan", "Karunakaran", "Mahalingam", "Narayanaswamy", "Ramanathan", "Sivaramakrishnan", "Thiruvengadam", "Venkataraman"]
  },
  {
    id: "oceania",
    firsts: ["Ari", "Blake", "Cody", "Declan", "Hemi", "Jarrah", "Kalani", "Lachlan", "Nikau", "Reece", "Tane", "Wiremu"],
    lasts: ["Barrowman", "Cottrell", "Fenwick", "Halligan", "Kelleher", "Lamplough", "Mataitonga", "Ngatai", "Poutasi", "Rangihau", "Tamehana", "Waverley"]
  }
];
var NATION_FAMILY = {
  England: "anglo",
  Scotland: "anglo",
  Wales: "anglo",
  Ireland: "anglo",
  "Northern Ireland": "anglo",
  USA: "anglo",
  Canada: "anglo",
  Australia: "oceania",
  "New Zealand": "oceania",
  Spain: "iberian",
  Portugal: "lusophone",
  Brazil: "lusophone",
  Angola: "lusophone",
  "Cape Verde": "lusophone",
  Argentina: "hispanic",
  Mexico: "hispanic",
  Colombia: "hispanic",
  Uruguay: "hispanic",
  Ecuador: "hispanic",
  Paraguay: "hispanic",
  Venezuela: "hispanic",
  Chile: "hispanic",
  Peru: "hispanic",
  "Costa Rica": "hispanic",
  Panama: "hispanic",
  Bolivia: "hispanic",
  Honduras: "hispanic",
  Guatemala: "hispanic",
  "El Salvador": "hispanic",
  France: "francophone",
  Italy: "italic",
  Belgium: "dutch",
  Netherlands: "dutch",
  Germany: "germanic",
  Austria: "germanic",
  Switzerland: "germanic",
  Luxembourg: "germanic",
  Norway: "nordic",
  Denmark: "nordic",
  Sweden: "nordic",
  Iceland: "nordic",
  Finland: "finnic",
  Russia: "slavicEast",
  Ukraine: "slavicEast",
  Belarus: "slavicEast",
  Poland: "slavicWest",
  "Czech Republic": "slavicWest",
  Slovakia: "slavicWest",
  Slovenia: "slavicWest",
  Croatia: "balkan",
  Serbia: "balkan",
  "Bosnia & Herzegovina": "balkan",
  Montenegro: "balkan",
  "North Macedonia": "balkan",
  Bulgaria: "balkan",
  Albania: "albanian",
  Kosovo: "albanian",
  Greece: "hellenic",
  Hungary: "magyar",
  Romania: "romanian",
  Turkey: "turkic",
  Uzbekistan: "turkic",
  Morocco: "arabic",
  Algeria: "arabic",
  Tunisia: "arabic",
  Egypt: "arabic",
  "Saudi Arabia": "arabic",
  Qatar: "arabic",
  "United Arab Emirates": "arabic",
  Iraq: "arabic",
  Jordan: "arabic",
  Bahrain: "arabic",
  Oman: "arabic",
  Syria: "arabic",
  Palestine: "arabic",
  Iran: "persian",
  Israel: "hebrew",
  Senegal: "westAfricaFr",
  "Ivory Coast": "westAfricaFr",
  Mali: "westAfricaFr",
  "Burkina Faso": "westAfricaFr",
  Guinea: "westAfricaFr",
  Benin: "westAfricaFr",
  Cameroon: "westAfricaFr",
  Gabon: "westAfricaFr",
  "DR Congo": "westAfricaFr",
  Nigeria: "westAfricaEn",
  Ghana: "westAfricaEn",
  "South Africa": "southernAfrica",
  Zambia: "southernAfrica",
  Uganda: "southernAfrica",
  Japan: "japanese",
  "South Korea": "korean",
  "North Korea": "korean",
  China: "chinese",
  Thailand: "seAsian",
  Vietnam: "seAsian",
  Indonesia: "seAsian",
  Philippines: "seAsian",
  Jamaica: "caribbean",
  Haiti: "caribbean",
  "Cura\xE7ao": "caribbean",
  "Trinidad and Tobago": "caribbean",
  Cuba: "hispanic",
  "Dominican Republic": "hispanic",
  Suriname: "dutch",
  Georgia: "caucasus",
  Armenia: "caucasus",
  /* The rest of the international engine's nation list. Section 7 of
     simStartingXi asserts this map is TOTAL against NATION_CONFED, which
     is how these forty six arrived: the harness named every one of them. */
  Azerbaijan: "turkic",
  Kazakhstan: "turkic",
  Tajikistan: "persian",
  Cyprus: "hellenic",
  Malta: "italic",
  Moldova: "romanian",
  Estonia: "baltic",
  Latvia: "baltic",
  Lithuania: "baltic",
  "Faroe Islands": "nordic",
  Liechtenstein: "germanic",
  Kuwait: "arabic",
  Lebanon: "arabic",
  Libya: "arabic",
  Ethiopia: "eastAfrica",
  Kenya: "eastAfrica",
  Tanzania: "eastAfrica",
  Zimbabwe: "southernAfrica",
  Congo: "westAfricaFr",
  Comoros: "westAfricaFr",
  Madagascar: "westAfricaFr",
  Togo: "westAfricaFr",
  "Guinea-Bissau": "lusophone",
  Mozambique: "lusophone",
  Liberia: "westAfricaEn",
  "Sierra Leone": "westAfricaEn",
  "The Gambia": "westAfricaEn",
  India: "southAsia",
  "New Caledonia": "oceania",
  Tahiti: "oceania",
  Fiji: "oceania",
  "Solomon Islands": "oceania",
  "Papua New Guinea": "oceania",
  Vanuatu: "oceania",
  Samoa: "oceania",
  "American Samoa": "oceania",
  "Cook Islands": "oceania",
  Tonga: "oceania"
};
var FALLBACK_FAMILY = "anglo";
function familyFor(nation) {
  const id = NATION_FAMILY[nation] ?? FALLBACK_FAMILY;
  return NAME_FAMILIES.find((f) => f.id === id) ?? NAME_FAMILIES[0];
}
var REAL_PAIR_SWAPS = {
  "Facundo Quiroga": "Facundo Quiroga-Leiva",
  "Bastian Reinhardt": "Bastian Reinhardtsberg",
  "Dominik Reinhardt": "Dominik Reinhardtsberg"
};
function pairName(first, last) {
  const name = `${first} ${last}`;
  return REAL_PAIR_SWAPS[name] ?? name;
}
function intlName(nation, i) {
  const fam = familyFor(nation);
  let h = 2166136261;
  for (let k = 0; k < nation.length; k++) {
    h ^= nation.charCodeAt(k);
    h = Math.imul(h, 16777619);
  }
  h >>>= 0;
  const first = fam.firsts[(h + i * 5) % fam.firsts.length];
  const last = fam.lasts[(Math.floor(h / 7) + i * 7) % fam.lasts.length];
  return pairName(first, last);
}

// src/lib/soccerCurrency.ts
var CURRENCIES = [
  { code: "EUR", symbol: "\u20AC", name: "Euro", perEur: 1 },
  { code: "GBP", symbol: "\xA3", name: "British pound", perEur: 0.8567 },
  { code: "USD", symbol: "$", name: "US dollar", perEur: 1.1699 },
  { code: "BRL", symbol: "R$", name: "Brazilian real", perEur: 6.0518 },
  { code: "MXN", symbol: "MX$", name: "Mexican peso", perEur: 19.769 },
  { code: "JPY", symbol: "\xA5", name: "Japanese yen", perEur: 185.66 },
  { code: "INR", symbol: "\u20B9", name: "Indian rupee", perEur: 111.9595 },
  { code: "AUD", symbol: "A$", name: "Australian dollar", perEur: 1.6321 }
];
var EUR = CURRENCIES[0];
var STORAGE_KEY = "dukb-soccer-currency";
function currencyByCode(code) {
  if (!code) return EUR;
  return CURRENCIES.find((c) => c.code === code) ?? EUR;
}
function getCurrency() {
  try {
    return currencyByCode(localStorage.getItem(STORAGE_KEY));
  } catch {
    return EUR;
  }
}
function trim(v) {
  const a = Math.abs(v);
  if (a >= 100) return v.toFixed(0);
  if (a >= 10) return v.toFixed(1);
  return v.toFixed(2).replace(/(\.\d*[1-9])0+$/, "$1").replace(/\.0+$/, "");
}
var LADDER = ["", "k", "M", "B", "T"];
function normalise(value, unit) {
  let i = Math.max(0, LADDER.indexOf(unit));
  let v = value;
  while (Math.abs(v) >= 1e3 && i < LADDER.length - 1) {
    v /= 1e3;
    i += 1;
  }
  while (Math.abs(v) < 1 && v !== 0 && i > 0) {
    v *= 1e3;
    i -= 1;
  }
  return { value: v, unit: LADDER[i] };
}
var MONEY = /€(\d+(?:\.\d+)?)([kMB])?/g;
function localizeMoney(text2, cur = getCurrency()) {
  if (cur.code === "EUR" || !text2 || text2.indexOf("\u20AC") === -1) return text2;
  return text2.replace(MONEY, (_full, num2, unit) => {
    const n = normalise(Number(num2) * cur.perEur, unit ?? "");
    return `${cur.symbol}${trim(n.value)}${n.unit}`;
  });
}

// src/lib/soccerCareerToManager.ts
init_managerOffers();

// src/lib/soccerCareerEngine.ts
init_managerOffers();

// src/lib/careerSocial.ts
var r22 = (v) => Math.round(v * 100) / 100;
function payFocusBoost(s, sport) {
  if (!sport.focus.get(s)) return false;
  sport.payFocus(s);
  sport.focus.set(s, false);
  sport.log(s, sport.words.focusPaid);
  return true;
}
function seasonFollowerGrowth(s, season2, g) {
  let growth = g.buzz(s, season2);
  const home = g.homeMarket(s);
  if (home !== 1) growth *= home;
  growth += g.standing.get(s) * g.standingRate;
  if (g.rng() < g.viral.chance) growth += Math.floor(g.rng() * (g.viral.max - g.viral.min + 1)) + g.viral.min;
  growth *= g.personality(s);
  return r22(growth);
}

// src/lib/careerBrand.ts
var r23 = (v) => Math.round(v * 100) / 100;
function brandSaveId(rung, sport) {
  return sport.saveIds?.[rung] ?? rung;
}
function brandRungOf(stored, sport) {
  if (!stored) return null;
  for (const t of sport.tiers) if (brandSaveId(t.id, sport) === stored) return t.id;
  return null;
}
function brandRungPay(rung, tiers) {
  if (!rung) return 0;
  const t = tiers.find((x) => x.id === rung);
  return t?.income || 0;
}
function brandSeasonIncome(f, sport) {
  let income = f.bonus;
  for (const [line, pays] of sport.fame) {
    if (f.standing >= line) {
      income += pays;
      break;
    }
  }
  income += f.followers * sport.perFollower;
  if (f.legacy !== 0) income += f.legacy;
  income += brandRungPay(brandRungOf(f.tier, sport), sport.tiers);
  return r23(Math.max(0, income));
}

// src/lib/soccerCareerBrand.ts
var clamp6 = (v, min, max) => Math.max(min, Math.min(max, v));
var log = (s, line) => {
  s.events = [...s.events, line];
};
var followers = {
  get: (s) => s.socialMediaFollowers,
  set: (s, v) => {
    s.socialMediaFollowers = v;
  }
};
var popularity = {
  get: (s) => s.popularity,
  set: (s, v) => {
    s.popularity = v;
  }
};
var SOCIAL_MEDIA_ACTIONS = [
  { id: "training_video", label: "Post training video", emoji: "\u{1F3CB}\uFE0F", description: "Show off your skills in the gym", followerGain: [5e4, 2e5], reputationChange: 0 },
  { id: "viral_celebration", label: "Go viral with celebration clip", emoji: "\u{1F3AC}", description: "Post an iconic goal celebration", followerGain: [5e5, 2e6], reputationChange: 0 },
  { id: "controversial_opinion", label: "Post controversial opinion", emoji: "\u{1F525}", description: "Share a hot take about football", followerGain: [1e6, 1e6], reputationChange: -10, extraEffect: "Reputation -10" },
  { id: "charity_work", label: "Announce charity work", emoji: "\u2764\uFE0F", description: "Highlight your philanthropic efforts", followerGain: [2e5, 2e5], reputationChange: 15, extraEffect: "Reputation +15" },
  { id: "personal_life", label: "Post about personal life", emoji: "\u{1F4F8}", description: "Share a glimpse into your life off the pitch", followerGain: [3e5, 3e5], reputationChange: 0 },
  { id: "troll_rival", label: "Troll your rival on social media", emoji: "\u{1F608}", description: "Take a shot at your rival online", followerGain: [8e5, 8e5], reputationChange: 0, extraEffect: "All talk: just the followers, nothing else moves" },
  { id: "stay_off", label: "Stay off social media", emoji: "\u{1F9D8}", description: "Focus on football, no distractions", followerGain: [0, 0], reputationChange: 0, extraEffect: "+2 to all stats next season" }
];
var FOCUS_STATS = ["pace", "shooting", "passing", "dribbling", "defending", "physical", "reflexes"];
var SOCCER_SOCIAL = {
  posts: SOCIAL_MEDIA_ACTIONS,
  focusPost: "stay_off",
  rivalPost: "troll_rival",
  followerUnit: 1e6,
  followers,
  standing: popularity,
  posted: {
    get: (s) => s.socialMediaActionUsedThisSeason,
    set: (s, v) => {
      s.socialMediaActionUsedThisSeason = v;
    }
  },
  focus: {
    get: (s) => s.socialMediaFocusBoost,
    set: (s, v) => {
      s.socialMediaFocusBoost = v;
    }
  },
  payFocus: (s) => {
    for (const k of FOCUS_STATS) s[k] = clamp6(s[k] + 2, 20, 99);
  },
  rivalName: (s) => s.rival && !s.rival.retired ? s.rival.name : null,
  log,
  rng: () => Math.random(),
  words: {
    focus: "\u{1F9D8} Stayed off social media: focus boost for next season (+2 all stats)",
    gained: (p, gain) => `\u{1F4F1} ${p.emoji} ${p.label}: gained ${gain.toFixed(1)}M followers!`,
    standingUp: (n) => `\u2728 Reputation +${n}`,
    standingDown: (n) => `\u26A0\uFE0F Reputation ${n}`,
    rival: (name) => `\u{1F624} Rivalry with ${name} intensifies!`,
    focusPaid: "\u{1F9D8} Social media detox paid off: +2 to all stats!"
  }
};
var BIG_NATIONS = ["England", "Spain", "France", "Germany", "Brazil", "Argentina", "USA", "Mexico", "Japan", "Italy"];
var SOCCER_FOLLOWER_GROWTH = {
  buzz: (_s, season2) => {
    let growth = 0;
    growth += season2.goals * 0.02;
    if (season2.leagueTitle) growth += 0.5;
    if (season2.championsLeague) growth += 1;
    if (season2.worldCup) growth += 3;
    if (season2.ballonDor) growth += 5;
    return growth;
  },
  homeMarket: (s) => BIG_NATIONS.includes(s.nationality) ? 1.5 : 1,
  standing: popularity,
  standingRate: 5e-3,
  viral: { chance: 0.05, min: 1, max: 5 },
  personality: (s) => personalityFollowerMult(s.personality),
  rng: () => Math.random()
};
var SOCCER_SAVE_IDS = {
  local_deal: "local_brand",
  kit_deal: "nike_adidas",
  global_ambassador: "global_ambassador",
  own_line: "merchandise_line",
  game_cover: "cover_athlete"
};
var SOCCER_TIERS = [
  { id: "local_deal", name: "Local Brand Deal", emoji: "\u{1F3EA}", minFollowers: 1e6, income: 0.5 },
  { id: "kit_deal", name: "Global Boot Deal", emoji: "\u{1F45F}", minFollowers: 5e6, income: 3 },
  { id: "global_ambassador", name: "Global Brand Ambassador", emoji: "\u{1F30D}", minFollowers: 15e6, income: 8 },
  { id: "own_line", name: "Own Merchandise Line", emoji: "\u{1F455}", minFollowers: 3e7, income: 15 },
  { id: "game_cover", name: "Game Cover Athlete", emoji: "\u{1F3AE}", minFollowers: 5e7, income: 25 }
];
var SPONSORSHIP_TIERS = SOCCER_TIERS.map((t) => ({ tier: SOCCER_SAVE_IDS[t.id], name: t.name, emoji: t.emoji, minFollowers: t.minFollowers, income: t.income }));
var SOCCER_COVER = {
  minFollowers: 5e7,
  minRating: 90,
  pay: 25,
  followers: 5,
  declineStanding: 5,
  award: { name: "Game Cover Athlete", emoji: "\u{1F3AE}" }
};
var SOCCER_BRAND = {
  tiers: SOCCER_TIERS,
  saveIds: SOCCER_SAVE_IDS,
  followerUnit: 1e6,
  followers,
  standing: popularity,
  cash: {
    get: (s) => s.netWorth,
    set: (s, v) => {
      s.netWorth = v;
    }
  },
  rating: (s) => s.overall,
  tier: {
    get: (s) => s.activeSponsorship,
    set: (s, stored) => {
      s.activeSponsorship = stored;
    }
  },
  cover: {
    ...SOCCER_COVER,
    taken: {
      get: (s) => s.coverAthleteAccepted,
      set: (s, v) => {
        s.coverAthleteAccepted = v;
      }
    },
    waiting: {
      get: (s) => s.pendingCoverAthleteEvent,
      set: (s, v) => {
        s.pendingCoverAthleteEvent = v;
      }
    },
    record: (s, a) => {
      s.awards = [...s.awards, { year: s.seasons[s.seasons.length - 1]?.year || 2024, name: a.name, emoji: a.emoji }];
    }
  },
  fame: [[80, 2], [60, 1], [40, 0.3]],
  perFollower: 0.1,
  // €100k per 1M followers
  log,
  words: {
    signed: (t) => `${t.emoji} NEW SPONSORSHIP: ${t.name}, \u20AC${t.income}M/year!`,
    coverTaken: `\u{1F3AE} You are the cover athlete of the world's biggest football video game! \u20AC${SOCCER_COVER.pay}M + ${SOCCER_COVER.followers}M followers + Legacy +10`,
    coverDeclined: `\u{1F3AE} Declined the game cover: gained respect for being selective. Reputation +${SOCCER_COVER.declineStanding}`,
    money: (m) => `\u20AC${m}M`
  }
};

// src/lib/soccerCareerAttributes.ts
var HEIGHT_MIN = 155;
var HEIGHT_MAX = 210;
var WEIGHT_MIN = 50;
var WEIGHT_MAX = 110;
var SHAPE_MAX = 12;
var clampNum = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
var DEFAULT_PHYSIQUE = {
  GK: { heightCm: 190, weightKg: 84 },
  CB: { heightCm: 187, weightKg: 82 },
  LB: { heightCm: 178, weightKg: 73 },
  RB: { heightCm: 178, weightKg: 73 },
  CDM: { heightCm: 183, weightKg: 78 },
  CM: { heightCm: 180, weightKg: 75 },
  CAM: { heightCm: 176, weightKg: 71 },
  LW: { heightCm: 175, weightKg: 70 },
  RW: { heightCm: 175, weightKg: 70 },
  ST: { heightCm: 183, weightKg: 78 }
};
function defaultPhysique(position) {
  const d = DEFAULT_PHYSIQUE[position] || { heightCm: 180, weightKg: 76 };
  return { ...d };
}
function safePhysique(position, p) {
  const d = defaultPhysique(position);
  const h = Number(p?.heightCm);
  const w = Number(p?.weightKg);
  return {
    heightCm: Number.isFinite(h) ? Math.round(clampNum(h, HEIGHT_MIN, HEIGHT_MAX)) : d.heightCm,
    weightKg: Number.isFinite(w) ? Math.round(clampNum(w, WEIGHT_MIN, WEIGHT_MAX)) : d.weightKg
  };
}
var OUTFIELD_TREE = [
  {
    key: "pace",
    label: "Pace",
    children: [
      { id: "acceleration", label: "Acceleration", perCm: -0.2, perKg: -0.34, does: "The first three yards. Getting away from a defender who is already touching you" },
      { id: "sprint_speed", label: "Sprint Speed", perCm: 0.1, perKg: -0.18, does: "Top end over forty yards, once you are already moving" }
    ]
  },
  {
    key: "shooting",
    label: "Shooting",
    children: [
      { id: "finishing", label: "Finishing", does: "One touch inside the box, the chances that decide seasons" },
      { id: "shot_power", label: "Shot Power", perKg: 0.14, perCm: 0.06, does: "How hard you hit it, and whether a keeper can hold it" },
      { id: "long_shots", label: "Long Shots", does: "Anything from outside the area" },
      { id: "heading", label: "Heading", perCm: 0.36, perKg: 0.12, does: "Attacking headers from crosses and set pieces" },
      { id: "penalties", label: "Penalties", does: "From twelve yards, and in a shootout" }
    ]
  },
  {
    key: "passing",
    label: "Passing",
    children: [
      { id: "vision", label: "Vision", does: "Seeing the pass nobody else in the stadium saw" },
      { id: "short_pass", label: "Short Passing", does: "Keeping the ball under pressure in tight areas" },
      { id: "crossing", label: "Crossing", does: "Delivery from wide, both feet, both heights" },
      { id: "long_pass", label: "Long Passing", does: "Switching play, and the ball over the top" },
      { id: "free_kicks", label: "Free Kicks", does: "Dead ball delivery and the ones you shoot yourself" }
    ]
  },
  {
    key: "dribbling",
    label: "Dribbling",
    children: [
      { id: "ball_control", label: "Ball Control", perCm: -0.06, does: "First touch, and whether the ball sticks when it arrives fast" },
      { id: "agility", label: "Agility", perCm: -0.3, perKg: -0.22, does: "Turning, changing direction, getting out of a crowd" },
      { id: "balance", label: "Balance", perCm: -0.12, perKg: 0.16, does: "Staying on your feet when somebody leans on you" },
      { id: "flair", label: "Flair", does: "The trick nobody asked for that comes off anyway" }
    ]
  },
  {
    key: "defending",
    label: "Defending",
    children: [
      { id: "marking", label: "Marking", perCm: 0.1, does: "Staying with a man for ninety minutes" },
      { id: "tackling", label: "Tackling", perKg: 0.1, does: "Winning the ball cleanly, standing up and going to ground" },
      { id: "interceptions", label: "Interceptions", perCm: 0.08, does: "Reading the pass before it is played and stepping in front" },
      { id: "reading", label: "Reading The Game", does: "Where to be before anything happens" }
    ]
  },
  {
    key: "physical",
    label: "Physical",
    children: [
      { id: "strength", label: "Strength", perCm: 0.16, perKg: 0.46, does: "Holding the ball up and winning the shoulder to shoulder stuff" },
      { id: "stamina", label: "Stamina", perKg: -0.22, does: "Still running in the ninetieth minute, and playing every week" },
      { id: "aggression", label: "Aggression", perKg: 0.1, does: "How hard you go into a challenge you might not win" },
      { id: "jumping", label: "Jumping", perCm: 0.26, perKg: -0.1, does: "How high you get off the floor, which is not the same as being tall" }
    ]
  }
];
var GK_TREE = [
  {
    key: "reflexes",
    label: "Reflexes",
    children: [
      { id: "gk_reflex", label: "Shot Reflexes", perCm: -0.1, does: "The save nobody had time to think about" },
      { id: "gk_recovery", label: "Recovery Saves", perCm: -0.12, does: "Getting back up and stopping the rebound" }
    ]
  },
  {
    key: "shooting",
    label: "Shot Stopping",
    children: [
      { id: "gk_one_v_one", label: "One On Ones", perCm: 0.1, does: "A striker through on goal with only you to beat" },
      { id: "gk_long_range", label: "Long Range", does: "Everything struck from outside the box" }
    ]
  },
  {
    key: "defending",
    label: "Positioning",
    children: [
      { id: "gk_angles", label: "Angles", perCm: 0.16, does: "Making the goal look small before the shot is hit" },
      { id: "gk_reading", label: "Reading The Game", does: "Knowing where the ball is going before it goes there" }
    ]
  },
  {
    key: "physical",
    label: "Aerial Command",
    children: [
      { id: "gk_crosses", label: "Claiming Crosses", perCm: 0.3, perKg: 0.1, does: "Coming and taking it in a crowded six yard box" },
      { id: "gk_punching", label: "Punching", perKg: 0.2, does: "Clearing the danger when catching it is not on" }
    ]
  },
  {
    key: "passing",
    label: "Distribution",
    children: [
      { id: "gk_throwing", label: "Throwing", perKg: 0.16, does: "Starting a counter attack with your hands" },
      { id: "gk_kicking", label: "Kicking", does: "Playing out from the back and finding a man long" }
    ]
  },
  {
    key: "dribbling",
    label: "Penalty Saving",
    children: [
      { id: "gk_pen_read", label: "Reading The Penalty", does: "Picking the corner before he strikes it" },
      { id: "gk_nerve", label: "Shootout Nerve", does: "The fifth kick of a shootout, in front of their end" }
    ]
  },
  {
    key: "pace",
    label: "Sweeping Speed",
    children: [
      { id: "gk_rush", label: "Rushing Out", perKg: -0.24, does: "Beating a striker to a through ball outside your area" },
      { id: "gk_recovery_pace", label: "Recovery Pace", perCm: -0.12, perKg: -0.28, does: "Getting back when the ball goes over your head" }
    ]
  }
];
function attrTreeFor(position) {
  return position === "GK" ? GK_TREE : OUTFIELD_TREE;
}
var ALL_ATTR_IDS = [
  ...OUTFIELD_TREE.flatMap((f) => f.children.map((c) => c.id)),
  ...GK_TREE.flatMap((f) => f.children.map((c) => c.id))
];
function safeShape(position, raw) {
  const out = {};
  if (!raw || typeof raw !== "object") return out;
  for (const fam of attrTreeFor(position)) {
    const vals = [];
    for (const c of fam.children) {
      const v = Number(raw[c.id]);
      vals.push(Number.isFinite(v) ? Math.round(clampNum(v, -SHAPE_MAX, SHAPE_MAX)) : 0);
    }
    const sum = vals.reduce((a, b) => a + b, 0);
    if (sum !== 0) continue;
    fam.children.forEach((c, i) => {
      if (vals[i] !== 0) out[c.id] = vals[i];
    });
  }
  return out;
}
function frameDelta(def, phys) {
  const dh = phys.heightCm - 180;
  const dw = phys.weightKg - 76;
  return (def.perCm || 0) * dh + (def.perKg || 0) * dw;
}
function deriveAttributes(stats, position, physique, shape) {
  const phys = safePhysique(position, physique);
  const sh = safeShape(position, shape);
  const out = [];
  for (const fam of attrTreeFor(position)) {
    const base = Number(stats[fam.key]) || 0;
    for (const c of fam.children) {
      const fd = frameDelta(c, phys);
      out.push({
        id: c.id,
        label: c.label,
        family: fam.key,
        familyLabel: fam.label,
        does: c.does,
        frameDelta: Math.round(fd),
        value: Math.round(clampNum(base + (sh[c.id] || 0) + fd, 1, 99))
      });
    }
  }
  return out;
}
function deriveMap(stats, position, physique, shape) {
  const m = {};
  for (const a of deriveAttributes(stats, position, physique, shape)) m[a.id] = a.value;
  return m;
}
var POSITION_OFFSETS = {
  ST: [5, 8, -3, 2, -10, 3, -5],
  LW: [8, 3, 0, 6, -10, -2, -5],
  RW: [8, 3, 0, 6, -10, -2, -5],
  CAM: [2, 3, 6, 6, -12, 0, -5],
  CM: [-4, -3, 6, 3, 0, 3, -5],
  CDM: [-1, -8, 3, -3, 8, 6, -5],
  CB: [-2, -10, 0, -6, 10, 8, 0],
  LB: [5, -8, 3, -4, 6, 2, -4],
  RB: [5, -8, 3, -4, 6, 2, -4],
  GK: [-4, -14, 0, -8, 0, 4, 12]
};
var STAT_KEYS = ["pace", "shooting", "passing", "dribbling", "defending", "physical", "reflexes"];
function referenceLine(position, overall) {
  const o = POSITION_OFFSETS[position] || [0, 0, 0, 0, 0, 0, 0];
  const line = {};
  STAT_KEYS.forEach((k, i) => {
    line[k] = clampNum(overall + o[i], 25, 99);
  });
  return line;
}
var ATTACK_W = { finishing: 0.42, shot_power: 0.16, long_shots: 0.12, heading: 0.16, acceleration: 0.14 };
var CREATIVE_W = { vision: 0.3, short_pass: 0.22, crossing: 0.2, long_pass: 0.18, agility: 0.1 };
var AVAIL_W = { stamina: 0.45, strength: 0.3, balance: 0.15, jumping: 0.1 };
var DEFENCE_W = { marking: 0.3, tackling: 0.28, interceptions: 0.22, reading: 0.12, heading: 0.08 };
var KEEPER_W = { gk_reflex: 0.3, gk_recovery: 0.14, gk_one_v_one: 0.16, gk_long_range: 0.1, gk_angles: 0.14, gk_reading: 0.08, gk_crosses: 0.08 };
var GK_AVAIL_W = { gk_rush: 0.4, gk_recovery_pace: 0.3, gk_punching: 0.3 };
function score(map, w) {
  let total = 0;
  for (const k in w) total += (map[k] ?? 0) * w[k];
  return total;
}
var NEUTRAL_EFFECTS = {
  goalMult: 1,
  assistMult: 1,
  appsMult: 1,
  cleanSheetMult: 1,
  ratingDelta: 0,
  injuryDelta: 0,
  attackDelta: 0,
  creativeDelta: 0,
  availDelta: 0,
  defenceDelta: 0,
  keeperDelta: 0
};
function buildEffects(stats, position, overall, physique, shape) {
  const isGK = position === "GK";
  const mine = deriveMap(stats, position, physique, shape);
  const ref = deriveMap(referenceLine(position, overall), position, null, null);
  if (isGK) {
    const keeperDelta = score(mine, KEEPER_W) - score(ref, KEEPER_W);
    const availDelta2 = score(mine, GK_AVAIL_W) - score(ref, GK_AVAIL_W);
    return {
      goalMult: 1,
      assistMult: 1,
      appsMult: clampNum(1 + availDelta2 * 8e-3, 0.89, 1.11),
      cleanSheetMult: clampNum(1 + keeperDelta * 0.02, 0.72, 1.3),
      ratingDelta: clampNum(keeperDelta * 0.012, -0.3, 0.3),
      injuryDelta: clampNum(-availDelta2 * 2e-3, -0.04, 0.04),
      attackDelta: 0,
      creativeDelta: 0,
      availDelta: availDelta2,
      defenceDelta: 0,
      keeperDelta
    };
  }
  const attackDelta = score(mine, ATTACK_W) - score(ref, ATTACK_W);
  const creativeDelta = score(mine, CREATIVE_W) - score(ref, CREATIVE_W);
  const availDelta = score(mine, AVAIL_W) - score(ref, AVAIL_W);
  const defenceDelta = score(mine, DEFENCE_W) - score(ref, DEFENCE_W);
  const ratingSource = ["ST", "LW", "RW"].includes(position) ? attackDelta : ["CAM", "CM"].includes(position) ? creativeDelta * 0.6 + attackDelta * 0.4 : ["CDM"].includes(position) ? defenceDelta * 0.6 + creativeDelta * 0.4 : defenceDelta;
  return {
    goalMult: clampNum(1 + attackDelta * 0.03, 0.62, 1.42),
    assistMult: clampNum(1 + creativeDelta * 0.028, 0.64, 1.4),
    appsMult: clampNum(1 + availDelta * 8e-3, 0.89, 1.11),
    cleanSheetMult: 1,
    ratingDelta: clampNum(ratingSource * 0.012, -0.3, 0.3),
    injuryDelta: clampNum(-availDelta * 2e-3, -0.04, 0.04),
    attackDelta,
    creativeDelta,
    availDelta,
    defenceDelta,
    keeperDelta: 0
  };
}

// src/lib/soccerCareerRealismB.ts
init_soccerInternational();

// src/lib/careerCritic.ts
var CRITIC_FIRST = [
  "Marguerite",
  "Desmond",
  "Ottoline",
  "Barnaby",
  "Winifred",
  "Cedric",
  "Rosalind",
  "Alastair",
  "Prudence",
  "Hollis",
  "Gwendolyn",
  "Fitzwilliam"
];
var CRITIC_LAST = [
  "Pemberton",
  "Crossley",
  "Hargreave",
  "Villiers",
  "Ashcombe",
  "Dunmore",
  "Trelawney",
  "Ravensworth",
  "Marchbank",
  "Stallybrass",
  "Quillfeather",
  "Netherfield"
];
function hashOf(seed) {
  let h = 2166136261;
  for (let i = 0; i < seed.length; i += 1) {
    h ^= seed.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h);
}
function criticName(seed) {
  const h = hashOf(seed);
  return `${CRITIC_FIRST[h % CRITIC_FIRST.length]} ${CRITIC_LAST[Math.floor(h / CRITIC_FIRST.length) % CRITIC_LAST.length]}`;
}
function criticPaper(seed, papers) {
  return papers.length ? papers[hashOf(`${seed}|paper`) % papers.length] : "";
}
function criticScore(f) {
  const n = f.recentRatings.length;
  if (n === 0) return 50;
  const w = (i) => f.answered === 2 ? i === n - 1 ? 1 : 0 : 1;
  const wsum = f.recentRatings.reduce((a, _, i) => a + w(i), 0) || 1;
  const meanRating = f.recentRatings.reduce((a, r, i) => a + r * w(i), 0) / wsum;
  const meanApps = f.recentApps.length ? f.recentApps.reduce((a, v, i) => a + v * w(i), 0) / wsum : 0;
  let score2 = 50;
  score2 += (meanRating - 7.1) * 22;
  score2 += (meanApps - 28) * 0.35;
  score2 += f.recentTrophies * 6;
  score2 += Math.min(12, f.careerTrophies * 1.5);
  score2 += (f.popularity - 55) * 0.15;
  if (f.answered === 1) score2 += (meanRating - 7.1) * 8 - 4;
  if (f.answered === 3) score2 += 8;
  return Math.max(0, Math.min(100, Math.round(score2)));
}
function criticStance(score2) {
  if (score2 >= 68) return "backing";
  if (score2 >= 50) return "watching";
  if (score2 >= 33) return "doubting";
  return "written_off";
}
var VOICE = {
  backing: [
    (c, s) => `${s}. ${c} wrote that anybody still arguing about this is arguing for the sake of it.`,
    (c, s) => `${s}. ${c} called it the best season anybody at the club has had in years, and he does not hand those out.`,
    (c, s) => `${s}. ${c} led his column with it for the third week running and apologised to nobody.`
  ],
  watching: [
    (c, s) => `${s}. ${c} filed a careful one: good, not yet the thing everybody keeps promising.`,
    (c, s) => `${s}. ${c} says the talent was never the question and it still is not the answer either.`,
    (c, s) => `${s}. ${c} is waiting for the season that settles it. He has been waiting a while.`
  ],
  doubting: [
    (c, s) => `${s}. ${c} spent nine hundred words asking where the rest of it went.`,
    (c, s) => `${s}. ${c} thinks the reputation is doing more work than the football is.`,
    (c, s) => `${s}. ${c} put a question mark in the headline, which from him is a verdict.`
  ],
  written_off: [
    (c, s) => `${s}. ${c} wrote the obituary column, in full, with a photograph from four years ago.`,
    (c, s) => `${s}. ${c} says the club would get more from the money somewhere else, and he named the somewhere.`,
    (c, s) => `${s}. ${c} has stopped asking questions about it. That is worse.`
  ]
};
function criticColumn(critic, year, stance, clause) {
  const bank = VOICE[stance];
  return { year, stance, line: bank[Math.abs(year) % bank.length](critic, clause) };
}

// src/lib/soccerCareerCritic.ts
var flag = (s, key) => (s.lifeFlags || {})[key] || 0;
var CRITIC_FLAG = "criticAnswered";
var GK = (pos) => pos === "GK";
var BACK = (pos) => ["CB", "LB", "RB", "LWB", "RWB", "CDM"].includes(pos);
function soccerCriticName(c) {
  const born = c.seasons?.[0]?.year ?? 2020;
  return criticName(`${c.playerName}|${c.nationality}|${born}`);
}
var trophiesIn = (s) => (s.leagueTitle ? 1 : 0) + (s.domesticCup ? 1 : 0) + (s.championsLeague ? 1 : 0) + (s.worldCup ? 1 : 0) + (s.continentalCup ? 1 : 0) + (s.clubCupTitle ? 1 : 0);
function seasonClause(pos, s) {
  const apps = s.apps ?? 0;
  const games = `${apps} game${apps === 1 ? "" : "s"}`;
  if (GK(pos)) return `${s.cleanSheets ?? 0} clean sheets in ${games}`;
  if (BACK(pos)) return `${games} at a ${(s.rating ?? 0).toFixed(1)} average`;
  return `${s.goals ?? 0} goals and ${s.assists ?? 0} assists in ${games}`;
}
function stanceAfter(c, played, index) {
  const window = played.slice(Math.max(0, index - 2), index + 1);
  const upTo = played.slice(0, index + 1);
  const score2 = criticScore({
    recentRatings: window.map((s) => s.rating ?? 0),
    recentApps: window.map((s) => s.apps ?? 0),
    recentTrophies: window.reduce((a, s) => a + trophiesIn(s), 0),
    careerTrophies: upTo.reduce((a, s) => a + trophiesIn(s), 0),
    popularity: c.popularity ?? 50,
    answered: flag(c, CRITIC_FLAG)
  });
  return { score: score2, stance: criticStance(score2) };
}
function playedSeasons(c) {
  return (c.seasons ?? []).filter((s) => s.type === "playing");
}
function soccerCriticArticle(c, season2, papers) {
  const played = playedSeasons(c).length ? playedSeasons(c) : [season2];
  const { stance } = stanceAfter(c, played, played.length - 1);
  const name = soccerCriticName(c);
  const col = criticColumn(name, season2.year, stance, seasonClause(c.position, season2));
  const title = {
    backing: `THE COLUMN: ${name} Has Seen Enough, And He Is Saying So`,
    watching: `THE COLUMN: ${name} Is Still Making His Mind Up About ${c.playerName}`,
    doubting: `THE COLUMN: ${name} Wants To Know Where The Rest Of It Went`,
    written_off: `THE COLUMN: ${name} Says The Argument About ${c.playerName} Is Over`
  };
  return {
    paper: criticPaper(`${c.playerName}|${c.nationality}|${played[0].year}`, papers),
    headline: title[stance],
    body: col.line,
    hostile: stance === "doubting" || stance === "written_off"
  };
}
var DISGRACE = [
  (c) => `${c} has written about you every season since you turned pro. This week he filed four hundred words, none of them about football, and the last line was that he should have asked harder questions sooner.`,
  (c) => `${c} pulled every column he ever wrote about you and printed the dates beside the charges. He did not editorialise. He did not need to.`,
  (c) => `${c} wrote that he had spent a decade arguing about your first touch with people who now want to talk about something else entirely.`
];
function soccerCriticDisgraceArticle(c, papers) {
  const name = soccerCriticName(c);
  const played = playedSeasons(c);
  const year = played.length ? played[played.length - 1].year : c.seasons?.[0]?.year ?? 2020;
  return {
    paper: criticPaper(`${c.playerName}|${c.nationality}|${played[0]?.year ?? year}`, papers),
    headline: `THE COLUMN: ${name} Has Been Writing About You For Years. Never Like This`,
    body: DISGRACE[Math.abs(year) % DISGRACE.length](name)
  };
}

// src/lib/soccerCareerAcademy.ts
var ACADEMY_FOCUS_BONUS = 2;
var ACADEMY_FOCUS_NEAR = 3;
function academyFocusOptions(position) {
  return attrTreeFor(position).map((f) => ({ key: f.key, label: f.label }));
}
function academyFocusOf(s) {
  const f = s.academyFocus;
  if (typeof f !== "string") return null;
  return academyFocusOptions(s.position).some((o) => o.key === f) ? f : null;
}
function academyFocusBonus(overall, potential) {
  if (!(overall < potential)) return 0;
  if (overall >= potential - ACADEMY_FOCUS_NEAR) return 1;
  return ACADEMY_FOCUS_BONUS;
}
function applyAcademyFocus(s, potential) {
  const focus = academyFocusOf(s);
  if (!focus) return 0;
  const before = s[focus];
  s[focus] = Math.min(99, before + academyFocusBonus(s.overall, potential));
  s.academyFocusAdded = s[focus] - before;
  return s.academyFocusAdded;
}
var ACADEMY_FOCUS_RULE = `+${ACADEMY_FOCUS_BONUS} to that skill on top of the year's normal growth. If the year takes you close to your ceiling it adds +1, and nothing once you reach it.`;

// src/lib/season/momentsSave.ts
var LEDGER_MAX = 12;
var ENTRY_MIN = 3;
var ENTRY_MAX = 8;
var KEY_MAX = 200;
var MD_MAX = 400;
var YEAR_MAX = 9999;
var PAID_MAX = 2;
var TALLY_MAX = { seasons: 200, moments: 2400, stars: 7200 };
var isInt = (v, lo, hi) => typeof v === "number" && Number.isInteger(v) && v >= lo && v <= hi;
function readSeasonMoments(raw) {
  try {
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) return null;
    const r = raw;
    if (r.v !== 1) return null;
    if (typeof r.key !== "string" || r.key.length === 0 || r.key.length > KEY_MAX) return null;
    if (!Array.isArray(r.m) || r.m.length > LEDGER_MAX) return null;
    const m = [];
    for (const e of r.m) {
      if (!Array.isArray(e) || e.length < ENTRY_MIN || e.length > ENTRY_MAX) return null;
      if (!e.every((x) => typeof x === "number" && Number.isFinite(x))) return null;
      if (!isInt(e[0], 1, MD_MAX) || !isInt(e[1], 0, LEDGER_MAX - 1) || !isInt(e[2], -1, 3)) return null;
      if (m.some((x) => x[0] === e[0] && x[1] === e[1])) continue;
      m.push(e.slice());
    }
    const out = { v: 1, key: r.key, m };
    if (r.banked !== void 0) {
      if (r.banked !== 1) return null;
      out.banked = 1;
    }
    if (r.paid !== void 0) {
      const p = r.paid;
      if (out.banked !== 1 || !Array.isArray(p) || p.length !== 2 || !isInt(p[0], 0, YEAR_MAX) || !isInt(p[1], 1, PAID_MAX)) return null;
      out.paid = [p[0], p[1]];
    }
    if (r.tally !== void 0) {
      const t = r.tally;
      if (!t || typeof t !== "object" || Array.isArray(t)) return null;
      if (!isInt(t.seasons, 0, TALLY_MAX.seasons) || !isInt(t.moments, 0, TALLY_MAX.moments) || !isInt(t.stars, 0, TALLY_MAX.stars)) return null;
      out.tally = { seasons: t.seasons, moments: t.moments, stars: t.stars };
    }
    return out;
  } catch {
    return null;
  }
}

// src/lib/soccerCareerEngine.ts
init_soccerInternational();

// src/data/nationalPools.ts
var NATIONAL_POOL_YEARS = { first: 2016, last: 2026 };
var NATIONAL_POOLS = {
  "Albania|2016": "Elseid Hysaj:RB:79,Etrit Berisha:GK:72,Taulant Xhaka:CDM:72,Amir Abrashi:CDM:70,Bekim Balaj:ST:70,Ledian Memushaj:CM:70,Shk\xEBlzen Gashi:LW:70,Sokol Cikalleshi:ST:70,Arlind Ajeti:CB:68,Azdren Llullaku:LW:68,Ansi Nika:RM:64,Arenc Dibra:CF:64,Ermir Lenjani:LB:64,Eros Grezda:RW:64,Esin Hakaj:LM:64,Iv\xE1n Balliu:RB:64,Odise Roshi:RW:64,Thomas Strakosha:GK:64",
  "Albania|2017": "Elseid Hysaj:RB:81,Thomas Strakosha:GK:79,Etrit Berisha:GK:76,Taulant Xhaka:CDM:72,Amir Abrashi:CDM:70,Bekim Balaj:ST:70,Mergim Mavraj:CB:70,Iv\xE1n Balliu:RB:68,Jahmir Hyka:LM:68,Ansi Nika:RM:64,Arenc Dibra:CF:64,Armando Vajushi:LW:64,Azdren Llullaku:LW:64,Ermir Lenjani:LB:64,Odise Roshi:RW:64",
  "Albania|2020": "Marash Kumbulla:CB:83,Thomas Strakosha:GK:82,Berat Djimsiti:CB:80,Elseid Hysaj:RB:79,Emanuele Ndoj:CM:70,Etrit Berisha:GK:70,Nedim Bajrami:CAM:70,Taulant Xhaka:CDM:70,Amir Abrashi:CDM:68,Keidi Bare:CM:68,Myrto Uzuni:LW:68,Albi Doka:RB:64,Ansi Nika:RM:64,Elis Kaptina:CF:64,Eros Grezda:RW:64,Esin Hakaj:LM:64,Odise Roshi:RW:64",
  "Albania|2023": "Armando Broja:ST:83,Berat Djimsiti:CB:77,Marash Kumbulla:CB:77,Myrto Uzuni:LW:77,Ernest Muci:CAM:76,Nedim Bajrami:CAM:76,Elseid Hysaj:RB:73,Iv\xE1n Balliu:RB:72,Thomas Strakosha:GK:72,Keidi Bare:CM:70,Elhan Kastrati:GK:68,Mario Mitaj:LB:68,Bardhec Bytyqi:LM:64,Marseljan Mema:CF:64",
  "Albania|2024": "Armando Broja:ST:82,Ernest Muci:CAM:79,Berat Djimsiti:CB:77,Myrto Uzuni:LW:77,Mirlind Daku:ST:76,Ardian Ismajli:CB:74,Cristian Shpendi:ST:74,Marash Kumbulla:CB:73,Mario Mitaj:LB:73,Nedim Bajrami:CAM:73,Qazim Laci:CM:72,Elseid Hysaj:RB:70,Iv\xE1n Balliu:RB:70,Keidi Bare:CM:70,Thomas Strakosha:GK:70,Albion Ademi:LW:68,Alen Sherri:GK:64,Elis Kaptina:CF:64,Esin Hakaj:LM:64,Stavro Pilo:LB:64",
  "Albania|2025": "Armando Broja:ST:79,Ernest Muci:CAM:78,Mirlind Daku:ST:77,Marash Kumbulla:CB:76,Myrto Uzuni:LW:76,Berat Djimsiti:CB:74,Mario Mitaj:LB:74,Medon Berisha:CM:74,Cristian Shpendi:ST:73,Arbnor Muja:RW:72,Nedim Bajrami:CAM:72,Qazim Laci:CM:72,Arb\xEBr Hoxha:LW:70,Thomas Strakosha:GK:70,Jasir Asani:RW:68,Stavro Pilo:LB:68,Brayan Boci:LM:64,Enis Tozaj:CF:64",
  "Albania|2026": "Anis Mehmeti:CAM:79,Ernest Muci:CAM:78,Mirlind Daku:ST:77,Armando Broja:ST:76,Cristian Shpendi:ST:74,Mario Mitaj:LB:74,Medon Berisha:CM:74,Ardian Ismajli:CB:73,Berat Djimsiti:CB:73,Myrto Uzuni:LW:73,Arb\xEBr Hoxha:LW:70,Luis Hasa:CM:70,Qazim Laci:CM:70,Thomas Strakosha:GK:70,Arbnor Muja:RW:68,Elseid Hysaj:RB:68,Jasir Asani:RW:68,Brayan Boci:LM:64",
  "Algeria|2019": "Riyad Mahrez:RW:87,Houssem Aouar:CAM:86,Yacine Brahimi:LW:83,Faouzi Ghoulam:LB:82,Youcef Atal:RB:82,A\xEFssa Mandi:CB:81,Isma\xEBl Bennacer:CDM:80,Andy Delort:ST:79,Ishak Belfodil:ST:79,Nabil Bentaleb:CDM:79,Ramy Bensebaini:CB:78,Rayan A\xEFt-Nouri:LB:78,Adam Ounas:RW:77,Islam Slimani:ST:77,Sa\xEFd Benrahma:LW:76,Sofiane Feghouli:CAM:76,Saphir Ta\xEFder:CM:70,Alexandre Oukidja:GK:68,Hicham Boudaoui:CM:68,Luca Zidane:GK:68,Mehdi Zeffane:RB:68,Abdesselam Rihane:RM:64,Sid Ahmed Aouedj:LM:64",
  "Algeria|2020": "Houssem Aouar:CAM:87,Riyad Mahrez:RW:86,Isma\xEBl Bennacer:CDM:85,Sa\xEFd Benrahma:LW:82,Youcef Atal:RB:81,A\xEFssa Mandi:CB:80,Ramy Bensebaini:CB:80,Yacine Brahimi:LW:80,Amine Gouiri:ST:79,Andy Delort:ST:79,Faouzi Ghoulam:LB:78,Ishak Belfodil:ST:78,Adil Aouchiche:CAM:77,Adam Ounas:RW:76,Mohamed Fares:LB:76,Yacine Adli:CDM:75,Hicham Boudaoui:CM:72,Adem Zorgane:CM:70,Alexandre Oukidja:GK:70,Mehdi Abeid:CM:70,Saphir Ta\xEFder:CM:70,Luca Zidane:GK:68,Mehdi Zeffane:RB:68,Mohamed Bentiba:RM:64,Sid Ahmed Aouedj:LM:64",
  "Algeria|2021": "Amine Gouiri:ST:86,Houssem Aouar:CAM:85,Isma\xEBl Bennacer:CDM:85,Riyad Mahrez:RW:85,Ramy Bensebaini:CB:82,Sa\xEFd Benrahma:LW:82,Rayan A\xEFt-Nouri:LB:81,Andy Delort:ST:80,Youcef Atal:RB:80,Rachid Ghezzal:RW:78,Adil Aouchiche:CAM:77,Yacine Adli:CDM:77,A\xEFssa Mandi:CB:76,Yacine Brahimi:LW:76,Baghdad Bounedjah:ST:74,Mohamed Fares:LB:74,Adem Zorgane:CM:70,Alexandre Oukidja:GK:70,Haris Belkebla:CM:70,Saphir Ta\xEFder:CM:70,Akim Zedadka:RB:68,Luca Zidane:GK:68,Mohamed Farsi:RM:64",
  "Algeria|2022": "Amine Gouiri:ST:86,Isma\xEBl Bennacer:CDM:85,Riyad Mahrez:RW:84,Houssem Aouar:CAM:83,Sa\xEFd Benrahma:LW:82,Ramy Bensebaini:CB:81,Andy Delort:ST:79,Youcef Atal:RB:79,Rachid Ghezzal:RW:77,Yacine Adli:CDM:77,Hicham Boudaoui:CM:75,Adil Aouchiche:CAM:74,A\xEFssa Mandi:CB:74,Baghdad Bounedjah:ST:74,Mohamed Fares:LB:73,Adem Zorgane:CM:72,Akim Zedadka:RB:72,Haris Belkebla:CM:72,Yasser Larouci:LB:72,Luca Zidane:GK:68,Youcef Bela\xEFli:LW:68,Alexandre Oukidja:GK:64,Mohamed Amine Ouis:RM:64",
  "Algeria|2023": "Amine Gouiri:ST:84,Rayan A\xEFt-Nouri:LB:83,Sa\xEFd Benrahma:LW:82,Ramy Bensebaini:CB:81,Riyad Mahrez:RW:81,Far\xE8s Cha\xEFbi:CAM:79,Houssem Aouar:CAM:79,Hicham Boudaoui:CM:77,Mohamed Amoura:ST:77,Youcef Atal:RB:77,Adam Ounas:RW:76,Adem Zorgane:CM:74,Baghdad Bounedjah:ST:72,Yasser Larouci:LB:72,Akim Zedadka:RB:70,Haris Belkebla:CM:70,Yacine Brahimi:LW:70,Anthony Mandr\xE9a:GK:68,Luca Zidane:GK:68,Mohamed Farsi:RM:68,Abderrahmane Bacha:CF:64,Karim Zedadka:LM:64",
  "Algeria|2024": "Rayan A\xEFt-Nouri:LB:84,Amine Gouiri:ST:82,Mohamed Amoura:ST:82,Sa\xEFd Benrahma:LW:81,Far\xE8s Cha\xEFbi:CAM:80,Anis Hadj Moussa:RW:78,Riyad Mahrez:RW:78,Hicham Boudaoui:CM:77,Houssem Aouar:CAM:77,Ramy Bensebaini:CB:77,Youcef Atal:RB:73,Andy Delort:ST:72,Jaouen Hadjam:LB:72,Farid El Melali:LW:70,Kevin Van Den Kerkhof:RB:70,Mohamed Farsi:RM:70,Anthony Mandr\xE9a:GK:68,Luca Zidane:GK:68,Abderrahmane Bacha:CF:64,Karim Zedadka:LM:64",
  "Algeria|2025": "Rayan A\xEFt-Nouri:LB:85,Mohamed Amoura:ST:84,Amine Gouiri:ST:83,Ibrahim Maza:CAM:82,Anis Hadj Moussa:RW:81,Far\xE8s Cha\xEFbi:CAM:79,Hicham Boudaoui:CM:79,Badredine Bouanani:RW:78,Adem Zorgane:CM:77,Jaouen Hadjam:LB:77,Sa\xEFd Benrahma:LW:77,Rafik Belghali:RB:76,Ramy Bensebaini:CB:76,Yassine Titraoui:CM:73,Farid El Melali:LW:72,Mohamed Farsi:RM:70,Youcef Atal:RB:70,Luca Zidane:GK:68,Abderrahmane Bacha:CF:64,Anis Bakhouche:LM:64",
  "Argentina|2016": "Lionel Messi:RW:91,Gonzalo Higua\xEDn:ST:89,\xC1ngel Di Mar\xEDa:RW:87,Sergio Ag\xFCero:ST:87,Paulo Dybala:CF:86,Mauro Icardi:ST:85,Nicol\xE1s Otamendi:CB:84,Nico Gait\xE1n:CAM:83,Ezequiel Garay:CB:82,Javier Pastore:CAM:82,\xC9ver Banega:CM:81,Lucas Biglia:CDM:81,Marcos Rojo:CB:81,Roberto Pereyra:CM:80,Diego Perotti:LW:79,Enzo P\xE9rez:CDM:79,Mateo Musacchio:CB:79,Pablo Zabaleta:RB:79,Papu G\xF3mez:LW:77,Augusto Fern\xE1ndez:CM:76,Ger\xF3nimo Rulli:GK:76,Ricardo \xC1lvarez:CM:76,Cristian Ansaldi:LB:74,Gino Peruzzi:RB:74,Emmanuel M\xE1s:LB:73,Sergio Romero:GK:73,Jes\xFAs D\xE1tolo:LM:70,Ramiro Carrera:RM:70",
  "Argentina|2017": "Lionel Messi:RW:91,Gonzalo Higua\xEDn:ST:89,Mauro Icardi:ST:89,Paulo Dybala:CF:89,Sergio Ag\xFCero:ST:88,\xC1ngel Di Mar\xEDa:RW:86,Nicol\xE1s Otamendi:CB:83,Nico Gait\xE1n:CAM:82,Diego Perotti:LW:81,\xC9ver Banega:CM:81,Javier Pastore:CAM:81,Lucas Biglia:CDM:81,Marcos Rojo:CB:81,Leandro Paredes:CDM:80,Mateo Musacchio:CB:80,Papu G\xF3mez:LW:80,Roberto Pereyra:CM:80,Cristian Pav\xF3n:RB:79,Ezequiel Garay:CB:79,Ger\xF3nimo Rulli:GK:79,Marcos Acu\xF1a:LB:78,Pablo Zabaleta:RB:76,Augusto Fern\xE1ndez:CM:74,Cristian Ansaldi:LB:74,Ricardo \xC1lvarez:CM:74,Sergio Romero:GK:74,Augusto Solari:RM:72,Gervasio N\xFA\xF1ez:LM:68",
  "Argentina|2018": "Lionel Messi:RW:93,Paulo Dybala:CF:91,Mauro Icardi:ST:90,Sergio Ag\xFCero:ST:89,Gonzalo Higua\xEDn:ST:87,\xC1ngel Di Mar\xEDa:RW:86,Nicol\xE1s Otamendi:CB:84,Giovani Lo Celso:CAM:83,Leandro Paredes:CDM:82,Santiago Ascac\xEDbar:CDM:82,Cristian Pav\xF3n:RB:81,Diego Perotti:LW:81,\xC9ver Banega:CM:81,Exequiel Palacios:CM:81,Germ\xE1n Pezzella:CB:81,Gonzalo Mart\xEDnez:CAM:81,Nicol\xE1s Tagliafico:LB:81,Franco Cervi:LW:80,Marcos Rojo:CB:80,Rodrigo De Paul:CM:80,Ezequiel Garay:CB:79,Fabricio Bustos:RB:79,Marcos Acu\xF1a:LB:79,Roberto Pereyra:CM:78,Ger\xF3nimo Rulli:GK:77,Franco Armani:GK:76,Augusto Solari:RM:74,An\xEDbal Domeneghini:LM:64",
  "Argentina|2019": "Lionel Messi:RW:92,Mauro Icardi:ST:90,Paulo Dybala:CF:90,Lautaro Mart\xEDnez:ST:89,Sergio Ag\xFCero:ST:88,Giovani Lo Celso:CAM:86,\xC1ngel Di Mar\xEDa:RW:85,Leandro Paredes:CDM:85,Nicol\xE1s Tagliafico:LB:84,Nicol\xE1s Otamendi:CB:83,Exequiel Palacios:CM:82,Lucas Ocampos:LW:82,Rodrigo De Paul:CM:82,Lisandro Mart\xEDnez:CB:81,Thiago Almada:LW:81,Emiliano Buend\xEDa:CAM:80,Germ\xE1n Pezzella:CB:80,Marcos Acu\xF1a:LB:80,Nicol\xE1s Dom\xEDnguez:CM:80,Santiago Ascac\xEDbar:CDM:80,Agust\xEDn Almendra:CM:79,Cristian Pav\xF3n:RB:79,Cristian Romero:CB:79,Juan Musso:GK:79,Esteban Andrada:GK:77,Gonzalo Montiel:RB:77,Augusto Solari:RM:74,Cristian Canuh\xE9:LM:64",
  "Argentina|2020": "Lionel Messi:RW:91,Paulo Dybala:CF:90,Lautaro Mart\xEDnez:ST:88,Mauro Icardi:ST:87,Lucas Ocampos:LW:86,Sergio Ag\xFCero:ST:86,Giovani Lo Celso:CAM:85,\xC1ngel Di Mar\xEDa:RW:84,Rodrigo De Paul:CM:84,Nicol\xE1s Tagliafico:LB:83,Exequiel Palacios:CM:82,Lisandro Mart\xEDnez:CB:82,Juan Musso:GK:81,Leandro Paredes:CDM:81,Emiliano Buend\xEDa:CAM:80,Emiliano Mart\xEDnez:GK:80,Nico Gonz\xE1lez:LW:80,Nicol\xE1s Dom\xEDnguez:CM:80,Cristian Pav\xF3n:RB:79,Cristian Romero:CB:79,Marcos Senesi:CB:79,Agust\xEDn Almendra:CM:78,Guido Rodr\xEDguez:CDM:78,Marcos Acu\xF1a:LB:78,Gonzalo Montiel:RB:76,Emanuel Mammana:CB:74,Augusto Solari:RM:72,Claudio Pombo:LM:64",
  "Argentina|2021": "Lautaro Mart\xEDnez:ST:89,Lionel Messi:RW:89,Paulo Dybala:CF:87,Lucas Ocampos:LW:86,Mauro Icardi:ST:85,Rodrigo De Paul:CM:85,Cristian Romero:CB:84,Emiliano Buend\xEDa:CAM:84,Emiliano Mart\xEDnez:GK:84,\xC1ngel Di Mar\xEDa:RW:83,Giovani Lo Celso:CAM:83,Guido Rodr\xEDguez:CDM:82,Leandro Paredes:CDM:82,Lisandro Mart\xEDnez:CB:82,Nico Gonz\xE1lez:LW:82,Nicol\xE1s Tagliafico:LB:82,Sergio Ag\xFCero:ST:82,Juan Foyth:CB:81,Juan Musso:GK:81,Marcos Senesi:CB:81,Exequiel Palacios:CM:80,Gonzalo Montiel:RB:80,Marcos Acu\xF1a:LB:80,Nicol\xE1s Dom\xEDnguez:CM:79,Cristian Pav\xF3n:RB:78,Alexis Mac Allister:CM:77,Augusto Solari:RM:72",
  "Argentina|2022": "Lautaro Mart\xEDnez:ST:89,Cristian Romero:CB:87,Enzo Fern\xE1ndez:CM:87,\xC1ngel Correa:CF:86,Juli\xE1n Alvarez:ST:86,Lionel Messi:RW:86,Lisandro Mart\xEDnez:CB:86,Alexis Mac Allister:CM:85,Rodrigo De Paul:CM:85,Emiliano Buend\xEDa:CAM:84,Emiliano Mart\xEDnez:GK:83,Guido Rodr\xEDguez:CDM:83,Giovani Lo Celso:CAM:82,Juan Foyth:CB:82,Lucas Ocampos:LW:82,Mauro Icardi:ST:82,Nahuel Molina:RB:82,Erik Lamela:RW:80,Juan Musso:GK:80,Leandro Paredes:CDM:80,Marcos Acu\xF1a:LB:80,Marcos Senesi:CB:80,Nicol\xE1s Tagliafico:LB:80,Thiago Almada:LW:80,Exequiel Palacios:CM:79,Gonzalo Montiel:RB:79,Augusto Solari:RM:70",
  "Argentina|2023": "Lautaro Mart\xEDnez:ST:91,Juli\xE1n Alvarez:ST:90,Enzo Fern\xE1ndez:CM:89,Alexis Mac Allister:CM:88,Cristian Romero:CB:88,Lionel Messi:RW:86,Lisandro Mart\xEDnez:CB:86,Nahuel Molina:RB:86,Exequiel Palacios:CM:85,Nico Gonz\xE1lez:LW:85,Rodrigo De Paul:CM:85,\xC1ngel Correa:CF:84,Alejandro Garnacho:LW:83,Emiliano Buend\xEDa:CAM:83,Emiliano Mart\xEDnez:GK:83,Facundo Medina:CB:82,Juan Foyth:CB:82,Mat\xEDas Soul\xE9:RW:82,Mauro Icardi:ST:81,Giovani Lo Celso:CAM:80,Juan Musso:GK:79,Gonzalo Montiel:RB:78,Marcos Acu\xF1a:LB:78,Nicol\xE1s Tagliafico:LB:77,Augusto Solari:RM:68,Claudio Pombo:LM:64",
  "Argentina|2024": "Lautaro Mart\xEDnez:ST:91,Juli\xE1n Alvarez:ST:90,Alexis Mac Allister:CM:89,Enzo Fern\xE1ndez:CM:89,Cristian Romero:CB:88,Alejandro Garnacho:LW:86,Exequiel Palacios:CM:86,Lisandro Mart\xEDnez:CB:86,Nahuel Molina:RB:84,Nico Gonz\xE1lez:LW:84,Emiliano Mart\xEDnez:GK:83,Lionel Messi:RW:83,Rodrigo De Paul:CM:83,Emiliano Buend\xEDa:CAM:82,Facundo Buonanotte:CAM:82,Facundo Medina:CB:82,Marcos Senesi:CB:82,Mat\xEDas Soul\xE9:RW:82,Santiago Castro:ST:82,Paulo Dybala:CF:81,Walter Ben\xEDtez:GK:79,Gonzalo Montiel:RB:77,Julio Soler:LB:76,Nicol\xE1s Tagliafico:LB:76,Joaqu\xEDn Gho:RM:70,Gabriel Alan\xEDs:LM:66",
  "Argentina|2025": "Alexis Mac Allister:CM:90,Juli\xE1n Alvarez:ST:90,Lautaro Mart\xEDnez:ST:90,Enzo Fern\xE1ndez:CM:89,Nico Paz:CAM:88,Cristian Romero:CB:87,Alejandro Garnacho:LW:86,Franco Mastantuono:RW:86,Lisandro Mart\xEDnez:CB:86,Exequiel Palacios:CM:85,Mat\xEDas Soul\xE9:RW:84,Santiago Castro:ST:84,Nico Gonz\xE1lez:LW:83,Facundo Medina:CB:82,Marcos Senesi:CB:82,Rodrigo De Paul:CM:82,Emiliano Mart\xEDnez:GK:81,Facundo Buonanotte:CAM:81,Nahuel Molina:RB:81,Agust\xEDn Giay:RB:78,Agust\xEDn Rossi:GK:77,\xC1ngel Correa:CF:77,Alexandro Bernabei:LB:76,Francisco Ortega:LB:76,Santino Andino:LM:73,Joaqu\xEDn Gho:RM:70",
  "Argentina|2026": "Enzo Fern\xE1ndez:CM:90,Juli\xE1n Alvarez:ST:90,Alexis Mac Allister:CM:89,Lautaro Mart\xEDnez:ST:89,Nico Paz:CAM:88,Cristian Romero:CB:86,Franco Mastantuono:RW:86,Alejandro Garnacho:LW:85,Giuliano Simeone:RW:85,Lisandro Mart\xEDnez:CB:85,Joaqu\xEDn Panichelli:ST:84,Valent\xEDn Barco:CM:84,Exequiel Palacios:CM:83,Marcos Senesi:CB:82,Nico Gonz\xE1lez:LW:82,Emiliano Buend\xEDa:CAM:80,Facundo Medina:CB:80,Emiliano Mart\xEDnez:GK:79,Nahuel Molina:RB:79,Agust\xEDn Giay:RB:77,Agust\xEDn Rossi:GK:77,Francisco Ortega:LB:76,Julio Soler:LB:76,Santino Andino:LM:74,Joaqu\xEDn Gho:RM:68",
  "Australia|2020": "Aaron Mooy:CM:77,Mathew Ryan:GK:76,Harry Souttar:CB:72,Jackson Irvine:CM:72,Awer Mabil:LW:70,Massimo Luongo:CM:70,Milos Degenek:CB:70,Tom Rogic:CAM:70,Fran Karacic:RB:68,Mathew Leckie:LW:68,Ahmad Elrich:RM:64,Brad Jones:GK:64,Brad Smith:LB:64,Callum Elder:LB:64,Daniel Arzani:RW:64,Richard Cardozo:CF:64",
  "Austria|2016": "David Alaba:CB:86,Aleksandar Dragovic:CB:79,Marko Arnautovic:ST:78,Kevin Wimmer:CB:76,Zlatko Junuzovic:CM:76,Julian Baumgartlinger:CDM:74,Martin Hinteregger:CB:74,Alessandro Sch\xF6pf:CM:73,Florian Kainz:CAM:73,Marcel Sabitzer:CM:73,Andreas Weimann:ST:72,Florian Grillitsch:CDM:72,Louis Schaub:RM:72,Martin Harnik:ST:72,Konrad Laimer:RB:70,Moritz Bauer:RB:70,Alexander Gorgon:CAM:68,Christoph Martschinko:LB:68,Alexander Hauser:LM:64,Andreas Lukse:GK:64,Andreas Ulmer:LB:64,Cican Stankovic:GK:64,Daniel Beichler:CF:64,Daniel Royer:LW:64",
  "Austria|2017": "David Alaba:CB:85,Marcel Sabitzer:CM:80,Aleksandar Dragovic:CB:79,Marko Arnautovic:ST:79,Kevin Wimmer:CB:78,Martin Hinteregger:CB:77,Michael Gregoritsch:ST:77,Alessandro Sch\xF6pf:CM:76,Guido Burgstaller:ST:76,Konrad Laimer:RB:76,Christian Fuchs:LB:74,Stefan Ilsanker:CDM:74,Florian Grillitsch:CDM:73,Valentino Lazaro:RM:73,Alexander Gorgon:CAM:70,Florian Kainz:CAM:70,Hannes Wolf:RW:70,Markus Suttner:LB:70,Moritz Bauer:RB:70,Veli Kavlak:CM:70,Daniel Royer:LW:68,Dominik Prokop:LM:68,Jakob Jantscher:LW:68,Andreas Lukse:GK:64,Darko Bodul:CF:64,Heinz Lindner:GK:64",
  "Austria|2018": "David Alaba:CB:87,Marko Arnautovic:ST:84,Marcel Sabitzer:CM:82,Florian Grillitsch:CDM:81,Michael Gregoritsch:ST:81,Valentino Lazaro:RM:80,Guido Burgstaller:ST:79,Stefan Lainer:RB:79,Xaver Schlager:CM:79,Kevin Wimmer:CB:78,Aleksandar Dragovic:CB:77,Hannes Wolf:RW:77,Martin Hinteregger:CB:77,Konrad Laimer:RB:76,Christian Fuchs:LB:74,Alessandro Sch\xF6pf:CM:73,Stefan Ilsanker:CDM:73,Zlatko Junuzovic:CM:73,Cican Stankovic:GK:72,Florian Kainz:CAM:72,Richard Strebinger:GK:72,Thomas Murg:CAM:72,Markus Suttner:LB:70,Daniel Royer:LW:68,Dominik Prokop:LM:68,Darko Bodul:CF:64,Jakob Jantscher:LW:64",
  "Austria|2019": "David Alaba:CB:88,Marcel Sabitzer:CM:85,Marko Arnautovic:ST:84,Florian Grillitsch:CDM:82,Konrad Laimer:RB:82,Valentino Lazaro:RM:81,Martin Hinteregger:CB:80,Michael Gregoritsch:ST:80,Stefan Lainer:RB:80,Stefan Posch:CB:79,Xaver Schlager:CM:79,Hannes Wolf:RW:78,Philipp Lienhart:CB:78,Guido Burgstaller:ST:74,Alessandro Sch\xF6pf:CM:73,Alexander Schlager:GK:73,Stefan Ilsanker:CDM:73,Cican Stankovic:GK:72,Peter Zulj:CM:72,Thomas Goiginger:LW:72,Christian Fuchs:LB:70,Daniel Royer:LW:70,Florian Kainz:CAM:70,Nikola Dovedan:CF:70,Alexander Gr\xFCnwald:CAM:68,Dominik Prokop:LM:68,Markus Suttner:LB:68",
  "Austria|2020": "David Alaba:CB:88,Marcel Sabitzer:CM:84,Konrad Laimer:RB:83,Florian Grillitsch:CDM:82,Christoph Baumgartner:CAM:80,Marko Arnautovic:ST:80,Martin Hinteregger:CB:80,Xaver Schlager:CM:80,Stefan Lainer:RB:79,Valentino Lazaro:RM:79,Hannes Wolf:RW:78,Adrian Grbic:ST:77,Aleksandar Dragovic:CB:75,Kevin Danso:CB:75,Kevin St\xF6ger:CAM:74,Michael Gregoritsch:ST:74,Alexander Schlager:GK:73,Yusuf Demir:RW:73,Alessandro Sch\xF6pf:CM:72,Zlatko Junuzovic:CM:72,Cican Stankovic:GK:70,Daniel Royer:LW:70,Dejan Ljubicic:CDM:70,Thomas Goiginger:LW:70,Husein Balic:LM:68,Nikola Dovedan:CF:68,Rene Renner:LB:64",
  "Austria|2021": "David Alaba:CB:87,Marcel Sabitzer:CM:85,Konrad Laimer:RB:83,Xaver Schlager:CM:83,Christoph Baumgartner:CAM:82,Sasa Kalajdzic:ST:82,Florian Grillitsch:CDM:81,Martin Hinteregger:CB:80,Philipp Lienhart:CB:80,Nicolas Seiwald:CDM:79,Stefan Lainer:RB:79,Stefan Posch:CB:79,Valentino Lazaro:RM:79,Yusuf Demir:RW:78,Hannes Wolf:RW:77,Marko Arnautovic:ST:77,Adrian Grbic:ST:76,Romano Schmid:CAM:73,Marco Gr\xFCll:LW:72,Alessandro Sch\xF6pf:CM:70,Alexander Schlager:GK:70,Carney Chukwuemeka:CM:70,Daniel Bachmann:GK:70,Phillipp Mwene:LB:70,Robert Zulj:CF:70,Daniel Royer:LW:68,Christian Fuchs:LB:64",
  "Austria|2022": "David Alaba:CB:87,Konrad Laimer:RB:83,Xaver Schlager:CM:83,Christoph Baumgartner:CAM:82,Marcel Sabitzer:CM:82,Sasa Kalajdzic:ST:82,Nicolas Seiwald:CDM:81,Philipp Lienhart:CB:81,Florian Grillitsch:CDM:80,Carney Chukwuemeka:CM:79,Kevin Danso:CB:79,Maximilian W\xF6ber:CB:78,Marko Arnautovic:ST:77,Yusuf Demir:RW:77,Junior Adamu:ST:76,Valentino Lazaro:RM:75,Stefan Lainer:RB:74,Hannes Wolf:RW:73,Marco Gr\xFCll:LW:73,Dijon Kameri:CAM:72,Matthias Braun\xF6der:CM:72,Daniel Bachmann:GK:70,Phillipp Mwene:LB:70,Cican Stankovic:GK:68,Robert Zulj:CF:68",
  "Austria|2023": "David Alaba:CB:86,Konrad Laimer:RB:83,Xaver Schlager:CM:83,Christoph Baumgartner:CAM:82,Kevin Danso:CB:82,Marcel Sabitzer:CM:81,Philipp Lienhart:CB:81,Patrick Wimmer:RW:80,Carney Chukwuemeka:CM:79,Maximilian W\xF6ber:CB:79,Sasa Kalajdzic:ST:79,Junior Adamu:ST:76,Marko Arnautovic:ST:76,Romano Schmid:CAM:75,Yusuf Demir:RW:74,Marco Gr\xFCll:LW:72,Alexander Schlager:GK:70,Daniel Bachmann:GK:70,Matthias Braun\xF6der:CM:70,Phillipp Mwene:LB:70,Stefan Lainer:RB:70,David Schnegg:LB:68,Husein Balic:LM:68,Mathias Honsak:LW:68,Robert Zulj:CF:68,Ante Bajic:RM:64",
  "Austria|2024": "Konrad Laimer:RB:83,Xaver Schlager:CM:83,David Alaba:CB:82,Kevin Danso:CB:82,Christoph Baumgartner:CAM:81,Marcel Sabitzer:CM:81,Paul Wanner:CAM:80,Carney Chukwuemeka:CM:79,Patrick Wimmer:RW:79,Philipp Lienhart:CB:79,Stefan Posch:CB:79,Michael Gregoritsch:ST:76,Junior Adamu:ST:74,Sasa Kalajdzic:ST:73,Alexander Prass:LM:72,Marco Gr\xFCll:LW:72,Matthias Seidl:CM:72,Valentino Lazaro:RM:72,Alexander Schlager:GK:70,Hannes Wolf:RW:70,Niklas Hedl:GK:70,Stefan Lainer:RB:70,Thierno Ballo:LW:70,David Schnegg:LB:68,Jonas Auer:LB:68,Robert Zulj:CF:68",
  "Austria|2025": "Konrad Laimer:RB:84,Carney Chukwuemeka:CM:82,Kevin Danso:CB:82,Christoph Baumgartner:CAM:81,Leopold Querfeld:CB:80,Paul Wanner:CAM:80,Xaver Schlager:CM:80,Patrick Wimmer:RW:79,Marco Friedl:CB:78,Samson Baidoo:CB:78,Marcel Sabitzer:CM:77,Alexander Prass:LM:76,Marco Gr\xFCll:LW:74,Thierno Ballo:LW:74,Hannes Wolf:RW:73,Junior Adamu:ST:73,Valentino Lazaro:RM:73,Matthias Seidl:CM:72,Michael Gregoritsch:ST:72,Sasa Kalajdzic:ST:72,Alexander Schlager:GK:70,Niklas Hedl:GK:70,David Schnegg:LB:68,Jonas Auer:LB:68,Tim Trummer:RB:68,Amir Abdijanovic:CF:64",
  "Austria|2026": "Konrad Laimer:RB:84,Christoph Baumgartner:CAM:83,Samson Baidoo:CB:82,Carney Chukwuemeka:CM:81,Kevin Danso:CB:81,Leopold Querfeld:CB:80,Paul Wanner:CAM:80,Patrick Wimmer:RW:79,Alexander Prass:LM:78,Philipp Lienhart:CB:78,Xaver Schlager:CM:77,Marcel Sabitzer:CM:76,Marco Gr\xFCll:LW:74,Raul Florucz:ST:74,Thierno Ballo:LW:74,Hannes Wolf:RW:73,Junior Adamu:ST:72,Valentino Lazaro:RM:72,Alexander Schlager:GK:70,Tobias Lawal:GK:70,Phillipp Mwene:LB:68,Tim Trummer:RB:68",
  "Belarus|2017": "Aleksandr Martynovich:CB:70,Mikhail Gordeychuk:RW:68,Renan Bressan:CAM:68,Aleksandr Dzhigero:LM:64,Aleksandr Gutor:GK:64,Aleksandr Tolkanitsa:RM:64,Aleksey Rios:RB:64,Anton Putilo:CAM:64,Dmitriy Komarovskiy:CF:64,Igor Stasevich:LW:64,Maksim Volodko:LB:64,Pavel Nekhaychik:LW:64,Pavel Savitskiy:RW:64,Sergey Balanovich:LB:64,Sergey Chernik:GK:64",
  "Belgium|2016": "Eden Hazard:LW:88,Kevin De Bruyne:CAM:87,Romelu Lukaku:ST:85,Radja Nainggolan:CM:84,Thibaut Courtois:GK:84,Axel Witsel:CDM:83,Christian Benteke:ST:83,Toby Alderweireld:CB:83,Vincent Kompany:CB:83,Yannick Carrasco:LW:83,Jan Vertonghen:CB:82,Michy Batshuayi:ST:82,Marouane Fellaini:CM:81,Dries Mertens:CF:80,Mousa Demb\xE9l\xE9:CM:80,Kevin Mirallas:RW:79,Youri Tielemans:CM:79,Simon Mignolet:GK:78,Thorgan Hazard:CAM:78,Bj\xF6rn Engels:CB:77,Adnan Januzaj:RW:76,Leander Dendoncker:CDM:76,Thomas Meunier:RB:76,Jordan Lukaku:LB:72,Laurens De Bock:LB:72,Luis Pedro Cavanda:RB:72,J\xE9r\xE9my Serwy:RM:64,Nils Schouterden:LM:64",
  "Belgium|2017": "Eden Hazard:LW:89,Kevin De Bruyne:CAM:89,Romelu Lukaku:ST:88,Radja Nainggolan:CM:86,Thibaut Courtois:GK:85,Yannick Carrasco:LW:85,Dries Mertens:CF:84,Toby Alderweireld:CB:84,Christian Benteke:ST:83,Jan Vertonghen:CB:83,Michy Batshuayi:ST:82,Vincent Kompany:CB:82,Youri Tielemans:CM:82,Thorgan Hazard:CAM:81,Axel Witsel:CDM:80,Leander Dendoncker:CDM:80,Mousa Demb\xE9l\xE9:CM:80,Dennis Praet:CM:79,Kevin Mirallas:RW:79,Simon Mignolet:GK:78,Bj\xF6rn Engels:CB:77,Thomas Meunier:RB:77,Adnan Januzaj:RW:76,Laurens De Bock:LB:72,Thomas Foket:RB:72,Boli Bolingoli:LB:64,J\xE9r\xE9my Serwy:RM:64,Nils Schouterden:LM:64",
  "Belgium|2018": "Eden Hazard:LW:92,Kevin De Bruyne:CAM:92,Romelu Lukaku:ST:90,Thibaut Courtois:GK:88,Radja Nainggolan:CM:86,Axel Witsel:CDM:85,Michy Batshuayi:ST:85,Thorgan Hazard:CAM:85,Toby Alderweireld:CB:85,Yannick Carrasco:LW:85,Jan Vertonghen:CB:84,Thomas Meunier:RB:84,Dries Mertens:CF:83,Christian Benteke:ST:82,Dennis Praet:CM:82,Youri Tielemans:CM:82,Leander Dendoncker:CDM:80,Mousa Demb\xE9l\xE9:CM:80,Adnan Januzaj:RW:79,Simon Mignolet:GK:78,Christian Kabasele:CB:77,Kevin Mirallas:RW:77,Vincent Kompany:CB:77,Jordan Lukaku:LB:76,Thomas Foket:RB:73,Boli Bolingoli:LB:72,Alexis Saelemaekers:RM:70,Jason Bourdouxhe:LM:64",
  "Belgium|2019": "Eden Hazard:LW:92,Kevin De Bruyne:CAM:92,Romelu Lukaku:ST:89,Thibaut Courtois:GK:87,Youri Tielemans:CM:87,Thorgan Hazard:CAM:86,Toby Alderweireld:CB:85,Axel Witsel:CDM:84,Jan Vertonghen:CB:83,Leander Dendoncker:CDM:83,Michy Batshuayi:ST:83,Radja Nainggolan:CM:83,Thomas Meunier:RB:83,Yannick Carrasco:LW:83,Dennis Praet:CM:82,Dries Mertens:CF:82,Divock Origi:ST:81,Dodi Luk\xE9bakio:RW:81,Timothy Castagne:RB:81,Zinho Vanheusden:CB:80,Adnan Januzaj:RW:79,Jason Denayer:CB:79,Koen Casteels:GK:79,Albert Sambi Lokonga:CM:78,Alexis Saelemaekers:RM:76,Jordan Lukaku:LB:74,Boli Bolingoli:LB:72,Nils Schouterden:LM:64",
  "Belgium|2020": "Kevin De Bruyne:CAM:91,Eden Hazard:LW:90,Romelu Lukaku:ST:90,Thibaut Courtois:GK:89,Youri Tielemans:CM:86,Leander Dendoncker:CDM:84,Toby Alderweireld:CB:83,Dennis Praet:CM:82,Thomas Meunier:RB:82,Timothy Castagne:RB:82,Yannick Carrasco:LW:82,Axel Witsel:CDM:81,Dodi Luk\xE9bakio:RW:81,Dries Mertens:CF:81,Alexis Saelemaekers:RM:80,Divock Origi:ST:80,Jason Denayer:CB:80,Michy Batshuayi:ST:80,Radja Nainggolan:CM:80,Hans Vanaken:CAM:79,Zinho Vanheusden:CB:79,Albert Sambi Lokonga:CM:77,Koen Casteels:GK:77,Christian Kabasele:CB:75,Isaac Mbenza:RW:74,Jordan Lukaku:LB:72,Boli Bolingoli:LB:70,Jason Bourdouxhe:LM:64",
  "Belgium|2021": "Kevin De Bruyne:CAM:90,Romelu Lukaku:ST:90,Thibaut Courtois:GK:89,Youri Tielemans:CM:87,Eden Hazard:LW:86,Yannick Carrasco:LW:85,Leander Dendoncker:CDM:84,Thorgan Hazard:CAM:84,Timothy Castagne:RB:83,Jason Denayer:CB:82,Orel Mangala:CDM:82,Alexis Saelemaekers:RM:81,Dennis Praet:CM:81,Albert Sambi Lokonga:CM:80,Divock Origi:ST:80,Thomas Meunier:RB:80,Dodi Luk\xE9bakio:RW:79,Koen Casteels:GK:79,Sebastiaan Bornauw:CB:79,Toby Alderweireld:CB:79,Adnan Januzaj:RW:78,Dries Mertens:CF:78,Zinho Vanheusden:CB:78,Aster Vranckx:CM:77,Christian Benteke:ST:77,Boli Bolingoli:LB:70,Jordan Lukaku:LB:70",
  "Belgium|2022": "Kevin De Bruyne:CAM:89,Romelu Lukaku:ST:89,Thibaut Courtois:GK:87,Youri Tielemans:CM:87,Yannick Carrasco:LW:85,Amadou Onana:CDM:84,Charles De Ketelaere:CAM:83,Leander Dendoncker:CDM:83,Leandro Trossard:LW:83,Timothy Castagne:RB:83,Arthur Theate:CB:81,Wout Faes:CB:81,Alexis Saelemaekers:RM:80,Jason Denayer:CB:80,Albert Sambi Lokonga:CM:79,Dennis Praet:CM:79,Adnan Januzaj:RW:78,Divock Origi:ST:78,Dodi Luk\xE9bakio:RW:78,Koen Casteels:GK:78,Lo\xEFs Openda:ST:78,Aster Vranckx:CM:77,Hugo Siquet:RB:76,Toby Alderweireld:CB:76,Dries Mertens:CF:72,Maxim De Cuyper:LB:70,Kristof D'Haene:LB:64",
  "Belgium|2023": "J\xE9r\xE9my Doku:LW:88,Kevin De Bruyne:CAM:88,Lo\xEFs Openda:ST:87,Thibaut Courtois:GK:86,Johan Bakayoko:RW:85,Leandro Trossard:LW:85,Romelu Lukaku:ST:85,Charles De Ketelaere:CAM:83,Youri Tielemans:CM:83,Arthur Theate:CB:82,Timothy Castagne:RB:82,Wout Faes:CB:81,Albert Sambi Lokonga:CM:79,Alexis Saelemaekers:RM:79,Ameen Al-Dakhil:CB:79,Dodi Luk\xE9bakio:RW:79,Hugo Cuypers:ST:79,Zeno Debast:CB:79,Aster Vranckx:CM:78,Bryan Heynen:CM:78,Maarten Vandevoordt:GK:78,Maxim De Cuyper:LB:76,Thomas Foket:RB:76,Olivier Deman:LB:74,Dries Mertens:CF:72,Jason Bourdouxhe:LM:64",
  "Belgium|2024": "J\xE9r\xE9my Doku:LW:88,Lo\xEFs Openda:ST:87,Johan Bakayoko:RW:86,Kevin De Bruyne:CAM:86,Charles De Ketelaere:CAM:85,Romelu Lukaku:ST:83,Thibaut Courtois:GK:83,Youri Tielemans:CM:83,Malick Fofana:LW:82,Zeno Debast:CB:82,Arthur Theate:CB:81,Dodi Luk\xE9bakio:RW:81,Wout Faes:CB:81,Timothy Castagne:RB:80,Albert Sambi Lokonga:CM:79,Alexis Saelemaekers:RM:78,Ameen Al-Dakhil:CB:78,Arne Engels:CM:78,Aster Vranckx:CM:78,Maarten Vandevoordt:GK:78,Maxim De Cuyper:LB:78,Hugo Cuypers:ST:77,Joaquin Seys:LB:76,Killian Sardella:RB:74,Diego Moreira:LM:68,Dries Mertens:CF:68",
  "Belgium|2025": "J\xE9r\xE9my Doku:LW:88,Lo\xEFs Openda:ST:86,Youri Tielemans:CM:85,Charles De Ketelaere:CAM:84,Johan Bakayoko:RW:84,Kevin De Bruyne:CAM:83,Malick Fofana:LW:83,Zeno Debast:CB:83,Alexis Saelemaekers:RM:82,Arthur Theate:CB:82,Dodi Luk\xE9bakio:RW:82,Koni De Winter:CB:82,Maxim De Cuyper:LB:82,Romelu Lukaku:ST:82,Senne Lammens:GK:82,Matias Fernandez-Pardo:ST:81,Thibaut Courtois:GK:81,Diego Moreira:LM:80,Nathan De Cat:CM:80,Joaquin Seys:LB:79,Matte Smets:CB:79,Timothy Castagne:RB:79,Arne Engels:CM:78,Bryan Heynen:CM:78,Kyriani Sabbe:RB:74,Dries Mertens:CF:68",
  "Belgium|2026": "J\xE9r\xE9my Doku:LW:88,Lo\xEFs Openda:ST:84,Youri Tielemans:CM:84,Malick Fofana:LW:83,Matias Fernandez-Pardo:ST:83,Senne Lammens:GK:83,Zeno Debast:CB:83,Alexis Saelemaekers:RM:82,Diego Moreira:LM:82,Koni De Winter:CB:82,Maxim De Cuyper:LB:82,Mike Penders:GK:82,Nathan De Cat:CM:82,Arthur Theate:CB:81,Dodi Luk\xE9bakio:RW:81,Nathan Ngoy:CB:81,Arne Engels:CM:80,Joaquin Seys:LB:80,Lucas Stassin:ST:79,Albert Sambi Lokonga:CM:77,Kevin De Bruyne:CAM:77,Timothy Castagne:RB:77,Cyril Ngonge:RW:76,Kyriani Sabbe:RB:76,Hans Vanaken:CAM:74",
  "Bosnia-Herzegovina|2016": "Miralem Pjani\u0107:CM:85,Edin Dzeko:ST:79,Asmir Begovic:GK:78,Senad Lulic:LM:77,Edin Visca:RW:76,Sead Kolasinac:CB:76,Muhamed Besic:CDM:74,Danijel Milicevic:CAM:73,Armin Hodzic:ST:72,Ervin Zukanovic:CB:72,Riad Bajic:ST:72,Tino-Sven Susic:CM:72,Ermin Bicakcic:CB:70,Gojko Cimirot:CDM:70,Toni Sunjic:CB:70,Ermin Zec:LW:68,Haris Duljevic:LW:68,Haris Medunjanin:CM:68,Izet Hajrovic:RW:68,Almir Bekic:LB:64,Anes Haurdic:RM:64,Haris Ribic:CF:64,Ibrahim Sehic:GK:64,Mateo Susic:RB:64,Senijad Ibricic:CAM:64,Zoran Kvrzic:RB:64",
  "Bosnia-Herzegovina|2017": "Miralem Pjani\u0107:CM:86,Edin Dzeko:ST:82,Sead Kolasinac:CB:79,Asmir Begovic:GK:76,Edin Visca:RW:76,Senad Lulic:LM:76,Muhamed Besic:CDM:74,Riad Bajic:ST:73,Armin Hodzic:ST:72,Ervin Zukanovic:CB:72,Gojko Cimirot:CDM:72,Danijel Milicevic:CAM:70,Dario Dumic:CB:70,Tino-Sven Susic:CM:70,Avdija Vrsajevic:RB:68,Deni Milosevic:CAM:68,Ermin Bicakcic:CB:68,Ermin Zec:LW:68,Anes Haurdic:RM:64,Goran Karacic:GK:64,Haris Duljevic:LW:64,Izet Hajrovic:RW:64,Joco Stokic:CF:64",
  "Bosnia-Herzegovina|2018": "Miralem Pjani\u0107:CM:88,Edin Dzeko:ST:82,Sead Kolasinac:CB:81,Edin Visca:RW:77,Asmir Begovic:GK:76,Rade Krunic:CDM:76,Senad Lulic:LM:75,Muhamed Besic:CDM:73,Ermin Bicakcic:CB:72,Riad Bajic:ST:72,Sanjin Prcic:CM:70,Smail Prevljak:ST:70,Deni Milosevic:CAM:68,Haris Hajradinovic:CAM:68,Izet Hajrovic:RW:68,Darko Todorovic:RB:64,Eldar Civic:LB:64,Elvin Halavac:RM:64,Haris Duljevic:LW:64,Ibrahim Sehic:GK:64,Joco Stokic:CF:64,Luka Menalo:LW:64",
  "Bosnia-Herzegovina|2019": "Miralem Pjani\u0107:CM:88,Sead Kolasinac:CB:81,Edin Dzeko:ST:79,Edin Visca:RW:78,Amer Gojak:CAM:76,Asmir Begovic:GK:76,Rade Krunic:CDM:76,Gojko Cimirot:CDM:74,Ermin Bicakcic:CB:72,Mario Vrancic:CM:72,Riad Bajic:ST:72,Sanjin Prcic:CM:72,Senad Lulic:LM:72,Izet Hajrovic:RW:70,Smail Prevljak:ST:70,Haris Hajradinovic:CAM:68,Darko Todorovic:RB:64,Eldar Civic:LB:64,Ibrahim Sehic:GK:64,Josip Corluka:RM:64,Mateo Susic:RB:64,Sabahudin Jusufbasic:CF:64",
  "Bosnia-Herzegovina|2021": "Miralem Pjani\u0107:CM:85,Ermedin Demirovic:ST:78,Edin Visca:RW:77,Anel Ahmedhodzic:CB:76,Rade Krunic:CDM:76,Sead Kolasinac:CB:75,Edin Dzeko:ST:73,Ivan Sunjic:CDM:73,Amer Gojak:CAM:72,Amar Dedi\u0107:RB:70,Haris Hajradinovic:CAM:70,Luka Menalo:LW:70,Smail Prevljak:ST:70,Asmir Begovic:GK:68,Eldar Civic:LB:68,Jusuf Gazibegovic:RB:68,Miroslav Stevanovic:RM:68,Vladan Kovacevic:GK:68,Abdullah Dzafo:CF:64",
  "Bosnia-Herzegovina|2022": "Miralem Pjani\u0107:CM:79,Amar Dedi\u0107:RB:77,Anel Ahmedhodzic:CB:77,Ermedin Demirovic:ST:77,Rade Krunic:CDM:77,Amir Hadziahmetovic:CDM:74,Edin Visca:RW:74,Dennis Hadzikadunic:CB:72,Edin Dzeko:ST:72,Haris Hajradinovic:CAM:72,Sanjin Prcic:CM:72,Amar Rahmanovic:CAM:70,Dario Saric:CM:70,Smail Prevljak:ST:70,Dino Hotic:RW:68,Eldar Civic:LB:68,Ibrahim Sehic:GK:68,Luka Menalo:LW:68,Miroslav Stevanovic:RM:68,Asmir Begovic:GK:64,Dejan Zivkovic:CF:64",
  "Bosnia-Herzegovina|2023": "Amar Dedi\u0107:RB:81,Anel Ahmedhodzic:CB:81,Ermedin Demirovic:ST:81,Sead Kolasinac:CB:76,Vladan Kovacevic:GK:76,Benjamin Tahirovi\u0107:CM:74,Miralem Pjani\u0107:CM:74,Edin Dzeko:ST:72,Edin Visca:RW:72,Jusuf Gazibegovic:RB:72,Haris Hajradinovic:CAM:70,Ifet Djakovac:CM:70,Sanjin Prcic:CM:70,Dal Varesanovic:CAM:68,Dino Hotic:RW:68,Miroslav Stevanovic:RM:68,Bojan Nastic:LM:67,Dejan Zivkovic:CF:64,Ibrahim Sehic:GK:64,Ivan Milicevic:LB:64",
  "Bosnia-Herzegovina|2024": "Ermedin Demirovic:ST:83,Amar Dedi\u0107:RB:81,Anel Ahmedhodzic:CB:80,Sead Kolasinac:CB:77,Vladan Kovacevic:GK:74,Jusuf Gazibegovic:RB:73,Adrian Leon Barisic:CB:72,Denis Huseinbasic:CM:72,Esmir Bajraktarevic:RW:72,Miralem Pjani\u0107:CM:72,Samed Bazdar:ST:72,Amar Rahmanovic:CAM:70,Armin Gigovic:CM:70,Dal Varesanovic:CAM:70,Edin Dzeko:ST:70,Ifet Djakovac:CM:70,Nikola Vasilj:GK:70,Amar Memi\u0107:RM:64,Bojan Nastic:LM:64,Dejan Zivkovic:CF:64",
  "Bosnia-Herzegovina|2025": "Ermedin Demirovic:ST:82,Anel Ahmedhodzic:CB:80,Amar Dedi\u0107:RB:79,Tarik Muharemovi\u0107:CB:79,Kerim Alajbegovic:LW:76,Sead Kolasinac:CB:76,Adrian Leon Barisic:CB:73,Benjamin Tahirovi\u0107:CM:73,Esmir Bajraktarevic:RW:73,Nikola Vasilj:GK:73,Amar Memi\u0107:RM:72,Jusuf Gazibegovic:RB:72,Vladan Kovacevic:GK:72,Armin Gigovic:CM:70,Dal Varesanovic:CAM:70,Denis Huseinbasic:CM:70,Ermin Mahmic:CAM:70,Nail Omerovic:LW:70,Edin Visca:RW:68,Bojan Nastic:LM:64,Dejan Zivkovic:CF:64",
  "Bosnia-Herzegovina|2026": "Ermedin Demirovic:ST:82,Tarik Muharemovi\u0107:CB:81,Amar Dedi\u0107:RB:79,Kerim Alajbegovic:LW:79,Anel Ahmedhodzic:CB:78,Sead Kolasinac:CB:74,Amar Memi\u0107:RM:73,Benjamin Tahirovi\u0107:CM:73,Ermin Mahmic:CAM:73,Esmir Bajraktarevic:RW:73,Nikola Vasilj:GK:73,Nidal Celik:CB:72,Ajdin Hasic:RW:70,Denis Huseinbasic:CM:70,Jusuf Gazibegovic:RB:70,Nail Omerovic:LW:70,Vladan Kovacevic:GK:70,Emir Karic:LB:68,Bojan Nastic:LM:64",
  "Brazil|2016": "Neymar:CAM:90,Hulk:ST:85,Douglas Costa:RW:84,Lucas Moura:RW:84,Oscar:CAM:84,Roberto Firmino:ST:84,Willian:LW:84,Alex Sandro:LB:83,David Luiz:CB:83,Fernandinho:CDM:83,Marcelo:LB:83,Marquinhos:CB:83,Casemiro:CDM:81,Felipe Anderson:LW:81,Gabriel Barbosa:ST:81,Thiago Silva:CB:81,Danilo:CB:80,Bruno Peres:RB:79,Ramires:CM:79,Jonas:CF:78,Dani Alves:RB:77,Fred:CM:77,Gerson:CM:77,Paulinho:CM:77,Alisson:GK:76,Ederson:GK:76,Ilsinho:RM:72,Michel Bastos:LM:72",
  "Brazil|2017": "Neymar:CAM:92,Philippe Coutinho:CAM:88,Gabriel Jesus:ST:86,Alex Sandro:LB:85,Lucas Moura:RW:85,Marcelo:LB:85,Roberto Firmino:ST:85,Douglas Costa:RW:84,Marquinhos:CB:84,Willian:LW:84,Casemiro:CDM:83,David Luiz:CB:83,Ederson:GK:82,Fabinho:CDM:82,Felipe Anderson:LW:82,Hulk:ST:82,Paulinho:CM:81,Alisson:GK:80,Danilo:CB:80,Ricardo Goulart:CF:80,Thiago Silva:CB:80,Arthur Melo:CM:79,Bruno Peres:RB:79,Ramires:CM:79,Fred:CM:77,Mariano:RB:76,Ricardinho:LM:68,Diego Macedo:RM:64",
  "Brazil|2018": "Neymar:CAM:93,Philippe Coutinho:CAM:92,Gabriel Jesus:ST:89,Roberto Firmino:ST:89,Alisson:GK:88,Casemiro:CDM:88,Marcelo:LB:88,Douglas Costa:RW:87,Ederson:GK:87,Marquinhos:CB:87,Alex Sandro:LB:86,Allan:CDM:86,Arthur Melo:CM:86,Fred:CM:86,Malcom:RW:86,Richarlison:ST:86,Willian:LW:86,Paulinho:CM:85,Felipe Anderson:LW:84,David Luiz:CB:83,Danilo:CB:81,\xC9der Milit\xE3o:CB:81,Gerson:CM:79,Ricardo Goulart:CF:79,Rafael:RB:77,Bruno Peres:RB:76,Diego Rigonato:LM:70,Diego Macedo:RM:64",
  "Brazil|2019": "Neymar:CAM:93,Alisson:GK:90,Philippe Coutinho:CAM:90,Roberto Firmino:ST:90,Arthur Melo:CM:88,Casemiro:CDM:88,Ederson:GK:88,Fabinho:CDM:88,Gabriel Jesus:ST:88,Marquinhos:CB:88,Vinicius Junior:LW:88,Richarlison:ST:87,Alex Sandro:LB:86,David Neres:RW:86,\xC9der Milit\xE3o:CB:86,Felipe Anderson:LW:86,Rodrygo:RW:86,Alex Telles:LB:85,Fred:CM:84,Joelinton:CM:84,Paulinho:CM:84,Diego Carlos:CB:82,Felipe:CB:82,Emerson Royal:RB:79,Ricardo Goulart:CF:79,Rafael:RB:77,Diego Rigonato:LM:68,Guilherme Costa:RM:64",
  "Brazil|2020": "Neymar:CAM:91,Alisson:GK:89,Casemiro:CDM:89,Marquinhos:CB:88,Richarlison:ST:88,Roberto Firmino:ST:88,Arthur Melo:CM:87,Ederson:GK:87,Fabinho:CDM:87,Gabriel Jesus:ST:87,Philippe Coutinho:CAM:87,Diego Carlos:CB:86,Renan Lodi:LB:86,Rodrygo:RW:86,Vinicius Junior:LW:86,Alex Sandro:LB:85,\xC9der Milit\xE3o:CB:85,Felipe Anderson:LW:85,Malcom:RW:85,Bruno Guimar\xE3es:CM:84,Felipe:CB:84,Douglas Luiz:CM:83,Emerson Royal:RB:82,Joelinton:CM:82,William:RB:78,R\xF3ger Guedes:CF:77,Luis Henrique:RM:76,Assis:LM:64",
  "Brazil|2021": "Neymar:CAM:91,Vinicius Junior:LW:90,Marquinhos:CB:89,Alisson:GK:88,Casemiro:CDM:88,\xC9der Milit\xE3o:CB:87,Ederson:GK:87,Fabinho:CDM:87,Gabriel Jesus:ST:87,Richarlison:ST:87,Roberto Firmino:ST:87,Diego Carlos:CB:86,Philippe Coutinho:CAM:86,Rodrygo:RW:86,Arthur Melo:CM:85,Raphinha:LW:85,Renan Lodi:LB:85,Douglas Luiz:CM:84,Alex Telles:LB:83,Bruno Guimar\xE3es:CM:83,David Neres:RW:83,Emerson Royal:RB:82,Fred:CM:82,Gabriel:CB:82,Dod\xF4:RB:81,R\xF3ger Guedes:CF:77,Luis Henrique:RM:76",
  "Brazil|2022": "Vinicius Junior:LW:91,Antony:RW:89,Gabriel Jesus:ST:89,Neymar:CAM:89,Rodrygo:RW:89,Marquinhos:CB:88,Bruno Guimar\xE3es:CM:87,\xC9der Milit\xE3o:CB:87,Fabinho:CDM:87,Gabriel Martinelli:LW:87,Richarlison:ST:87,Alisson:GK:86,Casemiro:CDM:86,Ederson:GK:86,Lucas Paquet\xE1:CAM:86,Bremer:CB:85,Diego Carlos:CB:85,Douglas Luiz:CM:85,Joelinton:CM:84,Roberto Firmino:ST:84,Emerson Royal:RB:83,Renan Lodi:LB:83,Danilo:CM:82,Caio Henrique:LB:81,Dod\xF4:RB:81,R\xF3ger Guedes:CF:76,Luis Henrique:RM:74",
  "Brazil|2023": "Vinicius Junior:LW:92,Rodrygo:RW:90,Bruno Guimar\xE3es:CM:89,Gabriel Jesus:ST:89,Gabriel Martinelli:LW:89,Antony:RW:88,\xC9der Milit\xE3o:CB:88,Lucas Paquet\xE1:CAM:88,Marquinhos:CB:88,Neymar:CAM:88,Douglas Luiz:CM:87,Gabriel:CB:87,Alisson:GK:86,Bremer:CB:86,Endrick:ST:86,Richarlison:ST:86,Ederson:GK:85,Joelinton:CM:85,Danilo:CM:83,Emerson Royal:RB:82,Caio Henrique:LB:81,Dod\xF4:RB:81,Renan Lodi:LB:81,Paulinho:CF:79,Yan Couto:RM:78,Diego Medeiros:LM:64",
  "Brazil|2024": "Vinicius Junior:LW:94,Rodrygo:RW:91,Bruno Guimar\xE3es:CM:89,Gabriel:CB:89,Gabriel Martinelli:LW:89,Douglas Luiz:CM:88,Gabriel Jesus:ST:88,Lucas Paquet\xE1:CAM:88,Bremer:CB:87,\xC9der Milit\xE3o:CB:87,Endrick:ST:87,Marquinhos:CB:87,\xC9derson:CM:86,Est\xEAv\xE3o:RW:86,Jo\xE3o Pedro:ST:86,Jo\xE3o Gomes:CM:85,Ederson:GK:84,Alisson:GK:83,Neymar:CAM:83,Carlos Augusto:LB:82,Dod\xF4:RB:82,Yan Couto:RM:82,Caio Henrique:LB:81,Vanderson:RB:81,Paulinho:CF:80,Diego Rigonato:LM:64",
  "Brazil|2025": "Vinicius Junior:LW:93,Raphinha:LW:90,Rodrygo:RW:90,Bruno Guimar\xE3es:CM:89,Est\xEAv\xE3o:RW:89,Gabriel:CB:89,Jo\xE3o Pedro:ST:88,Matheus Cunha:ST:88,Murillo:CB:87,Bremer:CB:86,\xC9derson:CM:86,Andrey Santos:CM:85,Douglas Luiz:CM:85,Evanilson:ST:85,Lucas Paquet\xE1:CAM:84,Marquinhos:CB:84,Wesley:RB:84,Carlos Augusto:LB:83,Dod\xF4:RB:82,Ederson:GK:82,Luis Henrique:RM:82,Alisson:GK:81,Evander:CAM:80,Mauro J\xFAnior:LB:80,Paulinho:CF:80,Paulo Azzi:LM:68",
  "Brazil|2026": "Vinicius Junior:LW:92,Bruno Guimar\xE3es:CM:89,Est\xEAv\xE3o:RW:89,Gabriel:CB:89,Jo\xE3o Pedro:ST:89,Raphinha:LW:89,Matheus Cunha:ST:88,Andrey Santos:CM:86,Igor Thiago:ST:86,Murillo:CB:86,Rodrygo:RW:86,\xC9derson:CM:85,Wesley:RB:85,Bremer:CB:84,Jo\xE3o Gomes:CM:84,Lucas Paquet\xE1:CAM:84,Carlos Augusto:LB:83,Marquinhos:CB:83,Luis Henrique:RM:82,Vanderson:RB:81,Alisson:GK:80,Evander:CAM:80,Mauro J\xFAnior:LB:80,Ederson:GK:79,Ruan:LM:68",
  "Bulgaria|2020": "Anton Nedyalkov:LB:72,Cicinho:RB:72,Kiril Despodov:RW:70,Marcelinho:CAM:70,Plamen Iliev:GK:70,Bozhidar Kraev:CAM:68,Georgi Kostadinov:CDM:68,Kristiyan Malinov:CDM:68,Vladislav Stoyanov:GK:68,Ahmed Osman:CF:64,Fabian N\xFCrnberger:LM:64,Ivan Goranov:LB:64,Nikola Gavov:RM:64,Nikolay Dimitrov:RW:64,Strahil Popov:RB:64",
  "Cameroon|2016": "Jo\xEBl Matip:CB:80,Alex Song:CDM:77,Clinton N'Jie:RW:77,Eric-Maxim Choupo-Moting:ST:77,Nicolas N'Koulou:CB:77,Paul-Georges Ntep:LW:77,Vincent Aboubakar:ST:77,Aur\xE9lien Chedjou:CB:76,Georges-Kevin N'Koudou:LW:76,St\xE9phane Mbia:CDM:75,Benjamin Moukandjo:ST:73,Carlos Kameni:GK:73,Allan Nyom:RB:72,Jean-Armel Kana-Biyik:CB:70,Charles Itandje:GK:68,Olivier Ntcham:CM:68,Ambroise Oyongo:LB:64,Collins Fai:RB:64,Edgar Salli:RW:64,Lionel Enguene:CAM:64,Marcel Ndjeng:RM:64,Yannick:LM:64",
  "Cameroon|2017": "Jo\xEBl Matip:CB:82,Vincent Aboubakar:ST:79,Paul-Georges Ntep:LW:77,Andr\xE9 Onana:GK:76,Clinton N'Jie:RW:76,Eric-Maxim Choupo-Moting:ST:76,Georges-Kevin N'Koudou:LW:76,Nicolas N'Koulou:CB:76,Benjamin Moukandjo:ST:74,Allan Nyom:RB:73,St\xE9phane Mbia:CDM:73,Aur\xE9lien Chedjou:CB:72,Carlos Kameni:GK:72,Christian Bassogog:RW:72,Alex Song:CDM:70,Michael Ngadeu:CB:70,Frank Anguissa:CM:68,Ga\xEBtan Bong:LB:68,Olivier Ntcham:CM:68,Beno\xEEt Assou-Ekotto:LB:64,Collins Fai:RB:64,Marcel Ndjeng:RM:64",
  "Cameroon|2018": "Andr\xE9 Onana:GK:83,Frank Anguissa:CM:82,Jo\xEBl Matip:CB:82,Karl Toko Ekambi:ST:80,Vincent Aboubakar:ST:80,Clinton N'Jie:RW:79,Nicolas N'Koulou:CB:79,Eric-Maxim Choupo-Moting:ST:76,Georges-Kevin N'Koudou:LW:76,Allan Nyom:RB:73,James L\xE9a Siliki:CM:73,Christian Bassogog:RW:72,Michael Ngadeu:CB:72,F\xE9lix Eboa Eboa:CB:70,Olivier Ntcham:CM:70,St\xE9phane Mbia:CDM:70,Alex Song:CDM:68,Collins Fai:RB:68,Ga\xEBtan Bong:LB:68,Beno\xEEt Assou-Ekotto:LB:64,Didier Lamkel Z\xE9:LW:64,Fabrice Ondoa:GK:64",
  "Cameroon|2019": "Andr\xE9 Onana:GK:86,Jo\xEBl Matip:CB:85,Frank Anguissa:CM:82,Nicolas N'Koulou:CB:81,Karl Toko Ekambi:ST:80,Vincent Aboubakar:ST:80,Pierre Kunde:CM:77,St\xE9phane Bahoken:ST:76,Nicolas Moumi Ngamaleu:LW:74,Bryan Mbeumo:RW:73,Didier Lamkel Z\xE9:LW:73,F\xE9lix Eboa Eboa:CB:73,J\xE9r\xF4me Ongu\xE9n\xE9:CB:73,Olivier Ntcham:CM:73,Allan Nyom:RB:72,Ambroise Oyongo:LB:72,Christian Bassogog:RW:72,James L\xE9a Siliki:CM:72,Collins Fai:RB:68,Frank Boya:CDM:68,Jeando Fuchs:CDM:68,Junior Dina Ebimbe:RM:64",
  "Cameroon|2020": "Andr\xE9 Onana:GK:84,Jo\xEBl Matip:CB:84,Frank Anguissa:CM:81,Karl Toko Ekambi:ST:79,Bryan Mbeumo:RW:78,Ignatius Ganago:ST:76,Jean-Pierre Nsame:ST:76,Pierre Kunde:CM:76,James L\xE9a Siliki:CM:74,Michael Ngadeu:CB:74,Nicolas Moumi Ngamaleu:LW:74,Georges-Kevin N'Koudou:LW:73,J\xE9r\xF4me Ongu\xE9n\xE9:CB:73,Olivier Ntcham:CM:73,Allan Nyom:RB:72,Christian Bassogog:RW:72,Harold Moukoudi:CB:72,Ambroise Oyongo:LB:70,Collins Fai:RB:68,Frank Boya:CDM:68,Ga\xEBl Ondoua:CDM:68,Nouhou:LB:68,Felix Kekoh:RM:64",
  "Cameroon|2021": "Andr\xE9 Onana:GK:83,Frank Anguissa:CM:83,Jo\xEBl Matip:CB:82,Bryan Mbeumo:RW:80,Karl Toko Ekambi:ST:79,Vincent Aboubakar:ST:77,Ignatius Ganago:ST:76,James L\xE9a Siliki:CM:75,Georges-Kevin N'Koudou:LW:74,Junior Dina Ebimbe:RM:74,Didier Lamkel Z\xE9:LW:73,Harold Moukoudi:CB:73,Nicolas N'Koulou:CB:73,Pierre Kunde:CM:73,Yvan Neyou:CDM:73,Christian Bassogog:RW:72,Gerzino Nyamsi:CB:72,Olivier Ntcham:CM:72,Allan Nyom:RB:70,Ga\xEBl Ondoua:CDM:70,Nouhou:LB:70,Ambroise Oyongo:LB:68,Olivier Mbaizo:RB:68",
  "Cameroon|2022": "Frank Anguissa:CM:85,Bryan Mbeumo:RW:83,Jo\xEBl Matip:CB:80,Andr\xE9 Onana:GK:79,Karl Toko Ekambi:ST:79,Vincent Aboubakar:ST:77,Gerzino Nyamsi:CB:76,Jean-Pierre Nsame:ST:76,Junior Dina Ebimbe:RM:76,Nathan Ngoumou:RW:76,Christopher Wooh:CB:74,Georges-Kevin N'Koudou:LW:74,Enzo Ebosse:CB:73,Jean Onana:CDM:73,Nicolas Moumi Ngamaleu:LW:73,Martin Hongla:CDM:72,Enzo Tchato:RB:70,Jackson Tchatchoua:RB:70,James L\xE9a Siliki:CM:70,Nouhou:LB:70,Olivier Ntcham:CM:70,Ambroise Oyongo:LB:68",
  "Cameroon|2023": "Andr\xE9 Onana:GK:85,Bryan Mbeumo:RW:85,Frank Anguissa:CM:85,Junior Dina Ebimbe:RM:79,Jo\xEBl Matip:CB:78,Karl Toko Ekambi:ST:77,Faris Moumbagna:ST:76,Vincent Aboubakar:ST:76,Christopher Wooh:CB:74,Georges-Kevin N'Koudou:LW:73,Gerzino Nyamsi:CB:73,Nouhou:LB:73,Enzo Ebosse:CB:72,Nicolas Moumi Ngamaleu:LW:72,Enzo Tchato:RB:70,Jackson Tchatchoua:RB:70,Olivier Kemen:CM:70,Olivier Ntcham:CM:70,Darlin Yongwa:LB:68",
  "Cameroon|2026": "Bryan Mbeumo:RW:89,Christian Kofane:ST:85,Enzo Boyomo:CB:81,Frank Anguissa:CM:81,Karl Etta Eyong:ST:80,Arthur Avom:CM:79,Andr\xE9 Onana:GK:78,Jackson Tchatchoua:RB:78,Darlin Yongwa:LB:74,Junior Dina Ebimbe:RM:74,Mahamadou Nagida:LB:74,Christopher Wooh:CB:73,Danny Namaso:LW:73,Harold Moukoudi:CB:73,Malcom Bokele:CB:73,Faris Moumbagna:ST:72,Nathan Ngoumou:RW:72,Georges-Kevin N'Koudou:LW:70,Olivier Ntcham:CM:70,Enzo Tchato:RB:68,Simon Ngapandouetnbu:GK:68",
  "Canada|2021": "Alphonso Davies:LB:89,Jonathan David:ST:86,Cyle Larin:ST:78,Tajon Buchanan:RW:76,Jonathan Osorio:CM:74,Mark-Anthony Kaye:CM:74,Lucas Cavallini:ST:73,Stephen Eustaquio:CM:73,Richie Laryea:RB:72,Alistair Johnston:RB:70,Samuel Piette:CDM:70,Jacob Shaffelburg:LW:68,Junior Hoilett:LW:68,Liam Fraser:CDM:68,Maxime Cr\xE9peau:GK:68,Milan Borjan:GK:68,Billy Ofori Bitihene:CF:64,Cristi\xE1n Guti\xE9rrez:LB:64,Fraser Aird:RM:64",
  "Canada|2022": "Alphonso Davies:LB:88,Jonathan David:ST:86,Cyle Larin:ST:78,Tajon Buchanan:RW:78,Stephen Eustaquio:CM:76,Alistair Johnston:RB:74,Isma\xEBl Kon\xE9:CM:74,Ik\xE9 Ugbo:ST:73,Jayden Nelson:LW:72,Jonathan Osorio:CM:72,Kamal Miller:CB:72,Mark-Anthony Kaye:CM:72,Jahkeele Marshall-Rutty:RB:70,Liam Millar:LW:70,Maxime Cr\xE9peau:GK:70,Samuel Piette:CDM:70,Dayne St. Clair:GK:68,Liam Fraser:CDM:68,Sam Adekugbe:LB:68,Theo Corbeanu:RW:68,Billy Ofori Bitihene:CF:64,Fraser Aird:RM:64",
  "Canada|2023": "Alphonso Davies:LB:88,Jonathan David:ST:87,Stephen Eustaquio:CM:79,Isma\xEBl Kon\xE9:CM:78,Alistair Johnston:RB:76,Cyle Larin:ST:76,Kamal Miller:CB:73,Alfie Jones:CB:72,Jacob Shaffelburg:LW:72,Jayden Nelson:LW:72,Ayo Akinola:ST:70,Jahkeele Marshall-Rutty:RB:70,Jonathan Osorio:CM:70,Mathieu Choini\xE8re:CM:70,Maxime Cr\xE9peau:GK:70,Sam Adekugbe:LB:70,Dayne St. Clair:GK:68,Theo Corbeanu:RW:68,Billy Ofori Bitihene:CF:64,Bruno Zebie:LM:64,Marcus Godinho:RM:64",
  "Canada|2024": "Alphonso Davies:LB:87,Jonathan David:ST:86,Stephen Eustaquio:CM:79,Isma\xEBl Kon\xE9:CM:78,Alistair Johnston:RB:77,Mo\xEFse Bombito:CB:76,Tajon Buchanan:RW:76,Jacob Shaffelburg:LW:73,Alfie Jones:CB:72,Cyle Larin:ST:72,Derek Cornelius:CB:72,Liam Millar:LW:72,Mathieu Choini\xE8re:CM:72,Maxime Cr\xE9peau:GK:72,Dayne St. Clair:GK:68,Jahkeele Marshall-Rutty:RB:68,Theo Corbeanu:RW:68,Ryan Raposo:LM:67,Billy Ofori Bitihene:CF:64,Fraser Aird:RM:64",
  "Canada|2025": "Alphonso Davies:LB:86,Jonathan David:ST:86,Isma\xEBl Kon\xE9:CM:79,Promise David:ST:79,Alistair Johnston:RB:77,Mo\xEFse Bombito:CB:77,Stephen Eustaquio:CM:77,Tajon Buchanan:RW:77,Tani Oluwaseyi:ST:76,Derek Cornelius:CB:73,Nathan-Dylan Saliba:CM:73,Ali Ahmed:LM:72,Dayne St. Clair:GK:72,Jacob Shaffelburg:LW:72,Jayden Nelson:LW:70,Maxime Cr\xE9peau:GK:70,Jahkeele Marshall-Rutty:RB:68,Theo Corbeanu:RW:68,Billy Ofori Bitihene:CF:64,Fraser Aird:RM:64",
  "Canada|2026": "Alphonso Davies:LB:86,Jonathan David:ST:84,Isma\xEBl Kon\xE9:CM:81,Promise David:ST:80,Tajon Buchanan:RW:78,Alistair Johnston:RB:76,Mo\xEFse Bombito:CB:76,Stephen Eustaquio:CM:76,Tani Oluwaseyi:ST:76,Alfie Jones:CB:74,Nathan-Dylan Saliba:CM:74,Marcelo Flores:LW:73,Ali Ahmed:LM:72,Dayne St. Clair:GK:72,Jacob Shaffelburg:LW:70,Jahkeele Marshall-Rutty:RB:68,Maxime Cr\xE9peau:GK:68,Theo Corbeanu:RW:68,Gabriel Antinoro:RM:64",
  "Chile|2016": "Alexis S\xE1nchez:CF:87,Arturo Vidal:CM:85,Claudio Bravo:GK:79,Gary Medel:CB:79,Charles Ar\xE1nguiz:CM:78,Mat\xEDas Fern\xE1ndez:CAM:76,Eduardo Vargas:ST:74,Mauricio Isla:RB:74,Pablo Hern\xE1ndez:CM:74,\xC1ngelo Henr\xEDquez:ST:73,Jorge Valdivia:CAM:73,Felipe Guti\xE9rrez:CM:72,Junior Fernandes:ST:72,Eugenio Mena:LB:70,Manuel Iturra:CDM:70,Marcelo D\xEDaz:CDM:70,Boris Rieloff:RB:64,Cristopher Toselli:GK:64,Fernando Cordero:LB:64,Fernando Meneses:RM:64,Mark Gonz\xE1lez:LW:64,Sebasti\xE1n Ubilla:RW:64",
  "Chile|2017": "Alexis S\xE1nchez:CF:88,Arturo Vidal:CM:85,Gary Medel:CB:79,Claudio Bravo:GK:78,Charles Ar\xE1nguiz:CM:77,Eduardo Vargas:ST:74,Mat\xEDas Fern\xE1ndez:CAM:74,Pablo Hern\xE1ndez:CM:74,Erick Pulgar:CDM:73,Fabi\xE1n Orellana:RW:72,Fernando Zampedri:ST:72,Mauricio Isla:RB:72,Nicol\xE1s Castillo:ST:72,Edson Puch:LW:70,Felipe Guti\xE9rrez:CM:70,Paulo D\xEDaz:CB:70,\xC1ngelo Sagal:LW:68,Bryan Rabello:CAM:68,Carlos Carmona:CDM:68,Eugenio Mena:LB:68,Fernando Meneses:RM:64,Jean Beausejour:LB:64,Nicol\xE1s Maturana:RW:64,Stefano Magnasco:RB:64",
  "Chile|2018": "Alexis S\xE1nchez:CF:88,Arturo Vidal:CM:84,Charles Ar\xE1nguiz:CM:79,Erick Pulgar:CDM:74,Nicol\xE1s Castillo:ST:74,Ben Brereton D\xEDaz:ST:73,Claudio Bravo:GK:73,Gary Medel:CB:73,Pablo Hern\xE1ndez:CM:73,Leonardo Gil:CM:72,Mauricio Isla:RB:72,Diego Vald\xE9s:CAM:70,Edson Puch:LW:70,Fabi\xE1n Orellana:RW:70,Felipe Mora:ST:70,Guillermo Marip\xE1n:CB:70,Mart\xEDn Rodr\xEDguez:CAM:70,Miiko Albornoz:LB:70,\xC1ngelo Sagal:LW:68,Claudio Baeza:CDM:68,Juan Cornejo:LB:68,Boris Rieloff:RB:64,Fernando Meneses:RM:64,Mat\xEDas Sep\xFAlveda:LM:64",
  "Chile|2019": "Alexis S\xE1nchez:CF:84,Arturo Vidal:CM:80,Charles Ar\xE1nguiz:CM:79,Erick Pulgar:CDM:79,Guillermo Marip\xE1n:CB:79,Paulo D\xEDaz:CB:76,Nicol\xE1s Castillo:ST:74,Diego Vald\xE9s:CAM:73,Eduardo Vargas:ST:73,V\xEDctor D\xE1vila:ST:73,Leonardo Gil:CM:72,Claudio Baeza:CDM:70,Fabi\xE1n Orellana:RW:70,Gabriel Arias:GK:70,Jean Meneses:LW:70,Mart\xEDn Rodr\xEDguez:CAM:70,\xC1ngelo Sagal:LW:68,Bryan Carrasco:RW:68,Eugenio Mena:LB:68,Juan Cornejo:LB:68,Mauricio Isla:RB:68,\xD3scar Opazo:RB:68,Fernando Meneses:RM:64,Mat\xEDas Sep\xFAlveda:LM:64",
  "Chile|2020": "Alexis S\xE1nchez:CF:81,Erick Pulgar:CDM:79,Arturo Vidal:CM:78,Charles Ar\xE1nguiz:CM:78,Nicol\xE1s Castillo:ST:74,Sebasti\xE1n Vegas:CB:74,Diego Vald\xE9s:CAM:73,Jean Meneses:LW:73,Paulo D\xEDaz:CB:73,V\xEDctor D\xE1vila:ST:73,Ben Brereton D\xEDaz:ST:72,Claudio Baeza:CDM:70,Gabriel Arias:GK:70,Leonardo Gil:CM:70,Luis Felipe Gallegos:CM:70,\xC1ngelo Sagal:LW:68,C\xE9sar Pinares:CAM:68,Fabi\xE1n Orellana:RW:68,Juan Delgado:RW:68,Yonathan And\xEDa:RB:68,Eugenio Mena:LB:64,Fernando Meneses:RM:64,Gabriel Suazo:LB:64,Mat\xEDas Sep\xFAlveda:LM:64,Mauricio Isla:RB:64",
  "Chile|2021": "Guillermo Marip\xE1n:CB:79,Ben Brereton D\xEDaz:ST:77,Charles Ar\xE1nguiz:CM:77,Erick Pulgar:CDM:77,Alexis S\xE1nchez:CF:76,Paulo D\xEDaz:CB:76,Arturo Vidal:CM:74,Diego Vald\xE9s:CAM:74,Sebasti\xE1n Vegas:CB:74,Gabriel Arias:GK:73,Jean Meneses:LW:73,V\xEDctor D\xE1vila:ST:73,\xC1ngelo Araos:CAM:72,Claudio Baeza:CDM:72,Felipe Mora:ST:72,Pablo Galdames:CM:70,\xC1ngelo Sagal:LW:68,Brayan Cort\xE9s:GK:68,Eugenio Mena:LB:68,Fabi\xE1n Orellana:RW:68,Joaqu\xEDn Montecinos:RW:68,Leonardo Gil:CM:68,Yonathan And\xEDa:RB:68,Alfonso Parot:LB:64,Raimundo Rebolledo:RB:64",
  "Chile|2022": "Ben Brereton D\xEDaz:ST:80,Guillermo Marip\xE1n:CB:79,Erick Pulgar:CDM:76,Paulo D\xEDaz:CB:76,Claudio Baeza:CDM:74,Diego Vald\xE9s:CAM:74,Marcelino N\xFA\xF1ez:CM:74,Sebasti\xE1n Vegas:CB:74,Alexis S\xE1nchez:CF:73,Jean Meneses:LW:73,V\xEDctor D\xE1vila:ST:73,Charles Ar\xE1nguiz:CM:72,Diego Rubio:ST:72,Igor Lichnovsky:CB:72,Brayan Cort\xE9s:GK:70,Dar\xEDo Osorio:RW:70,Gabriel Arias:GK:70,Pablo Galdames:CM:70,\xC1ngelo Araos:CAM:68,\xC1ngelo Sagal:LW:68,Eugenio Mena:LB:68,Gabriel Suazo:LB:68,Joaqu\xEDn Montecinos:RW:68",
  "Chile|2023": "Ben Brereton D\xEDaz:ST:80,Guillermo Marip\xE1n:CB:77,Diego Vald\xE9s:CAM:76,V\xEDctor D\xE1vila:ST:74,Dami\xE1n Pizarro:ST:73,Jean Meneses:LW:73,Paulo D\xEDaz:CB:73,Alexis S\xE1nchez:CF:72,Igor Lichnovsky:CB:72,Lucas Assadi:CAM:72,Sebasti\xE1n Vegas:CB:72,Brayan Cort\xE9s:GK:70,Charles Ar\xE1nguiz:CM:70,Gabriel Arias:GK:70,Gabriel Suazo:LB:70,Guillermo Soto:RB:68,Joaqu\xEDn Montecinos:RW:68,Thomas Galdames:LB:68,Mat\xEDas Sep\xFAlveda:LM:64",
  "Chile|2024": "Guillermo Marip\xE1n:CB:77,Ben Brereton D\xEDaz:ST:76,Dar\xEDo Osorio:RW:76,Dami\xE1n Pizarro:ST:75,Diego Vald\xE9s:CAM:75,Williams Alarc\xF3n:CM:75,Alexander Aravena:LW:74,Paulo D\xEDaz:CB:74,V\xEDctor D\xE1vila:ST:74,Marcelino N\xFA\xF1ez:CM:73,Lucas Assadi:CAM:72,Sebasti\xE1n Vegas:CB:72,Alexis S\xE1nchez:CF:70,Brayan Cort\xE9s:GK:70,Felipe Loyola:CM:70,Jean Meneses:LW:70,Thomas Galdames:LB:70,Ariel Uribe:RW:68,Fabi\xE1n Hormaz\xE1bal:RB:68,Marcelo Morales:LB:68,Thomas Gillier:GK:68,Mat\xEDas Sep\xFAlveda:LM:64",
  "Chile|2025": "Dar\xEDo Osorio:RW:77,Felipe Loyola:CM:77,Marcelino N\xFA\xF1ez:CM:77,Ben Brereton D\xEDaz:ST:76,Gabriel Suazo:LB:76,Williams Alarc\xF3n:CM:74,Paulo D\xEDaz:CB:73,V\xEDctor D\xE1vila:ST:73,Carlos Palacios:CAM:72,Dami\xE1n Pizarro:ST:72,Diego Vald\xE9s:CAM:72,Lucas Cepeda:LW:72,Brayan Cort\xE9s:GK:70,C\xE9sar P\xE9rez:CM:70,Fabi\xE1n Hormaz\xE1bal:RB:70,Alexis S\xE1nchez:CF:68,Ariel Uribe:RW:68,Jean Meneses:LW:68,Marcelo Morales:LB:68,Thomas Gillier:GK:68,Mat\xEDas Sep\xFAlveda:LM:64",
  "Chile|2026": "Dar\xEDo Osorio:RW:77,Marcelino N\xFA\xF1ez:CM:77,Felipe Loyola:CM:76,Gabriel Suazo:LB:76,Ben Brereton D\xEDaz:ST:74,V\xEDctor D\xE1vila:ST:73,Carlos Palacios:CAM:72,Gonzalo Tapia:ST:72,Lucas Cepeda:LW:72,Williams Alarc\xF3n:CM:72,C\xE9sar P\xE9rez:CM:70,Diego Vald\xE9s:CAM:70,Fabi\xE1n Hormaz\xE1bal:RB:70,Brayan Cort\xE9s:GK:68,Francisco Salinas:RB:68,Marcelo Morales:LB:68,Thomas Gillier:GK:68,Mat\xEDas Sep\xFAlveda:LM:64",
  "Colombia|2016": "James Rodr\xEDguez:CAM:89,Carlos Bacca:ST:82,Juan Cuadrado:RM:82,Radamel Falcao:ST:82,Jackson Mart\xEDnez:ST:80,Jeison Murillo:CB:80,Fredy Guar\xEDn:CM:77,Jos\xE9 Izquierdo:LW:77,David Ospina:GK:76,Juan Fernando Quintero:CAM:76,V\xEDctor Ibarbo:CF:76,Davinson S\xE1nchez:CB:74,Santiago Arias:RB:74,Carlos S\xE1nchez:CDM:73,Dorlan Pab\xF3n:RW:73,Yerry Mina:CB:73,\xC9der Balanta:CDM:72,Mauricio Cuero:RW:72,Avil\xE9s Hurtado:LW:70,Bernardo Espinosa:CB:70,Camilo Z\xFA\xF1iga:LM:70,Stefan Medina:RB:70,Frank Fabra:LB:68,Johan Mojica:LB:68,Camilo Vargas:GK:64",
  "Colombia|2017": "James Rodr\xEDguez:CAM:86,Juan Cuadrado:RM:83,Carlos Bacca:ST:82,Davinson S\xE1nchez:CB:82,Luis Muriel:ST:81,Duv\xE1n Zapata:ST:79,Jeison Murillo:CB:79,Jos\xE9 Izquierdo:LW:79,Yerry Mina:CB:77,David Ospina:GK:76,Santiago Arias:RB:76,Fredy Guar\xEDn:CM:75,Giovanni Moreno:CAM:74,Bernardo Espinosa:CB:73,Dorlan Pab\xF3n:RW:73,Felipe Pardo:RW:73,Frank Fabra:LB:73,Wilmar Barrios:CDM:73,Andr\xE9s Ibarg\xFCen:LW:72,Carlos S\xE1nchez:CDM:70,V\xEDctor Ibarbo:CF:70,Andr\xE9s Tello:CM:68,Camilo Z\xFA\xF1iga:LM:68,Juan Daniel Roa:CM:68,Luis Orejuela:RB:68,Brayan Angulo:LB:64,Camilo Vargas:GK:64",
  "Colombia|2018": "James Rodr\xEDguez:CAM:89,Davinson S\xE1nchez:CB:85,Juan Cuadrado:RM:83,Yerry Mina:CB:83,Duv\xE1n Zapata:ST:82,Jefferson Lerma:CDM:82,Santiago Arias:RB:81,Jeison Murillo:CB:79,Jos\xE9 Izquierdo:LW:79,Luis Muriel:ST:79,Radamel Falcao:ST:79,Wilmar Barrios:CDM:78,Juan Fernando Quintero:CAM:77,Bernardo Espinosa:CB:76,Frank Fabra:LB:74,David Ospina:GK:73,Dorlan Pab\xF3n:RW:73,Fredy Guar\xEDn:CM:73,Johan Mojica:LB:73,Avil\xE9s Hurtado:LW:72,Felipe Pardo:RW:72,Iv\xE1n Arboleda:GK:72,Stefan Medina:RB:72,Baldomero Perlaza:CM:68,V\xEDctor Ibarbo:CF:68,Yairo Moreno:LM:68",
  "Colombia|2019": "Davinson S\xE1nchez:CB:87,Duv\xE1n Zapata:ST:86,James Rodr\xEDguez:CAM:86,Jefferson Lerma:CDM:82,Yerry Mina:CB:82,Luis Muriel:ST:81,Wilmar Barrios:CDM:81,Juan Cuadrado:RM:80,Santiago Arias:RB:80,Juan Fernando Quintero:CAM:79,Rafael Borr\xE9:ST:79,Luis D\xEDaz:LW:78,Jeison Murillo:CB:77,Jos\xE9 Izquierdo:LW:77,Jhon Lucum\xED:CB:76,Luis Qui\xF1\xF3nes:RW:73,Cristi\xE1n Borja:LB:72,Danilo Asprilla:RW:72,David Ospina:GK:72,Frank Fabra:LB:72,Stefan Medina:RB:72,Eduard Atuesta:CM:70,Steven Alzate:CM:70,\xC1lvaro Montero:GK:68,Andr\xE9s Ricaurte:CM:68,V\xEDctor Ibarbo:CF:68,Cristian Echavarria:LM:64",
  "Colombia|2020": "Davinson S\xE1nchez:CB:86,Duv\xE1n Zapata:ST:85,James Rodr\xEDguez:CAM:84,Luis Muriel:ST:82,Jefferson Lerma:CDM:81,Yerry Mina:CB:81,Jhon C\xF3rdoba:ST:80,Juan Cuadrado:RM:80,Wilmar Barrios:CDM:80,Luis D\xEDaz:LW:79,Luis Sinisterra:LW:78,Santiago Arias:RB:78,Juan Fernando Quintero:CAM:76,Steven Alzate:CM:76,Yairo Moreno:LM:76,Bernardo Espinosa:CB:73,Danilo Asprilla:RW:73,David Ospina:GK:73,Luis Qui\xF1\xF3nes:RW:73,Carlos Cuesta:CB:72,Cristi\xE1n Borja:LB:72,Daniel Mu\xF1oz:RB:72,Eduard Atuesta:CM:72,\xC1lvaro Montero:GK:70,Andr\xE9s Ricaurte:CM:70,Frank Fabra:LB:70,Isaac Arias:CF:64",
  "Colombia|2021": "Luis D\xEDaz:LW:85,Davinson S\xE1nchez:CB:84,Duv\xE1n Zapata:ST:84,James Rodr\xEDguez:CAM:83,Luis Muriel:ST:83,Wilmar Barrios:CDM:81,Yerry Mina:CB:81,Jhon C\xF3rdoba:ST:80,Juan Cuadrado:RM:80,Matheus Uribe:CDM:80,Jhon Lucum\xED:CB:79,Luis Sinisterra:LW:78,Daniel Mu\xF1oz:RB:77,Carlos Cuesta:CB:76,Jorge Carrascal:CAM:76,Santiago Arias:RB:76,Steven Alzate:CM:76,Diego Valoyes:RW:74,Eduard Atuesta:CM:74,David Ospina:GK:73,Luis Qui\xF1\xF3nes:RW:72,Cristi\xE1n Borja:LB:70,Iv\xE1n Arboleda:GK:70,\xC1lvaro Angulo:LB:68,V\xEDctor Ibarbo:CF:64",
  "Colombia|2022": "Luis D\xEDaz:LW:89,Davinson S\xE1nchez:CB:83,Duv\xE1n Zapata:ST:83,Luis Sinisterra:LW:82,Luis Muriel:ST:81,Rafael Borr\xE9:ST:81,Wilmar Barrios:CDM:81,Yerry Mina:CB:81,Matheus Uribe:CDM:80,James Rodr\xEDguez:CAM:79,Jhon Lucum\xED:CB:78,Jorge Carrascal:CAM:77,Carlos Cuesta:CB:76,Daniel Mu\xF1oz:RB:76,Jhon Arias:RW:76,Juan Cuadrado:RM:76,Diego Valoyes:RW:74,Eduard Atuesta:CM:74,Johan Mojica:LB:73,Steven Alzate:CM:73,Santiago Arias:RB:72,\xC1lvaro Montero:GK:70,Camilo Vargas:GK:70,Cristi\xE1n Borja:LB:70,Sebasti\xE1n G\xF3mez:CM:68,Esteban \xC1ngel:CF:64",
  "Colombia|2023": "Luis D\xEDaz:LW:89,Davinson S\xE1nchez:CB:81,Jhon Dur\xE1n:ST:80,Cucho Hern\xE1ndez:ST:79,Jhon C\xF3rdoba:ST:78,Jhon Lucum\xED:CB:78,Yerry Mina:CB:78,Daniel Mu\xF1oz:RB:77,Jhon Arias:RW:77,Carlos Cuesta:CB:76,J\xE1minton Campaz:LW:76,Jorge Carrascal:CAM:76,Yairo Moreno:LM:76,Diego Valoyes:RW:74,Steven Alzate:CM:73,Deiver Machado:LB:72,Juan Cuadrado:RM:72,Kevin Agudelo:CAM:72,Kevin Mier:GK:72,\xC1lvaro Montero:GK:70,Eduard Atuesta:CM:70,Jhon Sol\xEDs:CM:70,Johan Mojica:LB:70,Santiago Arias:RB:70,Jefferson Palacios:CF:64",
  "Colombia|2024": "Luis D\xEDaz:LW:89,Jhon Dur\xE1n:ST:85,Daniel Mu\xF1oz:RB:82,Davinson S\xE1nchez:CB:81,Cucho Hern\xE1ndez:ST:80,Jhon Arias:RW:80,Jhon Lucum\xED:CB:80,Luis Sinisterra:LW:80,Y\xE1ser Asprilla:RW:80,Jhon C\xF3rdoba:ST:79,Juan Cabal:LB:77,Jorge Carrascal:CAM:76,Kevin Mier:GK:76,Yerson Mosquera:CB:76,Yairo Moreno:LM:75,Carlos Cuesta:CB:74,Miguel Monsalve:CAM:74,Nelson Deossa:CM:73,Deiver Machado:LB:72,Devis V\xE1squez:GK:72,Gustavo Puerta:CM:72,Jhon Sol\xEDs:CM:72,Juan Portilla:CM:72,Juan Mosquera:RB:70,Juan Cuadrado:RM:68,V\xEDctor Ibarbo:CF:64",
  "Colombia|2025": "Luis D\xEDaz:LW:88,Jhon Dur\xE1n:ST:84,Daniel Mu\xF1oz:RB:83,Jhon Lucum\xED:CB:82,Luis Su\xE1rez:ST:82,Davinson S\xE1nchez:CB:81,Cucho Hern\xE1ndez:ST:80,Jhon Arias:RW:80,Luis Sinisterra:LW:79,Y\xE1ser Asprilla:RW:79,Jorge Carrascal:CAM:77,Juan Cabal:LB:77,Nelson Deossa:CM:77,Yerson Mosquera:CB:77,Carlos Cuesta:CB:76,Kevin Mier:GK:76,Yairo Moreno:LM:73,Eduard Atuesta:CM:72,Gustavo Puerta:CM:72,Johan Rojas:CAM:72,Juan Portilla:CM:72,\xC1lvaro Angulo:LB:70,\xC9dier Ocampo:RB:70,\xC1lvaro Montero:GK:68,Andr\xE9s Ferr\xEDn:RM:64,Camilo S\xE1nchez:CF:64",
  "Colombia|2026": "Luis D\xEDaz:LW:88,Daniel Mu\xF1oz:RB:83,Luis Su\xE1rez:ST:83,Jhon Dur\xE1n:ST:82,Jhon Lucum\xED:CB:82,Cucho Hern\xE1ndez:ST:80,Davinson S\xE1nchez:CB:80,Jhon Arias:RW:79,Y\xE1ser Asprilla:RW:79,Jorge Carrascal:CAM:78,Luis Sinisterra:LW:78,Juan Cabal:LB:77,Nelson Deossa:CM:77,Carlos Cuesta:CB:76,Kevin Mier:GK:75,Jhohan Roma\xF1a:CB:74,Gustavo Puerta:CM:73,Eduard Atuesta:CM:72,Johan Rojas:CAM:72,Juan Portilla:CM:72,\xC1lvaro Angulo:LB:70,\xC1lvaro Montero:GK:70,\xC9dier Ocampo:RB:70,Juan Arizala:LM:70,Juan Cuadrado:RM:64",
  "Cote d'Ivoire|2016": "Eric Bailly:CB:82,Wilfried Bony:ST:82,Yaya Tour\xE9:CM:81,Gervinho:LW:79,Serge Aurier:RB:79,Seydou Doumbia:ST:78,Jonathan Kodjia:ST:77,Max Gradel:LW:77,Franck Kessi\xE9:CM:76,Jean Micha\xEBl Seri:CDM:76,Cheik Tiot\xE9:CDM:74,Lamine Kon\xE9:CB:74,Jean-Philippe Gbamin:CB:73,Alban Lafont:GK:72,Jean-Daniel Akpa Akpro:CM:72,Seko Fofana:CM:72,Willy Boly:CB:72,Arthur Boka:LB:68,Eloge Yao:RB:68,Abdoulaye Diarra:LM:64,Anthony Moura-Komenan:CF:64,Brahima Tour\xE9:RM:64,Constant Djakpa:LB:64,Franck Dja Dj\xE9dj\xE9:RW:64,Ibrahim Sissoko:CAM:64,Tiemoko Konat\xE9:RW:64",
  "Cote d'Ivoire|2017": "Eric Bailly:CB:83,Jean Micha\xEBl Seri:CDM:82,Franck Kessi\xE9:CM:81,Wilfried Bony:ST:80,Wilfried Zaha:LW:80,Serge Aurier:RB:79,S\xE9bastien Haller:ST:78,Jonathan Kodjia:ST:77,Maxwel Cornet:LW:77,Seko Fofana:CM:77,Yaya Tour\xE9:CM:77,Alban Lafont:GK:76,Jean-Philippe Gbamin:CB:76,Lamine Kon\xE9:CB:76,Nicolas P\xE9p\xE9:RW:74,Willy Boly:CB:72,Brice Dja Dj\xE9dj\xE9:CDM:70,Eloge Yao:RB:68,Ghislain Konan:LB:68,Jean-Daniel Akpa Akpro:CM:68,Abdoulaye Diarra:LM:64,Ange Dezai:CF:64,Franck Dja Dj\xE9dj\xE9:RW:64",
  "Cote d'Ivoire|2018": "Nicolas P\xE9p\xE9:RW:85,Eric Bailly:CB:84,Franck Kessi\xE9:CM:84,Jean Micha\xEBl Seri:CDM:84,S\xE9bastien Haller:ST:84,Wilfried Zaha:LW:84,Jean-Philippe Gbamin:CB:83,Serge Aurier:RB:81,Alban Lafont:GK:80,Maxwel Cornet:LW:80,Christian Kouam\xE9:ST:79,Evan Ndicka:CB:79,Seko Fofana:CM:79,Wilfried Bony:ST:78,Ibrahim Sangar\xE9:CDM:77,Willy Boly:CB:77,Ghislain Konan:LB:73,Yaya Tour\xE9:CM:73,Eloge Yao:RB:68,Ange Dezai:CF:64",
  "Cote d'Ivoire|2019": "Nicolas P\xE9p\xE9:RW:89,Wilfried Zaha:LW:87,S\xE9bastien Haller:ST:86,Franck Kessi\xE9:CM:84,Jean-Philippe Gbamin:CB:83,Christian Kouam\xE9:ST:82,Eric Bailly:CB:82,Evan Ndicka:CB:82,Jean Micha\xEBl Seri:CDM:82,Jonathan Bamba:LW:81,Alban Lafont:GK:80,Ibrahim Sangar\xE9:CDM:79,Seko Fofana:CM:79,Willy Boly:CB:79,Jonathan Kodjia:ST:77,Ghislain Konan:LB:76,Hassane Kamara:LB:72,Victorien Angban:CM:72,Cheick Timite:RW:68,Eric Tia:LM:64",
  "Cote d'Ivoire|2020": "Nicolas P\xE9p\xE9:RW:86,Wilfried Zaha:LW:86,Franck Kessi\xE9:CM:85,S\xE9bastien Haller:ST:84,Evan Ndicka:CB:82,Jean-Philippe Gbamin:CB:82,J\xE9r\xE9mie Boga:LW:82,Serge Aurier:RB:81,Christian Kouam\xE9:ST:80,Eric Bailly:CB:80,Willy Boly:CB:80,Alban Lafont:GK:79,Amad Diallo:RW:79,Ibrahim Sangar\xE9:CDM:78,Jean Micha\xEBl Seri:CDM:78,Seko Fofana:CM:77,Hassane Kamara:LB:76,Roger Assal\xE9:ST:76,Ghislain Konan:LB:74,Jean-Daniel Akpa Akpro:CM:72,Mohamed Diomand\xE9:CM:70,Cedric Kouadio:CF:64,Eric Tia:LM:64",
  "Cote d'Ivoire|2021": "Franck Kessi\xE9:CM:87,Wilfried Zaha:LW:86,Nicolas P\xE9p\xE9:RW:85,Evan Ndicka:CB:83,S\xE9bastien Haller:ST:83,J\xE9r\xE9mie Boga:LW:82,Odilon Kossounou:CB:82,Serge Aurier:RB:81,Amad Diallo:RW:80,Jean-Philippe Gbamin:CB:80,Seko Fofana:CM:80,Eric Bailly:CB:79,Christian Kouam\xE9:ST:78,Alban Lafont:GK:77,Ibrahim Sangar\xE9:CDM:77,Hassane Kamara:LB:76,Elye Wahi:ST:74,Ghislain Konan:LB:74,Habib Ma\xEFga:CDM:74,Jean-Daniel Akpa Akpro:CM:72,Victorien Angban:CM:72,Yahia Fofana:GK:68,Cedric Kouadio:CF:64",
  "Cote d'Ivoire|2022": "Franck Kessi\xE9:CM:86,Wilfried Zaha:LW:85,Evan Ndicka:CB:84,S\xE9bastien Haller:ST:84,Seko Fofana:CM:83,Hamed Traor\xE9:LW:82,Odilon Kossounou:CB:81,Alban Lafont:GK:80,Elye Wahi:ST:80,Amad Diallo:RW:79,Christian Kouam\xE9:ST:79,Wilfried Singo:CB:79,Abakar Sylla:CB:77,Ghislain Konan:LB:76,Hassane Kamara:LB:74,Evann Guessand:RW:73,Jean Micha\xEBl Seri:CDM:73,Paul Akouokou:CDM:73,Lazare Amani:CM:70,Victorien Angban:CM:70,Yahia Fofana:GK:70,Koffi Kouao:RB:68",
  "Cote d'Ivoire|2023": "Elye Wahi:ST:85,Ousmane Diomande:CB:85,Odilon Kossounou:CB:84,Seko Fofana:CM:84,Evan Ndicka:CB:83,Franck Kessi\xE9:CM:83,S\xE9bastien Haller:ST:83,Wilfried Zaha:LW:83,Simon Adingra:LW:82,Alban Lafont:GK:81,Nicolas P\xE9p\xE9:RW:80,Wilfried Singo:CB:80,Karim Konat\xE9:ST:79,Ghislain Konan:LB:76,Hassane Kamara:LB:76,Serge Aurier:RB:76,Evann Guessand:RW:73,Lazare Amani:CM:73,Mohamed Diomand\xE9:CM:70,Yahia Fofana:GK:70,Koffi Kouao:RB:68,Cedric Kouadio:CF:64,Eric Tia:LM:64,Mario Dorgeles:RM:64",
  "Cote d'Ivoire|2024": "Ousmane Diomande:CB:85,Elye Wahi:ST:84,Odilon Kossounou:CB:84,Simon Adingra:LW:83,Amad Diallo:RW:82,Evan Ndicka:CB:82,Karim Konat\xE9:ST:82,Wilfried Singo:CB:82,Ange-Yoan Bonny:ST:81,Evann Guessand:RW:81,Franck Kessi\xE9:CM:80,Hamed Traor\xE9:LW:80,Seko Fofana:CM:80,Malick Yalcouy\xE9:CM:79,Alban Lafont:GK:77,Gu\xE9la Dou\xE9:RB:76,Ghislain Konan:LB:74,Mohamed Diomand\xE9:CM:74,Serge Aurier:RB:74,Hassane Kamara:LB:73,Yahia Fofana:GK:73,Mario Dorgeles:RM:72,Cedric Kouadio:CF:64,Eric Tia:LM:64",
  "Cote d'Ivoire|2025": "Amad Diallo:RW:86,Ousmane Diomande:CB:86,Yan Diomande:LW:86,Ange-Yoan Bonny:ST:84,Evan Ndicka:CB:83,Evann Guessand:RW:83,Simon Adingra:LW:83,Wilfried Singo:CB:83,Elye Wahi:ST:82,Odilon Kossounou:CB:82,Emmanuel Latte Lath:ST:80,Gu\xE9la Dou\xE9:RB:80,Malick Yalcouy\xE9:CM:80,Franck Kessi\xE9:CM:79,Abdoul Ouattara:RB:77,Mario Dorgeles:RM:77,Seko Fofana:CM:77,Christ Inao Oula\xEF:CM:76,Yahia Fofana:GK:76,Alban Lafont:GK:72,Christopher Operi:LB:72,Hassane Kamara:LB:72,Cedric Kouadio:CF:64,Eric Tia:LM:64",
  "Cote d'Ivoire|2026": "Yan Diomande:LW:89,Amad Diallo:RW:86,Ousmane Diomande:CB:86,Ange-Yoan Bonny:ST:84,Bazoumana Tour\xE9:LW:84,Evan Ndicka:CB:84,Evann Guessand:RW:83,Wilfried Singo:CB:82,Patrick Zabi:CM:81,Christ Inao Oula\xEF:CM:80,Emmanuel Agbadou:CB:80,Gu\xE9la Dou\xE9:RB:80,Kader Me\xEFt\xE9:ST:80,Abdoul Ouattara:RB:79,Emmanuel Latte Lath:ST:79,Franck Kessi\xE9:CM:78,Malick Yalcouy\xE9:CM:78,Mario Dorgeles:RM:77,Yahia Fofana:GK:73,Christopher Operi:LB:72,Alban Lafont:GK:70,Ghislain Konan:LB:70,Farouck Adekami:CAM:68,Eric Tia:LM:64",
  "Croatia|2016": "Ivan Rakitic:CM:86,Luka Modri\u0107:CM:86,Ivan Peri\u0161i\u0107:LW:82,Marcelo Brozovi\u0107:CDM:81,Mario Mand\u017Euki\u0107:ST:81,Mateo Kovacic:CM:81,Marko Pjaca:LW:80,Sime Vrsaljko:RB:80,Dejan Lovren:CB:79,Nikola Kalini\u0107:ST:79,Vedran Corluka:CB:78,Alen Halilovic:CAM:77,Andrej Kramaric:CAM:77,Milan Badelj:CDM:77,Domagoj Vida:CB:76,Marko Rog:CM:76,Tin Jedvaj:CB:76,Danijel Subasic:GK:73,Ivan Strinic:LB:73,Darijo Srna:RB:72,Duje Cop:ST:72,Lovre Kalinic:GK:72,Fran Tudor:RM:68,Josip Pivaric:LB:68,Dejan Skolnik:LM:64,Goran Mujanovic:RW:64,Jan Dolezal:CF:64,Robert Muric:RW:64",
  "Croatia|2017": "Ivan Peri\u0161i\u0107:LW:86,Ivan Rakitic:CM:86,Luka Modri\u0107:CM:86,Marcelo Brozovi\u0107:CDM:82,Mateo Kovacic:CM:82,Mario Mand\u017Euki\u0107:ST:81,Nikola Kalini\u0107:ST:81,Dejan Lovren:CB:80,Marko Pjaca:LW:80,Sime Vrsaljko:RB:80,Andrej Kramaric:CAM:79,Milan Badelj:CDM:79,Ante Coric:CAM:77,Domagoj Vida:CB:77,Marko Rog:CM:77,Filip Benkovic:CB:76,Tin Jedvaj:CB:75,Danijel Subasic:GK:73,Duje Cop:ST:73,Ivan Strinic:LB:73,Lovre Kalinic:GK:73,Darijo Srna:RB:70,Fran Tudor:RM:70,Borna Barisic:LB:68,Marin Tomasov:RW:68,Antonio Pavic:LM:64,Goran Mujanovic:RW:64,Jan Dolezal:CF:64",
  "Croatia|2018": "Ivan Rakitic:CM:88,Ivan Peri\u0161i\u0107:LW:86,Marcelo Brozovi\u0107:CDM:86,Luka Modri\u0107:CM:85,Andrej Kramaric:CAM:84,Ante Rebi\u0107:LW:84,Mateo Kovacic:CM:84,Mario Mand\u017Euki\u0107:ST:82,Sime Vrsaljko:RB:82,Dejan Lovren:CB:81,Nikola Kalini\u0107:ST:80,Nikola Vla\u0161i\u0107:CAM:80,Duje Caleta-Car:CB:79,Milan Badelj:CDM:79,Domagoj Vida:CB:78,Filip Benkovic:CB:78,Lovre Kalinic:GK:76,Mario Pa\u0161ali\u0107:CM:76,Borna Sosa:LB:74,Danijel Subasic:GK:73,Ivan Santini:ST:73,Ivan Strinic:LB:73,Marin Tomasov:RW:70,Fran Tudor:RM:68,Mario Situm:RB:68,Antonio Jakolis:RW:64,Antonio Pavic:LM:64,Jan Dolezal:CF:64",
  "Croatia|2019": "Marcelo Brozovi\u0107:CDM:87,Ivan Rakitic:CM:86,Mateo Kovacic:CM:86,Andrej Kramaric:CAM:85,Ante Rebi\u0107:LW:85,Ivan Peri\u0161i\u0107:LW:84,Nikola Vla\u0161i\u0107:CAM:82,Dejan Lovren:CB:81,Luka Modri\u0107:CM:81,Duje Caleta-Car:CB:80,Mario Mand\u017Euki\u0107:ST:80,Bruno Petkovic:ST:79,Dominik Livakovic:GK:79,Mario Pa\u0161ali\u0107:CM:79,Filip Benkovic:CB:78,Domagoj Vida:CB:77,Milan Badelj:CDM:77,Nikola Kalini\u0107:ST:77,Domagoj Bradari\u0107:LB:75,Lovre Kalinic:GK:75,Borna Sosa:LB:72,Marin Tomasov:RW:72,Josip Juranovic:RB:70,Dino Mikanovic:RB:68,Antonio Pavic:LM:64,Fran Tudor:RM:64,Jan Dolezal:CF:64",
  "Croatia|2020": "Marcelo Brozovi\u0107:CDM:86,Mateo Kovacic:CM:86,Andrej Kramaric:CAM:84,Ante Rebi\u0107:LW:84,Nikola Vla\u0161i\u0107:CAM:83,Duje Caleta-Car:CB:82,Mario Pa\u0161ali\u0107:CM:82,Ivan Rakitic:CM:81,Dejan Lovren:CB:80,Ivan Peri\u0161i\u0107:LW:80,Josko Gvardiol:CB:80,Ante Budimir:ST:79,Dominik Livakovic:GK:79,Marko Rog:CM:79,Bruno Petkovic:ST:78,Sime Vrsaljko:RB:78,Ivo Grbic:GK:76,Nikola Moro:CDM:76,Nikola Kalini\u0107:ST:75,Domagoj Bradari\u0107:LB:74,Dino Peric:CB:73,Borna Barisic:LB:72,Marin Tomasov:RW:70,Dino Mikanovic:RB:68,Robert Muric:RW:68,Antonio Pavic:LM:64,Fran Tudor:RM:64,Ivan Laca:CF:64",
  "Croatia|2021": "Mateo Kovacic:CM:86,Marcelo Brozovi\u0107:CDM:85,Andrej Kramaric:CAM:84,Ante Rebi\u0107:LW:84,Mario Pa\u0161ali\u0107:CM:83,Nikola Vla\u0161i\u0107:CAM:83,Duje Caleta-Car:CB:82,Josko Gvardiol:CB:82,Borna Sosa:LB:81,Dominik Livakovic:GK:79,Josip Brekalo:LW:79,Luka Sucic:CM:79,Bruno Petkovic:ST:78,Ante Budimir:ST:77,Dejan Lovren:CB:77,Ivan Rakitic:CM:77,Marin Pongracic:CB:77,Nikola Moro:CDM:77,Ivo Grbic:GK:76,Sime Vrsaljko:RB:76,Borna Barisic:LB:74,Marko Livaja:ST:74,Josip Juranovic:RB:72,Robert Muric:RW:70,Dario \u0160piki\u0107:RW:68,Fran Tudor:RM:68,Andrej Saronja:CF:64",
  "Croatia|2022": "Josko Gvardiol:CB:89,Marcelo Brozovi\u0107:CDM:85,Mateo Kovacic:CM:85,Mario Pa\u0161ali\u0107:CM:83,Ante Rebi\u0107:LW:82,Borna Sosa:LB:82,Lovro Majer:CAM:82,Nikola Vla\u0161i\u0107:CAM:82,Luka Sucic:CM:81,Duje Caleta-Car:CB:80,Josip Sutalo:CB:80,Dominik Livakovic:GK:79,Josip Brekalo:LW:79,Josip Juranovic:RB:77,Kristijan Jakic:CDM:77,Luka Modri\u0107:CM:77,Bruno Petkovic:ST:76,Josip Stanisic:RB:76,Marko Livaja:ST:76,Bartol Franjic:LB:75,Dion Beljo:ST:75,Filip Uremovic:CB:74,Ivica Ivusic:GK:73,Robert Muric:RW:72,Dario \u0160piki\u0107:RW:70,Fran Tudor:RM:70,Andrej Saronja:CF:64",
  "Croatia|2023": "Josko Gvardiol:CB:89,Mateo Kovacic:CM:85,Lovro Majer:CAM:83,Mario Pa\u0161ali\u0107:CM:81,Josip Sutalo:CB:80,Luka Sucic:CM:80,Martin Baturina:CAM:80,Dominik Livakovic:GK:78,Duje Caleta-Car:CB:78,Josip Juranovic:RB:78,Josip Stanisic:RB:78,Ante Rebi\u0107:LW:77,Roko Simic:ST:77,Domagoj Bradari\u0107:LB:76,Ivan Peri\u0161i\u0107:LW:76,Luka Vuskovic:CB:76,Marko Livaja:ST:76,Petar Musa:ST:76,Borna Barisic:LB:75,Toma Ba\u0161i\u0107:CM:74,Dario \u0160piki\u0107:RW:72,Dominik Kotarski:GK:72,Fran Tudor:RM:72,Marco Pa\u0161ali\u0107:RW:72,Andrej Saronja:CF:64,Antonio Pavic:LM:64",
  "Croatia|2024": "Josko Gvardiol:CB:89,Josip Stanisic:RB:83,Mateo Kovacic:CM:83,Lovro Majer:CAM:81,Martin Baturina:CAM:81,Josip Sutalo:CB:80,Luka Sucic:CM:80,Mario Pa\u0161ali\u0107:CM:79,Dominik Livakovic:GK:78,Petar Su\u010Di\u0107:CM:78,Luka Vuskovic:CB:77,Marin Pongracic:CB:77,Ante Crnac:ST:76,Borna Sosa:LB:76,Dominik Kotarski:GK:76,Igor Matanovic:ST:76,Josip Juranovic:RB:76,Marin Ljubicic:ST:76,Mauro Perkovic:LB:73,Bruno Durdov:RW:72,Gabriel Vidovic:LW:72,Josip Brekalo:LW:72,Marco Pa\u0161ali\u0107:RW:72,Fran Tudor:RM:70,Antonio Pavic:LM:64,Ivan Laca:CF:64",
  "Croatia|2025": "Josko Gvardiol:CB:89,Luka Vuskovic:CB:85,Josip Stanisic:RB:84,Petar Su\u010Di\u0107:CM:83,Josip Sutalo:CB:82,Martin Baturina:CAM:82,Mateo Kovacic:CM:82,Franjo Ivanovi\u0107:ST:81,Lovro Majer:CAM:80,Luka Sucic:CM:79,Dominik Kotarski:GK:77,Dominik Livakovic:GK:77,Marin Pongracic:CB:77,Mario Pa\u0161ali\u0107:CM:77,Ante Crnac:ST:76,Igor Matanovic:ST:76,Marco Pa\u0161ali\u0107:RW:75,Borna Sosa:LB:73,Domagoj Bradari\u0107:LB:72,Josip Brekalo:LW:72,Josip Juranovic:RB:72,Gabriel Vidovic:LW:70,Marin Soticek:RW:70,Fran Tudor:RM:68,Ivan Laca:CF:64,Luka Lucic:LM:64",
  "Croatia|2026": "Josko Gvardiol:CB:88,Luka Vuskovic:CB:87,Josip Stanisic:RB:84,Petar Su\u010Di\u0107:CM:83,Martin Baturina:CAM:82,Franjo Ivanovi\u0107:ST:80,Josip Sutalo:CB:79,Mateo Kovacic:CM:78,Igor Matanovic:ST:77,Lovro Majer:CAM:77,Luka Sucic:CM:77,Marin Pongracic:CB:76,Mario Pa\u0161ali\u0107:CM:76,Matija Frigan:ST:76,Marco Pa\u0161ali\u0107:RW:75,Dominik Kotarski:GK:74,Borna Sosa:LB:72,Dominik Livakovic:GK:72,Bruno Durdov:RW:70,Domagoj Bradari\u0107:LB:70,Gabriel Vidovic:LW:70,Ivan Smolcic:RB:70,Fran Tudor:RM:68,Marko Pjaca:LW:68,Luka Lucic:LM:64",
  "Czech Republic|2016": "Petr Cech:GK:78,Vladim\xEDr Darida:CM:77,Matej Vydra:ST:74,Marek Suchy:CB:73,Tomas Necid:ST:73,Borek Dockal:CAM:72,Ladislav Krejci:LM:72,Pavel Kaderabek:RM:72,Tom\xE1\u0161 Vacl\xEDk:GK:72,Jakub Brabec:CB:70,Patrik Schick:ST:70,Theodor Gebre Selassie:RB:70,Tomas Kalas:CB:70,Tomas Sivok:CB:70,David Limbersky:LB:68,David Pavelka:CM:68,Josef Husbauer:CM:68,Lukas Vacha:CDM:68,Martin Frydek:LB:68,Tomas Horava:CM:68,Tom\xE1\u0161 Sou\u010Dek:CDM:68,Vaclav Cerny:RW:68,Ales Cermak:CAM:64,Dominik Smekal:CF:64,Frantisek Rajtoral:RB:64",
  "Czech Republic|2017": "Patrik Schick:ST:81,Jakub Jankto:LM:79,Petr Cech:GK:77,Vladim\xEDr Darida:CM:77,Anton\xEDn Bar\xE1k:CAM:76,Matej Vydra:ST:74,Pavel Kaderabek:RM:74,Jiri Pavlenka:GK:73,Tomas Kalas:CB:73,Marek Suchy:CB:72,Michael Krmencik:ST:72,Borek Dockal:CAM:70,Jakub Brabec:CB:70,Jaromir Zmrhal:LB:70,Josef Husbauer:CM:70,Theodor Gebre Selassie:RB:70,Tomas Horava:CM:70,Daniel Pudil:LB:68,David Pavelka:CM:68,Jan Sykora:LW:68,Lukas Vacha:CDM:68,Tom\xE1\u0161 Sou\u010Dek:CDM:68,Antonin Rusek:CF:64,Michal Sacek:RB:64",
  "Czech Republic|2018": "Patrik Schick:ST:81,Pavel Kaderabek:RM:80,Tom\xE1\u0161 Vacl\xEDk:GK:80,Anton\xEDn Bar\xE1k:CAM:79,Jakub Jankto:LM:79,Jiri Pavlenka:GK:77,Matej Vydra:ST:77,Vladim\xEDr Darida:CM:76,Tomas Kalas:CB:73,Tom\xE1\u0161 Sou\u010Dek:CDM:73,Jaromir Zmrhal:LB:72,Marek Suchy:CB:72,Michael Krmencik:ST:72,Josef Husbauer:CM:70,Michal Travnik:CM:70,Theodor Gebre Selassie:RB:70,Tomas Horava:CM:70,Borek Dockal:CAM:68,Jiri Skalak:LW:68,Martin Frydek:LB:68,Ondrej Petrak:CDM:68,Radim Reznik:RB:68,Vaclav Cerny:RW:68,Antonin Rusek:CF:64,Jan Sykora:LW:64",
  "Czech Republic|2019": "Pavel Kaderabek:RM:81,Tom\xE1\u0161 Vacl\xEDk:GK:80,Patrik Schick:ST:79,Anton\xEDn Bar\xE1k:CAM:78,Jakub Jankto:LM:78,Jiri Pavlenka:GK:78,Tom\xE1\u0161 Sou\u010Dek:CDM:77,Adam Hlozek:ST:76,Alex Kr\xE1l:CM:76,Matej Vydra:ST:76,Tomas Kalas:CB:74,Vladim\xEDr Darida:CM:74,Filip Novak:LB:72,Jaromir Zmrhal:LB:72,Josef Husbauer:CM:72,Michal Sad\xEDlek:CM:72,Theodor Gebre Selassie:RB:70,Borek Dockal:CAM:68,Lukas Kalvach:CDM:68,Michal Sacek:RB:68,Antonin Rusek:CF:64,Jan Sykora:LW:64,Jiri Skalak:LW:64,Vaclav Cerny:RW:64",
  "Czech Republic|2020": "Tom\xE1\u0161 Sou\u010Dek:CDM:83,Patrik Schick:ST:82,Pavel Kaderabek:RM:80,Tom\xE1\u0161 Vacl\xEDk:GK:79,Adam Hlozek:ST:78,Alex Kr\xE1l:CM:77,Anton\xEDn Bar\xE1k:CAM:77,Jakub Jankto:LM:77,Jiri Pavlenka:GK:76,Vladim\xEDr Coufal:RB:76,Tomas Kalas:CB:74,Vladim\xEDr Darida:CM:74,Michael Krmencik:ST:73,Filip Novak:LB:72,Petr Sevcik:CM:72,David Zima:CB:70,Jaromir Zmrhal:LB:70,Lukas Kalvach:CDM:70,Michal Sad\xEDlek:CM:70,Ales Cermak:CAM:68,Lukas Provod:LW:68,Michal Sacek:RB:68,Adam Fila:CF:64",
  "Czech Republic|2021": "Tom\xE1\u0161 Sou\u010Dek:CDM:86,Patrik Schick:ST:85,Adam Hlozek:ST:81,Anton\xEDn Bar\xE1k:CAM:80,Vladim\xEDr Coufal:RB:78,Alex Kr\xE1l:CM:77,David Zima:CB:76,Ondrej Kolar:GK:76,Pavel Kaderabek:RM:76,Tomas Holes:CB:76,Tom\xE1\u0161 Vacl\xEDk:GK:76,Lukas Provod:LW:74,Jan Kuchta:ST:73,Ladislav Krej\u010D\xED:CB:73,Tomas Kalas:CB:73,Petr Sevcik:CM:72,Adam Karabec:CAM:70,Lukas Kalvach:CDM:70,Pavel Bucha:CM:70,Daniel Samek:CM:68,Filip Novak:LB:68,Jaromir Zmrhal:LB:68,Michal Sacek:RB:68,Adam Fila:CF:64,Vaclav Cerny:RW:64",
  "Czech Republic|2022": "Patrik Schick:ST:86,Tom\xE1\u0161 Sou\u010Dek:CDM:86,Adam Hlozek:ST:81,Anton\xEDn Bar\xE1k:CAM:81,Vladim\xEDr Coufal:RB:78,Alex Kr\xE1l:CM:76,David Zima:CB:76,Tomas Holes:CB:76,Jan Kuchta:ST:73,Jindrich Stanek:GK:73,Ladislav Krej\u010D\xED:CB:73,Lukas Masopust:RM:72,Michal Sad\xEDlek:CM:72,Tomas Kalas:CB:72,Tom\xE1\u0161 Vacl\xEDk:GK:72,Adam Karabec:CAM:70,David Jur\xE1sek:LB:70,Lukas Kalvach:CDM:70,Pavel Bucha:CM:70,Petr Sevcik:CM:70,Filip Novak:LB:68,Jakub Pesek:RW:68,Jan Sykora:LW:68,Michal Sacek:RB:68,Antonin Rusek:CF:64",
  "Czech Republic|2023": "Patrik Schick:ST:83,Adam Hlozek:ST:80,Jakub Jankto:LM:78,Tomas Cvancara:ST:78,Alex Kr\xE1l:CM:77,Anton\xEDn Bar\xE1k:CAM:77,Vladim\xEDr Coufal:RB:77,David Jur\xE1sek:LB:76,Vaclav Cerny:RW:76,Michal Sad\xEDlek:CM:74,Ladislav Krej\u010D\xED:CB:73,Matej Kovar:GK:73,Jindrich Stanek:GK:72,Mat\u011Bj Jur\xE1sek:RW:72,Ondrej Lingr:CAM:72,Pavel Kaderabek:RM:70,Jan Sykora:LW:68,Vasil Kusej:LW:68,Antonin Rusek:CF:64,Jaromir Zmrhal:LB:64,Michal Sacek:RB:64",
  "Czech Republic|2024": "Patrik Schick:ST:82,Adam Hlozek:ST:80,Martin Vit\xEDk:CB:79,Anton\xEDn Kinsk\xFD:GK:78,Ladislav Krej\u010D\xED:CB:78,Tomas Cvancara:ST:77,David Jur\xE1sek:LB:76,Lukas Provod:LW:76,Mat\u011Bj Jur\xE1sek:RW:76,Matej Kovar:GK:76,Michal Sad\xEDlek:CM:76,Robin Hranac:CB:76,Vaclav Cerny:RW:76,Vladim\xEDr Coufal:RB:76,Alex Kr\xE1l:CM:74,Tomas Vlcek:CB:74,Jakub Jankto:LM:72,Lukas Cerv:CM:72,Ondrej Lingr:CAM:72,Adam Karabec:CAM:70,David Doudera:RM:70,Michal Sacek:RB:68,Ondrej Zmrzly:LB:68,Antonin Rusek:CF:64",
  "Czech Republic|2025": "Patrik Schick:ST:83,Ladislav Krej\u010D\xED:CB:82,Adam Hlozek:ST:80,Anton\xEDn Kinsk\xFD:GK:79,Martin Vit\xEDk:CB:79,Lukas Hornicek:GK:77,Vaclav Cerny:RW:77,Adam Karabec:CAM:76,David Zima:CB:76,Lukas Provod:LW:76,Mat\u011Bj Jur\xE1sek:RW:76,Michal Sad\xEDlek:CM:76,Robin Hranac:CB:76,Alex Kr\xE1l:CM:74,Lukas Cerv:CM:74,Vasil Kusej:LW:74,David Jur\xE1sek:LB:73,Matej Sin:CAM:73,Mojm\xEDr Chytil:ST:73,Vladim\xEDr Coufal:RB:73,David Doudera:RM:72,Matej Rynes:LM:72,Pavel Bucha:CM:72,Michal Sacek:RB:68,Ondrej Zmrzly:LB:68,Antonin Rusek:CF:64",
  "Czech Republic|2026": "Ladislav Krej\u010D\xED:CB:82,Patrik Schick:ST:81,Pavel Sulc:CAM:81,Anton\xEDn Kinsk\xFD:GK:79,Lukas Hornicek:GK:79,Adam Hlozek:ST:78,Martin Vit\xEDk:CB:77,Robin Hranac:CB:77,Adam Karabec:CAM:76,David Zima:CB:76,Lukas Provod:LW:76,Michal Sad\xEDlek:CM:76,Vaclav Cerny:RW:76,Lukas Cerv:CM:74,Mat\u011Bj Jur\xE1sek:RW:74,Matej Rynes:LM:73,Vasil Kusej:LW:73,David Doudera:RM:72,Mojm\xEDr Chytil:ST:72,Pavel Bucha:CM:72,Vladim\xEDr Coufal:RB:70,Ondrej Zmrzly:LB:68",
  "DR Congo|2016": "C\xE9dric Bakambu:ST:81,Yannick Bolasie:ST:81,Giannelli Imbula:CDM:80,Benik Afobe:ST:77,Chancel Mbemba:CB:77,Arthur Masuaku:LB:76,Ga\xEBl Kakuta:CAM:72,Paul-Jos\xE9 Mpoku:CAM:72,Aaron Tshibola:CM:70,Larrys Mabiala:CB:70,Marcel Tisserand:CB:70,Th\xE9o Bongonda:RW:70,Yeni Ngbakoto:RW:70,Youssouf Mulumbu:CDM:70,Arnaud Lusamba:CM:68,Fabrice N'Sakala:LB:68,Cedrick:LW:64,Herv\xE9 Kage:LW:64,Jacques Maghoma:LM:64,Jordan Ikoko:RB:64,Jordan N'Kololo:CF:64,Parfait Mandanda:GK:64,Ridge Mobulu:RM:64",
  "DR Congo|2019": "Aaron Wan-Bissaka:RB:85,C\xE9dric Bakambu:ST:79,Yannick Bolasie:ST:79,Arthur Masuaku:LB:77,Axel Tuanzebe:CB:77,Britt Assombalonga:ST:77,Christian Luyindama:CB:76,Marcel Tisserand:CB:76,Silas:RW:76,Th\xE9o Bongonda:RW:74,Giannelli Imbula:CDM:73,Samuel Bastien:CM:73,Samuel Moutoussamy:CM:73,Chancel Mbemba:CB:72,Ga\xEBl Kakuta:CAM:72,Nathana\xEBl Mbuku:LW:72,Neeskens Kebano:LW:70,Beni Baningime:CDM:68,Fabrice N'Sakala:LB:68,Jordan Ikoko:RB:68,Ambre Nsumbu:LM:64,Dimitry Bertaud:GK:64,Elie Dindamba:RM:64,Jordan N'Kololo:CF:64",
  "DR Congo|2020": "Aaron Wan-Bissaka:RB:85,C\xE9dric Bakambu:ST:79,Grady Diangana:RW:78,Arthur Masuaku:LB:76,Benik Afobe:ST:76,Britt Assombalonga:ST:76,Samuel Bastien:CM:76,Ga\xEBl Kakuta:CAM:74,Marcel Tisserand:CB:74,Nathana\xEBl Mbuku:LW:73,Th\xE9o Bongonda:RW:73,Arnaud Lusamba:CM:70,Giannelli Imbula:CDM:70,Jeremy Ngakia:RB:70,Joris Kayembe:LB:70,Samuel Moutoussamy:CM:70,Neeskens Kebano:LW:68,Dimitry Bertaud:GK:64,Elie Dindamba:RM:64,Jacques Maghoma:LM:64,Jordan N'Kololo:CF:64",
  "DR Congo|2021": "Aaron Wan-Bissaka:RB:85,Silas:RW:82,Chancel Mbemba:CB:80,C\xE9dric Bakambu:ST:78,Grady Diangana:RW:78,Nathana\xEBl Mbuku:LW:77,Yoane Wissa:ST:77,Arthur Masuaku:LB:76,Axel Tuanzebe:CB:76,Christian Luyindama:CB:76,Ga\xEBl Kakuta:CAM:76,Samuel Bastien:CM:74,Meschack Elia:CAM:73,Metinho:CM:73,Jackson Muleka:ST:72,Jeremy Ngakia:RB:72,Marcel Tisserand:CB:72,Charles Pickel:CDM:68,Neeskens Kebano:LW:68,Pelly Ruddock Mpanzu:CDM:68,Dimitry Bertaud:GK:64,Jordan N'Kololo:CF:64,Ngonda Muzinga:LB:64,Ridge Mobulu:RM:64",
  "DR Congo|2022": "Aaron Wan-Bissaka:RB:83,Chancel Mbemba:CB:80,Silas:RW:79,Yoane Wissa:ST:79,C\xE9dric Bakambu:ST:78,Th\xE9o Bongonda:RW:77,Axel Tuanzebe:CB:76,Ga\xEBl Kakuta:CAM:76,Nathana\xEBl Mbuku:LW:76,Simon Banza:ST:76,Arthur Masuaku:LB:74,Michel-Ange Balikwisha:LW:74,Meschack Elia:CAM:73,Charles Pickel:CDM:72,G\xE9d\xE9on Kalulu:RB:72,Marcel Tisserand:CB:72,Samuel Moutoussamy:CM:72,Joris Kayembe:LB:70,Metinho:CM:70,Samuel Bastien:CM:70,Dimitry Bertaud:GK:68,Pelly Ruddock Mpanzu:CDM:68,Jordan N'Kololo:CF:64,Ridge Mobulu:RM:64,Timothy Fayulu:GK:64",
  "DR Congo|2023": "Yoane Wissa:ST:82,Chancel Mbemba:CB:81,Michel-Ange Balikwisha:LW:78,Simon Banza:ST:78,Silas:RW:77,Arthur Masuaku:LB:74,Mario Stroeykens:CAM:74,Meschack Elia:CAM:74,C\xE9dric Bakambu:ST:73,Edo Kayembe:CM:73,G\xE9d\xE9on Kalulu:RB:73,Samuel Moutoussamy:CM:73,Axel Tuanzebe:CB:72,Jonathan Okita:LW:70,Joris Kayembe:LB:70,Noah Sadiki:CM:70,Aldo Kalulu:RW:68,Dimitry Bertaud:GK:68,Jeremy Ngakia:RB:68,Andrea Mutombo:LM:64,Jordan N'Kololo:CF:64,Timothy Fayulu:GK:64",
  "DR Congo|2024": "Yoane Wissa:ST:83,Aaron Wan-Bissaka:RB:82,Simon Banza:ST:80,Chancel Mbemba:CB:79,Mario Stroeykens:CAM:79,Michel-Ange Balikwisha:LW:77,Silas:RW:77,Noah Sadiki:CM:76,Th\xE9o Bongonda:RW:74,G\xE9d\xE9on Kalulu:RB:72,Jackson Muleka:ST:72,Metinho:CM:72,Edo Kayembe:CM:70,Joris Kayembe:LB:70,Matthieu Epolo:GK:70,Samuel Moutoussamy:CM:70,Jonathan Okita:LW:68,William Balikwisha:CAM:68,Andrea Mutombo:LM:64,Jordan N'Kololo:CF:64,Marvin Kaleta:RM:64,Timothy Fayulu:GK:64,Vital Nsimba:LB:64",
  "DR Congo|2025": "Yoane Wissa:ST:85,Aaron Wan-Bissaka:RB:82,Noah Sadiki:CM:82,Simon Banza:ST:79,Mario Stroeykens:CAM:78,Michel-Ange Balikwisha:LW:76,Silas:RW:76,Metinho:CM:74,Th\xE9o Bongonda:RW:74,Afimico Pululu:ST:73,Axel Tuanzebe:CB:73,Matthieu Epolo:GK:73,Edo Kayembe:CM:72,Meschack Elia:CAM:72,Arthur Masuaku:LB:70,G\xE9d\xE9on Kalulu:RB:68,Marvin Kaleta:RM:64,Timothy Fayulu:GK:64",
  "DR Congo|2026": "Noah Sadiki:CM:83,Yoane Wissa:ST:83,Aaron Wan-Bissaka:RB:82,Simon Banza:ST:78,Mario Stroeykens:CAM:74,Metinho:CM:74,Axel Tuanzebe:CB:73,Afimico Pululu:ST:72,Edo Kayembe:CM:72,Michel-Ange Balikwisha:LW:72,Arthur Masuaku:LB:70,Grady Diangana:RW:70,Joris Kayembe:LB:70,Silas:RW:70,Brian Cipenga:LW:68,Jeremy Ngakia:RB:68,Meschack Elia:CAM:68,Marvin Kaleta:RM:64,Timothy Fayulu:GK:64",
  "Denmark|2016": "Christian Eriksen:CAM:84,Andreas Christensen:CB:79,Daniel Wass:CM:77,Jannik Vestergaard:CB:77,Simon Kjaer:CB:77,Kasper Schmeichel:GK:76,Pierre-Emile H\xF8jbjerg:CDM:76,Martin Braithwaite:ST:74,Nicolai J\xF8rgensen:ST:74,Alexander Scholz:CB:73,Yussuf Poulsen:ST:73,Michael Krohn-Dehli:CM:72,Thomas Delaney:CM:72,Jonas L\xF6ssl:GK:70,Lasse Sch\xF6ne:CDM:70,Lasse Vigen:CM:70,Nicolai Boilesen:LB:68,Nicolaj Thomsen:CAM:68,Peter Ankersen:RB:68,Riza Durmisi:LB:68,Andreas Bruhn:RM:64,Bo Storm:CF:64,Emil Scheel:LM:64,Jens Stryger:RB:64,Tobias Mikkelsen:RW:64,Youssef Toutouh:LW:64",
  "Denmark|2017": "Christian Eriksen:CAM:86,Andreas Christensen:CB:80,Jannik Vestergaard:CB:79,Kasper Dolberg:ST:79,Nicolai J\xF8rgensen:ST:79,Simon Kjaer:CB:79,Daniel Wass:CM:77,Kasper Schmeichel:GK:77,Yussuf Poulsen:ST:77,Frederik S\xF8rensen:CB:76,Pierre-Emile H\xF8jbjerg:CDM:76,Thomas Delaney:CM:76,Riza Durmisi:LB:74,Pione Sisto:LW:73,Viktor Fischer:LW:73,Lasse Sch\xF6ne:CDM:72,Emiliano Marcondes:CAM:70,Jonas L\xF6ssl:GK:70,Michael Krohn-Dehli:CM:70,Anders Christiansen:CM:68,Peter Ankersen:RB:68,Rasmus Kristensen:RB:68,Uffe Bech:RW:68,Andreas Bruhn:RM:64,Bo Storm:CF:64,Brian H\xE4m\xE4l\xE4inen:LB:64,Emil Scheel:LM:64,Kasper Kusk:RW:64",
  "Denmark|2018": "Christian Eriksen:CAM:89,Andreas Christensen:CB:85,Thomas Delaney:CM:83,Jacob Bruun Larsen:LW:81,Jannik Vestergaard:CB:81,Yussuf Poulsen:ST:81,Kasper Dolberg:ST:80,Daniel Wass:CM:79,Joachim Andersen:CB:79,Nicolai J\xF8rgensen:ST:79,Pione Sisto:LW:79,Simon Kjaer:CB:79,Kasper Schmeichel:GK:78,Pierre-Emile H\xF8jbjerg:CDM:78,Philip Billing:CM:76,Lukas Lerager:CDM:74,Riza Durmisi:LB:74,Jonas L\xF6ssl:GK:73,Mathias Jensen:CM:73,Robert Skov:LM:73,Andreas Poulsen:LB:72,Jens Stryger:RB:72,Emiliano Marcondes:CAM:70,Rasmus Kristensen:RB:70,Younes Namli:RW:70,Andreas Skov Olsen:RW:68,Martin Mikkelsen:RM:64,Ronni M\xF6ller Iversen:CF:64",
  "Denmark|2019": "Christian Eriksen:CAM:90,Andreas Christensen:CB:84,Yussuf Poulsen:ST:84,Thomas Delaney:CM:83,Joachim Andersen:CB:82,Kasper Dolberg:ST:82,Jannik Vestergaard:CB:81,Philip Billing:CM:80,Daniel Wass:CM:79,Jacob Bruun Larsen:LW:79,Pierre-Emile H\xF8jbjerg:CDM:79,Robert Skov:LM:79,Kasper Schmeichel:GK:78,Joakim Maehle:LB:77,Martin Braithwaite:ST:77,Andreas Skov Olsen:RW:76,Pione Sisto:LW:76,Simon Kjaer:CB:76,Lukas Lerager:CDM:74,Jonas L\xF6ssl:GK:73,Kristian Pedersen:LB:73,Jens Stryger:RB:72,Mathias Jensen:CM:72,Rasmus Kristensen:RB:72,Jens Odgaard:CAM:70,Younes Namli:RW:70,Andreas Bruhn:RM:64,Ronni M\xF6ller Iversen:CF:64",
  "Denmark|2020": "Christian Eriksen:CAM:89,Pierre-Emile H\xF8jbjerg:CDM:83,Yussuf Poulsen:ST:83,Andreas Christensen:CB:82,Kasper Dolberg:ST:82,Joachim Andersen:CB:81,Thomas Delaney:CM:80,Philip Billing:CM:79,Robert Skov:LM:79,Andreas Cornelius:ST:78,Daniel Wass:CM:78,Jacob Bruun Larsen:LW:78,Joakim Maehle:LB:77,Kasper Schmeichel:GK:77,Mikkel Damsgaard:CAM:76,Rasmus Kristensen:RB:76,Andreas Skov Olsen:RW:75,Anders Dreyer:RW:74,Mohamed Daramy:LW:74,Kristian Pedersen:LB:73,Victor Nelsson:CB:73,Christian N\xF8rgaard:CDM:72,Frederik R\xF6nnow:GK:72,Magnus Kofod Andersen:CM:72,Alexander Bah:RB:70,Rasmus Lauritsen:CB:70,Marius Elvius:RM:64,Thomas Enevoldsen:CF:64",
  "Denmark|2021": "Christian Eriksen:CAM:85,Pierre-Emile H\xF8jbjerg:CDM:85,Andreas Christensen:CB:84,Joachim Andersen:CB:82,Kasper Dolberg:ST:82,Yussuf Poulsen:ST:82,Joakim Maehle:LB:81,Mikkel Damsgaard:CAM:81,Jannik Vestergaard:CB:80,Philip Billing:CM:80,Thomas Delaney:CM:80,Rasmus Kristensen:RB:79,Jesper Lindstr\xF8m:RW:77,Martin Braithwaite:ST:77,Simon Kjaer:CB:77,Anders Dreyer:RW:76,Christian N\xF8rgaard:CDM:76,Daniel Wass:CM:76,Kasper Schmeichel:GK:76,Mathias Jensen:CM:76,Mohamed Daramy:LW:76,Jacob Bruun Larsen:LW:75,Alexander Bah:RB:74,Kristian Pedersen:LB:72,Frederik R\xF6nnow:GK:70,Karl Leth:CF:64,Rasmus Carstensen:RM:64",
  "Denmark|2022": "Pierre-Emile H\xF8jbjerg:CDM:86,Andreas Christensen:CB:84,Joachim Andersen:CB:84,Jesper Lindstr\xF8m:RW:83,Christian Eriksen:CAM:82,Andreas Skov Olsen:RW:81,Kasper Dolberg:ST:80,Philip Billing:CM:80,Christian N\xF8rgaard:CDM:79,Jannik Vestergaard:CB:79,Joakim Maehle:LB:79,Jonas Wind:ST:79,Mathias Jensen:CM:79,Maurits Kj\xE6rgaard:CM:79,Mikkel Damsgaard:CAM:79,Rasmus H\xF8jlund:ST:79,Rasmus Kristensen:RB:79,Victor Nelsson:CB:79,Alexander Bah:RB:76,Casper Nielsen:CM:76,Mohamed Daramy:LW:76,Jacob Bruun Larsen:LW:74,Frederik R\xF6nnow:GK:72,Kasper Schmeichel:GK:72,Victor Kristiansen:LB:72,Rasmus Carstensen:RM:68,Ronni M\xF6ller Iversen:CF:64",
  "Denmark|2023": "Rasmus H\xF8jlund:ST:88,Andreas Christensen:CB:85,Joachim Andersen:CB:84,Jesper Lindstr\xF8m:RW:83,Mathias Jensen:CM:83,Christian Eriksen:CAM:82,Jonas Wind:ST:82,Philip Billing:CM:82,Victor Nelsson:CB:81,Andreas Skov Olsen:RW:80,Alexander Bah:RB:79,Filip J\xF8rgensen:GK:79,Joakim Maehle:LB:79,Matt O'Riley:CM:79,Maurits Kj\xE6rgaard:CM:79,Mikkel Damsgaard:CAM:79,Rasmus Kristensen:RB:79,Robert Skov:LM:78,Victor Kristiansen:LB:78,Kasper Dolberg:ST:77,Mads Hermansen:GK:77,Mohamed Daramy:LW:77,Rasmus Nicolaisen:CB:74,Nicolai Vallys:LW:73,Rasmus Carstensen:RM:70",
  "Denmark|2024": "Rasmus H\xF8jlund:ST:88,Andreas Christensen:CB:85,Joachim Andersen:CB:84,Mathias Jensen:CM:83,Jesper Lindstr\xF8m:RW:82,Matt O'Riley:CM:82,Philip Billing:CM:82,Filip J\xF8rgensen:GK:81,Jonas Wind:ST:81,Patrick Dorgu:LB:81,Andreas Skov Olsen:RW:80,Conrad Harder:ST:80,Victor Kristiansen:LB:80,Victor Nelsson:CB:80,Albert Gr\xF8nb\xE6k:CAM:79,Alexander Bah:RB:79,Maurits Kj\xE6rgaard:CM:79,Mikkel Damsgaard:CAM:79,Mads Hermansen:GK:78,Mads Roerslev:RB:78,Mohamed Daramy:LW:77,Robert Skov:LM:77,Jacob Bruun Larsen:LW:76,Rasmus Nicolaisen:CB:74,Rasmus Carstensen:RM:68",
  "Denmark|2025": "Rasmus H\xF8jlund:ST:86,Joachim Andersen:CB:83,Mika Biereth:ST:83,Mikkel Damsgaard:CAM:83,Patrick Dorgu:LB:83,Victor Froholdt:CM:83,Conrad Harder:ST:82,Matt O'Riley:CM:82,Gustav Isaksen:RW:81,Filip J\xF8rgensen:GK:80,Jesper Lindstr\xF8m:RW:80,Mads Hermansen:GK:80,Mathias Jensen:CM:80,Andreas Christensen:CB:79,Jens Odgaard:CAM:79,Jens Stage:CM:79,Joakim Maehle:LB:79,Rasmus Kristensen:RB:79,Alexander Bah:RB:78,Lucas H\xF8gsberg:CB:78,Thomas Kristensen:CB:77,Robert Skov:LM:75,Clement Bischoff:LW:73,Jacob Bruun Larsen:LW:73,Rasmus Carstensen:RM:68",
  "Denmark|2026": "Rasmus H\xF8jlund:ST:86,Patrick Dorgu:LB:84,Mikkel Damsgaard:CAM:83,Victor Froholdt:CM:83,Joachim Andersen:CB:82,Conrad Harder:ST:81,Matt O'Riley:CM:81,Gustav Isaksen:RW:80,Mika Biereth:ST:80,Anders Dreyer:RW:79,Filip J\xF8rgensen:GK:79,Jens Odgaard:CAM:79,Jens Stage:CM:79,Lucas H\xF8gsberg:CB:79,Mads Bidstrup:CM:79,Mads Hermansen:GK:79,Thomas Kristensen:CB:78,Victor Kristiansen:LB:78,Alexander Bah:RB:77,Andreas Christensen:CB:77,Elias Jelert:RB:76,Clement Bischoff:LW:73,Jacob Bruun Larsen:LW:73,Robert Skov:LM:73,Rasmus Carstensen:RM:68",
  "Ecuador|2016": "Enner Valencia:ST:78,Antonio Valencia:RB:76,Christian Noboa:CM:74,Felipe Caicedo:ST:73,Juan Cazares:CAM:73,Fidel Mart\xEDnez:LW:72,Frickson Erazo:CB:72,Jaime Ayov\xED:ST:72,Miler Bola\xF1os:CAM:72,\xC1ngel Mena:RW:70,Alexander Dom\xEDnguez:GK:68,Arturo Mina:CB:68,Carlos Gruezo:CDM:68,Ely Esterilla:RW:68,Esteban Dreer:GK:68,Juan Carlos Paredes:CDM:68,Mario Pineida:LB:68,Michael Arroyo:LW:68,Andr\xE9s L\xF3pez:RB:64,An\xEDbal Chal\xE1:LB:64",
  "Ecuador|2017": "Antonio Valencia:RB:77,Enner Valencia:ST:77,Jefferson Montero:LW:73,Juan Cazares:CAM:73,Christian Noboa:CM:72,Jaime Ayov\xED:ST:72,Miler Bola\xF1os:CAM:72,\xC1ngel Mena:RW:70,Arturo Mina:CB:70,Cristian Ram\xEDrez:LB:70,Felipe Caicedo:ST:70,Fidel Mart\xEDnez:LW:70,Alexander Dom\xEDnguez:GK:68,Andr\xE9s L\xF3pez:RB:68,Carlos Gruezo:CDM:68,Esteban Dreer:GK:68,Fernando Gaibor:CM:68,Juan Carlos Paredes:CDM:68,Mario Pineida:LB:68,Renato Ibarra:RW:68",
  "Ecuador|2018": "Antonio Valencia:RB:77,Cristian Ram\xEDrez:LB:75,Enner Valencia:ST:74,Juan Cazares:CAM:73,Ayrton Preciado:LW:70,Bryan Angulo:ST:70,Fernando Gaibor:CM:70,Jaime Ayov\xED:ST:70,Miler Bola\xF1os:CAM:70,Renato Ibarra:RW:70,Alexander Dom\xEDnguez:GK:68,Andr\xE9s L\xF3pez:RB:68,\xC1ngel Mena:RW:68,Carlos Gruezo:CDM:68,Christian Noboa:CM:68,Cristian Penilla:LW:68,Esteban Dreer:GK:68,Diego Palacios:LB:64,John Yeboah:CF:64,Juan Carlos Paredes:CDM:64",
  "Ecuador|2020": "Pervis Estupi\xF1\xE1n:LB:79,Cristian Ram\xEDrez:LB:75,Felipe Caicedo:ST:74,Carlos Gruezo:CDM:73,Mois\xE9s Caicedo:CDM:73,Enner Valencia:ST:72,Gonzalo Plata:RW:72,Juan Cazares:CAM:72,Renato Ibarra:RW:72,Angelo Preciado:RB:70,Antonio Valencia:RB:70,Eryc Castillo:LW:70,Jordan Sierra:CM:70,Jos\xE9 Cifuentes:CM:70,J\xFAnior Sornoza:CAM:70,Alexander Alvarado:LW:68,John Yeboah:CF:64,Manuel Aguirre:RM:64,Pedro Ortiz:GK:64",
  "Ecuador|2022": "Mois\xE9s Caicedo:CDM:85,Piero Hincapi\xE9:CB:82,Pervis Estupi\xF1\xE1n:LB:81,Jos\xE9 Cifuentes:CM:78,F\xE9lix Torres:CB:74,Gonzalo Plata:RW:74,Angelo Preciado:RB:72,Carlos Gruezo:CDM:72,Diego Palacios:LB:72,Enner Valencia:ST:72,Willian Pacho:CB:72,Alan Franco:CM:70,Ayrton Preciado:LW:70,Bryan Angulo:ST:70,Byron Castillo:RB:70,Jeremy Sarmiento:LW:70,Leonardo Campana:ST:70,Pedro Vite:CAM:70,Anderson Julio:RW:68,Juan Cazares:CAM:68,Dilan Saltos:CF:64,Mois\xE9s Ram\xEDrez:GK:64",
  "Ecuador|2023": "Pervis Estupi\xF1\xE1n:LB:84,Piero Hincapi\xE9:CB:84,Willian Pacho:CB:82,Kendry P\xE1ez:CAM:77,Jos\xE9 Cifuentes:CM:76,F\xE9lix Torres:CB:74,Cristian Ram\xEDrez:LB:73,Angelo Preciado:RB:72,Enner Valencia:ST:72,Jackson Porozo:CB:72,Jordy Caicedo:ST:72,Leonardo Campana:ST:72,Alan Franco:CM:70,Byron Castillo:RB:70,Pedro Vite:CAM:70,Alan Minda:RW:68,Alexander Alvarado:LW:68,Anderson Julio:RW:68,Ayrton Preciado:LW:68,John Yeboah:CF:68,Mois\xE9s Ram\xEDrez:GK:68",
  "Ecuador|2024": "Piero Hincapi\xE9:CB:85,Willian Pacho:CB:85,Pervis Estupi\xF1\xE1n:LB:83,Joel Ord\xF3\xF1ez:CB:80,Kendry P\xE1ez:CAM:78,Jeremy Sarmiento:LW:76,Jos\xE9 Cifuentes:CM:76,Alan Minda:RW:74,F\xE9lix Torres:CB:74,Gonzalo Plata:RW:74,Angelo Preciado:RB:73,Alan Franco:CM:72,Cristian Ram\xEDrez:LB:72,John Mercado:LW:70,John Yeboah:CF:70,Justin Lerma:CAM:70,Leonardo Campana:ST:70,Gonzalo Valle:GK:68,Jos\xE9 Andr\xE9s Hurtado:RB:68,Jefferson Troya:RM:64,Jord\xE1n Mohor:LM:64",
  "Ecuador|2025": "Willian Pacho:CB:88,Piero Hincapi\xE9:CB:86,Joel Ord\xF3\xF1ez:CB:83,Pervis Estupi\xF1\xE1n:LB:83,Kendry P\xE1ez:CAM:77,Keny Arroyo:RW:77,Gonzalo Plata:RW:76,Jeremy Ar\xE9valo:ST:76,Jeremy Sarmiento:LW:76,Nilson Angulo:LW:76,Denil Castillo:CM:74,Patrik Mercado:CAM:74,Jos\xE9 Cifuentes:CM:73,Kevin Rodr\xEDguez:ST:73,Angelo Preciado:RB:72,Jhoanner Ch\xE1vez:LB:72,John Yeboah:CF:70,Jos\xE9 Andr\xE9s Hurtado:RB:70,Gonzalo Valle:GK:68,Jandry G\xF3mez:RM:64",
  "Ecuador|2026": "Willian Pacho:CB:88,Piero Hincapi\xE9:CB:86,Joel Ord\xF3\xF1ez:CB:84,Nilson Angulo:LW:80,Pervis Estupi\xF1\xE1n:LB:79,Kendry P\xE1ez:CAM:77,Keny Arroyo:RW:77,Gonzalo Plata:RW:76,Jeremy Ar\xE9valo:ST:76,Denil Castillo:CM:74,Patrik Mercado:CAM:74,Alan Franco:CM:73,Jos\xE9 Cifuentes:CM:73,Kevin Rodr\xEDguez:ST:73,Angelo Preciado:RB:72,John Mercado:LW:72,L\xE9o Realpe:CB:72,Yaimar Medina:LB:72,Jos\xE9 Andr\xE9s Hurtado:RB:70,Gonzalo Valle:GK:68,Jandry G\xF3mez:RM:64",
  "Egypt|2016": "Mohamed Salah:RW:83,Mohamed Elneny:CDM:76,Ahmed Hassan:ST:73,Ahmed El Mohamady:RB:72,Ali Ghazal:CB:70,Ramadan Sobhi:CAM:70,Ahmed El Shenawy:GK:68,Ahmed Fathi:RB:68,Mohamed Abdelshafi:LB:68,Trezeguet:LW:68,Ahmed Farag:CF:64,Ahmed Sabry:RM:64,Amr Warda:LW:64,Ayman Hefny:CAM:64,Sherif Ekramy:GK:64",
  "Egypt|2017": "Mohamed Salah:RW:85,Mohamed Elneny:CDM:77,Ramadan Sobhi:CAM:73,Ahmed El Mohamady:RB:72,Ahmed Hassan:ST:72,Ahmed Hegazy:CB:70,Ahmed El Shenawy:GK:68,Kahraba:ST:68,Mohamed Abdelshafi:LB:68,Trezeguet:LW:68,Ahmed El Sheikh:RW:64,Ahmed Fathi:RB:64,Ahmed Omran:CF:64,Amr Warda:LW:64,Hazem Emam:RM:64,Islam Kamal:LM:64,Karim Hafez:LB:64,Sherif Ekramy:GK:64",
  "Egypt|2018": "Mohamed Salah:RW:92,Mohamed Elneny:CDM:77,Ahmed Hegazy:CB:76,Ramadan Sobhi:CAM:76,Trezeguet:LW:73,Ahmed El Mohamady:RB:70,Ahmed Hassan:ST:70,Abdallah El Said:CM:68,Hussein El Shahat:LW:68,Ibrahim Hassan:RW:68,Mohamed El Shenawy:GK:68,Afsha:CAM:64,Ahmed Fathi:RB:64,Hazem Emam:RM:64,Karim Hafez:LB:64,Mohamed Abdelshafi:LB:64,Mohamed Awad:GK:64,Said Mourad:LM:64",
  "Egypt|2020": "Mohamed Salah:RW:91,Trezeguet:LW:77,Mohamed Elneny:CDM:76,Ahmed Hegazy:CB:73,Mohamed El Shenawy:GK:70,Afsha:CAM:68,Ahmed El Mohamady:RB:68,Ahmed El Shenawy:GK:68,Hussein El Shahat:LW:68,Tarek Hamed:CDM:68,Ahmed El Sheikh:RW:64,Hazem Emam:RM:64,Karim Hafez:LB:64,Mohamed Hany:RB:64",
  "England|2016": "Raheem Sterling:RW:86,Harry Kane:ST:85,Wayne Rooney:ST:85,John Stones:CB:84,Jordan Henderson:CDM:83,Daniel Sturridge:ST:82,Jack Wilshere:CM:82,Ross Barkley:CM:82,Theo Walcott:RW:82,Adam Lallana:CAM:81,Alex Oxlade-Chamberlain:CM:81,Chris Smalling:CB:81,Dele Alli:CAM:81,Luke Shaw:LB:81,Nathaniel Clyne:RB:81,Eric Dier:CB:80,Gary Cahill:CB:80,Joe Hart:GK:80,Leighton Baines:LB:80,Fraser Forster:GK:79,James Milner:CM:79,Kyle Walker:RB:79,Marcus Rashford:LW:77,Jack Colback:CDM:76,Marc Albrighton:RM:74,Stewart Downing:LM:74,Jack Grealish:LW:73,Lee Tomlin:CF:72",
  "England|2017": "Harry Kane:ST:89,Dele Alli:CAM:87,Raheem Sterling:RW:86,John Stones:CB:84,Kyle Walker:RB:84,Alex Oxlade-Chamberlain:CM:83,Danny Rose:LB:83,Eric Dier:CB:83,Jordan Henderson:CDM:83,Marcus Rashford:LW:83,Adam Lallana:CAM:82,Daniel Sturridge:ST:82,Ross Barkley:CM:82,Theo Walcott:RW:82,Chris Smalling:CB:81,Jack Wilshere:CM:81,Luke Shaw:LB:81,Nathaniel Clyne:RB:81,Wayne Rooney:ST:81,Gary Cahill:CB:80,Danny Drinkwater:CM:79,Fraser Forster:GK:79,Jack Butland:GK:79,Jake Livermore:CDM:76,Marc Albrighton:RM:74,Izzy Brown:LW:73,Lee Tomlin:CF:72,Stewart Downing:LM:72",
  "England|2018": "Harry Kane:ST:92,Raheem Sterling:RW:91,Dele Alli:CAM:90,Jadon Sancho:LW:88,Marcus Rashford:LW:88,John Stones:CB:87,Harry Maguire:CB:86,Kyle Walker:RB:86,Trent Alexander-Arnold:RB:86,Alex Oxlade-Chamberlain:CM:85,Eric Dier:CB:85,Jesse Lingard:CAM:85,Jordan Pickford:GK:85,Joe Gomez:CB:84,Ryan Sessegnon:LB:84,Danny Rose:LB:83,Jordan Henderson:CDM:83,Callum Wilson:ST:82,Jack Butland:GK:82,Ross Barkley:CM:82,Daniel Sturridge:ST:81,Danny Drinkwater:CM:81,Declan Rice:CM:81,Theo Walcott:RW:81,Harry Winks:CDM:79,Marc Albrighton:RM:77,Lee Tomlin:CF:70,Stewart Downing:LM:70",
  "England|2019": "Raheem Sterling:RW:93,Harry Kane:ST:92,Jadon Sancho:LW:91,Trent Alexander-Arnold:RB:91,Dele Alli:CAM:90,Marcus Rashford:LW:89,Harry Maguire:CB:88,Declan Rice:CM:87,James Maddison:CAM:87,John Stones:CB:87,Ben Chilwell:LB:86,Kyle Walker:RB:86,Tammy Abraham:ST:86,Eric Dier:CB:85,Harry Winks:CDM:85,Jordan Pickford:GK:85,Alex Oxlade-Chamberlain:CM:84,Joe Gomez:CB:84,Jordan Henderson:CDM:84,Ryan Sessegnon:LB:84,Callum Wilson:ST:83,Ross Barkley:CM:83,Ruben Loftus-Cheek:CM:83,Mason Greenwood:RW:81,Jack Butland:GK:80,Marc Albrighton:RM:77,Lee Tomlin:CF:68,Marvin Johnson:LM:68",
  "England|2020": "Jadon Sancho:LW:92,Harry Kane:ST:91,Raheem Sterling:RW:91,Trent Alexander-Arnold:RB:91,Dele Alli:CAM:89,Marcus Rashford:LW:89,Declan Rice:CM:87,Harry Maguire:CB:87,James Maddison:CAM:87,Ben Chilwell:LB:86,Dominic Calvert-Lewin:ST:86,John Stones:CB:86,Mason Greenwood:RW:86,Joe Gomez:CB:85,Kyle Walker:RB:85,Tammy Abraham:ST:85,Harry Winks:CDM:84,Ryan Sessegnon:LB:84,Alex Oxlade-Chamberlain:CM:83,James Tarkowski:CB:83,Jordan Henderson:CDM:83,Jordan Pickford:GK:83,James Ward-Prowse:CM:82,Ruben Loftus-Cheek:CM:82,Dean Henderson:GK:81,Marc Albrighton:RM:76,Kadeem Harris:LM:68,Lee Tomlin:CF:68",
  "England|2021": "Harry Kane:ST:91,Jack Grealish:LW:90,Jadon Sancho:LW:90,Raheem Sterling:RW:90,Trent Alexander-Arnold:RB:90,Declan Rice:CM:89,Jude Bellingham:CAM:89,Mason Mount:CAM:89,Bukayo Saka:RW:88,Reece James:RB:87,Ben Chilwell:LB:86,Dominic Calvert-Lewin:ST:86,Fikayo Tomori:CB:86,Harry Maguire:CB:86,Kalvin Phillips:CDM:85,Luke Shaw:LB:85,Tammy Abraham:ST:85,James Ward-Prowse:CM:84,Joe Gomez:CB:84,Tyrone Mings:CB:84,Curtis Jones:CM:83,Aaron Ramsdale:GK:82,Conor Gallagher:CM:82,Dean Henderson:GK:82,Harry Winks:CDM:82,Marc Albrighton:RM:73,Conor Chaplin:CF:64",
  "England|2022": "Jude Bellingham:CAM:91,Phil Foden:CAM:91,Bukayo Saka:RW:90,Harry Kane:ST:90,Declan Rice:CM:89,Jadon Sancho:LW:89,Trent Alexander-Arnold:RB:89,Jack Grealish:LW:88,Raheem Sterling:RW:88,Reece James:RB:88,Fikayo Tomori:CB:86,Ivan Toney:ST:86,Kalvin Phillips:CDM:86,Tammy Abraham:ST:86,Ben Chilwell:LB:85,Harry Maguire:CB:85,Luke Shaw:LB:85,Conor Gallagher:CM:84,James Ward-Prowse:CM:84,Marc Gu\xE9hi:CB:84,Aaron Ramsdale:GK:83,Curtis Jones:CM:83,Eric Dier:CB:83,Jordan Pickford:GK:83,Oliver Skipp:CDM:80,Marc Albrighton:RM:70,Conor Chaplin:CF:64",
  "England|2023": "Jude Bellingham:CAM:93,Bukayo Saka:RW:91,Declan Rice:CM:91,Harry Kane:ST:91,Phil Foden:CAM:91,Jack Grealish:LW:89,Marcus Rashford:LW:89,Reece James:RB:88,Trent Alexander-Arnold:RB:88,Levi Colwill:CB:87,Ollie Watkins:ST:87,Raheem Sterling:RW:87,Fikayo Tomori:CB:86,Ivan Toney:ST:86,Aaron Ramsdale:GK:85,Conor Gallagher:CM:85,Jacob Ramsey:CM:85,James Ward-Prowse:CM:85,John Stones:CB:85,Luke Shaw:LB:85,Marc Gu\xE9hi:CB:85,Ben Chilwell:LB:84,Jordan Pickford:GK:82,Conor Chaplin:CF:70,Ryan Longman:RM:70,Kadeem Harris:LM:67",
  "England|2024": "Jude Bellingham:CAM:93,Bukayo Saka:RW:92,Cole Palmer:CAM:92,Declan Rice:CM:91,Harry Kane:ST:90,Trent Alexander-Arnold:RB:89,Jack Grealish:LW:88,Ollie Watkins:ST:88,Anthony Gordon:LW:87,Ben White:RB:87,Kobbie Mainoo:CM:87,Levi Colwill:CB:87,Conor Gallagher:CM:86,Curtis Jones:CM:86,Dominic Solanke:ST:86,Jarrod Bowen:RW:86,Marc Gu\xE9hi:CB:86,Fikayo Tomori:CB:85,Jarrad Branthwaite:CB:85,Luke Shaw:LB:84,Ben Chilwell:LB:83,Aaron Ramsdale:GK:82,Jordan Pickford:GK:82,Keane Lewis-Potter:LM:80,Conor Chaplin:CF:76,Tom Fellows:RM:70",
  "England|2025": "Jude Bellingham:CAM:93,Bukayo Saka:RW:92,Phil Foden:CAM:92,Declan Rice:CM:91,Harry Kane:ST:89,Trent Alexander-Arnold:RB:89,Anthony Gordon:LW:88,Elliot Anderson:CM:87,Levi Colwill:CB:87,Marc Gu\xE9hi:CB:87,Ben White:RB:86,Curtis Jones:CM:86,Jamie Gittens:LW:86,Jarrad Branthwaite:CB:86,Kobbie Mainoo:CM:86,Mason Greenwood:RW:86,Myles Lewis-Skelly:LB:86,Ollie Watkins:ST:86,Dominic Solanke:ST:85,Jarell Quansah:CB:85,Nico O'Reilly:LB:85,Dean Henderson:GK:83,James Trafford:GK:83,Keane Lewis-Potter:LM:82,Tom Fellows:RM:77,Conor Chaplin:CF:74",
  "England|2026": "Jude Bellingham:CAM:92,Bukayo Saka:RW:91,Cole Palmer:CAM:91,Declan Rice:CM:91,Harry Kane:ST:88,Marc Gu\xE9hi:CB:88,Trent Alexander-Arnold:RB:88,Anthony Gordon:LW:87,Elliot Anderson:CM:87,Mason Greenwood:RW:87,Reece James:RB:87,Jarell Quansah:CB:86,Jarrad Branthwaite:CB:86,Kobbie Mainoo:CM:86,Levi Colwill:CB:86,Nico O'Reilly:LB:86,Alex Scott:CM:85,Marcus Rashford:LW:85,Dominic Solanke:ST:84,Lewis Hall:LB:84,Liam Delap:ST:84,Dean Henderson:GK:83,James Trafford:GK:82,Keane Lewis-Potter:LM:82,Tom Fellows:RM:76",
  "France|2016": "Antoine Griezmann:CF:89,Paul Pogba:CM:89,Karim Benzema:ST:87,Alexandre Lacazette:ST:85,Anthony Martial:ST:84,Blaise Matuidi:CM:83,Dimitri Payet:CAM:83,Eliaquim Mangala:CB:83,Morgan Schneiderlin:CDM:83,N'Golo Kant\xE9:CDM:83,Rapha\xEBl Varane:CB:83,Hugo Lloris:GK:82,Laurent Koscielny:CB:82,Layvin Kurzawa:LB:82,Samuel Umtiti:CB:82,Kingsley Coman:LW:81,Moussa Sissoko:CM:81,Samir Nasri:CAM:81,Corentin Tolisso:CM:80,Lucas Digne:LB:80,Djibril Sidib\xE9:RB:78,Florian Thauvin:RW:78,Alphonse Areola:GK:77,Franck Rib\xE9ry:LW:77,Mathieu Debuchy:RB:77,Jonathan Biabiany:RW:76,Jonathan Schmid:RM:72,Romain Philippoteaux:LM:68",
  "France|2017": "Kylian Mbapp\xE9:ST:90,Antoine Griezmann:CF:89,Paul Pogba:CM:89,Karim Benzema:ST:87,Alexandre Lacazette:ST:86,N'Golo Kant\xE9:CDM:86,Corentin Tolisso:CM:85,Kingsley Coman:LW:84,Rapha\xEBl Varane:CB:84,Benjamin Mendy:LB:83,Blaise Matuidi:CM:83,Dimitri Payet:CAM:83,Samuel Umtiti:CB:83,Steven Nzonzi:CDM:83,Thomas Lemar:CAM:83,Adrien Rabiot:CM:82,Hugo Lloris:GK:82,Laurent Koscielny:CB:82,Layvin Kurzawa:LB:82,Dayot Upamecano:CB:81,Djibril Sidib\xE9:RB:80,Florian Thauvin:RW:80,Allan Saint-Maximin:LW:77,Alphonse Areola:GK:77,Anthony Knockaert:RW:76,S\xE9bastien Corchia:RB:76,Jonathan Schmid:RM:72,Romain Philippoteaux:LM:68",
  "France|2018": "Kylian Mbapp\xE9:ST:94,Antoine Griezmann:CF:92,N'Golo Kant\xE9:CDM:90,Paul Pogba:CM:90,Ousmane Demb\xE9l\xE9:ST:89,Rapha\xEBl Varane:CB:89,Alexandre Lacazette:ST:88,Nabil Fekir:CAM:88,Samuel Umtiti:CB:88,Thomas Lemar:CAM:88,Lucas Hern\xE1ndez:LB:87,Adrien Rabiot:CM:86,Benjamin Mendy:LB:86,Corentin Tolisso:CM:86,Florian Thauvin:RW:86,Kingsley Coman:LW:86,Tanguy Ndomb\xE9l\xE9:CM:86,Benjamin Pavard:CB:85,Cl\xE9ment Lenglet:CB:85,Tiemou\xE9 Bakayoko:CDM:85,Hugo Lloris:GK:83,Djibril Sidib\xE9:RB:82,Allan Saint-Maximin:LW:81,Alphonse Areola:GK:79,Nordi Mukiele:RB:79,Anthony Knockaert:RW:76,Ludovic Blas:RM:73,Romain Philippoteaux:LM:68",
  "France|2019": "Kylian Mbapp\xE9:ST:94,Antoine Griezmann:CF:92,Ousmane Demb\xE9l\xE9:ST:91,N'Golo Kant\xE9:CDM:90,Paul Pogba:CM:90,Rapha\xEBl Varane:CB:89,Alexandre Lacazette:ST:88,Lucas Hern\xE1ndez:LB:88,Tanguy Ndomb\xE9l\xE9:CM:88,Cl\xE9ment Lenglet:CB:87,Kingsley Coman:LW:87,Nabil Fekir:CAM:87,Dayot Upamecano:CB:86,Florian Thauvin:RW:86,Ibrahima Konat\xE9:CB:86,Matt\xE9o Guendouzi:CM:86,Thomas Lemar:CAM:86,Benjamin Mendy:LB:85,Corentin Tolisso:CM:85,Tiemou\xE9 Bakayoko:CDM:84,Allan Saint-Maximin:LW:82,Hugo Lloris:GK:82,Jules Kound\xE9:RB:82,Mike Maignan:GK:82,Nordi Mukiele:RB:82,Moussa Diaby:RW:81,Ludovic Blas:RM:77,Bryan Pel\xE9:LM:68",
  "France|2020": "Kylian Mbapp\xE9:ST:93,Antoine Griezmann:CF:90,N'Golo Kant\xE9:CDM:89,Paul Pogba:CM:89,Ousmane Demb\xE9l\xE9:ST:88,Rapha\xEBl Varane:CB:88,Alexandre Lacazette:ST:87,Dayot Upamecano:CB:87,Lucas Hern\xE1ndez:LB:87,Benjamin Pavard:CB:86,Cl\xE9ment Lenglet:CB:86,Eduardo Camavinga:CM:86,Kingsley Coman:LW:86,Matt\xE9o Guendouzi:CM:86,Tanguy Ndomb\xE9l\xE9:CM:86,Theo Hern\xE1ndez:LB:86,Jonathan Ikon\xE9:RW:85,Jules Kound\xE9:RB:85,Allan Saint-Maximin:LW:84,Boubacar Kamara:CDM:84,Florian Thauvin:RW:84,Nabil Fekir:CAM:84,Jeff Reine-Ad\xE9la\xEFde:CAM:82,Nordi Mukiele:RB:82,Mike Maignan:GK:81,Alphonse Areola:GK:79,Ludovic Blas:RM:78,Bryan Pel\xE9:LM:68",
  "France|2021": "Kylian Mbapp\xE9:ST:93,Kingsley Coman:LW:88,Rapha\xEBl Varane:CB:88,Antoine Griezmann:CF:87,Christopher Nkunku:ST:87,Dayot Upamecano:CB:87,Eduardo Camavinga:CM:87,Jules Kound\xE9:RB:87,N'Golo Kant\xE9:CDM:87,Paul Pogba:CM:87,Anthony Martial:ST:86,Ferland Mendy:LB:86,Lucas Hern\xE1ndez:LB:86,Moussa Diaby:RW:86,Tanguy Ndomb\xE9l\xE9:CM:86,Aur\xE9lien Tchouam\xE9ni:CDM:85,Cl\xE9ment Lenglet:CB:85,Presnel Kimpembe:CB:85,Thomas Lemar:CAM:85,Allan Saint-Maximin:LW:84,Jordan Veretout:CM:84,Florian Thauvin:RW:83,Nabil Fekir:CAM:83,Mike Maignan:GK:82,Nordi Mukiele:RB:82,Illan Meslier:GK:81,Ludovic Blas:RM:80",
  "France|2022": "Kylian Mbapp\xE9:ST:93,Aur\xE9lien Tchouam\xE9ni:CDM:90,Christopher Nkunku:ST:89,Wesley Fofana:CB:88,Dayot Upamecano:CB:87,Eduardo Camavinga:CM:87,Jules Kound\xE9:RB:87,Kingsley Coman:LW:87,Moussa Diaby:RW:87,Ousmane Demb\xE9l\xE9:ST:87,Rapha\xEBl Varane:CB:87,Theo Hern\xE1ndez:LB:87,Lucas Hern\xE1ndez:LB:86,Paul Pogba:CM:86,William Saliba:CB:86,Allan Saint-Maximin:LW:85,N'Golo Kant\xE9:CDM:85,Nabil Fekir:CAM:85,Thomas Lemar:CAM:85,Antoine Griezmann:CF:84,Mike Maignan:GK:84,Tanguy Ndomb\xE9l\xE9:CM:84,Adrien Rabiot:CM:82,Illan Meslier:GK:82,Michael Olise:RW:82,Nordi Mukiele:RB:81,Ludovic Blas:RM:80",
  "France|2023": "Kylian Mbapp\xE9:ST:93,Eduardo Camavinga:CM:90,Christopher Nkunku:ST:89,Randal Kolo Muani:ST:89,William Saliba:CB:89,Kingsley Coman:LW:88,Dayot Upamecano:CB:87,Jules Kound\xE9:RB:87,Moussa Diaby:RW:87,Theo Hern\xE1ndez:LB:87,Warren Za\xEFre-Emery:CM:87,Wesley Fofana:CB:87,Lucas Hern\xE1ndez:LB:86,Michael Olise:RW:86,Mike Maignan:GK:86,Adrien Rabiot:CM:85,Axel Disasi:CB:85,Kh\xE9phren Thuram:CM:85,Allan Saint-Maximin:LW:84,Nabil Fekir:CAM:83,Rayan Cherki:CAM:83,Antoine Griezmann:CF:82,Ludovic Blas:RM:82,Malo Gusto:RB:82,Illan Meslier:GK:81,Alan Virginius:LM:64",
  "France|2024": "Kylian Mbapp\xE9:ST:93,Eduardo Camavinga:CM:90,Marcus Thuram:ST:89,William Saliba:CB:89,Bradley Barcola:LW:88,Christopher Nkunku:ST:88,Michael Olise:RW:88,Jules Kound\xE9:RB:87,Leny Yoro:CB:87,Moussa Diaby:RW:87,Theo Hern\xE1ndez:LB:87,Warren Za\xEFre-Emery:CM:87,Benjamin Pavard:CB:86,Castello Lukeba:CB:86,Kingsley Coman:LW:86,Enzo Millot:CAM:85,Lucas Hern\xE1ndez:LB:85,Mike Maignan:GK:85,Adrien Rabiot:CM:84,Kh\xE9phren Thuram:CM:84,Malo Gusto:RB:84,Lucas Chevalier:GK:83,Rayan Cherki:CAM:83,Antoine Griezmann:CF:82,Ludovic Blas:RM:80,Alan Virginius:LM:72",
  "France|2025": "Kylian Mbapp\xE9:ST:94,Michael Olise:RW:92,D\xE9sir\xE9 Dou\xE9:RW:90,Ousmane Demb\xE9l\xE9:ST:90,William Saliba:CB:90,Hugo Ekitik\xE9:ST:89,Bradley Barcola:LW:88,Dayot Upamecano:CB:88,Eduardo Camavinga:CM:88,Jules Kound\xE9:RB:88,Ibrahima Konat\xE9:CB:87,Leny Yoro:CB:87,Warren Za\xEFre-Emery:CM:87,Manu Kon\xE9:CM:86,Rayan Cherki:CAM:86,Kh\xE9phren Thuram:CM:85,Lucas Chevalier:GK:85,Theo Hern\xE1ndez:LB:85,Enzo Millot:CAM:84,Malo Gusto:RB:84,Kingsley Coman:LW:83,Lucas Hern\xE1ndez:LB:83,Mike Maignan:GK:82,Antoine Griezmann:CF:80,Ludovic Blas:RM:80,Alan Virginius:LM:72",
  "France|2026": "Kylian Mbapp\xE9:ST:94,Michael Olise:RW:92,D\xE9sir\xE9 Dou\xE9:RW:90,Hugo Ekitik\xE9:ST:90,Ousmane Demb\xE9l\xE9:ST:90,William Saliba:CB:90,Bradley Barcola:LW:88,Dayot Upamecano:CB:88,Jules Kound\xE9:RB:88,Rayan Cherki:CAM:88,J\xE9r\xE9my Jacquet:CB:87,Warren Za\xEFre-Emery:CM:87,Castello Lukeba:CB:86,Eduardo Camavinga:CM:86,Manu Kon\xE9:CM:86,Kh\xE9phren Thuram:CM:85,Malo Gusto:RB:84,Enzo Millot:CAM:83,Lucas Chevalier:GK:83,Theo Hern\xE1ndez:LB:83,Adrien Truffert:LB:82,Jean-Matt\xE9o Bahoya:LW:82,Mike Maignan:GK:82,Ludovic Blas:RM:77,Alan Virginius:LM:73",
  "Georgia|2024": "Khvicha Kvaratskhelia:LW:89,Giorgi Mamardashvili:GK:86,Georges Mikautadze:ST:81,Saba Goglichidze:CB:76,Zuriko Davitashvili:LW:76,Irakli Azarovi:LB:73,Otar Kiteishvili:CAM:73,Giorgi Chakvetadze:CAM:72,Giorgi Kochorashvili:CM:72,Giorgi Gocholeishvili:RB:70,Otar Kakabadze:RB:68,Roin Odishelidze:CF:64,Vakhtang Chanturishvili:LM:64",
  "Georgia|2026": "Khvicha Kvaratskhelia:LW:90,Georges Mikautadze:ST:83,Giorgi Mamardashvili:GK:83,Zuriko Davitashvili:LW:77,Otar Kiteishvili:CAM:74,Giorgi Chakvetadze:CAM:73,Giorgi Kochorashvili:CM:73,Giorgi Gocholeishvili:RB:70,Irakli Azarovi:LB:70,Otar Kakabadze:RB:68,Eldar Parkinashvili:LM:64,Saba Kharebashvili:LB:64,Tornike Gaprindashvili:RM:64",
  "Germany|2016": "Thomas M\xFCller:CF:89,Toni Kroos:CM:87,J\xE9r\xF4me Boateng:CB:86,Manuel Neuer:GK:86,Marco Reus:CAM:86,Mesut \xD6zil:CAM:86,Mats Hummels:CB:85,\u0130lkay G\xFCndo\u011Fan:CM:83,Julian Draxler:LW:83,Leroy San\xE9:RW:83,Shkodran Mustafi:CB:83,Andr\xE9 Sch\xFCrrle:LW:82,Karim Bellarabi:RW:82,Joshua Kimmich:CDM:81,Lars Bender:CDM:81,Sami Khedira:CM:81,Benedikt H\xF6wedes:CB:80,Bernd Leno:GK:80,Max Meyer:CM:80,Philipp Lahm:RB:80,Jonas Hector:LB:79,Mario G\xF3mez:ST:78,Marcel Schmelzer:LB:77,Lukas Podolski:ST:76,Mitchell Weiser:RB:76,Timo Werner:ST:76,Marcel Risse:RM:72,Axel Bellinghausen:LM:64",
  "Germany|2017": "Toni Kroos:CM:88,Thomas M\xFCller:CF:87,Timo Werner:ST:87,Leroy San\xE9:RW:86,Manuel Neuer:GK:86,Mesut \xD6zil:CAM:86,J\xE9r\xF4me Boateng:CB:85,Joshua Kimmich:CDM:85,Leon Goretzka:CM:85,Marco Reus:CAM:85,Mats Hummels:CB:85,Julian Draxler:LW:84,\u0130lkay G\xFCndo\u011Fan:CM:83,Julian Weigl:CDM:83,Niklas S\xFCle:CB:83,Sami Khedira:CM:83,Shkodran Mustafi:CB:83,Andr\xE9 Sch\xFCrrle:LW:82,Karim Bellarabi:RW:82,Marc-Andr\xE9 ter Stegen:GK:82,Jonas Hector:LB:81,Kai Havertz:ST:80,Benjamin Henrichs:RB:78,Mark Uth:ST:78,Mitchell Weiser:RB:78,Marcel Schmelzer:LB:77,Marcel Risse:RM:73,Axel Bellinghausen:LM:64",
  "Germany|2018": "Leroy San\xE9:RW:90,Marc-Andr\xE9 ter Stegen:GK:89,Toni Kroos:CM:89,Kai Havertz:ST:88,Timo Werner:ST:88,Joshua Kimmich:CDM:87,Mats Hummels:CB:87,Thomas M\xFCller:CF:87,Antonio R\xFCdiger:CB:86,J\xE9r\xF4me Boateng:CB:86,Julian Brandt:CAM:86,Marco Reus:CAM:86,Niklas S\xFCle:CB:86,\u0130lkay G\xFCndo\u011Fan:CM:85,Julian Draxler:LW:85,Leon Goretzka:CM:85,Manuel Neuer:GK:84,Julian Weigl:CDM:83,Sami Khedira:CM:83,Mark Uth:ST:82,Benjamin Henrichs:RB:81,Nico Schulz:LB:81,Philipp Max:LB:81,Andr\xE9 Sch\xFCrrle:LW:79,Karim Bellarabi:RW:78,Mitchell Weiser:RB:78,Felix Klaus:RM:73,Keanan Bennetts:LM:68",
  "Germany|2019": "Kai Havertz:ST:90,Leroy San\xE9:RW:90,Marc-Andr\xE9 ter Stegen:GK:90,Joshua Kimmich:CDM:89,Serge Gnabry:CF:89,Timo Werner:ST:89,Niklas S\xFCle:CB:87,Toni Kroos:CM:87,Antonio R\xFCdiger:CB:86,\u0130lkay G\xFCndo\u011Fan:CM:86,Julian Brandt:CAM:86,Leon Goretzka:CM:86,Marco Reus:CAM:86,Emre Can:CB:85,Jonathan Tah:CB:85,Bernd Leno:GK:84,Julian Draxler:LW:84,Kerem Demirbay:CM:84,Julian Weigl:CDM:82,Nico Schulz:LB:82,Davie Selke:ST:81,Philipp Max:LB:80,Benjamin Henrichs:RB:79,Karim Bellarabi:RW:79,Mitchell Weiser:RB:79,Andr\xE9 Sch\xFCrrle:LW:78,Felix Klaus:RM:70,Christopher Lenz:LM:68",
  "Germany|2020": "Serge Gnabry:CF:90,Joshua Kimmich:CDM:89,Kai Havertz:ST:89,Leroy San\xE9:RW:89,Marc-Andr\xE9 ter Stegen:GK:89,Timo Werner:ST:89,Leon Goretzka:CM:87,Niklas S\xFCle:CB:86,Toni Kroos:CM:86,Antonio R\xFCdiger:CB:85,\u0130lkay G\xFCndo\u011Fan:CM:85,Julian Brandt:CAM:85,Lukas Klostermann:CB:85,Bernd Leno:GK:84,Marco Reus:CAM:84,Matthias Ginter:CB:84,Florian Neuhaus:CM:83,Robin Gosens:LB:83,Julian Draxler:LW:82,Julian Weigl:CDM:81,Luca Waldschmidt:ST:80,Nico Schulz:LB:80,Benjamin Henrichs:RB:78,Karim Bellarabi:RW:78,Ridle Baku:RB:78,Linton Maina:LW:77,Christopher Lenz:LM:72,Felix Klaus:RM:70",
  "Germany|2021": "Joshua Kimmich:CDM:90,Marc-Andr\xE9 ter Stegen:GK:89,Florian Wirtz:CAM:88,Kai Havertz:ST:88,Leon Goretzka:CM:88,Leroy San\xE9:RW:88,Serge Gnabry:CF:88,Timo Werner:ST:88,Jamal Musiala:CAM:87,Toni Kroos:CM:86,Florian Neuhaus:CM:85,\u0130lkay G\xFCndo\u011Fan:CM:85,Niklas S\xFCle:CB:85,Antonio R\xFCdiger:CB:84,Karim Adeyemi:RW:84,Lukas Klostermann:CB:84,Matthias Ginter:CB:84,Robin Gosens:LB:84,Bernd Leno:GK:82,Julian Weigl:CDM:82,Ridle Baku:RB:82,Julian Draxler:LW:81,Jonathan Burkardt:ST:80,Philipp Max:LB:80,Benjamin Henrichs:RB:78,Amin Younes:LW:77,Felix Klaus:RM:68",
  "Germany|2022": "Jamal Musiala:CAM:90,Joshua Kimmich:CDM:89,Florian Wirtz:CAM:88,Kai Havertz:ST:88,Leon Goretzka:CM:88,Leroy San\xE9:RW:88,Serge Gnabry:CF:88,Antonio R\xFCdiger:CB:85,Timo Werner:ST:85,Karim Adeyemi:RW:84,Nico Schlotterbeck:CB:84,Niklas S\xFCle:CB:84,David Raum:LB:83,Marc-Andr\xE9 ter Stegen:GK:83,Robin Gosens:LB:83,Youssoufa Moukoko:ST:83,\u0130lkay G\xFCndo\u011Fan:CM:82,Jonathan Tah:CB:82,Julian Weigl:CDM:82,Florian Neuhaus:CM:81,Ridle Baku:RB:81,Toni Kroos:CM:81,Benjamin Henrichs:RB:80,Julian Draxler:LW:80,Manuel Neuer:GK:79,Kevin Schade:LW:78,Idrissa Tour\xE9:RM:68",
  "Germany|2023": "Jamal Musiala:CAM:91,Florian Wirtz:CAM:90,Leroy San\xE9:RW:89,Kai Havertz:ST:87,Serge Gnabry:CF:87,Leon Goretzka:CM:86,Karim Adeyemi:RW:85,Marc-Andr\xE9 ter Stegen:GK:85,Nico Schlotterbeck:CB:85,Antonio R\xFCdiger:CB:84,Niklas S\xFCle:CB:84,Malick Thiaw:CB:83,Youssoufa Moukoko:ST:83,Felix Nmecha:CM:82,Kevin Schade:LW:82,Timo Werner:ST:82,Benjamin Henrichs:RB:81,David Raum:LB:81,\u0130lkay G\xFCndo\u011Fan:CM:81,Chris F\xFChrich:LW:80,Toni Kroos:CM:80,Bernd Leno:GK:79,Ridle Baku:RB:79,Robin Gosens:LB:79,Christopher Lenz:LM:73,Idrissa Tour\xE9:RM:70",
  "Germany|2024": "Florian Wirtz:CAM:92,Jamal Musiala:CAM:92,Kai Havertz:ST:89,Leroy San\xE9:RW:88,Nico Schlotterbeck:CB:85,Serge Gnabry:CF:85,Karim Adeyemi:RW:84,Chris F\xFChrich:LW:83,Deniz Undav:ST:83,Felix Nmecha:CM:83,Jonathan Tah:CB:83,Leon Goretzka:CM:83,Marc-Andr\xE9 ter Stegen:GK:83,Maximilian Beier:ST:83,Yann Bisseck:CB:83,Antonio R\xFCdiger:CB:82,David Raum:LB:82,Kevin Schade:LW:82,Benjamin Henrichs:RB:81,Maximilian Mittelst\xE4dt:LB:81,Diant Ramaj:GK:80,\u0130lkay G\xFCndo\u011Fan:CM:80,Rocco Reitz:CM:79,Josha Vagnoman:RB:78,Christopher Lenz:LM:73,Idrissa Tour\xE9:RM:70",
  "Germany|2025": "Florian Wirtz:CAM:92,Jamal Musiala:CAM:92,Kai Havertz:ST:88,Nick Woltemade:ST:88,Karim Adeyemi:RW:87,Nico Schlotterbeck:CB:87,Felix Nmecha:CM:86,Leroy San\xE9:RW:85,Malick Thiaw:CB:85,Said El Mala:LW:85,Tom Bischof:CM:85,Jonathan Burkardt:ST:84,Kevin Schade:LW:84,Nathaniel Brown:LB:84,Yann Bisseck:CB:84,Assan Ou\xE9draogo:CM:83,Jonathan Tah:CB:83,Leon Goretzka:CM:82,Serge Gnabry:CF:82,David Raum:LB:81,Noah Atubolu:GK:81,Benjamin Henrichs:RB:79,Alexander N\xFCbel:GK:78,Ridle Baku:RB:78,Idrissa Tour\xE9:RM:74,Christopher Lenz:LM:70",
  "Germany|2026": "Florian Wirtz:CAM:91,Jamal Musiala:CAM:91,Nick Woltemade:ST:88,Nico Schlotterbeck:CB:87,Felix Nmecha:CM:86,Kai Havertz:ST:86,Karim Adeyemi:RW:86,Malick Thiaw:CB:86,Jamie Leweling:RW:85,Maximilian Beier:ST:85,Tom Bischof:CM:85,Yann Bisseck:CB:85,Kevin Schade:LW:84,Nathaniel Brown:LB:84,Said El Mala:LW:84,Assan Ou\xE9draogo:CM:83,Finn Jeltsch:CB:83,David Raum:LB:82,Noah Atubolu:GK:81,Rocco Reitz:CM:81,Jonas Urbig:GK:79,Ridle Baku:RB:78,Benjamin Henrichs:RB:77,Idrissa Tour\xE9:RM:74,Christopher Lenz:LM:68",
  "Ghana|2016": "I\xF1aki Williams:RW:81,Andr\xE9 Ayew:ST:80,Abdul Rahman Baba:LB:79,Kwadwo Asamoah:LM:79,Alfred Duncan:CM:76,Jordan Ayew:ST:76,Emmanuel Badu:CM:74,Godfred Donsah:CDM:74,Asamoah Gyan:ST:73,Daniel Amartey:CB:73,Frank Acheampong:LW:73,Thomas Partey:CDM:73,Christian Atsu:LW:72,Afriyie Acquah:CM:70,Mubarak Wakaso:CM:70,Bernard Mensah:CAM:68,David Accam:RW:68,Kevin-Prince Boateng:CAM:68,Adam Kwarasey:GK:64,Alex Asamoah:CF:64,Emmanuel Gyasi:RM:64,Harrison Afful:RB:64,Phil Ofosu-Ayeh:RB:64",
  "Ghana|2017": "I\xF1aki Williams:RW:82,Andr\xE9 Ayew:ST:80,Kwadwo Asamoah:LM:79,Alfred Duncan:CM:77,Abdul Rahman Baba:LB:76,Godfred Donsah:CDM:76,Jordan Ayew:ST:76,Emmanuel Badu:CM:74,Asamoah Gyan:ST:73,Christian Atsu:LW:73,Daniel Amartey:CB:73,Derrick Luckassen:CB:73,Frank Acheampong:LW:73,Kevin-Prince Boateng:CAM:73,Thomas Partey:CDM:73,Afriyie Acquah:CM:70,Albert Adomah:RW:70,Andy Yiadom:RB:70,Daniel Opare:RB:70,Nana Asare:LB:70,Bernard Mensah:CAM:68,Raman Chibsah:CM:68,Adam Kwarasey:GK:64,Alex Asamoah:CF:64,Emmanuel Gyasi:RM:64",
  "Ghana|2020": "Thomas Partey:CDM:86,I\xF1aki Williams:RW:85,Tariq Lamptey:RB:80,Alfred Duncan:CM:79,Mohammed Kudus:RW:78,Jeffrey Schlupp:LM:77,Jordan Ayew:ST:77,Elisha Owusu:CDM:76,Alexander Djiku:CB:75,Andr\xE9 Ayew:ST:74,Caleb Ekuban:ST:74,Daniel Amartey:CB:74,Frank Acheampong:LW:74,Bernard Mensah:CAM:73,Christian Atsu:LW:73,Andy Yiadom:RB:72,Kasim Adams:CB:72,Abdul Rahman Baba:LB:70,Clifford Aboagye:CM:70,Gideon Mensah:LB:70,Kevin-Prince Boateng:CAM:70,Majeed Ashimeru:CM:70,Mubarak Wakaso:CM:70,Emmanuel Gyasi:RM:68,Lawrence Ati Zigi:GK:68,Kelvin Inkoom:CF:64",
  "Ghana|2021": "Thomas Partey:CDM:86,I\xF1aki Williams:RW:82,Kamaldeen Sulemana:LW:81,Tariq Lamptey:RB:80,Mohammed Kudus:RW:79,Alfred Duncan:CM:78,Mohammed Salisu:CB:77,Alexander Djiku:CB:76,Caleb Ekuban:ST:76,Jordan Ayew:ST:76,Joseph Aidoo:CB:76,Kamal Sowah:CM:76,Elisha Owusu:CDM:74,Frank Acheampong:LW:74,Daniel Amartey:CB:73,Andr\xE9 Ayew:ST:72,Abdul Rahman Baba:LB:70,Daniel-Kofi Kyereh:CAM:70,Emmanuel Gyasi:RM:70,Iddrisu Baba:CM:70,Kevin-Prince Boateng:CAM:70,Majeed Ashimeru:CM:70,Andy Yiadom:RB:68,Lawrence Ati Zigi:GK:68,Clinton Duodu:CF:64,Lumor Agbenyenu:LB:64",
  "Ghana|2022": "Thomas Partey:CDM:85,I\xF1aki Williams:RW:82,Mohammed Kudus:RW:81,Kamaldeen Sulemana:LW:80,Mohammed Salisu:CB:80,Tariq Lamptey:RB:80,Daniel Amartey:CB:79,Alexander Djiku:CB:77,Alfred Duncan:CM:77,Salis Abdul Samed:CDM:77,Daniel-Kofi Kyereh:CAM:76,Francis Amuzu:LW:76,Joseph Aidoo:CB:76,Jordan Ayew:ST:74,Kamal Sowah:CM:74,Benjamin Tetteh:ST:72,Bernard Mensah:CAM:72,Iddrisu Baba:CM:72,Majeed Ashimeru:CM:72,Emmanuel Gyasi:RM:70,Gideon Mensah:LB:70,Lawrence Ati Zigi:GK:70,Abdul Rahman Baba:LB:68,Andy Yiadom:RB:64,Charles Gyamfi Kamara:CF:64",
  "Ghana|2023": "Mohammed Kudus:RW:86,I\xF1aki Williams:RW:82,Kamaldeen Sulemana:LW:82,Mohammed Salisu:CB:80,Daniel Amartey:CB:78,Joseph Paintsil:LW:78,Tariq Lamptey:RB:78,Jeffrey Schlupp:LM:77,Alexander Djiku:CB:76,Alidu Seidu:CB:76,Amankwah Forson:CM:76,Daniel-Kofi Kyereh:CAM:76,Jordan Ayew:ST:73,Kamal Sowah:CM:72,Bernard Mensah:CAM:70,Derrick K\xF6hn:LB:70,Gideon Mensah:LB:70,Iddrisu Baba:CM:70,Lawrence Ati Zigi:GK:70,Emmanuel Gyasi:RM:68,Charles Gyamfi Kamara:CF:64,Richard Ofori:GK:64",
  "Ghana|2024": "Mohammed Kudus:RW:86,Antoine Semenyo:RW:83,Ibrahim Osman:LW:80,Mohammed Salisu:CB:79,Tariq Lamptey:RB:78,Alexander Djiku:CB:77,Alidu Seidu:CB:77,Joseph Paintsil:LW:77,Daniel Amartey:CB:76,Jeffrey Schlupp:LM:76,Derrick K\xF6hn:LB:74,Alfred Duncan:CM:72,Gideon Mensah:LB:72,Jordan Ayew:ST:72,Michael Baidoo:CAM:72,Augustine Boakye:CAM:70,Emmanuel Gyasi:RM:68,Lawrence Ati Zigi:GK:68,Marvin Senaya:RB:68,Arcadio Baidoo:CF:64",
  "Ghana|2025": "Antoine Semenyo:RW:88,Mohammed Kudus:RW:87,Kamaldeen Sulemana:LW:81,Brandon Thomas-Asante:ST:78,Ibrahim Osman:LW:78,Mohammed Salisu:CB:78,Tariq Lamptey:RB:78,Alidu Seidu:CB:77,Alexander Djiku:CB:76,Jeffrey Schlupp:LM:76,Jonas Adjetey:CB:76,Caleb Yirenkyi:CM:74,Ransford K\xF6nigsd\xF6rffer:ST:74,Amankwah Forson:CM:73,Mohammed Fuseini:ST:73,Gideon Mensah:LB:72,Ebenezer Annan:LB:70,Marvin Senaya:RB:70,Michael Baidoo:CAM:70,Emmanuel Gyasi:RM:68,Lawrence Ati Zigi:GK:68,Charles Gyamfi Kamara:CF:64",
  "Ghana|2026": "Antoine Semenyo:RW:89,Mohammed Kudus:RW:87,Kamaldeen Sulemana:LW:80,Brandon Thomas-Asante:ST:79,Christopher Bonsu Baah:LW:78,Kojo Peprah Oppong:CB:77,Mohammed Salisu:CB:77,Edmund Baidoo:ST:76,Jeffrey Schlupp:LM:76,Jonas Adjetey:CB:76,Alidu Seidu:CB:74,Augustine Boakye:CAM:74,Caleb Yirenkyi:CM:74,Amankwah Forson:CM:73,Tariq Lamptey:RB:73,Derrick K\xF6hn:LB:72,Ezekiel Alladoh:ST:72,Gideon Mensah:LB:72,Marvin Senaya:RB:70,Bernard Mensah:CAM:68,Lawrence Ati Zigi:GK:68,Emmanuel Gyasi:RM:64",
  "Greece|2016": "Konstantinos Manolas:CB:82,Sokratis:CB:82,Konstantinos Mitroglou:ST:78,Andreas Samaris:CDM:77,Konstantinos Fortounis:CAM:77,Kyriakos Papadopoulos:CB:76,Orestis Karnezis:GK:73,Nikolaos Karelis:ST:72,Panagiotis Kone:CM:72,Stefanos Athanasiadis:ST:72,Vasilios Torosidis:RB:72,Dimitrios Siovas:CB:70,Giannis Fetfatzidis:RW:70,Giannis Maniatis:CDM:70,Konstantinos Stafylidis:LB:70,Stefanos Kapino:GK:70,Dimitrios Pelkas:CAM:68,Jose Cholevas:LB:68,Zeca:CM:68,Anastasios Donis:LW:64,Charalampos Georgiou:RM:64,Charalampos Mavrias:RB:64,Dimitrios Kolovos:LW:64,Giannis Mystakidis:RW:64,Giannis Nalmpantis:LM:64,Michail Fragos:CF:64",
  "Greece|2017": "Konstantinos Manolas:CB:84,Sokratis:CB:83,Panagiotis Retsos:CB:80,Konstantinos Mitroglou:ST:78,Konstantinos Fortounis:CAM:77,Kyriakos Papadopoulos:CB:77,Andreas Samaris:CDM:76,Konstantinos Stafylidis:LB:73,Nikolaos Karelis:ST:73,Orestis Karnezis:GK:73,Giannis Fetfatzidis:RW:72,Anastasios Donis:LW:70,Panagiotis Kone:CM:70,Stefanos Kapino:GK:70,Zeca:CM:70,Athanasios Androutsos:CM:68,Charalampos Lykogiannis:LB:68,Dimitrios Pelkas:CAM:68,Manolis Siopis:CDM:68,Dimitrios Kolovos:LW:64,Dimitrios Limnios:RW:64,Kyriakos Kivrakidis:RB:64,Michail Fragos:CF:64,Michalis Bakakis:RB:64,Nikolaos Galas:LM:64,Spyros Gougoudis:RM:64",
  "Greece|2018": "Konstantinos Manolas:CB:86,Sokratis:CB:81,Panagiotis Retsos:CB:80,Konstantinos Mitroglou:ST:77,Andreas Samaris:CDM:76,Konstantinos Fortounis:CAM:76,Kyriakos Papadopoulos:CB:76,Odysseas Vlachodimos:GK:74,Giannis Fetfatzidis:RW:73,Anastasios Donis:LW:72,Dimitrios Pelkas:CAM:72,Konstantinos Galanopoulos:CM:72,Konstantinos Stafylidis:LB:72,Alexandros Paschalakis:GK:68,Dimitrios Kourbelis:CDM:68,Jose Cholevas:LB:68,Lazaros Christodoulopoulos:RW:68,Michalis Bakakis:RB:68,Anastasios Chatzigiovanis:LW:64,Andreas Vlachomitros:CF:64,Giannis Masouras:RB:64,Nikolaos Galas:LM:64",
  "Greece|2019": "Konstantinos Manolas:CB:86,Sokratis:CB:81,Odysseas Vlachodimos:GK:79,Panagiotis Retsos:CB:79,Andreas Samaris:CDM:77,Konstantinos Mitroglou:ST:76,Dimitrios Siovas:CB:74,Leonardo Koutris:LB:74,Dimitrios Giannoulis:LB:73,Dimitrios Limnios:RW:73,Efthymios Koulouris:ST:73,Anastasios Donis:LW:72,Dimitrios Pelkas:CAM:72,Konstantinos Galanopoulos:CM:72,Petros Mantalos:CAM:72,Andreas Bouchalakis:CM:68,Georgios Masouras:LW:68,Michalis Bakakis:RB:68,Orestis Karnezis:GK:68,Taxiarchis Fountas:CF:68,Giannis Fetfatzidis:RW:64,Marios Vrousai:RB:64,Nikolaos Galas:LM:64",
  "Greece|2020": "Konstantinos Manolas:CB:84,Odysseas Vlachodimos:GK:80,Konstantinos Tsimikas:LB:77,Konstantinos Fortounis:CAM:76,George Baldock:RB:75,Andreas Samaris:CDM:74,Dimitrios Giannoulis:LB:74,Dimitrios Siovas:CB:74,Vasilios Barkas:GK:73,Christos Tzolis:LW:72,Dimitrios Limnios:RW:72,Petros Mantalos:CAM:72,Taxiarchis Fountas:CF:72,Vangelis Pavlidis:ST:72,Anastasios Donis:LW:70,Andreas Bouchalakis:CM:70,Efthymios Koulouris:ST:70,Konstantinos Galanopoulos:CM:70,Dimitrios Kourbelis:CDM:68,Giannis Fetfatzidis:RW:68,Michalis Bakakis:RB:64,Nikolaos Galas:LM:64",
  "Greece|2021": "Konstantinos Manolas:CB:83,Konstantinos Mavropanos:CB:80,Odysseas Vlachodimos:GK:80,Christos Tzolis:LW:78,Anastasios Bakasetas:CAM:77,Konstantinos Tsimikas:LB:77,Dimitrios Giannoulis:LB:76,Dimitrios Pelkas:CAM:76,Georgios Masouras:LW:76,George Baldock:RB:75,Andreas Bouchalakis:CM:73,Andreas Samaris:CDM:72,Dimitrios Limnios:RW:72,Sokratis:CB:72,Vasilios Barkas:GK:72,Manolis Siopis:CDM:70,Taxiarchis Fountas:CF:70,Marios Vrousai:RB:68,Giannis Fetfatzidis:RW:64",
  "Greece|2022": "Konstantinos Tsimikas:LB:80,Odysseas Vlachodimos:GK:80,Konstantinos Mavropanos:CB:79,Anastasios Bakasetas:CAM:78,Christos Tzolis:LW:77,Georgios Masouras:LW:77,Vangelis Pavlidis:ST:76,Manolis Siopis:CDM:74,Andreas Bouchalakis:CM:73,Georgios Giakoumakis:ST:73,Georgios Kyriakopoulos:LB:73,Konstantinos Manolas:CB:73,Dimitrios Nikolaou:CB:72,George Baldock:RB:72,Giannis Michailidis:CB:72,Sotiris Alexandropoulos:CM:72,Anastasios Douvikas:ST:70,Konstantinos Fortounis:CAM:70,Dimitrios Limnios:RW:68,Georgios Athanasiadis:GK:68,Giannis Papanikolaou:CDM:68,Lefteris Lyratzis:RB:68,Andreas Vlachomitros:CF:64",
  "Greece|2023": "Konstantinos Tsimikas:LB:82,Vangelis Pavlidis:ST:82,Odysseas Vlachodimos:GK:80,Konstantinos Mavropanos:CB:79,Anastasios Bakasetas:CAM:78,Anastasios Douvikas:ST:78,Fotis Ioannidis:ST:77,Georgios Masouras:LW:74,Christos Tzolis:LW:73,Christos Zafeiris:CM:73,Taxiarchis Fountas:CF:73,Andreas Bouchalakis:CM:72,Dimitrios Giannoulis:LB:72,George Baldock:RB:72,Konstantinos Koulierakis:CB:72,Pantelis Hatzidiakos:CB:72,Dimitrios Pelkas:CAM:70,Sotiris Alexandropoulos:CM:70,Vasilios Barkas:GK:70,Dimitrios Limnios:RW:68,Georgios Vagiannidis:RB:68,Panos Katseris:RM:64",
  "Greece|2024": "Konstantinos Tsimikas:LB:82,Vangelis Pavlidis:ST:82,Konstantinos Mavropanos:CB:81,Christos Tzolis:LW:80,Fotis Ioannidis:ST:80,Giannis Konstantelias:CAM:80,Konstantinos Koulierakis:CB:79,Christos Zafeiris:CM:78,Georgios Giakoumakis:ST:77,Odysseas Vlachodimos:GK:77,Anastasios Bakasetas:CAM:76,Georgios Vagiannidis:RB:74,Konstantinos Tzolakis:GK:74,Panagiotis Retsos:CB:73,Taxiarchis Fountas:CF:72,Christos Mouzakitis:CM:70,Dimitrios Giannoulis:LB:70,George Baldock:RB:70,Panos Katseris:RM:70,Sotiris Alexandropoulos:CM:70,Anastasios Chatzigiovanis:LW:68",
  "Greece|2025": "Vangelis Pavlidis:ST:84,Christos Tzolis:LW:83,Konstantinos Karetsas:CAM:83,Charalampos Kostoulas:ST:82,Christos Mouzakitis:CM:82,Fotis Ioannidis:ST:82,Konstantinos Koulierakis:CB:82,Giannis Konstantelias:CAM:81,Konstantinos Mavropanos:CB:80,Konstantinos Tsimikas:LB:80,Konstantinos Tzolakis:GK:79,Christos Zafeiris:CM:78,Georgios Vagiannidis:RB:78,Christos Mandas:GK:77,Panagiotis Retsos:CB:74,Andreas Ntoi:CB:73,Lazaros Rota:RB:72,Dimitrios Giannoulis:LB:70,Panos Katseris:RM:70,Taxiarchis Fountas:CF:70,Alexandros Kyziridis:LW:68,Nektarios Alafakis:LM:64",
  "Greece|2026": "Konstantinos Karetsas:CAM:84,Vangelis Pavlidis:ST:84,Christos Tzolis:LW:83,Charalampos Kostoulas:ST:82,Christos Mouzakitis:CM:82,Konstantinos Koulierakis:CB:82,Giannis Konstantelias:CAM:81,Stefanos Tzimas:ST:81,Konstantinos Mavropanos:CB:79,Konstantinos Tzolakis:GK:79,Christos Zafeiris:CM:78,Georgios Vagiannidis:RB:78,Christos Mandas:GK:77,Konstantinos Tsimikas:LB:76,Panagiotis Retsos:CB:74,Alexandros Kyziridis:LW:72,Andreas Ntoi:CB:72,Lazaros Rota:RB:72,Dimitrios Giannoulis:LB:70,Panos Katseris:RM:68,Nektarios Alafakis:LM:64",
  "Hungary|2018": "Willi Orb\xE1n:CB:79,P\xE9ter Gul\xE1csi:GK:77,Roland Sallai:RB:73,Tam\xE1s K\xE1d\xE1r:CB:73,\xC1d\xE1m Szalai:ST:72,\xC1d\xE1m Nagy:CDM:70,\xC1kos Elek:CDM:68,Dominik Szoboszlai:CAM:68,L\xE1szl\xF3 Kleinheisler:CAM:68,\xC1d\xE1m B\xF3di:RM:64,\xC1d\xE1m Bogd\xE1n:GK:64,\xC1d\xE1m Gyurcs\xF3:LW:64,Botond Birtalan:CF:64,D\xE1niel Sall\xF3i:LW:64,D\xE1vid Barczi:LM:64,Lo\xEFc Nego:RB:64,Palk\xF3 D\xE1rdai:RW:64,Roland Varga:RW:64",
  "Hungary|2019": "Willi Orb\xE1n:CB:81,P\xE9ter Gul\xE1csi:GK:78,Roland Sallai:RB:73,Tam\xE1s K\xE1d\xE1r:CB:73,Nemanja Nikolics:ST:72,Bal\xE1zs Dzsudzs\xE1k:CAM:70,Lo\xEFc Nego:RB:70,Dominik Nagy:LW:68,L\xE1szl\xF3 Kleinheisler:CAM:68,\xC1d\xE1m B\xF3di:RM:64,Botond Birtalan:CF:64,D\xE1niel Sall\xF3i:LW:64,D\xE1vid Barczi:LM:64,D\xE9nes Dibusz:GK:64,Palk\xF3 D\xE1rdai:RW:64,Roland Varga:RW:64",
  "Hungary|2020": "Dominik Szoboszlai:CAM:82,Willi Orb\xE1n:CB:80,P\xE9ter Gul\xE1csi:GK:78,Roland Sallai:RB:73,Tam\xE1s K\xE1d\xE1r:CB:72,\xC1d\xE1m Gyurcs\xF3:LW:68,\xC1d\xE1m Nagy:CDM:68,Callum Styles:LB:68,D\xE9nes Dibusz:GK:68,Kevin Varga:LW:68,L\xE1szl\xF3 Kleinheisler:CAM:68,Lo\xEFc Nego:RB:68,\xC1d\xE1m B\xF3di:RM:64,Botond Birtalan:CF:64,D\xE1vid Barczi:LM:64",
  "Hungary|2021": "Dominik Szoboszlai:CAM:83,Roland Sallai:RB:80,Willi Orb\xE1n:CB:80,P\xE9ter Gul\xE1csi:GK:79,Attila Szalai:CB:78,D\xE1niel Sall\xF3i:LW:76,M\xE1rton D\xE1rdai:CB:74,Callum Styles:LB:72,D\xE9nes Dibusz:GK:70,Kevin Varga:LW:70,L\xE1szl\xF3 Kleinheisler:CAM:70,\xC1d\xE1m Nagy:CDM:68,Lo\xEFc Nego:RB:68,\xC1d\xE1m B\xF3di:RM:64,Botond Birtalan:CF:64",
  "Hungary|2022": "Dominik Szoboszlai:CAM:84,Attila Szalai:CB:79,Roland Sallai:RB:78,Willi Orb\xE1n:CB:77,D\xE1niel Sall\xF3i:LW:76,Milos Kerkez:LB:76,P\xE9ter Gul\xE1csi:GK:76,D\xE1niel Gazdag:CAM:74,Andr\xE1s Sch\xE4fer:CM:73,M\xE1rton D\xE1rdai:CB:73,Callum Styles:LB:72,D\xE9nes Dibusz:GK:70,\xC1d\xE1m Nagy:CDM:68,Kevin Varga:LW:68,\xC1d\xE1m B\xF3di:RM:64,Botond Birtalan:CF:64",
  "Hungary|2026": "Dominik Szoboszlai:CAM:90,Milos Kerkez:LB:85,Alex T\xF3th:CM:78,Roland Sallai:RB:78,Bence D\xE1rdai:CAM:76,Willi Orb\xE1n:CB:74,Andr\xE1s Sch\xE4fer:CM:73,Barnab\xE1s Varga:ST:72,Damir Redzic:RW:72,\xC1ron Yaakobishvili:GK:70,Callum Styles:LB:70,D\xE1niel Sall\xF3i:LW:70,Bendeg\xFAz Bolla:RB:68,D\xE9nes Dibusz:GK:68,\xC1d\xE1m B\xF3di:RM:64,\xC1ron Doktorics:LM:64",
  "Iceland|2024": "Albert Gudmundsson:CF:83,Orri \xD3skarsson:ST:81,H\xE1kon Arnar Haraldsson:CAM:77,Kristian Hlynsson:CAM:76,\xCDsak J\xF3hannesson:CM:73,Arn\xF3r Sigurdsson:LW:70,H\xE1kon Valdimarsson:GK:70,J\xF3n Dagur Thorsteinsson:LW:70,Mikael Egill Ellertsson:CM:70,Alfons Sampsted:RB:68,Dagur Dan Th\xF3rhallsson:RB:68,Logi T\xF3masson:LB:68,Bjarki Bjarkason:LM:64,Kolbeinn Finnsson:LB:64,Vidar Ari J\xF3nsson:RM:64",
  "Ireland|2016": "S\xE9amus Coleman:RB:81,James McCarthy:CM:80,Shane Long:ST:77,Robbie Brady:LM:76,Aiden McGeady:LW:73,Ciaran Clark:CB:73,Jeff Hendrick:CM:73,Jonathan Walters:RW:72,Shane Duffy:CB:72,Alan Judge:CM:70,Anthony Pilkington:LW:70,Darron Gibson:CM:70,Glenn Whelan:CDM:70,Joe Mason:ST:70,Marc Wilson:CB:70,Darren Randolph:GK:68,Joey O'Brien:RB:68,Keiren Westwood:GK:68,Wes Hoolahan:CAM:68,Aaron Doran:RM:64,Billy Clarke:CF:64",
  "Ireland|2017": "S\xE9amus Coleman:RB:80,James McCarthy:CM:79,Robbie Brady:LM:77,Shane Long:ST:77,Scott Hogan:ST:76,Jeff Hendrick:CM:74,Ciaran Clark:CB:73,Shane Duffy:CB:73,Aiden McGeady:LW:72,Conor Hourihane:CM:72,Darren Randolph:GK:72,Alan Judge:CM:70,Anthony Pilkington:LW:70,Joe Mason:ST:70,Jonathan Walters:RW:70,Marc Wilson:CB:70,Keiren Westwood:GK:68,Matt Doherty:RB:68,Stephen Ward:LB:68,Wes Hoolahan:CAM:68,Aaron Doran:RM:64,Billy Clarke:CF:64",
  "Ireland|2018": "S\xE9amus Coleman:RB:79,James McCarthy:CM:78,Shane Duffy:CB:78,Jeff Hendrick:CM:77,Matt Doherty:RB:77,Robbie Brady:LM:77,Harry Arter:CM:76,Scott Hogan:ST:76,Shane Long:ST:76,Ciaran Clark:CB:74,Darren Randolph:GK:73,Conor Hourihane:CM:72,Greg Cunningham:CB:72,John Egan:CB:72,Aiden McGeady:LW:70,Stephen Ward:LB:70,Anthony Pilkington:LW:68,Glenn Whelan:CDM:68,Jonathan Walters:RW:68,Rob Elliot:GK:68,Aaron Doran:RM:64,Billy Clarke:CF:64",
  "Ireland|2019": "Matt Doherty:RB:81,S\xE9amus Coleman:RB:79,Jeff Hendrick:CM:78,Shane Duffy:CB:78,John Egan:CB:77,Callum Robinson:ST:76,Conor Hourihane:CM:76,Harry Arter:CM:76,Robbie Brady:LM:76,Shane Long:ST:76,Ciaran Clark:CB:74,Enda Stevens:LB:74,Aaron Connolly:ST:73,Darren Randolph:GK:73,James McCarthy:CM:73,Aiden McGeady:LW:70,Ryan Manning:LB:68,Aaron Doran:RM:64,Billy Clarke:CF:64,Caoimh\xEDn Kelleher:GK:64,Mikey Johnston:LW:64",
  "Ireland|2020": "Matt Doherty:RB:81,Jeff Hendrick:CM:77,S\xE9amus Coleman:RB:77,Aaron Connolly:ST:76,Callum Robinson:ST:76,Enda Stevens:LB:76,Conor Hourihane:CM:74,Ciaran Clark:CB:73,Harry Arter:CM:73,James McCarthy:CM:73,Michael Obafemi:ST:73,Robbie Brady:LM:73,Darren Randolph:GK:72,Ryan Manning:LB:70,Caoimh\xEDn Kelleher:GK:68,Aaron Doran:RM:64,Billy Clarke:CF:64,Mikey Johnston:LW:64",
  "Ireland|2021": "Matt Doherty:RB:80,Jeff Hendrick:CM:77,Aaron Connolly:ST:76,Nathan Collins:CB:76,S\xE9amus Coleman:RB:76,Shane Duffy:CB:76,Callum Robinson:ST:74,Jason Knight:CM:74,Conor Hourihane:CM:73,Alan Browne:CM:72,Ciaran Clark:CB:72,Enda Stevens:LB:72,Michael Obafemi:ST:72,Caoimh\xEDn Kelleher:GK:70,Darren Randolph:GK:68,Aaron Doran:RM:64,Graham Burke:CF:64",
  "Ireland|2022": "Nathan Collins:CB:82,Gavin Bazunu:GK:79,Matt Doherty:RB:78,Caoimh\xEDn Kelleher:GK:76,John Egan:CB:76,Josh Cullen:CM:76,Aaron Connolly:ST:74,Callum Robinson:ST:74,Jason Knight:CM:73,Jeff Hendrick:CM:73,Shane Duffy:CB:73,Troy Parrott:ST:73,Alan Browne:CM:72,Andrew Omobamidele:CB:72,Festy Ebosele:RB:72,Ryan Manning:LB:70,Chiedozie Ogbene:RW:68,Enda Stevens:LB:68,Harvey Vale:RM:68,Sammie Szmodics:CAM:68,Graham Burke:CF:64",
  "Ireland|2023": "Evan Ferguson:ST:88,Nathan Collins:CB:82,Gavin Bazunu:GK:80,Caoimh\xEDn Kelleher:GK:79,Josh Cullen:CM:79,Andrew Omobamidele:CB:78,Matt Doherty:RB:77,Dara O'Shea:CB:76,Festy Ebosele:RB:74,John Egan:CB:74,Tom Cannon:ST:74,Jason Knight:CM:73,Sammie Szmodics:CAM:73,Aaron Connolly:ST:72,Will Smallbone:CM:72,Robbie Brady:LM:71,Alan Browne:CM:70,Andrew Moran:CAM:70,Chiedozie Ogbene:RW:70,Ryan Manning:LB:70,Harvey Vale:RM:68,Mikey Johnston:LW:68,Graham Burke:CF:64",
  "Ireland|2024": "Evan Ferguson:ST:87,Nathan Collins:CB:83,Caoimh\xEDn Kelleher:GK:82,Dara O'Shea:CB:79,Gavin Bazunu:GK:79,Jake O'Brien:RB:79,Andrew Omobamidele:CB:78,Finn Azaz:CAM:77,Josh Cullen:CM:77,Mark McGuinness:CB:77,Chiedozie Ogbene:RW:76,Troy Parrott:ST:76,Will Smallbone:CM:76,Festy Ebosele:RB:74,Tom Cannon:ST:74,Jason Knight:CM:73,Ryan Manning:LB:72,Alan Browne:CM:70,Andrew Moran:CAM:70,Callum O'Dowda:LM:70,Mikey Johnston:LW:70,Harvey Vale:RM:68,Graham Burke:CF:64",
  "Ireland|2025": "Evan Ferguson:ST:84,Nathan Collins:CB:84,Caoimh\xEDn Kelleher:GK:82,Troy Parrott:ST:82,Finn Azaz:CAM:80,Jake O'Brien:RB:80,Dara O'Shea:CB:79,Gavin Bazunu:GK:78,Kasey McAteer:RM:78,Andrew Omobamidele:CB:77,Sammie Szmodics:CAM:77,Tom Cannon:ST:77,Chiedozie Ogbene:RW:76,Eiran Cashin:CB:76,Jason Knight:CM:76,Josh Cullen:CM:76,Festy Ebosele:RB:74,Will Smallbone:CM:74,Mikey Johnston:LW:72,Callum O'Dowda:LM:70,Jack Taylor:CM:70,Tyler Goodrham:RW:70,Graham Burke:CF:64",
  "Ireland|2026": "Nathan Collins:CB:83,Caoimh\xEDn Kelleher:GK:82,Evan Ferguson:ST:82,Troy Parrott:ST:82,Finn Azaz:CAM:80,Jake O'Brien:RB:80,Dara O'Shea:CB:79,Gavin Bazunu:GK:77,Kasey McAteer:RM:77,Andrew Omobamidele:CB:76,Jason Knight:CM:76,Mark McGuinness:CB:76,Tom Cannon:ST:76,Josh Cullen:CM:74,Sammie Szmodics:CAM:74,Chiedozie Ogbene:RW:73,Jimmy Dunne:RB:73,Mikey Johnston:LW:72,Will Smallbone:CM:72,Jack Taylor:CM:70,Ryan Manning:LB:70,Tyler Goodrham:RW:70,Alex Murphy:LB:68,Callum O'Dowda:LM:68,Rocco Vata:LW:68",
  "Italy|2016": "Leonardo Bonucci:CB:85,Marco Verratti:CM:85,Claudio Marchisio:CM:83,Alessandro Florenzi:RB:82,Antonio Candreva:RW:82,Lorenzo Insigne:LW:82,Alessio Romagnoli:CB:81,Domenico Berardi:RW:81,Giacomo Bonaventura:CAM:81,Jorginho:CDM:81,Manolo Gabbiadini:ST:80,Mattia Perin:GK:80,Stephan El Shaarawy:LW:80,Andrea Belotti:ST:79,Andrea Bertolacci:CM:79,Daniele Rugani:CB:79,\xC9der:ST:79,Gianluigi Donnarumma:GK:79,Giorgio Chiellini:CB:79,Matteo Darmian:RB:79,Riccardo Saponara:CAM:79,Stefano Sturaro:CM:78,Domenico Criscito:LB:77,Sebastian Giovinco:CF:77,Daniele De Rossi:CDM:76,Davide Santon:LB:76,Davide Zappacosta:RM:73,Emanuele Giaccherini:LM:72",
  "Italy|2017": "Lorenzo Insigne:LW:87,Marco Verratti:CM:87,Leonardo Bonucci:CB:86,Andrea Belotti:ST:85,Gianluigi Donnarumma:GK:85,Ciro Immobile:ST:84,Federico Chiesa:RW:84,Claudio Marchisio:CM:83,Federico Bernardeschi:RW:83,Jorginho:CDM:83,Alessandro Florenzi:RB:82,Alessio Romagnoli:CB:82,Giacomo Bonaventura:CAM:82,Daniele Rugani:CB:81,Mattia Caldara:CB:81,Roberto Gagliardini:CM:81,Stephan El Shaarawy:LW:81,Lorenzo Pellegrini:CAM:80,Mattia Perin:GK:80,Simone Zaza:ST:80,Andrea Conti:RB:79,Bryan Cristante:CDM:79,Davide Zappacosta:RM:79,Emerson:LB:79,Nicol\xF2 Barella:CM:79,Leonardo Spinazzola:LB:78,Sebastian Giovinco:CF:77,Emanuele Giaccherini:LM:70",
  "Italy|2018": "Lorenzo Insigne:LW:89,Jorginho:CDM:88,Marco Verratti:CM:88,Ciro Immobile:ST:86,Federico Bernardeschi:RW:86,Federico Chiesa:RW:86,Alessio Romagnoli:CB:85,Andrea Belotti:ST:85,Gianluigi Donnarumma:GK:85,Leonardo Bonucci:CB:84,Lorenzo Pellegrini:CAM:84,Alessandro Florenzi:RB:83,Nicol\xF2 Barella:CM:83,Patrick Cutrone:ST:83,Bryan Cristante:CDM:82,Daniele Rugani:CB:82,Giacomo Bonaventura:CAM:82,Mattia Caldara:CB:82,Stephan El Shaarawy:LW:82,Davide Zappacosta:RM:81,Emerson:LB:81,Marco Benassi:CM:81,Roberto Gagliardini:CM:81,Alex Meret:GK:80,Davide Calabria:RB:80,Leonardo Spinazzola:LB:78,Gianluca Caprari:CF:77,Andrea Badan:LM:64",
  "Italy|2019": "Marco Verratti:CM:89,Jorginho:CDM:88,Lorenzo Insigne:LW:88,Federico Chiesa:RW:87,Gianluigi Donnarumma:GK:87,Alessio Romagnoli:CB:86,Ciro Immobile:ST:86,Federico Bernardeschi:RW:86,Nicol\xF2 Barella:CM:86,Nicol\xF2 Zaniolo:CF:86,Alex Meret:GK:85,Andrea Belotti:ST:85,Lorenzo Pellegrini:CAM:85,Moise Kean:ST:85,Emerson:LB:83,Gianluca Mancini:CB:83,Leonardo Bonucci:CB:83,Sandro Tonali:CDM:83,Stefano Sensi:CM:83,Stephan El Shaarawy:LW:83,Alessandro Bastoni:CB:82,Alessandro Florenzi:RB:82,Gaetano Castrovilli:CM:82,Simone Verdi:CAM:82,Davide Calabria:RB:81,Leonardo Spinazzola:LB:80,Davide Zappacosta:RM:79,Antonio Zito:LM:64",
  "Italy|2020": "Gianluigi Donnarumma:GK:87,Marco Verratti:CM:87,Nicol\xF2 Barella:CM:87,Nicol\xF2 Zaniolo:CF:87,Alessandro Bastoni:CB:86,Ciro Immobile:ST:86,Federico Chiesa:RW:86,Jorginho:CDM:86,Lorenzo Insigne:LW:86,Andrea Belotti:ST:85,Lorenzo Pellegrini:CAM:85,Alessio Romagnoli:CB:84,Alex Meret:GK:84,Federico Bernardeschi:RW:84,Manuel Locatelli:CDM:84,Moise Kean:ST:83,Emerson:LB:82,Gaetano Castrovilli:CM:82,Gianluca Mancini:CB:82,Giovanni Di Lorenzo:RB:82,Leonardo Spinazzola:LB:82,Luiz Felipe:CB:82,Stefano Sensi:CM:82,Alessandro Florenzi:RB:80,Simone Verdi:CAM:80,Mattia Zaccagni:LW:79,Davide Zappacosta:RM:78,Andrea Errico:LM:64",
  "Italy|2021": "Federico Chiesa:RW:88,Gianluigi Donnarumma:GK:88,Nicol\xF2 Barella:CM:88,Alessandro Bastoni:CB:87,Marco Verratti:CM:87,Jorginho:CDM:86,Lorenzo Insigne:LW:86,Lorenzo Pellegrini:CAM:86,Ciro Immobile:ST:85,Nicol\xF2 Zaniolo:CF:85,Andrea Belotti:ST:84,Domenico Berardi:RW:84,Manuel Locatelli:CDM:84,Moise Kean:ST:84,Alessio Romagnoli:CB:83,Gianluca Mancini:CB:83,Leonardo Spinazzola:LB:83,Davide Calabria:RB:82,Gaetano Castrovilli:CM:82,Giovanni Di Lorenzo:RB:82,Alessio Cragno:GK:81,Luiz Felipe:CB:81,Matteo Pessina:CM:81,Federico Dimarco:LB:80,Mattia Zaccagni:LW:79,Davide Zappacosta:RM:77,Roberto Soriano:CAM:77",
  "Italy|2022": "Federico Chiesa:RW:88,Nicol\xF2 Barella:CM:88,Alessandro Bastoni:CB:87,Gianluigi Donnarumma:GK:86,Lorenzo Pellegrini:CAM:86,Marco Verratti:CM:86,Sandro Tonali:CDM:86,Jorginho:CDM:85,Domenico Berardi:RW:84,Giacomo Raspadori:CF:84,Ciro Immobile:ST:83,Gianluca Scamacca:ST:83,Moise Kean:ST:83,Davide Calabria:RB:82,Davide Frattesi:CM:82,Destiny Udogie:LB:82,Federico Dimarco:LB:82,Gianluca Mancini:CB:82,Giovanni Di Lorenzo:RB:82,Lorenzo Insigne:LW:82,Mattia Zaccagni:LW:82,Giorgio Scalvini:CB:81,Alessio Romagnoli:CB:80,Matteo Pessina:CM:80,Alex Meret:GK:79,Davide Zappacosta:RM:77,Igor Coronado:CAM:75",
  "Italy|2023": "Nicol\xF2 Barella:CM:89,Alessandro Bastoni:CB:87,Federico Chiesa:RW:86,Federico Dimarco:LB:86,Gianluigi Donnarumma:GK:86,Destiny Udogie:LB:85,Giorgio Scalvini:CB:85,Marco Verratti:CM:85,Giacomo Raspadori:CF:84,Lorenzo Pellegrini:CAM:84,Nicol\xF2 Fagioli:CM:84,Davide Frattesi:CM:83,Gianluca Scamacca:ST:83,Guglielmo Vicario:GK:83,Mattia Zaccagni:LW:83,Alessandro Buongiorno:CB:82,Giovanni Di Lorenzo:RB:82,Nicol\xF2 Casale:CB:82,Davide Calabria:RB:81,Domenico Berardi:RW:81,Andrea Pinamonti:ST:80,Ciro Immobile:ST:80,Tommaso Baldanzi:CAM:79,Lorenzo Insigne:LW:78,Davide Zappacosta:RM:76,Andrea Errico:LM:64",
  "Italy|2024": "Alessandro Bastoni:CB:89,Nicol\xF2 Barella:CM:89,Federico Dimarco:LB:87,Alessandro Buongiorno:CB:86,Destiny Udogie:LB:86,Giorgio Scalvini:CB:86,Federico Chiesa:RW:85,Gianluigi Donnarumma:GK:85,Davide Frattesi:CM:84,Gianluca Scamacca:ST:84,Guglielmo Vicario:GK:84,Mateo Retegui:ST:84,Giacomo Raspadori:CF:83,Moise Kean:ST:83,Federico Gatti:CB:82,Lorenzo Pellegrini:CAM:82,Mattia Zaccagni:LW:82,Michael Kayode:RB:82,Raoul Bellanova:RM:82,Nicol\xF2 Fagioli:CM:81,Andrea Colpani:CAM:80,Edoardo Bove:CM:80,Giovanni Di Lorenzo:RB:80,Riccardo Orsolini:RW:80,Vincenzo Grifo:LW:77,Andrea Ghezzi:LM:64",
  "Italy|2025": "Alessandro Bastoni:CB:89,Nicol\xF2 Barella:CM:89,Alessandro Buongiorno:CB:86,Federico Dimarco:LB:86,Gianluigi Donnarumma:GK:86,Mateo Retegui:ST:86,Moise Kean:ST:86,Riccardo Calafiori:LB:86,Davide Frattesi:CM:84,Giorgio Scalvini:CB:84,Guglielmo Vicario:GK:84,Pio Esposito:ST:84,Michael Kayode:RB:83,Federico Gatti:CB:82,Giacomo Raspadori:CF:82,Marco Palestra:RB:82,Raoul Bellanova:RM:82,Riccardo Orsolini:RW:82,Wilfried Gnonto:RW:82,Mattia Zaccagni:LW:81,Nicol\xF2 Cambiaghi:LW:80,Nicol\xF2 Fagioli:CM:80,Cesare Casadei:CM:79,Andrea Colpani:CAM:78,Giovanni Fabbian:CAM:78,Samuele Angori:LM:74",
  "Italy|2026": "Alessandro Bastoni:CB:88,Federico Dimarco:LB:86,Gianluigi Donnarumma:GK:86,Nicol\xF2 Barella:CM:86,Pio Esposito:ST:86,Riccardo Calafiori:LB:86,Moise Kean:ST:85,Alessandro Buongiorno:CB:84,Mateo Retegui:ST:84,Michael Kayode:RB:84,Giorgio Scalvini:CB:83,Marco Palestra:RB:83,Davide Frattesi:CM:82,Giovanni Leoni:CB:82,Guglielmo Vicario:GK:82,Niccol\xF2 Pisilli:CM:81,Fabio Miretti:CM:80,Nicol\xF2 Cambiaghi:LW:80,Raoul Bellanova:RM:80,Riccardo Orsolini:RW:80,Wilfried Gnonto:RW:80,Antonio Vergara:CAM:79,Lorenzo Bernasconi:LM:79,Mattia Zaccagni:LW:78,Cristian Volpato:CAM:77",
  "Jamaica|2017": "Leon Bailey:RW:83,Michail Antonio:ST:80,Andre Gray:ST:79,Demarai Gray:LW:77,Isaac Hayden:CDM:73,Mason Holgate:CB:73,Kevin Stewart:CDM:72,Michael Hector:CB:72,Kemar Roofe:ST:70,Wes Morgan:CB:70,Kasey Palmer:CAM:68,Rico Henry:LB:68,Andre Blake:GK:64,Chris Humphrey:RM:64,Kemar Lawrence:LB:64,Lance Laing:LM:64,Rolando Aarons:LW:64",
  "Jamaica|2018": "Leon Bailey:RW:86,Demarai Gray:LW:81,Michail Antonio:ST:80,Andre Gray:ST:79,Isaac Hayden:CDM:76,Liam Moore:CB:76,Mason Holgate:CB:76,Kemar Roofe:ST:72,Kevin Stewart:CDM:72,Michael Hector:CB:70,Wes Morgan:CB:70,Andre Blake:GK:68,Kasey Palmer:CAM:68,Kemar Lawrence:LB:68,Rico Henry:LB:68,Elliott Bennett:RM:64,Lance Laing:LM:64",
  "Jamaica|2019": "Leon Bailey:RW:85,Demarai Gray:LW:81,Andre Gray:ST:79,Michail Antonio:ST:79,Bobby De Cordova-Reid:CAM:77,Isaac Hayden:CDM:77,Liam Moore:CB:76,Mason Holgate:CB:76,Kemar Roofe:ST:75,Kevin Stewart:CDM:73,Michael Hector:CB:70,Andre Blake:GK:68,Kemar Lawrence:LB:68,Rico Henry:LB:68,Elliott Bennett:RM:64,Garath McCleary:RW:64,Lance Laing:LM:64",
  "Jamaica|2020": "Leon Bailey:RW:83,Mason Holgate:CB:80,Demarai Gray:LW:79,Michail Antonio:ST:78,Andre Gray:ST:77,Bobby De Cordova-Reid:CAM:77,Isaac Hayden:CDM:77,Kemar Roofe:ST:74,Michael Hector:CB:74,Kevin Stewart:CDM:73,Rico Henry:LB:73,Daniel Johnson:CM:72,Ethan Pinnock:CB:72,Andre Blake:GK:68,Kasey Palmer:CAM:68,Kemar Lawrence:LB:68,Elliott Bennett:RM:64,Kyle Duncan:RB:64,Saeed Robinson:LM:64",
  "Jamaica|2021": "Leon Bailey:RW:84,Demarai Gray:LW:82,Mason Holgate:CB:81,Rico Henry:LB:79,Michail Antonio:ST:78,Ethan Pinnock:CB:77,Isaac Hayden:CDM:77,Kemar Roofe:ST:74,Andre Gray:ST:73,Liam Moore:CB:73,Michael Hector:CB:72,Andre Blake:GK:70,Daniel Johnson:CM:70,Kasey Palmer:CAM:68,Kyle Duncan:RB:68,Elliott Bennett:RM:64,Kemal Malcolm:CF:64,Kemar Lawrence:LB:64",
  "Jamaica|2023": "Leon Bailey:RW:83,Rico Henry:LB:83,Demarai Gray:LW:81,Ethan Pinnock:CB:79,Mason Holgate:CB:78,Bobby De Cordova-Reid:CAM:76,Michail Antonio:ST:76,Shamar Nicholson:ST:75,Kemar Roofe:ST:72,Andre Brooks:CM:70,Dexter Lembikisa:RB:70,Andre Blake:GK:68,Kyle Duncan:RB:68,Andrew Booth:RM:64,Saeed Robinson:LM:64",
  "Japan|2016": "Shinji Kagawa:CAM:80,Shinji Okazaki:ST:77,Keisuke Honda:CAM:76,Atsuto Uchida:RB:74,Yoshinori Muto:ST:74,Maya Yoshida:CB:72,Junya Tanaka:ST:70,Makoto Hasebe:CDM:70,Takashi Usami:CF:70,Takumi Minamino:LW:70,Gotoku Sakai:RB:68,Hotaru Yamaguchi:CDM:68,Kosuke Ota:LB:68,Takuma Asano:RW:68,Yosuke Kashiwagi:CM:68,Akihiro Ienaga:RW:64,Alex:LM:64,Daigo Watanabe:RM:64,Eiji Kawashima:GK:64,Hiroki Fujiharu:LB:64,Masaaki Higashiguchi:GK:64",
  "Japan|2017": "Shinji Kagawa:CAM:79,Shinji Okazaki:ST:76,Yuya Osako:ST:74,Hiroshi Kiyotake:CAM:73,Maya Yoshida:CB:73,Yoshinori Muto:ST:73,Yuto Nagatomo:LB:73,Takumi Minamino:LW:72,Gotoku Sakai:RB:70,Hiroki Sakai:RB:70,Takashi Inui:LW:70,Takuma Asano:RW:70,Yuki Kobayashi:CM:70,Hotaru Yamaguchi:CDM:68,Makoto Hasebe:CDM:68,Yosuke Kashiwagi:CM:68,Yuki Muto:CF:68,Akihiro Hayashi:GK:64,Akihiro Ienaga:RW:64,Daigo Watanabe:RM:64,Daisuke Kikuchi:LM:64,Eiji Kawashima:GK:64,Hiroki Fujiharu:LB:64",
  "Japan|2018": "Shinji Kagawa:CAM:79,Shoya Nakajima:CAM:79,Yoshinori Muto:ST:77,Hiroki Sakai:RB:76,Maya Yoshida:CB:76,Ritsu Doan:RW:76,Shinji Okazaki:ST:76,Takashi Inui:LW:76,Takehiro Tomiyasu:RB:74,Yuya Osako:ST:74,Takumi Minamino:LW:73,Gen Shoji:CB:72,Gaku Shibasaki:CM:70,Yuki Kobayashi:CM:70,Hotaru Yamaguchi:CDM:68,Kosuke Nakamura:GK:68,Shu Kurata:LM:68,Shusaku Nishikawa:GK:68,Takashi Usami:CF:68,Takuma Asano:RW:68,Yosuke Kashiwagi:CM:68,Daigo Watanabe:RM:64,Hiroki Fujiharu:LB:64,Kosuke Ota:LB:64",
  "Japan|2019": "Shoya Nakajima:CAM:82,Takefusa Kubo:RW:79,Takumi Minamino:LW:79,Daichi Kamada:CAM:77,Takehiro Tomiyasu:RB:77,Yoshinori Muto:ST:77,Hiroki Sakai:RB:76,Maya Yoshida:CB:76,Yuya Osako:ST:74,Junya Ito:RW:73,Gen Shoji:CB:72,Shinji Okazaki:ST:72,Takashi Inui:LW:72,Kento Hashimoto:CDM:68,Kento Misao:CDM:68,Ko Matsubara:LB:68,Kosuke Nakamura:GK:68,Kosuke Ota:LB:68,Masaaki Higashiguchi:GK:68,Takashi Usami:CF:68,Yoshifumi Kashiwa:LM:68,Daiki Kogure:RM:64",
  "Japan|2020": "Takefusa Kubo:RW:83,Daichi Kamada:CAM:80,Shoya Nakajima:CAM:80,Takehiro Tomiyasu:RB:80,Takumi Minamino:LW:77,Hiroki Sakai:RB:76,Ritsu Doan:RW:76,Wataru Endo:CDM:74,Yoshinori Muto:ST:74,Yuya Osako:ST:73,Masaya Okugawa:LW:72,Maya Yoshida:CB:72,Kento Hashimoto:CDM:70,Koji Miyoshi:RM:68,Akito Kawamoto:CF:64,Daigo Araki:LM:64,Daiki Sugioka:LB:64,Keisuke Osako:GK:64,Ko Matsubara:LB:64,Kosuke Nakamura:GK:64",
  "Japan|2021": "Daichi Kamada:CAM:82,Takehiro Tomiyasu:RB:82,Takefusa Kubo:RW:81,Takumi Minamino:LW:78,Wataru Endo:CDM:77,Junya Ito:RW:76,Shoya Nakajima:CAM:76,Kyogo Furuhashi:ST:74,Ko Itakura:CB:72,Yuma Suzuki:ST:72,Hidemasa Morita:CM:70,Kento Hashimoto:CDM:70,Koji Miyoshi:RM:70,Masaya Okugawa:LW:70,Yukinari Sugawara:RB:70,Daisuke Ishizu:CF:64,Keisuke Osako:GK:64,Kosuke Nakamura:GK:64,Yusuke Maruhashi:LB:64",
  "Japan|2022": "Daichi Kamada:CAM:83,Takehiro Tomiyasu:RB:82,Ritsu Doan:RW:79,Ko Itakura:CB:78,Takefusa Kubo:RW:78,Takumi Minamino:LW:78,Hidemasa Morita:CM:76,Kaoru Mitoma:LW:76,Wataru Endo:CDM:76,Hiroki Ito:CB:74,Kyogo Furuhashi:ST:74,Reo Hatate:CM:73,Hiroki Sakai:RB:72,Shoya Nakajima:CAM:72,Ao Tanaka:CM:70,Koji Miyoshi:RM:70,Daniel Schmidt:GK:68,Kento Hashimoto:CDM:68,Daisuke Ishizu:CF:64,Yusuke Maruhashi:LB:64",
  "Japan|2023": "Takefusa Kubo:RW:87,Kaoru Mitoma:LW:86,Daichi Kamada:CAM:83,Takehiro Tomiyasu:RB:83,Hiroki Ito:CB:82,Ko Itakura:CB:79,Kyogo Furuhashi:ST:79,Yukinari Sugawara:RB:79,Hidemasa Morita:CM:78,Keito Nakamura:LW:78,Reo Hatate:CM:78,Ayase Ueda:ST:77,Junya Ito:RW:77,Koki Machida:CB:74,Tsuyoshi Watanabe:CB:74,Hayao Kawabe:CM:73,Ao Tanaka:CM:70,Daniel Schmidt:GK:68,Koji Miyoshi:RM:68,Shoya Nakajima:CAM:68,Yohei Takaoka:GK:68,Daigo Araki:LM:64,Daisuke Ishizu:CF:64",
  "Japan|2024": "Kaoru Mitoma:LW:86,Takefusa Kubo:RW:86,Takehiro Tomiyasu:RB:84,Hiroki Ito:CB:83,Ritsu Doan:RW:82,Takumi Minamino:LW:81,Daichi Kamada:CAM:80,Hidemasa Morita:CM:79,Ko Itakura:CB:79,Kyogo Furuhashi:ST:79,Reo Hatate:CM:78,Koki Machida:CB:77,Tsuyoshi Watanabe:CB:77,Zion Suzuki:GK:77,Ayase Ueda:ST:76,Yuito Suzuki:CF:76,Hayao Kawabe:CM:73,Kodai Sano:CM:73,Kanya Fujimoto:CAM:72,Keigo Tsunemoto:RB:70,Leo Kokubo:GK:70,Shuto Machino:ST:70,Keita Kosugi:LB:68,Koji Miyoshi:RM:68,Takahiro Akimoto:LB:68,Shion Homma:LM:65",
  "Japan|2025": "Kaoru Mitoma:LW:85,Takefusa Kubo:RW:83,Hiroki Ito:CB:82,Ritsu Doan:RW:82,Takehiro Tomiyasu:RB:82,Zion Suzuki:GK:81,Ayase Ueda:ST:79,Hidemasa Morita:CM:79,Reo Hatate:CM:79,Takumi Minamino:LW:79,Yuito Suzuki:CF:79,Daichi Kamada:CAM:78,Ko Itakura:CB:78,Koki Machida:CB:78,Kyogo Furuhashi:ST:78,Yukinari Sugawara:RB:78,Ao Tanaka:CM:77,Tsuyoshi Watanabe:CB:77,Joel Chima Fujita:CM:76,Shuto Machino:ST:76,Kanya Fujimoto:CAM:73,Sota Kitano:RM:73,Keita Kosugi:LB:72,Leo Kokubo:GK:72,Ryoya Ogawa:LB:68,Shunki Higashi:LM:68",
  "Japan|2026": "Takefusa Kubo:RW:83,Kaoru Mitoma:LW:82,Ritsu Doan:RW:81,Zion Suzuki:GK:81,Hiroki Ito:CB:80,Ayase Ueda:ST:79,Daizen Maeda:LW:79,Daichi Kamada:CAM:78,Ao Tanaka:CM:77,Hidemasa Morita:CM:77,Joel Chima Fujita:CM:77,Ko Itakura:CB:77,Reo Hatate:CM:77,Tsuyoshi Watanabe:CB:77,Keisuke Goto:ST:76,Kento Shiogai:ST:76,Koki Machida:CB:76,Takehiro Tomiyasu:RB:76,Yukinari Sugawara:RB:76,Keita Kosugi:LB:74,Leo Kokubo:GK:73,Isa Sakamoto:CAM:72,Taiga Hata:LB:70,Hayate Matsuda:RM:68,Shunki Higashi:LM:68",
  "Kazakhstan|2018": "Dmitriy Shomko:LB:70,Roman Murtazaev:LW:70,Aleksandr Zuev:LW:68,Bauyrzhan Islamkhan:CAM:68,Gafurzhan Suyumbaev:LB:68,Islambek Kuat:CDM:68,Abzal Beysebekov:RB:64,Adil Balgabaev:CF:64,Dmitriy Miroshnichenko:RB:64,Dmitriy Nepogodov:GK:64,Erkebulan Tungyshbaev:RW:64,Ilya Kalinin:RM:64,Mardan Tolebek:RW:64,Rakhimzhan Rozybakiev:LM:64,Stas Pokatilov:GK:64",
  "Korea, South|2016": "Heung-min Son:LW:82,Sung-yueng Ki:CDM:76,Hyun-jun Suk:ST:72,Tae-hee Nam:CAM:72,Jeong-ho Hong:CB:70,Ju-ho Park:LB:70,Bo-kyung Kim:CAM:68,Chung-yong Lee:RW:68,Myong-jin Koh:CM:68,Chan-ho Cho:RW:64,Chul Hong:LB:64,Chul-soon Choi:RB:64,Dae-sun Jung:CF:64,Dong-hyeok Ahn:LM:64,Hwa-yong Shin:GK:64,Hyung-min Shin:CDM:64,Ik-hyeon Kim:RM:64,Jin-hyeon Kim:GK:64,Keun-ho Lee:LW:64",
  "Korea, South|2017": "Heung-min Son:LW:83,Sung-yueng Ki:CDM:76,Ja-cheol Koo:CM:73,Hee-chan Hwang:ST:72,Tae-hee Nam:CAM:72,Hyun-jun Suk:ST:70,Bo-kyung Kim:CAM:68,Chang-min Lee:CM:68,Chung-yong Lee:RW:68,Il-lok Yun:LW:68,Kook-young Han:CDM:68,Cha-won Ko:RM:64,Chang-hoon Kwon:RW:64,Dae-sun Jung:CF:64,Han-been Yang:GK:64,Hyun-beom Ahn:RB:64,Jin-hyeon Kim:GK:64,Ju-ho Park:LB:64,Jun-yeob Lee:LM:64,Tae-hwan Kim:RB:64,Woon Jeong:LB:64",
  "Kosovo|2025": "Fisnik Asllani:ST:83,Edon Zhegrova:RW:82,Albian Hajdari:CB:78,Amir Rrahmani:CB:78,Albion Rrahmani:ST:76,Arijanet Muri\u0107:GK:76,Milot Rashica:RW:76,Vedat Muriqi:ST:73,Elvis Rexhbecaj:CM:72,Amir Saipi:GK:70,Dion Gallapeni:LM:70,M\xEBrgim Vojvoda:RB:70,Meriton Korenica:LW:70,Zymer Bytyqi:LW:70,Bersant Celina:CAM:68,Donat Rrudhani:RM:68,Leart Pa\xE7arada:LB:68",
  "Mali|2016": "Adama Traor\xE9:CM:76,Bakary Sako:LW:76,Abdoulay Diaby:RW:74,Abdoulaye Doucour\xE9:CAM:74,Cheick Diabat\xE9:ST:73,Almamy Tour\xE9:CB:70,Moussa Marega:ST:70,Sambou Yatabar\xE9:CM:70,Birama Tour\xE9:CDM:68,Hamari Traor\xE9:RB:68,Kalifa Coulibaly:ST:68,Massadio Ha\xEFdara:LB:68,Molla Wagu\xE9:CB:68,Tongo Doumbia:CDM:68,Cheick Keita:LB:64,Hadi Sacko:RW:64,Mamadou Samassa:GK:64,Moussa Doumbia:LW:64,Ousmane Coulibaly:RB:64,Sigamary Diarra:LM:64",
  "Mali|2017": "Moussa Marega:ST:76,Abdoulaye Doucour\xE9:CAM:74,Bakary Sako:LW:74,Abdoulay Diaby:RW:72,Almamy Tour\xE9:CB:72,Cheick Diabat\xE9:ST:72,Diadi\xE9 Samass\xE9kou:CDM:72,Adama Niane:ST:70,Amadou Haidara:CM:68,Birama Tour\xE9:CDM:68,Hamari Traor\xE9:RB:68,Lassana Coulibaly:CM:68,Mamadou Samassa:GK:68,Massadio Ha\xEFdara:LB:68,Sambou Yatabar\xE9:CM:68,Cheick Keita:LB:64,Moussa Doumbia:LW:64,Ousmane Coulibaly:RB:64,Sigamary Diarra:LM:64",
  "Mali|2018": "Abdoulaye Doucour\xE9:CAM:82,Moussa Marega:ST:82,Amadou Haidara:CM:81,Diadi\xE9 Samass\xE9kou:CDM:81,Yves Bissouma:CDM:79,Almamy Tour\xE9:CB:76,Abdoulay Diaby:RW:74,Hamari Traor\xE9:RB:74,Bakary Sako:LW:73,Moussa Djenepo:LW:73,Moussa Sylla:ST:73,Bakaye Dibassy:CB:72,Cheick Diabat\xE9:ST:72,Fousseni Diabat\xE9:RW:70,Mamadou Samassa:GK:70,Charles Traor\xE9:LB:68,Cheick Keita:LB:64,Falaye Sacko:RB:64",
  "Mali|2019": "Moussa Marega:ST:83,Abdoulaye Doucour\xE9:CAM:82,Amadou Haidara:CM:81,Diadi\xE9 Samass\xE9kou:CDM:81,Yves Bissouma:CDM:79,Moussa Djenepo:LW:78,Youssouf Kon\xE9:LB:77,Almamy Tour\xE9:CB:75,Abdoulay Diaby:RW:74,Hamari Traor\xE9:RB:74,Kalifa Coulibaly:ST:73,S\xE9kou Ko\xEFta:ST:73,Bakary Sako:LW:72,Falaye Sacko:RB:72,Mamadou Fofana:CB:72,Bakaye Dibassy:CB:70,Charles Traor\xE9:LB:70,Fousseni Diabat\xE9:RW:70,Mamadou Samassa:GK:68,Ibrahim Kane:RM:64,Sibiry Keita:LM:64",
  "Mali|2020": "Abdoulaye Doucour\xE9:CAM:82,Moussa Marega:ST:81,Amadou Haidara:CM:80,Diadi\xE9 Samass\xE9kou:CDM:79,Moussa Djenepo:LW:79,S\xE9kou Ko\xEFta:ST:79,Yves Bissouma:CDM:79,El Bilal Tour\xE9:LW:78,Hamari Traor\xE9:RB:76,Youssouf Kon\xE9:LB:75,Abdoulay Diaby:RW:73,Falaye Sacko:RB:72,Kalifa Coulibaly:ST:72,Mamadou Fofana:CB:72,Charles Traor\xE9:LB:70,Mamadou Samassa:GK:70,Fousseni Diabat\xE9:RW:68,Ibrahim Kane:RM:64",
  "Mali|2021": "Abdoulaye Doucour\xE9:CAM:82,Amadou Haidara:CM:82,Mohamed Camara:CDM:82,Yves Bissouma:CDM:82,Moussa Marega:ST:81,Moussa Djenepo:LW:79,S\xE9kou Ko\xEFta:ST:79,El Bilal Tour\xE9:LW:76,Hamari Traor\xE9:RB:76,Almamy Tour\xE9:CB:74,Kiki Kouyat\xE9:CB:74,Falaye Sacko:RB:72,Abdoulay Diaby:RW:70,Amadou Dante:LB:70,Ismaila Coulibaly:CM:70,Massadio Ha\xEFdara:LB:70,Rominigue Kouam\xE9:CM:70,Mamadou Samassa:GK:68,Dorgeles Nene:RW:64,Ibrahim Kane:RM:64",
  "Mexico|2016": "Chicharito:ST:82,Carlos Vela:RW:80,H\xE9ctor Herrera:CM:80,Ra\xFAl Jim\xE9nez:ST:78,Jes\xFAs Corona:RW:77,Miguel Lay\xFAn:RB:77,Andr\xE9s Guardado:CM:76,Giovani dos Santos:CF:76,H\xE9ctor Moreno:CB:76,Hirving Lozano:LW:75,Jonathan dos Santos:CDM:74,\xC9rick Guti\xE9rrez:CM:73,Marco Fabi\xE1n:CAM:73,Rodolfo Pizarro:CAM:73,Rogelio Funes Mori:ST:73,Diego Reyes:CB:72,Javier Aquino:RB:72,Orbel\xEDn Pineda:CM:72,Carlos Salcedo:CB:70,C\xE9sar Montes:CB:70,Guillermo Ochoa:GK:70,Jes\xFAs Due\xF1as:CDM:70,Jonathan Orozco:GK:70,Carlos Cisneros:LW:68,Edwin Hern\xE1ndez:LB:68,Efra\xEDn Velarde:LB:68,Alejandro Vela:LM:64,Diego Campos:RM:64",
  "Mexico|2017": "Chicharito:ST:82,Carlos Vela:RW:79,H\xE9ctor Herrera:CM:79,Hirving Lozano:LW:79,Jes\xFAs Corona:RW:78,Ra\xFAl Jim\xE9nez:ST:78,Andr\xE9s Guardado:CM:76,H\xE9ctor Moreno:CB:76,Jonathan dos Santos:CDM:76,Marco Fabi\xE1n:CAM:76,Miguel Lay\xFAn:RB:76,Diego Reyes:CB:74,Orbel\xEDn Pineda:CM:74,Rodolfo Pizarro:CAM:74,\xC9rick Guti\xE9rrez:CM:73,Giovani dos Santos:CF:73,Javier Aquino:RB:73,Rogelio Funes Mori:ST:73,Carlos Salcedo:CB:72,Jorge Hern\xE1ndez:CDM:72,C\xE9sar Montes:CB:70,Guillermo Ochoa:GK:70,Jorge Torres Nilo:LB:70,Rodolfo Cota:GK:70,Adri\xE1n Aldrete:LB:68,Arturo Gonz\xE1lez:LW:68,Alejandro Vela:LM:64,Diego Campos:RM:64",
  "Mexico|2018": "Hirving Lozano:LW:85,H\xE9ctor Herrera:CM:81,Chicharito:ST:80,Ra\xFAl Jim\xE9nez:ST:80,Carlos Salcedo:CB:77,Carlos Vela:RW:77,Rodolfo Pizarro:CAM:77,\xC9rick Guti\xE9rrez:CM:76,N\xE9stor Ara\xFAjo:CB:76,Diego Reyes:CB:74,H\xE9ctor Moreno:CB:74,Rogelio Funes Mori:ST:74,Andr\xE9s Guardado:CM:73,Javier Aquino:RB:73,Jonathan dos Santos:CDM:73,Jonathan Gonz\xE1lez:CDM:73,Marco Fabi\xE1n:CAM:73,Miguel Lay\xFAn:RB:73,Orbel\xEDn Pineda:CM:73,Guillermo Ochoa:GK:72,J\xFCrgen Damm:RW:72,Giovani dos Santos:CF:70,Luis Reyes:LB:70,Rodolfo Cota:GK:70,Adri\xE1n Aldrete:LB:68,Arturo Gonz\xE1lez:LW:68,Alejandro Vela:LM:64,Brayan Villalobos:RM:64",
  "Mexico|2019": "Hirving Lozano:LW:85,Ra\xFAl Jim\xE9nez:ST:85,H\xE9ctor Herrera:CM:82,Jes\xFAs Corona:RW:82,Carlos Vela:RW:79,Edson \xC1lvarez:CDM:79,Chicharito:ST:78,Carlos Salcedo:CB:77,Rodolfo Pizarro:CAM:77,N\xE9stor Ara\xFAjo:CB:76,Orbel\xEDn Pineda:CM:76,Rogelio Funes Mori:ST:76,V\xEDctor Guzm\xE1n:CAM:76,\xC9rick Guti\xE9rrez:CM:75,Jonathan Gonz\xE1lez:CDM:75,H\xE9ctor Moreno:CB:74,Andr\xE9s Guardado:CM:73,C\xE9sar Montes:CB:73,Javier Aquino:RB:73,Jes\xFAs Gallardo:LB:73,Alexis Vega:LW:72,Guillermo Ochoa:GK:72,Jorge S\xE1nchez:RB:72,Ra\xFAl Gudi\xF1o:GK:70,Adri\xE1n Aldrete:LB:68,Giovani dos Santos:CF:68,Alejandro Vela:LM:64,Brayan Villalobos:RM:64",
  "Mexico|2020": "Ra\xFAl Jim\xE9nez:ST:86,Hirving Lozano:LW:85,Jes\xFAs Corona:RW:83,H\xE9ctor Herrera:CM:80,Carlos Vela:RW:79,Alan Pulido:ST:77,Edson \xC1lvarez:CDM:77,Jos\xE9 Juan Mac\xEDas:ST:77,Rodolfo Pizarro:CAM:77,Carlos Rodr\xEDguez:CDM:76,Orbel\xEDn Pineda:CM:76,V\xEDctor Guzm\xE1n:CAM:76,C\xE9sar Montes:CB:75,\xC9rick Aguirre:RB:74,\xC9rick Guti\xE9rrez:CM:74,Jes\xFAs Gallardo:LB:74,Alexis Vega:LW:73,Javier Aquino:RB:73,Johan V\xE1squez:CB:73,Cristian Calder\xF3n:LB:72,Fernando Beltr\xE1n:CM:72,H\xE9ctor Moreno:CB:72,Sebasti\xE1n Jurado:GK:72,Carlos Acevedo:GK:70,Gilberto Sep\xFAlveda:CB:70,Giovani dos Santos:CF:68,Allam Bello:LM:64,Brayan Villalobos:RM:64",
  "Mexico|2021": "Hirving Lozano:LW:86,Ra\xFAl Jim\xE9nez:ST:84,Jes\xFAs Corona:RW:83,Edson \xC1lvarez:CDM:80,Alan Pulido:ST:77,Carlos Rodr\xEDguez:CDM:77,Jos\xE9 Juan Mac\xEDas:ST:77,Orbel\xEDn Pineda:CM:77,Carlos Vela:RW:76,C\xE9sar Montes:CB:76,H\xE9ctor Herrera:CM:76,N\xE9stor Ara\xFAjo:CB:76,Rodolfo Pizarro:CAM:76,Sebasti\xE1n C\xF3rdova:CAM:76,Alexis Vega:LW:75,Carlos Salcedo:CB:74,\xC9rick Aguirre:RB:74,Johan V\xE1squez:CB:74,Carlos Acevedo:GK:73,Gerardo Arteaga:LB:73,\xC1lvaro Fidalgo:CM:72,\xC9rick Guti\xE9rrez:CM:72,Kevin \xC1lvarez:RB:72,Salvador Reyes:LB:72,Luis Malag\xF3n:GK:70,Giovani dos Santos:CF:68,Carlos L\xF3pez Flores:RM:64",
  "Mexico|2022": "Edson \xC1lvarez:CDM:84,Hirving Lozano:LW:84,Jes\xFAs Corona:RW:80,Ra\xFAl Jim\xE9nez:ST:80,Carlos Rodr\xEDguez:CDM:77,Alexis Vega:LW:76,C\xE9sar Montes:CB:76,\xC9rick Guti\xE9rrez:CM:76,\xC9rick S\xE1nchez:CM:76,Jes\xFAs Angulo:CB:76,Jos\xE9 Juan Mac\xEDas:ST:76,V\xEDctor Guzm\xE1n:CAM:76,\xC1lvaro Fidalgo:CM:74,Efra\xEDn \xC1lvarez:CAM:74,Fernando Beltr\xE1n:CM:74,Henry Martin:ST:74,Jorge S\xE1nchez:RB:74,Juli\xE1n Araujo:RB:74,Roberto Alvarado:RW:74,Carlos Acevedo:GK:73,Carlos Salcedo:CB:72,Johan V\xE1squez:CB:72,Luis Malag\xF3n:GK:72,Osvaldo Rodr\xEDguez:LB:72,Salvador Reyes:LB:72,C\xE9sar Villaluz:CF:64,H\xE9ctor Mascorro:RM:64",
  "Mexico|2023": "Santiago Gimenez:ST:86,Hirving Lozano:LW:82,\xC9rick S\xE1nchez:CM:77,Jes\xFAs Corona:RW:77,Juli\xE1n Qui\xF1ones:ST:77,Ra\xFAl Jim\xE9nez:ST:77,\xC1lvaro Fidalgo:CM:76,Arturo Gonz\xE1lez:LW:76,C\xE9sar Montes:CB:76,Gerardo Arteaga:LB:76,Jes\xFAs Angulo:CB:76,Kevin \xC1lvarez:RB:76,V\xEDctor Guzm\xE1n:CAM:76,Orbel\xEDn Pineda:CM:75,Roberto Alvarado:RW:75,Sebasti\xE1n C\xF3rdova:CAM:75,\xC9rick Guti\xE9rrez:CM:74,Jes\xFAs Orozco Chiquete:CB:74,Johan V\xE1squez:CB:74,Juli\xE1n Araujo:RB:74,Carlos Acevedo:GK:73,Jes\xFAs Gallardo:LB:73,Luis Malag\xF3n:GK:73,H\xE9ctor Mascorro:RM:64,Jes\xFAs P\xE9rez:LM:64,Rai Villa:CF:64",
  "Mexico|2024": "Santiago Gimenez:ST:86,Hirving Lozano:LW:80,\xC9rick S\xE1nchez:CM:77,Johan V\xE1squez:CB:77,Juli\xE1n Araujo:RB:77,Juli\xE1n Qui\xF1ones:ST:77,\xC1lvaro Fidalgo:CM:76,Germ\xE1n Berterame:ST:76,Jes\xFAs Orozco Chiquete:CB:76,Luis Malag\xF3n:GK:76,Orbel\xEDn Pineda:CM:76,Roberto Alvarado:RW:76,V\xEDctor Guzm\xE1n:CB:76,Marcel Ruiz:CM:75,Uriel Antuna:RW:75,Alan Mozo:RB:74,Alexis Vega:LW:74,Gerardo Arteaga:LB:74,Jes\xFAs Angulo:CB:74,Omar Campos:LB:73,Sebasti\xE1n C\xF3rdova:CAM:73,Brian Guti\xE9rrez:CAM:72,Carlos Acevedo:GK:72,Christian Pinz\xF3n:LM:64,H\xE9ctor Mascorro:RM:64,Luis Egurrola:CF:64",
  "Mexico|2025": "Santiago Gimenez:ST:83,Johan V\xE1squez:CB:79,Juli\xE1n Qui\xF1ones:ST:78,Alexis Vega:LW:77,\xC1lvaro Fidalgo:CM:77,Gilberto Mora:CAM:77,Hirving Lozano:LW:77,Juli\xE1n Araujo:RB:77,Marcel Ruiz:CM:77,Armando Gonz\xE1lez:ST:76,C\xE9sar Montes:CB:76,Luis Malag\xF3n:GK:76,Obed Vargas:CM:76,Orbel\xEDn Pineda:CM:76,Roberto Alvarado:RW:76,Efra\xEDn \xC1lvarez:CAM:75,Jes\xFAs Orozco Chiquete:CB:75,Diego Lainez:RW:74,Jes\xFAs Angulo:CB:74,Alan Mozo:RB:73,Omar Campos:LB:73,Carlos Acevedo:GK:72,Gerardo Arteaga:LB:72,\xC1ngel Estrada:LM:64,H\xE9ctor Mascorro:RM:64,Luis Egurrola:CF:64",
  "Mexico|2026": "Santiago Gimenez:ST:81,Armando Gonz\xE1lez:ST:79,Johan V\xE1squez:CB:79,Germ\xE1n Berterame:ST:78,\xC1lvaro Fidalgo:CM:77,Gilberto Mora:CAM:77,Juli\xE1n Araujo:RB:77,Marcel Ruiz:CM:77,Alexis Vega:LW:76,Brian Guti\xE9rrez:CAM:76,C\xE9sar Montes:CB:76,Diego Lainez:RW:76,Jord\xE1n Carrillo:LW:76,Obed Vargas:CM:76,Orbel\xEDn Pineda:CM:76,Roberto Alvarado:RW:76,Luis Malag\xF3n:GK:75,Bryan Gonz\xE1lez:LB:74,Jes\xFAs Orozco Chiquete:CB:74,Ra\xFAl Rangel:GK:74,Richard Ledezma:RB:74,Israel Reyes:CB:73,Omar Campos:LB:73,Sergio Hern\xE1ndez:LM:68,H\xE9ctor Mascorro:RM:64",
  "Morocco|2016": "Medhi Benatia:CB:80,Sofiane Boufal:CAM:79,Hakim Ziyech:RW:78,Munir El Haddadi:CAM:77,Youssef El Arabi:ST:76,Mehdi Carcela-Gonz\xE1lez:RW:73,Abderrazak Hamdallah:ST:72,Adam Masina:CB:72,Fay\xE7al Fajr:CM:72,Issa Diop:CB:72,Mostapha El Kabir:ST:72,Oussama Assaidi:LW:72,Romain Sa\xEFss:CB:72,Yassin Ayoub:CM:72,Achraf Lazaar:LM:70,Karim El Ahmadi:CDM:70,Nabil Dirar:RB:70,Youssef A\xEFt Bennasser:CDM:70,Amine Harit:LW:68,Fouad Chafik:RB:64,Hicham El Fatihi:CF:64,Mehdi Ballouchy:RM:64,Yassine Bounou:GK:64,Zakarya Bergdich:LB:64",
  "Morocco|2017": "Medhi Benatia:CB:80,Amine Harit:LW:79,Hakim Ziyech:RW:79,Sofiane Boufal:CAM:79,Munir El Haddadi:CAM:77,K\xE9vin Malcuit:RB:76,Adam Masina:CB:74,Issa Diop:CB:74,Youssef El Arabi:ST:74,Nordin Amrabat:RW:73,Yassin Ayoub:CM:73,Karim El Ahmadi:CDM:72,Mimoun Mahi:LW:72,Romain Sa\xEFss:CB:72,Sofyan Amrabat:CDM:72,Achraf Lazaar:LM:70,Fay\xE7al Fajr:CM:70,Mostapha El Kabir:ST:70,Nabil Dirar:RB:70,Adel Taarabt:CM:68,Abdallah Madi:CF:64,Omar Najdi:RM:64,Yassine Bounou:GK:64",
  "Morocco|2018": "Hakim Ziyech:RW:84,Achraf Hakimi:RB:82,Amine Harit:LW:82,Issa Diop:CB:82,Medhi Benatia:CB:82,K\xE9vin Malcuit:RB:79,Sofiane Boufal:CAM:79,Munir El Haddadi:CAM:78,Yassine Bounou:GK:77,Youssef A\xEFt Bennasser:CDM:77,Adam Masina:CB:76,Hamza Mendyl:LB:76,Romain Sa\xEFss:CB:74,Yassin Ayoub:CM:74,Youssef El Arabi:ST:74,Youssef En-Nesyri:ST:74,Brahim D\xEDaz:RW:73,Mimoun Mahi:LW:73,Sofyan Amrabat:CDM:73,Fay\xE7al Fajr:CM:72,Rachid Alioui:ST:72,Mehdi Bourabia:CM:70,Achraf Lazaar:LM:68,Abdallah Madi:CF:64,Abdelali Mhamdi:GK:64,Mehdi Karnass:RM:64,Mohammed Nahiri:LB:64",
  "Morocco|2019": "Achraf Hakimi:RB:86,Hakim Ziyech:RW:86,Issa Diop:CB:84,Amine Harit:LW:83,Mohamed Ihattaren:CAM:82,Brahim D\xEDaz:RW:80,K\xE9vin Malcuit:RB:80,Munir El Haddadi:CAM:78,Oussama Idrissi:LW:78,Youssef En-Nesyri:ST:78,Medhi Benatia:CB:77,Sofyan Amrabat:CDM:77,Youssef A\xEFt Bennasser:CDM:77,Adam Masina:CB:76,Abderrazak Hamdallah:ST:74,Imr\xE2n Louza:CM:74,Adel Taarabt:CM:73,Fay\xE7al Fajr:CM:73,Romain Sa\xEFss:CB:73,Hamza Mendyl:LB:72,Mehdi Bourabia:CM:72,Ahmed Reda Tagnaouti:GK:68,Abdelali Mhamdi:GK:64,Achraf Lazaar:LM:64,Ayoub Nanah:CF:64,Mehdi Karnass:RM:64,Mohammed Nahiri:LB:64",
  "Morocco|2020": "Achraf Hakimi:RB:87,Hakim Ziyech:RW:86,Issa Diop:CB:83,Amine Harit:LW:82,Mohamed Ihattaren:CAM:81,Sofyan Amrabat:CDM:81,Brahim D\xEDaz:RW:79,Noussair Mazraoui:RB:79,Oussama Idrissi:LW:79,Yassine Bounou:GK:79,Youssef En-Nesyri:ST:79,Imr\xE2n Louza:CM:78,Sofiane Boufal:CAM:76,Abderrazak Hamdallah:ST:75,Adel Taarabt:CM:74,Medhi Benatia:CB:74,Youssef A\xEFt Bennasser:CDM:73,Rachid Alioui:ST:72,Zouhair Feddal:CB:72,Abdou Harroui:CM:70,Fay\xE7al Fajr:CM:70,Hamza Mendyl:LB:70,Abdelali Mhamdi:GK:64,Achraf Lazaar:LM:64,Ayoub Nanah:CF:64,Mehdi Karnass:RM:64,Mohammed Nahiri:LB:64",
  "Morocco|2021": "Achraf Hakimi:RB:88,Hakim Ziyech:RW:85,Youssef En-Nesyri:ST:85,Brahim D\xEDaz:RW:82,Sofiane Diop:LW:81,Issa Diop:CB:80,Mohamed Ihattaren:CAM:80,Noussair Mazraoui:RB:80,Yassine Bounou:GK:80,Sofyan Amrabat:CDM:79,Amine Adli:LW:78,Imr\xE2n Louza:CM:78,Nayef Aguerd:CB:77,Romain Sa\xEFss:CB:77,Selim Amallah:CAM:76,Abderrazak Hamdallah:ST:74,Zouhair Feddal:CB:74,Abdou Harroui:CM:72,Adel Taarabt:CM:72,Youssef Maleh:CM:72,Youssef A\xEFt Bennasser:CDM:70,Hamza Mendyl:LB:68,Munir El Kajoui:GK:68,Ayoub Nanah:CF:64,Mehdi Karnass:RM:64",
  "Morocco|2022": "Achraf Hakimi:RB:88,Hakim Ziyech:RW:84,Youssef En-Nesyri:ST:84,Noussair Mazraoui:RB:83,Brahim D\xEDaz:RW:82,Nayef Aguerd:CB:82,Sofyan Amrabat:CDM:82,Sofiane Diop:LW:81,Yassine Bounou:GK:80,Amine Harit:LW:79,Azzedine Ounahi:CM:79,Issa Diop:CB:79,Ilias Chair:CAM:77,Imr\xE2n Louza:CM:77,Sofiane Boufal:CAM:77,Romain Sa\xEFss:CB:76,Tarik Tissoudali:ST:76,Walid Cheddira:ST:74,Zouhair Feddal:CB:72,Abdou Harroui:CM:70,Adel Taarabt:CM:70,Yahia Attiyat Allah:LB:70,Ahmed Reda Tagnaouti:GK:68,Aschraf El Mahdioui:CDM:68,Ayoub Nanah:CF:64,Hamza Mendyl:LB:64,Mehdi Karnass:RM:64",
  "Morocco|2023": "Achraf Hakimi:RB:88,Nayef Aguerd:CB:85,Noussair Mazraoui:RB:83,Amine Adli:LW:82,Bilal El Khannouss:CAM:82,Issa Diop:CB:82,Brahim D\xEDaz:RW:81,Youssef En-Nesyri:ST:81,Eliesse Ben Seghir:LW:80,Hakim Ziyech:RW:80,Azzedine Ounahi:CM:78,Yassine Bounou:GK:78,Ilias Chair:CAM:77,Imr\xE2n Louza:CM:77,Walid Cheddira:ST:76,Tarik Tissoudali:ST:75,Amir Richardson:CM:74,Chadi Riad:CB:74,Romain Sa\xEFss:CB:74,Khalil Fayad:CM:73,Ayoub Amraoui:LB:70,Yahia Attiyat Allah:LB:70,Ahmed Reda Tagnaouti:GK:68,Achraf Lazaar:LM:64,Ayoub Nanah:CF:64,Mehdi Karnass:RM:64",
  "Morocco|2024": "Achraf Hakimi:RB:87,Brahim D\xEDaz:RW:85,Nayef Aguerd:CB:84,Noussair Mazraoui:RB:84,Amine Adli:LW:83,Bilal El Khannouss:CAM:83,Eliesse Ben Seghir:LW:83,Ayyoub Bouaddi:CM:82,Ismael Saibari:CAM:82,Youssef En-Nesyri:ST:82,Issa Diop:CB:81,Chadi Riad:CB:79,Ilias Akhomach:RW:79,Azzedine Ounahi:CM:78,Amir Richardson:CM:77,Yassine Bounou:GK:77,Abdel Abqar:CB:76,Imr\xE2n Louza:CM:76,Tarik Tissoudali:ST:75,Walid Cheddira:ST:74,Souffian El Karouani:LB:73,Yahia Attiyat Allah:LB:70,Alaa Bellaarouch:GK:68,Achraf Lazaar:LM:64,Adam Boayar:CF:64,Mehdi Karnass:RM:64",
  "Morocco|2025": "Achraf Hakimi:RB:89,Brahim D\xEDaz:RW:86,Ayyoub Bouaddi:CM:85,Bilal El Khannouss:CAM:84,Ismael Saibari:CAM:84,Eliesse Ben Seghir:LW:83,Chemsdine Talbi:RW:82,Nayef Aguerd:CB:82,Noussair Mazraoui:RB:82,Youssef En-Nesyri:ST:82,Abde Ezzalzouli:LW:81,Neil El Aynaoui:CM:81,Hamza Igamane:ST:80,Issa Diop:CB:80,Chadi Riad:CB:79,Souffian El Karouani:LB:79,Anass Salah-Eddine:LB:78,Abdelhamid Ait Boudlal:CB:77,Azzedine Ounahi:CM:77,Bilal Nadir:CM:77,Maroan Sannadi:ST:77,Yassine Bounou:GK:75,El Mehdi Benabid:GK:68,Achraf Lazaar:LM:64,Adam Boayar:CF:64,Mehdi Karnass:RM:64",
  "Morocco|2026": "Achraf Hakimi:RB:89,Ayyoub Bouaddi:CM:86,Bilal El Khannouss:CAM:84,Brahim D\xEDaz:RW:84,Ismael Saibari:CAM:84,Abde Ezzalzouli:LW:83,Chemsdine Talbi:RW:82,Amine Adli:LW:81,Nayef Aguerd:CB:81,Neil El Aynaoui:CM:81,Noussair Mazraoui:RB:81,Youssef En-Nesyri:ST:81,Hamza Igamane:ST:80,Samir El Mourabet:CM:80,Imr\xE2n Louza:CM:79,Souffian El Karouani:LB:79,Chadi Riad:CB:78,Abdelhamid Ait Boudlal:CB:77,Issa Diop:CB:77,Yassir Zabiri:ST:77,Adam Aznou:LB:76,Yassine Bounou:GK:72,El Mehdi Benabid:GK:68,Nabil Touaizi:RM:64,Redouan Ait Lamkadem:LM:64",
  "Netherlands|2016": "Daley Blind:CB:82,Georginio Wijnaldum:CM:82,Memphis Depay:CF:82,Arjen Robben:RW:81,Stefan de Vrij:CB:81,Quincy Promes:LW:80,Virgil van Dijk:CB:80,Davy Klaassen:CM:79,Kevin Strootman:CM:79,Vincent Janssen:ST:79,Wesley Sneijder:CAM:79,Bruno Martins Indi:CB:78,Jasper Cillessen:GK:78,Jeremain Lens:RW:78,Jordy Clasie:CDM:78,Robin van Persie:ST:78,Bas Dost:ST:77,Davy Pr\xF6pper:CM:77,Marten de Roon:CDM:77,Daryl Janmaat:RB:76,Erik Pieters:LB:76,Gregory van der Wiel:RB:76,Jeroen Zoet:GK:76,Siem de Jong:CAM:76,Jorrit Hendrix:LM:73,Ola John:LW:73,Daley Sinkgraven:LB:72,Jeffrey Sarpong:RM:64",
  "Netherlands|2017": "Stefan de Vrij:CB:84,Georginio Wijnaldum:CM:83,Virgil van Dijk:CB:83,Daley Blind:CB:82,Kevin Strootman:CM:82,Quincy Promes:LW:82,Memphis Depay:CF:81,Bas Dost:ST:80,Davy Klaassen:CM:80,Vincent Janssen:ST:79,Bruno Martins Indi:CB:78,Jasper Cillessen:GK:78,Jeremain Lens:RW:78,Marten de Roon:CDM:78,Arjen Robben:RW:77,Davy Pr\xF6pper:CM:77,Jeroen Zoet:GK:77,Jordy Clasie:CDM:77,Luuk de Jong:ST:77,Patrick van Aanholt:LB:77,Rick Karsdorp:RB:77,Wesley Sneijder:CAM:77,Bart Ramselaar:LW:76,Daryl Janmaat:RB:76,Erik Pieters:LB:76,Jens Toornstra:CAM:76,Jorrit Hendrix:LM:73,Jeffrey Sarpong:RM:64",
  "Netherlands|2018": "Virgil van Dijk:CB:89,Matthijs de Ligt:CB:88,Frenkie de Jong:CM:87,Memphis Depay:CF:86,Stefan de Vrij:CB:86,Georginio Wijnaldum:CM:85,Kevin Strootman:CM:83,Steven Bergwijn:LW:83,Bas Dost:ST:82,Nathan Ak\xE9:CB:82,Quincy Promes:LW:82,Davy Klaassen:CM:81,Jasper Cillessen:GK:81,Justin Kluivert:CAM:81,Marten de Roon:CDM:80,Jeroen Zoet:GK:79,Wout Weghorst:ST:79,Denzel Dumfries:RB:78,Steven Berghuis:RW:78,Hans Hateboer:RB:77,Jorrit Hendrix:LM:77,Luuk de Jong:ST:77,Patrick van Aanholt:LB:77,Arjen Robben:RW:76,Erik Pieters:LB:76,Jordy Clasie:CDM:76,Guus Til:CAM:74,Jeffrey Sarpong:RM:64",
  "Netherlands|2019": "Frenkie de Jong:CM:90,Virgil van Dijk:CB:90,Matthijs de Ligt:CB:89,Donny van de Beek:CM:87,Memphis Depay:CF:87,Stefan de Vrij:CB:87,Georginio Wijnaldum:CM:86,Nathan Ak\xE9:CB:84,Steven Bergwijn:LW:84,Donyell Malen:ST:83,Wout Weghorst:ST:83,Bas Dost:ST:82,Davy Klaassen:CM:82,Justin Kluivert:CAM:82,Marten de Roon:CDM:82,Quincy Promes:LW:82,Calvin Stengs:CAM:81,Jasper Cillessen:GK:80,Denzel Dumfries:RB:79,Hans Hateboer:RB:79,Steven Berghuis:RW:79,Teun Koopmeiners:CDM:79,Jeroen Zoet:GK:78,Patrick van Aanholt:LB:78,Anwar El Ghazi:RW:77,Owen Wijndal:LB:77,Jorrit Hendrix:LM:76,Jeffrey Sarpong:RM:64",
  "Netherlands|2020": "Matthijs de Ligt:CB:89,Virgil van Dijk:CB:89,Frenkie de Jong:CM:88,Stefan de Vrij:CB:87,Donny van de Beek:CM:86,Memphis Depay:CF:86,Georginio Wijnaldum:CM:85,Nathan Ak\xE9:CB:85,Steven Bergwijn:LW:83,Wout Weghorst:ST:83,Donyell Malen:ST:82,Justin Kluivert:CAM:82,Marten de Roon:CDM:82,Calvin Stengs:CAM:80,Hans Hateboer:RB:80,Javair\xF4 Dilrosun:LW:80,Myron Boadu:ST:80,Teun Koopmeiners:CDM:80,Davy Klaassen:CM:79,Denzel Dumfries:RB:79,Jasper Cillessen:GK:79,Steven Berghuis:RW:79,Owen Wijndal:LB:78,Patrick van Aanholt:LB:77,Anwar El Ghazi:RW:76,Jeroen Zoet:GK:76,Jorrit Hendrix:LM:73,Jeffrey Sarpong:RM:64",
  "Netherlands|2021": "Frenkie de Jong:CM:90,Matthijs de Ligt:CB:89,Virgil van Dijk:CB:88,Memphis Depay:CF:86,Stefan de Vrij:CB:86,Arnaut Danjuma:LW:85,Donny van de Beek:CM:84,Georginio Wijnaldum:CM:84,Nathan Ak\xE9:CB:84,Ryan Gravenberch:CDM:84,Donyell Malen:ST:83,Wout Weghorst:ST:83,Cody Gakpo:LW:82,Marten de Roon:CDM:82,Jeremie Frimpong:RB:81,Calvin Stengs:CAM:80,Davy Klaassen:CM:80,Denzel Dumfries:RB:80,Justin Kluivert:CAM:80,Owen Wijndal:LB:80,Anwar El Ghazi:RW:79,Myron Boadu:ST:79,Steven Berghuis:RW:79,Justin Bijlow:GK:78,Daley Sinkgraven:LB:77,Jasper Cillessen:GK:74,Jeffrey Sarpong:RM:64",
  "Netherlands|2022": "Matthijs de Ligt:CB:88,Cody Gakpo:LW:87,Frenkie de Jong:CM:87,Virgil van Dijk:CB:87,Arnaut Danjuma:LW:86,Jurri\xEBn Timber:RB:86,Sven Botman:CB:85,Memphis Depay:CF:84,Ryan Gravenberch:CDM:84,Stefan de Vrij:CB:84,Denzel Dumfries:RB:83,Donyell Malen:ST:83,Teun Koopmeiners:CDM:83,Donny van de Beek:CM:82,Georginio Wijnaldum:CM:82,Tyrell Malacia:LB:82,Wout Weghorst:ST:80,Xavi Simons:CAM:80,Brian Brobbey:ST:79,Davy Klaassen:CM:79,Justin Bijlow:GK:79,Justin Kluivert:CAM:79,Steven Berghuis:RW:79,Owen Wijndal:LB:78,Anwar El Ghazi:RW:77,Mark Flekken:GK:76,Jeffrey Sarpong:RM:64",
  "Netherlands|2023": "Frenkie de Jong:CM:90,Matthijs de Ligt:CB:89,Xavi Simons:CAM:88,Cody Gakpo:LW:87,Jeremie Frimpong:RB:86,Micky van de Ven:CB:86,Sven Botman:CB:86,Virgil van Dijk:CB:86,Jurri\xEBn Timber:RB:85,Donyell Malen:ST:84,Arnaut Danjuma:LW:83,Joshua Zirkzee:ST:83,Joey Veerman:CM:82,Jorrel Hato:LB:82,Quilindschy Hartman:LB:82,Quinten Timber:CM:82,Tijjani Reijnders:CM:82,Memphis Depay:CF:80,Bart Verbruggen:GK:79,Brian Brobbey:ST:79,Calvin Stengs:CAM:79,Justin Bijlow:GK:79,Steven Berghuis:RW:78,Mitchel Bakker:LM:77,Daan Rots:RW:70,Jeffrey Sarpong:RM:64",
  "Netherlands|2024": "Xavi Simons:CAM:89,Frenkie de Jong:CM:88,Matthijs de Ligt:CB:88,Cody Gakpo:LW:87,Micky van de Ven:CB:87,Jeremie Frimpong:RB:86,Joshua Zirkzee:ST:86,Jurri\xEBn Timber:RB:86,Sven Botman:CB:86,Tijjani Reijnders:CM:86,Donyell Malen:ST:85,Ian Maatsen:LB:85,Joey Veerman:CM:85,Nathan Ak\xE9:CB:85,Brian Brobbey:ST:84,Quinten Timber:CM:84,Jorrel Hato:LB:83,Bart Verbruggen:GK:82,Crysencio Summerville:LW:82,Justin Kluivert:CAM:82,Justin Bijlow:GK:79,Mitchel Bakker:LM:79,Tijjani Noslin:RW:78,Memphis Depay:CF:77,Daan Rots:RW:76,Sami Ouaissa:RM:64",
  "Netherlands|2025": "Cody Gakpo:LW:88,Jurri\xEBn Timber:RB:88,Micky van de Ven:CB:88,Tijjani Reijnders:CM:88,Xavi Simons:CAM:88,Frenkie de Jong:CM:86,Jeremie Frimpong:RB:86,Jorrel Hato:LB:85,Matthijs de Ligt:CB:85,Sven Botman:CB:85,Bart Verbruggen:GK:84,Jan Paul van Hecke:CB:84,Joshua Zirkzee:ST:84,Justin Kluivert:CAM:84,Brian Brobbey:ST:83,Emmanuel Emegha:ST:83,Joey Veerman:CM:83,Kenneth Taylor:CM:83,Crysencio Summerville:LW:82,Ernest Poku:RW:81,Jayden Addai:RW:81,Quilindschy Hartman:LB:80,Robin Roefs:GK:80,Memphis Depay:CF:77,Mitchel Bakker:LM:77,Sami Ouaissa:RM:70",
  "Netherlands|2026": "Cody Gakpo:LW:88,Jurri\xEBn Timber:RB:88,Micky van de Ven:CB:88,Tijjani Reijnders:CM:87,Frenkie de Jong:CM:86,Xavi Simons:CAM:86,Bart Verbruggen:GK:85,Matthijs de Ligt:CB:85,Donyell Malen:ST:84,Jan Paul van Hecke:CB:84,Jeremie Frimpong:RB:84,Jorrel Hato:LB:84,Sepp van den Berg:CB:84,Crysencio Summerville:LW:83,Emmanuel Emegha:ST:83,Ian Maatsen:LB:83,Joey Veerman:CM:83,Justin Kluivert:CAM:83,Brian Brobbey:ST:82,Ernest Poku:RW:82,Kees Smit:CM:82,Robin Roefs:GK:82,Jayden Addai:RW:81,Mitchel Bakker:LM:76,Adil Lechkar:RM:64",
  "Nigeria|2016": "Ahmed Musa:LW:80,John Obi Mikel:CDM:78,Odion Ighalo:ST:78,Emmanuel Emenike:ST:77,Kelechi Iheanacho:ST:77,Alex Iwobi:LW:76,Victor Moses:RW:76,Wilfred Ndidi:CDM:76,John Chibuike:CF:72,Efe Ambrose:CB:70,Godfrey Oboabona:CB:70,Raheem Lawal:CM:70,Chidozie Awaziem:CB:68,Elderson:LB:68,John Ogu:CM:68,Kenneth Omeruo:CB:68,Nosa Igiebor:CM:68,Vincent Enyeama:GK:68,Abdullahi Nura:RB:64,Anthony Bassey:RM:64,Bryan Idowu:LB:64,Chico Ofoedu:RW:64,Michel Babatunde:CAM:64",
  "Nigeria|2017": "Ahmed Musa:LW:80,Victor Moses:RW:80,Kelechi Iheanacho:ST:79,Wilfred Ndidi:CDM:79,Alex Iwobi:LW:77,Odion Ighalo:ST:77,Emmanuel Emenike:ST:76,John Obi Mikel:CDM:76,Sone Aluko:RW:73,Godfrey Oboabona:CB:70,Joel Obi:CM:70,Kevin Akpoguma:CB:70,Elderson:LB:68,Kenneth Omeruo:CB:68,Ola Aina:RB:68,Vincent Enyeama:GK:68,Abdullahi Nura:RB:64,Anthony Bassey:RM:64,Bryan Idowu:LB:64,John Chibuike:CF:64",
  "Nigeria|2018": "Wilfred Ndidi:CDM:84,Alex Iwobi:LW:82,Ademola Lookman:LW:81,Victor Moses:RW:81,Kelechi Iheanacho:ST:79,Kevin Akpoguma:CB:78,Jordan Torunarigha:CB:77,Odion Ighalo:ST:77,Peter Etebo:CDM:76,Samuel Kalu:RW:76,Ola Aina:RB:75,Chidozie Awaziem:CB:74,Emmanuel Dennis:ST:74,Joel Obi:CM:73,Kenneth Omeruo:CB:70,Tyronne Ebuehi:RB:68,Anthony Bassey:RM:64,Francis Uzoho:GK:64,John Chibuike:CF:64",
  "Nigeria|2019": "Wilfred Ndidi:CDM:86,Alex Iwobi:LW:84,Samuel Chukwueze:RW:83,Victor Osimhen:ST:83,Ademola Lookman:LW:81,Victor Moses:RW:79,David Okereke:ST:78,Emmanuel Dennis:ST:78,Jordan Torunarigha:CB:77,Ola Aina:RB:77,Kevin Akpoguma:CB:75,Chidozie Awaziem:CB:73,Kenneth Omeruo:CB:73,Anderson Esiti:CDM:72,Frank Onyeka:CM:70,Jamilu Collins:LB:70,Joel Obi:CM:70,Tyronne Ebuehi:RB:68,Anthony Bassey:RM:64,Felix Agu:LB:64,Francis Uzoho:GK:64,Jacob Njoku:CF:64",
  "Nigeria|2021": "Victor Osimhen:ST:87,Wilfred Ndidi:CDM:87,Alex Iwobi:LW:82,Paul Onuachu:ST:82,Kelechi Iheanacho:ST:81,Samuel Chukwueze:RW:81,Ademola Lookman:LW:79,Jordan Torunarigha:CB:78,Joe Aribo:CM:77,Ola Aina:RB:76,Samuel Kalu:RW:76,Zaidu Sanusi:LB:76,Kevin Akpoguma:CB:74,Semi Ajayi:CB:74,Bright Osayi-Samuel:RB:73,Chidozie Awaziem:CB:73,Felix Agu:LB:70,Mikel Agu:CDM:70,Fred Onyedinma:RM:64,Jacob Njoku:CF:64,Maduka Okoye:GK:64",
  "Nigeria|2022": "Victor Osimhen:ST:88,Wilfred Ndidi:CDM:87,Alex Iwobi:LW:82,Ademola Lookman:LW:81,Kelechi Iheanacho:ST:81,Paul Onuachu:ST:81,Samuel Chukwueze:RW:81,Calvin Bassey:CB:80,Joe Aribo:CM:79,Raphael Onyedika:CDM:79,Frank Onyeka:CM:77,Zaidu Sanusi:LB:77,Alhassan Yusuf:CM:74,Kevin Akpoguma:CB:74,Chidozie Awaziem:CB:73,Nathan Tella:RW:73,Maduka Okoye:GK:72,Ola Aina:RB:72,Semi Ajayi:CB:72,Felix Agu:LB:70,Ishaq Abdulrazak:RM:70,Arthur Okonkwo:GK:68,Tyronne Ebuehi:RB:68,Adeshina Fatai:CF:64",
  "Nigeria|2024": "Victor Osimhen:ST:90,Ademola Lookman:LW:87,Victor Boniface:ST:86,Taiwo Awoniyi:ST:83,Alex Iwobi:LW:82,Nathan Tella:RW:82,Samuel Chukwueze:RW:81,Calvin Bassey:CB:80,Ola Aina:RB:79,Frank Onyeka:CM:77,Bright Osayi-Samuel:RB:76,Igoh Ogbu:CB:76,Maduka Okoye:GK:76,Felix Agu:LB:74,Fisayo Dele-Bashiru:CM:74,Joe Aribo:CM:74,Jordan Torunarigha:CB:73,Zaidu Sanusi:LB:70,Ahmad Ghali:LM:64,Fred Onyedinma:RM:64,Kingsley Bucci:CF:64",
  "Nigeria|2025": "Victor Osimhen:ST:89,Ademola Lookman:LW:87,Victor Boniface:ST:85,Alex Iwobi:LW:83,Calvin Bassey:CB:83,Ola Aina:RB:82,Tolu Arokodare:ST:82,Nathan Tella:RW:79,Samuel Chukwueze:RW:79,Igoh Ogbu:CB:78,David Moses:CM:77,Bright Osayi-Samuel:RB:76,Chibuike Nwaiwu:CB:76,Fisayo Dele-Bashiru:CM:76,Frank Onyeka:CM:76,Maduka Okoye:GK:76,Ebenezer Akinsanmiro:CM:75,Emmanuel Uchenna:CB:73,Bruno Onyemaechi:LB:70,Arthur Okonkwo:GK:68,Aaron Olugbogi:LM:64,Abdullahi Bewene:RM:64,Kingsley Bucci:CF:64",
  "Nigeria|2026": "Victor Osimhen:ST:89,Ademola Lookman:LW:85,Calvin Bassey:CB:83,Alex Iwobi:LW:82,Tolu Arokodare:ST:82,Ola Aina:RB:81,Christantus Uche:ST:79,Nathan Tella:RW:79,Samuel Chukwueze:RW:79,David Moses:CM:77,Emmanuel Fernandez:CB:77,Maduka Okoye:GK:77,Chibuike Nwaiwu:CB:76,Frank Onyeka:CM:76,Igoh Ogbu:CB:76,Ebenezer Akinsanmiro:CM:75,Fisayo Dele-Bashiru:CM:75,Bright Osayi-Samuel:RB:74,Arthur Okonkwo:GK:70,Bruno Onyemaechi:LB:70,Zaidu Sanusi:LB:70,Aaron Olugbogi:LM:64,Abdullahi Bewene:RM:64",
  "Norway|2016": "H\xE5vard Nordtveit:CDM:74,Markus Henriksen:CM:73,Alexander Tettey:CDM:72,Joshua King:ST:72,Per Ciljan Skjelbred:CM:72,Martin \xD8degaard:CAM:70,Mohamed Elyounoussi:CF:70,Stefan Johansen:CM:70,Iver Fossum:CM:68,Jonas Svensson:RB:68,Martin Linnes:RB:68,P\xE5l Andr\xE9 Helland:RW:68,Aleksander Melgalvis:RM:64,Andr\xE9 Hansen:GK:64,Birger Meling:LB:64,Espen B\xF8rufsen:LM:64,Ghayas Zahid:CAM:64,Gustav Wikheim:LW:64,Jonathan Parr:LB:64,\xD8rjan Nyland:GK:64",
  "Norway|2018": "Sander Berge:CDM:80,Joshua King:ST:79,Mohamed Elyounoussi:CF:79,Alexander S\xF8rloth:ST:76,Ole Seln\xE6s:CDM:76,Jonas Svensson:RB:74,Erling Haaland:ST:73,Fredrik Midtsj\xF8:CM:73,Markus Henriksen:CM:73,Stefan Johansen:CM:73,Martin \xD8degaard:CAM:72,Iver Fossum:CM:70,\xD8rjan Nyland:GK:70,Rune Jarstein:GK:70,Birger Meling:LB:68,Gustav Wikheim:LW:68,Martin Linnes:RB:68,Simen Jukler\xF8d:LB:68,Aleksander Melgalvis:RM:64,Dennis Johnsen:LW:64,Eirik Hestad:RW:64,Espen B\xF8rufsen:LM:64,Jo Inge Berget:CAM:64,P\xE5l Andr\xE9 Helland:RW:64",
  "Norway|2020": "Erling Haaland:ST:90,Martin \xD8degaard:CAM:86,Alexander S\xF8rloth:ST:81,Sander Berge:CDM:81,Joshua King:ST:80,Mathias Normann:CDM:79,Mohamed Elyounoussi:CF:78,Fredrik Midtsj\xF8:CM:77,Jens Petter Hauge:LW:77,Omar Elabdellaoui:RB:74,Markus Henriksen:CM:73,Morten Thorsby:CM:73,H\xE5kon Evjen:CM:72,Jonas Svensson:RB:72,Kristoffer Ajer:CB:72,Birger Meling:LB:68,Gustav Wikheim:LW:68,Aleksander Melgalvis:RM:64,Andr\xE9 Hansen:GK:64,Eirik Hestad:RW:64,Fredrik Bj\xF8rkan:LB:64,Ghayas Zahid:CAM:64,Jon-Helge Tveita:LM:64,\xD8rjan Nyland:GK:64",
  "Norway|2021": "Erling Haaland:ST:92,Martin \xD8degaard:CAM:85,Alexander S\xF8rloth:ST:80,Kristoffer Ajer:CB:80,Sander Berge:CDM:80,Mathias Normann:CDM:79,Mohamed Elyounoussi:CF:78,Fredrik Midtsj\xF8:CM:77,Jens Petter Hauge:LW:77,Joshua King:ST:77,Morten Thorsby:CM:76,Kristian Thorstvedt:CM:74,Andreas Schjelderup:LW:73,Julian Ryerson:RB:72,Omar Elabdellaoui:RB:72,H\xE5kon Evjen:CM:70,Simen Jukler\xF8d:LB:70,Aron D\xF8nnum:RM:68,Fredrik Bj\xF8rkan:LB:68,Kristoffer Klaesson:GK:68,Kristoffer Zachariassen:CAM:68,Eirik Hestad:RW:64,\xD8rjan Nyland:GK:64",
  "Norway|2022": "Erling Haaland:ST:93,Martin \xD8degaard:CAM:87,Kristoffer Ajer:CB:80,Sander Berge:CDM:80,Fredrik Aursnes:CM:79,J\xF8rgen Strand Larsen:ST:78,Mathias Normann:CDM:78,Mohamed Elyounoussi:CF:78,Alexander S\xF8rloth:ST:77,Andreas Schjelderup:LW:77,Birger Meling:LB:76,Fredrik Midtsj\xF8:CM:76,Jens Petter Hauge:LW:76,Julian Ryerson:RB:76,Kristian Thorstvedt:CM:76,Leo \xD8stig\xE5rd:CB:76,Morten Thorsby:CM:76,Marcus Pedersen:RB:74,Andreas Hanche-Olsen:CB:72,Jakob Glesnes:CB:72,Ola Solbakken:RW:72,Fredrik Bj\xF8rkan:LB:70,Kristoffer Zachariassen:CAM:70,Aron D\xF8nnum:RM:68,Kristoffer Klaesson:GK:68,Mads Hedenstad:GK:64",
  "Norway|2023": "Erling Haaland:ST:93,Martin \xD8degaard:CAM:90,Antonio Nusa:LW:81,Fredrik Aursnes:CM:81,Kristoffer Ajer:CB:80,Alexander S\xF8rloth:ST:79,J\xF8rgen Strand Larsen:ST:79,Julian Ryerson:RB:79,Oscar Bobb:RW:79,Andreas Schjelderup:LW:77,Leo \xD8stig\xE5rd:CB:77,Mohamed Elyounoussi:CF:77,Andreas Hanche-Olsen:CB:76,Hugo Vetlesen:CM:76,Kristian Thorstvedt:CM:76,Marcus Pedersen:RB:76,Sverre Nypan:CM:76,Birger Meling:LB:73,Joel Mvuka:RM:73,Emil Breivik:CAM:72,Jakob Glesnes:CB:72,Ola Solbakken:RW:72,Mathias L\xF8vik:LB:70,Egil Selvik:GK:68,Kristoffer Klaesson:GK:68,Jon-Helge Tveita:LM:64",
  "Norway|2024": "Erling Haaland:ST:94,Martin \xD8degaard:CAM:91,Antonio Nusa:LW:83,J\xF8rgen Strand Larsen:ST:83,Alexander S\xF8rloth:ST:82,Oscar Bobb:RW:82,Fredrik Aursnes:CM:81,Julian Ryerson:RB:81,Kristoffer Ajer:CB:80,Sverre Nypan:CM:78,Andreas Hanche-Olsen:CB:77,Andreas Schjelderup:LW:77,Kristian Thorstvedt:CM:77,Hugo Vetlesen:CM:76,Leo \xD8stig\xE5rd:CB:76,Sindre Walle Egeli:RW:76,Fredrik Sj\xF8vold:RB:74,Mohamed Elyounoussi:CF:74,Jesper Daland:CB:73,Kristoffer Zachariassen:CAM:73,Mathias L\xF8vik:LB:73,Aron D\xF8nnum:RM:72,Birger Meling:LB:72,Egil Selvik:GK:64,Jon-Helge Tveita:LM:64,Mads Hedenstad:GK:64",
  "Norway|2025": "Erling Haaland:ST:94,Martin \xD8degaard:CAM:90,J\xF8rgen Strand Larsen:ST:85,Antonio Nusa:LW:84,Oscar Bobb:RW:83,Alexander S\xF8rloth:ST:82,Fredrik Aursnes:CM:81,Julian Ryerson:RB:81,Sindre Walle Egeli:RW:81,Kristoffer Ajer:CB:80,Andreas Schjelderup:LW:79,Sverre Nypan:CM:79,Torbj\xF8rn Heggem:CB:79,David M\xF8ller Wolfe:LB:78,Kristian Thorstvedt:CM:77,Leo \xD8stig\xE5rd:CB:77,Fredrik Sj\xF8vold:RB:76,Jens Hjert\xF8-Dahl:CM:76,Andreas Hanche-Olsen:CB:74,Aron D\xF8nnum:RM:73,Mathias L\xF8vik:LB:73,Mohamed Elyounoussi:CF:73,Tobias Gulliksen:CAM:73,Sander Tangvik:GK:72,Egil Selvik:GK:68,Lasse Nilsen:LM:64",
  "Norway|2026": "Erling Haaland:ST:94,Martin \xD8degaard:CAM:88,J\xF8rgen Strand Larsen:ST:86,Antonio Nusa:LW:84,Oscar Bobb:RW:83,Julian Ryerson:RB:82,Alexander S\xF8rloth:ST:81,Andreas Schjelderup:LW:81,Fredrik Aursnes:CM:80,Kristoffer Ajer:CB:80,Sindre Walle Egeli:RW:80,Sverre Nypan:CM:79,Torbj\xF8rn Heggem:CB:79,David M\xF8ller Wolfe:LB:77,Fredrik Sj\xF8vold:RB:77,Kristian Thorstvedt:CM:77,Leo \xD8stig\xE5rd:CB:77,Eivind Helland:CB:76,Jens Hjert\xF8-Dahl:CM:76,Aron D\xF8nnum:RM:73,Fredrik Bj\xF8rkan:LB:72,Emil Breivik:CAM:70,Sander Tangvik:GK:70,Egil Selvik:GK:64,Lasse Nilsen:LM:64",
  "Paraguay|2016": "Juan Iturbe:CF:79,Antonio Sanabria:ST:76,Lorenzo Melgarejo:ST:76,\xD3scar Romero:CAM:76,Gustavo G\xF3mez:CB:74,Miguel Almir\xF3n:RW:74,Ra\xFAl Bobadilla:ST:74,H\xE9ctor Villalba:RW:73,Andr\xE9s Cubas:CDM:72,\xC9dgar Barreto:CM:72,Osvaldo Mart\xEDnez:CM:70,Celso Ortiz:CDM:68,Edgar Ben\xEDtez:LW:68,Iv\xE1n Piris:RB:68,Kaku:CAM:68,Miguel Samudio:LB:68,Pablo Aguilar:CB:68,Roberto Fern\xE1ndez:GK:68,V\xEDctor Ayala:CM:68,Antony Silva:GK:64,Blas Riveros:LB:64,Eduardo Echeverr\xEDa:LM:64,Francisco Garc\xEDa:RM:64",
  "Paraguay|2017": "Derlis Gonz\xE1lez:CF:76,Miguel Almir\xF3n:RW:76,\xD3scar Romero:CAM:76,Gustavo G\xF3mez:CB:74,Antonio Sanabria:ST:73,Ra\xFAl Bobadilla:ST:73,Andr\xE9s Cubas:CDM:72,H\xE9ctor Villalba:RW:72,Jorge Moreira:RB:72,Kaku:CAM:72,Lorenzo Melgarejo:ST:72,Bruno Valdez:CB:70,Fabi\xE1n Balbuena:CB:70,Gast\xF3n Gim\xE9nez:CDM:70,J\xFAnior Alonso:CB:70,Roberto Fern\xE1ndez:GK:70,Edgar Ben\xEDtez:LW:68,Iv\xE1n Piris:RB:68,Osvaldo Mart\xEDnez:CM:68,V\xEDctor Ayala:CM:68,Ernesto Cristaldo:LM:64,Jorge Ba\xE9z:RM:64",
  "Paraguay|2018": "Miguel Almir\xF3n:RW:79,Antonio Sanabria:ST:76,Derlis Gonz\xE1lez:CF:74,Fabi\xE1n Balbuena:CB:74,Federico Santander:ST:74,J\xFAnior Alonso:CB:73,Kaku:CAM:73,Bruno Valdez:CB:72,Gustavo G\xF3mez:CB:72,H\xE9ctor Villalba:RW:72,Lorenzo Melgarejo:ST:72,Mat\xEDas Rojas:CAM:72,Andr\xE9s Cubas:CDM:70,Celso Ortiz:CDM:70,Roberto Fern\xE1ndez:GK:70,Blas Riveros:LB:68,Iv\xE1n Piris:RB:68,Jorge Moreira:RB:68,Osvaldo Mart\xEDnez:CM:68,Edgar Ben\xEDtez:LW:64,Fernando Gim\xE9nez:LM:64,Joel Silva:GK:64",
  "Paraguay|2019": "Miguel Almir\xF3n:RW:81,Fabi\xE1n Balbuena:CB:78,Antonio Sanabria:ST:77,Mat\xEDas Rojas:CAM:76,Bruno Valdez:CB:74,Cecilio Dom\xEDnguez:RW:74,Federico Santander:ST:74,Gustavo G\xF3mez:CB:73,Kaku:CAM:73,Andr\xE9s Cubas:CDM:72,Carlos Gonz\xE1lez:ST:72,Derlis Gonz\xE1lez:CF:72,Juan Escobar:CB:72,Celso Ortiz:CDM:70,Roberto Fern\xE1ndez:GK:70,Blas Riveros:LB:68,Jorge Moreira:RB:68,Miguel Samudio:LB:68,Richard S\xE1nchez:CM:68,Edgar Ben\xEDtez:LW:64,Fernando Gim\xE9nez:LM:64,Iv\xE1n Piris:RB:64,Joel Silva:GK:64,Nicol\xE1s Mart\xEDnez:RM:64",
  "Paraguay|2020": "Miguel Almir\xF3n:RW:80,Antonio Sanabria:ST:75,Omar Alderete:CB:75,Bruno Valdez:CB:74,Iv\xE1n Franco:RW:74,Mat\xEDas Rojas:CAM:74,Carlos Gonz\xE1lez:ST:73,Gustavo G\xF3mez:CB:73,Richard S\xE1nchez:CM:73,Santiago Arzamendia:LB:73,Andr\xE9s Cubas:CDM:72,Dar\xEDo Lezcano:ST:72,Derlis Gonz\xE1lez:CF:72,Gast\xF3n Gim\xE9nez:CDM:72,Juan Escobar:CB:72,Kaku:CAM:72,Alan Rodr\xEDguez:LB:68,Enzo Gim\xE9nez:RM:68,Roberto Fern\xE1ndez:GK:68,Alfredo Aguilar:GK:64,Brahian Ayala:LW:64,Fernando Gim\xE9nez:LM:64,Hugo Fern\xE1ndez:LW:64,Iv\xE1n Piris:RB:64,Jorge Moreira:RB:64",
  "Paraguay|2021": "Miguel Almir\xF3n:RW:80,Antonio Sanabria:ST:76,Gustavo G\xF3mez:CB:76,J\xFAnior Alonso:CB:76,Omar Alderete:CB:76,Richard S\xE1nchez:CM:76,David Mart\xEDnez:CB:75,\xC1ngel Romero:RW:74,Julio Enciso:CAM:74,Mat\xEDas Rojas:CAM:74,Carlos Gonz\xE1lez:ST:73,Santiago Arzamendia:LB:73,Andr\xE9s Cubas:CDM:72,\xC1ngel Cardozo Lucena:CM:72,Dar\xEDo Lezcano:ST:72,Jorge Morel:CDM:72,Derlis Gonz\xE1lez:CF:70,Agust\xEDn S\xE1ndez:LB:68,Enzo Gim\xE9nez:RM:68,Juan Jos\xE9 C\xE1ceres:RB:68,Iv\xE1n Ram\xEDrez:RB:64,Miguel Mart\xEDnez:GK:64,Roberto Fern\xE1ndez:GK:64",
  "Paraguay|2022": "Miguel Almir\xF3n:RW:81,Julio Enciso:CAM:78,Gustavo G\xF3mez:CB:77,Omar Alderete:CB:77,Antonio Sanabria:ST:76,J\xFAnior Alonso:CB:76,David Mart\xEDnez:CB:75,Jes\xFAs Medina:RW:74,Richard S\xE1nchez:CM:74,Sebasti\xE1n Ferreira:ST:73,Adam Bareiro:ST:72,Andr\xE9s Cubas:CDM:72,\xC1ngel Cardozo Lucena:CM:72,Derlis Gonz\xE1lez:CF:72,Jorge Morel:CDM:72,Mat\xEDas Rojas:CAM:72,Blas Armoa:LW:70,Agust\xEDn S\xE1ndez:LB:68,Alan Rodr\xEDguez:LB:68,Enzo Gim\xE9nez:RM:68,Iv\xE1n Leguizam\xF3n:LW:68,Iv\xE1n Ram\xEDrez:RB:68,Alberto Esp\xEDnola:RB:64,Santiago Rojas:GK:64",
  "Paraguay|2023": "Miguel Almir\xF3n:RW:84,Julio Enciso:CAM:82,Antonio Sanabria:ST:77,Gustavo G\xF3mez:CB:77,Jes\xFAs Medina:RW:76,J\xFAnior Alonso:CB:76,Mauricio:CAM:76,Ram\xF3n Sosa:CF:76,Richard S\xE1nchez:CM:76,Adam Bareiro:ST:74,Alexis Duarte:CB:72,Carlos Gonz\xE1lez:ST:72,David Mart\xEDnez:CB:72,Enso Gonz\xE1lez:LW:72,\xC1ngel Cardozo Lucena:CM:70,Blas Armoa:LW:70,Enzo Gim\xE9nez:RM:68,Mat\xEDas Espinoza:LB:68,Santiago Rojas:GK:68,Alberto Esp\xEDnola:RB:64,Gast\xF3n Olveira:GK:64,Santiago Arzamendia:LB:64",
  "Paraguay|2024": "Julio Enciso:CAM:82,Miguel Almir\xF3n:RW:81,Ram\xF3n Sosa:CF:79,Diego G\xF3mez:CM:78,Mauricio:CAM:78,Antonio Sanabria:ST:76,Gustavo G\xF3mez:CB:76,J\xFAnior Alonso:CB:76,Adam Bareiro:ST:74,Richard S\xE1nchez:CM:74,\xC1lex Arce:ST:73,Jes\xFAs Medina:RW:73,Juan Escobar:CB:73,Omar Alderete:CB:73,Diego Le\xF3n:LB:72,Enso Gonz\xE1lez:LW:72,Iv\xE1n Leguizam\xF3n:LW:72,W\xEDlder Viera:CM:70,Alan Rodr\xEDguez:LB:68,Carlos Coronel:GK:68,C\xE9sar Olmedo:RB:68,Alan N\xFA\xF1ez:RB:64,Enzo Gim\xE9nez:RM:64,Gustavo Cristaldo:LM:64",
  "Paraguay|2025": "Diego G\xF3mez:CM:82,Julio Enciso:CAM:82,Mauricio:CAM:78,Miguel Almir\xF3n:RW:78,Omar Alderete:CB:78,Isidro Pitta:ST:76,\xC1lex Arce:ST:73,Gustavo G\xF3mez:CB:73,J\xFAnior Alonso:CB:73,Orlando Gill:GK:73,Adam Bareiro:ST:72,Dami\xE1n Bobadilla:CM:72,Diego Gonz\xE1lez:RW:72,Diego Le\xF3n:LB:72,Enso Gonz\xE1lez:LW:72,Juan Jos\xE9 C\xE1ceres:RB:72,Lucas Quintana:CB:72,Mat\xEDas Galarza:CM:72,Richard S\xE1nchez:CM:72,Agust\xEDn S\xE1ndez:LB:70,Carlos Coronel:GK:68,C\xE9sar Olmedo:RB:68,Derlis Gonz\xE1lez:CF:68,Josu\xE9 Colm\xE1n:LW:68,Gustavo Cristaldo:LM:64",
  "Paraguay|2026": "Diego G\xF3mez:CM:82,Mauricio:CAM:79,Omar Alderete:CB:79,Miguel Almir\xF3n:RW:77,Isidro Pitta:ST:76,Diego Gonz\xE1lez:RW:74,Dami\xE1n Bobadilla:CM:73,Kaku:CAM:73,Orlando Gill:GK:73,Adam Bareiro:ST:72,Diego Le\xF3n:LB:72,Juan Jos\xE9 C\xE1ceres:RB:72,Lucas Quintana:CB:72,Robert Morales:ST:72,Rub\xE9n Lezcano:LW:72,Agust\xEDn S\xE1ndez:LB:70,Mat\xEDas Galarza:CM:70,Alcides Ben\xEDtez:RB:68,Carlos Coronel:GK:68,Enzo Gim\xE9nez:RM:68,Gustavo Cristaldo:LM:64",
  "Peru|2020": "Andr\xE9 Carrillo:CM:76,Ra\xFAl Ruid\xEDaz:ST:76,Luis Abram:CB:75,Gianluca Lapadula:ST:73,Pedro Aquino:CDM:73,Edison Flores:ST:72,Yoshimar Yot\xFAn:CM:72,Christian Cueva:CAM:70,Cristian Benavente:CAM:70,Pedro Gallese:GK:70,Renato Tapia:CDM:70,Luis Adv\xEDncula:RB:68,Miguel Trauco:LB:68,Marcos L\xF3pez:LB:64",
  "Poland|2016": "Robert Lewandowski:ST:89,Grzegorz Krychowiak:CDM:83,Arkadiusz Milik:ST:81,Piotr Zielinski:CM:79,Kamil Glik:CB:78,Wojciech Szcz\u0119sny:GK:78,Lukasz Fabianski:GK:77,Bartosz Kapustka:CAM:76,Jakub B\u0142aszczykowski:RW:76,Lukasz Piszczek:RB:76,Adrian Mierzejewski:CAM:73,Kamil Grosicki:LW:73,Lukasz Teodorczyk:ST:73,Maciej Rybus:LB:73,Artur J\u0119drzejczyk:CB:72,Eugen Polanski:CDM:72,Karol Linetty:CM:70,Micha\u0142 Pazdan:CB:70,Pawel Olkowski:RB:70,Bartosz Salamon:CB:68,Adam Mojta:LM:64,Andrzej Rybski:CF:64,Arkadiusz Wo\u017Aniak:RM:64,Jakub Kosecki:RW:64",
  "Poland|2017": "Robert Lewandowski:ST:89,Grzegorz Krychowiak:CDM:83,Piotr Zielinski:CM:82,Arkadiusz Milik:ST:81,Kamil Glik:CB:80,Wojciech Szcz\u0119sny:GK:80,Lukasz Teodorczyk:ST:79,Karol Linetty:CM:78,Lukasz Fabianski:GK:77,Bartosz Kapustka:CAM:76,Kamil Grosicki:LW:76,Lukasz Piszczek:RB:74,Jakub B\u0142aszczykowski:RW:73,Jan Bednarek:CB:73,Artur J\u0119drzejczyk:CB:72,Bartosz Bereszy\u0144ski:RB:72,Maciej Rybus:LB:72,Micha\u0142 Pazdan:CB:72,Adrian Mierzejewski:CAM:70,Ariel Borysiuk:CDM:68,Pawe\u0142 Wszo\u0142ek:RM:68,Adam Mojta:LM:64,Andrzej Rybski:CF:64,Maciej Makuszewski:RW:64",
  "Poland|2018": "Robert Lewandowski:ST:90,Piotr Zielinski:CM:85,Wojciech Szcz\u0119sny:GK:83,Arkadiusz Milik:ST:82,Grzegorz Krychowiak:CDM:81,Kamil Glik:CB:81,Karol Linetty:CM:79,Krzysztof Piatek:ST:79,Bartosz Bereszy\u0144ski:RB:78,Kamil Grosicki:LW:76,Lukasz Skorupski:GK:76,Jan Bednarek:CB:73,Robert Gumny:RB:73,Arkadiusz Reca:LM:72,Adrian Mierzejewski:CAM:70,Bartosz Kapustka:CAM:70,Jacek G\xF3ralski:CDM:70,Maciej Rybus:LB:70,Szymon \u017Burkowski:CM:70,Jakub B\u0142aszczykowski:RW:68,Jakub Piotrowski:CM:68,Kamil J\xF3\u017Awiak:LW:68,Michal Kucharczyk:RW:68,Pawe\u0142 Wszo\u0142ek:RM:68,Andrzej Rybski:CF:64",
  "Poland|2019": "Robert Lewandowski:ST:88,Arkadiusz Milik:ST:85,Krzysztof Piatek:ST:85,Piotr Zielinski:CM:85,Wojciech Szcz\u0119sny:GK:85,Bart\u0142omiej Dr\u0105gowski:GK:79,Jan Bednarek:CB:79,Karol Linetty:CM:79,Bartosz Bereszy\u0144ski:RB:77,Kamil Glik:CB:76,Krystian Bielik:CB:74,Sebastian Szymanski:CAM:74,Robert Gumny:RB:73,Arkadiusz Reca:LM:72,Kamil Grosicki:LW:72,Marcin Kami\u0144ski:CB:72,Szymon \u017Burkowski:CM:72,Bartosz Kapustka:CAM:70,Jacek G\xF3ralski:CDM:70,Maciej Rybus:LB:70,Mateusz Klich:CDM:70,Kamil J\xF3\u017Awiak:LW:68,Michal Kucharczyk:RW:68,Pawe\u0142 Wszo\u0142ek:RM:68,Hieronim Gierszewski:CF:64,Jakub B\u0142aszczykowski:RW:64",
  "Poland|2020": "Robert Lewandowski:ST:87,Piotr Zielinski:CM:85,Arkadiusz Milik:ST:84,Wojciech Szcz\u0119sny:GK:84,Krzysztof Piatek:ST:83,Jan Bednarek:CB:81,Grzegorz Krychowiak:CDM:80,Bart\u0142omiej Dr\u0105gowski:GK:79,Karol Linetty:CM:78,Matty Cash:RB:78,Sebastian Walukiewicz:RB:77,Sebastian Szymanski:CAM:76,Krystian Bielik:CB:74,Michal Karbownik:LB:74,Kamil Glik:CB:73,Filip Marchwinski:CAM:72,Kamil J\xF3\u017Awiak:LW:72,Mateusz Klich:CDM:72,Tomasz Kedziora:CB:72,Arkadiusz Reca:LM:70,Jakub Moder:CM:70,Kamil Grosicki:LW:70,Maciej Rybus:LB:70,Pawe\u0142 Wszo\u0142ek:RM:70,Szymon \u017Burkowski:CM:70,Damian Buczynski:CF:64,Konrad Wrzesinski:RW:64",
  "Poland|2021": "Robert Lewandowski:ST:87,Piotr Zielinski:CM:86,Arkadiusz Milik:ST:82,Jan Bednarek:CB:82,Matty Cash:RB:82,Wojciech Szcz\u0119sny:GK:82,Bart\u0142omiej Dr\u0105gowski:GK:80,Krzysztof Piatek:ST:80,Grzegorz Krychowiak:CDM:79,Sebastian Szymanski:CAM:79,Jakub Kaminski:LW:77,Jakub Moder:CM:77,Przemyslaw Frankowski:RB:76,Karol Linetty:CM:74,Michal Karbownik:LB:74,Krystian Bielik:CB:73,Kamil J\xF3\u017Awiak:LW:72,Szymon \u017Burkowski:CM:72,Tymoteusz Puchacz:LB:72,Pawe\u0142 Wszo\u0142ek:RM:70,Bartosz Kapustka:CAM:68,Bartosz Slisz:CDM:68,Mariusz Szuszkiewicz:CF:64",
  "Poland|2022": "Robert Lewandowski:ST:86,Piotr Zielinski:CM:85,Jan Bednarek:CB:82,Matty Cash:RB:82,Arkadiusz Milik:ST:80,Sebastian Szymanski:CAM:79,Wojciech Szcz\u0119sny:GK:79,Jakub Moder:CM:78,Krzysztof Piatek:ST:78,Bart\u0142omiej Dr\u0105gowski:GK:77,Jakub Kaminski:LW:77,Kacper Kozlowski:CAM:77,Grzegorz Krychowiak:CDM:76,Jakub Kiwior:CB:76,Przemyslaw Frankowski:RB:76,Szymon \u017Burkowski:CM:76,Kamil Pi\u0105tkowski:CB:73,Tomasz Kedziora:CB:73,Karol Linetty:CM:72,Michal Karbownik:LB:72,Kamil J\xF3\u017Awiak:LW:70,Lukasz Poreba:CDM:70,Tymoteusz Puchacz:LB:70,Adrian Danek:RM:64,Mariusz Szuszkiewicz:CF:64",
  "Poland|2023": "Robert Lewandowski:ST:85,Piotr Zielinski:CM:84,Matty Cash:RB:83,Jakub Kiwior:CB:82,Sebastian Szymanski:CAM:81,Jan Bednarek:CB:79,Marcin Bulka:GK:79,Jakub Kaminski:LW:78,Kamil Grabara:GK:78,Jakub Moder:CM:77,Przemyslaw Frankowski:RB:77,Arkadiusz Milik:ST:76,Kacper Kozlowski:CAM:76,Krzysztof Piatek:ST:76,Michal Skoras:LW:74,Szymon \u017Burkowski:CM:73,Arkadiusz Reca:LM:72,Maik Nawrocki:CB:72,Mateusz Wieteska:CB:72,Michal Karbownik:LB:72,Bartlomiej Wdowik:LB:70,Filip Szymczak:RW:70,Mateusz Legowski:CM:70,Aleksander Pawlak:RM:64",
  "Poland|2024": "Jakub Kiwior:CB:83,Matty Cash:RB:83,Piotr Zielinski:CM:82,Marcin Bulka:GK:81,Sebastian Szymanski:CAM:81,Nicola Zalewski:LM:80,Kamil Grabara:GK:79,Robert Lewandowski:ST:79,Jan Bednarek:CB:78,Jakub Moder:CM:77,Mateusz Bogusz:CAM:77,Przemyslaw Frankowski:RB:77,Jakub Kaminski:LW:76,Krzysztof Piatek:ST:75,Adam Buksa:ST:74,Jakub Piotrowski:CM:73,Kamil Pi\u0105tkowski:CB:73,Michal Skoras:LW:73,Dominik Marczuk:RW:72,Karol Linetty:CM:72,Micha\u0142 Gurgul:LB:72,Michal Karbownik:LB:72,Filip Szymczak:RW:70,Igor Orlikowski:RM:68",
  "Poland|2025": "Jakub Kiwior:CB:83,Matty Cash:RB:82,Marcin Bulka:GK:81,Nicola Zalewski:LM:81,Sebastian Szymanski:CAM:80,Kamil Grabara:GK:79,Piotr Zielinski:CM:79,Jakub Kaminski:LW:78,Jakub Moder:CM:78,Jan Bednarek:CB:78,Oskar Pietuszewski:LW:78,Robert Lewandowski:ST:78,Adrian Przyborek:CAM:76,Jan Ziolkowski:CB:76,Krzysztof Piatek:ST:76,Przemyslaw Frankowski:RB:76,Adam Buksa:ST:74,Jakub Piotrowski:CM:73,Kamil Pi\u0105tkowski:CB:73,Micha\u0142 Gurgul:LB:72,Dominik Marczuk:RW:68,Filip Luberecki:LB:68,Igor Orlikowski:RM:68",
  "Poland|2026": "Jakub Kiwior:CB:83,Matty Cash:RB:82,Nicola Zalewski:LM:81,Oskar Pietuszewski:LW:81,Marcin Bulka:GK:80,Jakub Kaminski:LW:78,Jan Bednarek:CB:78,Kacper Potulski:CB:78,Kamil Grabara:GK:78,Sebastian Szymanski:CAM:78,Jakub Moder:CM:77,Piotr Zielinski:CM:77,Adrian Przyborek:CAM:76,Krzysztof Piatek:ST:76,Przemyslaw Frankowski:RB:76,Robert Lewandowski:ST:76,Jakub Piotrowski:CM:73,Karol \u015Awiderski:ST:73,Wojciech Mo\u0144ka:CB:72,Filip Luberecki:LB:70,Micha\u0142 Gurgul:LB:70,Michael Ameyaw:RM:68",
  "Portugal|2016": "Cristiano Ronaldo:ST:91,Jo\xE3o M\xE1rio:CAM:84,Andr\xE9 Gomes:CM:83,Renato Sanches:CM:83,William Carvalho:CDM:83,Adrien Silva:CM:82,Bernardo Silva:CAM:81,Jo\xE3o Cancelo:RB:81,Jo\xE3o Moutinho:CM:80,Nani:LW:80,Rui Patr\xEDcio:GK:80,Anthony Lopes:GK:79,Danilo Pereira:CB:79,Rafa Silva:CF:79,C\xE9dric Soares:RB:78,F\xE1bio Coentr\xE3o:LB:78,Gelson Martins:RW:78,R\xFAben Neves:CDM:78,Andr\xE9 Silva:ST:77,Gon\xE7alo Guedes:LW:77,Rony Lopes:RW:77,Daniel Carri\xE7o:CB:76,M\xE1rio Rui:LB:76,Paulo Oliveira:CB:76,R\xFAben Semedo:CB:76,N\xE9lson Oliveira:ST:73,Filipe Morais:RM:64",
  "Portugal|2017": "Cristiano Ronaldo:ST:90,Bernardo Silva:CAM:85,Jo\xE3o M\xE1rio:CAM:84,Andr\xE9 Gomes:CM:83,Renato Sanches:CM:83,William Carvalho:CDM:83,Adrien Silva:CM:82,Andr\xE9 Silva:ST:82,Danilo Pereira:CB:81,Gelson Martins:RW:81,Jo\xE3o Cancelo:RB:81,N\xE9lson Semedo:RB:81,Gon\xE7alo Guedes:LW:80,Rui Patr\xEDcio:GK:80,Anthony Lopes:GK:79,Bruma:LW:79,Jo\xE3o Moutinho:CM:79,Rafa Silva:CF:79,R\xFAben Semedo:CB:79,R\xFAben Neves:CDM:77,F\xE1bio Coentr\xE3o:LB:76,Jos\xE9 Fonte:CB:76,M\xE1rio Rui:LB:76,Rony Lopes:RW:76,Rui Fonte:ST:74,Pepe:CB:73,Filipe Morais:RM:64",
  "Portugal|2018": "Cristiano Ronaldo:ST:91,Bernardo Silva:CAM:88,Jo\xE3o Cancelo:RB:87,Gon\xE7alo Guedes:LW:85,R\xFAben Neves:CDM:85,Andr\xE9 Silva:ST:84,Gelson Martins:RW:84,N\xE9lson Semedo:RB:84,Andr\xE9 Gomes:CM:83,Bruno Fernandes:CAM:83,Rony Lopes:RW:83,R\xFAben Dias:CB:83,Adrien Silva:CM:82,Danilo Pereira:CB:82,Renato Sanches:CM:82,William Carvalho:CDM:82,Anthony Lopes:GK:81,Diogo Jota:LW:80,Rui Patr\xEDcio:GK:80,Gedson Fernandes:CM:79,M\xE1rio Rui:LB:79,Rafa Silva:CF:79,R\xFAben Semedo:CB:76,Diogo Leite:CB:74,F\xE1bio Coentr\xE3o:LB:74,Rui Fonte:ST:74,R\xFAben Vinagre:LM:73,Filipe Morais:RM:64",
  "Portugal|2019": "Bernardo Silva:CAM:90,Cristiano Ronaldo:ST:90,Jo\xE3o F\xE9lix:CF:90,Bruno Fernandes:CAM:87,Jo\xE3o Cancelo:RB:87,R\xFAben Neves:CDM:86,Gon\xE7alo Guedes:LW:85,N\xE9lson Semedo:RB:85,R\xFAben Dias:CB:85,Diogo Jota:LW:84,Andr\xE9 Gomes:CM:83,Danilo Pereira:CB:83,Gelson Martins:RW:83,Andr\xE9 Silva:ST:82,Anthony Lopes:GK:82,Gedson Fernandes:CM:82,Rony Lopes:RW:82,William Carvalho:CDM:82,Rui Patr\xEDcio:GK:81,Ferro:CB:80,Renato Sanches:CM:80,Adrien Silva:CM:79,Gon\xE7alo Paci\xEAncia:ST:79,M\xE1rio Rui:LB:79,R\xFAben Vinagre:LM:77,Diogo Leite:CB:74,Pedro Rebocho:LB:74,Tom\xE1s Esteves:RM:68",
  "Portugal|2020": "Bruno Fernandes:CAM:90,Jo\xE3o F\xE9lix:CF:90,Bernardo Silva:CAM:89,Cristiano Ronaldo:ST:87,R\xFAben Dias:CB:87,Jo\xE3o Cancelo:RB:86,R\xFAben Neves:CDM:86,Diogo Jota:LW:85,N\xE9lson Semedo:RB:85,Andr\xE9 Silva:ST:83,Pedro Neto:RW:83,Rafael Le\xE3o:LW:83,Andr\xE9 Gomes:CM:82,Danilo Pereira:CB:82,F\xE1bio Silva:ST:82,Anthony Lopes:GK:81,Gelson Martins:RW:81,Renato Sanches:CM:81,William Carvalho:CDM:81,Rui Patr\xEDcio:GK:80,Gedson Fernandes:CM:79,M\xE1rio Rui:LB:79,Nuno Mendes:LB:78,R\xFAben Vinagre:LM:77,Adrien Silva:CM:76,Tom\xE1s Esteves:RM:76,Pedro Mendes:CB:74,Paulo Oliveira:CB:73",
  "Portugal|2021": "Bruno Fernandes:CAM:90,Jo\xE3o F\xE9lix:CF:90,Bernardo Silva:CAM:89,R\xFAben Dias:CB:89,Diogo Jota:LW:87,Jo\xE3o Cancelo:RB:87,Andr\xE9 Silva:ST:86,Cristiano Ronaldo:ST:86,R\xFAben Neves:CDM:86,Nuno Mendes:LB:85,Pedro Gon\xE7alves:LW:85,N\xE9lson Semedo:RB:84,Pedro Neto:RW:84,Jo\xE3o Palhinha:CDM:83,Renato Sanches:CM:83,F\xE1bio Silva:ST:82,Andr\xE9 Gomes:CM:81,Danilo Pereira:CB:81,S\xE9rgio Oliveira:CM:81,Anthony Lopes:GK:80,Diogo Costa:GK:80,Gelson Martins:RW:80,Gon\xE7alo In\xE1cio:CB:80,Gedson Fernandes:CM:79,Nuno Tavares:LB:79,Domingos Duarte:CB:78,Tom\xE1s Esteves:RM:74",
  "Portugal|2022": "Bernardo Silva:CAM:89,Bruno Fernandes:CAM:89,Rafael Le\xE3o:LW:89,R\xFAben Dias:CB:89,Jo\xE3o Cancelo:RB:88,Jo\xE3o F\xE9lix:CF:88,Diogo Jota:LW:87,Nuno Mendes:LB:87,Matheus Nunes:RB:86,Vitinha:CDM:86,Pedro Neto:RW:85,R\xFAben Neves:CDM:85,Andr\xE9 Silva:ST:84,Diogo Costa:GK:84,Cristiano Ronaldo:ST:83,Gon\xE7alo Ramos:ST:83,Renato Sanches:CM:83,Gon\xE7alo In\xE1cio:CB:82,Andr\xE9 Gomes:CM:80,Jos\xE9 S\xE1:GK:80,Nuno Tavares:LB:80,Ant\xF3nio Silva:CB:79,Danilo Pereira:CB:79,Gelson Martins:RW:79,S\xE9rgio Oliveira:CM:79,Miguel Crespo:CM:77,Tom\xE1s Esteves:RM:68",
  "Portugal|2023": "Rafael Le\xE3o:LW:90,Bernardo Silva:CAM:89,Bruno Fernandes:CAM:89,R\xFAben Dias:CB:89,Nuno Mendes:LB:88,Jo\xE3o Cancelo:RB:87,Matheus Nunes:RB:87,Ant\xF3nio Silva:CB:86,Diogo Costa:GK:86,Diogo Jota:LW:86,Gon\xE7alo Ramos:ST:86,Jo\xE3o F\xE9lix:CF:86,Jo\xE3o Neves:CM:86,Gon\xE7alo In\xE1cio:CB:85,Pedro Neto:RW:85,Vitinha:ST:82,Andr\xE9 Silva:ST:81,Renato Sanches:CM:81,Andr\xE9 Gomes:CM:80,Gedson Fernandes:CM:80,Jos\xE9 S\xE1:GK:80,Nuno Tavares:LB:80,Tiago Djal\xF3:CB:80,Carlos Forbs:RW:77,R\xFAben Vinagre:LM:75,Tom\xE1s Esteves:RM:64",
  "Portugal|2024": "Rafael Le\xE3o:LW:90,R\xFAben Dias:CB:89,Bernardo Silva:CAM:88,Bruno Fernandes:CAM:88,Jo\xE3o Neves:CM:87,Nuno Mendes:LB:87,Pedro Neto:RW:87,Ant\xF3nio Silva:CB:86,Diogo Costa:GK:86,Diogo Jota:LW:86,Gon\xE7alo In\xE1cio:CB:86,Gon\xE7alo Ramos:ST:86,Matheus Nunes:RB:86,Diogo Dalot:RB:85,Francisco Concei\xE7\xE3o:RW:84,Jo\xE3o F\xE9lix:CF:83,Tom\xE1s Ara\xFAjo:CB:83,Nuno Tavares:LB:82,F\xE1bio Silva:ST:80,Gedson Fernandes:CM:80,Cristiano Ronaldo:ST:79,Daniel Bragan\xE7a:CM:79,Jos\xE9 S\xE1:GK:79,Mateus Fernandes:CM:79,R\xFAben Vinagre:LM:73,Tom\xE1s Esteves:RM:70",
  "Portugal|2025": "Jo\xE3o Neves:CM:91,Nuno Mendes:LB:89,Rafael Le\xE3o:LW:88,R\xFAben Dias:CB:88,Pedro Neto:RW:87,Bernardo Silva:CAM:86,Bruno Fernandes:CAM:86,Diogo Jota:LW:86,Geovany Quenda:RW:86,Gon\xE7alo In\xE1cio:CB:86,Gon\xE7alo Ramos:ST:86,Diogo Costa:GK:85,Matheus Nunes:RB:85,Ant\xF3nio Silva:CB:84,Diogo Dalot:RB:84,Mateus Fernandes:CM:84,Tom\xE1s Ara\xFAjo:CB:84,F\xE1bio Silva:ST:83,Jo\xE3o F\xE9lix:CF:82,Nuno Tavares:LB:82,Gedson Fernandes:CM:81,Jo\xE3o Sim\xF5es:CM:79,Rodrigo Gomes:LM:79,Cristiano Ronaldo:ST:78,Jos\xE9 S\xE1:GK:76,Tom\xE1s Esteves:RM:68",
  "Portugal|2026": "Jo\xE3o Neves:CM:91,Nuno Mendes:LB:89,Rafael Le\xE3o:LW:88,Pedro Neto:RW:87,R\xFAben Dias:CB:87,Matheus Nunes:RB:86,Bruno Fernandes:CAM:85,Diogo Costa:GK:85,Geovany Quenda:RW:85,Gon\xE7alo In\xE1cio:CB:85,Rodrigo Mora:CAM:85,Gon\xE7alo Ramos:ST:84,Mateus Fernandes:CM:84,Ant\xF3nio Silva:CB:83,Diogo Dalot:RB:83,F\xE1bio Silva:ST:83,Pedro Gon\xE7alves:LW:83,Tom\xE1s Ara\xFAjo:CB:83,Gedson Fernandes:CM:80,Jo\xE3o Sim\xF5es:CM:79,Nuno Tavares:LB:79,Rodrigo Gomes:LM:79,Cristiano Ronaldo:ST:78,Rui Silva:GK:76,Tom\xE1s Esteves:RM:68",
  "Romania|2016": "Nicolae Stanciu:CAM:76,Costel Pantilimon:GK:74,\u0218tefan Radu:LB:74,Ciprian T\u0103t\u0103ru\u0219anu:GK:73,Florin Gardo\u0219:CB:73,Gabriel Torje:RW:73,Alexandru Maxim:CAM:72,Bogdan Stancu:ST:72,Claudiu Ke\u0219er\xFC:ST:72,Denis Alibec:ST:70,Adrian Popa:RW:68,Andrei Prepeli\u021B\u0103:CM:68,Paul Anton:CM:68,R\u0103zvan Marin:CM:68,Valeric\u0103 G\u0103man:CB:68,Adrian Boro\u0219tean:RM:64,Adrian Codin:CF:64,Adrian Stoian:LW:64,Alexandru M\u0103\u021Bel:RB:64,Alexandru Mitri\u021B\u0103:LW:64,Alexandru Stan:LM:64,Bogdan V\u0103t\u0103jelu:LB:64,Drago\u0219 Nedelcu:CDM:64",
  "Romania|2017": "Nicolae Stanciu:CAM:76,Vlad Chiriche\u0219:CDM:75,\u0218tefan Radu:LB:74,Ciprian T\u0103t\u0103ru\u0219anu:GK:73,Florin Andone:ST:73,Claudiu Ke\u0219er\xFC:ST:72,Costel Pantilimon:GK:72,Alexandru Chipciu:LB:70,Bogdan Stancu:ST:70,Dorin Rotariu:RW:70,Florin Gardo\u0219:CB:70,Gabriel Torje:RW:70,Adrian Stoian:LW:68,Drago\u0219 Nedelcu:CDM:68,Florin T\u0103nase:CAM:68,Florinel Coman:LW:68,R\u0103zvan Marin:CM:68,Romario Benzar:RB:68,Sergiu Hanca:RM:68,Adrian Codin:CF:64,Alexandru Stan:LM:64,Claudiu Belu:RB:64",
  "Romania|2018": "Ionu\u021B Radu:GK:76,R\u0103zvan Marin:CM:76,Florin Andone:ST:74,\u0218tefan Radu:LB:74,Nicolae Stanciu:CAM:73,Vlad Chiriche\u0219:CDM:73,Alexandru Mitri\u021B\u0103:LW:72,Ciprian T\u0103t\u0103ru\u0219anu:GK:72,Claudiu Ke\u0219er\xFC:ST:72,Dennis Man:RW:72,Alexandru Chipciu:LB:70,Alexandru Cic\xE2ld\u0103u:CAM:70,Cristian Manea:RB:70,Erik Bicfalvi:ST:70,Adrian Stoian:LW:68,Alexandru B\u0103lu\u021B\u0103:RW:68,Drago\u0219 Nedelcu:CDM:68,Paul Anton:CM:68,Romario Benzar:RB:68,Adrian Boro\u0219tean:RM:64,Adrian Codin:CF:64,Adrian Ungureanu:LM:64",
  "Romania|2019": "Ionu\u021B Radu:GK:79,R\u0103zvan Marin:CM:79,Dennis Man:RW:74,Florin Andone:ST:74,Florinel Coman:LW:74,George Pu\u0219ca\u0219:ST:74,Vlad Chiriche\u0219:CDM:74,Alexandru Cic\xE2ld\u0103u:CAM:73,\u0218tefan Radu:LB:73,Tudor B\u0103lu\u021B\u0103:CDM:73,Claudiu Ke\u0219er\xFC:ST:72,Constantin Budescu:CAM:72,Cristian Manea:RB:72,Ionu\u021B Nedelcearu:CB:72,Ciprian T\u0103t\u0103ru\u0219anu:GK:70,Nicu\u0219or Bancu:LB:70,Romario Benzar:RB:70,Alexandru B\u0103lu\u021B\u0103:RW:68,Adrian Codin:CF:64,Adrian Pribac:LM:64,Adrian Stoian:LW:64,Alexandru Vrabie:RM:64",
  "Romania|2020": "Ionu\u021B Radu:GK:78,R\u0103zvan Marin:CM:77,Dennis Man:RW:75,Alexandru Cic\xE2ld\u0103u:CAM:74,Alexandru Mitri\u021B\u0103:LW:74,Florinel Coman:LW:74,George Pu\u0219ca\u0219:ST:74,Ianis Hagi:CAM:73,Vlad Chiriche\u0219:CDM:73,Claudiu Ke\u0219er\xFC:ST:72,Florin Andone:ST:72,Ionu\u021B Nedelcearu:CB:72,\u0218tefan Radu:LB:72,Tudor B\u0103lu\u021B\u0103:CDM:72,Cristian Manea:RB:70,Alexandru B\u0103lu\u021B\u0103:RW:68,Florin Ni\u021B\u0103:GK:68,Nicu\u0219or Bancu:LB:68,Romario Benzar:RB:68,Adrian Codin:CF:64,Adrian Pribac:LM:64,Alexandru Vrabie:RM:64",
  "Romania|2021": "R\u0103zvan Marin:CM:79,Dennis Man:RW:78,Alexandru Cic\xE2ld\u0103u:CAM:77,Alexandru Mitri\u021B\u0103:LW:76,Ianis Hagi:CAM:76,Valentin Mih\u0103il\u0103:LW:76,Ionu\u021B Radu:GK:74,Andrei Burc\u0103:CB:72,George Pu\u0219ca\u0219:ST:72,Radu Dr\u0103gu\u0219in:CB:72,Vlad Chiriche\u0219:CDM:72,Cristian Manea:RB:70,Marius Marin:CDM:70,Deian Sorescu:RB:68,Florin Ni\u021B\u0103:GK:68,\u0218tefan Radu:LB:68,Adrian Codin:CF:64,Alexandru B\u0103lu\u021B\u0103:RW:64,George Tudoran:RM:64,M\xE1rio Camora:LB:64",
  "Romania|2022": "R\u0103zvan Marin:CM:78,Alexandru Cic\xE2ld\u0103u:CAM:77,Ianis Hagi:CAM:76,Dennis Man:RW:75,Olimpiu Moru\u021Ban:RW:73,Alexandru Mitri\u021B\u0103:LW:72,Andrei Burc\u0103:CB:72,Florinel Coman:LW:72,George Pu\u0219ca\u0219:ST:72,Ionu\u021B Radu:GK:72,Radu Dr\u0103gu\u0219in:CB:72,Cristian Manea:RB:70,Deian Sorescu:RB:68,Hora\u021Biu Moldovan:GK:68,Nicu\u0219or Bancu:LB:68,Tudor B\u0103lu\u021B\u0103:CDM:68,Vlad Chiriche\u0219:CDM:68,Adrian Doroban\u021Bu:CF:64,Mihai Gu\u0219u:RM:64",
  "Romania|2023": "Radu Dr\u0103gu\u0219in:CB:81,R\u0103zvan Marin:CM:76,Darius Olaru:CAM:75,Nicolae Stanciu:CAM:75,Dennis Man:RW:73,Florinel Coman:LW:73,Olimpiu Moru\u021Ban:RW:73,Andrei Burc\u0103:CB:72,Cristian Manea:RB:72,Ionu\u021B Radu:GK:72,Octavian Popescu:LW:72,Hora\u021Biu Moldovan:GK:70,Andrei Borza:LB:68,Andrei \u0218erban:LM:64,Mihai Gu\u0219u:RM:64,Petre Simon:CF:64",
  "Romania|2024": "Radu Dr\u0103gu\u0219in:CB:82,Dennis Man:RW:80,Andrei Ra\u021Biu:RB:76,Darius Olaru:CAM:76,Florinel Coman:LW:76,Nicolae Stanciu:CAM:73,Alexandru Mitri\u021B\u0103:LW:72,Daniel B\xEErligea:ST:72,Denis Dr\u0103gu\u0219:ST:72,Olimpiu Moru\u021Ban:RW:72,R\u0103zvan Marin:CM:72,\u0218tefan T\xE2rnovanu:GK:72,Cristian Manea:RB:70,Hora\u021Biu Moldovan:GK:70,Andrei Borza:LB:68,Nicu\u0219or Bancu:LB:68,Alexandru Capac:CF:64,Andrei \u0218erban:LM:64,Mihai Gu\u0219u:RM:64",
  "Romania|2025": "Radu Dr\u0103gu\u0219in:CB:82,Andrei Ra\u021Biu:RB:80,Dennis Man:RW:79,Darius Olaru:CAM:76,Daniel B\xEErligea:ST:73,Florinel Coman:LW:73,Ionu\u021B Radu:GK:73,Louis Munteanu:ST:73,\u0218tefan Baiaram:LW:73,\u0218tefan T\xE2rnovanu:GK:73,Denis Dr\u0103gu\u0219:ST:72,Nicolae Stanciu:CAM:72,R\u0103zvan Marin:CM:72,Alexandru Dobre:RW:70,Andrei Borza:LB:70,Cristian Manea:RB:68,Raul Opru\u021B:LB:68,Abel Coaj\u0103:LM:64,Alexandru Capac:CF:64,Constantin Radu:RM:64",
  "Romania|2026": "Radu Dr\u0103gu\u0219in:CB:81,Andrei Ra\u021Biu:RB:80,Dennis Man:RW:79,Ionu\u021B Radu:GK:76,Daniel B\xEErligea:ST:73,Darius Olaru:CAM:73,Louis Munteanu:ST:73,\u0218tefan Baiaram:LW:73,Alexandru Mitri\u021B\u0103:LW:72,R\u0103zvan Marin:CM:72,\u0218tefan T\xE2rnovanu:GK:72,\xDCmit Akda\u011F:CB:72,Alexandru Cic\xE2ld\u0103u:CAM:70,Alexandru Dobre:RW:70,Andrei Borza:LB:70,Cristian Manea:RB:68,Raul Opru\u021B:LB:68,Abel Coaj\u0103:LM:64,Mihai Gu\u0219u:RM:64",
  "Russia|2016": "Alan Dzagoev:CM:80,M\xE1rio Fernandes:RB:80,Igor Akinfeev:GK:79,Oleg Shatov:CAM:79,Igor Smolnikov:RB:78,Pavel Mamaev:CM:78,Artem Dzyuba:ST:77,Denis Cheryshev:LW:77,Fedor Smolov:ST:77,Jo\xE3ozinho:LW:77,Aleksandr Kokorin:CF:76,Dmitriy Kombarov:LB:76,Roman Neust\xE4dter:CB:76,Yuriy Lodygin:GK:76,Ari:ST:74,Denis Glushakov:CM:74,Igor Denisov:CDM:74,Aleksandr Erokhin:CAM:73,Aleksandr Samedov:RW:73,Aleksey Ionov:RW:73,Andrey Semenov:CB:73,Artur Yusupov:CM:73,Dmitriy Tarasov:CDM:73,Georgiy Shchennikov:LB:73,Ivan Novoseltsev:CB:73,Vitaliy Dyakov:CB:72,Yuriy Zhirkov:LM:70,Adlan Katsaev:RM:64",
  "Russia|2017": "M\xE1rio Fernandes:RB:80,Alan Dzagoev:CM:79,Fedor Smolov:ST:79,Aleksandr Kokorin:CF:78,Igor Akinfeev:GK:78,Aleksandr Golovin:CAM:77,Aleksey Miranchuk:CAM:77,Artem Dzyuba:ST:77,Andrey Lunev:GK:76,Denis Glushakov:CM:76,Dmitriy Poloz:LW:76,Igor Smolnikov:RB:76,Pavel Mamaev:CM:76,Daler Kuzyaev:CM:74,Denis Cheryshev:LW:73,Elmir Nabiullin:LB:73,Georgiy Shchennikov:LB:73,Roman Neust\xE4dter:CB:73,Andrey Semenov:CB:72,Georgiy Dzhikiya:CB:72,Maksim Kanunnikov:ST:72,Roman Emeljanov:CDM:72,Aleksandr Samedov:RW:70,Aleksandr Tashaev:RW:70,Dmitriy Tarasov:CDM:70,Ilya Kutepov:CB:70,Denis Tkachuk:LM:68,Adlan Katsaev:RM:64",
  "Russia|2018": "Aleksandr Golovin:CAM:83,M\xE1rio Fernandes:RB:83,Fedor Smolov:ST:80,Alan Dzagoev:CM:79,Aleksey Miranchuk:CAM:79,Artem Dzyuba:ST:79,Roman Zobnin:CM:79,Aleksandr Kokorin:CF:78,Daler Kuzyaev:CM:78,Igor Akinfeev:GK:78,Andrey Lunev:GK:77,Fedor Chalov:ST:77,Denis Cheryshev:LW:76,Igor Smolnikov:RB:76,Pavel Mamaev:CM:75,Dmitriy Poloz:LW:74,Georgiy Dzhikiya:CB:74,Aleksandr Tashaev:RW:73,Dmitriy Skopintsev:LB:73,Georgiy Shchennikov:LB:73,Ilya Kutepov:CB:73,Aleksey Ionov:RW:72,Andrey Semenov:CB:72,Maksim Belyaev:CB:72,Roman Emeljanov:CDM:72,Anton Shvets:CDM:70,Denis Tkachuk:LM:68,Adlan Katsaev:RM:64",
  "Russia|2019": "M\xE1rio Fernandes:RB:83,Aleksandr Golovin:CAM:82,Aleksey Miranchuk:CAM:80,Artem Dzyuba:ST:80,Fedor Chalov:ST:80,Roman Zobnin:CM:79,Daler Kuzyaev:CM:78,Dmitriy Barinov:CDM:78,Fedor Smolov:ST:78,Shapi Suleymanov:RW:78,Georgiy Dzhikiya:CB:77,Igor Akinfeev:GK:77,Matvey Safonov:GK:77,Yuriy Gazinskiy:CM:77,Alan Dzagoev:CM:76,Aleksandr Kokorin:CF:76,Magomed Ozdoev:CDM:76,Vyacheslav Karavaev:RB:76,Zelimkhan Bakaev:RW:76,Denis Cheryshev:LW:74,Dmitriy Skopintsev:LB:73,Georgiy Shchennikov:LB:73,Igor Diveev:CB:73,Maksim Belyaev:CB:73,Andrey Semenov:CB:72,Dmitriy Poloz:LW:72,Denis Tkachuk:LM:68,Adlan Katsaev:RM:64",
  "Russia|2020": "M\xE1rio Fernandes:RB:82,Aleksandr Golovin:CAM:81,Aleksey Miranchuk:CAM:80,Artem Dzyuba:ST:79,Dmitriy Barinov:CDM:79,Fedor Chalov:ST:79,Matvey Safonov:GK:79,Roman Zobnin:CM:79,Aleksandr Maksimenko:GK:78,Shapi Suleymanov:RW:78,Zelimkhan Bakaev:RW:77,Daler Kuzyaev:CM:76,Fedor Smolov:ST:76,Ivan Oblyakov:CM:76,Yuriy Gazinskiy:CM:76,Aleksandr Kokorin:CF:75,Igor Diveev:CB:74,Magomed Ozdoev:CDM:74,Vyacheslav Karavaev:RB:74,Daniil Lesovoy:LW:73,Denis Cheryshev:LW:73,Dmitriy Skopintsev:LB:72,Maksim Belyaev:CB:72,Evgeniy Chernov:LB:70,Roman Evgenjev:CB:70,Danil Krugovoy:LM:68,Adlan Katsaev:RM:64",
  "Russia|2021": "Aleksandr Golovin:CAM:83,Aleksey Miranchuk:CAM:80,M\xE1rio Fernandes:RB:80,Matvey Safonov:GK:80,Aleksandr Maksimenko:GK:79,Roman Zobnin:CM:79,Aleksandr Sobolev:ST:78,Artem Dzyuba:ST:78,Dmitriy Barinov:CDM:78,Fedor Chalov:ST:78,Daler Kuzyaev:CM:77,Daniil Fomin:CDM:77,Georgiy Dzhikiya:CB:77,Denis Makarov:RW:76,Shapi Suleymanov:RW:76,Vyacheslav Karavaev:RB:76,Ivan Oblyakov:CM:75,Igor Diveev:CB:74,Daniil Lesovoy:LW:73,Dmitriy Skopintsev:LB:73,Yuriy Gazinskiy:CM:73,Aleksandr Kokorin:CF:72,Denis Cheryshev:LW:72,Dmitriy Chistyakov:CB:72,Ilya Samoshnikov:LB:72,Maksim Osipenko:CB:72,Dmitriy Rybchinskiy:RM:70",
  "Russia|2022": "Aleksandr Golovin:CAM:82,Matvey Safonov:GK:80,Arsen Zakharyan:CAM:79,Dmitriy Barinov:CDM:78,Aleksandr Sobolev:ST:77,Daler Kuzyaev:CM:77,Daniil Fomin:CDM:77,Daniil Utkin:CM:76,Fedor Chalov:ST:76,Georgiy Dzhikiya:CB:76,Konstantin Tyukavin:ST:76,M\xE1rio Fernandes:RB:76,Denis Makarov:RW:74,Igor Diveev:CB:74,Ivan Oblyakov:CM:74,Roman Zobnin:CM:74,Vyacheslav Karavaev:RB:74,Maksim Osipenko:CB:73,Andrey Mostovoy:LW:72,Anton Zinkovskiy:LW:72,Dmitriy Chistyakov:CB:72,Shapi Suleymanov:RW:72,Aleksandr Maksimenko:GK:70,Ilya Samoshnikov:LB:70,Maksim Glushenkov:CF:70,Danil Stepanov:LB:68,Dmitriy Rybchinskiy:RM:68",
  "Russia|2023": "Aleksandr Golovin:CAM:83,Matvey Safonov:GK:80,Arsen Zakharyan:CAM:79,Fedor Chalov:ST:78,Aleksandr Sobolev:ST:77,Daler Kuzyaev:CM:77,Ivan Oblyakov:CM:77,Konstantin Tyukavin:ST:77,Daniil Utkin:CM:76,Georgiy Dzhikiya:CB:76,Igor Diveev:CB:76,Maksim Glushenkov:CF:76,Aleksandr Silyanov:RB:74,Roman Zobnin:CM:74,Vyacheslav Karavaev:RB:74,Maksim Osipenko:CB:73,Ruslan Litvinov:CB:73,Andrey Mostovoy:LW:72,Anton Zinkovskiy:LW:72,Aleksandr Selikhov:GK:70,Artem Makarchuk:LB:70,Dmitriy Skopintsev:LB:70,Roman Ezhov:RW:70,Shapi Suleymanov:RW:70,Danil Krugovoy:LM:68,Dmitriy Rybchinskiy:RM:68",
  "Russia|2024": "Aleksandr Golovin:CAM:83,Matvey Safonov:GK:82,Arsen Zakharyan:CAM:80,Konstantin Tyukavin:ST:80,Maksim Glushenkov:CF:80,Fedor Chalov:ST:78,Daler Kuzyaev:CM:77,Ivan Oblyakov:CM:77,Aleksandr Sobolev:ST:76,Igor Diveev:CB:76,Sergey Pinyaev:LW:76,Aleksandr Silyanov:RB:74,Daniil Utkin:CM:74,Maksim Osipenko:CB:73,Roman Zobnin:CM:73,Ruslan Litvinov:CB:73,Sergey Volkov:RB:73,Aleksandr Maksimenko:GK:72,Aleksandr Soldatenkov:CB:72,Andrey Mostovoy:LW:72,Dmitriy Skopintsev:LB:72,Ilya Samoshnikov:LB:72,Danil Krugovoy:LM:71,Denis Makarov:RW:70,Roman Ezhov:RW:70,Arkadiy Solop:RM:64",
  "Russia|2025": "Aleksandr Golovin:CAM:82,Aleksey Batrakov:CAM:82,Matvey Kislyak:CM:81,Matvey Safonov:GK:81,Konstantin Tyukavin:ST:80,Maksim Glushenkov:CF:79,Igor Diveev:CB:77,Ivan Oblyakov:CM:77,Sergey Pinyaev:LW:77,Stanislav Agkatsev:GK:77,Aleksandr Silyanov:RB:76,Fedor Chalov:ST:76,Kirill Glebov:RW:76,Aleksandr Sobolev:ST:74,Daler Kuzyaev:CM:73,Danil Krugovoy:LM:73,Danil Prutsev:CM:73,Evgeniy Morozov:CB:73,Ilya Rozhkov:LB:73,Maksim Osipenko:CB:73,Ruslan Litvinov:CB:73,Vyacheslav Karavaev:RB:73,Andrey Mostovoy:LW:72,Ilya Samoshnikov:LB:72,Yaroslav Gladyshev:RW:72,Vladislav Saus:RM:68",
  "Russia|2026": "Aleksey Batrakov:CAM:82,Matvey Safonov:GK:82,Matvey Kislyak:CM:81,Aleksandr Golovin:CAM:80,Konstantin Tyukavin:ST:79,Igor Diveev:CB:77,Ivan Oblyakov:CM:77,Kirill Glebov:RW:77,Sergey Pinyaev:LW:77,Stanislav Agkatsev:GK:77,Aleksandr Silyanov:RB:76,Aleksandr Sobolev:ST:74,Dmitriy Vorobyov:ST:73,Ilya Rozhkov:LB:73,Ruslan Litvinov:CB:73,Daler Kuzyaev:CM:72,Daniil Denisov:RB:72,Igor Dmitriev:LW:72,Dmitriy Pestryakov:RW:70,Ilya Samoshnikov:LB:70,Vladislav Saus:RM:70,Evgeniy Kharin:LM:68",
  "Scotland|2016": "Jordan Rhodes:ST:77,Oliver Burke:ST:77,Ross McCormack:CF:77,Andrew Robertson:LB:76,James McArthur:CM:76,Matt Ritchie:RM:76,Matt Phillips:RW:74,Robert Snodgrass:RW:74,Charlie Adam:CM:73,Chris Martin:ST:73,Grant Hanley:CB:73,James Morrison:CM:73,Scott Brown:CM:73,George Boyd:LW:72,Ikechi Anya:LM:72,David Marshall:GK:70,Kris Commons:CAM:70,Liam Bridcutt:CDM:70,Russell Martin:CB:70,Alan Hutton:RB:68,Allan McGregor:GK:68,Kevin McDonald:CDM:68,Phil Bardsley:RB:68,Barry Douglas:LB:64",
  "Scotland|2017": "Oliver Burke:ST:78,Jordan Rhodes:ST:77,Matt Phillips:RW:77,Matt Ritchie:RM:77,Ross McCormack:CF:77,Tom Cairney:CM:77,James McArthur:CM:76,Robert Snodgrass:RW:76,Charlie Adam:CM:73,Chris Martin:ST:73,Grant Hanley:CB:73,James Morrison:CM:73,Ryan Fraser:LW:73,George Boyd:LW:72,Ikechi Anya:LM:72,Kevin McDonald:CDM:72,Craig Gordon:GK:70,David Marshall:GK:70,Liam Bridcutt:CDM:70,Russell Martin:CB:70,Alan Hutton:RB:68,Kieran Tierney:LB:68,Phil Bardsley:RB:68,Stephen Kingsley:LB:68",
  "Scotland|2018": "Andrew Robertson:LB:86,Tom Cairney:CM:80,Kieran Tierney:LB:79,Ryan Fraser:LW:79,Matt Ritchie:RM:78,Oliver Burke:ST:78,Angus Gunn:GK:77,Matt Phillips:RW:77,Robert Snodgrass:RW:76,Scott McTominay:CM:76,Stuart Armstrong:CM:76,James McArthur:CM:74,Jordan Rhodes:ST:74,Callum Paterson:ST:73,Ross McCormack:CF:73,Grant Hanley:CB:72,Kevin McDonald:CDM:72,Craig Gordon:GK:70,George Boyd:LW:70,Ikechi Anya:LM:70,Alan Hutton:RB:68,Callum McGregor:CDM:68,Phil Bardsley:RB:68",
  "Scotland|2019": "Andrew Robertson:LB:89,Ryan Fraser:LW:83,Scott McTominay:CM:83,Kieran Tierney:LB:82,John McGinn:CM:81,Tom Cairney:CM:79,Ch\xE9 Adams:ST:78,Matt Ritchie:RM:78,Oli McBurnie:ST:78,Angus Gunn:GK:77,James McArthur:CM:76,Matt Phillips:RW:76,Oliver Burke:ST:76,Robert Snodgrass:RW:76,Liam Cooper:CB:74,Callum McGregor:CDM:73,Billy Gilmour:CDM:70,Craig Gordon:GK:68,George Boyd:LW:68,Ikechi Anya:LM:68,Phil Bardsley:RB:68,Ross McCormack:CF:68,Donald Love:RB:64",
  "Scotland|2020": "Andrew Robertson:LB:89,Kieran Tierney:LB:84,Ryan Fraser:LW:82,Scott McTominay:CM:82,John McGinn:CM:81,Ch\xE9 Adams:ST:79,Oli McBurnie:ST:79,Tom Cairney:CM:79,Matt Ritchie:RM:77,Billy Gilmour:CDM:76,James Forrest:RW:76,John Fleck:CM:76,Matt Phillips:RW:76,Angus Gunn:GK:75,Callum McGregor:CDM:74,Oliver Burke:ST:74,Aaron Hickey:RB:73,Lewis Morgan:LW:72,Alan Trouten:CF:64,Ali Crawford:LM:64,Craig Gordon:GK:64,Liam Palmer:RB:64",
  "Scotland|2021": "Andrew Robertson:LB:88,Kieran Tierney:LB:84,Scott McTominay:CM:84,John McGinn:CM:83,Ch\xE9 Adams:ST:81,Aaron Hickey:RB:79,Billy Gilmour:CDM:79,Oli McBurnie:ST:78,Ryan Fraser:LW:78,Ryan Christie:CM:77,Tom Cairney:CM:77,Callum McGregor:CDM:76,Liam Cooper:CB:76,Ryan Gauld:CAM:75,James Forrest:RW:74,Oliver Burke:ST:74,Jack Hendry:CB:73,Grant Hanley:CB:72,Matt Phillips:RW:72,Matt Ritchie:RM:72,Angus Gunn:GK:70,Nathan Patterson:RB:70,Siriki Demb\xE9l\xE9:LW:68,Alan Trouten:CF:64",
  "Scotland|2022": "Andrew Robertson:LB:88,John McGinn:CM:84,Kieran Tierney:LB:84,Scott McTominay:CM:84,Ch\xE9 Adams:ST:82,Aaron Hickey:RB:80,Billy Gilmour:CDM:78,Ryan Christie:CM:77,Scott McKenna:CB:77,Callum McGregor:CDM:76,Liam Cooper:CB:76,David Turnbull:CM:75,Ryan Gauld:CAM:75,Jack Hendry:CB:74,Lewis Morgan:LW:74,Calvin Ramsay:RB:73,Jacob Brown:ST:73,James Forrest:RW:73,Oli McBurnie:ST:73,Angus Gunn:GK:70,Siriki Demb\xE9l\xE9:LW:70,Johnny Russell:RW:68,Matt Ritchie:RM:68,Cammy Smith:CF:64",
  "Scotland|2023": "Andrew Robertson:LB:86,Aaron Hickey:RB:83,John McGinn:CM:83,Scott McTominay:CM:83,Kieran Tierney:LB:82,Ch\xE9 Adams:ST:81,Lewis Ferguson:CM:80,Nathan Patterson:RB:80,Ryan Christie:CM:78,Ben Gannon-Doak:RW:77,Scott McKenna:CB:77,Ryan Fraser:LW:76,Ryan Gauld:CAM:76,Jacob Brown:ST:74,Dominic Hyam:CB:73,Oli McBurnie:ST:73,Lewis Morgan:LW:72,Angus Gunn:GK:70,Scott Wright:RW:68,Adam Frizzell:RM:64,Ali Crawford:LM:64,Cammy Smith:CF:64",
  "Scotland|2024": "Scott McTominay:CM:85,Aaron Hickey:RB:83,Andrew Robertson:LB:83,John McGinn:CM:83,Lewis Ferguson:CM:82,Ch\xE9 Adams:ST:79,Nathan Patterson:RB:79,Ryan Christie:CM:78,Ben Gannon-Doak:RW:77,Scott McKenna:CB:77,Greg Taylor:LB:76,Ryan Gauld:CAM:76,Lewis Morgan:LW:74,Tommy Conway:ST:74,George Hirst:ST:73,John Souttar:CB:73,Angus Gunn:GK:70,Ryan Fraser:LW:70,Adedire Mebude:RW:68,Adam Frizzell:RM:64,Ali Crawford:LM:64,Cammy Smith:CF:64",
  "Scotland|2025": "Scott McTominay:CM:86,Lewis Ferguson:CM:83,Andrew Robertson:LB:81,Aaron Hickey:RB:80,Ben Gannon-Doak:RW:80,John McGinn:CM:80,Ch\xE9 Adams:ST:79,Nathan Patterson:RB:79,Kieran Tierney:LB:77,Ryan Christie:CM:77,George Hirst:ST:76,Tommy Conway:ST:76,Ryan Gauld:CAM:74,Lewis Morgan:LW:73,Scott McKenna:CB:73,Angus Gunn:GK:68,Rob Apter:RW:68,Ryan Fraser:LW:68,Adam Frizzell:RM:64,Ali Crawford:LM:64,Harley Willard:CF:64",
  "Scotland|2026": "Scott McTominay:CM:86,Aaron Hickey:RB:80,Ben Gannon-Doak:RW:80,Lewis Ferguson:CM:80,John McGinn:CM:79,Andrew Robertson:LB:77,Lennon Miller:CM:77,Nathan Patterson:RB:77,Tommy Conway:ST:77,Ch\xE9 Adams:ST:76,George Hirst:ST:76,Kieran Tierney:LB:76,Ryan Gauld:CAM:73,Angus Gunn:GK:68,Findlay Curtis:LW:68,Rob Apter:RW:68,Ryan Fraser:LW:68,Adam Frizzell:RM:64,Ali Crawford:LM:64",
  "Senegal|2016": "Kalidou Koulibaly:CB:83,Sadio Man\xE9:LW:83,Keita Bald\xE9:LW:79,M'Baye Niang:ST:79,Moussa Sow:ST:79,Oumar Niasse:ST:79,Cheikhou Kouyat\xE9:CDM:78,Idrissa Gueye:CDM:78,Pape Souar\xE9:LB:75,Mohamed Diam\xE9:CM:74,Henri Saivet:CM:73,Kara Mbodj:CB:73,Papy Djilobodji:CB:73,Salif San\xE9:CB:73,Cheikh N'Doye:CM:72,Ibrahima Mbaye:RB:72,Younousse Sankhar\xE9:CM:72,Youssouf Sabaly:RB:72,Alfred Gomis:GK:68,Boukary Dram\xE9:LB:68,Abdoulaye Diallo:GK:64,Demba Tour\xE9:CF:64,Issiar Dia:RW:64,Modou Sougou:RW:64",
  "Senegal|2017": "Sadio Man\xE9:LW:86,Kalidou Koulibaly:CB:85,Keita Bald\xE9:LW:82,Idrissa Gueye:CDM:80,Isma\xEFla Sarr:RW:79,M'Baye Niang:ST:79,Cheikhou Kouyat\xE9:CDM:78,Diafra Sakho:ST:78,Moussa Sow:ST:78,Abdou Diallo:CB:76,Kara Mbodj:CB:76,Salif San\xE9:CB:76,Pape Souar\xE9:LB:75,Mohamed Diam\xE9:CM:74,Henri Saivet:CM:73,Pape Cheikh:CM:73,Youssouf Sabaly:RB:73,Cheikh N'Doye:CM:72,Ibrahima Mbaye:RB:72,Alfred Gomis:GK:70,Amath Ndiaye:RW:70,Cheikh M'Bengue:LB:68,Abdoulaye Diallo:GK:64,Kr\xE9pin Diatta:RM:64,Pape Omar Faye:CF:64",
  "Senegal|2018": "Sadio Man\xE9:LW:89,Kalidou Koulibaly:CB:88,Abdou Diallo:CB:84,Keita Bald\xE9:LW:83,Salif San\xE9:CB:82,Idrissa Gueye:CDM:81,Isma\xEFla Sarr:RW:81,Badou Ndiaye:CDM:79,M'Baye Niang:ST:77,Moussa Niakhat\xE9:CB:77,Bouna Sarr:RB:76,Diafra Sakho:ST:76,Fod\xE9 Ballo-Tour\xE9:LB:76,Khouma Babacar:ST:76,Pape Cheikh:CM:76,Youssouf Sabaly:RB:76,Edouard Mendy:GK:74,Sada Thioub:RW:74,Henri Saivet:CM:73,Mohamed Diam\xE9:CM:73,Younousse Sankhar\xE9:CM:73,Adama Mbengue:LB:70,Alfred Gomis:GK:70,Kr\xE9pin Diatta:RM:70,Pape Omar Faye:CF:64",
  "Senegal|2019": "Sadio Man\xE9:LW:92,Kalidou Koulibaly:CB:89,Abdou Diallo:CB:84,Idrissa Gueye:CDM:83,Isma\xEFla Sarr:RW:83,Keita Bald\xE9:LW:82,Kr\xE9pin Diatta:RM:80,M'Baye Niang:ST:79,Moussa Niakhat\xE9:CB:79,Salif San\xE9:CB:79,Badou Ndiaye:CDM:78,Fod\xE9 Ballo-Tour\xE9:LB:78,Edouard Mendy:GK:77,Habib Diallo:ST:77,Mbaye Diagne:ST:77,Youssouf Sabaly:RB:77,Bouna Sarr:RB:76,Pape Cheikh:CM:76,Sada Thioub:RW:74,Younousse Sankhar\xE9:CM:73,Bingourou Kamara:GK:70,Adama Mbengue:LB:68,Cheikh N'Doye:CM:68,Mamadou Coulibaly:CM:68,Yannick Gomis:CF:68",
  "Senegal|2020": "Sadio Man\xE9:LW:91,Kalidou Koulibaly:CB:88,Abdou Diallo:CB:83,Edouard Mendy:GK:82,Idrissa Gueye:CDM:82,Isma\xEFla Sarr:RW:82,Kr\xE9pin Diatta:RM:81,Keita Bald\xE9:LW:80,Habib Diallo:ST:79,M'Baye Niang:ST:79,Alfred Gomis:GK:77,Bouna Sarr:RB:77,Ibrahima Niane:ST:77,Fod\xE9 Ballo-Tour\xE9:LB:76,Nampalys Mendy:CDM:76,Youssouf Sabaly:RB:76,Pape Cheikh:CM:74,Ismail Jakobs:LB:73,Pape Abou Ciss\xE9:CB:73,Mohamed Diam\xE9:CM:72,Ousseynou Ba:CB:72,Younousse Sankhar\xE9:CM:72,Amath Ndiaye:RW:70,Pape Gueye:CM:70,Yannick Gomis:CF:68",
  "Senegal|2021": "Sadio Man\xE9:LW:90,Kalidou Koulibaly:CB:86,Edouard Mendy:GK:84,Isma\xEFla Sarr:RW:83,Abdou Diallo:CB:82,Pape Matar Sarr:CM:81,Idrissa Gueye:CDM:80,Kr\xE9pin Diatta:RM:80,Moussa Niakhat\xE9:CB:80,Boulaye Dia:ST:79,Abdallah Sima:LW:78,Habib Diallo:ST:78,Ibrahima Niane:ST:77,Pape Gueye:CM:77,Alfred Gomis:GK:76,Cheikhou Kouyat\xE9:CDM:76,Ismail Jakobs:LB:76,Pape Abou Ciss\xE9:CB:76,Fod\xE9 Ballo-Tour\xE9:LB:75,Youssouf Sabaly:RB:75,Bouna Sarr:RB:74,Alassane Ndao:RW:73,Mamadou Coulibaly:CM:70,Pape Cheikh:CM:70,Yannick Gomis:CF:68",
  "Senegal|2022": "Sadio Man\xE9:LW:88,Edouard Mendy:GK:84,Kalidou Koulibaly:CB:84,Isma\xEFla Sarr:RW:83,Abdou Diallo:CB:82,Moussa Niakhat\xE9:CB:80,Kr\xE9pin Diatta:RM:79,Nicolas Jackson:ST:79,Pape Matar Sarr:CM:79,Boulaye Dia:ST:78,Habib Diallo:ST:78,Idrissa Gueye:CDM:78,Pape Gueye:CM:78,Abdallah Sima:LW:76,Alfred Gomis:GK:76,Iliman Ndiaye:RW:76,Ismail Jakobs:LB:76,Pape Abou Ciss\xE9:CB:76,Cheikhou Kouyat\xE9:CDM:72,Fod\xE9 Ballo-Tour\xE9:LB:72,Path\xE9 Ciss:CM:72,Youssouf Sabaly:RB:72,Bouna Sarr:RB:70,Habib Diarra:CM:70,Pape Omar Faye:CF:64",
  "Senegal|2023": "Sadio Man\xE9:LW:86,Nicolas Jackson:ST:84,Pape Matar Sarr:CM:84,Boulaye Dia:ST:82,Kalidou Koulibaly:CB:82,Isma\xEFla Sarr:RW:81,Edouard Mendy:GK:80,Habib Diallo:ST:80,Habib Diarra:CM:80,Iliman Ndiaye:RW:80,Moussa Niakhat\xE9:CB:80,Assane Diao:LW:79,Kr\xE9pin Diatta:RM:79,Abdou Diallo:CB:77,Arouna Sangante:CB:77,Pape Gueye:CM:77,Yehvann Diouf:GK:77,Ismail Jakobs:LB:76,Fod\xE9 Ballo-Tour\xE9:LB:72,Lamine Camara:CM:72,Bouna Sarr:RB:68,Noah Fadiga:RB:64,Yannick Gomis:CF:64",
  "Senegal|2024": "Nicolas Jackson:ST:87,Pape Matar Sarr:CM:86,Habib Diarra:CM:81,Isma\xEFla Sarr:RW:81,Lamine Camara:CM:81,El Hadji Malick Diouf:LB:80,Iliman Ndiaye:RW:80,Moussa Niakhat\xE9:CB:80,Boulaye Dia:ST:79,Sadio Man\xE9:LW:79,Assane Diao:LW:78,Habib Diallo:ST:78,Kr\xE9pin Diatta:RM:78,Arouna Sangante:CB:77,Kalidou Koulibaly:CB:77,Mikayil Faye:CB:77,Yehvann Diouf:GK:77,Edouard Mendy:GK:76,Ismail Jakobs:LB:76,Pape Gueye:CM:76,Ilay Camara:RB:70,Noah Fadiga:RB:70,Abdul Niang:CF:64,Ousseynou Niang:LM:64",
  "Senegal|2025": "Iliman Ndiaye:RW:86,Nicolas Jackson:ST:86,Pape Matar Sarr:CM:85,Habib Diarra:CM:84,Isma\xEFla Sarr:RW:84,Assane Diao:LW:83,El Hadji Malick Diouf:LB:83,Lamine Camara:CM:83,Mamadou Sarr:CB:82,Pape Gueye:CM:82,Boulaye Dia:ST:79,Moussa Niakhat\xE9:CB:79,Yehvann Diouf:GK:78,Abdallah Sima:LW:77,Abdoulaye Ndiaye:CB:76,Arouna Sangante:CB:76,Ismail Jakobs:LB:76,Kr\xE9pin Diatta:RM:76,Ousseynou Niang:LM:76,Cherif Ndiaye:ST:74,Edouard Mendy:GK:73,Ilay Camara:RB:72,Noah Fadiga:RB:70,Abdul Niang:CF:64",
  "Senegal|2026": "Iliman Ndiaye:RW:86,Nicolas Jackson:ST:85,Pape Gueye:CM:85,Habib Diarra:CM:84,Isma\xEFla Sarr:RW:84,Lamine Camara:CM:84,Pape Matar Sarr:CM:84,Assane Diao:LW:83,El Hadji Malick Diouf:LB:83,Mamadou Sarr:CB:82,Moussa Niakhat\xE9:CB:80,Mamadou Diakhon:LW:77,Arouna Sangante:CB:76,Boulaye Dia:ST:76,Ismail Jakobs:LB:76,Ousmane Diao:CB:76,Ousseynou Niang:LM:76,Yehvann Diouf:GK:76,Bamba Dieng:ST:74,Kr\xE9pin Diatta:RM:74,Edouard Mendy:GK:73,Ilay Camara:RB:72,Noah Fadiga:RB:68",
  "Serbia|2016": "Nemanja Mati\u0107:CDM:85,Du\u0161an Tadi\u0107:RW:80,Adem Ljajic:CAM:79,Aleksandar Mitrovi\u0107:ST:79,Lazar Markovic:RW:79,Matija Nastasi\u0107:CB:79,Aleksandar Kolarov:LB:78,Branislav Ivanovic:RB:78,Ljubomir Fejsa:CDM:78,Neven Subotic:CB:78,Nikola Maksimovi\u0107:CB:78,Filip Kosti\u0107:LM:77,Sergej Milinkovi\u0107-Savi\u0107:CM:77,Nenad Tomovic:CB:74,Dusan Basta:RB:73,Filip Djordjevic:ST:73,Filip Djuricic:CAM:73,Nikola Stojiljkovic:ST:72,Darko Brasanac:CM:70,Ivan Obradovic:LB:70,Nemanja Maksimovic:CM:70,Predrag Rajkovi\u0107:GK:70,Goran Causic:CM:68,Nemanja Mihajlovi\u0107:LW:68,Zeljko Brkic:GK:68,Aleksandar Lutovac:RM:64,Alen Stevanovic:LW:64,Danko Lazovic:CF:64",
  "Serbia|2017": "Sergej Milinkovi\u0107-Savi\u0107:CM:87,Nemanja Mati\u0107:CDM:84,Du\u0161an Tadi\u0107:RW:80,Adem Ljajic:CAM:79,Matija Nastasi\u0107:CB:79,Aleksandar Kolarov:LB:78,Ljubomir Fejsa:CDM:78,Nikola Maksimovi\u0107:CB:78,Aleksandar Mitrovi\u0107:ST:77,Filip Kosti\u0107:LM:77,Lazar Markovic:RW:77,Branislav Ivanovic:RB:76,Mijat Gacinovic:CAM:73,Milos Veljkovic:CB:73,Nenad Tomovic:CB:73,Aleksandar Prijovic:ST:72,Darko Brasanac:CM:72,Dusan Basta:RB:72,Filip Djordjevic:ST:70,Ivan Obradovic:LB:70,Mile Svilar:GK:70,Milos Jojic:CM:70,Nemanja Maksimovic:CM:70,Nemanja Mihajlovi\u0107:LW:68,Vanja Milinkovi\u0107-Savi\u0107:GK:68,Aco Lukic:RM:64,Alen Stevanovic:LW:64,Danko Lazovic:CF:64",
  "Serbia|2018": "Sergej Milinkovi\u0107-Savi\u0107:CM:90,Luka Jovi\u0107:ST:85,Nemanja Mati\u0107:CDM:85,Nikola Milenkovi\u0107:CB:84,Aleksandar Mitrovi\u0107:ST:82,Matija Nastasi\u0107:CB:82,Andrija Zivkovic:RW:80,Du\u0161an Tadi\u0107:RW:80,Adem Ljajic:CAM:79,Ljubomir Fejsa:CDM:79,Aleksandar Kolarov:LB:78,Milos Veljkovic:CB:78,Nikola Maksimovi\u0107:CB:78,Filip Kosti\u0107:LM:77,Marko Dmitrovic:GK:77,Nemanja Radonjic:LW:77,Nemanja Maksimovic:CM:76,Aleksandar Prijovic:ST:74,Branislav Ivanovic:RB:70,Ivan Obradovic:LB:70,Mile Svilar:GK:70,Milos Jojic:CM:70,Nenad Krsticic:CM:70,Aleksandar Katai:CAM:68,Milan Gajic:RB:68,Aco Lukic:RM:64,Danko Lazovic:CF:64,Djordje Ivanovic:LW:64",
  "Serbia|2019": "Sergej Milinkovi\u0107-Savi\u0107:CM:88,Luka Jovi\u0107:ST:87,Filip Kosti\u0107:LM:85,Nemanja Mati\u0107:CDM:83,Nikola Milenkovi\u0107:CB:83,Aleksandar Mitrovi\u0107:ST:82,Du\u0161an Tadi\u0107:RW:82,Luka Milivojevic:CDM:82,Nemanja Maksimovic:CM:81,Andrija Zivkovic:RW:80,Matija Nastasi\u0107:CB:80,Nikola Maksimovi\u0107:CB:80,Adem Ljajic:CAM:79,Marko Dmitrovic:GK:78,Mijat Gacinovic:CAM:78,Milos Veljkovic:CB:77,Aleksandar Kolarov:LB:76,Nemanja Radonjic:LW:76,Predrag Rajkovi\u0107:GK:76,Aleksandar Prijovic:ST:74,Filip Stevanovic:LW:72,Milan Rodic:LB:72,Nenad Krsticic:CM:72,Sa\u0161a Luki\u0107:CM:72,Branislav Ivanovic:RB:68,Marko Gobeljic:RB:68,Aleksandar Lutovac:RM:64,Filip Djordjevic:CF:64",
  "Serbia|2020": "Sergej Milinkovi\u0107-Savi\u0107:CM:89,Filip Kosti\u0107:LM:85,Luka Jovi\u0107:ST:84,Nikola Milenkovi\u0107:CB:83,Aleksandar Mitrovi\u0107:ST:82,Nemanja Maksimovic:CM:82,Du\u0161an Tadi\u0107:RW:81,Luka Milivojevic:CDM:81,Du\u0161an Vlahovi\u0107:ST:80,Nemanja Mati\u0107:CDM:80,Nikola Maksimovi\u0107:CB:80,Adem Ljajic:CAM:78,Marko Dmitrovic:GK:77,Predrag Rajkovi\u0107:GK:77,Filip Stevanovic:LW:76,Mijat Gacinovic:CAM:76,Nemanja Radonjic:LW:76,Aleksandar Kolarov:LB:75,Uros Spajic:CB:75,Milos Veljkovic:CB:74,Sa\u0161a Luki\u0107:CM:73,Andrija Zivkovic:RW:72,Ivan Ili\u0107:CM:70,Milan Gajic:RB:70,Milan Rodic:LB:70,Marko Gobeljic:RB:68,Aleksandar Lutovac:RM:64,Filip Djordjevic:CF:64",
  "Serbia|2021": "Du\u0161an Vlahovi\u0107:ST:88,Sergej Milinkovi\u0107-Savi\u0107:CM:88,Nikola Milenkovi\u0107:CB:82,Luka Jovi\u0107:ST:81,Aleksandar Mitrovi\u0107:ST:80,Du\u0161an Tadi\u0107:RW:80,Nemanja Maksimovic:CM:80,Marko Gruji\u0107:CDM:79,Ivan Ili\u0107:CM:78,Nikola Maksimovi\u0107:CB:78,Filip Djuricic:CAM:77,Luka Milivojevic:CDM:77,Marko Dmitrovic:GK:77,Predrag Rajkovi\u0107:GK:77,Matija Nastasi\u0107:CB:76,Sa\u0161a Luki\u0107:CM:76,Strahinja Pavlovi\u0107:CB:76,Filip Stevanovic:LW:75,Adem Ljajic:CAM:74,Andrija Zivkovic:RW:73,Milan Gajic:RB:72,Nemanja Jovic:LW:72,Filip Mladenovic:LB:70,Mihailo Ristic:LB:70,Aleksandar Filipovic:RB:64,Aleksandar Lutovac:RM:64,Filip Djordjevic:CF:64",
  "Serbia|2022": "Du\u0161an Vlahovi\u0107:ST:89,Sergej Milinkovi\u0107-Savi\u0107:CM:88,Aleksandar Mitrovi\u0107:ST:83,Nikola Milenkovi\u0107:CB:81,Strahinja Pavlovi\u0107:CB:81,Luka Jovi\u0107:ST:80,Du\u0161an Tadi\u0107:RW:79,Ivan Ili\u0107:CM:79,Nemanja Maksimovic:CM:79,Sa\u0161a Luki\u0107:CM:79,Marko Gruji\u0107:CDM:78,Predrag Rajkovi\u0107:GK:77,Strahinja Erakovic:CB:76,Uros Racic:CDM:76,Andrija Zivkovic:RW:74,Aleksandar Katai:CAM:73,Lazar Samard\u017Ei\u0107:CAM:73,Marko Dmitrovic:GK:73,Milos Veljkovic:CB:73,Nemanja Radonjic:LW:73,Filip Stevanovic:LW:72,Mihailo Ristic:LB:72,Milan Gajic:RB:72,Milan Rodic:LB:70,Nikola Boranijasevic:RB:68,Aleksandar Lutovac:RM:64,Filip Djordjevic:CF:64",
  "Serbia|2023": "Du\u0161an Vlahovi\u0107:ST:89,Sergej Milinkovi\u0107-Savi\u0107:CM:86,Filip Kosti\u0107:LM:84,Aleksandar Mitrovi\u0107:ST:83,Strahinja Pavlovi\u0107:CB:82,Ivan Ili\u0107:CM:81,Lazar Samard\u017Ei\u0107:CAM:81,Nikola Milenkovi\u0107:CB:80,Sa\u0161a Luki\u0107:CM:78,Djordje Petrovic:GK:77,Luka Jovi\u0107:ST:77,Predrag Rajkovi\u0107:GK:77,Strahinja Erakovic:CB:77,Andrija Zivkovic:RW:76,Erhan Masovic:CB:76,Nemanja Maksimovic:CM:76,Du\u0161an Tadi\u0107:RW:74,Milan Gajic:RB:73,Aleksa Terzic:LB:72,Mijat Gacinovic:CAM:72,Miroslav Bogosavac:LB:72,Nemanja Radonjic:LW:72,Stefan Mitrovi\u0107:LW:72,Kosta Nedeljkovic:RB:70,Aleksandar Lutovac:RM:64,Filip Djordjevic:CF:64",
  "Serbia|2024": "Du\u0161an Vlahovi\u0107:ST:88,Aleksandar Mitrovi\u0107:ST:83,Sergej Milinkovi\u0107-Savi\u0107:CM:83,Filip Kosti\u0107:LM:82,Nikola Milenkovi\u0107:CB:82,Strahinja Pavlovi\u0107:CB:82,Djordje Petrovic:GK:81,Lazar Samard\u017Ei\u0107:CAM:81,Ivan Ili\u0107:CM:80,Mile Svilar:GK:79,Sa\u0161a Luki\u0107:CM:77,Strahinja Erakovic:CB:77,Veljko Birmancevic:LW:77,Jan-Carlo Simi\u0107:CB:76,Kosta Nedeljkovic:RB:76,Luka Jovi\u0107:ST:76,Nemanja Maksimovic:CM:74,Milan Gajic:RB:73,Aleksandar \u0106irkovi\u0107:LW:72,Du\u0161an Tadi\u0107:RW:72,Aleksa Terzic:LB:70,Dejan Zukic:CAM:70,Miroslav Bogosavac:LB:68,Nikola Cumic:RW:68,Aleksandar Lutovac:RM:64,Filip Djordjevic:CF:64",
  "Serbia|2025": "Du\u0161an Vlahovi\u0107:ST:86,Mile Svilar:GK:84,Nikola Milenkovi\u0107:CB:84,Djordje Petrovic:GK:83,Strahinja Pavlovi\u0107:CB:83,Filip Kosti\u0107:LM:82,Veljko Milosavljevic:CB:81,Aleksandar Mitrovi\u0107:ST:80,Ivan Ili\u0107:CM:80,Lazar Samard\u017Ei\u0107:CAM:80,Sergej Milinkovi\u0107-Savi\u0107:CM:80,Andrija Maksimovic:CAM:79,Sa\u0161a Luki\u0107:CM:79,Jan-Carlo Simi\u0107:CB:78,Kosta Nedeljkovic:RB:77,Jovan Milosevic:ST:76,Ognjen Ugresic:CM:75,Veljko Birmancevic:LW:74,Lazar Jovanovic:RW:73,Milan Gajic:RB:73,Stefan Bukinac:LB:73,Aleksa Terzic:LB:72,Du\u0161an Tadi\u0107:RW:70,Nemanja Radonjic:LW:70,Aleksandar Lutovac:RM:64,Arsenije Vranic:CF:64",
  "Serbia|2026": "Du\u0161an Vlahovi\u0107:ST:84,Mile Svilar:GK:84,Strahinja Pavlovi\u0107:CB:84,Djordje Petrovic:GK:83,Nikola Milenkovi\u0107:CB:83,Veljko Milosavljevic:CB:81,Lazar Samard\u017Ei\u0107:CAM:80,Vasilije Kostov:CAM:80,Sergej Milinkovi\u0107-Savi\u0107:CM:79,Sa\u0161a Luki\u0107:CM:78,Aleksandar Mitrovi\u0107:ST:77,Filip Kosti\u0107:LM:77,Ivan Ili\u0107:CM:77,Petar Ratkov:ST:77,Andrija Zivkovic:RW:76,Ognjen Ugresic:CM:76,Strahinja Erakovic:CB:76,Kosta Nedeljkovic:RB:74,Veljko Birmancevic:LW:73,Adem Avdic:LB:72,Lazar Jovanovic:RW:72,Milan Gajic:RB:72,Stefan Bukinac:LB:72,Nemanja Trifunovic:LW:70,Aleksandar Lutovac:RM:64",
  "Slovakia|2016": "Marek Hamsik:CM:85,Martin Skrtel:CB:79,Juraj Kucka:CM:77,Tomas Hubocan:CB:75,Miroslav Stoch:LW:73,Ondrej Duda:CM:73,Robert Mak:LW:73,Matus Bero:CM:70,Peter Pekar\xEDk:RB:70,Michal Duris:ST:68,Dusan Kuciak:GK:64,Dusan Svento:LM:64,Filip Holosko:RW:64,Jakub Hromada:CDM:64,Jaroslav Kolbas:RM:64,Lukas Tesak:LB:64,Matus Kozacik:GK:64,Peter Katona:CF:64,Roman Prochazka:CDM:64",
  "Slovakia|2018": "Milan \u0160kriniar:CB:87,Marek Hamsik:CM:84,Stanislav Lobotka:CDM:82,Ondrej Duda:CM:76,Juraj Kucka:CM:73,Martin D\xFAbravka:GK:73,Miroslav Stoch:LW:73,Patrik Hrosovsky:CM:73,Robert Mak:LW:73,D\xE1vid Hancko:CB:70,Martin Skrtel:CB:70,Albert Rusn\xE1k:CAM:68,Nikolas Spalek:RW:68,Peter Pekar\xEDk:RB:68,Roman Prochazka:CDM:68,Erik Jirka:RM:64,Lubomir Ivanko-Macej:LM:64,Matus Kozacik:GK:64,Peter Katona:CF:64,Robert Mazan:LB:64",
  "Slovakia|2023": "Milan \u0160kriniar:CB:86,D\xE1vid Hancko:CB:84,Leo Sauer:LW:73,Lukas Haraslin:LW:73,Patrik Hrosovsky:CM:73,R\xF3bert Bo\u017Een\xEDk:ST:73,Denis Vavro:CB:72,L\xE1szl\xF3 B\xE9nes:CM:72,Martin Valjent:CB:72,Ondrej Duda:CM:72,Albert Rusn\xE1k:CAM:70,Marek Rod\xE1k:GK:70,Martin D\xFAbravka:GK:70,Tomas Suslov:CAM:70,Ivan Schranz:RW:68,Michal Tomic:RB:68,David Hrncar:RM:64,Jakub Svec:LM:64,Patrik Ciernik:CF:64",
  "Slovakia|2024": "Milan \u0160kriniar:CB:85,D\xE1vid Hancko:CB:84,Tomas Suslov:CAM:76,Lukas Haraslin:LW:75,Dominik Greif:GK:74,Martin Valjent:CB:74,L\xE1szl\xF3 B\xE9nes:CM:73,Leo Sauer:LW:73,R\xF3bert Bo\u017Een\xEDk:ST:73,Albert Rusn\xE1k:CAM:72,David Strelec:ST:72,Matus Bero:CM:72,Ondrej Duda:CM:72,Patrik Hrosovsky:CM:72,Ivan Schranz:RW:70,Marek Rod\xE1k:GK:70,Adri\xE1n Kapr\xE1lik:RW:68,David Hrncar:RM:64,Jakub Svec:LM:64,Michal Tomic:RB:64,Peter Kovacik:RB:64",
  "Slovakia|2025": "D\xE1vid Hancko:CB:84,Milan \u0160kriniar:CB:79,David Strelec:ST:76,Denis Vavro:CB:76,Dominik Greif:GK:76,Leo Sauer:LW:76,Lukas Haraslin:LW:76,Martin Valjent:CB:74,Tomas Suslov:CAM:74,Tomas Bobcek:ST:73,Albert Rusn\xE1k:CAM:72,Dominik Takac:GK:72,Matus Bero:CM:72,Ondrej Duda:CM:72,R\xF3bert Bo\u017Een\xEDk:ST:72,Tomas Rigo:CM:72,Ivan Schranz:RW:68,David Hrncar:RM:64,Jakub Svec:LM:64",
  "Slovakia|2026": "D\xE1vid Hancko:CB:84,Milan \u0160kriniar:CB:78,David Strelec:ST:76,Dominik Greif:GK:76,Leo Sauer:LW:76,Tomas Bobcek:ST:76,Adam Obert:CB:75,Nino Marcelli:LW:75,Denis Vavro:CB:73,R\xF3bert Bo\u017Een\xEDk:ST:72,Tomas Rigo:CM:72,Albert Rusn\xE1k:CAM:70,Dominik Takac:GK:70,L\xE1szl\xF3 B\xE9nes:CM:70,Ondrej Duda:CM:70,David Hrncar:RM:64,Jakub Svec:LM:64",
  "Slovenia|2016": "Jan Oblak:GK:84,Josip Ilicic:CAM:79,Kevin Kampl:CM:79,Samir Handanovi\u010D:GK:79,Robert Beric:ST:74,Jasmin Kurtic:CM:72,Valter Birsa:CAM:72,Andraz Sporar:ST:70,Dominic Maroh:CB:70,Miha Mevlja:CB:70,Benjamin Verbic:LW:68,Dejan Lazarevic:RW:68,Nejc Skubic:RB:68,Petar Stojanovi\u0107:RM:68,Bojan Jokic:LB:64,Dare Vrsic:CF:64,Enej Jelenic:LM:64,Martin Milec:RB:64,Matic Crnic:LW:64",
  "Slovenia|2017": "Jan Oblak:GK:85,Kevin Kampl:CM:80,Josip Ilicic:CAM:79,Samir Handanovi\u010D:GK:79,Jasmin Kurtic:CM:76,Miha Mevlja:CB:73,Robert Beric:ST:73,Valter Birsa:CAM:73,Dominic Maroh:CB:70,Benjamin Verbic:LW:68,Nejc Skubic:RB:68,Petar Stojanovi\u0107:RM:68,Rene Krhin:CDM:68,Dare Vrsic:CF:64,Dejan Lazarevic:RW:64,Dejan Sres:LM:64,Martin Milec:RB:64,Nicolas Rajsel:LW:64",
  "Slovenia|2024": "Benjamin Sesko:ST:86,Jan Oblak:GK:83,Jaka Bijol:CB:80,Sandi Lovri\u0107:CM:76,Adam Gnezda Cerin:CM:73,Tomi Horvat:RM:73,Andraz Sporar:ST:72,Kevin Kampl:CM:72,Timi Max Elsnik:CM:72,Vanja Drkusic:CB:72,Zan Celar:ST:72,Svit Seslar:CAM:70,Zan Karnicnik:RB:68,Haris Vuckic:CF:64,Jure Balkovec:LB:64,Matevz Vidovsek:GK:64",
  "South Africa|2018": "Lebo Mothiba:ST:76,Bongani Zungu:CM:72,Kamohelo Mokotjo:CDM:70,Anele Ngcongca:RB:68,Keagan Dolly:LW:68,Percy Tau:RW:68,Thulani Serero:CDM:68,Andile Mbenyane:CF:64,Aubrey Modiba:LB:64,Ayanda Patosi:CAM:64,Bandile Shandu:RM:64,Darren Keet:GK:64,Itumeleng Khune:GK:64,Luther Singh:LW:64,Mzikayise Mashaba:LM:64,Sifiso Hlanti:LB:64,Thapelo Morena:RB:64,Themba Zwane:CAM:64",
  "South Africa|2019": "Lebo Mothiba:ST:76,Percy Tau:RW:74,Bongani Zungu:CM:70,Thulani Serero:CDM:68,Andile Mbenyane:CF:64,Anele Ngcongca:RB:64,Aubrey Modiba:LB:64,Bandile Shandu:RM:64,Darren Keet:GK:64,Gift Links:LM:64,Itumeleng Khune:GK:64,Keagan Dolly:LW:64,Sifiso Hlanti:LB:64,Thamsanqa Mkhize:RB:64,Thembinkosi Lorch:LW:64",
  "South Africa|2020": "Lebo Mothiba:ST:73,Percy Tau:RW:73,Luther Singh:LW:70,Thulani Serero:CDM:70,Kamohelo Mokotjo:CDM:68,Thapelo Morena:RB:68,Andile Mbenyane:CF:64,Anele Ngcongca:RB:64,Aubrey Modiba:LB:64,Bandile Shandu:RM:64,Gift Links:LM:64,Innocent Maela:LB:64,Itumeleng Khune:GK:64,Ronwen Williams:GK:64,Themba Zwane:CAM:64,Thembinkosi Lorch:LW:64",
  "Spain|2016": "Koke:CM:87,Sergio Busquets:CDM:87,Cesc F\xE0bregas:CM:86,Diego Costa:ST:86,Isco:CAM:86,\xC1lvaro Morata:ST:85,David de Gea:GK:85,David Silva:CAM:85,Gerard Piqu\xE9:CB:85,Sergio Ramos:CB:85,Andr\xE9s Iniesta:CM:84,Jordi Alba:LB:84,Sa\xFAl \xD1\xEDguez:CM:84,Aymeric Laporte:CB:82,Daniel Carvajal:RB:82,Javi Mart\xEDnez:CB:82,Jos\xE9 Callej\xF3n:RW:82,Paco Alc\xE1cer:ST:82,Pedro:RW:82,H\xE9ctor Beller\xEDn:RB:81,Jes\xFAs Navas:RM:81,Jos\xE9 Gay\xE0:LB:81,Nolito:LW:80,Vitolo:LW:80,Asier Illarramendi:CDM:79,Sergio Rico:GK:79,Bojan Krkic:CF:77,Albert Riera:LM:64",
  "Spain|2017": "Koke:CM:87,Sergio Busquets:CDM:87,\xC1lvaro Morata:ST:86,Diego Costa:ST:86,Thiago Alc\xE1ntara:CM:86,David de Gea:GK:85,Gerard Piqu\xE9:CB:85,Isco:CAM:85,Sa\xFAl \xD1\xEDguez:CM:85,Sergio Ramos:CB:85,Cesc F\xE0bregas:CM:84,Daniel Carvajal:RB:84,Javi Mart\xEDnez:CB:84,Jordi Alba:LB:84,Juan Mata:CAM:84,C\xE9sar Azpilicueta:CB:83,H\xE9ctor Beller\xEDn:RB:83,Pedro:RW:83,Vitolo:LW:83,Jos\xE9 Callej\xF3n:RW:82,Paco Alc\xE1cer:ST:81,Sergio Rico:GK:81,Jos\xE9 Gay\xE0:LB:80,Asier Illarramendi:CDM:79,Iker Muniain:LW:79,Jes\xFAs Navas:RM:79,Bojan Krkic:CF:76,Nano:LM:64",
  "Spain|2018": "Isco:CAM:90,Marco Asensio:CAM:90,Sa\xFAl \xD1\xEDguez:CM:90,Sergio Busquets:CDM:89,\xC1lvaro Morata:ST:88,David de Gea:GK:88,Jordi Alba:LB:88,Koke:CM:88,Aymeric Laporte:CB:87,Daniel Carvajal:RB:87,Diego Costa:ST:87,Kepa Arrizabalaga:GK:87,Sergi Roberto:CM:87,Thiago Alc\xE1ntara:CM:87,Gerard Piqu\xE9:CB:86,Marcos Alonso:CB:86,Rodri:CDM:86,Rodrigo:ST:86,Sergio Ramos:CB:86,H\xE9ctor Beller\xEDn:RB:85,Jos\xE9 Gay\xE0:LB:85,Jos\xE9 Callej\xF3n:RW:82,Pedro:RW:82,Vitolo:LW:82,Iker Muniain:LW:77,Jes\xFAs Navas:RM:74,Dani Raba:CF:73,Borja Gal\xE1n:LM:64",
  "Spain|2019": "Sa\xFAl \xD1\xEDguez:CM:90,Aymeric Laporte:CB:89,Rodri:CDM:89,David de Gea:GK:88,Koke:CM:88,Thiago Alc\xE1ntara:CM:88,Fabi\xE1n Ruiz:CM:87,Isco:CAM:87,Kepa Arrizabalaga:GK:87,Marco Asensio:CAM:87,Mikel Oyarzabal:ST:87,\xC1lvaro Morata:ST:86,Daniel Carvajal:RB:86,Jordi Alba:LB:86,Jos\xE9 Gay\xE0:LB:86,Paco Alc\xE1cer:ST:86,Sergio Busquets:CDM:86,Ansu Fati:LW:85,H\xE9ctor Beller\xEDn:RB:85,Marcos Alonso:CB:85,C\xE9sar Azpilicueta:CB:84,Gerard Piqu\xE9:CB:84,Adama Traor\xE9:RW:83,Jos\xE9 Callej\xF3n:RW:81,Iker Muniain:LW:80,Manu Vallejo:CF:74,Jes\xFAs Navas:RM:72,Borja Gal\xE1n:LM:64",
  "Spain|2020": "Ansu Fati:LW:89,Rodri:CDM:88,Sa\xFAl \xD1\xEDguez:CM:88,Aymeric Laporte:CB:87,Koke:CM:87,Luis Alberto:CAM:87,Mikel Oyarzabal:ST:87,\xC1lvaro Morata:ST:86,David de Gea:GK:86,Fabi\xE1n Ruiz:CM:86,Ferran Torres:ST:86,Marcos Llorente:RB:86,Thiago Alc\xE1ntara:CM:86,Adama Traor\xE9:RW:85,Daniel Carvajal:RB:85,Isco:CAM:85,Jordi Alba:LB:85,Jos\xE9 Gay\xE0:LB:85,Kepa Arrizabalaga:GK:85,Pau Torres:CB:85,I\xF1igo Mart\xEDnez:CB:83,Sergio Busquets:CDM:83,C\xE9sar Azpilicueta:CB:82,Portu:RW:81,Iker Muniain:LW:79,Manu Vallejo:CF:74,Jes\xFAs Navas:RM:70,Borja Gal\xE1n:LM:64",
  "Spain|2021": "Ansu Fati:LW:89,Marcos Llorente:RB:89,Pedri:CM:89,Mikel Oyarzabal:ST:88,Rodri:CDM:88,Fabi\xE1n Ruiz:CM:87,Koke:CM:87,Sa\xFAl \xD1\xEDguez:CM:87,\xC1lvaro Morata:ST:86,Aymeric Laporte:CB:86,Dani Olmo:CAM:86,Ferran Torres:ST:86,Luis Alberto:CAM:86,Pau Torres:CB:86,Daniel Carvajal:RB:85,Jos\xE9 Gay\xE0:LB:85,Adama Traor\xE9:RW:84,Angeli\xF1o:LB:84,Mario Hermoso:CB:84,Bryan Gil:LW:83,Robin Le Normand:CB:83,Unai Sim\xF3n:GK:83,Y\xE9remy Pino:RW:83,\xC1lex Remiro:GK:82,Mart\xEDn Zubimendi:CDM:82,Manu Vallejo:CF:76,Jes\xFAs Navas:RM:70",
  "Spain|2022": "Gavi:CM:90,Pedri:CM:90,Rodri:CDM:89,Ansu Fati:LW:87,Fabi\xE1n Ruiz:CM:87,Marc Cucurella:LB:87,Mikel Oyarzabal:ST:87,Aymeric Laporte:CB:86,Carlos Soler:CM:86,Dani Olmo:CAM:86,Ferran Torres:ST:86,Marcos Llorente:RB:86,Pau Torres:CB:86,Gerard Moreno:ST:85,Jos\xE9 Gay\xE0:LB:85,Marco Asensio:CAM:85,Mart\xEDn Zubimendi:CDM:85,Y\xE9remy Pino:RW:85,Robert S\xE1nchez:GK:84,Robin Le Normand:CB:84,\xC1lex Remiro:GK:82,Bryan Gil:LW:82,I\xF1igo Mart\xEDnez:CB:82,Pedro Porro:RB:82,Adama Traor\xE9:RW:81,Isi Palaz\xF3n:CF:76,Jes\xFAs Navas:RM:70",
  "Spain|2023": "Gavi:CM:90,Pedri:CM:90,Lamine Yamal:RW:87,Alejandro Balde:LB:86,Dani Olmo:CAM:86,Mikel Merino:CM:86,Mikel Oyarzabal:ST:86,Nico Williams:LW:86,Pau Torres:CB:86,Pedro Porro:RB:86,Brais M\xE9ndez:CAM:85,Fabi\xE1n Ruiz:CM:85,Marc Cucurella:LB:85,Robin Le Normand:CB:85,Y\xE9remy Pino:RW:85,Ansu Fati:LW:84,David Raya:GK:84,Ferran Torres:ST:84,Marcos Llorente:RB:84,Aymeric Laporte:CB:83,Gerard Moreno:ST:83,Robert S\xE1nchez:GK:83,Igor Zubeldia:CB:82,Isi Palaz\xF3n:CF:78,Jes\xFAs Navas:RM:70,Borja Gal\xE1n:LM:64",
  "Spain|2024": "Lamine Yamal:RW:93,Gavi:CM:90,Pedri:CM:90,Nico Williams:LW:88,Pau Cubars\xED:CB:88,Dani Olmo:CAM:87,Alejandro Balde:LB:86,Alejandro Grimaldo:LB:86,\xC1lex Baena:LW:86,Ferm\xEDn L\xF3pez:CAM:86,Mikel Merino:CM:86,Mikel Oyarzabal:ST:86,Pablo Barrios:CM:86,Pau Torres:CB:86,Pedro Porro:RB:86,Samu Aghehowa:ST:86,Dani Vivian:CB:85,David Raya:GK:85,Robin Le Normand:CB:85,Ferran Torres:ST:83,Marcos Llorente:RB:83,Unai Sim\xF3n:GK:83,Y\xE9remy Pino:RW:83,Isi Palaz\xF3n:CF:77,Jes\xFAs Navas:RM:70,Daniel Sandoval:LM:64",
  "Spain|2025": "Lamine Yamal:RW:94,Pedri:CM:92,Pau Cubars\xED:CB:89,Dean Huijsen:CB:88,Ferm\xEDn L\xF3pez:CAM:88,Gavi:CM:88,Nico Williams:LW:88,Alejandro Balde:LB:87,\xC1lex Baena:LW:87,\xC1lvaro Carreras:LB:87,Dani Olmo:CAM:87,Pablo Barrios:CM:87,Ferran Torres:ST:86,Samu Aghehowa:ST:86,Dani Vivian:CB:85,David Raya:GK:85,Fabi\xE1n Ruiz:CM:85,Pau Torres:CB:85,Pedro Porro:RB:85,Y\xE9remy Pino:RW:84,Joan Garc\xEDa:GK:83,Mikel Oyarzabal:ST:83,Marcos Llorente:RB:82,Isi Palaz\xF3n:CF:72,Jean Carlos Silva:LM:68,Jordi Calavera:RM:64",
  "Spain|2026": "Lamine Yamal:RW:94,Pedri:CM:92,Ferm\xEDn L\xF3pez:CAM:90,Pau Cubars\xED:CB:89,Dean Huijsen:CB:88,Alejandro Balde:LB:87,\xC1lvaro Carreras:LB:87,Dani Olmo:CAM:87,Pablo Barrios:CM:87,\xC1lex Baena:LW:86,Ferran Torres:ST:86,Nico Williams:LW:86,Samu Aghehowa:ST:86,Fabi\xE1n Ruiz:CM:85,Joan Garc\xEDa:GK:85,Pedro Porro:RB:85,Cristhian Mosquera:CB:84,David Raya:GK:84,Eric Garc\xEDa:CB:84,Mikel Jauregizar:CM:84,Y\xE9remy Pino:RW:84,Gonzalo Garc\xEDa:ST:83,\xC1lex Jim\xE9nez:RB:82,Jean Carlos Silva:LM:68,Jordi Calavera:RM:64",
  "Suriname|2016": "Ryan Donk:CB:73,Stefano Denswil:CB:73,Tjaronn Chery:CAM:73,Jean-Paul Bo\xEBtius:CAM:72,Virgil Misidjan:LM:72,Warner Hahn:GK:70,Florian Jozefzoon:RW:68,Luciano Slagveer:RW:68,Mitchell Donald:CM:68,Djavan Anderson:RM:64,Kelvin Leerdam:RB:64,Miquel Nelom:LB:64,Sheraldo Becker:LW:64",
  "Suriname|2017": "Ridgeciano Haps:LB:74,Stefano Denswil:CB:73,Jean-Paul Bo\xEBtius:CAM:72,Tjaronn Chery:CAM:72,Virgil Misidjan:LM:72,Yanic Wildschut:LW:72,Gyrano Kerk:RW:68,Kelvin Leerdam:RB:68,Mitchell Donald:CM:68,Warner Hahn:GK:68,Djavan Anderson:RM:64,Florian Jozefzoon:RW:64,Miquel Nelom:LB:64,Sean Klaiber:RB:64,Sheraldo Becker:LW:64",
  "Suriname|2019": "Jean-Paul Bo\xEBtius:CAM:74,Ridgeciano Haps:LB:74,Stefano Denswil:CB:74,Gyrano Kerk:RW:73,Daishawn Redan:ST:72,Virgil Misidjan:LM:72,Diego Biseswar:CAM:70,Florian Jozefzoon:RW:70,Sean Klaiber:RB:70,Anfernee Dijksteel:RB:68,Warner Hahn:GK:68,Yanic Wildschut:LW:68,Denzel Jubitana:CF:64,Djavan Anderson:RM:64,Sheraldo Becker:LW:64",
  "Suriname|2020": "Gyrano Kerk:RW:75,Deyovaisio Zeefuik:RB:73,Jean-Paul Bo\xEBtius:CAM:73,Ridgeciano Haps:LB:73,Stefano Denswil:CB:73,Daishawn Redan:ST:72,Sean Klaiber:RB:72,Diego Biseswar:CAM:68,Florian Jozefzoon:RW:68,Melayro Bogarde:CDM:68,Sheraldo Becker:LW:68,Denzel Jubitana:CF:64,Djavan Anderson:RM:64,Warner Hahn:GK:64,Yanic Wildschut:LW:64",
  "Suriname|2023": "Sheraldo Becker:LW:80,Jo\xEBl Piroe:ST:79,Stefano Denswil:CB:72,Immanuel Pherai:CAM:70,Kenneth Paal:LB:70,Sean Klaiber:RB:70,Anfernee Dijksteel:RB:68,Delano Burgzorg:LW:68,Jean-Paul Bo\xEBtius:CAM:68,Denzel Jubitana:CF:64,Djavan Anderson:RM:64,Djevencio van der Kust:LB:64,Etienne Vaessen:GK:64,Virgil Misidjan:LM:64",
  "Sweden|2016": "Zlatan Ibrahimovi\u0107:ST:79,Victor Lindel\xF6f:CB:78,Pontus Wernbloom:CM:77,Andreas Granqvist:CB:76,John Guidetti:ST:76,Albin Ekdal:CDM:73,Emil Forsberg:LW:73,Marcus Berg:ST:73,Oscar Wendt:LB:73,Sam Larsson:CAM:73,Erkan Zengin:LW:72,Jimmy Durmaz:CM:72,Ludwig Augustinsson:LB:72,Mikael Lustig:RB:72,Oscar Hiljemark:CM:72,Sebastian Larsson:CM:72,Kristoffer Nordfeldt:GK:70,Simon Gustafson:CAM:70,Alexander Kacaniklic:RW:68,Anton Tinnerholm:RB:68,Emil Bergstr\xF6m:CB:68,Karl-Johan Johnsson:GK:68,Oscar Lewicki:CDM:68,Albin Skoglund:CF:64,Anton Liljenb\xE4ck:RM:64,Anton Wede:LM:64,Jordan Larsson:RW:64",
  "Sweden|2017": "Emil Forsberg:LW:82,Victor Lindel\xF6f:CB:82,Zlatan Ibrahimovi\u0107:ST:78,John Guidetti:ST:76,Pontus Wernbloom:CM:76,Sam Larsson:CAM:76,Alexander Isak:ST:74,Andreas Granqvist:CB:73,Ludwig Augustinsson:LB:73,Martin Olsson:LB:73,Pontus Jansson:CB:73,Mikael Lustig:RB:72,Oscar Hiljemark:CM:72,Albin Ekdal:CDM:70,Jakob Johansson:CDM:70,Jimmy Durmaz:CM:70,Karl-Johan Johnsson:GK:70,Kristoffer Nordfeldt:GK:70,Sebastian Larsson:CM:70,Alexander Kacaniklic:RW:68,Anton Tinnerholm:RB:68,Daniel Larsson:LW:68,Niclas Eliasson:RM:68,Simon Gustafson:CAM:68,Albin Skoglund:CF:64,Anton Wede:LM:64",
  "Sweden|2018": "Emil Forsberg:LW:82,Victor Lindel\xF6f:CB:82,Viktor Claesson:ST:79,Ludwig Augustinsson:LB:78,Robin Olsen:GK:77,Zlatan Ibrahimovi\u0107:ST:76,Pontus Wernbloom:CM:75,Alexander Isak:ST:74,Pontus Jansson:CB:74,Sam Larsson:CAM:74,Albin Ekdal:CDM:73,Andreas Granqvist:CB:72,Mattias Svanberg:CM:72,Mikael Lustig:RB:72,Joel Asoro:RW:70,Karl-Johan Johnsson:GK:70,Ken Sema:LB:70,Riccardo Gagliolo:CB:70,Simon Gustafson:CAM:70,Simon Tibbling:CM:70,Alexander Kacaniklic:RW:68,Anton Tinnerholm:RB:68,Jimmy Durmaz:CM:68,Niclas Eliasson:RM:68,Adrian Johansson:CF:64,Christopher Rasmus Nilsson Telo:LM:64,Daniel Larsson:LW:64,Oscar Lewicki:CDM:64",
  "Sweden|2019": "Victor Lindel\xF6f:CB:84,Emil Forsberg:LW:83,Dejan Kulusevski:CAM:82,Viktor Claesson:ST:80,Alexander Isak:ST:77,Robin Olsen:GK:76,Robin Quaison:ST:76,Mattias Svanberg:CM:74,Pontus Jansson:CB:74,Sam Larsson:CAM:74,Albin Ekdal:CDM:73,Emil Krafth:RB:73,Kristoffer Olsson:CM:73,Benjamin Nygren:RW:72,Jordan Larsson:RW:72,Ken Sema:LB:72,Kristoffer Peterson:LW:72,Martin Olsson:LB:72,Jakob Johansson:CDM:70,Joel Andersson:RB:70,Pontus Wernbloom:CM:70,Simon Tibbling:CM:70,Karl-Johan Johnsson:GK:68,Niclas Eliasson:RM:68,Albin Skoglund:CF:64,Isak Br\xE5holm:LM:64",
  "Sweden|2020": "Dejan Kulusevski:CAM:86,Victor Lindel\xF6f:CB:83,Alexander Isak:ST:82,Emil Forsberg:LW:82,Robin Quaison:ST:79,Viktor Claesson:ST:79,Jordan Larsson:RW:77,Mattias Svanberg:CM:75,Robin Olsen:GK:75,Pontus Jansson:CB:74,Ken Sema:LB:73,Niclas Eliasson:RM:73,Emil Krafth:RB:72,Kristoffer Olsson:CM:72,Sam Larsson:CAM:72,Albin Ekdal:CDM:70,Anton Tinnerholm:RB:70,Jens Cajuste:CDM:70,Pontus Almqvist:RW:70,Jesper Karlsson:LW:68,Martin Olsson:LB:68,Albin Skoglund:CF:64,Anton Wede:LM:64,Isak Pettersson:GK:64",
  "Sweden|2021": "Alexander Isak:ST:85,Dejan Kulusevski:CAM:85,Victor Lindel\xF6f:CB:82,Emil Forsberg:LW:81,Jordan Larsson:RW:79,Mattias Svanberg:CM:79,Ludwig Augustinsson:LB:77,Viktor Claesson:ST:77,Jens Cajuste:CDM:76,Jesper Karlsson:LW:76,Robin Quaison:ST:76,Pontus Jansson:CB:74,Anthony Elanga:RW:72,Carl Starfelt:CB:72,Emil Krafth:RB:72,Filip Helander:CB:72,Gabriel Gudmundsson:LB:72,Kristoffer Olsson:CM:72,Patrik W\xE5lemark:CAM:72,Robin Olsen:GK:72,Albin Ekdal:CDM:70,Anton Tinnerholm:RB:70,Niclas Eliasson:RM:70,Albin Skoglund:CF:64,Kristoffer Nordfeldt:GK:64",
  "Sweden|2022": "Alexander Isak:ST:86,Dejan Kulusevski:CAM:86,Anthony Elanga:RW:82,Victor Lindel\xF6f:CB:82,Jesper Karlsson:LW:80,Mattias Svanberg:CM:79,Emil Forsberg:LW:78,Jordan Larsson:RW:76,Pontus Jansson:CB:76,Robin Quaison:ST:76,Viktor Claesson:ST:76,Carl Starfelt:CB:74,Jens Cajuste:CDM:73,Patrik W\xE5lemark:CAM:73,Hjalmar Ekdal:CB:72,Hugo Larsson:CM:72,Kristoffer Olsson:CM:72,Yasin Ayari:CM:72,Anton Tinnerholm:RB:70,Emil Holm:RB:70,Ken Sema:LB:70,Niclas Eliasson:RM:70,Hampus Finndell:CDM:68,Robin Olsen:GK:68,Adam Lundkvist:LB:64,Albin Skoglund:CF:64,Andreas Linde:GK:64",
  "Sweden|2023": "Alexander Isak:ST:88,Dejan Kulusevski:CAM:87,Viktor Gy\xF6keres:ST:86,Hugo Larsson:CM:83,Anthony Elanga:RW:80,Jesper Karlsson:LW:80,Mattias Svanberg:CM:80,Victor Lindel\xF6f:CB:80,Amin Sarr:ST:77,Isak Hien:CB:77,Roony Bardghji:RW:77,Emil Forsberg:LW:76,Emil Holm:RB:76,Hjalmar Ekdal:CB:76,Carl Starfelt:CB:75,Yasin Ayari:CM:74,Gabriel Gudmundsson:LB:73,Lucas Bergvall:CM:73,Patrik W\xE5lemark:CAM:72,Daniel Svensson:LB:70,Niclas Eliasson:RM:70,Viktor Johansson:GK:70,Joe Mendes:RB:68,Leopold Wahlstedt:GK:68,Albin Skoglund:CF:64,Anton Wede:LM:64",
  "Sweden|2024": "Alexander Isak:ST:89,Viktor Gy\xF6keres:ST:89,Dejan Kulusevski:CAM:87,Hugo Larsson:CM:84,Isak Hien:CB:83,Anthony Elanga:RW:82,Mattias Svanberg:CM:79,Victor Lindel\xF6f:CB:79,Emil Holm:RB:78,Lucas Bergvall:CM:78,Yasin Ayari:CM:78,Roony Bardghji:RW:77,Gabriel Gudmundsson:LB:76,Gustaf Nilsson:ST:76,Hjalmar Ekdal:CB:76,Jacob Ondrejka:LW:76,Carl Starfelt:CB:74,Daniel Svensson:LB:74,Hugo Bolin:LW:73,Niclas Eliasson:RM:73,Viktor Johansson:GK:73,Joe Mendes:RB:72,Elis Bishesari:GK:70,Patrik W\xE5lemark:CAM:70,Sebastian Nanasi:LM:68,Albin Skoglund:CF:64",
  "Sweden|2025": "Alexander Isak:ST:92,Viktor Gy\xF6keres:ST:89,Anthony Elanga:RW:87,Dejan Kulusevski:CAM:86,Hugo Larsson:CM:85,Lucas Bergvall:CM:85,Isak Hien:CB:83,Yasin Ayari:CM:83,Daniel Svensson:LB:82,Sebastian Nanasi:LM:80,Emil Holm:RB:79,Gabriel Gudmundsson:LB:79,Roony Bardghji:RW:77,Viktor Johansson:GK:77,Williot Swedberg:LW:77,Jacob Ondrejka:LW:76,Victor Lindel\xF6f:CB:76,Carl Starfelt:CB:74,Eric Smith:CB:74,Amin Sarr:ST:73,Besfort Zeneli:CM:73,Love Arrhov:CAM:73,Niclas Eliasson:RM:72,Jacob Widell Zetterstr\xF6m:GK:70,Joe Mendes:RB:70,Albin Skoglund:CF:64",
  "Sweden|2026": "Alexander Isak:ST:90,Viktor Gy\xF6keres:ST:88,Anthony Elanga:RW:85,Lucas Bergvall:CM:85,Dejan Kulusevski:CAM:84,Hugo Larsson:CM:84,Yasin Ayari:CM:83,Daniel Svensson:LB:82,Isak Hien:CB:82,Gabriel Gudmundsson:LB:81,Benjamin Nygren:RW:79,Emil Holm:RB:79,Sebastian Nanasi:LM:79,Williot Swedberg:LW:79,Viktor Johansson:GK:78,Adrian Lahdo:CM:77,Jacob Ondrejka:LW:75,Hjalmar Ekdal:CB:74,Victor Lindel\xF6f:CB:74,Carl Starfelt:CB:73,Isac Lidberg:ST:73,Love Arrhov:CAM:73,Niclas Eliasson:RM:72,Jacob Widell Zetterstr\xF6m:GK:70,Joe Mendes:RB:70",
  "Switzerland|2016": "Granit Xhaka:CDM:84,Ricardo Rodr\xEDguez:LB:83,Breel Embolo:ST:82,Xherdan Shaqiri:CAM:80,Yann Sommer:GK:77,Admir Mehmedi:CF:76,Haris Seferovic:ST:76,Silvan Widmer:RB:76,Stephan Lichtsteiner:RB:76,G\xF6khan Inler:CDM:74,Josip Drmic:ST:74,Roman B\xFCrki:GK:74,Fabian Lustenberger:CB:73,Fabian Sch\xE4r:CB:73,Nico Elvedi:CB:73,Almen Abdi:CM:72,Blerim Dzemaili:CM:72,Johan Djourou:CB:72,Luca Zuffi:CM:72,Renato Steffen:RW:72,Valentin Stocker:LW:72,Marco Sch\xF6nb\xE4chler:LM:70,Valon Behrami:CM:70,Fran\xE7ois Moubandje:LB:68,Oliver Buff:CAM:68,Adrian Winter:RM:64",
  "Switzerland|2017": "Granit Xhaka:CDM:84,Breel Embolo:ST:81,Ricardo Rodr\xEDguez:LB:81,Denis Zakaria:CDM:80,Xherdan Shaqiri:CAM:79,Nico Elvedi:CB:78,Remo Freuler:CM:77,Roman B\xFCrki:GK:77,Silvan Widmer:RB:77,Yann Sommer:GK:77,Eren Derdiyok:ST:74,Steven Zuber:LW:74,Timm Klose:CB:74,Haris Seferovic:ST:73,Michael Lang:RB:73,Pajtim Kasami:CM:73,Admir Mehmedi:CF:72,Fabian Lustenberger:CB:72,Fabian Sch\xE4r:CB:72,Luca Zuffi:CM:72,Renato Steffen:RW:72,Valentin Stocker:LW:72,Almen Abdi:CM:70,Fran\xE7ois Moubandje:LB:70,Christian Fassnacht:CAM:68,Marvin Spielmann:LM:68,Adrian Winter:RM:64",
  "Switzerland|2018": "Granit Xhaka:CDM:86,Manuel Akanji:CB:85,Nico Elvedi:CB:82,Xherdan Shaqiri:CAM:82,Denis Zakaria:CDM:81,Breel Embolo:ST:80,Remo Freuler:CM:80,Ricardo Rodr\xEDguez:LB:80,Yann Sommer:GK:79,Kevin Mbabu:RB:77,Roman B\xFCrki:GK:77,Steven Zuber:LW:77,Silvan Widmer:RB:76,Djibril Sow:CM:75,Dimitri Oberlin:ST:74,Haris Seferovic:ST:74,Admir Mehmedi:CF:73,Christian Fassnacht:CAM:73,Fabian Sch\xE4r:CB:72,Luca Zuffi:CM:72,Marvin Spielmann:LM:72,Renato Steffen:RW:72,Timm Klose:CB:72,Blerim Dzemaili:CM:70,Fran\xE7ois Moubandje:LB:70,Kevin Bua:LW:68,Matteo Tosetti:RM:68",
  "Switzerland|2019": "Denis Zakaria:CDM:86,Granit Xhaka:CDM:86,Manuel Akanji:CB:85,Nico Elvedi:CB:84,Xherdan Shaqiri:CAM:82,Remo Freuler:CM:81,Breel Embolo:ST:80,Fabian Sch\xE4r:CB:80,Haris Seferovic:ST:80,Ricardo Rodr\xEDguez:LB:80,Roman B\xFCrki:GK:79,Djibril Sow:CM:78,Yann Sommer:GK:78,Admir Mehmedi:CF:77,Kevin Mbabu:RB:77,Albian Ajeti:ST:76,Rub\xE9n Vargas:LW:76,Steven Zuber:LW:76,Kevin R\xFCegg:RB:74,Christian Fassnacht:CAM:73,Michel Aebischer:CM:73,Loris Benito:CB:72,Fran\xE7ois Moubandje:LB:70,Anto Grgic:CM:68,Matteo Tosetti:RM:68,Dan Ndoye:RW:64,Dominik Schwizer:LM:64",
  "Switzerland|2020": "Denis Zakaria:CDM:85,Granit Xhaka:CDM:83,Nico Elvedi:CB:83,Manuel Akanji:CB:82,Remo Freuler:CM:82,Xherdan Shaqiri:CAM:81,Breel Embolo:ST:80,Rub\xE9n Vargas:LW:79,Haris Seferovic:ST:78,Roman B\xFCrki:GK:78,Djibril Sow:CM:77,Noah Okafor:LW:77,Yann Sommer:GK:77,Admir Mehmedi:CF:76,Kevin Mbabu:RB:76,Ricardo Rodr\xEDguez:LB:76,Jordan Lotomba:RB:74,Michel Aebischer:CM:74,Albian Ajeti:ST:73,Becir Omeragic:CB:73,Christian Fassnacht:CAM:73,Marvin Spielmann:LM:73,Renato Steffen:RW:73,Simon Sohm:CM:73,Loris Benito:CB:72,Ulisses Garcia:LB:70,Dan Ndoye:RW:68,Darian Males:RM:68",
  "Switzerland|2021": "Denis Zakaria:CDM:85,Nico Elvedi:CB:84,Manuel Akanji:CB:83,Granit Xhaka:CDM:82,Remo Freuler:CM:82,Gregor Kobel:GK:81,Breel Embolo:ST:80,Djibril Sow:CM:80,Haris Seferovic:ST:80,Kevin Mbabu:RB:79,Rub\xE9n Vargas:LW:79,Xherdan Shaqiri:CAM:79,Fabian Sch\xE4r:CB:78,Noah Okafor:LW:78,Becir Omeragic:CB:76,Jonas Omlin:GK:76,Jordan Lotomba:RB:74,Albian Ajeti:ST:73,Renato Steffen:RW:73,Simon Sohm:CM:73,Dan Ndoye:RW:72,Darian Males:RM:72,Kastriot Imeri:CM:72,Christian Fassnacht:CAM:70,Ricardo Rodr\xEDguez:LB:70,Fran\xE7ois Moubandje:LB:68,Nassim Ben Khalifa:CF:64",
  "Switzerland|2022": "Denis Zakaria:CDM:83,Granit Xhaka:CDM:83,Manuel Akanji:CB:83,Djibril Sow:CM:82,Gregor Kobel:GK:82,Noah Okafor:LW:82,Breel Embolo:ST:81,Nico Elvedi:CB:81,Remo Freuler:CM:81,Fabian Sch\xE4r:CB:77,Haris Seferovic:ST:77,Kevin Mbabu:RB:77,Rub\xE9n Vargas:LW:77,Becir Omeragic:CB:76,Jonas Omlin:GK:76,Jordan Lotomba:RB:76,Kastriot Imeri:CM:76,Xherdan Shaqiri:CAM:76,Michael Frey:ST:73,Christian Fassnacht:CAM:72,Darian Males:RM:72,Michel Aebischer:CM:72,Ricardo Rodr\xEDguez:LB:72,Renato Steffen:RW:70,Ulisses Garcia:LB:70,Julian Von Moos:RW:68,Admir Mehmedi:CF:64",
  "Switzerland|2023": "Gregor Kobel:GK:85,Manuel Akanji:CB:85,Breel Embolo:ST:82,Djibril Sow:CM:82,Noah Okafor:LW:82,Nico Elvedi:CB:80,Zeki Amdouni:ST:79,Dan Ndoye:RW:77,Fabian Sch\xE4r:CB:77,Jonas Omlin:GK:77,Remo Freuler:CM:77,C\xE9dric Zesiger:CB:76,Jordan Lotomba:RB:76,Kastriot Imeri:CM:76,Rub\xE9n Vargas:LW:75,Michel Aebischer:CM:74,Andi Zeqiri:ST:73,Kevin Mbabu:RB:73,Ricardo Rodr\xEDguez:LB:72,Xherdan Shaqiri:CAM:72,Dominik Schmid:LB:70,Alvyn Sanches:CAM:68,Julian Von Moos:RW:68,Maren Haile-Selassie:RM:68,Marvin Spielmann:LM:68,Admir Mehmedi:CF:64",
  "Switzerland|2024": "Manuel Akanji:CB:86,Gregor Kobel:GK:85,Dan Ndoye:RW:82,Noah Okafor:LW:81,Zeki Amdouni:ST:79,Breel Embolo:ST:78,Djibril Sow:CM:78,Michel Aebischer:CM:78,Alvyn Sanches:CAM:77,Aur\xE8le Amenda:CB:77,Fabian Rieder:CAM:77,Fabian Sch\xE4r:CB:77,Nico Elvedi:CB:77,Rub\xE9n Vargas:LW:77,Filip Ugrinic:CM:76,Jonas Omlin:GK:76,Jordan Lotomba:RB:76,Remo Freuler:CM:75,Leonidas Stergiou:RB:73,Andi Zeqiri:ST:72,Darian Males:RM:72,Ulisses Garcia:LB:72,Dominik Schmid:LB:70,Julian Von Moos:RW:68,Christian Witzig:LM:64,Mario Greco:CF:64",
  "Switzerland|2025": "Dan Ndoye:RW:85,Gregor Kobel:GK:85,Manuel Akanji:CB:84,Johan Manzambi:CM:83,Noah Okafor:LW:80,Alvyn Sanches:CAM:79,Breel Embolo:ST:78,Zeki Amdouni:ST:78,Luca Jaquez:CB:77,Marvin Keller:GK:77,Simon Sohm:CM:77,Aur\xE8le Amenda:CB:76,C\xE9dric Zesiger:CB:76,Djibril Sow:CM:76,Fabian Rieder:CAM:76,Filip Ugrinic:CM:76,Sascha Britschgi:RB:76,Zachary Athekame:RB:76,Jo\xEBl Monteiro:LM:74,Ulisses Garcia:LB:73,Andi Zeqiri:ST:72,Dominik Schmid:LB:72,Darian Males:RM:70,Th\xE9o Berdayes:RW:70,Mario Greco:CF:64",
  "Switzerland|2026": "Gregor Kobel:GK:85,Dan Ndoye:RW:84,Johan Manzambi:CM:84,Manuel Akanji:CB:80,Noah Okafor:LW:80,Breel Embolo:ST:78,Rub\xE9n Vargas:LW:78,Alvyn Sanches:CAM:77,Bruno Ogbus:CB:77,Luca Jaquez:CB:77,Sascha Britschgi:RB:77,Zachary Athekame:RB:77,Zeki Amdouni:ST:77,Alessandro Vogt:ST:76,Aur\xE8le Amenda:CB:76,Djibril Sow:CM:76,Fabian Rieder:CAM:76,Jo\xEBl Monteiro:LM:76,Marvin Keller:GK:76,Simon Sohm:CM:76,Filip Ugrinic:CM:74,Miro Muheim:LB:73,Junior Ligue:LB:72,Darian Males:RM:68,Samuel Ballet:RW:68",
  "Tunisia|2018": "Wahbi Khazri:LW:79,Ellyes Skhiri:CDM:77,Na\xEFm Sliti:LW:76,Rani Khedira:CDM:74,Dylan Bronn:CB:73,Sa\xEEf-Eddine Khaoui:CAM:73,Aymen Abdennour:CB:72,Oussama Haddadi:CB:70,Ali Ma\xE2loul:LB:68,Ferjani Sassi:CM:68,Abdelkader Oueslati:RM:64,Aymen Balbouli:GK:64,Hamdi Nagguez:RB:64,Houcine Jabeur:CF:64,Majdi Mosrati:LM:64,Mouez Hassen:GK:64",
  "Tunisia|2019": "Wahbi Khazri:LW:80,Ellyes Skhiri:CDM:78,Rani Khedira:CDM:77,Dylan Bronn:CB:76,Na\xEFm Sliti:LW:76,Yan Valery:RB:76,Oussama Haddadi:CB:72,Sa\xEEf-Eddine Khaoui:CAM:72,Yassine Meriah:CB:72,Bassem Srarfi:RW:70,Ferjani Sassi:CM:70,Mohamed Dr\xE4ger:RB:70,Ali Ma\xE2loul:LB:68,Farouk Ben Mustapha:GK:68,Abdelkader Oueslati:RM:64,Amor Layouni:RW:64,Houcine Jabeur:CF:64,Mouez Hassen:GK:64",
  "Tunisia|2020": "Wahbi Khazri:LW:77,Na\xEFm Sliti:LW:76,Rani Khedira:CDM:76,Ellyes Skhiri:CDM:75,Yan Valery:RB:75,Dylan Bronn:CB:73,Ferjani Sassi:CM:70,Ali Ma\xE2loul:LB:68,Bassem Srarfi:RW:68,Mohamed Dr\xE4ger:RB:68,Saad Bguir:CAM:68,Sa\xEEf-Eddine Khaoui:CAM:68,Abdelkader Oueslati:RM:64,Ayman Ben Mohamed:LB:64,Aymen Dahmen:GK:64,Farouk Ben Mustapha:GK:64,Houcine Jabeur:CF:64,Sayfallah Ltaief:LM:64",
  "Tunisia|2022": "Ellyes Skhiri:CDM:79,Na\xEFm Sliti:LW:76,Rani Khedira:CDM:76,A\xEFssa La\xEFdouni:CM:72,Anis Ben Slimane:CM:72,Dylan Bronn:CB:72,Firas Ben Larbi:CAM:72,Montassar Talbi:CB:72,Wahbi Khazri:LW:72,Mohamed Ali Ben Romdhane:CM:70,Saad Bguir:CAM:70,Ali Abdi:LB:68,Aymen Dahmen:GK:64,Bechir Ben Said:GK:64,Bechir Mkadem:CF:64,Mohamed Amine Tritar:RM:64,Mohamed Dr\xE4ger:RB:64",
  "Tunisia|2023": "Hannibal:CAM:78,A\xEFssa La\xEFdouni:CM:77,Montassar Talbi:CB:76,Firas Ben Larbi:CAM:73,Isma\xEBl Gharbi:LW:73,Na\xEFm Sliti:LW:73,Anis Ben Slimane:CM:70,Mohamed Ali Ben Romdhane:CM:70,Ali Abdi:LB:68,Yan Valery:RB:68,Alaya Brigui:RM:64,Ali Ma\xE2loul:LB:64,Aymen Dahmen:GK:64,Bechir Ben Said:GK:64,Bechir Mkadem:CF:64,Sayfallah Ltaief:LM:64",
  "T\xFCrkiye|2016": "Arda Turan:LW:84,\xD6mer Toprak:CB:81,Hakan \xC7alhano\u011Flu:CDM:80,G\xF6khan T\xF6re:RW:79,O\u011Fuzhan \xD6zyakup:CM:79,Caner Erkin:LB:78,Mehmet Topal:CDM:78,Yunus Mall\u0131:CM:77,Alper Potuk:LW:76,Burak Y\u0131lmaz:ST:76,Cenk Tosun:ST:76,Onur K\u0131vrak:GK:76,Ozan Tufan:CM:76,Sel\xE7uk \u0130nan:CM:76,Semih Kaya:CB:76,Volkan Babacan:GK:76,G\xF6khan G\xF6n\xFCl:RB:75,Yasin \xD6ztekin:ST:74,Ahmet \xC7al\u0131k:CB:73,Cenk \u015Eahin:RW:73,Ersan G\xFCl\xFCm:CB:73,Hasan Ali Kald\u0131r\u0131m:LB:73,\u0130smail K\xF6yba\u015F\u0131:LM:73,\xD6zer Hurmac\u0131:CAM:73,\u015Eener \xD6zbayrakl\u0131:RB:73,Emre \xC7olak:CAM:72,Furkan Safi:CF:64,Hamit Alt\u0131ntop:RM:64",
  "T\xFCrkiye|2017": "Arda Turan:LW:83,Hakan \xC7alhano\u011Flu:CDM:81,\xD6mer Toprak:CB:80,Enes \xDCnal:ST:79,O\u011Fuzhan \xD6zyakup:CM:79,Yunus Mall\u0131:CM:79,G\xF6khan T\xF6re:RW:78,\xC7a\u011Flar S\xF6y\xFCnc\xFC:CB:77,Cengiz \xDCnder:RW:77,Cenk Tosun:ST:77,Alper Potuk:LW:76,Caner Erkin:LB:76,Emre \xC7olak:CAM:76,Mehmet Topal:CDM:76,Ozan Tufan:CM:76,Volkan Babacan:GK:76,Burak Y\u0131lmaz:ST:74,Hasan Ali Kald\u0131r\u0131m:LB:74,Mehmet Ekici:CAM:74,Onur K\u0131vrak:GK:74,Ahmet \xC7al\u0131k:CB:73,\u0130smail K\xF6yba\u015F\u0131:LM:73,\xD6mer Ali \u015Eahiner:RB:73,Semih Kaya:CB:73,\u015Eener \xD6zbayrakl\u0131:RB:73,Sel\xE7uk \u0130nan:CM:72,Abd\xFClkadir \xD6m\xFCr:RM:64",
  "T\xFCrkiye|2018": "Cengiz \xDCnder:RW:84,Hakan \xC7alhano\u011Flu:CDM:83,Cenk Tosun:ST:82,\xC7a\u011Flar S\xF6y\xFCnc\xFC:CB:80,Arda Turan:LW:78,\xD6mer Toprak:CB:78,Yusuf Yaz\u0131c\u0131:CAM:78,O\u011Fuzhan \xD6zyakup:CM:77,Okay Yoku\u015Flu:CDM:77,Yunus Mall\u0131:CM:77,Abd\xFClkadir \xD6m\xFCr:RM:76,Enes \xDCnal:ST:76,Emre Akbaba:CAM:74,Umut Bozok:ST:74,Zeki \xC7elik:RB:74,Alper Potuk:LW:73,G\xF6khan T\xF6re:RW:73,Volkan Babacan:GK:73,Harun Tekin:GK:72,Hasan Ali Kald\u0131r\u0131m:LB:72,Serdar Aziz:CB:72,Berkay \xD6zcan:CM:70,Caner Erkin:LB:70,Mustafa Saymak:CM:70,Bar\u0131\u015F Yard\u0131mc\u0131:RB:68,\u0130smail K\xF6yba\u015F\u0131:LM:68,Raif Demir:CF:64",
  "T\xFCrkiye|2019": "\xC7a\u011Flar S\xF6y\xFCnc\xFC:CB:85,Cengiz \xDCnder:RW:84,Ozan Kabak:CB:82,Hakan \xC7alhano\u011Flu:CDM:81,Merih Demiral:CB:81,Zeki \xC7elik:RB:81,Cenk Tosun:ST:80,Yusuf Yaz\u0131c\u0131:CAM:80,Abd\xFClkadir \xD6m\xFCr:RM:79,Okay Yoku\u015Flu:CDM:78,\u0130rfan Can Kahveci:RW:76,\xD6mer Toprak:CB:76,Orkun K\xF6k\xE7\xFC:CM:76,O\u011Fuzhan \xD6zyakup:CM:75,Ahmed Kutucu:LW:74,Emre Akbaba:CAM:74,U\u011Furcan \xC7ak\u0131r:GK:74,Enes \xDCnal:ST:73,Mert M\xFCld\xFCr:RB:73,Altay Bay\u0131nd\u0131r:GK:72,Emre K\u0131l\u0131n\xE7:LW:72,G\xFCven Yal\xE7\u0131n:ST:72,Abdulkadir Parmak:CM:70,Berkay \xD6zcan:CM:70,Hasan Ali Kald\u0131r\u0131m:LB:70,Caner Erkin:LB:68,\u0130smail K\xF6yba\u015F\u0131:LM:64",
  "T\xFCrkiye|2020": "\xC7a\u011Flar S\xF6y\xFCnc\xFC:CB:85,Hakan \xC7alhano\u011Flu:CDM:84,Ozan Kabak:CB:84,Merih Demiral:CB:83,Zeki \xC7elik:RB:81,Orkun K\xF6k\xE7\xFC:CM:80,U\u011Furcan \xC7ak\u0131r:GK:80,Abd\xFClkadir \xD6m\xFCr:RM:79,Yusuf Yaz\u0131c\u0131:CAM:79,Altay Bay\u0131nd\u0131r:GK:78,Cenk Tosun:ST:78,Enes \xDCnal:ST:77,\u0130rfan Can Kahveci:RW:77,Mert M\xFCld\xFCr:RB:77,Ozan Tufan:CM:77,Kaan Ayhan:CDM:76,Emre K\u0131l\u0131n\xE7:LW:75,Ahmed Kutucu:LW:74,Deniz T\xFCr\xFC\xE7:RW:74,Ferdi Kad\u0131o\u011Flu:LB:74,Berkay \xD6zcan:CM:73,G\xFCven Yal\xE7\u0131n:ST:72,H\xFCseyin T\xFCrkmen:CB:72,\xD6mer Bayram:LB:72,Emre Akbaba:CAM:70,Salih U\xE7an:CM:70,Ferhat Duman:CF:64,\u0130smail K\xF6yba\u015F\u0131:LM:64",
  "T\xFCrkiye|2021": "\xC7a\u011Flar S\xF6y\xFCnc\xFC:CB:86,Hakan \xC7alhano\u011Flu:CDM:84,Merih Demiral:CB:83,Ozan Kabak:CB:82,Cengiz \xDCnder:RW:81,U\u011Furcan \xC7ak\u0131r:GK:81,Yusuf Yaz\u0131c\u0131:CAM:81,Zeki \xC7elik:RB:81,Altay Bay\u0131nd\u0131r:GK:80,Orkun K\xF6k\xE7\xFC:CM:79,\u0130rfan Can Kahveci:RW:78,Ozan Tufan:CM:78,Enes \xDCnal:ST:77,Mert M\xFCld\xFCr:RB:77,Abd\xFClkadir \xD6m\xFCr:RM:76,Okay Yoku\u015Flu:CDM:76,Ferdi Kad\u0131o\u011Flu:LB:75,Cenk Tosun:ST:74,Emre K\u0131l\u0131n\xE7:LW:74,Kerem Akt\xFCrko\u011Flu:LW:74,Halil Dervi\u015Fo\u011Flu:ST:73,Salih U\xE7an:CM:73,Abdulkadir Parmak:CM:72,R\u0131dvan Y\u0131lmaz:LB:72,Emre Akbaba:CAM:70,Burak Seres:CF:64",
  "T\xFCrkiye|2022": "\xC7a\u011Flar S\xF6y\xFCnc\xFC:CB:85,Merih Demiral:CB:83,Orkun K\xF6k\xE7\xFC:CM:83,Cengiz \xDCnder:RW:82,Enes \xDCnal:ST:82,Altay Bay\u0131nd\u0131r:GK:80,Kerem Akt\xFCrko\u011Flu:LW:80,Salih \xD6zcan:CDM:80,U\u011Furcan \xC7ak\u0131r:GK:80,Yusuf Yaz\u0131c\u0131:CAM:80,Zeki \xC7elik:RB:80,Ozan Kabak:CB:79,Ferdi Kad\u0131o\u011Flu:LB:78,Abd\xFClkadir \xD6m\xFCr:RM:77,Arda G\xFCler:CAM:77,\u0130rfan Can Kahveci:RW:77,Berat \xD6zdemir:CDM:76,Mert M\xFCld\xFCr:RB:76,Ozan Tufan:CM:75,R\u0131dvan Y\u0131lmaz:LB:75,Berkan Kutlu:CM:74,Umut Bozok:ST:74,Ahmetcan Kaplan:CB:73,Berkay \xD6zcan:CM:73,Do\u011Fukan Sinik:LW:72,Halil Dervi\u015Fo\u011Flu:ST:72,Emincan Tekin:CF:64",
  "T\xFCrkiye|2023": "Orkun K\xF6k\xE7\xFC:CM:84,Enes \xDCnal:ST:82,Cengiz \xDCnder:RW:81,Ferdi Kad\u0131o\u011Flu:LB:81,Merih Demiral:CB:81,Kerem Akt\xFCrko\u011Flu:LW:80,Altay Bay\u0131nd\u0131r:GK:79,Arda G\xFCler:CAM:79,\xC7a\u011Flar S\xF6y\xFCnc\xFC:CB:79,Ozan Kabak:CB:79,U\u011Furcan \xC7ak\u0131r:GK:79,Yusuf Yaz\u0131c\u0131:CAM:78,Abd\xFClkadir \xD6m\xFCr:RM:77,Abd\xFClkerim Bardakc\u0131:CB:77,\u0130rfan Can Kahveci:RW:77,Kenan Y\u0131ld\u0131z:LW:77,Zeki \xC7elik:RB:77,Berkan Kutlu:CM:73,Berkay \xD6zcan:CM:73,Bertu\u011F Y\u0131ld\u0131r\u0131m:ST:73,Mert M\xFCld\xFCr:RB:73,R\u0131dvan Y\u0131lmaz:LB:73,Salih U\xE7an:CM:73,Cenk Tosun:ST:70,Emincan Tekin:CF:64,\u0130smail K\xF6yba\u015F\u0131:LM:64",
  "T\xFCrkiye|2024": "Arda G\xFCler:CAM:86,Kenan Y\u0131ld\u0131z:LW:86,Ferdi Kad\u0131o\u011Flu:LB:83,Orkun K\xF6k\xE7\xFC:CM:83,Kerem Akt\xFCrko\u011Flu:LW:82,Enes \xDCnal:ST:81,Cengiz \xDCnder:RW:80,Merih Demiral:CB:80,Semih K\u0131l\u0131\xE7soy:ST:79,\xC7a\u011Flar S\xF6y\xFCnc\xFC:CB:78,Can Uzun:CAM:78,Eren Dink\xE7i:RW:78,Abd\xFClkerim Bardakc\u0131:CB:77,Ahmetcan Kaplan:CB:77,Altay Bay\u0131nd\u0131r:GK:77,Abd\xFClkadir \xD6m\xFCr:RM:76,Mert M\xFCld\xFCr:RB:76,U\u011Furcan \xC7ak\u0131r:GK:76,Zeki \xC7elik:RB:74,R\u0131dvan Y\u0131lmaz:LB:73,Salih U\xE7an:CM:73,Berkan Kutlu:CM:72,Bertu\u011F Y\u0131ld\u0131r\u0131m:ST:72,Emirhan \u0130lkhan:CM:70,Baran Mo\u011Fultay:LM:64,\xDCnal Durmu\u015Fhan:CF:64",
  "T\xFCrkiye|2025": "Arda G\xFCler:CAM:90,Kenan Y\u0131ld\u0131z:LW:89,Can Uzun:CAM:86,Ferdi Kad\u0131o\u011Flu:LB:83,Orkun K\xF6k\xE7\xFC:CM:83,Bar\u0131\u015F Alper Y\u0131lmaz:LW:82,Yunus Akg\xFCn:RW:80,Yusuf Ak\xE7i\xE7ek:CB:80,Merih Demiral:CB:79,Semih K\u0131l\u0131\xE7soy:ST:79,U\u011Furcan \xC7ak\u0131r:GK:79,Zeki \xC7elik:RB:78,Berke \xD6zer:GK:77,Enes \xDCnal:ST:77,Abd\xFClkerim Bardakc\u0131:CB:76,\xC7a\u011Flar S\xF6y\xFCnc\xFC:CB:76,Cengiz \xDCnder:RW:76,Eren Elmal\u0131:LB:74,Mert M\xFCld\xFCr:RB:74,Abd\xFClkadir \xD6m\xFCr:RM:73,\u0130sak Vural:CM:73,Mustafa Hekimo\u011Flu:ST:73,Berkan Kutlu:CM:72,Yusuf \xD6zdemir:LM:70,Halil \xD6zdemir:CF:64",
  "T\xFCrkiye|2026": "Arda G\xFCler:CAM:90,Kenan Y\u0131ld\u0131z:LW:89,Can Uzun:CAM:86,Bar\u0131\u015F Alper Y\u0131lmaz:LW:83,Ferdi Kad\u0131o\u011Flu:LB:83,Orkun K\xF6k\xE7\xFC:CM:82,Yunus Akg\xFCn:RW:80,Merih Demiral:CB:79,Semih K\u0131l\u0131\xE7soy:ST:79,U\u011Furcan \xC7ak\u0131r:GK:79,Yusuf Ak\xE7i\xE7ek:CB:79,Berke \xD6zer:GK:77,Ozan Kabak:CB:77,Enes \xDCnal:ST:76,Mert M\xFCld\xFCr:RB:76,Abd\xFClkerim Bardakc\u0131:CB:75,Deniz G\xFCl:ST:74,Eren Dink\xE7i:RW:74,Arda Okan Kurtulan:RM:73,Emirhan \u0130lkhan:CM:73,Eren Elmal\u0131:LB:73,\u0130sak Vural:CM:73,Ba\u015Far \xD6nal:LM:72,Taha \u015Eahin:RB:70",
  "Ukraine|2016": "Andriy Yarmolenko:RW:82,Yevgen Konoplyanka:LW:82,Marlos:RW:77,Yaroslav Rakitskyi:CB:77,Taras Stepanenko:CDM:76,Yevgen Khacheridi:CB:76,Denys Boyko:GK:73,Denys Garmash:CAM:73,Sergiy Rybalka:CDM:73,Viktor Kovalenko:CM:73,Andriy Pyatov:GK:72,J\xFAnior Moraes:ST:72,Roman Zozulya:ST:72,Artem Fedetskyi:RB:70,Artem Kravets:ST:70,Oleksandr Karavaev:RB:70,Ivan Petryak:LW:68,Oleg Gusev:RM:68,Roman Bezus:CAM:68,Yevgen Shakhov:CM:68,Andriy Dragolyuk:CF:64,Andriy Grynchenko:LM:64,Oleksandr Kapliyenko:LB:64",
  "Ukraine|2017": "Andriy Yarmolenko:RW:82,Yevgen Konoplyanka:LW:80,Marlos:RW:77,Yaroslav Rakitskyi:CB:77,Taras Stepanenko:CDM:76,Yevgen Khacheridi:CB:76,Viktor Kovalenko:CM:74,Oleksandr Zinchenko:LB:73,Sergiy Sydorchuk:CDM:73,Andriy Pyatov:GK:72,Denys Garmash:CAM:72,J\xFAnior Moraes:ST:72,Ruslan Malinovskyi:CM:72,Artem Kravets:ST:70,Eduard Sobol:LB:70,Ivan Ordets:CB:70,Oleksandr Karavaev:RB:70,Anton Kanibolotskyi:GK:68,Artem Gromov:LW:68,Bogdan Butko:RB:68,Vitaliy Buyalskyi:CAM:68,Yevgen Shakhov:CM:68,Andriy Dragolyuk:CF:64,Andriy Grynchenko:LM:64,Andriy Nykytyuk:RM:64",
  "Ukraine|2018": "Andriy Yarmolenko:RW:82,Oleksandr Zinchenko:LB:79,Marlos:RW:78,Ruslan Malinovskyi:CM:77,Taras Stepanenko:CDM:77,Yevgen Konoplyanka:LW:77,Andriy Lunin:GK:76,Yaroslav Rakitskyi:CB:76,Denys Garmash:CAM:73,Sergiy Sydorchuk:CDM:73,Viktor Kovalenko:CM:73,Yevgen Khacheridi:CB:73,Ivan Ordets:CB:72,Roman Yaremchuk:ST:72,Andriy Pyatov:GK:70,J\xFAnior Moraes:ST:70,Mykola Matvienko:CB:70,Mykola Morozyuk:RB:70,Mykola Shaparenko:CM:70,Oleg Danchenko:RB:70,Volodymyr Shepelev:CM:70,Ivan Petryak:LW:68,Roman Bezus:CAM:68,Andriy Dragolyuk:CF:64,Andriy Grynchenko:LM:64,Anton Kotlyar:RM:64,Vitaliy Mykolenko:LB:64",
  "Ukraine|2019": "Oleksandr Zinchenko:LB:83,Andriy Yarmolenko:RW:81,Viktor Tsygankov:RW:81,Ruslan Malinovskyi:CM:79,Roman Yaremchuk:ST:78,Taras Stepanenko:CDM:77,Yaroslav Rakitskyi:CB:77,Andriy Lunin:GK:76,Yevgen Konoplyanka:LW:75,Viktor Kovalenko:CM:74,Vitaliy Mykolenko:LB:74,J\xFAnior Moraes:ST:73,Sergiy Sydorchuk:CDM:73,Denys Garmash:CAM:72,Mykola Shaparenko:CM:72,Mykyta Burda:CB:72,Oleg Danchenko:RB:72,Sergiy Kryvtsov:CB:72,Vitaliy Buyalskyi:CAM:72,Volodymyr Shepelev:CM:72,Andriy Pyatov:GK:70,Vladyslav Supryaga:ST:70,Bogdan Butko:RB:68,Ivan Petryak:LW:68,Andriy Dragolyuk:CF:64,Andriy Nykytyuk:RM:64,Anton Shevchuk:LM:64",
  "Ukraine|2020": "Oleksandr Zinchenko:LB:82,Ruslan Malinovskyi:CM:81,Viktor Tsygankov:RW:81,Vitaliy Mykolenko:LB:79,Andriy Yarmolenko:RW:78,Roman Yaremchuk:ST:78,Taras Stepanenko:CDM:77,Vladyslav Supryaga:ST:76,Viktor Kovalenko:CM:74,Yevgen Konoplyanka:LW:74,J\xFAnior Moraes:ST:73,Sergiy Kryvtsov:CB:73,Sergiy Sydorchuk:CDM:73,Mykola Shaparenko:CM:72,Mykyta Burda:CB:72,Oleksandr Karavaev:RB:72,Vitaliy Buyalskyi:CAM:72,Volodymyr Shepelev:CM:72,Andriy Lunin:GK:70,Bogdan Lednev:CAM:70,Georgiy Bushchan:GK:70,Oleg Danchenko:RB:70,Ivan Petryak:LW:68,Anton Shevchuk:LM:64,Denys Skepskyi:CF:64,Mykola Kogut:RM:64",
  "Ukraine|2021": "Oleksandr Zinchenko:LB:83,Ruslan Malinovskyi:CM:83,Viktor Tsygankov:RW:82,Roman Yaremchuk:ST:80,Vitaliy Mykolenko:LB:80,Ilya Zabarnyi:CB:79,Mykola Matvienko:CB:78,Georgiy Bushchan:GK:77,Anatoliy Trubin:GK:76,Marlos:RW:76,Taras Stepanenko:CDM:76,Vitaliy Buyalskyi:CAM:76,Vladyslav Supryaga:ST:76,Viktor Kovalenko:CM:74,Yaroslav Rakitskyi:CB:74,Ivan Ordets:CB:73,Yevgen Konoplyanka:LW:72,Bogdan Lednev:CAM:70,Igor Kharatin:CDM:70,Oleksandr Tymchyk:RB:70,Volodymyr Shepelev:CM:70,Yukhym Konoplya:RB:70,Vladyslav Kabaev:LW:68,Artem Kozak:RM:64,Pavlo Krishtan:CF:64",
  "Ukraine|2022": "Mykhaylo Mudryk:LW:85,Oleksandr Zinchenko:LB:84,Ruslan Malinovskyi:CM:83,Viktor Tsygankov:RW:82,Vitaliy Mykolenko:LB:82,Roman Yaremchuk:ST:80,Ilya Zabarnyi:CB:79,Anatoliy Trubin:GK:78,Mykola Matvienko:CB:78,Artem Dovbyk:ST:77,Vitaliy Buyalskyi:CAM:76,Georgiy Sudakov:CAM:74,Taras Stepanenko:CDM:74,Yaroslav Rakitskyi:CB:74,Ivan Ordets:CB:73,Sergiy Sydorchuk:CDM:73,Andriy Lunin:GK:72,Oleksandr Karavaev:RB:72,Yukhym Konoplya:RB:72,Andriy Yarmolenko:RW:70,Oleksandr Pikhalyonok:CM:70,Viktor Kovalenko:CM:70,Vladyslav Supryaga:ST:70,Volodymyr Shepelev:CM:70,Ivan Petryak:LW:68,Andriy Lyashenko:RM:64,Ruslan Kisil:CF:64",
  "Ukraine|2023": "Mykhaylo Mudryk:LW:87,Oleksandr Zinchenko:LB:85,Artem Dovbyk:ST:83,Vitaliy Mykolenko:LB:83,Anatoliy Trubin:GK:82,Ilya Zabarnyi:CB:82,Viktor Tsygankov:RW:82,Mykola Matvienko:CB:81,Georgiy Sudakov:CAM:80,Ruslan Malinovskyi:CM:79,Artem Bondarenko:CAM:77,Roman Yaremchuk:ST:77,Andriy Lunin:GK:76,Mykola Shaparenko:CM:76,Danylo Sikan:ST:74,Oleksandr Pikhalyonok:CM:73,Oleksandr Zubkov:RW:73,Dmytro Kryskiv:CM:72,Yukhym Konoplya:RB:72,Oleksandr Karavaev:RB:70,Andriy Lyashenko:RM:64,Artem Shchedryi:LM:64,Ruslan Kisil:CF:64",
  "Ukraine|2024": "Ilya Zabarnyi:CB:85,Oleksandr Zinchenko:LB:85,Artem Dovbyk:ST:84,Georgiy Sudakov:CAM:84,Mykhaylo Mudryk:LW:84,Viktor Tsygankov:RW:83,Vitaliy Mykolenko:LB:83,Anatoliy Trubin:GK:82,Andriy Lunin:GK:82,Mykola Matvienko:CB:80,Vladyslav Vanat:ST:78,Yegor Yarmolyuk:CM:78,Artem Bondarenko:CAM:77,Mykola Shaparenko:CM:77,Danylo Sikan:ST:76,Dmytro Kryskiv:CM:76,Ruslan Malinovskyi:CM:76,Yukhym Konoplya:RB:76,Valeriy Bondar:CB:74,Oleksandr Tymchyk:RB:73,Denys Popov:CB:72,Nazar Voloshyn:RW:72,Vladyslav Kabaev:LW:72,Andriy Lyashenko:RM:64,Artem Sukhotskyi:LM:64",
  "Ukraine|2025": "Ilya Zabarnyi:CB:87,Georgiy Sudakov:CAM:84,Anatoliy Trubin:GK:83,Artem Dovbyk:ST:83,Vitaliy Mykolenko:LB:83,Oleksandr Zinchenko:LB:82,Yegor Yarmolyuk:CM:82,Andriy Lunin:GK:80,Mykhaylo Mudryk:LW:80,Mykola Matvienko:CB:80,Viktor Tsygankov:RW:80,Vladyslav Vanat:ST:79,Mykola Shaparenko:CM:78,Arseniy Batagov:CB:77,Artem Bondarenko:CAM:77,Dmytro Kryskiv:CM:76,Taras Mykhavko:CB:76,Nazar Voloshyn:RW:73,Oleksandr Tymchyk:RB:73,Yukhym Konoplya:RB:73,Vladyslav Kabaev:LW:72,Denys Kuzyk:RM:68,Andriy Gavrylenko:LM:64",
  "Ukraine|2026": "Ilya Zabarnyi:CB:86,Georgiy Sudakov:CAM:83,Yegor Yarmolyuk:CM:83,Anatoliy Trubin:GK:82,Vitaliy Mykolenko:LB:82,Andriy Lunin:GK:79,Artem Dovbyk:ST:79,Mykola Matvienko:CB:79,Viktor Tsygankov:RW:79,Vladyslav Vanat:ST:79,Arseniy Batagov:CB:78,Oleksandr Zinchenko:LB:77,Taras Mykhavko:CB:77,Artem Bondarenko:CAM:76,Mykola Shaparenko:CM:76,Oleksandr Zubkov:RW:76,Matviy Ponomarenko:ST:74,Dmytro Kryskiv:CM:73,Oleksandr Tymchyk:RB:72,Oleksandr Nazarenko:LW:70,Oleksandr Pikhalyonok:CM:70,Vladyslav Kabaev:LW:70,Denys Kuzyk:RM:68,Ilya Krupskyi:RB:68,Andriy Gavrylenko:LM:64",
  "United States|2016": "John Brooks:CB:77,Fabian Johnson:LM:76,Christian Pulisic:RW:73,Clint Dempsey:CF:73,Aron J\xF3hannsson:ST:72,Bobby Wood:ST:72,DeAndre Yedlin:RB:72,Alejandro Bedoya:CM:70,Brad Guzan:GK:70,Geoff Cameron:CB:70,Gyasi Zardes:ST:70,Jermaine Jones:CDM:70,Matt Miazga:CB:70,Michael Bradley:CM:70,Alfredo Morales:CM:68,Danny Williams:CDM:68,Darlington Nagbe:CM:68,Edgar Castillo:LB:68,Eric Lichaj:RB:68,Ethan Finlay:RW:68,Lee Nguyen:CAM:68,Luis Robles:GK:68,Brian Span:RM:64,Chris Tierney:LB:64,Harry Shipp:LW:64,Kekuta Manneh:LW:64",
  "United States|2017": "Christian Pulisic:RW:86,John Brooks:CB:79,Fabian Johnson:LM:74,Bobby Wood:ST:73,DeAndre Yedlin:RB:73,Weston McKennie:CM:73,Jozy Altidore:ST:72,Timothy Chandler:RB:72,Clint Dempsey:CF:70,Geoff Cameron:CB:70,Matt Miazga:CB:70,Michael Bradley:CM:70,Omar Gonz\xE1lez:CB:70,Alfredo Morales:CM:68,Brad Guzan:GK:68,Danny Williams:CDM:68,Darlington Nagbe:CM:68,Edgar Castillo:LB:68,Kellyn Acosta:CDM:68,Sacha Kljestan:CAM:68,William Yarbrough:GK:68,Alex Mart\xEDnez:RM:64,Alex Muyl:RW:64,Brandon Vincent:LB:64,Chris Pontius:LW:64,Harry Shipp:LW:64",
  "United States|2018": "Christian Pulisic:RW:86,John Brooks:CB:79,Weston McKennie:CM:79,DeAndre Yedlin:RB:76,Jordan:ST:76,Fabian Johnson:LM:73,Jozy Altidore:ST:73,Timothy Chandler:RB:73,Timothy Weah:RM:73,Tyler Adams:CDM:73,Zack Steffen:GK:73,Gyasi Zardes:ST:72,Tim Ream:CB:72,Cristian Rold\xE1n:CM:70,Geoff Cameron:CB:70,Matt Miazga:CB:70,Michael Bradley:CM:70,Wil Trapp:CDM:70,Alejandro Bedoya:CM:68,Alex Bono:GK:68,Jorge Villafa\xF1a:LB:68,Sacha Kljestan:CAM:68,\xC1lex Zendejas:RW:64,Antonee Robinson:LB:64,Chris Pontius:LW:64,Clint Dempsey:CF:64,Kekuta Manneh:LW:64,Lee Nguyen:CAM:64",
  "United States|2019": "Christian Pulisic:RW:87,Weston McKennie:CM:82,John Brooks:CB:79,Tyler Adams:CDM:79,Sergi\xF1o Dest:RB:78,Zack Steffen:GK:77,DeAndre Yedlin:RB:76,Josh Sargent:ST:76,Timothy Weah:RM:76,Jordan:ST:74,Aaron Long:CB:72,Alfredo Morales:CM:72,Cristian Rold\xE1n:CM:72,Gyasi Zardes:ST:72,Paul Arriola:RW:72,Tim Ream:CB:72,Djordje Mihailovic:CAM:70,Fabian Johnson:LM:70,Miles Robinson:CB:70,Brenden Aaronson:CAM:68,Danny Williams:CDM:68,Ethan Horvath:GK:68,Romain Gall:LW:68,Tyler Boyd:LW:68,Ben Sweat:LB:64,Daniel Lovitz:LB:64",
  "United States|2020": "Christian Pulisic:RW:87,Giovanni Reyna:CAM:83,Weston McKennie:CM:82,Sergi\xF1o Dest:RB:81,Tyler Adams:CDM:80,Timothy Weah:RM:76,Zack Steffen:GK:76,DeAndre Yedlin:RB:75,Antonee Robinson:LB:73,Cole Bassett:CAM:73,Cristian Rold\xE1n:CM:73,Jordan Morris:ST:73,Yunus Musah:CM:73,Chris Richards:CB:72,Darlington Nagbe:CM:72,Folarin Balogun:ST:72,Gyasi Zardes:ST:72,Mark McKenzie:CB:72,Walker Zimmerman:CB:72,Andr\xE9s Perea:CDM:70,Chris Mueller:RW:70,George Bello:LB:70,Konrad de la Fuente:LW:70,Miles Robinson:CB:70,Ethan Horvath:GK:68,Fabian Johnson:LM:68,Tyler Boyd:LW:68",
  "United States|2021": "Christian Pulisic:RW:86,Giovanni Reyna:CAM:85,Sergi\xF1o Dest:RB:83,Weston McKennie:CM:82,Tyler Adams:CDM:81,John Brooks:CB:79,Timothy Weah:RM:79,Yunus Musah:CM:79,Brenden Aaronson:CAM:78,Antonee Robinson:LB:77,Daryl Dike:ST:77,Gianluca Busio:CM:77,Josh Sargent:ST:77,Chris Richards:CB:76,Joe Scally:RB:76,Ricardo Pepi:ST:76,Cristian Rold\xE1n:CM:74,Zack Steffen:GK:74,Mark McKenzie:CB:73,Miles Robinson:CB:73,Chris Mueller:RW:72,George Bello:LB:72,James Sands:CDM:72,Matt Turner:GK:70,Benji Michel:LW:68,Jonathan Lewis:LW:64,Joseph Restani:CF:64",
  "United States|2022": "Christian Pulisic:RW:85,Giovanni Reyna:CAM:84,Brenden Aaronson:CAM:83,Weston McKennie:CM:82,Yunus Musah:CM:82,Sergi\xF1o Dest:RB:80,Tyler Adams:CDM:80,Folarin Balogun:ST:79,Timothy Weah:RM:79,Chris Richards:CB:78,Joe Scally:RB:78,Josh Sargent:ST:78,Antonee Robinson:LB:77,Cameron Carter-Vickers:CB:77,Daryl Dike:ST:77,Gabriel Slonina:GK:76,Gianluca Busio:CM:76,John Brooks:CB:76,Cristian Rold\xE1n:CM:74,Konrad de la Fuente:LW:74,Zack Steffen:GK:74,Cade Cowell:LW:73,Mark McKenzie:CB:73,DeJuan Jones:LB:72,Keaton Parks:CDM:72,Chris Mueller:RW:70",
  "United States|2023": "Christian Pulisic:RW:84,Folarin Balogun:ST:83,Giovanni Reyna:CAM:83,Brenden Aaronson:CAM:82,Weston McKennie:CM:82,Yunus Musah:CM:82,Antonee Robinson:LB:81,Sergi\xF1o Dest:RB:80,Cameron Carter-Vickers:CB:79,Timothy Weah:RM:79,Joe Scally:RB:78,Josh Sargent:ST:78,Ricardo Pepi:ST:78,Auston Trusty:CB:77,Chris Richards:CB:77,Gabriel Slonina:GK:77,Matt Turner:GK:77,Mark McKenzie:CB:76,Cristian Rold\xE1n:CM:74,Johnny Cardoso:CM:74,Taylor Booth:RW:74,Caleb Wiley:LB:73,Kevin Paredes:LM:72,Konrad de la Fuente:LW:70,Jonathan Lewis:LW:68",
  "United States|2024": "Christian Pulisic:RW:86,Antonee Robinson:LB:83,Folarin Balogun:ST:83,Malik Tillman:CAM:83,Weston McKennie:CM:83,Johnny Cardoso:CM:82,Sergi\xF1o Dest:RB:82,Yunus Musah:CM:82,Giovanni Reyna:CAM:80,Ricardo Pepi:ST:80,Timothy Weah:RM:80,Cameron Carter-Vickers:CB:79,Josh Sargent:ST:79,Chris Richards:CB:78,Joe Scally:RB:77,Matt Turner:GK:77,Auston Trusty:CB:76,Caleb Wiley:LB:76,Gianluca Busio:CM:75,\xC1lex Zendejas:RW:74,Mark McKenzie:CB:74,Kevin Paredes:LM:73,Gabriel Slonina:GK:72",
  "United States|2025": "Christian Pulisic:RW:87,Antonee Robinson:LB:84,Malik Tillman:CAM:84,Chris Richards:CB:82,Folarin Balogun:ST:82,Johnny Cardoso:CM:82,Weston McKennie:CM:82,Josh Sargent:ST:81,Timothy Weah:RM:81,Yunus Musah:CM:81,Ricardo Pepi:ST:80,Sergi\xF1o Dest:RB:80,Brenden Aaronson:CAM:79,Cameron Carter-Vickers:CB:79,Noahkai Banks:CB:79,\xC1lex Zendejas:RW:77,Joe Scally:RB:77,Aidan Morris:CM:76,Auston Trusty:CB:76,Caleb Wiley:LB:76,Diego Luna:LM:76,Max Arfsten:LW:73,Cade Cowell:LW:72,Gabriel Slonina:GK:72,Patrick Schulte:GK:72",
  "United States|2026": "Christian Pulisic:RW:86,Folarin Balogun:ST:83,Malik Tillman:CAM:83,Weston McKennie:CM:83,Antonee Robinson:LB:82,Chris Richards:CB:82,Johnny Cardoso:CM:82,Noahkai Banks:CB:82,Ricardo Pepi:ST:82,Timothy Weah:RM:81,Brenden Aaronson:CAM:80,Josh Sargent:ST:80,Sergi\xF1o Dest:RB:80,Yunus Musah:CM:80,Aidan Morris:CM:77,\xC1lex Zendejas:RW:77,Cameron Carter-Vickers:CB:77,Caleb Wiley:LB:76,Diego Luna:LM:76,Joe Scally:RB:76,Auston Trusty:CB:74,Max Arfsten:LW:73,Cade Cowell:LW:72,Gabriel Slonina:GK:72,Patrick Schulte:GK:72",
  "Uruguay|2016": "Luis Su\xE1rez:ST:90,Diego God\xEDn:CB:85,Edinson Cavani:ST:85,Jos\xE9 Mar\xEDa Gim\xE9nez:CB:83,Fernando Muslera:GK:79,Mat\xEDas Vecino:CM:78,Abel Hern\xE1ndez:ST:76,Gast\xF3n Pereiro:CAM:76,Giorgian de Arrascaeta:CAM:76,Mart\xEDn C\xE1ceres:CB:76,Mauricio Lemos:CB:76,Maxi Pereira:RB:76,Diego Laxalt:LB:74,Rodrigo Bentancur:CDM:74,Gast\xF3n Ram\xEDrez:CM:73,\xC1lvaro Pereira:LB:70,Camilo Mayada:RB:70,Chory Castro:LW:70,Cristian Rodr\xEDguez:LM:70,Gast\xF3n Guruceaga:GK:70,Jonathan Urretaviscaya:RW:70,Nahitan N\xE1ndez:CM:70,Sebasti\xE1n Crist\xF3foro:CM:70,Tabar\xE9 Vi\xFAdez:RW:70,Walter Gargano:CDM:70,Brian Lozano:LW:68,Adri\xE1n Leites:CF:64,\xC1lvaro Pe\xF1a:RM:64",
  "Uruguay|2017": "Luis Su\xE1rez:ST:90,Edinson Cavani:ST:86,Diego God\xEDn:CB:85,Jos\xE9 Mar\xEDa Gim\xE9nez:CB:83,Lucas Torreira:CDM:82,Mat\xEDas Vecino:CM:82,Fernando Muslera:GK:79,Rodrigo Bentancur:CDM:79,Diego Laxalt:LB:77,Gast\xF3n Pereiro:CAM:77,Gast\xF3n Ram\xEDrez:CM:77,Mauricio Lemos:CB:77,Abel Hern\xE1ndez:ST:76,Giorgian de Arrascaeta:CAM:76,Sebasti\xE1n Coates:CB:76,Nicol\xE1s de la Cruz:CM:73,Jonathan Urretaviscaya:RW:72,Nahitan N\xE1ndez:CM:72,Dami\xE1n Su\xE1rez:RB:70,Gast\xF3n Guruceaga:GK:70,Rodrigo Amaral:CF:70,Brian Lozano:LW:68,Camilo Mayada:RB:68,Carlos de Pena:LW:68,Marcelo Saracchi:LB:68,Tabar\xE9 Vi\xFAdez:RW:68,Washington Camacho:LM:68,\xC1nyelo Rodr\xEDguez:RM:64",
  "Uruguay|2018": "Luis Su\xE1rez:ST:89,Edinson Cavani:ST:87,Lucas Torreira:CDM:87,Jos\xE9 Mar\xEDa Gim\xE9nez:CB:86,Diego God\xEDn:CB:84,Maxi G\xF3mez:ST:84,Rodrigo Bentancur:CDM:84,Mat\xEDas Vecino:CM:82,Diego Laxalt:LB:80,Gast\xF3n Pereiro:CAM:79,Marcelo Saracchi:LB:79,Nahitan N\xE1ndez:CM:79,Gast\xF3n Ram\xEDrez:CM:77,Mauro Arambarri:CM:77,Sebasti\xE1n Coates:CB:77,Fernando Muslera:GK:76,Mauricio Lemos:CB:74,Mart\xEDn Campa\xF1a:GK:73,Mauricio Pereyra:CAM:73,Dami\xE1n Su\xE1rez:RB:72,Jonathan Urretaviscaya:RW:72,Brian Lozano:LW:70,Diego Zabala:RW:70,Mat\xEDas Aguirregaray:RB:70,Carlos de Pena:LW:68,Rodrigo Amaral:CF:68,Adolfo Lima:LM:64,\xC1nyelo Rodr\xEDguez:RM:64",
  "Uruguay|2019": "Jos\xE9 Mar\xEDa Gim\xE9nez:CB:88,Lucas Torreira:CDM:87,Edinson Cavani:ST:86,Federico Valverde:CM:86,Luis Su\xE1rez:ST:86,Maxi G\xF3mez:ST:85,Rodrigo Bentancur:CDM:85,Nahitan N\xE1ndez:CM:83,Mat\xEDas Vecino:CM:82,Diego God\xEDn:CB:81,Giorgian de Arrascaeta:CAM:81,Mauro Arambarri:CM:81,Sebasti\xE1n Coates:CB:79,Diego Laxalt:LB:78,Gast\xF3n Pereiro:CAM:78,Leandro Cabrera:CB:77,Marcelo Saracchi:LB:77,Brian Rodr\xEDguez:LW:74,Fernando Muslera:GK:73,Dami\xE1n Su\xE1rez:RB:72,Mart\xEDn Campa\xF1a:GK:72,Diego Zabala:RW:70,Jonathan Urretaviscaya:RW:70,Camilo Mayada:RB:68,Carlos de Pena:LW:68,Thom\xE1s Chac\xF3n:LM:68,Adri\xE1n Leites:CF:64,\xC1nyelo Rodr\xEDguez:RM:64",
  "Uruguay|2020": "Federico Valverde:CM:88,Jos\xE9 Mar\xEDa Gim\xE9nez:CB:88,Rodrigo Bentancur:CDM:86,Lucas Torreira:CDM:84,Luis Su\xE1rez:ST:84,Maxi G\xF3mez:ST:84,Mauro Arambarri:CM:82,Nahitan N\xE1ndez:CM:82,Edinson Cavani:ST:81,Mat\xEDas Vecino:CM:81,Giorgian de Arrascaeta:CAM:79,Ronald Araujo:CB:79,Brian Rodr\xEDguez:LW:78,Marcelo Saracchi:LB:77,Brian Lozano:LW:76,Diego Laxalt:LB:76,Facundo Pellistri:RW:76,Gast\xF3n Pereiro:CAM:76,Erick Cabaco:CB:73,Fernando Muslera:GK:73,Dami\xE1n Su\xE1rez:RB:72,Sebasti\xE1n C\xE1ceres:CB:72,Diego Zabala:RW:70,Camilo Mayada:RB:68,Facundo Waller:LM:68,Gast\xF3n Guruceaga:GK:68,Adri\xE1n Leites:CF:64,\xC1nyelo Rodr\xEDguez:RM:64",
  "Uruguay|2021": "Federico Valverde:CM:88,Jos\xE9 Mar\xEDa Gim\xE9nez:CB:88,Rodrigo Bentancur:CDM:85,Darwin N\xFA\xF1ez:ST:84,Maxi G\xF3mez:ST:84,Ronald Araujo:CB:84,Lucas Torreira:CDM:83,Nahitan N\xE1ndez:CM:82,Mauro Arambarri:CM:81,Giorgian de Arrascaeta:CAM:80,Nicol\xE1s de la Cruz:CM:80,Luis Su\xE1rez:ST:79,Sebasti\xE1n Coates:CB:79,Math\xEDas Olivera:LB:78,Brian Rodr\xEDguez:LW:77,Facundo Pellistri:RW:74,Facundo Torres:RW:74,Lucas Olaza:LB:74,Sebasti\xE1n C\xE1ceres:CB:74,Brian Lozano:LW:73,David Terans:CAM:72,Fernando Muslera:GK:72,Guillermo Varela:RB:70,Sebasti\xE1n Sosa:GK:70,Camilo Mayada:RB:68,Adri\xE1n Leites:CF:64,\xC1nyelo Rodr\xEDguez:RM:64",
  "Uruguay|2022": "Federico Valverde:CM:90,Darwin N\xFA\xF1ez:ST:88,Ronald Araujo:CB:87,Jos\xE9 Mar\xEDa Gim\xE9nez:CB:86,Rodrigo Bentancur:CDM:85,Giorgian de Arrascaeta:CAM:81,Lucas Torreira:CDM:81,Nicol\xE1s de la Cruz:CM:80,Math\xEDas Olivera:LB:79,Mauro Arambarri:CM:79,Maxi G\xF3mez:ST:79,Nahitan N\xE1ndez:CM:79,Sebasti\xE1n Coates:CB:79,Mat\xEDas Vi\xF1a:LB:77,Agust\xEDn \xC1lvarez:ST:76,Facundo Torres:RW:76,Leonardo Fern\xE1ndez:CAM:76,Santiago Bueno:CB:76,Agust\xEDn Canobbio:LW:72,Brian Lozano:LW:72,Manuel Castro:RW:72,Sergio Rochet:GK:72,Fernando Muslera:GK:70,Dami\xE1n Su\xE1rez:RB:68,Giovanni Gonz\xE1lez:RB:68,Adri\xE1n Leites:CF:64,\xC1nyelo Rodr\xEDguez:RM:64",
  "Uruguay|2023": "Federico Valverde:CM:90,Darwin N\xFA\xF1ez:ST:88,Ronald Araujo:CB:88,Jos\xE9 Mar\xEDa Gim\xE9nez:CB:84,Giorgian de Arrascaeta:CAM:81,Math\xEDas Olivera:LB:80,Facundo Torres:RW:79,Joaqu\xEDn Piquerez:LB:79,Mauro Arambarri:CM:79,Nicol\xE1s de la Cruz:CM:79,Facundo Pellistri:RW:77,Fernando Gorriar\xE1n:CM:77,Gast\xF3n \xC1lvarez:CB:77,Agust\xEDn \xC1lvarez:ST:76,Leonardo Fern\xE1ndez:CAM:76,Mart\xEDn Satriano:ST:76,Santiago Bueno:CB:76,Brian Lozano:LW:73,Brian Rodr\xEDguez:LW:73,Sergio Rochet:GK:72,Agust\xEDn Sant'Anna:RB:70,Franco Israel:GK:70,Gast\xF3n Martirena:RB:70,Franco Fag\xFAndez:CF:68,Facundo Waller:LM:67,\xC1nyelo Rodr\xEDguez:RM:64",
  "Uruguay|2024": "Federico Valverde:CM:92,Darwin N\xFA\xF1ez:ST:88,Ronald Araujo:CB:88,Jos\xE9 Mar\xEDa Gim\xE9nez:CB:82,Math\xEDas Olivera:LB:80,Nicol\xE1s de la Cruz:CM:80,Rodrigo Zalazar:CAM:80,Facundo Torres:RW:79,Gast\xF3n \xC1lvarez:CB:79,Giorgian de Arrascaeta:CAM:79,Joaqu\xEDn Piquerez:LB:79,Facundo Pellistri:RW:77,Agust\xEDn \xC1lvarez:ST:76,Alan Matturro:CB:76,Fernando Gorriar\xE1n:CM:76,Franco Israel:GK:76,Luciano Rodr\xEDguez:ST:76,Brian Rodr\xEDguez:LW:74,Felipe Carballo:CM:73,Gast\xF3n Martirena:RB:73,Diego Fag\xFAndez:LW:72,Sergio Rochet:GK:72,Agust\xEDn Sant'Anna:RB:70,Facundo Waller:LM:70,Emiliano G\xF3mez:CF:68,Bruno Centeno:RM:64",
  "Uruguay|2025": "Federico Valverde:CM:92,Darwin N\xFA\xF1ez:ST:86,Ronald Araujo:CB:86,Maxi Ara\xFAjo:LB:82,Jos\xE9 Mar\xEDa Gim\xE9nez:CB:81,Math\xEDas Olivera:LB:81,Rodrigo Zalazar:CAM:81,Nicol\xE1s de la Cruz:CM:80,Facundo Torres:RW:79,Giorgian de Arrascaeta:CAM:79,Gast\xF3n \xC1lvarez:CB:77,Luciano Rodr\xEDguez:ST:77,Santiago Bueno:CB:77,Santiago Mouri\xF1o:RB:77,Facundo Pellistri:RW:76,Brian Rodr\xEDguez:LW:75,Fernando Gorriar\xE1n:CM:75,Miguel Merentiel:ST:75,Agust\xEDn Canobbio:LW:74,Franco Israel:GK:74,Gast\xF3n Martirena:RB:74,Felipe Carballo:CM:73,Sergio Rochet:GK:72,Facundo Waller:LM:70,Emiliano G\xF3mez:CF:68,\xC1nyelo Rodr\xEDguez:RM:64",
  "Uruguay|2026": "Federico Valverde:CM:91,Darwin N\xFA\xF1ez:ST:82,Maxi Ara\xFAjo:LB:82,Rodrigo Zalazar:CAM:82,Ronald Araujo:CB:81,Giorgian de Arrascaeta:CAM:79,Math\xEDas Olivera:LB:79,Jos\xE9 Mar\xEDa Gim\xE9nez:CB:78,Facundo Torres:RW:77,Luciano Rodr\xEDguez:ST:77,Mauro Arambarri:CM:77,Nicol\xE1s de la Cruz:CM:77,Santiago Bueno:CB:77,Santiago Mouri\xF1o:RB:77,Brian Rodr\xEDguez:LW:76,Gast\xF3n \xC1lvarez:CB:76,Agust\xEDn Canobbio:LW:74,Mart\xEDn Satriano:ST:74,Cristian Olivera:RW:73,Gast\xF3n Martirena:RB:73,Ignacio Sosa:CM:73,Franco Israel:GK:70,Thiago Cardozo:GK:70,Alexander Vel\xE1zquez:LM:64,\xC1nyelo Rodr\xEDguez:RM:64",
  "Wales|2016": "Gareth Bale:RW:90,Aaron Ramsey:CM:84,Joe Allen:CM:78,Ben Davies:CB:77,Ashley Williams:CB:76,Neil Taylor:LB:74,Andy King:CM:72,Joe Ledley:CM:72,Paul Dummett:LB:72,Sam Vokes:ST:72,Wayne Hennessey:GK:72,Adam Matthews:RB:70,Chris Gunter:RB:70,Hal Robson-Kanu:ST:70,Karl Darlow:GK:70,Emyr Huws:CDM:68,David Cotterill:RW:64,David Vaughan:CDM:64,Jonny Williams:CAM:64,Nicky Adams:RM:64,Tom Lawrence:CAM:64,Tyler Roberts:CF:64",
  "Wales|2017": "Gareth Bale:RW:90,Aaron Ramsey:CM:84,Ben Davies:CB:79,Joe Allen:CM:79,Ashley Williams:CB:76,James Chester:CB:76,Neil Taylor:LB:74,Ben Woodburn:CAM:73,Karl Darlow:GK:73,Sam Vokes:ST:73,Joe Ledley:CM:72,Paul Dummett:LB:72,Wayne Hennessey:GK:72,Andy King:CM:70,Chris Gunter:RB:70,Hal Robson-Kanu:ST:70,Adam Matthews:RB:68,Emyr Huws:CDM:68,David Cotterill:RW:64,Jonny Williams:CAM:64,Nicky Adams:RM:64,Tyler Roberts:CF:64",
  "Wales|2018": "Gareth Bale:RW:90,Aaron Ramsey:CM:86,Ben Davies:CB:82,Joe Allen:CM:80,David Brooks:RW:78,Danny Ward:GK:77,Ashley Williams:CB:76,Chris Mepham:CB:76,Ethan Ampadu:CDM:76,James Chester:CB:76,Sam Vokes:ST:74,Ben Woodburn:CAM:73,Karl Darlow:GK:73,Neil Taylor:LB:73,Tom Lawrence:CAM:73,Andy King:CM:70,Joe Ledley:CM:70,Tyler Roberts:CF:70,Adam Matthews:RB:68,Chris Gunter:RB:68,Declan John:LB:64,Nicky Adams:RM:64",
  "Wales|2019": "Gareth Bale:RW:88,Aaron Ramsey:CM:85,Daniel James:RW:83,Ben Davies:CB:82,Chris Mepham:CB:79,Joe Allen:CM:79,Ethan Ampadu:CDM:77,Rabbi Matondo:LW:77,Danny Ward:GK:76,James Chester:CB:76,Paul Dummett:LB:76,Ben Woodburn:CAM:73,Sam Vokes:ST:73,Tom Lawrence:CAM:73,Wayne Hennessey:GK:73,Connor Roberts:RB:72,Neil Taylor:LB:72,Tyler Roberts:CF:72,Andy King:CM:70,Joe Ledley:CM:70,Chris Gunter:RB:68,Matthew Smith:CDM:68",
  "Wales|2020": "Aaron Ramsey:CM:84,Gareth Bale:RW:84,Daniel James:RW:82,Ben Davies:CB:80,Ethan Ampadu:CDM:77,Neco Williams:LB:77,Rabbi Matondo:LW:76,Danny Ward:GK:75,Joe Allen:CM:74,Paul Dummett:LB:74,Tom Lawrence:CAM:74,Ben Cabango:CB:73,Ben Woodburn:CAM:73,Connor Roberts:RB:72,Tyler Roberts:CF:72,Hal Robson-Kanu:ST:70,Karl Darlow:GK:70,Sam Vokes:ST:70,Chris Gunter:RB:64,Nicky Adams:RM:64",
  "Wales|2021": "Gareth Bale:RW:81,Ben Davies:CB:80,David Brooks:RW:80,Aaron Ramsey:CM:79,Ethan Ampadu:CDM:79,Joe Rodon:CB:77,Ben Cabango:CB:76,Chris Mepham:CB:76,Tyler Roberts:CF:76,Danny Ward:GK:74,Connor Roberts:RB:73,Kieffer Moore:ST:73,Rabbi Matondo:LW:73,Tom Lawrence:CAM:73,Paul Dummett:LB:72,Ben Woodburn:CAM:70,Jay Dasilva:LB:70,Joe Allen:CM:70,Karl Darlow:GK:70,Will Vaulks:CDM:70,Sorba Thomas:LW:68,Nicky Adams:RM:64",
  "Wales|2022": "Ben Davies:CB:81,Brennan Johnson:RW:81,Daniel James:RW:80,Neco Williams:LB:80,Ethan Ampadu:CDM:79,Joe Rodon:CB:77,Ben Cabango:CB:76,Danny Ward:GK:76,Tyler Roberts:CF:76,Chris Mepham:CB:74,Connor Roberts:RB:74,Kieffer Moore:ST:73,Tom Lawrence:CAM:73,Rabbi Matondo:LW:72,Aaron Ramsey:CM:70,Karl Darlow:GK:70,Paul Dummett:LB:68,Ryan Broom:RM:64",
  "Wales|2023": "Brennan Johnson:RW:86,Neco Williams:LB:81,Harry Wilson:RW:80,Ben Cabango:CB:79,Ben Davies:CB:79,Chris Mepham:CB:76,Connor Roberts:RB:76,Joe Rodon:CB:76,Danny Ward:GK:74,Sorba Thomas:LW:74,Jordan James:CM:72,Kieffer Moore:ST:72,Nathan Broadhead:LW:72,Tom Lawrence:CAM:72,Oliver Cooper:CAM:70,Rhys Norrington-Davies:LB:70,Tyler Roberts:CF:70,Dom Jefferies:RM:64,Karl Darlow:GK:64",
  "Wales|2025": "Brennan Johnson:RW:85,Neco Williams:LB:82,Harry Wilson:RW:81,Ben Cabango:CB:77,Jordan James:CM:76,Sorba Thomas:LW:76,Ben Davies:CB:74,Chris Mepham:CB:74,Jay Dasilva:LB:74,Connor Roberts:RB:73,Liam Cullen:CAM:70,Oliver Cooper:CAM:70,Wes Burns:RM:70,Rabbi Matondo:LW:68,Tyler Roberts:CF:68,Danny Ward:GK:64"
};

// src/lib/soccerInternationalSquads.ts
init_soccerInternational();
var XI_SHAPE = [
  /* Round 257, owner report: "I'm a right winger but I'm in the position
     of a left winger. Also cdm isn't in the correct spot."
     This array is ALSO the left-to-right render order of each line (see
     order() below), and it was listing the right side first, so every
     sheet was mirrored: the right winger sat on the left of the screen
     and the holding midfielder sat out on a flank. A team sheet is drawn
     the way a camera behind your own goal sees it, so the left-sided
     shirts come first and the holder sits in the middle of his three. */
  { slot: "GK", group: "GK" },
  { slot: "LB", group: "DEF" },
  { slot: "CB", group: "DEF" },
  { slot: "CB", group: "DEF" },
  { slot: "RB", group: "DEF" },
  { slot: "CM", group: "MID" },
  { slot: "CDM", group: "MID" },
  { slot: "CM", group: "MID" },
  { slot: "LW", group: "ATT" },
  { slot: "ST", group: "ATT" },
  { slot: "RW", group: "ATT" }
];
var POOL_ALIAS = {
  USA: "United States",
  Turkey: "T\xFCrkiye",
  "Ivory Coast": "Cote d'Ivoire",
  "South Korea": "Korea, South",
  "Bosnia & Herzegovina": "Bosnia-Herzegovina"
};
var poolCache = /* @__PURE__ */ new Map();
function realPool(nation, year) {
  if (year < NATIONAL_POOL_YEARS.first || year > NATIONAL_POOL_YEARS.last) return null;
  const key = `${POOL_ALIAS[nation] ?? nation}|${year}`;
  if (poolCache.has(key)) return poolCache.get(key) ?? null;
  const blob = NATIONAL_POOLS[key];
  if (!blob) {
    poolCache.set(key, null);
    return null;
  }
  const men = [];
  for (const entry of blob.split(",")) {
    const [name, pos, ovr] = entry.split(":");
    if (!name || !pos || !ovr) continue;
    men.push({ name, pos, ovr: Number(ovr), group: positionGroup(pos) });
  }
  men.sort((a, b) => b.ovr - a.ovr);
  poolCache.set(key, men.length ? men : null);
  return men.length ? men : null;
}
var XI_FILL = {
  GK: ["GK"],
  DEF: ["CB", "CB", "RB", "LB"],
  MID: ["CM", "CM", "CDM"],
  ATT: ["ST", "RW", "LW"]
};
function slotForPosition(pos) {
  if (pos === "GK") return "GK";
  if (pos === "CAM") return "CM";
  if (pos === "CF") return "ST";
  if (XI_SHAPE.some((x) => x.slot === pos)) return pos;
  return positionGroup(pos) === "ATT" ? "ST" : positionGroup(pos) === "MID" ? "CM" : "CB";
}
function buildStartingXi(nation, form, myScore, myRank, rivals, called, year) {
  const pool = year === void 0 ? null : realPool(nation, year);
  const drawn = /* @__PURE__ */ new Set();
  const shirtWants = {
    GK: ["GK"],
    CB: ["CB"],
    LB: ["LB", "LM"],
    RB: ["RB", "RM"],
    CDM: ["CDM", "CM"],
    CM: ["CM", "CAM", "CDM"],
    ST: ["ST", "CF"],
    LW: ["LW", "LM"],
    RW: ["RW", "RM"]
  };
  const takeForShirts = (group, shirts) => {
    if (!pool) return shirts.map(() => null);
    const out = [];
    for (const shirt of shirts) {
      const wants = shirtWants[shirt] ?? [shirt];
      let man;
      for (const want of wants) {
        man = pool.find((m) => m.pos === want && !drawn.has(m.name));
        if (man) break;
      }
      if (!man) man = pool.find((m) => m.group === group && !drawn.has(m.name));
      if (man) drawn.add(man.name);
      out.push(man ?? null);
    }
    return out;
  };
  const str = nationStrength(nation);
  const poolTop = 0.65 * str + 28.6;
  const myGroup = form ? positionGroup(form.position) : null;
  const rows = { GK: [], DEF: [], MID: [], ATT: [] };
  let mySlot = null;
  let aheadOfMe = null;
  let nameIdx = 0;
  for (const group of ["GK", "DEF", "MID", "ATT"]) {
    const shirts = [...XI_FILL[group]];
    const starters = shirts.length;
    const others = group === myGroup ? [...rivals].sort((a, b) => b - a) : Array.from({ length: starters }, (_, i) => poolTop - i * 1.4 + (Math.random() * 4 - 2)).sort((a, b) => b - a);
    const real = takeForShirts(group, shirts);
    const nameFor = (i) => real[i]?.name ?? intlName(nation, nameIdx + i);
    const ovrFor = (i, fallback) => real[i] ? real[i].ovr : Math.round(fallback);
    const iStart = called && group === myGroup && myRank <= starters;
    if (iStart && form) {
      const want = slotForPosition(form.position);
      const idx = shirts.indexOf(want);
      const takes = idx >= 0 ? idx : shirts.length - 1;
      const label = form.position === "CAM" || !shirts.includes(form.position) ? form.position : shirts[takes];
      mySlot = label;
      const mine = { slot: label, name: "You", ovr: Math.round(form.overall), me: true };
      shirts.splice(takes, 1);
      real.splice(takes, 1);
      const rest = shirts.map((slot, i) => ({
        slot,
        name: nameFor(i),
        ovr: ovrFor(i, others[i] ?? poolTop),
        me: false
      }));
      nameIdx += shirts.length;
      rows[group] = [mine, ...rest];
    } else {
      rows[group] = shirts.map((slot, i) => ({
        slot,
        name: nameFor(i),
        ovr: ovrFor(i, others[i] ?? poolTop),
        me: false
      }));
      nameIdx += shirts.length;
      if (called && group === myGroup) {
        aheadOfMe = rows[group][rows[group].length - 1].name;
      }
    }
  }
  const order = (group) => {
    const want = XI_SHAPE.filter((x) => x.group === group).map((x) => x.slot);
    const men = [...rows[group]];
    const out = [];
    for (const slot of want) {
      const i = men.findIndex((m) => m.slot === slot);
      if (i >= 0) out.push(...men.splice(i, 1));
    }
    return [...out, ...men];
  };
  return {
    formation: "4-3-3",
    gk: order("GK"),
    def: order("DEF"),
    mid: order("MID"),
    att: order("ATT"),
    mySlot,
    aheadOfMe
  };
}
function pickSquad(nation, form, year) {
  const grp = form ? positionGroup(form.position) : "ATT";
  const places = SQUAD_PLACES[grp];
  const str = nationStrength(nation);
  const poolTop = 0.65 * str + 28.6;
  const poolSize = places * 2 + 2;
  const rivals = [];
  for (let i = 0; i < poolSize - 1; i++) {
    rivals.push(poolTop - i * 1.4 + (Math.random() * 4 - 2));
  }
  if (!form) {
    return {
      called: false,
      role: null,
      myRank: poolSize,
      poolSize,
      places,
      myScore: 0,
      cutScore: Math.round(rivals[places - 1] ?? str),
      reason: `You are not in the ${nation} setup.`,
      /* Round 197: the eleven exists whether or not he is in it. Watching
         the team you are not in is the point of being left out. */
      xi: buildStartingXi(nation, null, 0, poolSize, rivals, false, year)
    };
  }
  const formBonus = clamp((form.lastRating - 6.9) * 4, -6, 6) + clamp(form.lastGoals * 0.12, 0, 4);
  const agePenalty = form.age >= 36 ? 5 : form.age >= 34 ? 2.5 : 0;
  const captainBonus = form.isCaptain ? 3 : 0;
  const myScore = form.overall + formBonus + captainBonus - agePenalty;
  const better = rivals.filter((r) => r > myScore).length;
  const myRank = better + 1;
  const cut = [...rivals].sort((a, b) => b - a)[places - 1] ?? 0;
  const called = myRank <= places;
  let role = null;
  if (called) {
    if (form.isCaptain) role = "Captain";
    else if (myRank === 1) role = "Starter";
    else if (myRank <= Math.max(1, Math.ceil(places / 2))) role = "Starter";
    else role = "Squad player";
  }
  const reason = called ? myRank === 1 ? `You are ${nation}'s first choice in your position.` : `You made it as number ${myRank} of ${places} in your position.` : `You came ${myRank}th in your position and ${nation} named ${places}. Not this time.`;
  return {
    called,
    role,
    reason,
    myRank,
    poolSize,
    places,
    myScore: Math.round(myScore),
    cutScore: Math.round(cut),
    xi: buildStartingXi(nation, form, myScore, myRank, rivals, called, year)
  };
}
function runInternationalSummer(nation, year, form) {
  const fmt = tournamentForYear(nation, year);
  if (!fmt) return null;
  const qualifying = runQualifying(nation, fmt, form);
  const squad = qualifying.qualified ? pickSquad(nation, form, year) : null;
  return simulateTournament(nation, fmt, year, qualifying, squad, form);
}

// src/lib/soccerCareerEngine.ts
init_soccerInternational();

// src/lib/careerAwardsNight.ts
var byPoints = (a, b) => b.points - a.points;
function placeOf(list2) {
  const i = list2.findIndex((n) => n.isPlayer);
  return i >= 0 ? i + 1 : null;
}
function uniqueRivals(list2) {
  const seen = /* @__PURE__ */ new Set();
  return list2.filter((c) => {
    if (c.isPlayer || seen.has(c.name)) return false;
    seen.add(c.name);
    return true;
  });
}
function runAwardsNight(award, year, ballot) {
  const seats = ballot.player ? award.shortlistSize - 1 : award.shortlistSize;
  let shortlist = uniqueRivals(ballot.field).slice(0, seats);
  if (shortlist.length < seats && ballot.fill) {
    ballot.fill(shortlist, seats);
    shortlist = uniqueRivals(shortlist);
  }
  if (ballot.player) shortlist.push(ballot.player);
  shortlist.sort(byPoints);
  const nominees = shortlist.slice(0, award.shortlistSize);
  let place = placeOf(nominees);
  for (const verdict of ballot.verdicts ?? []) {
    verdict(nominees, place);
    nominees.sort(byPoints);
    place = placeOf(nominees);
  }
  if (place === null && ballot.widerEligible && award.widerSize > award.shortlistSize) {
    const better = ballot.field.filter((n) => !n.isPlayer && n.points > ballot.playerPoints).length;
    const wider = Math.max(award.shortlistSize + 1, better + 1);
    if (wider <= award.widerSize) place = wider;
  }
  return { year, nominees, playerRank: place, playerPoints: ballot.playerPoints, playerNominated: ballot.player !== null };
}
function describeSteps(meters, steps) {
  return steps.map(({ meter, delta }) => {
    const m = meters[meter];
    return `${m.label} ${m.show ? m.show(delta) : `${delta >= 0 ? "+" : ""}${delta}`}`;
  }).join(", ");
}
function applyMeterSteps(meters, s, steps) {
  for (const step of steps) meters[step.meter].add(s, step.delta);
}
function measureMoves(meters, s, apply) {
  const ids = Object.keys(meters);
  const before = ids.map((m) => meters[m].read(s));
  apply();
  return ids.map((meter, i) => ({ meter, delta: Math.round((meters[meter].read(s) - before[i]) * 100) / 100 })).filter((st) => st.delta !== 0);
}
function settleAwardsNight(sport, s, season2, night) {
  const place = night.playerRank;
  let moved = null;
  if (place !== null) {
    sport.recordPlace(season2, place);
    if (place === 1) {
      sport.recordWin(season2);
      sport.addToCabinet(s, { year: night.year, name: sport.award.name, emoji: sport.award.emoji });
      moved = measureMoves(sport.meters, s, () => applyMeterSteps(sport.meters, s, sport.winnerSteps));
    } else if (place <= sport.award.podiumSize) {
      moved = measureMoves(sport.meters, s, () => applyMeterSteps(sport.meters, s, sport.podiumSteps));
      sport.onPodium?.(s);
    }
  }
  sport.stage(s, moved ? { ...night, moved: describeSteps(sport.meters, moved) } : night);
}

// src/lib/soccerCareerEngine.ts
var SPENDING_ITEMS = [
  // Properties
  { id: "rent_apartment", name: "Rent Apartment", emoji: "\u{1F3E2}", category: "property", cost: 0, monthlyCost: 0.024, description: "Basic city apartment, \u20AC2k/month", oneTime: true },
  { id: "city_apartment", name: "City Apartment", emoji: "\u{1F3D9}\uFE0F", category: "property", cost: 0.8, description: "Buy a stylish city apartment, \u20AC800k", oneTime: true, minNetWorth: 0.5 },
  { id: "luxury_house", name: "Luxury House", emoji: "\u{1F3E0}", category: "property", cost: 3, description: "Buy a luxury house, \u20AC3M", oneTime: true, minNetWorth: 2 },
  { id: "mansion", name: "Mansion", emoji: "\u{1F3F0}", category: "property", cost: 8, description: "Buy a sprawling mansion, \u20AC8M", oneTime: true, minNetWorth: 5 },
  { id: "private_island", name: "Private Island", emoji: "\u{1F3DD}\uFE0F", category: "property", cost: 25, description: "Buy your own private island, \u20AC25M", oneTime: true, minNetWorth: 20 },
  // Vehicles
  { id: "sports_car", name: "Sports Car", emoji: "\u{1F3CE}\uFE0F", category: "vehicle", cost: 0.15, description: "Buy a sports car, \u20AC150k", oneTime: false },
  { id: "supercar_collection", name: "Supercar Collection", emoji: "\u{1F697}", category: "vehicle", cost: 0.8, description: "Build a supercar collection, \u20AC800k", oneTime: true, minNetWorth: 1 },
  { id: "private_jet", name: "Private Jet", emoji: "\u2708\uFE0F", category: "vehicle", cost: 15, monthlyCost: 0.5, description: "Buy a private jet, \u20AC15M + \u20AC500k/yr upkeep", oneTime: true, minNetWorth: 12 },
  { id: "yacht", name: "Yacht", emoji: "\u{1F6E5}\uFE0F", category: "vehicle", cost: 8, monthlyCost: 0.3, description: "Buy a luxury yacht, \u20AC8M + \u20AC300k/yr upkeep", oneTime: true, minNetWorth: 6 },
  // Investments
  { id: "restaurant_chain", name: "Restaurant Chain", emoji: "\u{1F37D}\uFE0F", category: "investment", cost: 0.5, description: "30% chance profit \u20AC1.5M, 70% break even or loss", oneTime: false },
  { id: "crypto", name: "Crypto", emoji: "\u20BF", category: "investment", cost: 0.2, description: "50% chance 3x return, 50% lose it all", oneTime: false },
  { id: "football_shares", name: "Football Club Shares", emoji: "\u26BD", category: "investment", cost: 5, description: "Steady 8% return per year", oneTime: true, minNetWorth: 4 },
  { id: "tech_startup", name: "Tech Startup", emoji: "\u{1F4BB}", category: "investment", cost: 1, description: "20% chance 10x return, 80% lose it", oneTime: false },
  // Lifestyle upgrades
  { id: "personal_chef", name: "Personal Chef", emoji: "\u{1F468}\u200D\u{1F373}", category: "lifestyle", cost: 0, monthlyCost: 0.05, description: "Hire a personal chef, \u20AC50k/year", oneTime: true, effect: "Better nutrition, +2 morale per season" },
  { id: "personal_trainer", name: "Personal Trainer", emoji: "\u{1F4AA}", category: "lifestyle", cost: 0, monthlyCost: 0.08, description: "Private trainer, \u20AC80k/year", oneTime: true, effect: "+1 Physical stat per season" },
  { id: "sports_psychologist", name: "Sports Psychologist", emoji: "\u{1F9E0}", category: "lifestyle", cost: 0, monthlyCost: 0.06, description: "Mental coach, \u20AC60k/year", oneTime: true, effect: "+5 Morale permanently on hire" },
  { id: "elite_recovery", name: "Elite Recovery Clinic", emoji: "\u{1F3E5}", category: "lifestyle", cost: 0, monthlyCost: 0.1, description: "Top recovery tech, \u20AC100k/year", oneTime: true, effect: "Reduces injury recovery time by 50%" },
  // Performance upgrades
  { id: "perf_chef", name: "Private Chef", emoji: "\u{1F957}", category: "performance", cost: 2, description: "Elite nutrition plan, \u20AC2M", oneTime: true, effect: "+2 Physical, +2 Stamina" },
  { id: "perf_psychologist", name: "Sports Psychologist", emoji: "\u{1F9E0}", category: "performance", cost: 1.5, description: "Mental performance coach, \u20AC1.5M", oneTime: true, effect: "+3 Composure" },
  { id: "perf_cryo", name: "Cryotherapy Suite", emoji: "\u{1F9CA}", category: "performance", cost: 3, description: "Home cryo chamber, \u20AC3M", oneTime: true, effect: "Reduces injury risk by 15%" },
  { id: "perf_trainer", name: "Elite Personal Trainer", emoji: "\u{1F3CB}\uFE0F", category: "performance", cost: 2.5, description: "World-class trainer, \u20AC2.5M", oneTime: true, effect: "+2 Pace, +2 Physical" },
  { id: "perf_biomech", name: "Biomechanics Coach", emoji: "\u{1F52C}", category: "performance", cost: 2, description: "Technique specialist, \u20AC2M", oneTime: true, effect: "+2 Shooting, +2 Passing" },
  { id: "perf_altitude", name: "Altitude Training Camp", emoji: "\u26F0\uFE0F", category: "performance", cost: 1, description: "High-altitude camp, \u20AC1M", oneTime: true, effect: "+3 Stamina" },
  { id: "perf_sleep", name: "Sleep Optimization Clinic", emoji: "\u{1F634}", category: "performance", cost: 1.5, description: "Sleep science program, \u20AC1.5M", oneTime: true, effect: "Faster injury recovery" },
  { id: "perf_vr", name: "VR Training System", emoji: "\u{1F97D}", category: "performance", cost: 2, description: "Virtual training tech, \u20AC2M", oneTime: true, effect: "+2 Decision Making" },
  { id: "perf_vision", name: "Vision Training Clinic", emoji: "\u{1F441}\uFE0F", category: "performance", cost: 1.5, description: "Visual processing training, \u20AC1.5M", oneTime: true, effect: "+2 Passing, better assist rate" },
  { id: "perf_setpiece", name: "Set Piece Coach", emoji: "\u{1F3AF}", category: "performance", cost: 1, description: "Dead ball specialist, \u20AC1M", oneTime: true, effect: "+3 Free Kick accuracy" },
  // 2026-08-05 money expansion (owner: "way more options to do with ur money")
  { id: "boyhood_club", name: "Buy Your Boyhood Club", emoji: "\u{1F3DF}\uFE0F", category: "property", cost: 60, description: "Buy the club where it all started, \u20AC60M", oneTime: true, minNetWorth: 50, effect: "Legacy landmark, popularity +20" },
  { id: "hometown_academy", name: "Hometown Academy", emoji: "\u{1F393}", category: "property", cost: 10, description: "Build a youth academy back home, \u20AC10M", oneTime: true, minNetWorth: 8, effect: "Legacy +, popularity +10" },
  { id: "football_museum", name: "Museum of You", emoji: "\u{1F5BC}\uFE0F", category: "property", cost: 12, description: "A museum about your own career, \u20AC12M", oneTime: true, minNetWorth: 15, effect: "Popularity +8, peak ego" },
  { id: "hypercar", name: "Hypercar", emoji: "\u{1F3CE}\uFE0F", category: "vehicle", cost: 2, description: "A seven-figure hypercar, \u20AC2M", oneTime: false, minNetWorth: 3 },
  { id: "submarine", name: "Personal Submarine", emoji: "\u{1F6F3}\uFE0F", category: "vehicle", cost: 30, monthlyCost: 0.4, description: "Yes, a submarine, \u20AC30M", oneTime: true, minNetWorth: 45, effect: "Absolutely unnecessary. Popularity +5" },
  { id: "teammate_startup", name: "Teammate's Startup", emoji: "\u{1F680}", category: "investment", cost: 1, description: "40% chance 5x return, 60% lose it", oneTime: false },
  { id: "meme_coin", name: "Meme Coin", emoji: "\u{1F415}", category: "investment", cost: 0.5, description: "10% chance 20x, 90% goes to zero", oneTime: false },
  { id: "art_collection", name: "Art Collection", emoji: "\u{1F3A8}", category: "investment", cost: 3, description: "Steady 12% a year, very classy", oneTime: true, minNetWorth: 5 },
  { id: "racehorse", name: "Racehorse", emoji: "\u{1F40E}", category: "investment", cost: 2, description: "25% chance of a \u20AC6M champion, else modest stud fees", oneTime: false, minNetWorth: 4 },
  { id: "esports_org", name: "Esports Org", emoji: "\u{1F3AE}", category: "investment", cost: 4, description: "35% chance 3x return", oneTime: true, minNetWorth: 6 },
  { id: "security_team", name: "Security Team", emoji: "\u{1F576}\uFE0F", category: "lifestyle", cost: 0, monthlyCost: 0.2, description: "Round-the-clock protection, \u20AC200k/year", oneTime: true, effect: "+3 Morale, sleeps easy" },
  { id: "documentary_crew", name: "Documentary Crew", emoji: "\u{1F3A5}", category: "lifestyle", cost: 0, monthlyCost: 0.15, description: "Your own all-access doc series, \u20AC150k/year", oneTime: true, effect: "+3 Popularity per season" },
  { id: "family_office", name: "Family Office", emoji: "\u{1F3E6}", category: "lifestyle", cost: 0, monthlyCost: 0.12, description: "Professional wealth managers, \u20AC120k/year", oneTime: true, effect: "+2% net worth growth per season" },
  { id: "charity_foundation", name: "Charity Foundation", emoji: "\u2764\uFE0F", category: "lifestyle", cost: 5, monthlyCost: 0.1, description: "Your name, doing good, \u20AC5M + \u20AC100k/year", oneTime: true, minNetWorth: 8, effect: "Popularity +3 and legacy credit per season" },
  // 2026-08-05 second wave: even more outta pocket
  { id: "signature_cologne", name: "Signature Cologne", emoji: "\u{1F9F4}", category: "investment", cost: 2, description: "Launch your own fragrance, \u20AC2M. 60% chance it prints \u20AC5M, 40% it smells like a locker room", oneTime: true, minNetWorth: 3 },
  { id: "tequila_brand", name: "Celebrity Tequila", emoji: "\u{1F943}", category: "investment", cost: 4, description: "Every star has one, \u20AC4M. 45% chance 3x, else slow fade", oneTime: true, minNetWorth: 6 },
  { id: "video_game_studio", name: "Football Game Studio", emoji: "\u{1F3AE}", category: "investment", cost: 8, description: "Fund a studio making a game where YOU are the cover star, \u20AC8M. 25% chance 4x hit", oneTime: true, minNetWorth: 12 },
  { id: "space_flight", name: "Seat To Space", emoji: "\u{1F680}", category: "lifestyle", cost: 12, description: "Eleven minutes above the atmosphere, \u20AC12M. Popularity +12, perspective forever", oneTime: true, minNetWorth: 20 },
  { id: "rivals_boyhood_club", name: "Buy Your Rival's Boyhood Club", emoji: "\u{1F5FF}", category: "property", cost: 45, description: "The pettiest \u20AC45M in football history. Rename the stadium after yourself", oneTime: true, minNetWorth: 60, effect: "Popularity +8, the feud becomes eternal" },
  // ── Round 54 mega expansion: FLEX. Pure, glorious, unnecessary. ──
  { id: "flex_gold_chain", name: "Cuban Link Chain", emoji: "\u26D3\uFE0F", category: "flex", cost: 0.3, description: "Half a kilo of gold around your neck, \u20AC300k", oneTime: true, popularityBoost: 2, effect: "Popularity +2" },
  { id: "flex_diamond_grill", name: "Diamond Grill", emoji: "\u{1F62C}", category: "flex", cost: 0.5, description: "Your smile now costs more than most transfers, \u20AC500k", oneTime: true, popularityBoost: 3, effect: "Popularity +3, blinding" },
  { id: "flex_watch_wall", name: "Watch Wall", emoji: "\u231A", category: "flex", cost: 4, description: "A rotating display wall of 40 watches, \u20AC4M", oneTime: true, minNetWorth: 6, popularityBoost: 3, effect: "Popularity +3" },
  { id: "flex_sneaker_vault", name: "Sneaker Vault", emoji: "\u{1F45F}", category: "flex", cost: 1.5, description: "Climate-controlled room for 800 pairs, \u20AC1.5M", oneTime: true, minNetWorth: 2, moraleBoost: 4, effect: "+4 Morale" },
  { id: "flex_full_sleeve", name: "Full Tattoo Sleeve", emoji: "\u{1F58B}\uFE0F", category: "flex", cost: 0.05, description: "Your whole story in ink, \u20AC50k", oneTime: true, popularityBoost: 2, effect: "Popularity +2" },
  { id: "flex_back_tattoo", name: "Back Piece Of Yourself", emoji: "\u{1F3A8}", category: "flex", cost: 0.1, description: "A tattoo of you celebrating, on you, \u20AC100k", oneTime: true, minPopularity: 50, popularityBoost: 3, effect: "Peak ego. Popularity +3" },
  { id: "flex_tiger", name: "Pet Tiger", emoji: "\u{1F405}", category: "flex", cost: 1, monthlyCost: 0.15, description: "A literal tiger named Butters, \u20AC1M + upkeep", oneTime: true, minNetWorth: 5, popularityBoost: 5, heatChange: 5, effect: "Popularity +5, questions from authorities" },
  { id: "flex_exotic_aquarium", name: "Shark Aquarium", emoji: "\u{1F988}", category: "flex", cost: 2.5, monthlyCost: 0.1, description: "A wall-sized tank with two actual sharks, \u20AC2.5M", oneTime: true, minNetWorth: 8, moraleBoost: 3, effect: "+3 Morale, do not tap the glass" },
  { id: "flex_entourage", name: "Full-Time Entourage", emoji: "\u{1F57A}", category: "flex", cost: 0, monthlyCost: 0.5, description: "Twelve guys whose job is agreeing with you, \u20AC500k/yr", oneTime: true, minNetWorth: 10, moraleBoost: 5, effect: "+5 Morale, zero honest feedback" },
  { id: "flex_gold_phone", name: "Solid Gold Phone", emoji: "\u{1F4F1}", category: "flex", cost: 0.2, description: "It barely gets signal but it is GOLD, \u20AC200k", oneTime: true, popularityBoost: 1, effect: "Popularity +1" },
  { id: "flex_custom_cleats", name: "Diamond-Studded Boots", emoji: "\u{1F48E}", category: "flex", cost: 0.8, description: "Match-worn once, then straight into a display case, \u20AC800k", oneTime: true, minPopularity: 40, popularityBoost: 4, effect: "Popularity +4" },
  { id: "flex_hologram", name: "Hologram Of Yourself", emoji: "\u{1F47B}", category: "flex", cost: 3, description: "Greets guests in your foyer with your catchphrase, \u20AC3M", oneTime: true, minNetWorth: 12, popularityBoost: 3, effect: "Guests scream every time. Popularity +3" },
  { id: "flex_theme_park_day", name: "Rent A Theme Park", emoji: "\u{1F3A2}", category: "flex", cost: 1.2, description: "The whole park, one day, just your people, \u20AC1.2M", oneTime: false, minNetWorth: 4, moraleBoost: 6, effect: "+6 Morale" },
  { id: "flex_statue_garden", name: "Statue Garden Of You", emoji: "\u{1F5FD}", category: "flex", cost: 6, description: "Seven marble yous in seven iconic poses, \u20AC6M", oneTime: true, minNetWorth: 20, popularityBoost: 4, effect: "Popularity +4, deeply unsettling" },
  { id: "flex_racing_team", name: "Kart Racing Team", emoji: "\u{1F3CE}\uFE0F", category: "flex", cost: 2, description: "Your own liveried karting outfit, \u20AC2M", oneTime: true, minNetWorth: 8, moraleBoost: 3, popularityBoost: 2, effect: "+3 Morale, +2 Popularity" },
  // ── FAMILY. The people who knew you before the money. ──
  { id: "fam_parents_house", name: "Buy Your Parents A House", emoji: "\u{1F3E1}", category: "family", cost: 1.5, description: "The first big promise, kept, \u20AC1.5M", oneTime: true, moraleBoost: 8, popularityBoost: 3, effect: "+8 Morale, +3 Popularity. The photo goes viral" },
  { id: "fam_mom_car", name: "Mom's Dream Car", emoji: "\u{1F699}", category: "family", cost: 0.15, description: "She cried at the dealership, \u20AC150k", oneTime: true, moraleBoost: 4, effect: "+4 Morale" },
  { id: "fam_college_fund", name: "Siblings' College Fund", emoji: "\u{1F393}", category: "family", cost: 0.5, description: "Every niece, nephew and cousin covered, \u20AC500k", oneTime: true, moraleBoost: 5, effect: "+5 Morale" },
  { id: "fam_grandpa_season", name: "Grandpa's Lifetime Season Ticket", emoji: "\u{1F474}", category: "family", cost: 0.05, description: "Front row, halfway line, forever, \u20AC50k", oneTime: true, moraleBoost: 4, effect: "+4 Morale, he heckles the ref weekly" },
  { id: "fam_hometown_pitch", name: "Rebuild The Hometown Pitch", emoji: "\u{1F945}", category: "family", cost: 2, description: "The cage you learned in, redone properly with lights, \u20AC2M", oneTime: true, popularityBoost: 6, moraleBoost: 4, effect: "+6 Popularity, +4 Morale" },
  { id: "fam_family_vacation", name: "Whole-Family World Tour", emoji: "\u{1F30D}", category: "family", cost: 0.8, description: "Twenty-three relatives, first class, one summer, \u20AC800k", oneTime: false, moraleBoost: 6, effect: "+6 Morale" },
  { id: "fam_wedding", name: "Fairytale Wedding", emoji: "\u{1F492}", category: "family", cost: 3, description: "Castle, fireworks, a surprise performance by a global star, \u20AC3M", oneTime: true, minNetWorth: 5, moraleBoost: 8, popularityBoost: 4, effect: "+8 Morale, +4 Popularity" },
  { id: "fam_dad_pub", name: "Buy Dad The Local Pub", emoji: "\u{1F37A}", category: "family", cost: 0.7, description: "He renames it after your first goal, \u20AC700k", oneTime: true, moraleBoost: 5, popularityBoost: 2, effect: "+5 Morale, +2 Popularity" },
  { id: "fam_security_family", name: "Family Security Detail", emoji: "\u{1F6E1}\uFE0F", category: "family", cost: 0, monthlyCost: 0.25, description: "Round-the-clock protection for the whole family, \u20AC250k/yr", oneTime: true, minNetWorth: 15, moraleBoost: 4, effect: "+4 Morale, everyone sleeps easy" },
  { id: "fam_foundation_scholarship", name: "Hometown Scholarships", emoji: "\u{1F4DA}", category: "family", cost: 1, monthlyCost: 0.1, description: "Ten kids a year through school in your name, \u20AC1M + \u20AC100k/yr", oneTime: true, popularityBoost: 5, effect: "+5 Popularity and legacy credit" },
  // ── SHADY. The catalogue nobody photographs. Every purchase runs hot. ──
  { id: "shady_offshore", name: "Offshore Account", emoji: "\u{1F3DD}\uFE0F", category: "shady", cost: 0.5, description: "A quiet account in a sunny jurisdiction, \u20AC500k in fees", oneTime: true, minNetWorth: 3, heatChange: 12, effect: "Hides earnings from the taxman. Heat +12" },
  { id: "shady_shell_carwash", name: "Cash-Only Car Wash", emoji: "\u{1F9FC}", category: "shady", cost: 1, description: "Somehow washes 4,000 cars a week, \u20AC1M", oneTime: true, requiresDirty: true, heatChange: 8, effect: "Launders \u20AC2M of dirty money per season. Heat +8" },
  { id: "shady_nightclub", name: "Nightclub 'Offside'", emoji: "\u{1FAA9}", category: "shady", cost: 3, description: "VIP room, no cameras, cash bar, \u20AC3M", oneTime: true, minNetWorth: 5, requiresDirty: true, heatChange: 10, effect: "Launders \u20AC4M of dirty money per season. Heat +10" },
  { id: "shady_burner_phones", name: "Drawer Of Burner Phones", emoji: "\u{1F4F5}", category: "shady", cost: 0.02, description: "Twelve prepaid phones, no names, \u20AC20k", oneTime: true, heatChange: 4, effect: "Shady arcs get safer calls. Heat +4" },
  { id: "shady_fixer_retainer", name: "The Fixer's Retainer", emoji: "\u{1F574}\uFE0F", category: "shady", cost: 0, monthlyCost: 0.3, description: "A man who makes problems disappear, \u20AC300k/yr", oneTime: true, minNetWorth: 8, heatChange: 6, effect: "Reduces scandal fallout. Heat +6" },
  { id: "shady_ref_dinner", name: "'Dinner' With Officials", emoji: "\u{1F377}", category: "shady", cost: 0.25, description: "A very expensive restaurant, a very friendly whistle, \u20AC250k", oneTime: false, heatChange: 15, effect: "Next season runs smoother. Heat +15" },
  { id: "shady_passport", name: "Second Passport", emoji: "\u{1F6C2}", category: "shady", cost: 0.8, description: "A backup identity from a cooperative consulate, \u20AC800k", oneTime: true, minNetWorth: 5, heatChange: 10, effect: "An exit plan. Heat +10" },
  { id: "shady_casino_credit", name: "Casino Credit Line", emoji: "\u{1F3B0}", category: "shady", cost: 0, monthlyCost: 0.4, description: "The house always says yes to you, \u20AC400k/yr average damage", oneTime: true, minNetWorth: 10, heatChange: 8, effect: "Feeds the gambling arcs. Heat +8" },
  { id: "shady_paparazzi_payoff", name: "Paparazzi Payroll", emoji: "\u{1F4F8}", category: "shady", cost: 0, monthlyCost: 0.2, description: "They shoot what you TELL them to shoot, \u20AC200k/yr", oneTime: true, heatChange: 5, popularityBoost: 3, effect: "+3 Popularity, the bad photos vanish. Heat +5" },
  { id: "shady_crypto_mixer", name: "Crypto Tumbler", emoji: "\u{1F300}", category: "shady", cost: 0.3, description: "Coins go in dirty, come out confused, \u20AC300k", oneTime: true, requiresDirty: true, heatChange: 12, effect: "Launders \u20AC1.5M of dirty money per season. Heat +12" },
  // ── More PROPERTY, VEHICLES and INVESTMENTS while we are here. ──
  { id: "ski_chalet", name: "Alpine Ski Chalet", emoji: "\u{1F3BF}", category: "property", cost: 6, description: "Snow, sauna, silence, \u20AC6M", oneTime: true, minNetWorth: 10, moraleBoost: 3, effect: "+3 Morale" },
  { id: "desert_palace", name: "Desert Palace", emoji: "\u{1F54C}", category: "property", cost: 18, description: "Gold taps. Twelve bathrooms. Why not, \u20AC18M", oneTime: true, minNetWorth: 30, popularityBoost: 3, effect: "Popularity +3" },
  { id: "penthouse_row", name: "Penthouse In Five Cities", emoji: "\u{1F306}", category: "property", cost: 22, description: "Paris, Dubai, Miami, Tokyo, London. One key ring, \u20AC22M", oneTime: true, minNetWorth: 35, popularityBoost: 4, effect: "Popularity +4" },
  { id: "vineyard", name: "Tuscan Vineyard", emoji: "\u{1F347}", category: "property", cost: 9, description: "Your face on every bottle, \u20AC9M", oneTime: true, minNetWorth: 15, moraleBoost: 3, effect: "+3 Morale, surprisingly drinkable" },
  { id: "monster_truck", name: "Monster Truck", emoji: "\u{1F69B}", category: "vehicle", cost: 0.4, description: "For the school run, \u20AC400k", oneTime: true, popularityBoost: 2, effect: "Popularity +2" },
  { id: "vintage_bus", name: "The Team Bus (Vintage)", emoji: "\u{1F68C}", category: "vehicle", cost: 0.6, description: "Your first club's 1980s team bus, restored, \u20AC600k", oneTime: true, moraleBoost: 3, effect: "+3 Morale, pure nostalgia" },
  { id: "helicopter", name: "Personal Helicopter", emoji: "\u{1F681}", category: "vehicle", cost: 7, monthlyCost: 0.25, description: "Training is 90 seconds away, \u20AC7M", oneTime: true, minNetWorth: 12, effect: "Never late again" },
  { id: "superyacht", name: "Superyacht 'Golazo'", emoji: "\u{1F6F3}\uFE0F", category: "vehicle", cost: 40, monthlyCost: 1, description: "Helipad, cinema, a smaller boat inside it, \u20AC40M", oneTime: true, minNetWorth: 60, popularityBoost: 6, effect: "Popularity +6" },
  { id: "inv_padel_chain", name: "Padel Club Chain", emoji: "\u{1F3BE}", category: "investment", cost: 2, description: "Every footballer's favorite retirement hobby, early. 50% chance 2x", oneTime: true, minNetWorth: 4 },
  { id: "inv_burger_franchise", name: "Burger Franchise", emoji: "\u{1F354}", category: "investment", cost: 1.5, description: "Your celebration is on the cups. 55% chance 2x, else break even", oneTime: true, minNetWorth: 3 },
  { id: "inv_womens_club", name: "Fund A Women's Team", emoji: "\u26BD", category: "investment", cost: 3, description: "Build the women's side of a club properly. Steady 6% and huge respect", oneTime: true, minNetWorth: 6, popularityBoost: 5, effect: "+5 Popularity" },
  { id: "inv_stadium_naming", name: "Stadium Naming Rights", emoji: "\u{1F3DF}\uFE0F", category: "investment", cost: 15, description: "A real stadium, your name on it, 10 years. Steady 5% a year", oneTime: true, minNetWorth: 25, popularityBoost: 6, effect: "+6 Popularity" },
  /* ── Round 134: money that buys you something rather than a receipt ──
     His note was "there should be a lot more things u can do with ur money",
     and the half of that sentence that matters is what the money DOES. Every
     item below changes a number every season for as long as you own it: where
     you live, what you drive, who works for you and what you give away. The
     numbers are small because they compound over fifteen seasons, and a few of
     them cost you something as well as paying you, because a house nobody can
     find is worse for your fame and better for your head. */
  // Where you live
  { id: "home_by_training", name: "House By The Training Ground", emoji: "\u{1F3D8}\uFE0F", category: "property", cost: 2.5, description: "Ten minutes door to door, \u20AC2.5M", oneTime: true, minNetWorth: 2, perSeason: { morale: 2 }, injuryDrop: 5e-3, effect: "+2 Morale every season, and you turn up warm" },
  { id: "home_gym", name: "Gym In The Basement", emoji: "\u{1F3CB}\uFE0F\u200D\u2642\uFE0F", category: "property", cost: 1.2, description: "Plates, bikes, a physio bed, \u20AC1.2M", oneTime: true, minNetWorth: 1, perSeason: { stat: "physical", statAmount: 1 }, effect: "+1 Physical every season" },
  { id: "home_pitch", name: "Full Size Pitch In The Garden", emoji: "\u{1F945}", category: "property", cost: 4, description: "Floodlit, and the neighbours have opinions, \u20AC4M", oneTime: true, minNetWorth: 6, perSeason: { stat: "main", statAmount: 1 }, effect: "+1 to your main stat every season" },
  { id: "home_quiet", name: "Quiet Place Out Of Town", emoji: "\u{1F332}", category: "property", cost: 3, description: "Nobody knows the postcode, \u20AC3M", oneTime: true, minNetWorth: 4, perSeason: { morale: 3, popularity: -1 }, effect: "+3 Morale a season, and the cameras forget you a bit" },
  // What you drive
  { id: "driver_car", name: "A Driver And A Quiet Car", emoji: "\u{1F698}", category: "vehicle", cost: 0, monthlyCost: 0.12, description: "You stop driving yourself home at 1am, \u20AC120k/yr", oneTime: true, perSeason: { morale: 1 }, injuryDrop: 3e-3, effect: "+1 Morale a season, you arrive rested" },
  { id: "classic_car", name: "Restored Classic", emoji: "\u{1F699}", category: "vehicle", cost: 0.9, description: "The one off your bedroom wall, rebuilt, \u20AC900k", oneTime: true, popularityBoost: 2, perSeason: { morale: 1 }, effect: "+2 Popularity now, +1 Morale a season" },
  // Who you employ
  { id: "staff_perf_team", name: "Your Own Performance Team", emoji: "\u{1F9EA}", category: "performance", cost: 6, monthlyCost: 0.4, description: "Four people whose whole job is you, \u20AC6M + \u20AC400k/yr", oneTime: true, minNetWorth: 10, perSeason: { stat: "main", statAmount: 1, morale: 1 }, effect: "+1 to your main stat and +1 Morale every season" },
  { id: "staff_analyst", name: "Your Own Analyst", emoji: "\u{1F4BB}", category: "performance", cost: 0, monthlyCost: 0.2, description: "Every opponent, clipped and sent to your phone, \u20AC200k/yr", oneTime: true, perSeason: { stat: "passing", statAmount: 1 }, effect: "+1 Passing every season" },
  { id: "staff_physio_call", name: "Private Physio On Call", emoji: "\u{1F9CA}", category: "performance", cost: 0, monthlyCost: 0.25, description: "Answers at midnight, \u20AC250k/yr", oneTime: true, minNetWorth: 3, injuryDrop: 0.02, effect: "Meaningfully fewer injuries" },
  { id: "staff_media", name: "Media Manager", emoji: "\u{1F3A4}", category: "lifestyle", cost: 0, monthlyCost: 0.15, description: "Says no to the wrong things and yes to the right ones, \u20AC150k/yr", oneTime: true, sponsorMult: 1.12, perSeason: { popularity: 1 }, effect: "Sponsors pay 12% more, +1 Popularity a season" },
  { id: "staff_family_cook", name: "Family Cook", emoji: "\u{1F372}", category: "family", cost: 0, monthlyCost: 0.06, description: "Everybody eats properly, not just you, \u20AC60k/yr", oneTime: true, perSeason: { morale: 1 }, effect: "+1 Morale every season" },
  { id: "staff_kids_tutor", name: "A Tutor For The Kids", emoji: "\u{1F4D6}", category: "family", cost: 0, monthlyCost: 0.09, description: "Six moves in ten years is hard on a school report, \u20AC90k/yr", oneTime: true, perSeason: { morale: 1, integrity: 1 }, effect: "+1 Morale a season and it counts toward your legacy" },
  // What you give away
  { id: "give_kid_career", name: "Pay For A Kid's Whole Youth Career", emoji: "\u{1F9D2}", category: "family", cost: 0.3, description: "Boots, subs, travel, all of it, until he is sixteen, \u20AC300k", oneTime: true, perSeason: { integrity: 2, popularity: 1 }, effect: "Legacy credit every season, quietly" },
  { id: "give_home_club", name: "Cover The Hometown Club's Season", emoji: "\u{1F3DF}\uFE0F", category: "family", cost: 0, monthlyCost: 0.25, description: "Kit, pitch, minibus, the lot, \u20AC250k/yr", oneTime: true, minNetWorth: 2, perSeason: { integrity: 2, popularity: 2 }, effect: "Legacy and popularity every season you keep paying" },
  { id: "give_food_bank", name: "Fund The Food Bank Down Your Road", emoji: "\u{1F96B}", category: "family", cost: 0, monthlyCost: 0.08, description: "The one you walked past every day as a kid, \u20AC80k/yr", oneTime: true, perSeason: { integrity: 2, morale: 1 }, effect: "Legacy credit and it helps you sleep" },
  { id: "give_ward", name: "A Children's Ward, Not Named After You", emoji: "\u{1F3E5}", category: "family", cost: 8, description: "You asked them to leave your name off it, \u20AC8M", oneTime: true, minNetWorth: 12, popularityBoost: 6, perSeason: { integrity: 3 }, effect: "+6 Popularity now, big legacy credit every season" },
  { id: "biz_five_a_side", name: "Five A Side Place Back Home", emoji: "\u{1F945}", category: "investment", cost: 1.5, description: "Four pitches and a bad vending machine, \u20AC1.5M", oneTime: true, minNetWorth: 2, perSeason: { morale: 1, integrity: 1 }, effect: "A business you actually visit. +1 Morale a season" }
];
function getSpendingItem(id) {
  return SPENDING_ITEMS.find((i) => i.id === id);
}
var SOCCER_INBOX = {
  pool: PHONE_POOL,
  moodOf: (s) => s.karma ?? 50,
  setMood: (s, v) => {
    s.karma = v;
  },
  addPopularity: (s, delta) => {
    s.popularity = clamp7(s.popularity + delta, 0, 100);
  },
  addCash: (s, amount) => {
    s.netWorth = Math.round((s.netWorth + amount) * 100) / 100;
  },
  ageOf: (s) => s.age,
  yearOf: (s) => s.seasons[s.seasons.length - 1]?.year ?? 2020,
  maxInbox: 6,
  wantPerSeason: 2
};
function receivePhoneTexts(s, phase) {
  const fresh = receiveInboxTexts(s, phase, SOCCER_INBOX);
  for (const m of fresh) mirrorLegacyMessage(s, m.id, m.from, m.text, m.year);
  phoneSeasonTick(s, phase);
}
var SOCCER_RIVALRY_CHOICES = [
  {
    id: "rival_club_offer",
    emoji: "\u{1F4DE}",
    title: "THE ENEMY CALLS",
    description: "Your great rival's club triggers your release clause. Their sporting director says one sentence: come win everything next to him instead of against him. Your fans are already burning shirts preemptively.",
    when: (s) => s.age >= 24,
    choices: [
      {
        label: "Join forces with your rival",
        emoji: "\u{1F91D}",
        consequence: "The most talked-about transfer of the decade. Signing bonus 10M, old fans furious",
        apply: (s, r) => {
          s.netWorth = Math.round((s.netWorth + 10) * 100) / 100;
          s.popularity = clamp7(s.popularity - 10, 0, 100);
          s.morale = clamp7(s.morale + 5, 0, 100);
          s.rivalryIntensity = clamp7((s.rivalryIntensity ?? 0) - 30, 0, 100);
          return `\u{1F4DE} You answered the enemy's call. 10M signing bonus banked, and the football world lost its mind. Old fans are furious, ${r?.name ?? "your rival"} posted a handshake emoji.`;
        }
      },
      {
        label: "Leak the offer and refuse",
        emoji: "\u{1F4F0}",
        consequence: "Your fans crown you a legend of loyalty. Popularity +12, integrity +5",
        apply: (s) => {
          s.popularity = clamp7(s.popularity + 12, 0, 100);
          s.integrityBonus += 5;
          s.rivalryIntensity = clamp7((s.rivalryIntensity ?? 0) + 10, 0, 100);
          return "\u{1F4F0} The leaked offer made the front page. Your fans crowned you a legend of loyalty. Popularity +12.";
        }
      },
      {
        label: "Refuse quietly",
        emoji: "\u{1F910}",
        consequence: "Nobody ever knows how close it came",
        apply: () => "\u{1F910} You refused quietly. Somewhere in a drawer sits the most explosive transfer that never happened."
      }
    ]
  },
  {
    id: "rival_bad_tackle",
    emoji: "\u{1F9B5}",
    title: "THE TACKLE",
    description: "Your rival went through your ankle in the derby, studs up, no ball. The referee gave a yellow. Your physio says you are fine. Your teammates want blood. The rematch is in May.",
    when: () => true,
    choices: [
      {
        label: "Plot revenge for the rematch",
        emoji: "\u{1F608}",
        consequence: "The feud goes nuclear",
        risk: "30% chance you see red doing it: popularity and morale -5",
        apply: (s, r, rng) => {
          s.rivalryIntensity = clamp7((s.rivalryIntensity ?? 0) + 25, 0, 100);
          if (rng() < 0.3) {
            s.popularity = clamp7(s.popularity - 5, 0, 100);
            s.morale = clamp7(s.morale - 5, 0, 100);
            return `\u{1F7E5} Revenge tasted sweet for four seconds, then the red card came out. Popularity and morale -5, and ${r?.name ?? "your rival"} smiled the whole time.`;
          }
          s.morale = clamp7(s.morale + 8, 0, 100);
          return `\u{1F608} You got him back, clean enough to escape a card. The derby now has its own documentary crew.`;
        }
      },
      {
        label: "Accept his apology publicly",
        emoji: "\u{1F54A}\uFE0F",
        consequence: "Integrity +8, popularity +5, the feud cools",
        apply: (s) => {
          s.integrityBonus += 8;
          s.popularity = clamp7(s.popularity + 5, 0, 100);
          s.rivalryIntensity = clamp7((s.rivalryIntensity ?? 0) - 15, 0, 100);
          return "\u{1F54A}\uFE0F You accepted the apology on camera. The adults in the room won today. Integrity +8.";
        }
      },
      {
        label: "Say nothing. Score twice in May.",
        emoji: "\u{1F976}",
        consequence: "+1 Shooting next season, ice in the veins",
        apply: (s) => {
          s.statBoostNextSeason = { ...s.statBoostNextSeason, shooting: (s.statBoostNextSeason.shooting || 0) + 1 };
          s.rivalryIntensity = clamp7((s.rivalryIntensity ?? 0) + 10, 0, 100);
          return "\u{1F976} You said nothing. May is circled on your calendar in red ink. +1 Shooting next season.";
        }
      }
    ]
  },
  {
    id: "goat_debate_show",
    emoji: "\u{1F3A4}",
    title: "THE DEBATE SHOW",
    description: "A global sports network offers 2M for one live hour: you versus a panel of pundits arguing that your rival is better. No script, no edits, one microphone.",
    when: (s) => s.overall >= 85,
    choices: [
      {
        label: "Go on and cook them",
        emoji: "\u{1F525}",
        consequence: "2M fee",
        risk: "35% chance a clip goes viral badly: popularity -8",
        apply: (s, _r, rng) => {
          s.netWorth = Math.round((s.netWorth + 2) * 100) / 100;
          if (rng() < 0.35) {
            s.popularity = clamp7(s.popularity - 8, 0, 100);
            return "\u{1F3A4} You went on the debate show and one heated clip went viral for the wrong reasons. 2M banked, popularity -8.";
          }
          s.popularity = clamp7(s.popularity + 6, 0, 100);
          return "\u{1F525} You cooked the whole panel live on air. 2M banked and the clip is a permanent argument-ender. Popularity +6.";
        }
      },
      {
        label: "Send a highlight reel instead",
        emoji: "\u{1F4FC}",
        consequence: "The reel does the talking. Popularity +8",
        apply: (s) => {
          s.popularity = clamp7(s.popularity + 8, 0, 100);
          return "\u{1F4FC} You sent a four-minute highlight reel with no caption. It out-rated the show. Popularity +8.";
        }
      },
      {
        label: "Decline. Legends do not debate.",
        emoji: "\u{1F60E}",
        consequence: "Integrity +5, the mystique grows",
        apply: (s) => {
          s.integrityBonus += 5;
          return "\u{1F60E} You declined. Legends do not debate. The mystique compounds like interest.";
        }
      }
    ]
  },
  {
    id: "rival_charity_match",
    emoji: "\u{1F49B}",
    title: "TRUCE FOR ONE NIGHT",
    description: "Your rival's foundation asks you to co-headline a charity match for children's hospitals. Same pitch, same team, one night only. The photo of you two in the same shirt would break the internet.",
    when: () => true,
    choices: [
      {
        label: "Play, and split the donation",
        emoji: "\u{1F91D}",
        consequence: "1M donated, popularity +10, integrity +8, the feud softens",
        apply: (s, r) => {
          s.netWorth = Math.round((s.netWorth - 1) * 100) / 100;
          s.popularity = clamp7(s.popularity + 10, 0, 100);
          s.integrityBonus += 8;
          s.rivalryIntensity = clamp7((s.rivalryIntensity ?? 0) - 20, 0, 100);
          return `\u{1F49B} One night, one shirt, one cause. You and ${r?.name ?? "your rival"} raised millions for children's hospitals. The feud took the night off.`;
        }
      },
      {
        label: "Play, but start a playful nutmeg war",
        emoji: "\u{1F609}",
        consequence: "The clips are legendary. Popularity +12",
        apply: (s, r) => {
          s.popularity = clamp7(s.popularity + 12, 0, 100);
          return `\u{1F609} The charity match turned into a nutmeg war with ${r?.name ?? "your rival"}. The kids loved it, the internet melted. Popularity +12.`;
        }
      },
      {
        label: "Send a check, skip the match",
        emoji: "\u{1F4B8}",
        consequence: "1M donated quietly, integrity +3",
        apply: (s) => {
          s.netWorth = Math.round((s.netWorth - 1) * 100) / 100;
          s.integrityBonus += 3;
          return "\u{1F4B8} You sent the donation and skipped the cameras. The quiet kind of good. Integrity +3.";
        }
      }
    ]
  }
];
function rivalChoiceDilemma(id) {
  const d = SOCCER_RIVALRY_CHOICES.find((c) => c.id === id);
  return {
    id: d.id,
    emoji: d.emoji,
    title: d.title,
    description: typeof d.description === "string" ? d.description : "",
    choices: d.choices.map((c) => c.risk === void 0 ? { label: c.label, emoji: c.emoji, consequence: c.consequence } : { label: c.label, emoji: c.emoji, consequence: c.consequence, risk: c.risk })
  };
}
var MORAL_DILEMMAS = [
  {
    id: "match_fixing",
    emoji: "\u{1F3B0}",
    title: "MATCH FIXING",
    description: "A mysterious figure approaches you before a big match. He offers \u20AC5M to intentionally perform poorly. The money would be untraceable. No one would ever know... probably.",
    choices: [
      { label: "Accept the money", emoji: "\u{1F4B0}", consequence: "\u20AC5M added to your accounts", risk: "30% chance you are caught: banned for a season and the 5M taken back" },
      { label: "Refuse and report it", emoji: "\u{1F6E1}\uFE0F", consequence: "Reputation +20, Legacy +10, Fair Play Award" },
      { label: "Refuse silently", emoji: "\u{1F910}", consequence: "Walk away. Nothing happens." }
    ]
  },
  {
    id: "ped_offer",
    emoji: "\u{1F489}",
    title: "PERFORMANCE ENHANCING DRUGS",
    description: `A private trainer you met over the summer, nobody from your club, gets you alone after a session. He offers you an 'undetectable' substance that will boost all your stats by +5 for 3 seasons. "Nobody ever has to know," he whispers.`,
    choices: [
      { label: "Take the substance", emoji: "\u{1F48A}", consequence: "All stats +5 for 3 seasons", risk: "20% chance of a failed test each season: banned for a season" },
      { label: "Refuse", emoji: "\u270B", consequence: "Morale -5, but integrity +10 legacy bonus at retirement" }
    ]
  },
  {
    id: "diving_reputation",
    emoji: "\u{1F93F}",
    title: "DIVING REPUTATION",
    description: "You've developed a reputation for simulation. Journalists are running front-page stories about your theatrical falls in the box. Pundits are calling you 'the greatest actor in football.'",
    choices: [
      { label: "Embrace the dark arts", emoji: "\u{1F3AD}", consequence: "+2 goals per season from penalties, but reputation -15" },
      { label: "Clean up your game", emoji: "\u{1F91D}", consequence: "Reputation +10, integrity +5" },
      { label: "Ignore the noise", emoji: "\u{1F507}", consequence: "No change, let them talk" }
    ]
  },
  {
    id: "agent_corruption",
    emoji: "\u{1F574}\uFE0F",
    title: "AGENT CORRUPTION",
    description: "Your accountant finds your agent has been skimming double the agreed commission for the last 3 years. That is real money stolen from you, and your agent is sitting in your living room, sweating.",
    choices: [
      { label: "Fire your agent and sue", emoji: "\u2696\uFE0F", consequence: "Legal costs \u20AC500k, the stolen money back (up to \u20AC3M), and you negotiate your own deals from now on" },
      { label: "Keep your agent: the results are real", emoji: "\u{1F91D}", consequence: "Swallow the loss, morale -5" },
      { label: "Make them pay some of it back", emoji: "\u{1F4DD}", consequence: "Your agent stays, about a third of the money comes back" }
    ]
  },
  {
    id: "pitch_invader",
    emoji: "\u{1F3C3}",
    title: "PITCH INVADER",
    description: "Mid-match, a fan hops the barrier and sprints straight at you, phone out, screaming your name. Stewards are way behind. He's five yards away and closing.",
    choices: [
      { label: "Pose for the selfie", emoji: "\u{1F933}", consequence: "Popularity +10, but you concede possession and the crowd loves it" },
      { label: "Juke him like a defender", emoji: "\u{1F57A}", consequence: "Viral clip! Popularity +15, morale +5" },
      { label: "Push him away hard", emoji: "\u270B", consequence: "Crowd boos, popularity -10, but stewards praise your composure" }
    ]
  },
  {
    id: "match_fixer_approach",
    emoji: "\u{1F3AD}",
    title: "THE HOTEL BAR",
    description: 'A smooth operator finds you at a hotel bar the night before a meaningless end-of-season game. "Nobody cares about this one. Just miss a penalty if you get one. \u20AC2M, cash, tonight."',
    choices: [
      { label: "Take the deal", emoji: "\u{1F4B5}", consequence: "\u20AC2M added instantly", risk: "25% chance a recording leaks: banned for a season and the 2M taken back" },
      { label: "Film him and expose it", emoji: "\u{1F3A5}", consequence: "Hero status! Popularity +25, Fair Play recognition" },
      { label: "Politely decline, tell no one", emoji: "\u{1F6AA}", consequence: "Walk away clean. Nothing happens." }
    ]
  },
  {
    id: "captain_armband_feud",
    emoji: "\xA9\uFE0F",
    title: "THE ARMBAND WAR",
    description: "The manager is stripping the captaincy from a veteran teammate and offering it to you. The dressing room is split. The veteran hasn't spoken to you in three days.",
    choices: [
      { label: "Accept the armband", emoji: "\u{1F396}\uFE0F", consequence: "Popularity +10 with fans, morale -8 with a chunk of the squad" },
      { label: "Refuse out of respect", emoji: "\u{1F64F}", consequence: "Dressing room loyalty +, missed leadership bonus" },
      { label: "Broker peace between camps", emoji: "\u{1F54A}\uFE0F", consequence: "Morale +10 long term, no armband this season" }
    ]
  },
  {
    id: "tunnel_brawl",
    emoji: "\u{1F94A}",
    title: "TUNNEL INCIDENT",
    description: "After a brutal loss, an opposition player shoves you in the tunnel and says something about your family. Cameras are everywhere. Your teammates are already grabbing your shirt to hold you back.",
    choices: [
      { label: "Swing back", emoji: "\u{1F44A}", consequence: "Fined two weeks' wages, popularity -10 (your ultras loved it, nobody else did)" },
      { label: "Walk away, report it", emoji: "\u{1F6B6}", consequence: "Federation fines the other player, your reputation +15" },
      { label: "Trash talk, no contact", emoji: "\u{1F5E3}\uFE0F", consequence: "Fined a week's wages, the clip goes viral either way" }
    ]
  },
  {
    id: "sponsor_scandal",
    emoji: "\u{1F4F8}",
    title: "SPONSOR MELTDOWN",
    description: "Your energy drink sponsor just got exposed in a tax fraud scandal. Journalists are calling your phone nonstop asking if you'll cut ties with a \u20AC3M-a-year deal.",
    choices: [
      { label: "Cut ties publicly", emoji: "\u2702\uFE0F", consequence: "Lose \u20AC3M/year income, popularity +15" },
      { label: "Stay quiet, keep the money", emoji: "\u{1F910}", consequence: "Keep the deal, popularity -10 as backlash builds" },
      { label: "Donate the year's fee to charity", emoji: "\u2764\uFE0F", consequence: "Keep the deal, popularity +20, net worth unchanged this year" }
    ]
  },
  {
    id: "betting_ring_teammate",
    emoji: "\u{1F3B2}",
    title: "AN OLD FRIEND IN TROUBLE",
    description: "Your best mate from the academy, now playing a division below, confesses he owes a betting syndicate a huge sum and they've started asking him about your injury news. He's begging you not to tell anyone.",
    choices: [
      { label: "Report it to the federation", emoji: "\u{1F4E2}", consequence: "He gets suspended, integrity +15, morale -5 (you lost a friend)" },
      { label: "Lend him the money quietly", emoji: "\u{1F4B6}", consequence: "Net worth -1.5M, loyalty earned, risk buried" },
      { label: "Tell him to fix it himself", emoji: "\u{1F937}", consequence: "Nothing happens. You hope it stays that way" }
    ]
  },
  {
    id: "wonderkid_jealousy",
    emoji: "\u{1F31F}",
    title: "THE NEW WONDERKID",
    description: "The club just paid a fortune for a hyped 18-year-old who plays your exact position. The manager is clearly grooming him to replace you. He's also incredibly likeable, which makes it worse.",
    choices: [
      { label: "Mentor him openly", emoji: "\u{1F91D}", consequence: "Popularity +15, and the kid never forgets it" },
      { label: "Freeze him out", emoji: "\u{1F9CA}", consequence: "Morale -10, the dressing room turns cold on you" },
      { label: "Focus on yourself, ignore it", emoji: "\u{1F3AF}", consequence: "No change, business as usual" }
    ]
  },
  {
    id: "night_out_photo",
    emoji: "\u{1F37E}",
    title: "THE NIGHT OUT PHOTO",
    description: "A photo leaks of you out until 4am, three days before a huge cup final. It is blowing up online. Training is in six hours and the manager wants to see you immediately.",
    choices: [
      { label: "Own it, apologize publicly", emoji: "\u{1F647}", consequence: "Popularity +5 for honesty, morale -5, fined one week's wages" },
      { label: "Deny everything", emoji: "\u{1F645}", consequence: "Story drags on", risk: "35% chance it resurfaces: popularity -15" },
      { label: "Let your agent spin it", emoji: "\u{1F399}\uFE0F", consequence: "Story dies down fast, small net worth cost for the PR team" }
    ]
  },
  // 2026-08-05 storyline expansion (owner request: mafia arc, magazine offer, pitch chaos, more)
  {
    id: "magazine_shoot",
    emoji: "\u{1F4F8}",
    title: "THE MAGAZINE CALL",
    description: "A famous magazine wants you on the cover. The tasteful version pays well. The bold version, shirt off with a football under your arm, pays absurdly. Your agent is already laughing.",
    choices: [
      { label: "Tasteful calendar shoot", emoji: "\u{1F60E}", consequence: "2M fee, popularity +10" },
      { label: "The full artistic cover", emoji: "\u{1F648}", consequence: "6M fee, popularity +18", risk: "25% chance a sponsor drops you for 2M" },
      { label: "Decline politely", emoji: "\u{1F6AA}", consequence: "Nothing happens. Your grandmother approves." }
    ]
  },
  {
    id: "mafia_cup_ask",
    emoji: "\u{1F574}\uFE0F",
    title: "AN OFFER FROM SERIOUS PEOPLE",
    description: "Two men in beautiful suits find you at a family restaurant. They know your order. They want next month's cup tie thrown. 8M, offshore, untouchable. A small favor between friends, they say.",
    choices: [
      { label: "Take the money", emoji: "\u{1F4B0}", consequence: "8M offshore, morale -5. They now consider you a friend.", risk: "They ALWAYS come back" },
      { label: "Refuse and go to the police", emoji: "\u{1F694}", consequence: "Federation protection, popularity +20, integrity +15" },
      { label: "Refuse, say nothing", emoji: "\u{1F910}", consequence: "They nod and leave. You sleep badly for a week." }
    ]
  },
  {
    id: "mafia_second_ask",
    emoji: "\u{1F3A9}",
    title: "THE FRIENDS RETURN",
    description: "Same restaurant. Same suits. This time it is the title decider they want, and the number is 15M. The smile is thinner now. Friends help friends twice, they say.",
    choices: [
      { label: "Do it one last time", emoji: "\u{1F4B6}", consequence: "15M offshore", risk: "50% chance the investigation lands: banned for two seasons, legacy shattered" },
      { label: "Refuse them", emoji: "\u270B", consequence: "Morale -10, and they mention the first favor on the way out", risk: "40% chance the first fix leaks: banned for a season" },
      { label: "Go to the police, full confession", emoji: "\u{1F694}", consequence: "Immunity for testimony, popularity +25, integrity +10, the arc ends" }
    ]
  },
  {
    id: "streaker_proposal",
    emoji: "\u{1F48D}",
    title: "PITCH SIDE PROPOSAL",
    description: "A fan in a full wedding dress clears the hoardings, drops to one knee in the center circle, and holds up a ring the size of a grape. The stadium is HOWLING. The referee has given up.",
    choices: [
      { label: "Say yes as a joke", emoji: "\u{1F48D}", consequence: "The clip breaks the internet. Popularity +15" },
      { label: "Sign her sign, keep it moving", emoji: "\u{1F58A}\uFE0F", consequence: "Wholesome moment, popularity +8" },
      { label: "Play on, total professional", emoji: "\u26BD", consequence: "Pundits praise the focus, morale +3" }
    ]
  },
  {
    id: "deepfake_scandal",
    emoji: "\u{1F916}",
    title: "THE DEEPFAKE",
    description: "An AI video of you insulting your own fans is everywhere. It is fake, it is convincing, and your mentions are a war zone. The club wants a response within the hour.",
    choices: [
      { label: "Sue everyone involved", emoji: "\u2696\uFE0F", consequence: "1M legal costs, vindicated in court, popularity +15" },
      { label: "Post a parody of the parody", emoji: "\u{1F3AD}", consequence: "Popularity +20 if it lands", risk: "20% chance it reads wrong and costs 10 popularity" },
      { label: "Ignore it entirely", emoji: "\u{1F9D8}", consequence: "It burns out in a week. Small morale dip." }
    ]
  },
  {
    id: "hometown_statue",
    emoji: "\u{1F5FF}",
    title: "THE STATUE PROBLEM",
    description: "Your hometown commissioned a statue of you. The unveiling photos leak early. It looks like a melted action figure of someone else entirely. The sculptor is very proud.",
    choices: [
      { label: "Quietly fund a redo", emoji: "\u{1F4B6}", consequence: "2M cost, the new one is beautiful, popularity +12" },
      { label: "Embrace the meme statue", emoji: "\u{1F5FF}", consequence: "It becomes a pilgrimage site. Popularity +18" },
      { label: "Ask them to take it down", emoji: "\u{1F645}", consequence: "The town is hurt. Popularity -5" }
    ]
  },
  {
    id: "haunted_hotel",
    emoji: "\u{1F47B}",
    title: "THE HAUNTED HOTEL",
    description: "Night before the biggest match of the season, half the squad swears the team hotel is haunted. Two defenders are refusing to sleep alone. The manager is furious. Somebody has to lead here.",
    choices: [
      { label: "Lead a squad seance", emoji: "\u{1F56F}\uFE0F", consequence: "Team bonding of the strangest kind. Morale +8" },
      { label: "Demand a hotel change", emoji: "\u{1F3E8}", consequence: "Awkward with the club, but everyone sleeps. Morale +3" },
      { label: "Sleep in the team bus", emoji: "\u{1F68C}", consequence: "The photo goes viral. Popularity +10" }
    ]
  },
  {
    id: "valet_crash",
    emoji: "\u{1F511}",
    title: "THE VALET INCIDENT",
    description: "A hotel valet just reversed your hypercar into a fountain at 40 km/h. He is 19, shaking, and pretty sure his life is over. Forty phones are already filming.",
    choices: [
      { label: "Hug him, forgive publicly", emoji: "\u{1F917}", consequence: "The clip melts hearts. Popularity +12, the car costs 1.5M" },
      { label: "Insurance war", emoji: "\u{1F4CB}", consequence: "Insurance covers the 1.5M, popularity -8, he loses his job" },
      { label: "Gift him a bus pass and a smile", emoji: "\u{1F68C}", consequence: "Perfect comedy. Popularity +15, the car still costs 1.5M" }
    ]
  },
  {
    id: "wag_reality_show",
    emoji: "\u{1F4FA}",
    title: "THE REALITY SHOW",
    description: "A production company offers serious money to film a reality series inside your house. Your partner is excited. Your center back already texted: do NOT do this.",
    choices: [
      { label: "Full season, full access", emoji: "\u{1F3AC}", consequence: "3M fee, popularity +8", risk: "25% chance a dressing-room secret airs: morale -10" },
      { label: "One tasteful episode", emoji: "\u{1F39E}\uFE0F", consequence: "1M fee, everyone survives" },
      { label: "Hard no", emoji: "\u{1F6AA}", consequence: "Partner sulks for a week, morale +4 long term" }
    ]
  },
  {
    id: "ultras_tattoo",
    emoji: "\u{1F409}",
    title: "THE ULTRAS' DEMAND",
    description: "After your late winner, the ultras unfurl a banner: TATTOO THE CREST OR YOU NEVER LOVED US. They are outside training with a tattoo artist. He seems extremely available.",
    choices: [
      { label: "Get the crest tattooed", emoji: "\u{1F409}", consequence: "Popularity +15 here forever. Awkward if you ever transfer" },
      { label: "Henna prank first", emoji: "\u{1F58C}\uFE0F", consequence: "Popularity +8 for the joke", risk: "30% chance they find out it washed off: -10" },
      { label: "Respectfully decline", emoji: "\u{1F64F}", consequence: "Popularity -5, your skin remains yours" }
    ]
  },
  {
    id: "bdor_snub",
    emoji: "\u{1F948}",
    title: "THE SNUB",
    description: "Everyone in your camp thought this was your Ballon d'Or. It went to someone else. The cameras cut to your face at the exact wrong moment and the whole world saw it.",
    choices: [
      { label: "Fuel. Pure fuel.", emoji: "\u{1F525}", consequence: "+3 to every stat next season, morale -5. Revenge tour begins" },
      { label: "Congratulate the winner beautifully", emoji: "\u{1F91D}", consequence: "Popularity +10, integrity +5, the high road" },
      { label: "Skip the afterparty, train at midnight", emoji: "\u{1F319}", consequence: "The gym photo goes viral. +2 stats next season, popularity +5" }
    ]
  },
  {
    id: "biscuit_gate",
    emoji: "\u{1F36A}",
    title: "BISCUIT GATE",
    description: "You were photographed enjoying a rival brand's biscuit while your cereal sponsor pays you millions. The internet has named it Biscuit Gate. The sponsor's lawyers have named it a breach.",
    choices: [
      { label: "Apologize with a taste test video", emoji: "\u{1F3A5}", consequence: "Sponsor placated, the video hits huge, popularity +10" },
      { label: "Declare biscuit independence", emoji: "\u{1F36A}", consequence: "Lose 1M sponsor fee, popularity +15, folk hero status" },
      { label: "Blame a lookalike", emoji: "\u{1F978}", consequence: "Nobody believes you, popularity -5, it becomes a meme" }
    ]
  },
  // 2026-08-05 rivalry expansion: the feud gets interactive. Round 796: the
  // four live in SOCCER_RIVALRY_CHOICES above and are drawn from there, in
  // the same four places in this list.
  rivalChoiceDilemma("rival_club_offer"),
  rivalChoiceDilemma("rival_bad_tackle"),
  rivalChoiceDilemma("goat_debate_show"),
  rivalChoiceDilemma("rival_charity_match")
];
function yearOutRow(s, reason) {
  const last = s.seasons[s.seasons.length - 1];
  return {
    year: (last ? last.year : 2019) + 1,
    age: s.age,
    club: reason ?? s.currentClub,
    clubCountry: reason ? "" : s.currentClubCountry,
    clubTier: reason ? 99 : s.currentClubTier,
    apps: 0,
    goals: 0,
    assists: 0,
    cleanSheets: 0,
    yellowCards: 0,
    redCards: 0,
    rating: 0,
    leagueTitle: false,
    domesticCup: false,
    championsLeague: false,
    worldCup: false,
    ballonDor: false,
    ballonDorRank: null,
    type: "playing",
    intApps: 0,
    intGoals: 0,
    intAssists: 0,
    intRating: 0,
    tournament: null,
    tournamentResult: null
  };
}
var FLAG_MAP = {
  "England": "\u{1F3F4}\u{E0067}\u{E0062}\u{E0065}\u{E006E}\u{E0067}\u{E007F}",
  "Spain": "\u{1F1EA}\u{1F1F8}",
  "France": "\u{1F1EB}\u{1F1F7}",
  "Germany": "\u{1F1E9}\u{1F1EA}",
  "Brazil": "\u{1F1E7}\u{1F1F7}",
  "Argentina": "\u{1F1E6}\u{1F1F7}",
  "Portugal": "\u{1F1F5}\u{1F1F9}",
  "Italy": "\u{1F1EE}\u{1F1F9}",
  "Netherlands": "\u{1F1F3}\u{1F1F1}",
  "USA": "\u{1F1FA}\u{1F1F8}",
  "Mexico": "\u{1F1F2}\u{1F1FD}",
  "Japan": "\u{1F1EF}\u{1F1F5}",
  "South Korea": "\u{1F1F0}\u{1F1F7}",
  "Nigeria": "\u{1F1F3}\u{1F1EC}",
  "Senegal": "\u{1F1F8}\u{1F1F3}",
  "Ghana": "\u{1F1EC}\u{1F1ED}",
  "Morocco": "\u{1F1F2}\u{1F1E6}",
  "Colombia": "\u{1F1E8}\u{1F1F4}",
  "Uruguay": "\u{1F1FA}\u{1F1FE}",
  "Belgium": "\u{1F1E7}\u{1F1EA}",
  "Croatia": "\u{1F1ED}\u{1F1F7}",
  "Denmark": "\u{1F1E9}\u{1F1F0}",
  "Sweden": "\u{1F1F8}\u{1F1EA}",
  "Norway": "\u{1F1F3}\u{1F1F4}",
  "Switzerland": "\u{1F1E8}\u{1F1ED}",
  "Austria": "\u{1F1E6}\u{1F1F9}",
  "Scotland": "\u{1F3F4}\u{E0067}\u{E0062}\u{E0073}\u{E0063}\u{E0074}\u{E007F}",
  "Wales": "\u{1F3F4}\u{E0067}\u{E0062}\u{E0077}\u{E006C}\u{E0073}\u{E007F}",
  "Ireland": "\u{1F1EE}\u{1F1EA}",
  "Poland": "\u{1F1F5}\u{1F1F1}",
  "Czech Republic": "\u{1F1E8}\u{1F1FF}",
  "Serbia": "\u{1F1F7}\u{1F1F8}",
  "Romania": "\u{1F1F7}\u{1F1F4}",
  "Greece": "\u{1F1EC}\u{1F1F7}",
  "Turkey": "\u{1F1F9}\u{1F1F7}",
  "Russia": "\u{1F1F7}\u{1F1FA}",
  "Ukraine": "\u{1F1FA}\u{1F1E6}",
  "Australia": "\u{1F1E6}\u{1F1FA}",
  "New Zealand": "\u{1F1F3}\u{1F1FF}",
  "Canada": "\u{1F1E8}\u{1F1E6}",
  "Jamaica": "\u{1F1EF}\u{1F1F2}",
  "Costa Rica": "\u{1F1E8}\u{1F1F7}",
  "Ecuador": "\u{1F1EA}\u{1F1E8}",
  "Peru": "\u{1F1F5}\u{1F1EA}",
  "Chile": "\u{1F1E8}\u{1F1F1}",
  "Cameroon": "\u{1F1E8}\u{1F1F2}",
  "Ivory Coast": "\u{1F1E8}\u{1F1EE}",
  "Egypt": "\u{1F1EA}\u{1F1EC}",
  "Algeria": "\u{1F1E9}\u{1F1FF}",
  "Tunisia": "\u{1F1F9}\u{1F1F3}",
  // Round 54 expansion: more flags, more nations, more everything
  "Saudi Arabia": "\u{1F1F8}\u{1F1E6}",
  "Qatar": "\u{1F1F6}\u{1F1E6}",
  "UAE": "\u{1F1E6}\u{1F1EA}",
  "Iran": "\u{1F1EE}\u{1F1F7}",
  "Iraq": "\u{1F1EE}\u{1F1F6}",
  "Israel": "\u{1F1EE}\u{1F1F1}",
  "China": "\u{1F1E8}\u{1F1F3}",
  "India": "\u{1F1EE}\u{1F1F3}",
  "Indonesia": "\u{1F1EE}\u{1F1E9}",
  "Thailand": "\u{1F1F9}\u{1F1ED}",
  "Vietnam": "\u{1F1FB}\u{1F1F3}",
  "Malaysia": "\u{1F1F2}\u{1F1FE}",
  "Philippines": "\u{1F1F5}\u{1F1ED}",
  "Singapore": "\u{1F1F8}\u{1F1EC}",
  "Uzbekistan": "\u{1F1FA}\u{1F1FF}",
  "Kazakhstan": "\u{1F1F0}\u{1F1FF}",
  "Georgia": "\u{1F1EC}\u{1F1EA}",
  "Armenia": "\u{1F1E6}\u{1F1F2}",
  "Azerbaijan": "\u{1F1E6}\u{1F1FF}",
  "South Africa": "\u{1F1FF}\u{1F1E6}",
  "Kenya": "\u{1F1F0}\u{1F1EA}",
  "Ethiopia": "\u{1F1EA}\u{1F1F9}",
  "Tanzania": "\u{1F1F9}\u{1F1FF}",
  "Angola": "\u{1F1E6}\u{1F1F4}",
  "Mozambique": "\u{1F1F2}\u{1F1FF}",
  "DR Congo": "\u{1F1E8}\u{1F1E9}",
  "Mali": "\u{1F1F2}\u{1F1F1}",
  "Burkina Faso": "\u{1F1E7}\u{1F1EB}",
  "Guinea": "\u{1F1EC}\u{1F1F3}",
  "Gabon": "\u{1F1EC}\u{1F1E6}",
  "Zambia": "\u{1F1FF}\u{1F1F2}",
  "Zimbabwe": "\u{1F1FF}\u{1F1FC}",
  "Venezuela": "\u{1F1FB}\u{1F1EA}",
  "Bolivia": "\u{1F1E7}\u{1F1F4}",
  "Paraguay": "\u{1F1F5}\u{1F1FE}",
  "Panama": "\u{1F1F5}\u{1F1E6}",
  "Honduras": "\u{1F1ED}\u{1F1F3}",
  "El Salvador": "\u{1F1F8}\u{1F1FB}",
  "Guatemala": "\u{1F1EC}\u{1F1F9}",
  "Haiti": "\u{1F1ED}\u{1F1F9}",
  "Trinidad and Tobago": "\u{1F1F9}\u{1F1F9}",
  "Iceland": "\u{1F1EE}\u{1F1F8}",
  "Finland": "\u{1F1EB}\u{1F1EE}",
  "Slovakia": "\u{1F1F8}\u{1F1F0}",
  "Slovenia": "\u{1F1F8}\u{1F1EE}",
  "Hungary": "\u{1F1ED}\u{1F1FA}",
  "Bulgaria": "\u{1F1E7}\u{1F1EC}",
  "Albania": "\u{1F1E6}\u{1F1F1}",
  "Bosnia": "\u{1F1E7}\u{1F1E6}",
  "North Macedonia": "\u{1F1F2}\u{1F1F0}",
  "Montenegro": "\u{1F1F2}\u{1F1EA}",
  "Kosovo": "\u{1F1FD}\u{1F1F0}",
  "Cuba": "\u{1F1E8}\u{1F1FA}",
  "Dominican Republic": "\u{1F1E9}\u{1F1F4}",
  "Monaco": "\u{1F1F2}\u{1F1E8}",
  "Luxembourg": "\u{1F1F1}\u{1F1FA}",
  "Cyprus": "\u{1F1E8}\u{1F1FE}",
  "Malta": "\u{1F1F2}\u{1F1F9}",
  "Estonia": "\u{1F1EA}\u{1F1EA}",
  "Latvia": "\u{1F1F1}\u{1F1FB}",
  "Lithuania": "\u{1F1F1}\u{1F1F9}",
  "Moldova": "\u{1F1F2}\u{1F1E9}"
};
function getFlag(country) {
  return FLAG_MAP[country] || "\u{1F3F3}\uFE0F";
}
var rand2 = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
var clamp7 = (v, min, max) => Math.max(min, Math.min(max, v));
var pick2 = (arr) => arr[Math.floor(Math.random() * arr.length)];
var LEAGUE_DRAW_CAP = 5;
function leagueDrawGroups(candidates) {
  const groups = /* @__PURE__ */ new Map();
  for (const club of candidates) {
    const key = `${club.league}|${club.tier}`;
    const list2 = groups.get(key);
    if (list2) list2.push(club);
    else groups.set(key, [club]);
  }
  return [...groups].map(([key, clubs]) => ({ key, clubs, weight: Math.min(clubs.length, LEAGUE_DRAW_CAP) }));
}
function pickAcrossLeagues(candidates) {
  const groups = leagueDrawGroups(candidates);
  if (!groups.length) return candidates[0];
  let r = Math.random() * groups.reduce((s, g) => s + g.weight, 0);
  let chosen = groups[groups.length - 1];
  for (const g of groups) {
    if (r < g.weight) {
      chosen = g;
      break;
    }
    r -= g.weight;
  }
  return chosen.clubs[Math.floor(Math.random() * chosen.clubs.length)];
}
function getClubsByTier(clubs, tier) {
  return clubs.filter((c) => c.tier === tier);
}
function getYouthAcademyClub(clubs, nationality, overall) {
  const ovr = overall ?? 50;
  if (ovr >= 75) {
    const eliteFromHome = clubs.filter((c) => c.country === nationality && c.tier === 1 && ELITE_CLUBS.includes(c.name));
    if (eliteFromHome.length > 0) return pick2(eliteFromHome);
    const anyT1Home = clubs.filter((c) => c.country === nationality && c.tier === 1);
    if (anyT1Home.length > 0) return pick2(anyT1Home);
    const anyElite = clubs.filter((c) => ELITE_CLUBS.includes(c.name));
    if (anyElite.length > 0) return pick2(anyElite);
    return pickAcrossLeagues(getClubsByTier(clubs, 1));
  }
  if (ovr >= 66) {
    const homeTiers = clubs.filter((c) => c.country === nationality && (c.tier === 1 || c.tier === 2));
    if (homeTiers.length > 0) return pick2(homeTiers);
    const anyT1T2 = clubs.filter((c) => c.tier === 1 || c.tier === 2);
    if (anyT1T2.length > 0) return pickAcrossLeagues(anyT1T2);
    return pickAcrossLeagues(getClubsByTier(clubs, 2));
  }
  if (ovr >= 55) {
    const homeTiers = clubs.filter((c) => c.country === nationality && (c.tier === 2 || c.tier === 3));
    if (homeTiers.length > 0) return pick2(homeTiers);
    const anyT2T3 = clubs.filter((c) => c.tier === 2 || c.tier === 3);
    if (anyT2T3.length > 0) return pickAcrossLeagues(anyT2T3);
    return pickAcrossLeagues(getClubsByTier(clubs, 3));
  }
  if (ovr >= 40) {
    const homeClubs = clubs.filter((c) => c.country === nationality && c.tier >= 3);
    if (homeClubs.length > 0) return pick2(homeClubs);
    const anyT3T4 = clubs.filter((c) => c.tier >= 3);
    if (anyT3T4.length > 0) return pickAcrossLeagues(anyT3T4);
    return pickAcrossLeagues(getClubsByTier(clubs, 4));
  }
  const homeT4 = clubs.filter((c) => c.country === nationality && c.tier === 4);
  if (homeT4.length > 0) return pick2(homeT4);
  const t4 = getClubsByTier(clubs, 4);
  if (t4.length > 0) return pickAcrossLeagues(t4);
  return pickAcrossLeagues(getClubsByTier(clubs, 3));
}
function calcOverall(s, position) {
  if (position === "GK") {
    return Math.round(s.reflexes * 0.3 + s.defending * 0.2 + s.physical * 0.2 + s.pace * 0.1 + s.passing * 0.1 + s.dribbling * 0.05 + s.shooting * 0.05);
  }
  return Math.round((s.pace + s.shooting + s.passing + s.dribbling + s.defending + s.physical) / 6);
}
function rollPrimeType() {
  const r = Math.random();
  if (r < 0.25) return "early";
  if (r < 0.65) return "normal";
  if (r < 0.9) return "late";
  return "extended";
}
function isInPrime(age, primeType) {
  switch (primeType) {
    case "early":
      return age >= 22 && age <= 26;
    case "normal":
      return age >= 24 && age <= 28;
    case "late":
      return age >= 27 && age <= 31;
    case "extended":
      return age >= 23 && age <= 32;
  }
}
function isPastPrime(age, primeType) {
  switch (primeType) {
    case "early":
      return age > 26;
    case "normal":
      return age > 28;
    case "late":
      return age > 31;
    case "extended":
      return age > 32;
  }
}
function effectivePotential(s) {
  const base = Math.max(s.potential ?? Math.max(90, s.overall + 3), s.overall);
  const earned = Number(s.potentialEarned);
  return Math.min(99, base + (Number.isFinite(earned) ? Math.max(0, earned) : 0));
}
function careerBuildEffects(s) {
  try {
    return buildEffects(s, s.position, s.overall, s.physique, s.attrShape);
  } catch {
    return NEUTRAL_EFFECTS;
  }
}
var STORY_LINES_PER_SEASON = 40;
var STORY_SEASONS_MAX = 60;
function isStorySeason(v) {
  if (!v || typeof v !== "object" || Array.isArray(v)) return false;
  const e = v;
  return typeof e.year === "number" && Number.isFinite(e.year) && typeof e.age === "number" && Number.isFinite(e.age) && typeof e.club === "string" && Array.isArray(e.lines) && e.lines.every((l) => typeof l === "string") && (e.more === void 0 || typeof e.more === "number" && Number.isFinite(e.more) && e.more >= 0);
}
function cleanCareerStory(raw) {
  if (!Array.isArray(raw)) return [];
  const kept = raw.every(isStorySeason) ? raw : raw.filter(isStorySeason);
  return kept.length > STORY_SEASONS_MAX ? kept.slice(-STORY_SEASONS_MAX) : kept;
}
function archiveSeasonStory(s) {
  const story = cleanCareerStory(s.story);
  const lines = Array.isArray(s.events) ? s.events.filter((l) => typeof l === "string") : [];
  if (lines.length === 0) return story;
  const row = s.seasons.length > 0 ? s.seasons[s.seasons.length - 1] : null;
  const year = row ? row.year : 0;
  const age = row ? row.age : s.age;
  const club = row ? row.club : s.currentClub;
  const last = story.length > 0 ? story[story.length - 1] : null;
  const same = last !== null && last.year === year && last.age === age && last.club === club;
  const all = same ? [...last.lines, ...lines] : lines;
  const dropped = (same ? last.more ?? 0 : 0) + Math.max(0, all.length - STORY_LINES_PER_SEASON);
  const entry = { year, age, club, lines: all.slice(0, STORY_LINES_PER_SEASON) };
  if (dropped > 0) entry.more = dropped;
  const next = same ? [...story.slice(0, -1), entry] : [...story, entry];
  return next.length > STORY_SEASONS_MAX ? next.slice(-STORY_SEASONS_MAX) : next;
}
function repairCareer(state) {
  if (!state || typeof state !== "object") return state;
  const s = state;
  if (s.phase === "season_summary" && !s.pendingSummary) s.phase = "playing";
  if (!s.primeType) s.primeType = rollPrimeType();
  if (s.loan === void 0) s.loan = null;
  if (s.pendingLoanOffers === void 0) s.pendingLoanOffers = null;
  if (s.frozenOut === void 0) s.frozenOut = 0;
  if (s.badSeasonStreak === void 0) s.badSeasonStreak = 0;
  if (s.lastUCLResult && typeof s.lastUCLResult === "object") {
    const u = s.lastUCLResult;
    const badStage = u.firstStage !== void 0 && !isFirstStageResult(u.firstStage);
    const badName = u.competition !== void 0 && typeof u.competition !== "string";
    const badNote = u.simplified !== void 0 && typeof u.simplified !== "string";
    if (badStage || badName || badNote) {
      const fixed = { ...u };
      if (badStage) delete fixed.firstStage;
      if (badName) delete fixed.competition;
      if (badNote) delete fixed.simplified;
      s.lastUCLResult = fixed;
    }
  }
  if (Array.isArray(s.seasons) && s.seasons.some((x) => x && x.clubCupTitle !== void 0 && typeof x.clubCupTitle !== "string")) {
    s.seasons = s.seasons.map((x) => {
      if (!x || x.clubCupTitle === void 0 || typeof x.clubCupTitle === "string") return x;
      const { clubCupTitle: _dropped, ...rest } = x;
      return rest;
    });
  }
  if (Array.isArray(s.seasons) && s.seasons.some((x) => x && x.cupRun !== void 0 && !readCupRun(x))) {
    s.seasons = s.seasons.map((x) => {
      if (!x || x.cupRun === void 0 || readCupRun(x)) return x;
      const { cupRun: _dropped, ...rest } = x;
      return rest;
    });
  }
  if (s.seasonMoments !== void 0 && !readSeasonMoments(s.seasonMoments)) delete s.seasonMoments;
  s.story = cleanCareerStory(s.story);
  if ((s.isClubCaptain ?? false) && s.captainClub !== s.currentClub) {
    s.isClubCaptain = false;
    s.captainClub = null;
  }
  if (s.captainSeasons !== void 0 && (typeof s.captainSeasons !== "number" || !Number.isFinite(s.captainSeasons) || s.captainSeasons < 0)) {
    s.captainSeasons = 0;
  }
  const legacySponsor = s;
  if (legacySponsor.activeSponsorship === "fifa_cover") s.activeSponsorship = "cover_athlete";
  const legacyLifestyle = s;
  if (legacyLifestyle.lifestyleLevel === "Billionaire") s.lifestyleLevel = "Untouchable";
  if (s.eventLastFired !== void 0 && (typeof s.eventLastFired !== "object" || s.eventLastFired === null || Array.isArray(s.eventLastFired))) {
    delete s.eventLastFired;
  }
  const bonus = Number(s.sponsorBonus);
  s.sponsorBonus = Number.isFinite(bonus) ? clamp7(Math.round(bonus * 100) / 100, -20, 60) : 0;
  const legacyCover = s;
  if (legacyCover.fifaCoverAccepted === true) s.coverAthleteAccepted = true;
  if (legacyCover.pendingFifaCoverEvent === true) s.pendingCoverAthleteEvent = true;
  const earned = Number(s.potentialEarned);
  s.potentialEarned = Number.isFinite(earned) ? Math.max(0, Math.round(earned)) : 0;
  const streak = Number(s.eliteStreak);
  s.eliteStreak = Number.isFinite(streak) ? Math.max(0, Math.round(streak)) : 0;
  s.physique = safePhysique(s.position, s.physique);
  s.attrShape = safeShape(s.position, s.attrShape);
  const start = Number(s.startingOverall);
  if (Number.isFinite(start)) s.startingOverall = Math.round(clamp7(start, 1, 99));
  else delete s.startingOverall;
  if (typeof s.peakOverall !== "number" || !Number.isFinite(s.peakOverall)) s.peakOverall = s.overall;
  s.money = ensureMoney2(s);
  return state;
}
function developmentRate(s, justPlayed) {
  const pot = effectivePotential(s);
  const gap = pot - s.overall;
  const headroom = gap <= 0 ? 0.15 : gap <= 3 ? 0.5 : gap <= 8 ? 1 : gap <= 15 ? 1.5 : 1.9;
  let form = 1;
  const last = justPlayed ?? (s.seasons.length ? s.seasons[s.seasons.length - 1] : null);
  if (last && last.type !== "youth") {
    const apps = last.apps ?? 0;
    form *= apps >= 30 ? 1.25 : apps >= 18 ? 1 : apps >= 8 ? 0.78 : 0.5;
    const r = last.rating ?? 6.5;
    form *= r >= 7.6 ? 1.45 : r >= 7.1 ? 1.2 : r >= 6.6 ? 1 : r >= 6 ? 0.82 : 0.62;
  }
  const tierBase = s.currentClubTier === 1 ? 1.2 : s.currentClubTier === 2 ? 1.07 : 1;
  const lastApps = last && last.type !== "youth" ? last.apps ?? 0 : 25;
  const tierShare = lastApps >= 25 ? 1 : lastApps >= 12 ? 0.5 : 0.25;
  const tierF = 1 + (tierBase - 1) * tierShare;
  return clamp7(headroom * form * tierF, 0.1, 2.6);
}
function growStat(current, age, isYouth, isPace, primeType, potential = 99, currentOverall = 0, dev = 1) {
  let growth;
  if (isYouth) {
    growth = current >= 78 ? rand2(0, 1) : rand2(1, 3);
  } else if (isInPrime(age, primeType)) {
    growth = rand2(1, 3);
  } else if (!isPastPrime(age, primeType)) {
    growth = rand2(0, 2);
  } else {
    if (age >= 40) {
      growth = rand2(-7, -4);
    } else if (age >= 38) {
      growth = rand2(-6, -3);
    } else if (age >= 35) {
      growth = rand2(-5, -2);
    } else if (age >= 32) {
      growth = rand2(-3, -1);
    } else {
      const primeEnd = primeType === "early" ? 26 : primeType === "normal" ? 28 : primeType === "late" ? 31 : 32;
      const yearsPost = age - primeEnd;
      if (yearsPost <= 2) {
        growth = rand2(-2, 0);
      } else {
        growth = rand2(-3, -1);
      }
    }
  }
  if (growth > 0 && dev !== 1) {
    const scaled = growth * dev;
    growth = Math.floor(scaled) + (Math.random() < scaled % 1 ? 1 : 0);
  }
  if (growth > 0 && !isYouth) {
    if (current >= 94) growth = Math.random() < 0.2 ? 1 : 0;
    else if (current >= 90) growth = Math.random() < 0.45 ? 1 : 0;
    else if (current >= 86) growth = Math.min(growth, Math.random() < 0.5 ? 1 : 2);
  }
  if (growth > 0 && currentOverall > 0) {
    if (currentOverall >= potential) growth = Math.random() < 0.12 ? 1 : 0;
    else if (currentOverall >= potential - 3) growth = Math.min(growth, Math.random() < 0.55 ? 1 : 0);
  }
  if (isPace && age >= 28 && !isYouth) {
    growth -= 1;
    if (age >= 35) growth -= 1;
  }
  return clamp7(current + growth, 20, 99);
}
function clubAverageRating(tier) {
  switch (tier) {
    case 1:
      return 80;
    case 2:
      return 72;
    case 3:
      return 62;
    case 4:
      return 55;
    default:
      return 60;
  }
}
function calcMarketValue(overall, age, _position, _socialMediaFollowers) {
  let minVal, maxVal;
  if (overall >= 95) {
    if (age >= 20 && age <= 28) {
      minVal = 280;
      maxVal = 400;
    } else if (age >= 29 && age <= 31) {
      minVal = 180;
      maxVal = 280;
    } else if (age >= 32 && age <= 34) {
      minVal = 80;
      maxVal = 150;
    } else if (age >= 35) {
      minVal = 20;
      maxVal = 60;
    } else {
      minVal = 100;
      maxVal = 200;
    }
  } else if (overall >= 90) {
    if (age >= 20 && age <= 28) {
      minVal = 160;
      maxVal = 260;
    } else if (age >= 29 && age <= 31) {
      minVal = 100;
      maxVal = 180;
    } else if (age >= 32 && age <= 34) {
      minVal = 40;
      maxVal = 90;
    } else if (age >= 35) {
      minVal = 10;
      maxVal = 35;
    } else {
      minVal = 60;
      maxVal = 120;
    }
  } else if (overall >= 85) {
    if (age >= 20 && age <= 28) {
      minVal = 80;
      maxVal = 140;
    } else if (age >= 29 && age <= 31) {
      minVal = 50;
      maxVal = 100;
    } else if (age >= 32 && age <= 34) {
      minVal = 20;
      maxVal = 55;
    } else if (age >= 35) {
      minVal = 5;
      maxVal = 20;
    } else {
      minVal = 30;
      maxVal = 70;
    }
  } else if (overall >= 80) {
    if (age >= 20 && age <= 28) {
      minVal = 40;
      maxVal = 80;
    } else if (age >= 29 && age <= 31) {
      minVal = 25;
      maxVal = 55;
    } else if (age >= 32 && age <= 34) {
      minVal = 10;
      maxVal = 30;
    } else if (age >= 35) {
      minVal = 3;
      maxVal = 12;
    } else {
      minVal = 15;
      maxVal = 40;
    }
  } else if (overall >= 75) {
    if (age >= 20 && age <= 28) {
      minVal = 20;
      maxVal = 45;
    } else if (age >= 29 && age <= 31) {
      minVal = 10;
      maxVal = 25;
    } else if (age >= 32 && age <= 34) {
      minVal = 5;
      maxVal = 15;
    } else if (age >= 35) {
      minVal = 1;
      maxVal = 8;
    } else {
      minVal = 8;
      maxVal = 25;
    }
  } else if (overall >= 70) {
    if (age <= 28) {
      minVal = 8;
      maxVal = 25;
    } else if (age <= 31) {
      minVal = 4;
      maxVal = 14;
    } else {
      minVal = 1;
      maxVal = 6;
    }
  } else if (overall >= 65) {
    if (age <= 28) {
      minVal = 3;
      maxVal = 12;
    } else {
      minVal = 0.5;
      maxVal = 5;
    }
  } else {
    minVal = 0.1;
    maxVal = Math.max(0.5, overall * 0.05);
  }
  const value = minVal + Math.random() * (maxVal - minVal);
  return Math.max(0.1, Math.round(value * 10) / 10);
}
function calcLifestyleLevel(netWorth) {
  if (netWorth >= 500) return "Untouchable";
  if (netWorth >= 50) return "Superstar";
  if (netWorth >= 10) return "Wealthy";
  if (netWorth >= 2) return "Comfortable";
  return "Humble";
}
function calcLifestyleCost(level) {
  switch (level) {
    case "Untouchable":
      return 5;
    case "Superstar":
      return 2;
    case "Wealthy":
      return 0.8;
    case "Comfortable":
      return 0.2;
    case "Humble":
      return 0.05;
  }
}
function calcSponsorshipIncome(popularity2, socialMediaFollowers, sponsorDeal, activeSponsorship, bonus = 0) {
  let legacy = 0;
  if (sponsorDeal === "Nike" || sponsorDeal === "Vortex") legacy = 2;
  else if (sponsorDeal === "Adidas" || sponsorDeal === "Kinetiq") legacy = 1.5;
  return brandSeasonIncome({ standing: popularity2, followers: socialMediaFollowers, tier: activeSponsorship, bonus, legacy }, SOCCER_BRAND);
}
function growSocialMedia(state, season2) {
  return seasonFollowerGrowth(state, season2, SOCCER_FOLLOWER_GROWTH);
}
function simulateSeasonFinances(s, season2) {
  const wageIncome = s.weeklyWage * 52 / 1e6;
  s.sponsorshipIncome = Math.round(calcSponsorshipIncome(s.popularity, s.socialMediaFollowers, s.sponsorDeal, s.activeSponsorship, s.sponsorBonus ?? 0) * personalitySponsorMult(s.personality) * sponsorItemMult(s) * 100) / 100;
  const grossIncome = wageIncome + s.sponsorshipIncome;
  const agentCut = Math.round(grossIncome * agentIncomeCutRate(s.agentId) * 100) / 100;
  if (agentCut > 0) s.agentFeesPaid = Math.round((s.agentFeesPaid + agentCut) * 100) / 100;
  const totalIncome = grossIncome - agentCut;
  s.lifestyleLevel = calcLifestyleLevel(s.netWorth + (s.totalAssetValue || 0) + moneyWealth2(s));
  s.lifestyleCostPerYear = calcLifestyleCost(s.lifestyleLevel) + (s.customYearlyCosts || 0);
  const netThisYear = totalIncome - s.lifestyleCostPerYear;
  s.netWorth = Math.round((s.netWorth + netThisYear) * 100) / 100;
  s.totalEarnings = Math.round((s.totalEarnings + totalIncome) * 100) / 100;
  resolveInvestments(s);
  s.totalAssetValue = calcTotalAssets(s);
  const smGrowth = growSocialMedia(s, season2);
  s.socialMediaFollowers = Math.round((s.socialMediaFollowers + smGrowth) * 100) / 100;
  if (s.purchasedItems.includes("documentary_crew")) {
    s.popularity = clamp7(s.popularity + 3, 0, 100);
  }
  if (s.purchasedItems.includes("charity_foundation")) {
    s.popularity = clamp7(s.popularity + 3, 0, 100);
    s.integrityBonus += 2;
  }
  if (s.purchasedItems.includes("family_office") && s.netWorth > 0) {
    const growth = Math.round(s.netWorth * 0.02 * 100) / 100;
    s.netWorth = Math.round((s.netWorth + growth) * 100) / 100;
  }
  if (s.purchasedItems.includes("personal_chef")) {
    s.morale = clamp7(s.morale + 2, 0, 100);
  }
  applyPerSeasonItems(s);
  const moneyTick = moneySeasonTick2(s, season2.year);
  for (const line of moneyTick.events) s.events.push(line);
  if (netThisYear < 0) {
    s.consecutiveDeficitYears += 1;
  } else {
    s.consecutiveDeficitYears = 0;
  }
  if (s.consecutiveDeficitYears >= 3 || s.netWorth < -2) {
    s.events.push("\u{1F4B8} FINANCIAL CRISIS: Spending exceeds income! Forced to sell assets.");
    s.netWorth = Math.max(0, s.netWorth);
    s.lifestyleLevel = "Humble";
    s.lifestyleCostPerYear = 0.05;
    s.properties = [];
    const keep = (id) => getSpendingItem(id)?.category === "lifestyle";
    const soldUpkeep = s.purchasedItems.filter((id) => !keep(id)).reduce((sum, id) => sum + (getSpendingItem(id)?.monthlyCost || 0), 0);
    s.purchasedItems = s.purchasedItems.filter(keep);
    s.customYearlyCosts = Math.max(0, Math.round(((s.customYearlyCosts || 0) - soldUpkeep) * 1e3) / 1e3);
    s.totalAssetValue = 0;
    s.consecutiveDeficitYears = 0;
    s.morale = clamp7(s.morale - 20, 0, 100);
  }
  simulateFamilyLife(s);
}
function simulateFamilyLife(s) {
  if (s.hasRelationship && !s.family.isMarried && !s.family.isDivorced && s.age >= 22 && s.age <= 28 && Math.random() < 0.25) {
    s.family = { ...s.family, isMarried: true, marriedAge: s.age };
    s.morale = clamp7(s.morale + 5, 0, 100);
    s.events.push("\u{1F48D} Got married! Permanent morale boost.");
    s.netWorth -= 0.5;
  }
  if ((s.hasRelationship || s.family.isMarried) && !s.family.isDivorced && !s.pregnancyAnnounced && s.family.children < 3 && s.age >= 23 && s.age <= 30 && Math.random() < 0.2) {
    s.pregnancyAnnounced = true;
    s.morale = clamp7(s.morale + 5, 0, 100);
    s.events.push("\u{1F930} Your partner is pregnant. You are going to be a parent!");
    s.socialMediaFollowers += 0.3;
  } else if (s.pregnancyAnnounced) {
    s.pregnancyAnnounced = false;
    s.family = { ...s.family, children: s.family.children + 1 };
    s.morale = clamp7(s.morale + 10, 0, 100);
    s.socialMediaFollowers += 0.5;
    s.events.push(`\u{1F476} Your child is born. Congratulations! (${s.family.children} total) Morale +10, Legacy +5`);
    s.integrityBonus += 5;
  }
  if (s.family.children >= 1 && Math.random() < 0.2) {
    const childEvents = [
      { id: "first_steps", emoji: "\u{1F463}", text: "Your child's first steps! A moment you'll never forget.", morale: 3 },
      { id: "follow_footsteps", emoji: "\u26BD", text: "Your child wants to follow in your footsteps and become a footballer.", morale: 5 },
      { id: "watches_trophy", emoji: "\u{1F3C6}", text: "Your child watches you win a trophy, pure joy on their face!", morale: 8 }
    ];
    const available = childEvents.filter((e) => !s.childEventsSeen.includes(e.id));
    if (available.length > 0) {
      const ev = available[Math.floor(Math.random() * available.length)];
      s.childEventsSeen = [...s.childEventsSeen, ev.id];
      s.morale = clamp7(s.morale + ev.morale, 0, 100);
      s.events.push(`${ev.emoji} ${ev.text} Morale +${ev.morale}`);
    }
  }
  if (s.family.children >= 2 && Math.random() < 0.15 && !s.childEventsSeen.includes("juggling_family")) {
    s.childEventsSeen = [...s.childEventsSeen, "juggling_family"];
    s.morale = clamp7(s.morale + 3, 0, 100);
    s.events.push("\u{1F468}\u200D\u{1F469}\u200D\u{1F467}\u200D\u{1F466} Juggling family life and football is tough but rewarding. Morale +3");
  }
  if (s.family.isMarried && !s.family.isDivorced && s.morale < 40 && Math.random() < 0.15) {
    s.family = { ...s.family, isDivorced: true, isMarried: false, divorceAge: s.age };
    s.netWorth = Math.max(0, s.netWorth - 3);
    s.morale = clamp7(s.morale - 15, 0, 100);
    s.statBoostNextSeason = { ...s.statBoostNextSeason, shooting: (s.statBoostNextSeason.shooting || 0) - 2, dribbling: (s.statBoostNextSeason.dribbling || 0) - 2 };
    s.events.push("\u{1F494} Divorce! Settlement costs \u20AC3M. Performance dip next season.");
  }
}
function formatFollowers(m) {
  if (m >= 100) return `${m.toFixed(0)}M`;
  if (m >= 1) return `${m.toFixed(1)}M`;
  if (m >= 0.01) return `${Math.round(m * 1e3)}k`;
  return `${Math.round(m * 1e3)}`;
}
var MAIN_STAT_FOR_POS = (pos) => pos === "GK" ? "reflexes" : ["ST", "LW", "RW", "CAM"].includes(pos) ? "shooting" : ["CM", "CDM"].includes(pos) ? "passing" : "defending";
function applyPerSeasonItems(s) {
  for (const id of s.purchasedItems ?? []) {
    const item = getSpendingItem(id);
    const per = item?.perSeason;
    if (!per) continue;
    if (per.morale) s.morale = clamp7(s.morale + per.morale, 0, 100);
    if (per.popularity) s.popularity = clamp7(s.popularity + per.popularity, 0, 100);
    if (per.integrity) s.integrityBonus += per.integrity;
    if (per.stat && per.statAmount) {
      const key = per.stat === "main" ? MAIN_STAT_FOR_POS(s.position) : per.stat;
      s.statBoostNextSeason = {
        ...s.statBoostNextSeason,
        [key]: (s.statBoostNextSeason[key] || 0) + per.statAmount
      };
    }
  }
}
function sponsorItemMult(s) {
  let mult = 1;
  for (const id of s.purchasedItems ?? []) {
    const item = getSpendingItem(id);
    if (item?.sponsorMult) mult *= item.sponsorMult;
  }
  return Math.min(mult, 1.35);
}
function injuryDropFromItems(s) {
  if (!s) return 0;
  let drop = 0;
  for (const id of s.purchasedItems ?? []) {
    const item = getSpendingItem(id);
    if (item?.injuryDrop) drop += item.injuryDrop;
  }
  return Math.min(drop, 0.03);
}
function calcTotalAssets(s) {
  let total = 0;
  const propertyValues = {
    "city_apartment": 0.85,
    "luxury_house": 3.2,
    "mansion": 8.5,
    "private_island": 27,
    "sports_car": 0.1,
    "supercar_collection": 0.6,
    "private_jet": 10,
    "yacht": 5
  };
  for (const id of s.purchasedItems) {
    if (propertyValues[id]) total += propertyValues[id];
  }
  for (const h of s.investmentHoldings) {
    if (!h.resolved) total += h.invested;
  }
  return Math.round(total * 100) / 100;
}
function resolveInvestments(s) {
  for (let i = 0; i < s.investmentHoldings.length; i++) {
    const h = s.investmentHoldings[i];
    if (h.resolved) continue;
    const currentYear = s.seasons.length > 0 ? s.seasons[s.seasons.length - 1].year : 2020;
    const yearsHeld = currentYear - h.yearPurchased;
    if (h.name === "Football Club Shares") {
      const yearlyReturn = h.invested * 0.08;
      s.netWorth = Math.round((s.netWorth + yearlyReturn) * 100) / 100;
      if (yearsHeld > 0 && yearsHeld % 1 === 0) {
        s.events.push(`\u26BD Football Club Shares returned \u20AC${yearlyReturn.toFixed(1)}M this year`);
      }
      continue;
    }
    if (yearsHeld < 1) continue;
    h.resolved = true;
    if (h.name === "Restaurant Chain") {
      if (Math.random() < 0.3) {
        h.returnAmount = 1.5;
        s.netWorth = Math.round((s.netWorth + h.returnAmount) * 100) / 100;
        s.events.push(`\u{1F37D}\uFE0F Restaurant chain is thriving! Earned \u20AC${h.returnAmount.toFixed(1)}M profit!`);
      } else if (Math.random() < 0.5) {
        s.events.push("\u{1F37D}\uFE0F Restaurant chain broke even. No profit, no loss.");
      } else {
        const loss = h.invested * 0.5;
        s.events.push(`\u{1F37D}\uFE0F Restaurant chain struggling. Lost \u20AC${loss.toFixed(1)}M.`);
      }
    } else if (h.name === "Crypto") {
      if (Math.random() < 0.5) {
        h.returnAmount = h.invested * 3;
        s.netWorth = Math.round((s.netWorth + h.returnAmount) * 100) / 100;
        s.events.push(`\u20BF Crypto investment 3x'd! Earned \u20AC${h.returnAmount.toFixed(1)}M!`);
      } else {
        s.events.push("\u20BF Crypto investment crashed! Lost everything.");
      }
    } else if (h.name === "Art Collection") {
      const yearlyReturn = h.invested * 0.12;
      s.netWorth = Math.round((s.netWorth + yearlyReturn) * 100) / 100;
      s.events.push(`\u{1F3A8} Art collection appreciated \u20AC${yearlyReturn.toFixed(1)}M this year`);
      continue;
    } else if (h.name === "Teammate's Startup") {
      if (Math.random() < 0.4) {
        h.returnAmount = h.invested * 5;
        s.netWorth = Math.round((s.netWorth + h.returnAmount) * 100) / 100;
        s.events.push(`\u{1F680} Your teammate's startup got acquired! 5x return: \u20AC${h.returnAmount.toFixed(1)}M!`);
      } else {
        s.events.push("\u{1F680} The teammate's startup folded. He avoids you at training.");
      }
    } else if (h.name === "Meme Coin") {
      if (Math.random() < 0.1) {
        h.returnAmount = h.invested * 20;
        s.netWorth = Math.round((s.netWorth + h.returnAmount) * 100) / 100;
        s.events.push(`\u{1F415} THE MEME COIN DID A 20X. \u20AC${h.returnAmount.toFixed(1)}M. Delete the evidence of how proud you are.`);
      } else {
        s.events.push("\u{1F415} The meme coin went to zero, as meme coins do.");
      }
    } else if (h.name === "Racehorse") {
      if (Math.random() < 0.25) {
        h.returnAmount = 6;
        s.netWorth = Math.round((s.netWorth + h.returnAmount) * 100) / 100;
        s.events.push("\u{1F40E} Your horse WON THE BIG ONE. \u20AC6.0M in prize money and stud fees!");
      } else {
        h.returnAmount = h.invested * 0.4;
        s.netWorth = Math.round((s.netWorth + h.returnAmount) * 100) / 100;
        s.events.push(`\u{1F40E} The horse never won but the stud fees paid \u20AC${h.returnAmount.toFixed(1)}M back.`);
      }
    } else if (h.name === "Esports Org") {
      if (Math.random() < 0.35) {
        h.returnAmount = h.invested * 3;
        s.netWorth = Math.round((s.netWorth + h.returnAmount) * 100) / 100;
        s.events.push(`\u{1F3AE} Your esports org won a major! 3x return: \u20AC${h.returnAmount.toFixed(1)}M!`);
      } else {
        s.events.push("\u{1F3AE} The esports org burned through the money. Teenagers are expensive.");
      }
    } else if (h.name === "Tech Startup") {
      if (Math.random() < 0.2) {
        h.returnAmount = h.invested * 10;
        s.netWorth = Math.round((s.netWorth + h.returnAmount) * 100) / 100;
        s.events.push(`\u{1F4BB} Tech startup went viral! 10x return: \u20AC${h.returnAmount.toFixed(1)}M!`);
      } else {
        s.events.push("\u{1F4BB} Tech startup failed. Investment lost.");
      }
    }
  }
  s.investmentHoldings = s.investmentHoldings.filter((h) => !h.resolved || h.name === "Football Club Shares");
}
var ELITE_CLUBS = ["Bayern Munich", "PSG", "Man City", "Real Madrid", "Barcelona", "Liverpool"];
var HAND_CLUBS = [
  // Tier 1, elite
  { id: "fb-1", name: "Real Madrid", country: "Spain", tier: 1, color: "#FEBE10", league: "La Liga" },
  { id: "fb-2", name: "Barcelona", country: "Spain", tier: 1, color: "#A50044", league: "La Liga" },
  { id: "fb-3", name: "Man City", country: "England", tier: 1, color: "#6CABDD", league: "Premier League" },
  { id: "fb-4", name: "Liverpool", country: "England", tier: 1, color: "#C8102E", league: "Premier League" },
  { id: "fb-5", name: "Bayern Munich", country: "Germany", tier: 1, color: "#DC052D", league: "Bundesliga" },
  { id: "fb-6", name: "PSG", country: "France", tier: 1, color: "#004170", league: "Ligue 1" },
  { id: "fb-7", name: "Juventus", country: "Italy", tier: 1, color: "#000000", league: "Serie A" },
  { id: "fb-8", name: "Inter Milan", country: "Italy", tier: 1, color: "#0068A8", league: "Serie A" },
  { id: "fb-9", name: "Man United", country: "England", tier: 1, color: "#DA291C", league: "Premier League" },
  { id: "fb-10", name: "Arsenal", country: "England", tier: 1, color: "#EF0107", league: "Premier League" },
  { id: "fb-11", name: "Chelsea", country: "England", tier: 1, color: "#034694", league: "Premier League" },
  { id: "fb-12", name: "Ajax", country: "Netherlands", tier: 1, color: "#D2122E", league: "Eredivisie" },
  { id: "fb-13", name: "Benfica", country: "Portugal", tier: 1, color: "#E30613", league: "Primeira Liga" },
  { id: "fb-14", name: "Porto", country: "Portugal", tier: 1, color: "#003399", league: "Primeira Liga" },
  { id: "fb-15", name: "Boca Juniors", country: "Argentina", tier: 1, color: "#003DA5", league: "Liga Profesional" },
  { id: "fb-16", name: "River Plate", country: "Argentina", tier: 1, color: "#E9040F", league: "Liga Profesional" },
  { id: "fb-17", name: "Flamengo", country: "Brazil", tier: 1, color: "#C8102E", league: "Brasileirao" },
  { id: "fb-18", name: "Sao Paulo", country: "Brazil", tier: 1, color: "#B40404", league: "Brasileirao" },
  // Tier 2, strong mid-table
  { id: "fb-19", name: "Atletico Madrid", country: "Spain", tier: 2, color: "#CB3524", league: "La Liga" },
  { id: "fb-20", name: "Sevilla", country: "Spain", tier: 2, color: "#D0021B", league: "La Liga" },
  { id: "fb-21", name: "Tottenham", country: "England", tier: 2, color: "#132257", league: "Premier League" },
  { id: "fb-22", name: "Newcastle", country: "England", tier: 2, color: "#241F20", league: "Premier League" },
  { id: "fb-23", name: "Dortmund", country: "Germany", tier: 2, color: "#FDE100", league: "Bundesliga" },
  { id: "fb-24", name: "Leipzig", country: "Germany", tier: 2, color: "#DD0741", league: "Bundesliga" },
  { id: "fb-25", name: "AC Milan", country: "Italy", tier: 2, color: "#FB090B", league: "Serie A" },
  { id: "fb-26", name: "Napoli", country: "Italy", tier: 2, color: "#12A0D7", league: "Serie A" },
  { id: "fb-27", name: "Roma", country: "Italy", tier: 2, color: "#8E1F2F", league: "Serie A" },
  { id: "fb-28", name: "Marseille", country: "France", tier: 2, color: "#2FA0DA", league: "Ligue 1" },
  { id: "fb-29", name: "Lyon", country: "France", tier: 2, color: "#1C2C5B", league: "Ligue 1" },
  { id: "fb-30", name: "Feyenoord", country: "Netherlands", tier: 2, color: "#00A03C", league: "Eredivisie" },
  { id: "fb-31", name: "PSV", country: "Netherlands", tier: 2, color: "#ED1C24", league: "Eredivisie" },
  { id: "fb-32", name: "Sporting CP", country: "Portugal", tier: 2, color: "#008148", league: "Primeira Liga" },
  { id: "fb-33", name: "Fenerbahce", country: "Turkey", tier: 2, color: "#0A2C59", league: "Super Lig" },
  { id: "fb-34", name: "Galatasaray", country: "Turkey", tier: 2, color: "#A90432", league: "Super Lig" },
  { id: "fb-35", name: "Al Hilal", country: "Saudi Arabia", tier: 2, color: "#003DA5", league: "Saudi Pro League" },
  { id: "fb-36", name: "Celtic", country: "Scotland", tier: 2, color: "#018749", league: "Scottish Premiership" },
  { id: "fb-37", name: "Rangers", country: "Scotland", tier: 2, color: "#1E3A8A", league: "Scottish Premiership" },
  { id: "fb-38", name: "Palmeiras", country: "Brazil", tier: 2, color: "#006437", league: "Brasileirao" },
  { id: "fb-39", name: "LA Galaxy", country: "USA", tier: 2, color: "#00245D", league: "MLS" },
  { id: "fb-40", name: "Inter Miami", country: "USA", tier: 2, color: "#F7B5CD", league: "MLS" },
  // Tier 3, solid domestic clubs
  { id: "fb-41", name: "Real Sociedad", country: "Spain", tier: 3, color: "#0067B1", league: "La Liga" },
  { id: "fb-42", name: "Villarreal", country: "Spain", tier: 3, color: "#FFE667", league: "La Liga" },
  { id: "fb-43", name: "West Ham", country: "England", tier: 3, color: "#7A263A", league: "Championship" },
  { id: "fb-44", name: "Aston Villa", country: "England", tier: 3, color: "#670E36", league: "Premier League" },
  { id: "fb-45", name: "Everton", country: "England", tier: 3, color: "#003399", league: "Premier League" },
  { id: "fb-46", name: "Leverkusen", country: "Germany", tier: 3, color: "#E32221", league: "Bundesliga" },
  { id: "fb-47", name: "Frankfurt", country: "Germany", tier: 3, color: "#E1000F", league: "Bundesliga" },
  { id: "fb-48", name: "Atalanta", country: "Italy", tier: 3, color: "#1E71B8", league: "Serie A" },
  { id: "fb-49", name: "Fiorentina", country: "Italy", tier: 3, color: "#5B2A86", league: "Serie A" },
  { id: "fb-50", name: "Lille", country: "France", tier: 3, color: "#C60C30", league: "Ligue 1" },
  { id: "fb-51", name: "Monaco", country: "Monaco", tier: 3, color: "#E2231A", league: "Ligue 1" },
  { id: "fb-52", name: "Genk", country: "Belgium", tier: 3, color: "#0055A4", league: "Belgian Pro League" },
  { id: "fb-53", name: "Anderlecht", country: "Belgium", tier: 3, color: "#5E2C81", league: "Belgian Pro League" },
  { id: "fb-54", name: "FC Copenhagen", country: "Denmark", tier: 3, color: "#FFFFFF", league: "Danish Superliga" },
  { id: "fb-55", name: "Malmo FF", country: "Sweden", tier: 3, color: "#5CB8E4", league: "Allsvenskan" },
  { id: "fb-56", name: "Red Bull Salzburg", country: "Austria", tier: 3, color: "#DB021D", league: "Austrian Bundesliga" },
  { id: "fb-57", name: "Basel", country: "Switzerland", tier: 3, color: "#DB021D", league: "Swiss Super League" },
  { id: "fb-58", name: "Al Nassr", country: "Saudi Arabia", tier: 3, color: "#FFF200", league: "Saudi Pro League" },
  { id: "fb-59", name: "Cruz Azul", country: "Mexico", tier: 3, color: "#00539F", league: "Liga MX" },
  { id: "fb-60", name: "Club America", country: "Mexico", tier: 3, color: "#FFC72C", league: "Liga MX" },
  // Tier 4, smaller / lower league
  { id: "fb-61", name: "Real Betis", country: "Spain", tier: 4, color: "#00954C", league: "La Liga" },
  { id: "fb-62", name: "Celta Vigo", country: "Spain", tier: 4, color: "#8AC3EE", league: "La Liga" },
  { id: "fb-63", name: "Crystal Palace", country: "England", tier: 4, color: "#1B458F", league: "Premier League" },
  { id: "fb-64", name: "Brentford", country: "England", tier: 4, color: "#D20000", league: "Premier League" },
  { id: "fb-65", name: "Norwich City", country: "England", tier: 4, color: "#FFF200", league: "Championship" },
  { id: "fb-66", name: "Hertha Berlin", country: "Germany", tier: 4, color: "#004C9E", league: "2. Bundesliga" },
  { id: "fb-67", name: "Werder Bremen", country: "Germany", tier: 4, color: "#1D9053", league: "Bundesliga" },
  { id: "fb-68", name: "Torino", country: "Italy", tier: 4, color: "#881B1E", league: "Serie A" },
  { id: "fb-69", name: "Bologna", country: "Italy", tier: 4, color: "#A61C2E", league: "Serie A" },
  { id: "fb-70", name: "Nantes", country: "France", tier: 4, color: "#FCE300", league: "Ligue 2" },
  { id: "fb-71", name: "Strasbourg", country: "France", tier: 4, color: "#0072BB", league: "Ligue 1" },
  { id: "fb-72", name: "Utrecht", country: "Netherlands", tier: 4, color: "#D2122E", league: "Eredivisie" },
  { id: "fb-73", name: "Braga", country: "Portugal", tier: 4, color: "#DA020E", league: "Primeira Liga" },
  { id: "fb-74", name: "Aberdeen", country: "Scotland", tier: 4, color: "#D71920", league: "Scottish Premiership" },
  { id: "fb-75", name: "Santos", country: "Brazil", tier: 4, color: "#FFFFFF", league: "Brasileirao" },
  { id: "fb-76", name: "Colo-Colo", country: "Chile", tier: 4, color: "#FFFFFF", league: "Primera Division" },
  { id: "fb-77", name: "Al Ahly", country: "Egypt", tier: 4, color: "#C8102E", league: "Egyptian Premier League" },
  { id: "fb-78", name: "Kaizer Chiefs", country: "South Africa", tier: 4, color: "#FFD100", league: "PSL" },
  { id: "fb-79", name: "Yokohama F. Marinos", country: "Japan", tier: 4, color: "#00559A", league: "J1 League" },
  { id: "fb-80", name: "Urawa Red Diamonds", country: "Japan", tier: 4, color: "#D2001C", league: "J1 League" },
  { id: "fb-81", name: "Seattle Sounders", country: "USA", tier: 4, color: "#5D9741", league: "MLS" },
  // ── Round 54 expansion: 60+ new clubs so careers can wind through nearly
  // every football country on earth (owner: "more teams and more flags and
  // more of everything"). Tier 2, big names outside the usual five leagues.
  { id: "fb-82", name: "Al Ittihad", country: "Saudi Arabia", tier: 2, color: "#F9C623", league: "Saudi Pro League" },
  { id: "fb-83", name: "Club Brugge", country: "Belgium", tier: 2, color: "#0B4494", league: "Belgian Pro League" },
  { id: "fb-84", name: "Olympiacos", country: "Greece", tier: 2, color: "#D6202B", league: "Super League Greece" },
  { id: "fb-85", name: "Shakhtar Donetsk", country: "Ukraine", tier: 2, color: "#F26522", league: "Ukrainian Premier League" },
  { id: "fb-86", name: "Corinthians", country: "Brazil", tier: 2, color: "#141414", league: "Brasileirao" },
  { id: "fb-87", name: "Monterrey", country: "Mexico", tier: 2, color: "#0A2240", league: "Liga MX" },
  { id: "fb-88", name: "Tigres UANL", country: "Mexico", tier: 2, color: "#FDB913", league: "Liga MX" },
  { id: "fb-89", name: "Athletic Bilbao", country: "Spain", tier: 2, color: "#EE2523", league: "La Liga" },
  { id: "fb-90", name: "Brighton", country: "England", tier: 2, color: "#0057B8", league: "Premier League" },
  { id: "fb-91", name: "Stuttgart", country: "Germany", tier: 2, color: "#E32219", league: "Bundesliga" },
  { id: "fb-92", name: "LAFC", country: "USA", tier: 2, color: "#C39E6D", league: "MLS" },
  { id: "fb-93", name: "River Plate Asuncion", country: "Paraguay", tier: 4, color: "#CE1126", league: "Primera B Paraguay" },
  { id: "fb-94", name: "Racing Club", country: "Argentina", tier: 2, color: "#75AADB", league: "Liga Profesional" },
  { id: "fb-95", name: "Zenit", country: "Russia", tier: 2, color: "#009FDF", league: "Russian Premier League" },
  { id: "fb-96", name: "Girona", country: "Spain", tier: 2, color: "#CD2534", league: "Segunda Division" },
  // Tier 3, strong clubs across Europe, Asia, Africa and the Americas.
  { id: "fb-97", name: "PAOK", country: "Greece", tier: 3, color: "#2B2B2B", league: "Super League Greece" },
  { id: "fb-98", name: "Panathinaikos", country: "Greece", tier: 3, color: "#00743F", league: "Super League Greece" },
  { id: "fb-99", name: "Dinamo Zagreb", country: "Croatia", tier: 3, color: "#1F4C9C", league: "HNL" },
  { id: "fb-100", name: "Red Star Belgrade", country: "Serbia", tier: 3, color: "#D6202B", league: "Serbian SuperLiga" },
  { id: "fb-101", name: "Legia Warsaw", country: "Poland", tier: 3, color: "#0F5B2F", league: "Ekstraklasa" },
  { id: "fb-102", name: "Slavia Prague", country: "Czech Republic", tier: 3, color: "#D6202B", league: "Czech First League" },
  { id: "fb-103", name: "Besiktas", country: "Turkey", tier: 3, color: "#2B2B2B", league: "Super Lig" },
  { id: "fb-104", name: "Trabzonspor", country: "Turkey", tier: 3, color: "#5C1F33", league: "Super Lig" },
  { id: "fb-105", name: "Nice", country: "France", tier: 3, color: "#CC0000", league: "Ligue 1" },
  { id: "fb-106", name: "Wolves", country: "England", tier: 3, color: "#FDB913", league: "Championship" },
  { id: "fb-107", name: "Fulham", country: "England", tier: 3, color: "#111111", league: "Premier League" },
  { id: "fb-108", name: "Gremio", country: "Brazil", tier: 3, color: "#0D80BF", league: "Brasileirao" },
  { id: "fb-109", name: "Atletico Nacional", country: "Colombia", tier: 3, color: "#00A650", league: "Liga BetPlay" },
  { id: "fb-110", name: "Penarol", country: "Uruguay", tier: 3, color: "#FFD100", league: "Primera Division Uruguay" },
  { id: "fb-111", name: "Kawasaki Frontale", country: "Japan", tier: 3, color: "#009FE8", league: "J1 League" },
  { id: "fb-112", name: "Jeonbuk Motors", country: "South Korea", tier: 3, color: "#0C6B3E", league: "K League 1" },
  { id: "fb-113", name: "Al Sadd", country: "Qatar", tier: 3, color: "#2B2B2B", league: "Qatar Stars League" },
  { id: "fb-114", name: "Persepolis", country: "Iran", tier: 3, color: "#D6202B", league: "Persian Gulf Pro League" },
  { id: "fb-115", name: "Shanghai Port", country: "China", tier: 3, color: "#D6202B", league: "Chinese Super League" },
  { id: "fb-116", name: "Zamalek", country: "Egypt", tier: 3, color: "#FFFFFF", league: "Egyptian Premier League" },
  { id: "fb-117", name: "Wydad Casablanca", country: "Morocco", tier: 3, color: "#D6202B", league: "Botola Pro" },
  { id: "fb-118", name: "Esperance", country: "Tunisia", tier: 3, color: "#BC0C12", league: "Ligue 1 Tunisia" },
  { id: "fb-119", name: "Mamelodi Sundowns", country: "South Africa", tier: 3, color: "#FBC403", league: "PSL" },
  { id: "fb-120", name: "Toronto FC", country: "Canada", tier: 3, color: "#B81137", league: "MLS" },
  // Tier 4, the wide world where most careers actually start.
  { id: "fb-121", name: "Sparta Prague", country: "Czech Republic", tier: 4, color: "#7B0C11", league: "Czech First League" },
  { id: "fb-122", name: "Partizan", country: "Serbia", tier: 4, color: "#2B2B2B", league: "Serbian SuperLiga" },
  { id: "fb-123", name: "Ferencvaros", country: "Hungary", tier: 4, color: "#0E5C2F", league: "NB I" },
  { id: "fb-124", name: "Hajduk Split", country: "Croatia", tier: 4, color: "#0C4076", league: "HNL" },
  { id: "fb-125", name: "HJK Helsinki", country: "Finland", tier: 4, color: "#0056A3", league: "Veikkausliiga" },
  { id: "fb-126", name: "Breidablik", country: "Iceland", tier: 4, color: "#00954C", league: "Besta deild" },
  { id: "fb-127", name: "Slovan Bratislava", country: "Slovakia", tier: 4, color: "#57A8E2", league: "Slovak First League" },
  { id: "fb-128", name: "Ludogorets", country: "Bulgaria", tier: 4, color: "#00954C", league: "First League Bulgaria" },
  { id: "fb-129", name: "Sheriff Tiraspol", country: "Moldova", tier: 4, color: "#FBC403", league: "Super Liga Moldova" },
  { id: "fb-130", name: "Dinamo Tbilisi", country: "Georgia", tier: 4, color: "#0C4076", league: "Erovnuli Liga" },
  { id: "fb-131", name: "Pyunik", country: "Armenia", tier: 4, color: "#D6202B", league: "Armenian Premier League" },
  { id: "fb-132", name: "Qarabag", country: "Azerbaijan", tier: 4, color: "#2B2B2B", league: "Azerbaijan Premier League" },
  { id: "fb-133", name: "Kairat Almaty", country: "Kazakhstan", tier: 4, color: "#FBC403", league: "Kazakhstan Premier League" },
  { id: "fb-134", name: "Pakhtakor", country: "Uzbekistan", tier: 4, color: "#0056A3", league: "Uzbekistan Super League" },
  { id: "fb-135", name: "Mumbai City", country: "India", tier: 4, color: "#57A8E2", league: "Indian Super League" },
  { id: "fb-136", name: "Buriram United", country: "Thailand", tier: 4, color: "#0C2E5C", league: "Thai League 1" },
  { id: "fb-137", name: "Persija Jakarta", country: "Indonesia", tier: 4, color: "#D6202B", league: "Super League Indonesia" },
  { id: "fb-138", name: "Hanoi FC", country: "Vietnam", tier: 4, color: "#5C2D91", league: "V.League 1" },
  { id: "fb-139", name: "Johor Darul Tazim", country: "Malaysia", tier: 4, color: "#0C2E5C", league: "Malaysia Super League" },
  { id: "fb-140", name: "Melbourne Victory", country: "Australia", tier: 4, color: "#0C2E5C", league: "A-League" },
  { id: "fb-141", name: "Auckland FC", country: "New Zealand", tier: 4, color: "#2B2B2B", league: "A-League" },
  { id: "fb-142", name: "Wellington Phoenix", country: "New Zealand", tier: 4, color: "#FBC403", league: "A-League" },
  { id: "fb-143", name: "Raja Casablanca", country: "Morocco", tier: 4, color: "#00954C", league: "Botola Pro" },
  { id: "fb-144", name: "TP Mazembe", country: "DR Congo", tier: 4, color: "#2B2B2B", league: "Linafoot" },
  { id: "fb-145", name: "Enyimba", country: "Nigeria", tier: 4, color: "#0056A3", league: "NPFL" },
  { id: "fb-146", name: "Asante Kotoko", country: "Ghana", tier: 4, color: "#D6202B", league: "Ghana Premier League" },
  { id: "fb-147", name: "Gor Mahia", country: "Kenya", tier: 4, color: "#00954C", league: "Kenyan Premier League" },
  { id: "fb-148", name: "Orlando Pirates", country: "South Africa", tier: 4, color: "#2B2B2B", league: "PSL" },
  { id: "fb-149", name: "Saint George", country: "Ethiopia", tier: 4, color: "#FBC403", league: "Ethiopian Premier League" },
  { id: "fb-150", name: "Young Africans", country: "Tanzania", tier: 4, color: "#00954C", league: "NBC Premier League" },
  { id: "fb-151", name: "Atletico Petroleos", country: "Angola", tier: 4, color: "#FBC403", league: "Girabola" },
  { id: "fb-152", name: "Nacional", country: "Uruguay", tier: 4, color: "#FFFFFF", league: "Primera Division Uruguay" },
  { id: "fb-153", name: "Universidad de Chile", country: "Chile", tier: 4, color: "#0C2E5C", league: "Primera Division" },
  { id: "fb-154", name: "Millonarios", country: "Colombia", tier: 4, color: "#0056A3", league: "Liga BetPlay" },
  { id: "fb-155", name: "LDU Quito", country: "Ecuador", tier: 4, color: "#FFFFFF", league: "LigaPro" },
  { id: "fb-156", name: "Alianza Lima", country: "Peru", tier: 4, color: "#0C2E5C", league: "Liga 1 Peru" },
  { id: "fb-157", name: "Olimpia", country: "Paraguay", tier: 4, color: "#2B2B2B", league: "Primera Division Paraguay" },
  { id: "fb-158", name: "Caracas FC", country: "Venezuela", tier: 4, color: "#7B0C11", league: "Liga FUTVE" },
  { id: "fb-159", name: "Bolivar", country: "Bolivia", tier: 4, color: "#57A8E2", league: "Division Profesional" },
  { id: "fb-160", name: "Saprissa", country: "Costa Rica", tier: 4, color: "#5C2D91", league: "Liga FPD" },
  { id: "fb-161", name: "Olimpia Tegucigalpa", country: "Honduras", tier: 4, color: "#FFFFFF", league: "Liga Nacional Honduras" },
  { id: "fb-162", name: "Alianza FC", country: "El Salvador", tier: 4, color: "#FFFFFF", league: "Primera Division El Salvador" },
  { id: "fb-163", name: "Comunicaciones", country: "Guatemala", tier: 4, color: "#FFFFFF", league: "Liga Nacional Guatemala" },
  { id: "fb-164", name: "Violette AC", country: "Haiti", tier: 4, color: "#5C2D91", league: "Ligue Haitienne" },
  { id: "fb-165", name: "Waterhouse FC", country: "Jamaica", tier: 4, color: "#D6202B", league: "Jamaica Premier League" },
  { id: "fb-166", name: "Defence Force FC", country: "Trinidad and Tobago", tier: 4, color: "#7B0C11", league: "TT Premier League" },
  { id: "fb-167", name: "Vancouver Whitecaps", country: "Canada", tier: 4, color: "#0C2E5C", league: "MLS" },
  { id: "fb-168", name: "Chivas", country: "Mexico", tier: 4, color: "#D6202B", league: "Liga MX" },
  { id: "fb-169", name: "Pumas", country: "Mexico", tier: 4, color: "#0C2E5C", league: "Liga MX" },
  { id: "fb-170", name: "Al Duhail", country: "Qatar", tier: 4, color: "#D6202B", league: "Qatar Stars League" },
  { id: "fb-171", name: "Al Ain", country: "UAE", tier: 4, color: "#5C2D91", league: "UAE Pro League" },
  { id: "fb-172", name: "Beijing Guoan", country: "China", tier: 4, color: "#00954C", league: "Chinese Super League" },
  { id: "fb-173", name: "Maccabi Tel Aviv", country: "Israel", tier: 4, color: "#FBC403", league: "Israeli Premier League" },
  { id: "fb-174", name: "APOEL", country: "Cyprus", tier: 4, color: "#F26522", league: "Cypriot First Division" },
  { id: "fb-175", name: "Flora Tallinn", country: "Estonia", tier: 4, color: "#00954C", league: "Meistriliiga" },
  { id: "fb-176", name: "Zalgiris Vilnius", country: "Lithuania", tier: 4, color: "#00954C", league: "A Lyga" },
  /* Round 302, off the owner's tweaks document: the leagues he named by name
     (Liga Portugal here as Primeira Liga, Eredivisie, Scottish, MLS, Saudi,
     K League) get real depth instead of two or three clubs each. League
     labels are byte identical to the strings already in this array, because
     league is free text and a near miss silently creates a new league. */
  { id: "fb-177", name: "AZ Alkmaar", country: "Netherlands", tier: 3, color: "#DD0000", league: "Eredivisie" },
  { id: "fb-178", name: "Twente", country: "Netherlands", tier: 4, color: "#E70011", league: "Eredivisie" },
  { id: "fb-179", name: "Vitoria Guimaraes", country: "Portugal", tier: 4, color: "#F5F5F5", league: "Primeira Liga" },
  { id: "fb-180", name: "Hearts", country: "Scotland", tier: 4, color: "#800910", league: "Scottish Premiership" },
  { id: "fb-181", name: "Hibernian", country: "Scotland", tier: 4, color: "#006A4E", league: "Scottish Premiership" },
  { id: "fb-182", name: "Columbus Crew", country: "USA", tier: 3, color: "#FEDD00", league: "MLS" },
  { id: "fb-183", name: "Atlanta United", country: "USA", tier: 4, color: "#80000A", league: "MLS" },
  { id: "fb-184", name: "Al Ahli", country: "Saudi Arabia", tier: 3, color: "#006B3F", league: "Saudi Pro League" },
  { id: "fb-185", name: "Al Shabab", country: "Saudi Arabia", tier: 4, color: "#F2F2F2", league: "Saudi Pro League" },
  { id: "fb-186", name: "Ulsan HD", country: "South Korea", tier: 3, color: "#0053A0", league: "K League 1" },
  { id: "fb-187", name: "FC Seoul", country: "South Korea", tier: 4, color: "#AC1A2F", league: "K League 1" },
  { id: "fb-188", name: "Pohang Steelers", country: "South Korea", tier: 4, color: "#C8102E", league: "K League 1" },
  { id: "fb-189", name: "Botafogo", country: "Brazil", tier: 3, color: "#1A1A1A", league: "Brasileirao" },
  { id: "fb-190", name: "Cruzeiro", country: "Brazil", tier: 4, color: "#0033A0", league: "Brasileirao" }
];
var FALLBACK_CLUBS = [...HAND_CLUBS, ...CAREER_CLUB_POOL];
function projectLeagueApps(overall, clubTier, clubName, seasonsAtClub) {
  const clubAvg = clubAverageRating(clubTier);
  const diff = overall - clubAvg;
  const isEliteClub = ELITE_CLUBS.includes(clubName);
  if (overall >= 95) return { min: 34, max: 38 };
  if (overall >= 90) return { min: 32, max: 38 };
  if (overall >= 85 && clubTier <= 2) return { min: 30, max: 36 };
  if (isEliteClub && diff <= -10) {
    if (seasonsAtClub === 0) return { min: 8, max: 16 };
    if (seasonsAtClub === 1) return { min: 14, max: 22 };
    return { min: 12, max: 20 };
  }
  if (isEliteClub && diff <= -5) {
    if (seasonsAtClub === 0) return { min: 14, max: 22 };
    return { min: 20, max: 28 };
  }
  if (diff >= 15) return { min: 32, max: 38 };
  if (diff >= 5) return { min: 26, max: 34 };
  if (diff >= -5) return { min: 20, max: 30 };
  return { min: 8, max: 18 };
}
function calcAppearances(overall, clubTier, age, state, fx = NEUTRAL_EFFECTS) {
  const clubAvg = clubAverageRating(clubTier);
  const diff = overall - clubAvg;
  const isEliteClub = state ? ELITE_CLUBS.includes(state.currentClub) : false;
  const seasonsAtClub = state ? state.seasons.filter((s) => s.club === state.currentClub && s.type === "playing").length : 0;
  const band = projectLeagueApps(overall, clubTier, state?.currentClub ?? "", seasonsAtClub);
  const leagueMin = band.min, leagueMax = band.max;
  let leagueApps = rand2(leagueMin, leagueMax);
  if (state) leagueApps = clamp7(leagueApps + phoneAppsSwing(state), 0, 38);
  if (state?.frozenOut && state.frozenOut > 0) {
    leagueApps = Math.min(8, Math.round(leagueApps * 0.25));
  }
  let uclApps = 0;
  if (clubTier <= 2) {
    const qualifies = clubTier === 1 ? true : Math.random() < 0.5;
    if (qualifies) {
      const groupApps = rand2(6, 8);
      const deepRunChance = overall >= 90 ? 0.7 : overall >= 85 ? 0.5 : 0.3;
      if (Math.random() < deepRunChance) {
        uclApps = groupApps + rand2(3, 5);
      } else {
        uclApps = groupApps + rand2(0, 2);
      }
      if (leagueApps < 20) {
        uclApps = Math.round(uclApps * 0.5);
      }
    }
  }
  let cupApps = 0;
  if (leagueApps >= 20) {
    cupApps = rand2(3, 7);
  } else if (leagueApps >= 10) {
    cupApps = rand2(2, 5);
  } else {
    cupApps = rand2(1, 3);
  }
  let apps = leagueApps + uclApps + cupApps;
  apps = Math.max(0, Math.round(apps * fx.appsMult));
  let injured = false;
  let injuryWeeks = 0;
  let injuryName = null;
  let injurySevere = false;
  let injuryChance = clamp7(0.2 + fx.injuryDelta, 0.05, 0.4);
  const startedAt = state?.startingOverall;
  if (typeof startedAt === "number" && startedAt > 60 && age <= 23) {
    injuryChance = clamp7(injuryChance + clamp7(startedAt - 60, 0, 39) * 45e-4, 0.05, 0.42);
  }
  if (state?.purchasedItems?.includes("perf_cryo")) injuryChance -= 0.03;
  injuryChance -= injuryDropFromItems(state);
  injuryChance += state?.rehabFragility ?? 0;
  injuryChance = clamp7(injuryChance, 0.04, 0.42);
  const injuryRoll = rollSeasonInjury(injuryChance);
  if (injuryRoll) {
    injured = true;
    injuryName = injuryRoll.name;
    injurySevere = injuryRoll.severe;
    injuryWeeks = injuryRoll.weeks;
    if (state?.purchasedItems?.includes("elite_recovery")) {
      injuryWeeks = Math.max(1, Math.round(injuryWeeks * 0.5));
    }
    if (state?.purchasedItems?.includes("perf_sleep")) {
      injuryWeeks = Math.max(1, injuryWeeks - 1);
    }
    if (injuryWeeks < 14) injurySevere = false;
    const missedApps = Math.round(injuryWeeks * apps / 46);
    apps = Math.max(1, apps - clamp7(missedApps, 0, injurySevere ? 34 : 12));
  }
  return { apps, leagueApps, injured, injuryWeeks, injuryName, injurySevere };
}
function calcGoals(position, apps, overall, mult = 1) {
  const ovr = overall ?? 75;
  let lo, hi;
  switch (position) {
    case "ST":
      if (ovr >= 96) {
        lo = 35;
        hi = 48;
      } else if (ovr >= 93) {
        lo = 30;
        hi = 42;
      } else if (ovr >= 90) {
        lo = 25;
        hi = 35;
      } else if (ovr >= 85) {
        lo = 20;
        hi = 32;
      } else if (ovr >= 75) {
        lo = 12;
        hi = 22;
      } else if (ovr >= 65) {
        lo = 6;
        hi = 14;
      } else {
        lo = 3;
        hi = 8;
      }
      break;
    case "LW":
    case "RW":
      if (ovr >= 96) {
        lo = 32;
        hi = 45;
      } else if (ovr >= 93) {
        lo = 28;
        hi = 38;
      } else if (ovr >= 90) {
        lo = 22;
        hi = 32;
      } else if (ovr >= 85) {
        lo = 16;
        hi = 26;
      } else if (ovr >= 75) {
        lo = 8;
        hi = 16;
      } else if (ovr >= 65) {
        lo = 4;
        hi = 10;
      } else {
        lo = 2;
        hi = 6;
      }
      break;
    case "CAM":
      if (ovr >= 90) {
        lo = 14;
        hi = 22;
      } else if (ovr >= 85) {
        lo = 10;
        hi = 18;
      } else if (ovr >= 75) {
        lo = 6;
        hi = 12;
      } else {
        lo = 3;
        hi = 8;
      }
      break;
    case "CM":
      if (ovr >= 90) {
        lo = 6;
        hi = 12;
      } else {
        lo = 3;
        hi = 8;
      }
      break;
    case "CDM":
      lo = 1;
      hi = 4;
      break;
    case "CB":
    case "LB":
    case "RB":
      lo = 0;
      hi = 3;
      break;
    case "GK":
      return 0;
    default:
      lo = 0;
      hi = 3;
  }
  const rawGoals = Math.max(0, Math.round(rand2(lo, hi) * apps / 38 * mult));
  if (ovr >= 90 && apps >= 20 && ["ST", "LW", "RW", "CAM"].includes(position)) {
    return Math.max(Math.round(15 * mult), rawGoals);
  }
  return rawGoals;
}
function calcAssists(position, apps, overall, mult = 1) {
  const ovr = overall ?? 75;
  let lo, hi;
  if (ovr >= 90) {
    switch (position) {
      case "CAM":
      case "CM":
        lo = 15;
        hi = 22;
        break;
      case "LW":
      case "RW":
        lo = 12;
        hi = 18;
        break;
      case "ST":
        lo = 8;
        hi = 13;
        break;
      default:
        lo = 2;
        hi = 6;
    }
  } else {
    const per38 = {
      CAM: [10, 18],
      LW: [8, 15],
      RW: [8, 15],
      CM: [5, 10],
      ST: [3, 8],
      CDM: [2, 6],
      CB: [1, 4],
      LB: [1, 4],
      RB: [1, 4],
      GK: [0, 0]
    };
    [lo, hi] = per38[position] || [1, 4];
  }
  return Math.max(0, Math.round(rand2(lo, hi) * apps / 38 * mult));
}
var DEFENSIVE_SHEET_CREDIT = 0.035;
var CDM_EXPECTED_SHEET_SHARE = 0.325;
var CDM_CREDIT_SHARE = 0.75;
function defensiveRatingCredit(position, apps, cleanSheets) {
  if (position === "CB" || position === "LB" || position === "RB") return cleanSheets * DEFENSIVE_SHEET_CREDIT;
  if (position === "CDM") return apps * CDM_EXPECTED_SHEET_SHARE * DEFENSIVE_SHEET_CREDIT * CDM_CREDIT_SHARE;
  return 0;
}
function calcSeasonRating(position, apps, goals, assists, cleanSheets, overall, clubTier, buildDelta = 0) {
  const clubAvg = clubAverageRating(clubTier);
  const diff = overall - clubAvg;
  let base = 6 + diff * 0.06;
  if (position === "GK") {
    base += cleanSheets * 0.08;
  } else if (["ST", "LW", "RW", "CAM"].includes(position)) {
    base += goals * 0.04 + assists * 0.03;
  } else {
    base += goals * 0.06 + assists * 0.04;
  }
  base += defensiveRatingCredit(position, apps, cleanSheets);
  if (apps >= 30) base += 0.3;
  else if (apps < 15) base -= 0.4;
  base += buildDelta;
  base += (Math.random() - 0.5) * 0.8;
  return clamp7(parseFloat(base.toFixed(1)), 3, 10);
}
function seasonCupAssociation(season2, s) {
  const league = season2.club === s.currentClub ? s.currentLeague : FALLBACK_CLUBS.find((c) => c.name === season2.club)?.league ?? s.currentLeague;
  return cupAssociation(season2.clubCountry, league);
}
function seasonCupTitle(season2, s) {
  const st = cupFor(seasonCupAssociation(season2, s), season2.year);
  return cupTitle(st.kind === "NAMED" ? st.name : void 0);
}
function generateSeasonStats(state, clubs) {
  const { position, age, overall, currentClubTier } = state;
  const isGK = position === "GK";
  const lastYear = state.seasons.length > 0 ? state.seasons[state.seasons.length - 1].year : 0;
  const fx = careerBuildEffects(state);
  const { apps, leagueApps, injured, injuryWeeks, injuryName, injurySevere } = calcAppearances(overall, currentClubTier, age, state, fx);
  let goals = calcGoals(position, apps, overall, fx.goalMult);
  if (state.divingActive && !isGK) goals += 2;
  const assists = calcAssists(position, apps, overall, fx.assistMult);
  const keepsSheets = isGK || position === "CB" || position === "LB" || position === "RB";
  const cleanSheets = keepsSheets ? clamp7(Math.round(apps * rand2(20, 45) / 100 * fx.cleanSheetMult), 0, apps) : 0;
  const yellowCards = rand2(0, Math.min(8, Math.round(apps * 0.25)));
  const redCards = Math.random() < 0.08 ? 1 : 0;
  const rating = calcSeasonRating(position, apps, goals, assists, cleanSheets, overall, currentClubTier, fx.ratingDelta);
  const seasonYear = lastYear + 1;
  const isElite = eliteInYear(ELITE_CLUBS, state.currentClub, seasonYear);
  const performanceBoost = seasonPerformanceBoost(overall, rating);
  let leagueChance;
  if (isElite) leagueChance = 0.65;
  else if (currentClubTier === 1) leagueChance = 0.25;
  else if (currentClubTier === 2) leagueChance = 0.1;
  else leagueChance = 0.03;
  leagueChance = Math.min(0.85, leagueChance + performanceBoost);
  const cupChance = cupChanceFor({ elite: isElite, tier: currentClubTier, performanceBoost });
  const winLeague = Math.random() < leagueChance;
  const winCup = Math.random() < cupChance && cupFor(cupAssociation(state.currentClubCountry, state.currentLeague), seasonYear).kind !== "NONE";
  const finish = drawLeagueFinish({
    league: leagueKeyInYear({ name: state.currentClub, league: state.currentLeague }, seasonYear),
    year: seasonYear,
    tier: currentClubTier,
    elite: isElite,
    rating,
    leagueTitle: winLeague,
    seedKey: `${state.playerName}|${state.currentClub}|${seasonYear}|${apps}|${goals}|${assists}|${rating}`
  });
  const derbies = resolveSeasonDerbies({
    club: state.currentClub,
    league: state.currentLeague,
    year: seasonYear,
    clubs,
    elite: ELITE_CLUBS,
    position,
    apps,
    leagueApps,
    goals,
    leagueTitle: winLeague && !(injured && injurySevere),
    seedKey: `${state.playerName}|${state.currentClub}|${seasonYear}|${apps}|${goals}|${assists}|${rating}|derby`
  });
  return {
    year: lastYear + 1,
    age,
    club: state.currentClub,
    clubCountry: state.currentClubCountry,
    clubTier: currentClubTier,
    apps,
    leagueApps,
    goals,
    assists,
    cleanSheets,
    yellowCards,
    redCards,
    rating,
    ovr: overall,
    injury: injured ? injuryName : null,
    injuryWeeks: injured ? injuryWeeks : 0,
    injurySevere: injured ? injurySevere : false,
    leagueTitle: winLeague,
    ...finish,
    ...derbies.length > 0 ? { derbies } : {},
    domesticCup: winCup,
    championsLeague: false,
    worldCup: false,
    ballonDor: false,
    ballonDorRank: null,
    type: "playing",
    intApps: 0,
    intGoals: 0,
    intAssists: 0,
    intRating: 0,
    tournament: null,
    tournamentResult: null
  };
}
function wageForTier(tier, overall) {
  if (tier === 1) {
    if (overall >= 95) return rand2(38e4, 55e4);
    if (overall >= 90) return rand2(25e4, 38e4);
    if (overall >= 85) return rand2(15e4, 25e4);
    if (overall >= 80) return rand2(8e4, 15e4);
    return rand2(3e4, 8e4);
  }
  if (tier === 2) {
    if (overall >= 85) return rand2(7e4, 12e4);
    if (overall >= 80) return rand2(4e4, 8e4);
    if (overall >= 75) return rand2(2e4, 5e4);
    return rand2(8e3, 2e4);
  }
  if (tier === 3) {
    if (overall >= 75) return rand2(1e4, 25e3);
    return rand2(5e3, 15e3);
  }
  return rand2(500, 5e3);
}
function formatWage(wage) {
  if (wage >= 1e3) return localizeMoney(`\u20AC${(wage / 1e3).toFixed(0)}k/wk`);
  return localizeMoney(`\u20AC${wage}/wk`);
}
function generateContractOffers(clubs, overall, age, academyClubName) {
  let targetTiers;
  if (overall >= 66) targetTiers = [2, 2, 3];
  else if (overall >= 56) targetTiers = [3, 3, 3];
  else targetTiers = [3, 4, 4];
  const offers = [];
  const usedNames = /* @__PURE__ */ new Set();
  if (academyClubName) {
    const parentClub = clubs.find((c) => c.name === academyClubName);
    if (parentClub) {
      usedNames.add(parentClub.name);
      offers.push({
        club: parentClub,
        contractYears: rand2(3, 5),
        wage: Math.round(wageForTier(parentClub.tier, overall) * 0.8),
        transferFee: 0,
        isHomegrown: true
      });
    }
  }
  for (const tier of targetTiers) {
    const candidates = getClubsByTier(clubs, tier).filter((c) => !usedNames.has(c.name));
    if (candidates.length === 0) continue;
    const club = pickAcrossLeagues(candidates);
    usedNames.add(club.name);
    offers.push({ club, contractYears: rand2(2, 4), wage: wageForTier(tier, overall), transferFee: 0 });
  }
  return offers;
}
function realisticTransferFee(overall, age) {
  let minFee, maxFee;
  if (overall >= 95) {
    if (age <= 22) {
      minFee = 220;
      maxFee = 300;
    } else if (age <= 26) {
      minFee = 250;
      maxFee = 320;
    } else if (age <= 29) {
      minFee = 190;
      maxFee = 260;
    } else if (age <= 32) {
      minFee = 80;
      maxFee = 140;
    } else {
      minFee = 30;
      maxFee = 70;
    }
  } else if (overall >= 90) {
    if (age <= 22) {
      minFee = 150;
      maxFee = 220;
    } else if (age <= 26) {
      minFee = 170;
      maxFee = 240;
    } else if (age <= 29) {
      minFee = 120;
      maxFee = 180;
    } else if (age <= 32) {
      minFee = 50;
      maxFee = 90;
    } else {
      minFee = 20;
      maxFee = 45;
    }
  } else if (overall >= 85) {
    if (age <= 22) {
      minFee = 80;
      maxFee = 130;
    } else if (age <= 26) {
      minFee = 100;
      maxFee = 160;
    } else if (age <= 29) {
      minFee = 70;
      maxFee = 110;
    } else if (age <= 32) {
      minFee = 25;
      maxFee = 55;
    } else {
      minFee = 10;
      maxFee = 30;
    }
  } else if (overall >= 80) {
    if (age <= 22) {
      minFee = 40;
      maxFee = 75;
    } else if (age <= 26) {
      minFee = 55;
      maxFee = 90;
    } else if (age <= 29) {
      minFee = 35;
      maxFee = 65;
    } else if (age <= 32) {
      minFee = 12;
      maxFee = 30;
    } else {
      minFee = 5;
      maxFee = 15;
    }
  } else if (overall >= 75) {
    if (age <= 22) {
      minFee = 20;
      maxFee = 45;
    } else if (age <= 26) {
      minFee = 28;
      maxFee = 55;
    } else if (age <= 29) {
      minFee = 15;
      maxFee = 35;
    } else {
      minFee = 5;
      maxFee = 18;
    }
  } else if (overall >= 65) {
    minFee = 1;
    maxFee = 8;
  } else {
    minFee = 0.1;
    maxFee = 1;
  }
  return Math.round((minFee + Math.random() * (maxFee - minFee)) * 10) / 10;
}
function feeDescription(feeMillions) {
  if (feeMillions > 200) return pick2(["record breaking transfer", "the most expensive signing in football history"]);
  if (feeMillions >= 150) return pick2(["extraordinary transfer fee", "among the most expensive moves in history"]);
  if (feeMillions >= 100) return pick2(["mega money move", "one of the biggest deals of the season"]);
  if (feeMillions >= 60) return pick2(["huge transfer", "blockbuster deal"]);
  if (feeMillions >= 30) return pick2(["big money move", "major signing"]);
  if (feeMillions >= 15) return pick2(["significant transfer", "notable signing"]);
  if (feeMillions >= 5) return pick2(["decent transfer fee", "solid investment"]);
  if (feeMillions >= 1) return pick2(["modest fee", "reasonable deal", "solid signing"]);
  return pick2(["budget signing", "low cost move", "bargain deal"]);
}
function initCareer(playerName, nationality, position, era, stats, overall, startYear, clubs, appearance, potential, physique, attrShape) {
  const academyClub = getYouthAcademyClub(adjustClubsForYear(clubs, startYear), nationality, overall);
  const seedTexts = pickPhoneTexts(16, "youth", [], 1);
  const created = {
    playerName,
    nationality,
    position,
    era,
    age: 16,
    // Round 78: the hidden ceiling this career will fight to reach.
    // Round 79: clamped above the final overall, since the point-spend build
    // editor can nudge a keeper's overall a few points past the roll.
    /* Round 131: clamped at 99 as well as floored above the overall. Without
       the clamp a player who built himself to 99 on the creation screen was
       handed a ceiling of 101, a number the growth code can never reach, which
       quietly turned the wall off for exactly the player who most needs it. */
    potential: Math.min(99, Math.max(potential ?? rollPotential(overall), overall + 2)),
    potentialEarned: 0,
    eliteStreak: 0,
    startingOverall: overall,
    physique: safePhysique(position, physique ?? defaultPhysique(position)),
    attrShape: safeShape(position, attrShape),
    // Round 80: the phone starts neutral with one text waiting on day one
    karma: 50,
    phoneUsedIds: seedTexts.map((d) => d.id),
    phoneInbox: seedTexts.map((def) => ({
      id: `${def.id}-${startYear}`,
      defId: def.id,
      from: def.from,
      emoji: def.emoji,
      text: def.text,
      year: startYear,
      choices: def.choices
    })),
    currentClub: `${academyClub.name} Youth`,
    currentClubCountry: academyClub.country,
    currentClubTier: academyClub.tier,
    currentClubColor: academyClub.color,
    currentLeague: academyClub.league,
    contractYearsLeft: 2,
    weeklyWage: 500,
    marketValue: 0.1,
    ...stats,
    overall,
    seasons: [{
      year: startYear,
      age: 16,
      club: `${academyClub.name} Youth`,
      clubCountry: academyClub.country,
      clubTier: academyClub.tier,
      apps: 0,
      goals: 0,
      assists: 0,
      cleanSheets: 0,
      yellowCards: 0,
      redCards: 0,
      rating: 0,
      leagueTitle: false,
      domesticCup: false,
      championsLeague: false,
      worldCup: false,
      ballonDor: false,
      ballonDorRank: null,
      type: "youth",
      intApps: 0,
      intGoals: 0,
      intAssists: 0,
      intRating: 0,
      tournament: null,
      tournamentResult: null
    }],
    events: [`\u{1F4CB} Joined ${academyClub.name} Youth Academy aged 16`],
    retired: false,
    phase: "youth",
    pendingOffers: [],
    pendingSummary: null,
    transferSituation: null,
    loan: null,
    pendingLoanOffers: null,
    pendingEvents: [],
    lastEventId: null,
    statBoostNextSeason: {},
    pendingNews: [],
    internationalCareer: false,
    sponsorDeal: null,
    totalEarnings: 0,
    popularity: 10,
    morale: 70,
    isLeader: false,
    hasRelationship: false,
    intStats: {
      caps: 0,
      goals: 0,
      assists: 0,
      tournaments: 0,
      worldCups: 0,
      continentals: 0,
      worldCupWins: 0,
      continentalWins: 0,
      isCaptain: false,
      isRetired: false,
      debutYear: null,
      debutAge: null,
      worldCupResults: [],
      squadSnubs: 0,
      failedQualifications: 0
    },
    pendingWorldCup: null,
    pendingTournament: null,
    lastTournament: null,
    intlHistory: [],
    rival: null,
    rivalCreated: false,
    pendingRivalryEvent: null,
    lastRivalryEventId: null,
    rivalrySummary: null,
    netWorth: 0,
    lifestyleLevel: "Humble",
    lifestyleCostPerYear: 0.02,
    socialMediaFollowers: 0,
    sponsorshipIncome: 0,
    properties: [],
    investments: [],
    consecutiveDeficitYears: 0,
    agentFeesPaid: 0,
    family: { isMarried: false, marriedAge: null, children: 0, isDivorced: false, divorceAge: null },
    purchasedItems: [],
    investmentHoldings: [],
    totalAssetValue: 0,
    customYearlyCosts: 0,
    awards: [],
    pendingBallonDor: null,
    lastUCLResult: null,
    legacy: null,
    postRetirementChoice: null,
    managerState: null,
    isFinalSeason: false,
    isPundit: false,
    punditEvents: [],
    primeType: rollPrimeType(),
    socialMediaActionUsedThisSeason: false,
    socialMediaFocusBoost: false,
    pendingCoverAthleteEvent: false,
    coverAthleteAccepted: false,
    activeSponsorship: null,
    personality: null,
    agentId: null,
    lifeFlags: {},
    appearance: appearance ?? null,
    corruptionHeat: 0,
    dirtyMoney: 0,
    prisonSeasons: 0,
    academyClubName: academyClub.name,
    moralDilemmasTriggered: [],
    pendingMoralDilemma: null,
    pedSeasonsRemaining: 0,
    pedActive: false,
    matchFixBanned: 0,
    divingActive: false,
    integrityBonus: 0,
    pendingAppealResult: null,
    childEventsSeen: [],
    pregnancyAnnounced: false,
    punditState: null,
    ownerState: null,
    peakOverall: overall,
    retirementSuggested: false,
    /* Round 130: the phone gets its own random stream so replying to a text
       can never shift the world sim's dice. That is what makes a "did I bother
       messaging" A/B test in the harness honest. */
    phone: {
      threads: [],
      feed: [],
      world: null,
      clubs: {},
      rivalClub: null,
      seed: Math.floor(Math.random() * 4294967295) >>> 0 || 7,
      offers: 0,
      perksTaken: 0
    }
  };
  for (const m of created.phoneInbox ?? []) {
    mirrorLegacyMessage(created, m.id, m.from, m.text, m.year);
  }
  phoneSeasonTick(created, "youth");
  return created;
}
function advanceYouthYear(prev, clubs) {
  const s = repairCareer({ ...prev });
  s.age += 1;
  s.story = archiveSeasonStory(s);
  s.events = [];
  receivePhoneTexts(s, "youth");
  const pot = effectivePotential(s);
  const devY = developmentRate(s);
  s.pace = growStat(s.pace, s.age, true, true, s.primeType, pot, s.overall, devY);
  s.shooting = growStat(s.shooting, s.age, true, false, s.primeType, pot, s.overall, devY);
  s.passing = growStat(s.passing, s.age, true, false, s.primeType, pot, s.overall, devY);
  s.dribbling = growStat(s.dribbling, s.age, true, false, s.primeType, pot, s.overall, devY);
  s.defending = growStat(s.defending, s.age, true, false, s.primeType, pot, s.overall, devY);
  s.physical = growStat(s.physical, s.age, true, false, s.primeType, pot, s.overall, devY);
  s.reflexes = growStat(s.reflexes, s.age, true, false, s.primeType, pot, s.overall, devY);
  s.overall = calcOverall(s, s.position);
  if (applyAcademyFocus(s, pot) > 0) s.overall = calcOverall(s, s.position);
  const lastYear = s.seasons[s.seasons.length - 1].year;
  s.seasons = [...s.seasons, {
    year: lastYear + 1,
    age: s.age,
    club: s.currentClub,
    clubCountry: s.currentClubCountry,
    clubTier: s.currentClubTier,
    apps: rand2(10, 25),
    goals: s.position === "GK" ? 0 : rand2(0, 8),
    assists: rand2(0, 5),
    cleanSheets: s.position === "GK" || s.position === "CB" || s.position === "LB" || s.position === "RB" ? rand2(2, 8) : 0,
    yellowCards: rand2(0, 4),
    redCards: 0,
    rating: 0,
    leagueTitle: false,
    domesticCup: false,
    championsLeague: false,
    worldCup: false,
    ballonDor: false,
    ballonDorRank: null,
    type: "youth",
    intApps: 0,
    intGoals: 0,
    intAssists: 0,
    intRating: 0,
    tournament: null,
    tournamentResult: null
  }];
  s.events.push(`\u{1F4C8} Stats improved during youth development (OVR ${s.overall})`);
  moneySeasonTick2(s, s.seasons[s.seasons.length - 1].year);
  if (s.age >= 17) {
    s.events.push("\u{1F4E9} Professional contract offers received!");
    const academyName = s.academyClubName || (s.currentClub.endsWith(" Youth") ? s.currentClub.slice(0, -6) : void 0);
    s.pendingOffers = generateContractOffers(adjustClubsForYear(clubs, lastYear + 1), s.overall, s.age, academyName);
    s.phase = "contract_offer";
  }
  s.marketValue = calcMarketValue(s.overall, s.age, s.position);
  return s;
}
function acceptOffer(prev, offer2) {
  const s = { ...prev };
  s.currentClub = offer2.club.name;
  s.currentClubCountry = offer2.club.country;
  s.currentClubTier = offer2.club.tier;
  s.currentClubColor = offer2.club.color;
  s.currentLeague = offer2.club.league;
  s.contractYearsLeft = offer2.contractYears;
  s.weeklyWage = Math.round(offer2.wage * agentWageMult(prev.agentId));
  s.frozenOut = 0;
  s.badSeasonStreak = 0;
  s.phase = "playing";
  s.pendingOffers = [];
  s.transferSituation = null;
  s.pendingLoanOffers = null;
  const feeRate = agentTransferCutRate(prev.agentId);
  const agentFee = offer2.transferFee > 0 ? Math.round(offer2.transferFee * feeRate * 100) / 100 : 0;
  if (agentFee > 0) {
    s.agentFeesPaid = Math.round((s.agentFeesPaid + agentFee) * 100) / 100;
    s.events = [...s.events, `\u270D\uFE0F Signed with ${offer2.club.name} ${getFlag(offer2.club.country)} (${offer2.contractYears}yr, ${formatWage(s.weeklyWage)}) \xB7 Agent fee: \u20AC${agentFee.toFixed(1)}M`];
  } else {
    s.events = [...s.events, `\u270D\uFE0F Signed with ${offer2.club.name} ${getFlag(offer2.club.country)} (${offer2.contractYears}yr, ${formatWage(s.weeklyWage)})`];
  }
  endClubCaptaincy(s, "transfer");
  if (offer2.isHomegrown) {
    s.popularity = clamp7(s.popularity + 10, 0, 100);
    s.morale = clamp7(s.morale + 8, 0, 100);
    const cameThrough = prev.academyClubName && offer2.club.name === prev.academyClubName || prev.currentClub === `${offer2.club.name} Youth`;
    s.events.push(cameThrough && prev.currentClub.endsWith(" Youth") ? `\u{1F3E0} One of our own! The ${offer2.club.name} academy kid signs a first-team deal. The ultras already have a chant ready.` : `\u{1F3E0} THE HOMECOMING! ${s.playerName} returns to ${offer2.club.name}, the club that raised them. Scenes outside the stadium.`);
  }
  return s;
}
function shouldGetCallUp(state) {
  if (state.intStats.isRetired) return false;
  if (state.age < 18 || state.age > 33) return false;
  const threshold = state.currentClubTier <= 2 ? 70 : 72;
  return state.overall >= threshold;
}
function playerFormOf(state) {
  const last = state.seasons[state.seasons.length - 1];
  return {
    overall: state.overall,
    position: state.position,
    lastRating: last?.rating ?? 6.8,
    lastGoals: last?.goals ?? 0,
    age: state.age,
    isCaptain: state.intStats.isCaptain
  };
}
function generateIntSeasonStats(state, year) {
  if (!state.internationalCareer || state.intStats.isRetired) {
    return { intApps: 0, intGoals: 0, intAssists: 0, intRating: 0, tournament: null, tournamentResult: null };
  }
  const form = playerFormOf(state);
  if (!pickSquad(state.nationality, form).called) {
    return { intApps: 0, intGoals: 0, intAssists: 0, intRating: 0, tournament: null, tournamentResult: null };
  }
  const apps = offYearCaps(form);
  const goals = calcGoals(state.position, apps);
  const assists = calcAssists(state.position, apps);
  const rating = clamp7(parseFloat((6.5 + (state.overall - 72) * 0.06 + (Math.random() - 0.3) * 1).toFixed(1)), 4, 10);
  return { intApps: apps, intGoals: goals, intAssists: assists, intRating: rating, tournament: null, tournamentResult: null };
}
function runTournamentSummer(s, season2, year, out = false) {
  const fmt = tournamentForYear(s.nationality, year);
  if (!fmt) return;
  const eligible = !out && s.internationalCareer && !s.intStats.isRetired && !s.retired;
  const t = runInternationalSummer(s.nationality, year, eligible ? playerFormOf(s) : null);
  if (!t) return;
  s.lastTournament = t;
  s.intlHistory = [...s.intlHistory ?? [], toHistoryEntry(t, eligible)];
  season2.tournament = t.name;
  season2.tournamentResult = eligible ? t.myResult : null;
  if (t.champion === s.nationality && !eligible) {
    s.events.push(`\u{1F3C6} ${s.nationality} won the ${t.name} without you.`);
  } else if (t.champion !== s.nationality) {
    s.events.push(`\u{1F30D} ${t.champion} won the ${t.name}.`);
  }
  if (!eligible) return;
  s.pendingTournament = t;
  if (!t.qualified) {
    s.intStats = {
      ...s.intStats,
      failedQualifications: (s.intStats.failedQualifications ?? 0) + 1
    };
    s.events.push(`\u{1F61E} ${s.nationality} did not qualify for the ${t.name}. Your summer is free.`);
    s.morale = clamp7(s.morale - 8, 0, 100);
    return;
  }
  if (!t.squad?.called) {
    s.intStats = { ...s.intStats, squadSnubs: (s.intStats.squadSnubs ?? 0) + 1 };
    s.events.push(`\u{1F4CB} Left out of the ${s.nationality} squad for the ${t.name}. You watch it at home.`);
    s.morale = clamp7(s.morale - 12, 0, 100);
    return;
  }
  const isWC = t.kind === "World Cup";
  s.intStats = {
    ...s.intStats,
    caps: s.intStats.caps + t.playerApps,
    goals: s.intStats.goals + t.playerGoals,
    assists: s.intStats.assists + t.playerAssists,
    tournaments: s.intStats.tournaments + 1,
    worldCups: s.intStats.worldCups + (isWC ? 1 : 0),
    continentals: s.intStats.continentals + (isWC ? 0 : 1)
  };
  season2.intApps += t.playerApps;
  season2.intGoals += t.playerGoals;
  season2.intAssists += t.playerAssists;
  if (t.myResult === "Winner") {
    if (isWC) {
      s.intStats = { ...s.intStats, worldCupWins: s.intStats.worldCupWins + 1 };
      season2.worldCup = true;
      s.events.push(`\u{1F3C6} WORLD CUP WINNER with ${s.nationality}!`);
    } else {
      s.intStats = { ...s.intStats, continentalWins: s.intStats.continentalWins + 1 };
      season2.continentalCup = true;
      s.events.push(`\u{1F3C6} Won the ${t.name} with ${s.nationality}!`);
    }
    s.popularity = clamp7(s.popularity + (isWC ? 20 : 12), 0, 100);
    s.morale = clamp7(s.morale + 15, 0, 100);
  } else if (t.myResult === "Runner-up") {
    s.events.push(`\u{1F948} Lost the ${t.name} final with ${s.nationality}.`);
    s.morale = clamp7(s.morale - 5, 0, 100);
  }
  if (t.bestPlayer) {
    s.events.push(`\u{1F31F} Named Best Player of the ${t.name}!`);
    s.awards = [...s.awards, { year, name: `${t.short} Best Player`, emoji: "\u{1F31F}" }];
  }
  if (t.goldenBoot) {
    s.awards = [...s.awards, { year, name: `${t.short} Golden Boot`, emoji: "\u{1F45F}" }];
    s.events.push(`\u{1F45F} Won the ${t.name} Golden Boot with ${t.playerGoals} goals!`);
  }
}
function awardClubCaptaincy(s, viaVote) {
  if (s.isClubCaptain ?? false) return;
  s.isClubCaptain = true;
  s.captainClub = s.currentClub;
  s.captainSeasons = 0;
  s.isLeader = true;
  s.morale = clamp7(s.morale + 10, 0, 100);
  s.popularity = clamp7(s.popularity + 5, 0, 100);
  s.events.push(viaVote ? "\xA9\uFE0F Voted club captain by the dressing room" : `\xA9\uFE0F Handed the ${s.currentClub} armband. The manager wants his voice on the pitch`);
}
function endClubCaptaincy(s, reason, year) {
  if (!(s.isClubCaptain ?? false)) return;
  const n = s.captainSeasons ?? 0;
  const club = s.captainClub ?? s.currentClub;
  if (n >= 1) {
    const endYear = year ?? (s.seasons.length > 0 ? s.seasons[s.seasons.length - 1].year : 0);
    s.awards = [...s.awards ?? [], {
      year: endYear,
      name: `Club Captain of ${club} (${n} season${n === 1 ? "" : "s"})`,
      emoji: "\xA9\uFE0F"
    }];
  }
  s.isClubCaptain = false;
  s.captainClub = null;
  if (reason === "transfer") s.events.push(`\xA9\uFE0F The ${club} armband stays behind. A new captain will be chosen`);
  else if (reason === "loan") s.events.push(`\xA9\uFE0F The armband stays at ${club} while he is away`);
  else if (reason === "handover") s.events.push(`\xA9\uFE0F Passed the captaincy on after ${n} season${n === 1 ? "" : "s"} wearing it. The dressing room stood and clapped`);
  else s.events.push(n >= 1 ? `\xA9\uFE0F Retires as a club captain: ${n} season${n === 1 ? "" : "s"} with the ${club} armband` : "\xA9\uFE0F Hands back the armband on the way out");
}
function advanceProSeason(prev, clubs) {
  const s = repairCareer({ ...prev });
  s.age += 1;
  s.story = archiveSeasonStory(s);
  s.events = [];
  receivePhoneTexts(s, "pro");
  s.socialMediaActionUsedThisSeason = false;
  payFocusBoost(s, SOCCER_SOCIAL);
  if (s.matchFixBanned > 0) {
    s.matchFixBanned -= 1;
    s.events.push(`\u{1F6AB} Serving match-fixing ban (${s.matchFixBanned > 0 ? s.matchFixBanned + " season(s) remaining" : "ban lifted!"})`);
    if (s.matchFixBanned > 0) {
      const lastYear = s.seasons[s.seasons.length - 1].year;
      s.seasons = [...s.seasons, {
        year: lastYear + 1,
        age: s.age,
        club: "BANNED",
        clubCountry: "",
        clubTier: 99,
        apps: 0,
        goals: 0,
        assists: 0,
        cleanSheets: 0,
        yellowCards: 0,
        redCards: 0,
        rating: 0,
        leagueTitle: false,
        domesticCup: false,
        championsLeague: false,
        worldCup: false,
        ballonDor: false,
        ballonDorRank: null,
        type: "playing",
        intApps: 0,
        intGoals: 0,
        intAssists: 0,
        intRating: 0,
        tournament: null,
        tournamentResult: null
      }];
      s.pendingSummary = s.seasons[s.seasons.length - 1];
      s.phase = "season_summary";
      simulateSeasonFinances(s, s.pendingSummary);
      return s;
    }
  }
  if ((s.prisonSeasons ?? 0) > 0) {
    s.prisonSeasons = (s.prisonSeasons ?? 0) - 1;
    for (const k of ["pace", "shooting", "passing", "dribbling", "defending", "physical", "reflexes"]) {
      s[k] = clamp7(s[k] - rand2(3, 5), 20, 99);
    }
    s.overall = calcOverall(s, s.position);
    s.marketValue = calcMarketValue(s.overall, s.age, s.position);
    s.morale = clamp7(s.morale - 15, 0, 100);
    s.events.push(s.prisonSeasons > 0 ? `\u26D3\uFE0F A year served. ${s.prisonSeasons} more to go. You run laps of the yard to stay sharp.` : "\u26D3\uFE0F RELEASED. You walk out to forty cameras and one loyal agent. The comeback starts now.");
    const lastYearP = s.seasons[s.seasons.length - 1].year;
    s.seasons = [...s.seasons, {
      year: lastYearP + 1,
      age: s.age,
      club: "PRISON",
      clubCountry: "",
      clubTier: 99,
      apps: 0,
      goals: 0,
      assists: 0,
      cleanSheets: 0,
      yellowCards: 0,
      redCards: 0,
      rating: 0,
      leagueTitle: false,
      domesticCup: false,
      championsLeague: false,
      worldCup: false,
      ballonDor: false,
      ballonDorRank: null,
      type: "playing",
      intApps: 0,
      intGoals: 0,
      intAssists: 0,
      intRating: 0,
      tournament: null,
      tournamentResult: null
    }];
    s.pendingSummary = s.seasons[s.seasons.length - 1];
    s.phase = "season_summary";
    simulateSeasonFinances(s, s.pendingSummary);
    return s;
  }
  const dirtyNow = s.dirtyMoney ?? 0;
  if (dirtyNow > 0) {
    let washCapacity = 0;
    if (s.purchasedItems.includes("shady_shell_carwash")) washCapacity += 2;
    if (s.purchasedItems.includes("shady_nightclub")) washCapacity += 4;
    if (s.purchasedItems.includes("shady_crypto_mixer")) washCapacity += 1.5;
    if (washCapacity > 0) {
      const washed = Math.min(dirtyNow, washCapacity);
      s.dirtyMoney = Math.round((dirtyNow - washed) * 100) / 100;
      s.netWorth = Math.round((s.netWorth + washed) * 100) / 100;
      s.events.push(`\u{1F9FC} The businesses had a "great year": \u20AC${washed.toFixed(1)}M of quiet money is now clean.`);
    }
    if ((s.dirtyMoney ?? 0) > 0) {
      s.corruptionHeat = clamp7((s.corruptionHeat ?? 0) + 6, 0, 100);
      s.events.push(`\u{1F4BC} \u20AC${(s.dirtyMoney ?? 0).toFixed(1)}M still sits in the duffel bags. Money that loud attracts ears.`);
    }
  } else if ((s.corruptionHeat ?? 0) > 0) {
    s.corruptionHeat = clamp7((s.corruptionHeat ?? 0) - 8, 0, 100);
  }
  const heat = s.corruptionHeat ?? 0;
  if (heat >= 90 && Math.random() < 0.5) {
    const confiscated = Math.round(((s.dirtyMoney ?? 0) + s.netWorth * 0.3) * 100) / 100;
    s.dirtyMoney = 0;
    s.netWorth = Math.round(s.netWorth * 0.7 * 100) / 100;
    s.prisonSeasons = 1;
    s.corruptionHeat = 20;
    s.popularity = clamp7(s.popularity - 35, 0, 100);
    s.integrityBonus -= 30;
    s.events.push(`\u2696\uFE0F CONVICTED. Fraud, bribery, and one very confused judge reading out the submarine receipts. \u20AC${confiscated.toFixed(1)}M seized, 1 year inside.`);
    const disgrace = soccerCriticDisgraceArticle(s, NEWSPAPERS);
    s.pendingNews = [{
      newspaper: "The Daily Sport",
      type: "negative",
      headline: `GUILTY: ${s.playerName} Going To Prison`,
      body: `The fall is complete. ${s.playerName} was convicted on all counts after prosecutors traced years of unexplained income. The courtroom sketch artist gave them enormous sad eyes and the internet made it a meme within the hour.`
    }, {
      newspaper: disgrace.paper,
      type: "negative",
      headline: disgrace.headline,
      body: disgrace.body
    }];
    s.seasons = [...s.seasons, yearOutRow(s, "CONVICTED")];
    simulateSeasonFinances(s, s.seasons[s.seasons.length - 1]);
    runTournamentSummer(s, s.seasons[s.seasons.length - 1], s.seasons[s.seasons.length - 1].year, true);
    s.phase = "newspaper";
    return s;
  } else if (heat >= 70 && Math.random() < 0.35) {
    const fine = Math.round((s.netWorth * 0.2 + (s.dirtyMoney ?? 0) * 0.5) * 100) / 100;
    s.netWorth = Math.round((s.netWorth - fine) * 100) / 100;
    s.dirtyMoney = Math.round((s.dirtyMoney ?? 0) * 0.5 * 100) / 100;
    s.corruptionHeat = clamp7(heat - 30, 0, 100);
    s.popularity = clamp7(s.popularity - 15, 0, 100);
    s.integrityBonus -= 10;
    s.events.push(`\u{1F694} DAWN RAID. Financial crimes unit, seven vans, one very smug spokesperson. Settled for \u20AC${fine.toFixed(1)}M to avoid charges.`);
  }
  if (s.pedActive && s.pedSeasonsRemaining > 0) {
    s.pedSeasonsRemaining -= 1;
    if (Math.random() < 0.2) {
      s.pedActive = false;
      s.pedSeasonsRemaining = 0;
      for (const k of ["pace", "shooting", "passing", "dribbling", "defending", "physical", "reflexes"]) {
        s[k] = clamp7(s[k] - 5, 20, 99);
      }
      s.matchFixBanned = 1;
      s.integrityBonus -= 25;
      s.popularity = clamp7(s.popularity - 30, 0, 100);
      s.morale = clamp7(s.morale - 25, 0, 100);
      s.socialMediaFollowers = Math.max(0, s.socialMediaFollowers - 3);
      s.events.push("\u{1F6A8} FAILED DRUG TEST! Banned for 1 season. Legacy -25, reputation destroyed.");
      const lastYear = s.seasons[s.seasons.length - 1].year;
      s.seasons = [...s.seasons, {
        year: lastYear + 1,
        age: s.age,
        club: "BANNED (PED)",
        clubCountry: "",
        clubTier: 99,
        apps: 0,
        goals: 0,
        assists: 0,
        cleanSheets: 0,
        yellowCards: 0,
        redCards: 0,
        rating: 0,
        leagueTitle: false,
        domesticCup: false,
        championsLeague: false,
        worldCup: false,
        ballonDor: false,
        ballonDorRank: null,
        type: "playing",
        intApps: 0,
        intGoals: 0,
        intAssists: 0,
        intRating: 0,
        tournament: null,
        tournamentResult: null
      }];
      s.pendingSummary = s.seasons[s.seasons.length - 1];
      s.phase = "season_summary";
      simulateSeasonFinances(s, s.pendingSummary);
      return s;
    }
    if (s.pedSeasonsRemaining === 0) {
      s.pedActive = false;
      for (const k of ["pace", "shooting", "passing", "dribbling", "defending", "physical", "reflexes"]) {
        s[k] = clamp7(s[k] - 5, 20, 99);
      }
      s.events.push("\u{1F48A} The substance wore off. Stats returned to normal.");
    }
  }
  if (s.overall > s.peakOverall) s.peakOverall = s.overall;
  if (s.overall < 50 && s.age >= 33 || s.age >= 45) {
    s.retired = true;
    const reason = s.age >= 45 ? "\u{1F44B} Hung up the boots at 45. An incredible career!" : "\u{1F44B} Body can no longer keep up. Forced retirement";
    s.events.push(reason);
    const lastYr = s.seasons[s.seasons.length - 1].year;
    s.seasons = [...s.seasons, {
      year: lastYr + 1,
      age: s.age,
      club: s.currentClub,
      clubCountry: s.currentClubCountry,
      clubTier: s.currentClubTier,
      apps: 0,
      goals: 0,
      assists: 0,
      cleanSheets: 0,
      yellowCards: 0,
      redCards: 0,
      rating: 0,
      leagueTitle: false,
      domesticCup: false,
      championsLeague: false,
      worldCup: false,
      ballonDor: false,
      ballonDorRank: null,
      type: "retired",
      intApps: 0,
      intGoals: 0,
      intAssists: 0,
      intRating: 0,
      tournament: null,
      tournamentResult: null
    }];
    endClubCaptaincy(s, "retirement");
    if (s.rival) s.rivalrySummary = generateRivalrySummary(s);
    s.legacy = calculateLegacy(s);
    s.phase = "retirement_ceremony";
    return s;
  }
  if (!s.retirementSuggested && s.age >= 30) {
    const dropFromPeak = s.peakOverall - s.overall;
    if (dropFromPeak >= 10 || s.overall <= 75) {
      s.retirementSuggested = true;
      s.phase = "retirement_suggestion";
      return s;
    }
  }
  if (s.age >= 34 && s.overall <= 65 && Math.random() < 0.4) {
    s.phase = "retirement_suggestion";
    return s;
  }
  return playPendingProSeason(s, clubs);
}
var INT_SCORING_RECORDS = {
  Argentina: 126,
  Belgium: 94,
  Brazil: 80,
  Colombia: 36,
  Croatia: 45,
  Egypt: 69,
  England: 91,
  France: 67,
  Germany: 71,
  Italy: 35,
  Japan: 75,
  Netherlands: 55,
  Nigeria: 37,
  Norway: 65,
  Portugal: 146,
  "South Korea": 59,
  Spain: 59,
  Uruguay: 69
};
function awardAllTimeTopScorer(s, thisYear) {
  if (!s.internationalCareer) return;
  const record3 = INT_SCORING_RECORDS[s.nationality];
  if (record3 === void 0) return;
  const intGoals = s.intStats.goals;
  if (intGoals <= record3 || s.awards.some((a) => a.name === "All Time Top Scorer")) return;
  s.awards = [...s.awards, { year: thisYear, name: "All Time Top Scorer", emoji: "\u{1F451}" }];
  s.events.push(`\u{1F451} Became ${s.nationality}'s All Time Top International Scorer with ${intGoals} goals!`);
}
function playPendingProSeason(s, clubs) {
  const season2 = generateSeasonStats(s, clubs);
  if (season2.injury) s.events.push(`\u{1F691} Injury: ${season2.injury}, out ${season2.injuryWeeks} weeks, missed matches`);
  applySeasonDerbies(s, season2);
  if (season2.injury) {
    if (season2.injurySevere) {
      s.morale = clamp7(s.morale - 10, 0, 100);
      s.pendingRehab = {
        name: season2.injury,
        weeks: season2.injuryWeeks ?? 16,
        /* the season being played is one past the last one recorded; the
           2020 fallback matches the convention used elsewhere in this
           file for a career with no seasons behind it yet */
        year: s.seasons.length > 0 ? s.seasons[s.seasons.length - 1].year + 1 : 2020,
        specialistCost: s.netWorth >= 1.6 ? 0.8 : null
      };
      const injuryRow = { ...season2, leagueTitle: false, leagueFinish: void 0, leagueSize: void 0, domesticCup: false };
      if (s.loan) injuryRow.onLoanFrom = s.loan.parentClub;
      s.seasons = [...s.seasons, injuryRow];
      simulateSeasonFinances(s, injuryRow);
      runTournamentSummer(s, injuryRow, injuryRow.year, true);
      s.phase = "rehab_choice";
      return s;
    }
  }
  for (const [key, val] of Object.entries(s.statBoostNextSeason)) {
    const k = key;
    if (k in s) s[k] = clamp7(s[k] + (val || 0), 20, 99);
  }
  s.statBoostNextSeason = {};
  const potWall = effectivePotential(s);
  const dev = developmentRate(s, season2);
  s.pace = growStat(s.pace, s.age, false, true, s.primeType, potWall, s.overall, dev);
  s.shooting = growStat(s.shooting, s.age, false, false, s.primeType, potWall, s.overall, dev);
  s.passing = growStat(s.passing, s.age, false, false, s.primeType, potWall, s.overall, dev);
  s.dribbling = growStat(s.dribbling, s.age, false, false, s.primeType, potWall, s.overall, dev);
  s.defending = growStat(s.defending, s.age, false, false, s.primeType, potWall, s.overall, dev);
  s.physical = growStat(s.physical, s.age, false, false, s.primeType, potWall, s.overall, dev);
  if (s.purchasedItems.includes("personal_trainer")) {
    s.physical = clamp7(s.physical + 1, 20, 99);
  }
  s.reflexes = growStat(s.reflexes, s.age, false, false, s.primeType, potWall, s.overall, dev);
  s.overall = calcOverall(s, s.position);
  s.contractYearsLeft = Math.max(0, s.contractYearsLeft - 1);
  s.marketValue = calcMarketValue(s.overall, s.age, s.position, s.socialMediaFollowers);
  if (!s.internationalCareer && !s.intStats.isRetired && shouldGetCallUp(s)) {
    s.internationalCareer = true;
    s.intStats = { ...s.intStats, debutYear: season2.year, debutAge: s.age };
  }
  const lastYear = s.seasons.length > 0 ? s.seasons[s.seasons.length - 1].year : season2.year - 1;
  const thisYear = lastYear + 1;
  const intSeason = generateIntSeasonStats(s, thisYear);
  if (intSeason.intApps > 0) {
    s.intStats = {
      ...s.intStats,
      caps: s.intStats.caps + intSeason.intApps,
      goals: s.intStats.goals + intSeason.intGoals,
      assists: s.intStats.assists + intSeason.intAssists
    };
    if (!s.intStats.isCaptain && s.intStats.caps >= 30 && s.overall >= 80 && Math.random() < 0.25) {
      s.intStats = { ...s.intStats, isCaptain: true };
      s.events.push(`\xA9\uFE0F Named captain of ${s.nationality}! Legacy +15`);
      s.popularity = clamp7(s.popularity + 15, 0, 100);
    }
    const prevCaps = s.intStats.caps - intSeason.intApps;
    if (s.intStats.caps >= 100 && prevCaps < 100) {
      s.events.push(`\u{1F396}\uFE0F INTERNATIONAL LEGEND: reached 100 caps for ${s.nationality}!`);
    }
  }
  if (!(s.isClubCaptain ?? false) && !s.loan && s.age >= CAPTAIN_MIN_AGE && s.overall >= CAPTAIN_MIN_RATING) {
    const tenure = s.seasons.filter((ss) => ss.club === s.currentClub && ss.type === "playing").length;
    if (tenure >= 2) {
      const chance = 0.18 + (s.isLeader ? 0.15 : 0) + (s.academyClubName === s.currentClub ? 0.1 : 0) + Math.min(0.15, (tenure - 2) * 0.05);
      if (Math.random() < chance) awardClubCaptaincy(s, false);
    }
  }
  season2.intApps = intSeason.intApps;
  season2.intGoals = intSeason.intGoals;
  season2.intAssists = intSeason.intAssists;
  season2.intRating = intSeason.intRating;
  season2.tournament = intSeason.tournament;
  season2.tournamentResult = intSeason.tournamentResult;
  if (!s.rivalCreated && s.age >= 19 && s.age <= 21 && Math.random() < 0.6) {
    s.rival = createRival(s, clubs);
    s.rivalCreated = true;
    s.events.push(`\u{1F624} A new rival emerges: ${s.rival.name} (${getFlag(s.rival.nationality)} ${s.rival.nationality})`);
  } else if (!s.rivalCreated && s.age === 21) {
    s.rival = createRival(s, clubs);
    s.rivalCreated = true;
    s.events.push(`\u{1F624} A new rival emerges: ${s.rival.name} (${getFlag(s.rival.nationality)} ${s.rival.nationality})`);
  }
  if (s.rival && !s.rival.retired) {
    s.rival = simulateRivalSeason(s.rival, clubs, thisYear);
  }
  const rolledRivalry = rollRivalryEvent(s, s.rival, s.lastRivalryEventId, SOCCER_RIVALRY_EVENTS, Math.random);
  if (rolledRivalry) s.pendingRivalryEvent = rolledRivalry;
  const forcedRivalry = forcedRetirementEvent(s, s.rival, s.lastRivalryEventId, SOCCER_RIVALRY_EVENTS, 105);
  if (forcedRivalry) s.pendingRivalryEvent = forcedRivalry;
  const uclResult = simulateUCL(s, season2);
  s.lastUCLResult = uclResult;
  if (uclResult.qualified) {
    const isUcl = (uclResult.cup ?? "ucl") === "ucl";
    const cupName = uclResult.competition ?? "Champions League";
    const wonCup = uclResult.result === "Winner";
    season2.championsLeague = isUcl && wonCup;
    if (wonCup && !isUcl) season2.clubCupTitle = cupName;
    if (wonCup) s.events.push(`\u2B50 Won the ${cupName}!`);
    else if (uclResult.result === "Final") s.events.push(`\u2B50 Reached the ${cupName} Final`);
    else if (uclResult.result === "Group Stage" || uclResult.result === "League Phase") {
      const where = uclResult.result === "League Phase" ? "league phase" : "group stage";
      s.events.push(`\u{1F613} Out of the ${cupName} in the ${where}`);
    }
    if (uclResult.isTopScorer) {
      s.awards = [...s.awards, { year: thisYear, name: isUcl ? "UCL Top Scorer" : `${cupName} Top Scorer`, emoji: "\u26BD" }];
      s.events.push(`\u26BD Won the ${cupName} Golden Boot!`);
    }
  }
  if (season2.leagueTitle) s.events.push(`\u{1F3C6} Won the league with ${s.currentClub}!`);
  if (season2.domesticCup) s.events.push(`\u{1F3C6} Won the ${seasonCupTitle(season2, s)} with ${s.currentClub}!`);
  const MONTHS = ["August", "September", "October", "November", "December", "January", "February", "March", "April", "May"];
  const potmTotalGoals = season2.goals;
  const potmTotalApps = season2.apps;
  let potmCount = 0;
  const potmMonths = [];
  for (const month of MONTHS) {
    const monthGoals = Math.max(0, Math.round(potmTotalGoals / 10 + (Math.random() * 2 - 1)));
    let chance = 0.02;
    if (monthGoals >= 4) chance = 0.75;
    else if (monthGoals >= 3) chance = 0.5;
    else if (monthGoals >= 2) chance = 0.25;
    else if (monthGoals >= 1) chance = 0.1;
    if (Math.random() < chance) {
      potmCount++;
      potmMonths.push(month);
    }
  }
  if (potmTotalGoals >= 30 && potmCount < 6) {
    const remaining = MONTHS.filter((m) => !potmMonths.includes(m));
    while (potmCount < 6 && remaining.length > 0) {
      const idx = rand2(0, remaining.length - 1);
      potmMonths.push(remaining.splice(idx, 1)[0]);
      potmCount++;
    }
  }
  if (potmTotalGoals >= 35 && potmCount < 7) {
    const remaining = MONTHS.filter((m) => !potmMonths.includes(m));
    while (potmCount < 7 && remaining.length > 0) {
      const idx = rand2(0, remaining.length - 1);
      potmMonths.push(remaining.splice(idx, 1)[0]);
      potmCount++;
    }
  }
  if (potmCount > 0) {
    for (const month of potmMonths) {
      s.awards = [...s.awards, { year: thisYear, name: "Player of the Month", emoji: "\u{1F3C6}" }];
      s.events.push(`\u{1F3C6} Won Player of the Month (${month} ${thisYear})!`);
    }
  }
  if (season2.rating >= 8 && s.overall >= 82 && Math.random() < 0.25) {
    s.awards = [...s.awards, { year: thisYear, name: "Player of the Year", emoji: "\u{1F31F}" }];
    s.events.push(`\u{1F31F} Won Domestic Player of the Year!`);
    s.popularity = clamp7(s.popularity + 10, 0, 100);
  }
  if (s.internationalCareer && season2.intApps >= 6 && season2.intRating >= 7.5 && s.overall >= 83 && Math.random() < 0.15) {
    s.awards = [...s.awards, { year: thisYear, name: "International Player of the Year", emoji: "\u{1F30D}" }];
    s.events.push(`\u{1F30D} Named International Player of the Year!`);
  }
  if (season2.goals >= 15 && s.overall >= 80 && Math.random() < 0.08) {
    s.awards = [...s.awards, { year: thisYear, name: "Pusk\xE1s Award", emoji: "\u{1F3AF}" }];
    s.events.push(`\u{1F3AF} Won the Pusk\xE1s Award for Goal of the Year!`);
  }
  if (season2.goals >= 25 && s.currentClubTier <= 2 && Math.random() < 0.3) {
    s.awards = [...s.awards, { year: thisYear, name: "Golden Boot", emoji: "\u{1F45F}" }];
    s.events.push(`\u{1F45F} Won the League Golden Boot with ${season2.goals} goals!`);
  }
  if (s.position === "GK" && season2.cleanSheets >= 12 && season2.rating >= 7.5 && Math.random() < 0.3) {
    s.awards = [...s.awards, { year: thisYear, name: "Golden Glove", emoji: "\u{1F9E4}" }];
    s.events.push(`\u{1F9E4} Won the Golden Glove Award!`);
  }
  if (s.age < 23 && season2.rating >= 7.5 && s.overall >= 75 && Math.random() < 0.2) {
    s.awards = [...s.awards, { year: thisYear, name: "Young Player of the Year", emoji: "\u2B50" }];
    s.events.push(`\u2B50 Named Young Player of the Year!`);
    s.popularity = clamp7(s.popularity + 5, 0, 100);
  }
  if (season2.championsLeague && season2.rating >= 8 && s.overall >= 85 && Math.random() < 0.25) {
    s.awards = [...s.awards, { year: thisYear, name: "UEFA Player of the Year", emoji: "\u{1F1EA}\u{1F1FA}" }];
    s.events.push(`\u{1F1EA}\u{1F1FA} Named UEFA Player of the Year!`);
  }
  const prevSeasons = s.seasons.filter((ss) => ss.type === "playing");
  if (prevSeasons.length >= 2) {
    const prevRating = prevSeasons[prevSeasons.length - 1]?.rating || 0;
    if (prevRating <= 6.5 && season2.rating >= 7.8 && Math.random() < 0.3) {
      s.awards = [...s.awards, { year: thisYear, name: "Comeback Player of the Year", emoji: "\u{1F4AA}" }];
      s.events.push(`\u{1F4AA} Won Comeback Player of the Year!`);
    }
  }
  const clubAppsMap = {};
  for (const ss of s.seasons) {
    if (ss.type === "playing") clubAppsMap[ss.club] = (clubAppsMap[ss.club] || 0) + ss.apps;
  }
  clubAppsMap[s.currentClub] = (clubAppsMap[s.currentClub] || 0) + season2.apps;
  const alreadyClubLegend = s.awards.some((a) => a.name === "Club Legend");
  if (!alreadyClubLegend && clubAppsMap[s.currentClub] >= 300) {
    s.awards = [...s.awards, { year: thisYear, name: "Club Legend", emoji: "\u{1F3DB}\uFE0F" }];
    s.events.push(`\u{1F3DB}\uFE0F Granted Club Legend status at ${s.currentClub}! (300+ appearances)`);
    s.popularity = clamp7(s.popularity + 15, 0, 100);
  }
  if (season2.yellowCards <= 1 && season2.redCards === 0 && season2.rating >= 7.5 && season2.apps >= 25 && Math.random() < 0.1) {
    const alreadyFairPlayThisYear = s.awards.some((a) => a.name === "Fair Play Award" && a.year === thisYear);
    if (!alreadyFairPlayThisYear) {
      s.awards = [...s.awards, { year: thisYear, name: "Fair Play Award", emoji: "\u{1F91D}" }];
      s.events.push(`\u{1F91D} Won the Fair Play Award for exemplary conduct!`);
    }
  }
  const totalGoals = s.seasons.reduce((sum, ss) => sum + ss.goals, 0) + season2.goals;
  const totalApps = s.seasons.reduce((sum, ss) => sum + ss.apps, 0) + season2.apps;
  if (totalGoals >= 100 && totalGoals - season2.goals < 100) s.events.push("\u{1F4AF} Reached 100 career goals!");
  if (totalGoals >= 200 && totalGoals - season2.goals < 200) s.events.push("\u{1F525} Reached 200 career goals!");
  if (totalGoals >= 500 && totalGoals - season2.goals < 500) s.events.push("\u{1F451} Reached 500 career goals!");
  if (totalApps >= 500 && totalApps - season2.apps < 500) s.events.push("\u{1F396}\uFE0F Made 500th career appearance!");
  if (s.loan) season2.onLoanFrom = s.loan.parentClub;
  if ((s.isClubCaptain ?? false) && s.captainClub === s.currentClub) {
    s.captainSeasons = (s.captainSeasons ?? 0) + 1;
  } else if ((s.isClubCaptain ?? false) && s.captainClub !== s.currentClub) {
    endClubCaptaincy(s, "transfer", season2.year);
  }
  if ((s.isClubCaptain ?? false) && s.age >= 33 && s.overall <= 74) {
    endClubCaptaincy(s, "handover", season2.year);
    s.popularity = clamp7(s.popularity + 3, 0, 100);
  }
  s.seasons = [...s.seasons, season2];
  if (s.frozenOut && s.frozenOut > 0) {
    s.frozenOut -= 1;
    if (s.frozenOut === 0) {
      s.events.push(`\u{1F9CA} A season in the cold at ${s.currentClub} is over. You are back in the group and back in the reckoning.`);
    }
  }
  s.pendingSummary = season2;
  const news = generateNewsArticles(s, season2, totalGoals, totalApps);
  s.pendingNews = news;
  s.phase = news.length > 0 ? "newspaper" : "season_summary";
  simulateSeasonFinances(s, season2);
  if (s.contractYearsLeft <= 1) s.events.push("\u26A0\uFE0F Your contract is expiring!");
  runTournamentSummer(s, season2, thisYear);
  awardAllTimeTopScorer(s, thisYear);
  const cupAssoc = seasonCupAssociation(season2, s);
  const world = worldSeasonTick(s, {
    year: thisYear,
    playerLeagueTitle: season2.leagueTitle,
    playerUcl: season2.championsLeague,
    playerCup: season2.domesticCup,
    /* Round 1041: a cup belongs to an association, not a league */
    playerCupAssociation: cupAssoc,
    cupAssociationOf: (name) => {
      const c = clubs.find((x) => x.name === name) ?? FALLBACK_CLUBS.find((x) => x.name === name);
      return c ? cupAssociation(c.country, c.league) : null;
    }
  });
  {
    const worldLeague = worldLeagueOf(cupAssoc);
    const run = drawCupRun({
      status: cupFor(cupAssoc, season2.year),
      club: season2.club,
      year: season2.year,
      won: season2.domesticCup,
      chance: cupChanceFor({ elite: eliteInYear(ELITE_CLUBS, season2.club, season2.year), tier: season2.clubTier, performanceBoost: seasonPerformanceBoost(season2.ovr ?? s.overall, season2.rating) }),
      clubs,
      worldWinner: worldLeague ? world.cups[worldLeague] ?? null : null,
      goals: season2.goals,
      apps: season2.apps,
      seedKey: `${s.playerName}|${season2.club}|${season2.year}|${season2.apps}|${season2.goals}|${season2.assists}|${season2.rating}`
    });
    if (run) season2.cupRun = run;
  }
  settleAwardsNight(SOCCER_BALLON_DOR, s, season2, calculateBallonDor(s, season2, thisYear, world));
  if (s.intStats.debutYear === thisYear) {
    s.events.push(`\u{1F1FA}\u{1F1F3} First international call-up for ${s.nationality}!`);
  }
  pushCeiling(s, season2);
  if (s.events.length === 0) s.events.push(`\u26BD Solid season at ${s.currentClub}`);
  if (s.loan) {
    const back = s.loan;
    s.currentClub = back.parentClub;
    s.currentClubTier = back.parentTier;
    s.currentLeague = back.parentLeague;
    s.currentClubCountry = back.parentCountry;
    s.currentClubColor = back.parentColor;
    s.loan = null;
    const backSeasons = s.seasons.filter((ss) => ss.club === back.parentClub && ss.type === "playing").length;
    const nextHere = projectLeagueApps(s.overall, back.parentTier, back.parentClub, backSeasons);
    if (nextHere.min >= 20) {
      s.morale = clamp7(s.morale + 5, 0, 100);
      s.events.push(`\u{1F519} Loan over. Back at ${back.parentClub}, and this time they are planning around you: about ${nextHere.min} to ${nextHere.max} league games on the table.`);
    } else {
      s.events.push(`\u{1F519} Loan over. Back at ${back.parentClub}, and the pecking order has not moved much: about ${nextHere.min} to ${nextHere.max} league games unless something changes.`);
    }
  }
  return s;
}
function pushCeiling(s, season2) {
  const ceiling = effectivePotential(s);
  const elite = (season2.rating ?? 0) >= 7.5 && (season2.apps ?? 0) >= 30;
  const topLevel = (season2.clubTier ?? 4) <= 2;
  const decorated = !!(season2.championsLeague || season2.worldCup || season2.ballonDor) || topLevel && (!!season2.leagueTitle || !!season2.clubCupTitle || (season2.goals ?? 0) >= 30 || (season2.rating ?? 0) >= 8.2);
  const pressing = s.overall >= ceiling - 2;
  if (elite && decorated) s.eliteStreak = (s.eliteStreak ?? 0) + 1;
  else {
    s.eliteStreak = 0;
    return;
  }
  if (!pressing || ceiling >= 99) return;
  if ((s.eliteStreak ?? 0) < 2) return;
  s.potentialEarned = (s.potentialEarned ?? 0) + 1;
  s.events.push("\u{1F513} Another season like that at your ceiling. The coaches say there is more in you than anybody thought");
}
var NEWSPAPERS = ["The Daily Sport", "Football Weekly", "The Global Game", "Soccer Times", "The Beautiful Game Report", "The Daily Nutmeg", "El Golazo", "Tackle Weekly", "The Sunday Volley", "90+4 Magazine"];
function generateNewsArticles(s, season2, totalGoals, totalApps) {
  const articles = [];
  const name = s.playerName;
  const club = s.currentClub;
  const pos = s.position;
  const ovr = s.overall;
  const yearsPlaying = s.seasons.filter((ss) => ss.type === "playing").length;
  const firstClub = s.seasons.find((ss) => ss.type === "playing")?.club || club;
  const seasonsAtClub = s.seasons.filter((ss) => ss.club === club && ss.type === "playing").length;
  const templates = [
    {
      weight: 1,
      check: () => season2.goals >= 2 && season2.rating >= 7.5,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "positive",
        headline: `${name} Silences Critics With Stunning Performance`,
        body: `${name} put in an outstanding display for ${club} this season, netting ${season2.goals} goals and reminding the world of their immense talent. Pundits are running out of superlatives.`
      })
    },
    {
      weight: 1,
      check: () => ovr >= 88,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "positive",
        headline: `Is ${name} The Best ${pos} In The World Right Now?`,
        body: `With an overall rating of ${ovr}, ${name} continues to operate at a level few can match. Experts across the globe are debating whether the ${s.nationality} star has now surpassed every rival at ${pos}.`
      })
    },
    {
      weight: 1,
      check: () => season2.rating >= 7.8,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "positive",
        headline: `${name} Named In Team Of The Season`,
        body: `After averaging a ${season2.rating.toFixed(1)} rating across ${season2.apps} appearances, ${name} has been selected in the official Team of the Season. A thoroughly deserved recognition.`
      })
    },
    {
      weight: 1,
      check: () => s.marketValue >= 50 && s.currentClubTier > 1,
      gen: () => {
        const elites = ["Real Madrid", "Barcelona", "Manchester City", "Bayern Munich", "PSG", "Liverpool"];
        return {
          newspaper: pick2(NEWSPAPERS),
          type: "transfer",
          headline: `Transfer Rumours: ${pick2(elites)} Eyeing ${name} In Summer Window`,
          body: `Sources close to the deal suggest a bid of \u20AC${Math.round(s.marketValue)}M is being prepared. The ${s.nationality} international has been in outstanding form and could be set for a big move.`
        };
      }
    },
    {
      weight: 1,
      check: () => totalGoals > 0 && (totalGoals === 100 || totalGoals === 200 || totalGoals === 300 || totalGoals === 500),
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "milestone",
        headline: `${name} Breaks Club Record For Goals`,
        body: `With ${totalGoals} career goals to their name, ${name} has written themselves into the history books. An emotional moment at ${club} as teammates and fans celebrate the milestone.`
      })
    },
    {
      weight: 1,
      check: () => yearsPlaying >= 5 && s.currentClubTier <= 2 && ovr >= 78,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "positive",
        headline: `FROM ZERO TO HERO: ${name}'s Incredible Rise From ${firstClub} To The Top`,
        body: `${yearsPlaying} years ago, ${name} was an unknown prospect at ${firstClub}. Now at ${club}, the ${s.nationality} star has become one of football's most remarkable success stories. "I never gave up," they revealed.`
      })
    },
    {
      weight: 1,
      check: () => seasonsAtClub >= 2 && s.popularity >= 50,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "positive",
        headline: `${name} Voted Fan Favourite At ${club}`,
        body: `After ${seasonsAtClub} seasons of dedication, the ${club} faithful have spoken: ${name} is their Player of the Year. The bond between player and fans has become something truly special.`
      })
    },
    {
      weight: 1,
      check: () => s.isLeader && (season2.leagueTitle || season2.domesticCup || season2.championsLeague || !!season2.clubCupTitle),
      gen: () => {
        const trophy = season2.championsLeague ? "Champions League" : season2.clubCupTitle ? season2.clubCupTitle : season2.leagueTitle ? "League Title" : seasonCupTitle(season2, s);
        return {
          newspaper: pick2(NEWSPAPERS),
          type: "positive",
          headline: `CAPTAIN FANTASTIC: ${name} Leads ${club} To ${trophy} Glory`,
          body: `Wearing the armband with pride, ${name} delivered when it mattered most. A season that will live long in the memory of every ${club} supporter.`
        };
      }
    },
    {
      weight: 0.5,
      check: () => ovr >= 80 && s.popularity >= 60,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "positive",
        headline: `${name} Reveals Secret To Success In Exclusive Interview: 'I Never Stopped Believing'`,
        body: `In a rare sit-down interview, ${name} opened up about the sacrifices, the doubts, and the determination that drove them to the top. "Every setback was a lesson," the ${pos} reflected.`
      })
    },
    {
      weight: 0.5,
      check: () => s.socialMediaFollowers >= 1e6,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "positive",
        headline: `SOCIAL MEDIA SENSATION: ${name} Hits ${formatFollowers(s.socialMediaFollowers)} Followers After Viral Moment`,
        body: `${name} broke the internet this week after a viral clip racked up millions of views. The ${club} star's social media presence continues to grow at a staggering pace.`
      })
    },
    {
      weight: 1,
      check: () => season2.rating < 6.3 && season2.apps < 20,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "negative",
        headline: `CRISIS AT ${club.toUpperCase()}: ${name} Dropped From Squad After Poor Run Of Form`,
        body: `Sources inside the dressing room confirm that ${name} has been left out of the matchday squad following a disappointing spell. With just ${season2.apps} appearances and a ${season2.rating.toFixed(1)} average rating, questions are mounting.`
      })
    },
    {
      weight: 0.7,
      check: () => season2.rating < 6,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "negative",
        headline: `${name} Booed By Own Fans After Another Disappointing Display`,
        body: `Ugly scenes at ${club} as sections of the crowd turned on ${name} after another below-par performance. The ${s.nationality} international looked visibly shaken as boos rang around the stadium.`
      })
    },
    {
      weight: 0.5,
      check: () => s.contractYearsLeft <= 1 && s.morale < 50,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "negative",
        headline: `TRANSFER SAGA: ${name} Wants Out As Contract Talks Collapse`,
        body: `Negotiations between ${name}'s representatives and ${club} have broken down completely. With just ${s.contractYearsLeft} year${s.contractYearsLeft !== 1 ? "s" : ""} remaining, the club face losing their star for a cut-price fee.`
      })
    },
    {
      weight: 0.5,
      check: () => season2.apps < 15 && s.age < 34,
      gen: () => {
        const injuries = ["knee ligament damage", "hamstring tear", "ankle fracture", "groin injury", "shoulder dislocation"];
        return {
          newspaper: pick2(NEWSPAPERS),
          type: "negative",
          headline: `INJURY BLOW: ${name} Could Miss Months With Serious ${pick2(injuries).split(" ").map((w) => w[0].toUpperCase() + w.slice(1)).join(" ")}`,
          body: `${club} have been dealt a devastating blow after scans confirmed ${name} faces an extended spell on the sidelines. The ${pos} managed only ${season2.apps} appearances this season.`
        };
      }
    },
    {
      weight: 0.3,
      check: () => s.morale < 40,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "negative",
        headline: `CONTROVERSY: ${name} Hits Out At Manager In Shock Interview`,
        body: `In a bombshell interview, ${name} publicly criticised the management at ${club}, claiming they have been "disrespected and undervalued." The fallout is expected to dominate headlines for weeks.`
      })
    },
    {
      weight: 1,
      check: () => s.age >= 30 && ovr < 75 && season2.rating < 6.5,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "negative",
        headline: `HAS ${name.toUpperCase()} LOST IT? Former Star Struggles At ${club}`,
        body: `Once one of football's brightest talents, ${name} is now a shadow of their former self. At ${s.age}, the ${pos} averaged just ${season2.rating.toFixed(1)} this campaign. Time may finally be catching up.`
      })
    },
    {
      weight: 0.4,
      check: () => s.weeklyWage > 2e5 && s.contractYearsLeft <= 2,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "negative",
        headline: `WAGE DEMANDS SHOCK ${club.toUpperCase()} As ${name} Agent Demands Record Deal`,
        body: `${name}'s agent has reportedly demanded a staggering ${formatWage(Math.round(s.weeklyWage * 1.5))} weekly wage to extend their stay at ${club}. Board members are said to be "stunned" by the figures.`
      })
    },
    {
      weight: 0.5,
      check: () => s.rival !== null && !s.rival.retired && s.rival.ballonDors > 0,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "negative",
        headline: `RIVALS TAUNT ${name.toUpperCase()} After ${s.rival.name} Wins Ballon d'Or Again`,
        body: `Social media erupted as ${s.rival.name} claimed another Ballon d'Or, with fans of the ${s.rival.nationality} star flooding ${name}'s channels with taunts. The rivalry shows no signs of cooling down.`
      })
    },
    {
      weight: 0.7,
      check: () => s.marketValue >= 30,
      gen: () => {
        const bidders = ["Real Madrid", "Barcelona", "Manchester City", "PSG", "Chelsea", "Bayern Munich"];
        const bidClub = pick2(bidders.filter((b) => b !== club));
        const bidFee = realisticTransferFee(ovr, s.age);
        const desc = feeDescription(bidFee);
        return {
          newspaper: pick2(NEWSPAPERS),
          type: "transfer",
          headline: `${bidClub} Launch \u20AC${Math.round(bidFee)}M Bid For ${name} In ${desc.charAt(0).toUpperCase() + desc.slice(1)}`,
          body: `${bidClub} have made an audacious move for ${name}, tabling a ${desc} worth \u20AC${bidFee.toFixed(1)}M. ${club} are yet to respond but are understood to be reluctant to sell.`
        };
      }
    },
    {
      weight: 1,
      check: () => {
        const playingSzns = s.seasons.filter((ss) => ss.type === "playing");
        return playingSzns.length >= 2 && playingSzns[playingSzns.length - 1].club !== playingSzns[playingSzns.length - 2]?.club;
      },
      gen: () => {
        const prev = s.seasons.filter((ss) => ss.type === "playing");
        const oldClub = prev.length >= 2 ? prev[prev.length - 2].club : "Unknown";
        const fee = realisticTransferFee(ovr, s.age);
        const desc = feeDescription(fee);
        return {
          newspaper: pick2(NEWSPAPERS),
          type: "transfer",
          headline: `DONE DEAL: ${name} Signs For ${club} In ${desc.charAt(0).toUpperCase() + desc.slice(1)}`,
          body: `${name} has completed their move from ${oldClub} to ${club} in a ${desc} worth \u20AC${fee.toFixed(1)}M. The ${s.nationality} ${pos} is expected to make an immediate impact.`
        };
      }
    },
    {
      weight: 0.5,
      check: () => s.contractYearsLeft === 0,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "transfer",
        headline: `FREE AGENT FRENZY: ${name} Available On Free Transfer`,
        body: `${name} is officially a free agent after their contract at ${club} expired. Multiple top clubs are reportedly circling for what could be the bargain of the window.`
      })
    },
    {
      weight: 1,
      check: () => totalGoals >= 100 && totalGoals - season2.goals < 100,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "milestone",
        headline: `${name} Scores 100th Career Goal In Emotional Moment`,
        body: `There were tears of joy as ${name} reached the magical 100-goal mark for their career. The ${club} star celebrated with teammates and fans in an unforgettable moment.`
      })
    },
    {
      weight: 1,
      check: () => s.intStats.caps >= 100 && s.intStats.caps - (season2.intApps || 0) < 100,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "milestone",
        headline: `CENTURION: ${name} Earns 100th International Cap`,
        body: `${name} was given a guard of honour by teammates before earning their 100th cap for ${s.nationality}. An incredible achievement for the veteran ${pos}.`
      })
    },
    {
      weight: 1,
      check: () => s.isFinalSeason,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "milestone",
        headline: `LEGEND STATUS: ${name} Announces Retirement After ${yearsPlaying} Year Career`,
        body: `In an emotional press conference, ${name} confirmed this will be their final season as a professional footballer. ${yearsPlaying} years, ${totalGoals} goals, and countless memories. A true legend of the game.`
      })
    },
    // ── Round 54: twenty more stories. The papers now cover your snubs, your
    // scandals, your shopping and your softest moments. ──
    {
      weight: 1.4,
      check: () => s.bdorSnubFuel === true && season2.goals >= 25,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "negative",
        headline: `ROBBED! Fans Fume As ${name} Misses Out On Ballon d'Or AGAIN`,
        body: `${season2.goals} goals and still no golden ball. Social media has already produced 4,000 conspiracy charts, a petition, and one very angry podcast episode. "The voters watch highlights on mute," wrote one fan. Hard to argue.`
      })
    },
    {
      weight: 1.2,
      check: () => (s.corruptionHeat ?? 0) >= 50,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "negative",
        headline: `WHERE DOES THE MONEY COME FROM? Questions Mount Over ${name}'s Empire`,
        body: `An investigative series has begun sniffing around ${name}'s business affairs. A car wash that outsells the national chain. A nightclub with no music license. Nothing proven, the lawyers stress. Yet.`
      })
    },
    {
      weight: 1,
      check: () => (s.dirtyMoney ?? 0) > 3,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "negative",
        headline: `THE DUFFEL BAG FILES: Mystery Cash Linked To ${name}'s Circle`,
        body: `A leaked memo describes "sports bags of unusual weight" moving through ${name}'s entourage. The player's spokesperson called the story "gym equipment." The gym in question could not be located.`
      })
    },
    {
      weight: 1.3,
      check: () => s.seasons.filter((ss) => ss.club === "PRISON").length > 0 && season2.apps > 0 && season2.rating >= 7,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "positive",
        headline: `REDEMPTION: ${name} Is Officially BACK`,
        body: `From a cell to ${season2.goals} goals. Whatever you think of the past, ${name}'s comeback season at ${club} is one of the great sporting redemption stories. The away fans still sing about it. The home fans sing louder.`
      })
    },
    {
      weight: 1,
      check: () => s.purchasedItems.includes("flex_tiger"),
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "negative",
        headline: `${name}'s Pet Tiger Escapes Garden, Delays Training`,
        body: `Butters the tiger was found napping in a neighbour's gazebo on Tuesday. Animal control described the situation as "genuinely outside our training." ${name} apologised and bought the street lunch. The tiger remains extremely large.`
      })
    },
    {
      weight: 0.8,
      check: () => s.purchasedItems.includes("superyacht") || s.purchasedItems.includes("private_island"),
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "negative",
        headline: `OUT OF TOUCH? ${name}'s Latest Purchase Raises Eyebrows`,
        body: `As ticket prices climb, photos of ${name}'s newest toy did the rounds this week. A club source shrugged: "They scored ${season2.goals} this season, they can buy a moon." Fans remain split roughly 50-50 between outrage and requests for a ride.`
      })
    },
    {
      weight: 1,
      check: () => s.family.children > 0 && season2.goals >= 15,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "positive",
        headline: `DAD GOALS: ${name} Celebrates Every Strike With The Kids In The Stands`,
        body: `The now-famous routine, goal, run to the family section, ${s.family.children > 1 ? "high-five the kids" : "lift the little one"}, has become the league's most wholesome tradition. Cameras cut to the family before the ball even hits the net now.`
      })
    },
    {
      weight: 0.9,
      check: () => s.personality === "showman" && s.socialMediaFollowers >= 5,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "positive",
        headline: `BOX OFFICE: Every ${name} Match Is A Show Now`,
        body: `Nutmegs, no-look passes, a celebration catalogue deeper than most players' highlight reels. Purists grumble. Everyone else buys tickets. "I play football," ${name} shrugged, "the theatre is free."`
      })
    },
    {
      weight: 0.9,
      check: () => s.personality === "iceman" && season2.rating >= 7.5,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "positive",
        headline: `THE MACHINE: ${name} Never Celebrates, Never Blinks, Never Misses`,
        body: `Another ${season2.goals}-goal season delivered with the emotional range of a filing cabinet. Teammates say they have seen ${name} smile twice. Both times were at tactics boards.`
      })
    },
    {
      weight: 0.9,
      check: () => s.personality === "hothead" && (season2.yellowCards >= 8 || season2.redCards >= 1),
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "negative",
        headline: `TICKING TIME BOMB: ${name} Walks Disciplinary Tightrope AGAIN`,
        body: `${season2.yellowCards} yellows${season2.redCards > 0 ? ` and ${season2.redCards} red` : ""} this season. The talent is undeniable, the temper is unmissable. The league's referees have reportedly started a group chat.`
      })
    },
    {
      weight: 1,
      check: () => s.academyClubName !== void 0 && club === s.academyClubName && seasonsAtClub >= 3 && ovr >= 80,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "positive",
        headline: `ONE OF OUR OWN: ${name} Is ${club}'s Greatest Homegrown Story`,
        body: `From the academy pitches to ${season2.goals} goals a season, ${name} never needed to leave to become world class. The club shop cannot print the name fast enough. There are babies in this town named after a ${pos}.`
      })
    },
    {
      weight: 0.8,
      check: () => season2.goals >= 30 && s.age <= 21,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "positive",
        headline: `WONDERKID ALERT: ${s.age}-Year-Old ${name} Breaks The Scouting Apps`,
        body: `${season2.goals} goals at ${s.age}. Scouts from every superclub attended the last home game, and one reportedly cried. Comparisons to legends are premature, say pundits, before making seven of them in the same sentence.`
      })
    },
    {
      weight: 0.7,
      check: () => s.morale >= 85 && season2.rating >= 7.3,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "positive",
        headline: `HAPPIEST MAN IN FOOTBALL: The Secret To ${name}'s Golden Season`,
        body: `Sources close to the player credit "family, sleep, and turning the phone off." Whatever it is, it produced a ${season2.rating.toFixed(1)} average rating and the widest grin in the league.`
      })
    },
    {
      weight: 0.7,
      check: () => s.weeklyWage >= 4e5,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "transfer",
        headline: `${formatWage(s.weeklyWage)} A WEEK: Inside ${name}'s Monster Contract`,
        body: `Leaked figures put ${name} among the best paid players alive. The club insists the deal "reflects performance." The performance this season: ${season2.goals} goals, ${season2.assists} assists. The accountants have stopped complaining.`
      })
    },
    {
      weight: 0.6,
      check: () => s.intStats.isCaptain && (season2.intApps || 0) > 0,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "positive",
        headline: `LEADER OF THE NATION: ${name} Wears The ${s.nationality} Armband Like Armour`,
        body: `Since taking the captaincy, ${name} has turned the national side into a family business. Teammates describe the pre-match speeches as "somewhere between a sermon and a heist briefing."`
      })
    },
    {
      weight: 0.6,
      check: () => s.purchasedItems.includes("fam_parents_house"),
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "positive",
        headline: `THE PROMISE: ${name} Bought Mum The House, And The Video Broke The Internet`,
        body: `The clip of ${name}'s mother opening her new front door has passed 40 million views. "I told her when I was nine," the player said, and that was all anyone needed. Not a dry eye in the press room.`
      })
    },
    {
      weight: 0.6,
      check: () => season2.cleanSheets >= 15 && pos === "GK",
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "positive",
        headline: `THE WALL: ${name} Posts ${season2.cleanSheets} Clean Sheets, Strikers In Therapy`,
        body: `Opposition forwards have begun passing backwards on sight of ${name}. ${season2.cleanSheets} shutouts this season, and at least three saves that appeared to violate physics. The league is investigating the goalkeeper for witchcraft. (It is not.)`
      })
    },
    {
      weight: 0.6,
      check: () => s.rival !== null && !s.rival.retired && (s.rivalryIntensity ?? 0) >= 60,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "negative",
        headline: `THE FEUD: ${name} vs ${s.rival.name} Is Football's Coldest War`,
        body: `No handshake. No eye contact. One suspiciously timed unfollow. The rivalry between ${name} and ${s.rival.name} now has its own fan wikis, timeline threads, and at least one university thesis.`
      })
    },
    /* Round 473: this used to say "crossed into billionaire territory" and it
       fired at a net worth of 500, which is half a billion, and 500 is a
       number 120 seeded careers never once reached (the richest got to 252).
       So the milestone is now the one the money in this game can actually
       produce, it counts the same three pots the badge case counts, and it
       states a fact rather than an amount nobody has. */
    {
      weight: 0.5,
      check: () => s.netWorth + (s.totalAssetValue || 0) + moneyWealth2(s) >= 100,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "milestone",
        headline: `NINE FIGURES: ${name}'s Money Now Works Harder Than ${name} Does`,
        body: `Boots, brands, buildings and a market account: added up, what ${name} is worth is a nine figure number. The accountant replied to the news with one line and a full stop. Nobody in the dressing room has stopped bringing it up since.`
      })
    },
    {
      weight: 0.5,
      check: () => s.age >= 36 && season2.goals >= 15,
      gen: () => ({
        newspaper: pick2(NEWSPAPERS),
        type: "positive",
        headline: `AGELESS: ${s.age}-Year-Old ${name} Refuses To Read The Calendar`,
        body: `${season2.goals} goals at ${s.age}. Nutritionists want the meal plan, scientists want the bloodwork, defenders want it to stop. "I will retire when it stops being fun," ${name} smiled, ominously, at everyone under 30.`
      })
    }
  ];
  const out = [];
  const column = soccerCriticArticle(s, season2, NEWSPAPERS);
  if (column) {
    out.push({
      newspaper: column.paper,
      type: column.hostile ? "negative" : "positive",
      headline: column.headline,
      body: column.body
    });
  }
  const eligible = templates.filter((t) => t.check());
  if (eligible.length === 0) return out;
  const count = out.length === 0 && eligible.length >= 2 && Math.random() < 0.5 ? 2 : 1;
  const shuffled = eligible.sort(() => Math.random() - 0.5).sort((a, b) => b.weight - a.weight);
  for (const t of shuffled.slice(0, count)) out.push(t.gen());
  return out;
}
function dismissNewspaper(prev) {
  const s = { ...prev };
  s.pendingNews = [];
  if (!s.pendingSummary && (s.prisonSeasons ?? 0) > 0) {
    const lastRow = s.seasons[s.seasons.length - 1];
    if (lastRow && lastRow.age < s.age) {
      s.events = [...s.events];
      s.seasons = [...s.seasons, yearOutRow(s, "CONVICTED")];
      simulateSeasonFinances(s, s.seasons[s.seasons.length - 1]);
      runTournamentSummer(s, s.seasons[s.seasons.length - 1], s.seasons[s.seasons.length - 1].year, true);
    }
  }
  s.phase = s.pendingSummary ? "season_summary" : "playing";
  return s;
}
function uclLegGoals(lambda) {
  return poissonGoals(lambda, Math.random);
}
function simulateUCL(state, season2) {
  const tier = state.currentClubTier;
  const notIn = { qualified: false, matches: [], result: "N/A", playerGoals: 0, isTopScorer: false };
  if (tier > 2) return notIn;
  const uclYear = state.seasons.length > 0 ? state.seasons[state.seasons.length - 1].year + 1 : 2024;
  const cupFor2 = clubCupFor(state.currentClubCountry ?? "", uclYear);
  if (!cupFor2) return notIn;
  const isUcl = cupFor2.cup === "ucl";
  const period = periodFor(uclYear);
  const competition = isUcl ? period.name : cupFor2.period.name;
  const isEliteUCL = ELITE_CLUBS.includes(state.currentClub);
  const eliteBonus = isEliteUCL ? 0.15 : tier === 1 ? 0.08 : 0;
  const targetAt = (roundIndex) => clamp7(0.3 + (state.overall - 75) * 0.012 + eliteBonus - roundIndex * 0.04, 0.15, 0.75);
  const reachKnockout = tier === 1 ? 0.85 : 0.35;
  const shape = isUcl ? firstStageShape(uclYear) : null;
  const hasFirstStage = shape !== null && shape.kind !== "none";
  const passTarget = hasFirstStage ? firstStageTarget(targetAt(0), reachKnockout) : 1;
  const qualChance = reachKnockout / passTarget;
  if (Math.random() > qualChance) return notIn;
  const rounds = shape ? [...shape.ladder] : [...CONTINENTAL_LADDER];
  const tieLegs = isUcl ? period.koLegs ?? 1 : 2;
  const finalLegs = isUcl ? 1 : cupFor2.period.finalLegs;
  const awayGoalsApply = isUcl && uclYear >= UCL_AWAY_GOALS.introduced && uclYear <= UCL_AWAY_GOALS.lastSeason;
  const opponents = isUcl ? getEraUclOpponents(uclYear).filter((o) => o !== state.currentClub) : continentalOpponents(FALLBACK_CLUBS, cupFor2.confederation, uclYear, state.currentClub);
  const matches = [];
  let totalPlayerGoals = 0;
  const usedOpponents = /* @__PURE__ */ new Set([state.currentClub]);
  const isAttacker = ["ST", "CAM", "LW", "RW"].includes(state.position);
  const legPlayerGoals = (legs) => {
    const share = legs === 2 ? 0.5 : 1;
    if (state.position === "GK") return 0;
    if (isAttacker) return Math.random() < 0.4 * share ? rand2(1, 2) : 0;
    return Math.random() < 0.1 * share ? 1 : 0;
  };
  let firstStage;
  let stageGames = 0;
  if (hasFirstStage && shape) {
    const named = [];
    for (let i = 0; i < firstStageOpponentCount(shape); i++) {
      const available = opponents.filter((o2) => !usedOpponents.has(o2));
      const o = available.length > 0 ? pick2(available) : `Unknown FC ${i + 1}`;
      usedOpponents.add(o);
      named.push(o);
    }
    const strength = solveStageStrength(shape.curve, passTarget, targetAt(0));
    firstStage = playFirstStage(shape, state.currentClub, strength, named, Math.random, () => legPlayerGoals(2));
    for (const st of firstStage.stages) {
      for (const g of st.games) {
        totalPlayerGoals += g.playerGoals;
        stageGames += 1;
      }
    }
    if (!firstStage.through && !firstStage.playoff) {
      return {
        qualified: true,
        matches,
        result: shape.kind === "leaguePhase" ? "League Phase" : "Group Stage",
        playerGoals: totalPlayerGoals,
        isTopScorer: false,
        competition,
        cup: cupFor2.cup,
        firstStage
      };
    }
    if (firstStage.playoff) rounds.unshift("PO");
  }
  const ladder = rounds.filter((r) => r !== "PO");
  let out = false;
  for (const round of rounds) {
    if (out) break;
    const available = opponents.filter((o) => !usedOpponents.has(o));
    const opponent = available.length > 0 ? pick2(available) : "Unknown FC";
    usedOpponents.add(opponent);
    const legs = round === "Final" ? finalLegs : round === "PO" ? 2 : tieLegs;
    const target = targetAt(round === "PO" ? 0 : ladder.indexOf(round));
    const spread = Math.sqrt(2 * legs * UCL_BASE_LAMBDA);
    const edge = uclProbit(target) * spread / (2 * legs);
    let aggFor = 0;
    let aggAgainst = 0;
    const legRows = [];
    for (let leg = 1; leg <= legs; leg++) {
      const home = legs === 2 ? leg === 1 : false;
      const venue = legs === 2 ? home ? UCL_HOME_EDGE : -UCL_HOME_EDGE : 0;
      const gf = uclLegGoals(clamp7(UCL_BASE_LAMBDA + edge + venue, 0.25, 3.4));
      const ga = uclLegGoals(clamp7(UCL_BASE_LAMBDA - edge - venue, 0.25, 3.4));
      aggFor += gf;
      aggAgainst += ga;
      const pg = legPlayerGoals(legs);
      totalPlayerGoals += pg;
      legRows.push({ opponent, round, leg, home, goalsFor: gf, goalsAgainst: ga, playerGoals: pg, won: false });
    }
    const decider = legRows[legRows.length - 1];
    decider.aggFor = aggFor;
    decider.aggAgainst = aggAgainst;
    const awayRule = legs === 2 && awayGoalsApply;
    const legOf = (row) => ({ homeGoals: row.goalsFor, awayGoals: row.goalsAgainst });
    const tieAt90 = legs === 2 ? { leg1: legOf(legRows[0]), leg2: legOf(decider) } : { leg2: legOf(decider) };
    const at90 = uclTieOutcome(tieAt90, awayRule);
    let through;
    if (at90.winner !== null) {
      through = at90.winner === "home";
      decider.decidedBy = at90.byAwayGoals ? "awayGoals" : "aggregate";
    } else {
      const etFor = uclLegGoals(clamp7(0.34 + edge * 0.25, 0.05, 1.1));
      const etAgainst = uclLegGoals(clamp7(0.34 - edge * 0.25, 0.05, 1.1));
      decider.goalsFor += etFor;
      decider.goalsAgainst += etAgainst;
      decider.afterExtraTime = true;
      decider.etFor = etFor;
      decider.etAgainst = etAgainst;
      aggFor += etFor;
      aggAgainst += etAgainst;
      decider.aggFor = aggFor;
      decider.aggAgainst = aggAgainst;
      const tieAfterExtraTime = { ...tieAt90, leg2: legOf(decider) };
      const afterEt = uclTieOutcome(tieAfterExtraTime, awayRule);
      if (afterEt.winner !== null) {
        through = afterEt.winner === "home";
        decider.decidedBy = afterEt.byAwayGoals ? "awayGoals" : "extraTime";
      } else {
        const pensFor = rand2(2, 5);
        let pensAgainst = rand2(2, 5);
        if (pensFor === pensAgainst) pensAgainst += Math.random() < clamp7(0.5 + edge * 0.5, 0.3, 0.7) ? -1 : 1;
        decider.pensFor = pensFor;
        decider.pensAgainst = Math.max(0, pensAgainst);
        through = pensFor > decider.pensAgainst;
        decider.decidedBy = "penalties";
      }
    }
    decider.won = through;
    matches.push(...legRows);
    if (!through) out = true;
  }
  const decidedRows = matches.filter((m) => m.decidedBy !== void 0);
  const last = decidedRows[decidedRows.length - 1] ?? matches[matches.length - 1];
  const result = last.won && last.round === "Final" ? "Winner" : last.round === "Final" ? "Final" : last.round === "SF" ? "Semi-final" : last.round === "QF" ? "Quarter-final" : last.round === "PO" ? "Play-off" : "R16";
  const topScorerBar = 6 + Math.ceil(stageGames * TOP_SCORER_BAR_PER_STAGE_GAME);
  const isTopScorer = totalPlayerGoals >= topScorerBar && Math.random() < 0.5;
  return {
    qualified: true,
    matches,
    result,
    playerGoals: totalPlayerGoals,
    isTopScorer,
    competition,
    cup: cupFor2.cup,
    ...firstStage ? { firstStage } : {},
    ...isUcl ? {} : { simplified: CONTINENTAL_SIMPLIFIED }
  };
}
var TOP_SCORER_BAR_PER_STAGE_GAME = 0.4;
var SOCCER_AWARDS_METERS = {
  popularity: { label: "Popularity", add: (s, d) => {
    s.popularity = clamp7(s.popularity + d, 0, 100);
  }, read: (s) => s.popularity },
  morale: { label: "Morale", add: (s, d) => {
    s.morale = clamp7(s.morale + d, 0, 100);
  }, read: (s) => s.morale },
  integrityBonus: { label: "Integrity", add: (s, d) => {
    s.integrityBonus += d;
  }, read: (s) => s.integrityBonus },
  rivalryIntensity: { label: "Rivalry", add: (s, d) => {
    s.rivalryIntensity = clamp7((s.rivalryIntensity ?? 0) + d, 0, 100);
  }, read: (s) => s.rivalryIntensity ?? 0 },
  /* Round 1023 review: followers are counted in millions (formatFollowers),
     so a move of 3 is three million and the card says "+3M", the way the
     rest of the site writes a follower change ("+1M", "+500k"). */
  socialMediaFollowers: { label: "Followers", add: (s, d) => {
    s.socialMediaFollowers = Math.round((s.socialMediaFollowers + d) * 100) / 100;
  }, read: (s) => s.socialMediaFollowers, show: (d) => `${d >= 0 ? "+" : "-"}${Math.abs(d) >= 1 ? `${Math.round(Math.abs(d) * 100) / 100}M` : `${Math.round(Math.abs(d) * 1e3)}k`}` },
  marketValue: { label: "Market Value", add: (s, d) => {
    s.marketValue = Math.round((s.marketValue + d) * 10) / 10;
  }, read: (s) => s.marketValue, show: (d) => `${d >= 0 ? "+" : "-"}\u20AC${Math.abs(d)}M` }
};
var BDOR_WINNER_STEPS = [{ meter: "marketValue", delta: 15 }, { meter: "popularity", delta: 20 }];
var BDOR_PODIUM_STEPS = [{ meter: "popularity", delta: 5 }];
var SOCCER_BALLON_DOR = {
  award: { id: "ballon_dor", name: "Ballon d'Or", emoji: "\u{1F3C5}", shortlistSize: 10, widerSize: 30, podiumSize: 3, rivals: "legacy-real-era-stars" },
  meters: SOCCER_AWARDS_METERS,
  winnerSteps: BDOR_WINNER_STEPS,
  podiumSteps: BDOR_PODIUM_STEPS,
  stage: (s, night) => {
    s.pendingBallonDor = night;
  },
  recordPlace: (season2, place) => {
    season2.ballonDorRank = place;
  },
  recordWin: (season2) => {
    season2.ballonDor = true;
  },
  addToCabinet: (s, entry) => {
    s.awards = [...s.awards, entry];
  },
  onPodium: (s) => {
    s.bdorSnubFuel = true;
  },
  // the snub storyline can fire next season
  say: (s, line) => {
    s.events = [...s.events, line];
  },
  copy: {
    winnerTitle: "BALLON D'OR WINNER!",
    title: (year) => `Ballon d'Or ${year}`,
    winnerLine: (moved) => `The best player in the world!${moved ? ` ${moved}` : ""}`,
    podiumLine: (place, moved) => `You finished ${place === 2 ? "2nd" : "3rd"}!${moved ? ` ${moved}, and this` : " This"} snub could follow you into next season`,
    shortlistLine: (place) => `You finished ${place}th, close but not enough this year`,
    wider: { before: "Outside the top 10, but you ranked ", after: " in the world's Top 30" },
    notNominated: "You were not nominated this year"
  }
};
var GEN_NATIONALITIES = ["Brazil", "France", "England", "Spain", "Germany", "Argentina", "Portugal", "Netherlands", "Italy", "Norway", "Belgium", "Croatia", "Uruguay", "Egypt", "Colombia", "Nigeria", "Senegal", "Japan", "South Korea"];
var GEN_CLUBS = ["Real Madrid", "Man City", "Barcelona", "Bayern Munich", "Arsenal", "Liverpool", "PSG", "Inter Milan", "Chelsea", "Dortmund", "Atletico Madrid", "Juventus", "AC Milan", "Tottenham", "Man United", "Napoli", "Leverkusen"];
var GEN_POSITIONS = [
  { pos: "ST", goals: [18, 40] },
  { pos: "LW", goals: [10, 28] },
  { pos: "RW", goals: [10, 28] },
  { pos: "CAM", goals: [8, 22] },
  { pos: "CM", goals: [4, 14] },
  { pos: "CDM", goals: [2, 8] },
  { pos: "CB", goals: [1, 5] }
];
function generateContender(usedNames, seed) {
  const nat = GEN_NATIONALITIES[(seed * 7 + 3) % GEN_NATIONALITIES.length];
  let name = "";
  for (let i = 0; i < 40; i++) {
    const candidate = intlName(nat, seed + i);
    if (!usedNames.has(candidate)) {
      name = candidate;
      break;
    }
  }
  if (!name) name = `${intlName(nat, seed)} Jr.`;
  const p = GEN_POSITIONS[seed * 11 % GEN_POSITIONS.length];
  const club = GEN_CLUBS[(seed * 13 + 2) % GEN_CLUBS.length];
  return { name, nationality: nat, position: p.pos, club, baseGoals: p.goals, startAge: rand2(19, 28) };
}
function getClubLeagueEra(club, leagueMap) {
  for (const [league, clubs] of Object.entries(leagueMap)) {
    if (clubs.includes(club)) return league;
  }
  return null;
}
function calcBdorPoints(goals, assists, overall, clubTier, trophies, club, topClubs) {
  let pts = 0;
  pts += Math.min(goals * 0.7, 28);
  pts += Math.min(assists * 0.3, 8);
  if (trophies.includes("UCL")) pts += 25;
  if (trophies.includes("ClubCup")) pts += 8;
  if (trophies.includes("World Cup")) pts += 30;
  if (trophies.includes("League")) pts += 12;
  if (trophies.includes("Cup")) pts += 3;
  if (overall >= 92) pts += 8;
  else if (overall >= 88) pts += 4;
  if (topClubs.includes(club)) pts += 5;
  return Math.round(pts);
}
var lastJudged = null;
function calculateBallonDor(state, season2, year, world) {
  const yearOffset = year - 2024;
  const eraTopClubs = getEraTopClubs(year);
  const eraLeagues = getEraLeagueClubs(year);
  const uclWinnerClub = world?.ucl ?? pick2(eraTopClubs);
  const leagueWinners = {};
  for (const [league, clubs] of Object.entries(eraLeagues)) {
    leagueWinners[league] = world?.leagues?.[league] ?? pick2(clubs);
  }
  const cupWinners = world?.cups ?? {};
  const clubHonours = (club) => {
    const t = [];
    if (club === uclWinnerClub) t.push("UCL");
    const lg = getClubLeagueEra(club, eraLeagues);
    if (lg && leagueWinners[lg] === club) t.push("League");
    if (lg && cupWinners[lg] === club) t.push("Cup");
    return t;
  };
  const intlHonour = (nationality) => {
    const it = world?.intl;
    if (!it || it.champion !== nationality) return null;
    return it.name === "World Cup" ? "World Cup" : "Continental";
  };
  const isLowTierClub = state.currentClubTier >= 3;
  const hasMajorTrophy = season2.leagueTitle || season2.championsLeague || season2.worldCup;
  const playerEligible = !isLowTierClub || season2.goals >= 40 && hasMajorTrophy;
  const playerCanContend = state.currentClubTier <= 2 || isLowTierClub && season2.goals >= 40 && hasMajorTrophy;
  const playerTrophies = [];
  if (season2.leagueTitle) playerTrophies.push("League");
  if (season2.championsLeague) playerTrophies.push("UCL");
  if (season2.domesticCup) playerTrophies.push("Cup");
  if (season2.worldCup) playerTrophies.push("World Cup");
  if (season2.continentalCup) playerTrophies.push("Continental");
  if (season2.clubCupTitle) playerTrophies.push("ClubCup");
  let playerPoints = 0;
  if (playerCanContend) {
    playerPoints = calcBdorPoints(season2.goals, season2.assists, state.overall, state.currentClubTier, playerTrophies, state.currentClub, eraTopClubs);
  }
  const playerNominated = playerCanContend && playerPoints > 45;
  const useEraStars = year <= 2032;
  const usedNames = /* @__PURE__ */ new Set([state.playerName]);
  if (state.rival) usedNames.add(state.rival.name);
  const allNomineeData = [];
  if (useEraStars) {
    for (const star of getEraStars(year)) {
      if (usedNames.has(star.name)) continue;
      usedNames.add(star.name);
      const goals = rand2(star.baseGoals[0], star.baseGoals[1]);
      const assists = rand2(3, 18);
      const starClub = worldClubOf(state, star.name) ?? star.club;
      const trophies = clubHonours(starClub);
      const starIntl = intlHonour(star.nationality);
      if (starIntl) trophies.push(starIntl);
      const overall = clamp7(82 + star.power + rand2(-2, 2), 78, 96);
      const pts = calcBdorPoints(goals, assists, overall, 1, trophies, starClub, eraTopClubs) + star.power * rand2(1, 3);
      allNomineeData.push({
        name: star.name,
        nationality: star.nationality,
        position: star.position,
        club: starClub,
        points: pts,
        goals,
        trophies,
        isPlayer: false
      });
    }
  } else {
    for (let i = 0; i < 15; i++) {
      const gen = generateContender(usedNames, yearOffset * 100 + i);
      if (usedNames.has(gen.name)) continue;
      usedNames.add(gen.name);
      const goals = rand2(gen.baseGoals[0], gen.baseGoals[1]);
      const assists = rand2(3, 18);
      const trophies = clubHonours(gen.club);
      const genIntl = intlHonour(gen.nationality);
      if (genIntl) trophies.push(genIntl);
      const overall = clamp7(rand2(83, 93), 75, 95);
      const pts = calcBdorPoints(goals, assists, overall, 1, trophies, gen.club, eraTopClubs);
      allNomineeData.push({
        name: gen.name,
        nationality: gen.nationality,
        position: gen.position,
        club: gen.club,
        points: pts,
        goals,
        trophies,
        isPlayer: false
      });
    }
  }
  if (state.rival && !state.rival.retired && state.rival.clubTier <= 2) {
    const rivalGoals = state.rival.careerGoals > 0 ? rand2(12, 30) : rand2(5, 15);
    const rivalAssists = rand2(3, 12);
    const rivalTrophies = clubHonours(state.rival.club);
    const rivalIntl = intlHonour(state.rival.nationality);
    if (rivalIntl) rivalTrophies.push(rivalIntl);
    const rivalPts = calcBdorPoints(rivalGoals, rivalAssists, state.rival.overall, state.rival.clubTier, rivalTrophies, state.rival.club, eraTopClubs);
    allNomineeData.push({
      name: state.rival.name,
      nationality: state.rival.nationality,
      position: state.rival.position,
      club: state.rival.club,
      points: rivalPts,
      goals: rivalGoals,
      trophies: rivalTrophies,
      isPlayer: false
    });
  }
  allNomineeData.sort((a, b) => b.points - a.points);
  const productionScore = (goals, assists, trophies) => {
    let p = goals + assists * 0.5;
    if (trophies.includes("World Cup")) p += 22;
    if (trophies.includes("Continental")) p += 11;
    if (trophies.includes("UCL")) p += 18;
    if (trophies.includes("ClubCup")) p += 6;
    if (trophies.includes("League")) p += 9;
    if (trophies.includes("Cup")) p += 3;
    return p;
  };
  const playerProduction = productionScore(season2.goals, season2.assists, playerTrophies);
  const visibleField = allNomineeData.slice(0, SOCCER_BALLON_DOR.award.shortlistSize - 1);
  lastJudged = { year, names: visibleField.map((n) => n.name) };
  const fieldBest = visibleField.reduce(
    (mx, n) => Math.max(mx, productionScore(n.goals, 12, n.trophies)),
    0
  );
  const gaTotal = season2.goals + season2.assists;
  const trebleSeason = season2.leagueTitle && season2.championsLeague && season2.domesticCup;
  const statMonster = gaTotal >= 55 || season2.goals >= 45 || gaTotal >= 45 && (season2.leagueTitle || season2.championsLeague || season2.worldCup);
  const fieldTopGoals = visibleField.reduce((mx, n) => Math.max(mx, n.goals), 0);
  const outscoredEveryone = season2.goals > fieldTopGoals;
  const wonMajor = season2.leagueTitle || season2.championsLeague || season2.worldCup || !!season2.continentalCup || !!season2.clubCupTitle;
  const playerDominant = playerCanContend && (playerProduction > fieldBest || outscoredEveryone && wonMajor || statMonster && playerProduction >= fieldBest * 0.95 || trebleSeason && playerProduction >= fieldBest * 0.9);
  if (allNomineeData.length >= 2 && !playerDominant) {
    allNomineeData[0].points += rand2(5, 15);
    if (allNomineeData[1]) allNomineeData[1].points += rand2(2, 8);
  }
  const playerInTop10 = playerCanContend && (playerNominated || playerDominant || statMonster);
  return runAwardsNight(SOCCER_BALLON_DOR.award, year, {
    field: allNomineeData,
    // Add player if nominated (or if the season was flat out dominant)
    player: playerInTop10 ? {
      name: state.playerName,
      nationality: state.nationality,
      position: state.position,
      club: state.currentClub,
      points: playerPoints,
      goals: season2.goals,
      trophies: playerTrophies,
      isPlayer: true
    } : null,
    playerPoints,
    // Filler nominees (only needed if the era pool somehow ran short)
    fill: (shortlist, need) => {
      let fillerSeed = 0;
      while (shortlist.length < need && fillerSeed < 20) {
        const gen = generateContender(usedNames, year * 31 + fillerSeed++);
        if (usedNames.has(gen.name)) continue;
        usedNames.add(gen.name);
        shortlist.push({
          name: gen.name,
          nationality: gen.nationality,
          position: gen.position,
          club: gen.club,
          points: rand2(30, 50),
          goals: rand2(5, 15),
          trophies: [],
          isPlayer: false
        });
      }
    },
    verdicts: [
      // Round 54: a dominant season is untouchable. If the raw numbers say the
      // player owned the year, they lift the trophy, even if a filler nominee
      // landed above them on a technicality.
      (top10, playerRank) => {
        if (playerDominant && playerRank !== 1) {
          const playerEntry = top10.find((n) => n.isPlayer);
          if (playerEntry) {
            playerEntry.points = top10.reduce((mx, n) => Math.max(mx, n.points), 0) + rand2(3, 9);
          }
        }
      },
      // STRICT WIN CONDITIONS: Player can only win (rank 1) if they meet elite criteria.
      // Round 54 widened the paths so voters respect stats, not just trophies:
      // 30+ goals, UCL+League double, World Cup, a domestic treble, or a 45+ goal
      // involvement season alongside any major trophy all count as winning material.
      (top10, playerRank) => {
        if (playerRank === 1 && !playerDominant) {
          const hasUCLAndLeague = season2.championsLeague && season2.leagueTitle;
          const hasWorldCup = season2.worldCup;
          const has30PlusGoals = season2.goals >= BDOR_WIN_MIN_GOALS;
          const bigInvolvementPlusTrophy = gaTotal >= 45 && (season2.leagueTitle || season2.championsLeague);
          const meetsWinCondition = has30PlusGoals || hasUCLAndLeague || hasWorldCup || trebleSeason || bigInvolvementPlusTrophy;
          if (!meetsWinCondition) {
            const playerEntry = top10.find((n) => n.isPlayer);
            if (playerEntry && top10.length >= 2) {
              const topNPC = top10.find((n) => !n.isPlayer);
              if (topNPC) topNPC.points = Math.max(topNPC.points, playerEntry.points + rand2(2, 6));
            }
          }
        }
      },
      // Round 54 PODIUM FLOOR: even in a year someone else legitimately owned, a
      // monster individual season cannot be shoved down to 8th. 45+ goals, or 55+
      // goal involvements, guarantees at least a podium finish.
      (top10, playerRank) => {
        if (statMonster && playerRank !== null && playerRank > 3) {
          const playerEntry = top10.find((n) => n.isPlayer);
          if (playerEntry) {
            const thirdBest = [...top10].sort((a, b) => b.points - a.points)[2];
            playerEntry.points = (thirdBest ? thirdBest.points : playerEntry.points) + rand2(1, 4);
          }
        }
      }
    ],
    // Extended top-30 ranking: strong-but-not-nominated seasons still place in the world top 30
    widerEligible: playerCanContend && playerPoints >= 12
  });
}
function createRival(state, clubs) {
  const rivalYear = state.seasons.length > 0 ? state.seasons[state.seasons.length - 1].year : 2024;
  clubs = adjustClubsForYear(clubs, rivalYear);
  const ovrDiff = rand2(-5, 5);
  const rivalOvr = clamp7(state.overall + ovrDiff, 45, 95);
  const tiers = rivalOvr >= 80 ? [1] : rivalOvr >= 70 ? [1, 2] : rivalOvr >= 60 ? [2, 3] : [3, 4];
  const candidates = clubs.filter((c) => tiers.includes(c.tier) && c.name !== state.currentClub);
  const rivalClub = candidates.length > 0 ? pick2(candidates) : { name: "Unknown FC", tier: 2 };
  const sameNatChance = Math.random();
  const rivalNat = sameNatChance < 0.3 ? state.nationality : pick2(Object.keys(FLAG_MAP));
  return {
    name: getEraRivalName(rivalYear),
    nationality: rivalNat,
    position: state.position,
    club: rivalClub.name,
    clubTier: rivalClub.tier,
    overall: rivalOvr,
    careerGoals: 0,
    careerAssists: 0,
    careerApps: 0,
    leagueTitles: 0,
    championsLeagues: 0,
    worldCups: 0,
    ballonDors: 0,
    intCaps: 0,
    intGoals: 0,
    marketValue: calcMarketValue(rivalOvr, state.age, state.position),
    age: state.age + rand2(-1, 1),
    retired: false
  };
}
function simulateRivalSeason(rival, clubs, year) {
  if (year !== void 0) clubs = adjustClubsForYear(clubs, year);
  const r = { ...rival };
  if (r.retired) return r;
  r.age += 1;
  if (r.age <= 23) r.overall = clamp7(r.overall + rand2(1, 3), 45, 95);
  else if (r.age <= 29) r.overall = clamp7(r.overall + rand2(0, 2), 45, 95);
  else if (r.age <= 33) r.overall = clamp7(r.overall + rand2(-2, 0), 45, 95);
  else r.overall = clamp7(r.overall + rand2(-3, -1), 45, 95);
  if (Math.random() < 0.15) {
    const tiers = r.overall >= 82 ? [1] : r.overall >= 72 ? [1, 2] : r.overall >= 62 ? [2, 3] : [3, 4];
    const candidates = clubs.filter((c) => tiers.includes(c.tier) && c.name !== r.club);
    if (candidates.length > 0) r.club = pick2(candidates).name;
  }
  const apps = rand2(20, 36);
  const goals = calcGoals(r.position, apps);
  const assists = calcAssists(r.position, apps);
  r.careerApps += apps;
  r.careerGoals += goals;
  r.careerAssists += assists;
  const clubTier = r.clubTier;
  if (clubTier <= 2 && Math.random() < 0.2 / clubTier) r.leagueTitles += 1;
  if (clubTier === 1 && r.overall >= 78 && Math.random() < 0.06) r.championsLeagues += 1;
  if (r.overall >= 80 && Math.random() < 0.04) r.worldCups += 1;
  if (r.overall >= 88 && Math.random() < 0.08) r.ballonDors += 1;
  if (r.overall >= 72 && r.age <= 33) {
    const intApps = rand2(4, 10);
    r.intCaps += intApps;
    r.intGoals += calcGoals(r.position, intApps);
  }
  r.marketValue = calcMarketValue(r.overall, r.age, r.position);
  if (r.overall < 60 && r.age >= 30 || r.age >= 37) r.retired = true;
  return r;
}
var SOCCER_RIVALRY_EVENTS = [
  {
    id: 101,
    emoji: "\u{1F3C5}",
    title: "Rival Wins Ballon d'Or",
    description: (_s, r) => `${r.name} won the Ballon d'Or. You finished 3rd.`,
    consequence: "Motivation boost: stats +1 next season",
    when: (_s, r) => r.ballonDors > 0,
    apply: (s) => {
      s.statBoostNextSeason = { ...s.statBoostNextSeason, shooting: (s.statBoostNextSeason.shooting || 0) + 1, dribbling: (s.statBoostNextSeason.dribbling || 0) + 1 };
      s.morale = clamp7(s.morale - 5, 0, 100);
    }
  },
  {
    id: 102,
    emoji: "\u{1F3E0}",
    title: "Transfer Battle",
    description: (_s, r) => `You and ${r.name} both want to sign for the same club. The club chose your rival.`,
    consequence: "Morale -5",
    when: () => true,
    apply: (s) => {
      s.morale = clamp7(s.morale - 5, 0, 100);
    }
  },
  {
    id: 103,
    emoji: "\u{1F91D}",
    title: "Rival Shows Respect",
    description: (_s, r) => `${r.name} publicly says he respects you as the best player in the world.`,
    consequence: "Popularity +5, Morale +5",
    when: () => true,
    apply: (s) => {
      s.popularity = clamp7(s.popularity + 5, 0, 100);
      s.morale = clamp7(s.morale + 5, 0, 100);
    }
  },
  {
    id: 104,
    emoji: "\u26BD",
    title: "Head to Head Victory!",
    description: (_s, r) => `In a head-to-head match you scored twice against ${r.name}'s team.`,
    consequence: "Popularity +5, Confidence boost",
    when: () => true,
    apply: (s) => {
      s.popularity = clamp7(s.popularity + 5, 0, 100);
      s.morale = clamp7(s.morale + 5, 0, 100);
    }
  },
  {
    id: 105,
    emoji: "\u{1F44B}",
    title: "Rival Retires",
    description: (_s, r) => `${r.name} announces retirement. He calls you the greatest rival of his career.`,
    consequence: "Legacy +10, End of an era",
    when: (_s, r) => r.retired,
    apply: (s) => {
      s.popularity = clamp7(s.popularity + 10, 0, 100);
    }
  },
  {
    id: 106,
    emoji: "\u{1F1FA}\u{1F1F3}",
    title: "National Team Battle",
    description: (_s, r) => `Both you and ${r.name} are on the same national team. The manager must pick one to start.`,
    consequence: "50/50 outcome",
    when: (s) => s.internationalCareer,
    apply: (s, r, rng, pushLine2) => {
      if (rng() < 0.5) {
        s.morale = clamp7(s.morale + 5, 0, 100);
        pushLine2(`\u{1F1FA}\u{1F1F3} Manager chose you over ${r.name}!`);
      } else {
        s.morale = clamp7(s.morale - 5, 0, 100);
        pushLine2(`\u{1F1FA}\u{1F1F3} Manager chose ${r.name} over you.`);
      }
    }
  },
  {
    id: 107,
    emoji: "\u2B50",
    title: "Rival Wins Champions League",
    description: (_s, r) => `${r.name} wins the Champions League. You were eliminated in the semis.`,
    consequence: "Morale -5, Motivation boost",
    when: (_s, r) => r.championsLeagues > 0,
    apply: (s) => {
      s.morale = clamp7(s.morale - 5, 0, 100);
      s.statBoostNextSeason = { ...s.statBoostNextSeason, physical: (s.statBoostNextSeason.physical || 0) + 1 };
    }
  },
  {
    id: 108,
    emoji: "\u{1F4C8}",
    title: "Surpassed Your Rival!",
    description: (s, r) => `For the first time in your career, your overall rating (${s.overall}) has surpassed ${r.name}'s (${r.overall}).`,
    consequence: "Morale +10, Legacy boost",
    when: (s, r) => s.overall > r.overall && s.overall - r.overall >= 2,
    apply: (s) => {
      s.morale = clamp7(s.morale + 10, 0, 100);
    }
  },
  // 2026-08-05 rivalry expansion: ten more beats in the saga
  {
    id: 109,
    emoji: "\u{1F62C}",
    title: "Your Rival Is Now Your Teammate",
    description: (_s, r) => `${r.name} just signed for YOUR club. The first training session is the most watched non-match footage of the year.`,
    consequence: "The feud cools, the cameras multiply",
    when: (s, r) => r.club === s.currentClub,
    apply: (s) => {
      s.morale = clamp7(s.morale + 3, 0, 100);
      s.popularity = clamp7(s.popularity + 5, 0, 100);
      s.rivalryIntensity = clamp7((s.rivalryIntensity ?? 0) - 10, 0, 100);
    }
  },
  {
    id: 110,
    emoji: "\u{1F92C}",
    title: "Tunnel Bust-Up",
    description: (_s, r) => `Cameras catch you and ${r.name} chest to chest in the tunnel after a bad-blood derby. Lip readers are having the week of their lives.`,
    consequence: "Rivalry intensifies, the league schedules you for prime time",
    when: () => true,
    apply: (s) => {
      s.popularity = clamp7(s.popularity + 3, 0, 100);
      s.rivalryIntensity = clamp7((s.rivalryIntensity ?? 0) + 15, 0, 100);
    }
  },
  {
    id: 111,
    emoji: "\u{1F3AF}",
    title: "The Chase",
    description: (_s, r) => `${r.name} just passed 300 career goals. Every broadcast now shows your tallies side by side in real time.`,
    consequence: "Motivation surges: +1 Shooting next season",
    when: (_s, r) => r.careerGoals >= 300,
    apply: (s) => {
      s.statBoostNextSeason = { ...s.statBoostNextSeason, shooting: (s.statBoostNextSeason.shooting || 0) + 1 };
      s.rivalryIntensity = clamp7((s.rivalryIntensity ?? 0) + 5, 0, 100);
    }
  },
  {
    id: 112,
    emoji: "\u{1F4AB}",
    title: "The Armband Snub",
    description: (_s, r) => `The national team named ${r.name} captain. Your shirt number stays, the armband does not.`,
    consequence: "Morale -5, motivation +2 Physical next season",
    when: (s, r) => r.nationality === s.nationality,
    apply: (s) => {
      s.morale = clamp7(s.morale - 5, 0, 100);
      s.statBoostNextSeason = { ...s.statBoostNextSeason, physical: (s.statBoostNextSeason.physical || 0) + 2 };
      s.rivalryIntensity = clamp7((s.rivalryIntensity ?? 0) + 10, 0, 100);
    }
  },
  {
    id: 113,
    emoji: "\u{1F455}",
    title: "The Shirt Swap",
    description: (_s, r) => `After a classic against ${r.name}, you swap shirts and embrace. The photo becomes the wallpaper of half the football internet.`,
    consequence: "Popularity +8, the feud softens",
    when: () => true,
    apply: (s) => {
      s.popularity = clamp7(s.popularity + 8, 0, 100);
      s.rivalryIntensity = clamp7((s.rivalryIntensity ?? 0) - 15, 0, 100);
    }
  },
  {
    id: 114,
    emoji: "\u{1F3E5}",
    title: "Rival Goes Down",
    description: (_s, r) => `${r.name} tears a ligament and faces a year out. You post a genuine get-well message within the hour.`,
    consequence: "Integrity +5, Popularity +5, rivalry cools",
    when: () => true,
    apply: (s) => {
      s.integrityBonus += 5;
      s.popularity = clamp7(s.popularity + 5, 0, 100);
      s.rivalryIntensity = clamp7((s.rivalryIntensity ?? 0) - 20, 0, 100);
    }
  },
  {
    id: 115,
    emoji: "\u{1F410}",
    title: "The GOAT Debate",
    description: (_s, r) => `Every pundit panel this week ran the same segment: you or ${r.name}. Your teammates printed the losing poll and taped it to his locker room door.`,
    consequence: "Popularity +5, the era has a name now",
    when: (s, r) => s.overall >= 88 && r.overall >= 88,
    apply: (s) => {
      s.popularity = clamp7(s.popularity + 5, 0, 100);
      s.rivalryIntensity = clamp7((s.rivalryIntensity ?? 0) + 10, 0, 100);
    }
  },
  {
    id: 116,
    emoji: "\u{1F3F4}",
    title: "The Banner",
    description: (_s, r) => `${r.name}'s ultras unveil a 40-meter banner mocking you before kickoff. You answer the only way that matters.`,
    consequence: "+1 Shooting and +1 Dribbling next season, rivalry intensifies",
    when: (s) => s.popularity >= 40,
    apply: (s) => {
      s.statBoostNextSeason = { ...s.statBoostNextSeason, shooting: (s.statBoostNextSeason.shooting || 0) + 1, dribbling: (s.statBoostNextSeason.dribbling || 0) + 1 };
      s.rivalryIntensity = clamp7((s.rivalryIntensity ?? 0) + 10, 0, 100);
    }
  },
  {
    id: 117,
    emoji: "\u{1F3AC}",
    title: "The Rivalry Documentary",
    description: (_s, r) => `A streaming giant offers to make a series about you and ${r.name}. Both camps say yes before the call ends.`,
    consequence: "Net worth +3M, Popularity +8",
    when: (s) => s.age >= 28,
    apply: (s) => {
      s.netWorth = Math.round((s.netWorth + 3) * 100) / 100;
      s.popularity = clamp7(s.popularity + 8, 0, 100);
    }
  },
  {
    id: 118,
    emoji: "\u{1F91D}",
    title: "Testimonial Invitation",
    description: (_s, r) => `${r.name} personally invites you to captain the opposition in his testimonial match. Two decades of war, one guard of honor.`,
    consequence: "Integrity +8, Popularity +8, the feud becomes history",
    when: (s) => s.age >= 32,
    apply: (s) => {
      s.integrityBonus += 8;
      s.popularity = clamp7(s.popularity + 8, 0, 100);
      s.rivalryIntensity = clamp7((s.rivalryIntensity ?? 0) - 25, 0, 100);
    }
  }
];
function generateRivalrySummary(state) {
  if (!state.rival) return null;
  const r = state.rival;
  const totals = getCareerTotals(state.seasons);
  const categories = [
    { label: "Career Goals", playerVal: `${totals.goals}`, rivalVal: `${r.careerGoals}`, winner: totals.goals > r.careerGoals ? "player" : totals.goals < r.careerGoals ? "rival" : "tie" },
    { label: "Career Assists", playerVal: `${totals.assists}`, rivalVal: `${r.careerAssists}`, winner: totals.assists > r.careerAssists ? "player" : totals.assists < r.careerAssists ? "rival" : "tie" },
    { label: "League Titles", playerVal: `${totals.leagueTitles}`, rivalVal: `${r.leagueTitles}`, winner: totals.leagueTitles > r.leagueTitles ? "player" : totals.leagueTitles < r.leagueTitles ? "rival" : "tie" },
    { label: "Champions League", playerVal: `${totals.championsLeagues}`, rivalVal: `${r.championsLeagues}`, winner: totals.championsLeagues > r.championsLeagues ? "player" : totals.championsLeagues < r.championsLeagues ? "rival" : "tie" },
    { label: "Ballon d'Or", playerVal: `${totals.ballonDors}`, rivalVal: `${r.ballonDors}`, winner: totals.ballonDors > r.ballonDors ? "player" : totals.ballonDors < r.ballonDors ? "rival" : "tie" },
    { label: "Int'l Caps", playerVal: `${state.intStats.caps}`, rivalVal: `${r.intCaps}`, winner: state.intStats.caps > r.intCaps ? "player" : state.intStats.caps < r.intCaps ? "rival" : "tie" },
    { label: "Int'l Goals", playerVal: `${state.intStats.goals}`, rivalVal: `${r.intGoals}`, winner: state.intStats.goals > r.intGoals ? "player" : state.intStats.goals < r.intGoals ? "rival" : "tie" },
    { label: "Market Value", playerVal: `\u20AC${state.marketValue.toFixed(0)}M`, rivalVal: `\u20AC${r.marketValue.toFixed(0)}M`, winner: state.marketValue > r.marketValue ? "player" : state.marketValue < r.marketValue ? "rival" : "tie" }
  ];
  const playerWins = categories.filter((c) => c.winner === "player").length;
  const rivalWins = categories.filter((c) => c.winner === "rival").length;
  const overallWinner = playerWins > rivalWins ? "player" : playerWins < rivalWins ? "rival" : "tie";
  const legacyBonus = overallWinner === "player" ? 15 : overallWinner === "tie" ? 5 : -5 + ((state.rivalryIntensity ?? 0) >= 70 ? 5 : 0);
  return { playerWins, rivalWins, categories, overallWinner, legacyBonus };
}
function getCareerTotals(seasons) {
  return seasons.reduce((t, s) => ({
    apps: t.apps + s.apps,
    goals: t.goals + s.goals,
    assists: t.assists + s.assists,
    cleanSheets: t.cleanSheets + s.cleanSheets,
    yellowCards: t.yellowCards + s.yellowCards,
    redCards: t.redCards + s.redCards,
    leagueTitles: t.leagueTitles + (s.leagueTitle ? 1 : 0),
    domesticCups: t.domesticCups + (s.domesticCup ? 1 : 0),
    championsLeagues: t.championsLeagues + (s.championsLeague ? 1 : 0),
    worldCups: t.worldCups + (s.worldCup ? 1 : 0),
    ballonDors: t.ballonDors + (s.ballonDor ? 1 : 0),
    // Round 124: continental championships are counted, and counted separately
    // so a Euros never quietly reads as a World Cup in the cabinet.
    continentalCups: t.continentalCups + (s.continentalCup ? 1 : 0),
    // Round 972: a continental club cup outside UEFA, never a Champions League.
    clubCups: t.clubCups + (s.clubCupTitle ? 1 : 0)
  }), { apps: 0, goals: 0, assists: 0, cleanSheets: 0, yellowCards: 0, redCards: 0, leagueTitles: 0, domesticCups: 0, championsLeagues: 0, worldCups: 0, ballonDors: 0, continentalCups: 0, clubCups: 0 });
}
var POST_RETIREMENT_BONUS_CAP = 6;
function getLegacyTier(score2) {
  if (score2 >= 90) return "GOAT";
  if (score2 >= 80) return "LEGEND";
  if (score2 >= 70) return "GREAT";
  if (score2 >= 60) return "SOLID PRO";
  return "JOURNEYMAN";
}
function calculateLegacy(state) {
  const totals = getCareerTotals(state.seasons);
  const breakdown = [];
  let score2 = 0;
  const isAttacker = ["ST", "CAM", "LW", "RW"].includes(state.position);
  const isMid = ["CM", "CDM"].includes(state.position);
  const isDefender = ["CB", "LB", "RB"].includes(state.position);
  const isGK = state.position === "GK";
  let goalPoints = 0;
  if (isAttacker) goalPoints = Math.min(25, totals.goals * 0.08);
  else if (isMid) goalPoints = Math.min(20, totals.goals * 0.15);
  else if (isDefender) goalPoints = Math.min(15, totals.goals * 0.3);
  else if (isGK) goalPoints = Math.min(15, totals.cleanSheets * 0.15);
  breakdown.push({ label: isGK ? "Clean Sheets" : "Goals", points: Math.round(goalPoints) });
  score2 += goalPoints;
  const assistPoints = Math.min(10, totals.assists * 0.05);
  breakdown.push({ label: "Assists", points: Math.round(assistPoints) });
  score2 += assistPoints;
  const uclPoints = Math.min(20, totals.championsLeagues * 8);
  breakdown.push({ label: "Champions League", points: Math.round(uclPoints) });
  score2 += uclPoints;
  if (totals.clubCups > 0) {
    const clubCupPoints = Math.min(10, totals.clubCups * 4);
    breakdown.push({ label: "Continental Club Cups", points: Math.round(clubCupPoints) });
    score2 += clubCupPoints;
  }
  const leaguePoints = Math.min(10, totals.leagueTitles * 3);
  breakdown.push({ label: "League Titles", points: Math.round(leaguePoints) });
  score2 += leaguePoints;
  const cupPoints = Math.min(5, totals.domesticCups * 1.5);
  breakdown.push({ label: "Domestic Cups", points: Math.round(cupPoints) });
  score2 += cupPoints;
  const bdorPoints = Math.min(15, totals.ballonDors * 5);
  breakdown.push({ label: "Ballon d'Or", points: Math.round(bdorPoints) });
  score2 += bdorPoints;
  const capPoints = Math.min(4, state.intStats.caps * 0.035);
  const intTrophyPoints = Math.min(
    16,
    state.intStats.worldCupWins * 8 + state.intStats.continentalWins * 4 + capPoints
  );
  breakdown.push({ label: "International", points: Math.round(intTrophyPoints) });
  score2 += intTrophyPoints;
  const clubYears = {};
  state.seasons.filter((s) => s.type === "playing").forEach((s) => {
    clubYears[s.club] = (clubYears[s.club] || 0) + 1;
  });
  const maxYears = Math.max(0, ...Object.values(clubYears));
  const loyaltyPoints = maxYears >= 10 ? 8 : maxYears >= 7 ? 5 : maxYears >= 5 ? 3 : 0;
  breakdown.push({ label: "Club Loyalty", points: loyaltyPoints });
  score2 += loyaltyPoints;
  const careerLength = state.seasons.filter((s) => s.type === "playing").length;
  const longevityPoints = careerLength >= 18 ? 7 : careerLength >= 15 ? 5 : careerLength >= 12 ? 3 : 0;
  breakdown.push({ label: "Longevity", points: longevityPoints });
  score2 += longevityPoints;
  if (state.rivalrySummary) {
    const rivalPoints = state.rivalrySummary.legacyBonus > 0 ? Math.min(5, state.rivalrySummary.legacyBonus / 3) : 0;
    breakdown.push({ label: "Rivalry", points: Math.round(rivalPoints) });
    score2 += rivalPoints;
  }
  if (careerLength > 0) {
    if (state.isPundit) {
      breakdown.push({ label: "TV Pundit", points: 5 });
      score2 += 5;
    }
    const punditPoints = clamp7(Math.round(state.punditBonus ?? 0), 0, POST_RETIREMENT_BONUS_CAP);
    if (punditPoints > 0) {
      breakdown.push({ label: "Punditry", points: punditPoints });
      score2 += punditPoints;
    }
    const ownerPoints = clamp7(Math.round(state.ownerBonus ?? 0), 0, POST_RETIREMENT_BONUS_CAP);
    if (ownerPoints > 0) {
      breakdown.push({ label: "Club Owner", points: ownerPoints });
      score2 += ownerPoints;
    }
  }
  if (state.coverAthleteAccepted) {
    breakdown.push({ label: "Cover Star", points: 10 });
    score2 += 10;
  }
  let climbPoints = 0;
  if (typeof state.startingOverall === "number" && state.startingOverall > 0) {
    const climb = Math.max(0, state.peakOverall - state.startingOverall);
    const handed = clamp7(state.startingOverall - 67, 0, 32);
    climbPoints = clamp7(Math.round((climb - 12) * 0.42 - handed * 0.34), -18, 8);
  }
  if (state.integrityBonus !== 0) {
    const intPts = clamp7(state.integrityBonus, -30, 20);
    breakdown.push({ label: state.integrityBonus > 0 ? "Integrity" : "Scandal", points: intPts });
    score2 += intPts;
  }
  score2 = Math.round(clamp7(score2, 0, 100));
  if (climbPoints !== 0) {
    breakdown.push({ label: "The Climb", points: climbPoints });
    score2 = Math.round(clamp7(score2 + climbPoints, 0, 100));
  }
  return { score: score2, tier: getLegacyTier(score2), breakdown };
}

// src/lib/soccerCareerSave.ts
var record2 = (v) => typeof v === "object" && v !== null && !Array.isArray(v);
var text = (v) => typeof v === "string";
var number = (v) => typeof v === "number" && Number.isFinite(v);
var list = (v, check) => Array.isArray(v) && v.every(check);
var fields = (v, names, check) => names.every((name) => check(v[name]));
var phases = ["youth", "contract_offer", "playing", "newspaper", "season_summary", "transfer_window", "random_events", "international_debut", "world_cup", "rivalry_event", "ballon_dor", "retirement_ceremony", "retirement_suggestion", "post_retirement", "manager_season", "pundit_season", "owner_season", "social_media_action", "moral_dilemma", "red_card_appeal_result", "rehab_choice", "retired"];
var season = (v) => record2(v) && fields(v, ["club", "clubCountry", "type"], text) && fields(v, ["year", "age", "clubTier", "apps", "goals", "assists", "cleanSheets", "yellowCards", "redCards", "rating"], number);
var offer = (v) => record2(v) && record2(v.club) && fields(v.club, ["name", "country", "color", "league"], text) && number(v.club.tier) && fields(v, ["contractYears", "wage"], number);
var event = (v) => record2(v) && number(v.id) && fields(v, ["title", "description"], text) && list(v.choices, (choice) => record2(choice) && fields(choice, ["label", "consequence"], text)) && v.choices.length > 0;
function isSoccerCareerSave(value) {
  if (!record2(value)) return false;
  if (!fields(value, ["playerName", "nationality", "position", "era", "currentClub", "currentClubCountry", "currentClubColor", "currentLeague", "lifestyleLevel"], text) || !fields(value, ["age", "currentClubTier", "contractYearsLeft", "weeklyWage", "marketValue", "pace", "shooting", "passing", "dribbling", "defending", "physical", "reflexes", "overall", "netWorth", "socialMediaFollowers", "popularity", "morale"], number) || typeof value.retired !== "boolean" || !phases.includes(value.phase)) return false;
  if (!list(value.seasons, season) || value.seasons.length === 0 || !list(value.events, text) || !list(value.pendingEvents, event) || !list(value.pendingOffers, offer) || !list(value.pendingNews, (row) => record2(row) && fields(row, ["newspaper", "headline", "body"], text)) || !list(value.awards, (row) => record2(row) && number(row.year) && fields(row, ["name", "emoji"], text)) || !list(value.properties, text) || !list(value.investments, text)) return false;
  if (!record2(value.family) || !number(value.family.children) || typeof value.family.isMarried !== "boolean" || typeof value.family.isDivorced !== "boolean" || !record2(value.intStats) || !fields(value.intStats, ["caps", "goals", "assists"], number)) return false;
  if (value.pendingSummary != null && !season(value.pendingSummary)) return false;
  if (value.legacy != null && (!record2(value.legacy) || !number(value.legacy.score) || !text(value.legacy.tier) || !list(value.legacy.breakdown, (row) => record2(row) && text(row.label) && number(row.points)))) return false;
  for (const name of ["managerState", "ownerState"]) {
    const tail = value[name];
    if (tail != null && (!record2(tail) || !text(tail.club) || !fields(tail, ["clubTier", "season", "trophies", "promotions"], number) || !list(tail.seasonResults, (row) => record2(row) && fields(row, ["club", "result"], text) && number(row.year)))) return false;
  }
  if (value.ownerState != null && (!record2(value.ownerState) || !number(value.ownerState.budget))) return false;
  if (value.punditState != null && (!record2(value.punditState) || !fields(value.punditState, ["season", "controversies"], number) || !list(value.punditState.predictions, (row) => record2(row) && text(row.prediction) && typeof row.cameTrue === "boolean"))) return false;
  return true;
}

// src/lib/flagUtils.ts
var RI_A = 127462;
var TAG_A = 917601;
var TAG_CANCEL = 917631;
var BLACK_FLAG = 127988;
var TAG_SEQUENCES = {
  gbeng: "gb-eng",
  gbsct: "gb-sct",
  gbwls: "gb-wls"
};
function flagEmojiToIso(emoji) {
  const cps = [];
  for (const ch of (emoji ?? "").trim()) cps.push(ch.codePointAt(0) ?? 0);
  if (cps.length === 2 && cps.every((cp) => cp >= RI_A && cp <= RI_A + 25)) {
    return cps.map((cp) => String.fromCharCode(97 + (cp - RI_A))).join("");
  }
  if (cps.length >= 3 && cps[0] === BLACK_FLAG && cps[cps.length - 1] === TAG_CANCEL) {
    const letters = cps.slice(1, -1);
    if (letters.every((cp) => cp >= TAG_A && cp <= TAG_A + 25)) {
      const key = letters.map((cp) => String.fromCharCode(97 + (cp - TAG_A))).join("");
      return TAG_SEQUENCES[key] ?? null;
    }
  }
  return null;
}

// src/components/FlagImg.tsx
var FLAG_CODES = {
  "England": "gb-eng",
  "Scotland": "gb-sct",
  "Wales": "gb-wls",
  "Spain": "es",
  "France": "fr",
  "Germany": "de",
  "Brazil": "br",
  "Argentina": "ar",
  "Portugal": "pt",
  "Italy": "it",
  "Netherlands": "nl",
  "USA": "us",
  "United States": "us",
  "Mexico": "mx",
  "Japan": "jp",
  "South Korea": "kr",
  "Nigeria": "ng",
  "Senegal": "sn",
  "Ghana": "gh",
  "Morocco": "ma",
  "Colombia": "co",
  "Uruguay": "uy",
  "Belgium": "be",
  "Croatia": "hr",
  "Denmark": "dk",
  "Sweden": "se",
  "Norway": "no",
  "Switzerland": "ch",
  "Austria": "at",
  "Ireland": "ie",
  "Poland": "pl",
  "Czech Republic": "cz",
  "Serbia": "rs",
  "Romania": "ro",
  "Greece": "gr",
  "Turkey": "tr",
  "Russia": "ru",
  "Ukraine": "ua",
  "Australia": "au",
  "New Zealand": "nz",
  "Canada": "ca",
  "Jamaica": "jm",
  "Costa Rica": "cr",
  "Ecuador": "ec",
  "Peru": "pe",
  "Chile": "cl",
  "Cameroon": "cm",
  "Ivory Coast": "ci",
  "Egypt": "eg",
  "Algeria": "dz",
  "Tunisia": "tn",
  "Mali": "ml",
  "Guinea": "gn",
  "Gabon": "ga",
  "Paraguay": "py",
  "Bolivia": "bo",
  "Iran": "ir",
  "Saudi Arabia": "sa",
  "China": "cn",
  "India": "in",
  "South Africa": "za",
  "DR Congo": "cd",
  "Honduras": "hn",
  "Panama": "pa",
  "Venezuela": "ve",
  "Bosnia & Herzegovina": "ba",
  "Kosovo": "xk",
  "Uzbekistan": "uz",
  "Cape Verde": "cv",
  "Cura\xE7ao": "cw",
  "Iraq": "iq",
  "Cuba": "cu",
  "Iceland": "is",
  "Luxembourg": "lu",
  "Hungary": "hu",
  "Slovakia": "sk",
  "Bulgaria": "bg",
  "Finland": "fi",
  "Montenegro": "me",
  "North Macedonia": "mk",
  "Albania": "al",
  "Guinea-Bissau": "gw",
  "Slovenia": "si",
  "Georgia": "ge",
  /* West Germany flew the flag Germany flies today and Czechoslovakia the one
     the Czech Republic kept, so those two draw a true flag. The Soviet Union
     and Yugoslavia are deliberately absent: their only codes here were Russia
     and Serbia, whose flags they never flew, so Lev Yashin's Squad Deal card
     drew Russia's flag. With no entry they render as their name (Round 660). */
  "Bosnia": "ba",
  "West Germany": "de",
  "Czechoslovakia": "cz",
  // Exact nationality strings as they appear in player_market_values (Türkiye,
  // Cote d'Ivoire, Korea, South, Bosnia-Herzegovina, Curacao) plus common
  // footballing nations that were missing - all render real flags now instead
  // of falling back to plain text.
  "T\xFCrkiye": "tr",
  "Cote d'Ivoire": "ci",
  "Bosnia-Herzegovina": "ba",
  "Korea, South": "kr",
  "Curacao": "cw",
  "Israel": "il",
  "Belarus": "by",
  "Vietnam": "vn",
  "Armenia": "am",
  "El Salvador": "sv",
  "Northern Ireland": "gb-nir",
  "United Arab Emirates": "ae",
  "Angola": "ao",
  "Lithuania": "lt",
  "The Gambia": "gm",
  "Suriname": "sr",
  "Burkina Faso": "bf",
  "Guatemala": "gt",
  "Benin": "bj",
  "Cyprus": "cy",
  "Oman": "om",
  "Haiti": "ht",
  "Indonesia": "id",
  "Kazakhstan": "kz",
  "Togo": "tg",
  "Comoros": "km",
  "Guadeloupe": "gp",
  "Faroe Islands": "fo",
  "Zambia": "zm",
  "Latvia": "lv",
  "Fiji": "fj",
  "Libya": "ly",
  "Malta": "mt",
  "Moldova": "md",
  "Azerbaijan": "az",
  "Tajikistan": "tj",
  "Sierra Leone": "sl",
  "Congo": "cg",
  "Lebanon": "lb",
  "Kenya": "ke",
  "Liberia": "lr",
  "Zimbabwe": "zw",
  "Qatar": "qa",
  "Estonia": "ee",
  // Round 1035: Transfermarkt's spelling, and ESPN's and FotMob's, for an
  // A-League Men player whose nationality two of them agree on.
  "Southern Sudan": "ss",
  "South Sudan": "ss",
  // Round 925: Tim Duncan's birth country on nba.com and basketball-reference.
  "US Virgin Islands": "vi",
  // July 2026 site-wide flag-image sweep: names used by pools that previously
  // rendered emoji (dealPlayers, puckDetective labels, Olympics athletes).
  "Czechia": "cz",
  "Gambia": "gm",
  "Mozambique": "mz",
  "Equatorial Guinea": "gq",
  "Korea Republic": "kr",
  "Republic of Ireland": "ie",
  "Great Britain": "gb",
  "United Kingdom": "gb",
  "Bosnia and Herzegovina": "ba",
  "Saint Lucia": "lc",
  "Dominican Republic": "do",
  "Trinidad and Tobago": "tt",
  "Philippines": "ph",
  "Thailand": "th",
  "Jordan": "jo",
  "Bahrain": "bh",
  "Kuwait": "kw",
  "Uganda": "ug",
  "Tanzania": "tz",
  "Ethiopia": "et",
  "Madagascar": "mg",
  "Andorra": "ad",
  "San Marino": "sm",
  "Liechtenstein": "li",
  "North Korea": "kp",
  "Korea, North": "kp",
  /* Round 124: the other ten OFC full members, so an Oceania qualifying group
     shows real flags instead of bare country names. Tahiti plays under the
     French Polynesia flag (pf). */
  "New Caledonia": "nc",
  "Tahiti": "pf",
  "Solomon Islands": "sb",
  "Papua New Guinea": "pg",
  "Vanuatu": "vu",
  "Samoa": "ws",
  "American Samoa": "as",
  "Cook Islands": "ck",
  "Tonga": "to",
  "Syria": "sy",
  "Palestine": "ps",
  /* Round 194: nationalities surfaced by the player_market_values pass
     that had no flag yet. Codes are ISO 3166-1 alpha-2 as flagcdn serves
     them (Martinique mq, Guadeloupe gp and Saint-Martin mf are the French
     overseas codes flagcdn carries; football federations list players
     under them). */
  "Guyana": "gy",
  "Central African Republic": "cf",
  "Gibraltar": "gi",
  "Barbados": "bb",
  "St. Kitts & Nevis": "kn",
  "Grenada": "gd",
  "Seychelles": "sc",
  "Martinique": "mq",
  "Chad": "td",
  "Burundi": "bi",
  "Yemen": "ye",
  "Mauritania": "mr",
  "Saint-Martin": "mf",
  "Mauritius": "mu",
  // Round 902: Namibia, which the 2005-06 Bundesliga and Ligue 1 rows brought
  // (they brought French Guiana too, which Round 901 already flags just below).
  "Namibia": "na",
  /* Round 901: two nationalities the 2010-11 Serie A, Bundesliga and Ligue 1
     rows carry that had no flag yet. ISO 3166-1 alpha-2 codes, both served by
     flagcdn (probed 2026-10-03, w40 returns 200 for ne and gf). */
  "Niger": "ne",
  "French Guiana": "gf",
  /* Round 453: the two nationalities the golf and UFC pools print that had no
     flag yet. ISO 3166-1 alpha-2 codes, both served by flagcdn (probed
     2026-09-05, w40 returns 200 for je and kg). */
  "Jersey": "je",
  "Kyrgyzstan": "kg",
  /* Round 453, found by simNationalityFlags: Soccer Career's club table names
     Al Ain's country "UAE", which had no entry here, so an offer from Al Ain
     showed the letters where every other club shows a flag. Monaco and
     Malaysia are the other two club countries in that table with no flag. */
  "UAE": "ae",
  "Monaco": "mc",
  "Malaysia": "my",
  /* Round 669: Bangladesh, for Hamza Choudhury, the first Bangladesh
     international the defensive midfield research found. His row is held
     for now (the second site plays him at right back), so this is ready for
     when it lands. flagcdn serves bd (probed 2026-09-28, w40 returns 200). */
  "Bangladesh": "bd"
};
export {
  FALLBACK_CLUBS,
  FLAG_CODES,
  acceptOffer,
  advanceProSeason,
  advanceYouthYear,
  dismissNewspaper,
  flagEmojiToIso,
  initCareer,
  isSoccerCareerSave,
  repairCareer
};
