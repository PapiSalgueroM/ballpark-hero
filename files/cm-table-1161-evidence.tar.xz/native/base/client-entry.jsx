import React from 'react';
import {createRoot} from 'react-dom/client';
import {LeagueTableCard} from "/home/runner/work/_temp/table-1161.8KVA4Z/base-root/src/components/club-manager/LeagueTableCard.tsx";
export function mount(fixture){
 const input=JSON.parse(JSON.stringify(fixture)); let calls=[],submits=0;
 const view=createRoot(document.getElementById('fixture-root'));
 const publish=()=>{document.getElementById('callback-output').textContent=JSON.stringify(calls);};
 window.__table1161={snapshot:()=>({fixture:JSON.parse(JSON.stringify(input)),calls:[...calls],submits}),reset:()=>{calls=[];publish();}};
 view.render(<form onSubmit={e=>{e.preventDefault();submits++;}}>
  <button type="button" data-sentinel="before">Before table</button>
  <section data-table-board><LeagueTableCard rows={input.rows} myClub={input.myClub} compact={input.compact} preseason={input.preseason} zoneTop={input.zoneTop} title={input.title} footnote={input.footnote} isUnnamed={club=>club===input.unnamed} onClubClick={input.interactive?club=>{calls.push(club);publish();}:undefined}/></section>
  <button type="button" data-sentinel="after">After table</button><output id="callback-output">[]</output>
 </form>);
}