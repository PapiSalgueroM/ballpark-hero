import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';

async function main() {
  assert.equal(process.env.GITHUB_ACTIONS, 'true', 'Remote-only generator receipt');
  const root = process.cwd(), out = process.env.E;
  assert(out && process.env.TMPDIR, 'Owned external evidence and temp roots');
  const hash = bytes => createHash('sha256').update(bytes).digest('hex');
  const read = file => JSON.parse(fs.readFileSync(file, 'utf8'));
  const write = (file, value) => fs.writeFileSync(path.join(out, file), JSON.stringify(value, null, 2) + '\n');
  const routes = ['/nba-my-career', '/nfl-my-career', '/mlb-my-career', '/nhl-my-career', '/build-your-xi'];
  const parts = ['howToPlay', 'rules', 'example', 'tips'];
  const guideDir = path.join(root, 'src/data/gameContent');
  const inputFiles = fs.readdirSync(guideDir).sort();
  assert.equal(inputFiles.length, 17, 'Exact current guide fingerprint input inventory');
  const inputs = inputFiles.map(file => {
    const bytes = fs.readFileSync(path.join(guideDir, file));
    return { file: 'src/data/gameContent/' + file, bytes: bytes.length, sha256: hash(bytes) };
  });
  const source = hash(Buffer.from(inputFiles.map(file => fs.readFileSync(path.join(guideDir, file), 'utf8').replace(/\r\n/g, '\n')).join('\n'))).slice(0, 16);
  const bundle = path.join(process.env.TMPDIR, 'dukbSearchKeywords.bundle.mjs');
  const entry = path.join(process.env.TMPDIR, 'dukbSearchKeywordsEntry.mjs');
  assert.equal(fs.readFileSync(entry, 'utf8'), `\nexport { GAME_CONTENT } from '${root}/src/data/gameContent/index.ts';\nexport { flatGuide } from '${root}/src/data/gameContent/guideShape.ts';\nexport { CATEGORIES } from '${root}/src/data/gameRegistry.ts';\n`, 'Actual keyword generator entry imports exact held sources');
  const generated = await import(pathToFileURL(bundle).href);
  const games = generated.CATEGORIES.flatMap(category => category.games);
  const projection = Object.fromEntries(routes.map(route => {
    const content = generated.GAME_CONTENT[route];
    assert(content && games.some(game => game.path === route), 'Actual registered guide: ' + route);
    const flat = generated.flatGuide(content);
    for (const part of parts) assert(Array.isArray(flat[part]) && flat[part].length > 0 && flat[part].every(line => typeof line === 'string' && line.length > 0), route + '/' + part);
    return [route, Object.fromEntries(parts.map(part => [part, flat[part]]))];
  }));
  write('actual-guide-projection.json', projection);
  const keywords = read('src/data/searchKeywords.json');
  const beforeKeywords = read(path.join(out, 'before/searchKeywords.json'));
  const frozen = read('scripts/data/guideHeadingsFrozen.json');
  const beforeFrozen = read(path.join(out, 'before/guideHeadingsFrozen.json'));
  const keywordCheck = candidate => {
    assert.equal(candidate.v, 1, 'Actual keyword schema version');
    assert.equal(candidate.source, source, 'Keyword fingerprint matches all actual guide inputs');
    assert.deepEqual(Object.keys(candidate.k).sort(), [...new Set(games.map(game => game.path))].sort(), 'Keyword coverage equals actual registry');
    assert(Object.values(candidate.k).every(words => typeof words === 'string' && words.trim().length > 0), 'Every keyword row contains words');
  };
  const frozenCheck = candidate => {
    assert.deepEqual(Object.keys(candidate).sort(), Object.keys(beforeFrozen).sort(), 'Frozen fixture top-level keys held');
    for (const key of Object.keys(beforeFrozen).filter(key => key !== 'routes')) assert.deepEqual(candidate[key], beforeFrozen[key], 'Existing fixture metadata held: ' + key);
    assert.deepEqual(Object.keys(candidate.routes), Object.keys(beforeFrozen.routes), 'Existing frozen route inventory and order held');
    for (const route of Object.keys(beforeFrozen.routes)) {
      assert.deepEqual(candidate.routes[route], routes.includes(route) ? projection[route] : beforeFrozen.routes[route], 'Frozen route text equals actual projection or held baseline: ' + route);
    }
  };
  keywordCheck(keywords); frozenCheck(frozen);
  assert.notEqual(beforeKeywords.source, source, 'Prospective guide source differs from stale keyword input');
  assert.notDeepEqual(beforeFrozen.routes[routes[0]], projection[routes[0]], 'NBA prospective text differs from its original frozen record');
  const controls = [];
  const catchIntended = (name, baseline, changed, check, message) => {
    assert.notDeepEqual(changed, baseline, 'Copied control changes actual output: ' + name);
    write('controls/' + name + '.json', changed);
    let error;
    try { check(changed); } catch (caught) { error = caught; }
    assert(error && error.name === 'AssertionError' && error.message.includes(message), 'Exact intended copied-output failure: ' + name);
    controls.push({ name, baselineSha256: hash(Buffer.from(JSON.stringify(baseline))), changedSha256: hash(Buffer.from(JSON.stringify(changed))), error: { name: error.name, message: error.message, actual: error.actual, expected: error.expected, operator: error.operator } });
    check(baseline);
  };
  const staleKeywords = structuredClone(keywords);
  staleKeywords.source = beforeKeywords.source;
  catchIntended('stale-keyword-fingerprint', keywords, staleKeywords, keywordCheck, 'Keyword fingerprint matches all actual guide inputs');
  const staleFrozen = structuredClone(frozen);
  staleFrozen.routes[routes[0]] = beforeFrozen.routes[routes[0]];
  catchIntended('stale-nba-frozen-record', frozen, staleFrozen, frozenCheck, 'Frozen route text equals actual projection or held baseline: /nba-my-career');
  const stages = [{ name: 'keywords', command: ['node', 'scripts/genSearchKeywords.mjs'] }, ...routes.map((route, index) => ({ name: 'refresh-' + (index + 1), command: ['node', 'scripts/simGuideHeadings.mjs', '--refresh', route] }))];
  const stdout = stages.map(stage => {
    const bytes = fs.readFileSync(path.join(out, 'logs', stage.name + '.log'));
    const text = bytes.toString('utf8');
    if (stage.name === 'keywords') assert(text.includes('source hash ' + source), 'Actual keyword command printed current source fingerprint');
    else assert(text.includes('simGuideHeadings: refreshed ' + stage.command[3] + ' from its actual guide ('), 'Actual refresh command printed its exact route');
    assert.equal(fs.readFileSync(path.join(out, 'commands', stage.name + '.txt'), 'utf8'), stage.command.join(' ') + '\n', 'Exact executed generator command');
    return { ...stage, stdoutBytes: bytes.length, stdoutSha256: hash(bytes) };
  });
  const changedFrozenRoutes = Object.keys(frozen.routes).filter(route => JSON.stringify(frozen.routes[route]) !== JSON.stringify(beforeFrozen.routes[route]));
  assert(changedFrozenRoutes.every(route => routes.includes(route)), 'Only reviewed frozen records change');
  const changedKeywordRoutes = [...new Set([...Object.keys(beforeKeywords.k), ...Object.keys(keywords.k)])].filter(route => beforeKeywords.k[route] !== keywords.k[route]);
  const file = name => { const bytes = fs.readFileSync(name); return { file: name, bytes: bytes.length, sha256: hash(bytes) }; };
  write('generator-receipt.json', { disposition: 'GENERATOR_DELIVERY_ONLY', source, inputs, stages: stdout, projectionSha256: hash(fs.readFileSync(path.join(out, 'actual-guide-projection.json'))), outputs: [file('src/data/searchKeywords.json'), file('scripts/data/guideHeadingsFrozen.json')], temporaryBundle: [file(entry), file(bundle)], changedFrozenRoutes, changedKeywordRoutes, controls, limitations: ['No build, reader, browser, public snapshot, gameplay, engine, integration, production or release acceptance.'] });
  console.log('Guide generator receipt1157: PASS, actual two outputs, five refreshed routes, all other frozen records held and two effective copied-output controls.');
}

await main();
