// src/data/gameContent/academyManagement.ts
var ACADEMY_MANAGEMENT_CONTENT = {
  "/wonderkid-factory": {
    intro: [
      "Wonderkid Factory is a free idle football academy game. Scouts bring kids through the door, coaches make every one of them a little better every second, and each kid has a ceiling he will never grow past. The whole game is one repeated decision: sell him now, or let him cook a bit longer.",
      "A transfer fee pays for the rating on the day plus a promise premium for the room he still has to grow, and that premium is fattest while he is young. From 21 it starts to fade and at 23 it is gone completely. A kid still in an academy bed on his 24th birthday walks out on a free. Promote him before then and his first-team career can last until 34.",
      "Cash buys four upgrades, reputation stars make every future run faster, and six regions raise the ceilings your scouts can find, from District Fields all the way to the World Stage. Every kid is generated, so no real footballer ever appears in your academy."
    ],
    headings: {
      howToPlay: "How to play Wonderkid Factory, a free idle soccer academy game",
      rules: "Wonderkid Factory rules: ceilings, ages and academy money",
      example: "Wonderkid Factory walkthrough: scouting a kid through to a sale",
      tips: "Wonderkid Factory tips for scouting, selling and region moves",
      faq: "Wonderkid Factory FAQ: scouting, selling and the academy save"
    },
    howToPlaySections: [
      {
        heading: "Scouts bringing in kids and reading their ceiling",
        items: [
          "Wait for the scouts: kids arrive on their own, faster with every Scouting network level.",
          "Watch each kid grow toward his hidden ceiling. Scouting level 3 reads the ceiling as a range, level 6 reads it exactly, and a kid from a pack arrives with his tier's band already known."
        ]
      },
      {
        heading: "Selling a kid when his price looks right",
        items: [
          "Press Sell on a kid when the price looks right. The fee is quoted live on his card."
        ],
        subsections: [
          {
            heading: "Promoting a graduate to the first team",
            items: [
              "From age 18 to 23, you can promote a kid into one of five first-team places instead. Promotion frees his bed without paying a fee. Open First team to select a graduate, see his next birthday and decide when to sell him."
            ]
          }
        ]
      },
      {
        heading: "Boots from Stadium Tycoon titles and academy spending",
        items: [
          "Titles at Stadium Tycoon earn fictional boots and kit upgrades. Open the Boot room from First team to choose a wearer, move a pair or improve its level. Boots add to match rating for the defensive edge, without changing the player's transfer fee. Your collection survives sales, retirement and moving either ground.",
          "Spend the cash on Scouting, Coaching, Dorms and the Agent office. Costs climb with every level."
        ]
      },
      {
        heading: "Showcase Day training runs and the Deadline Day multiplier",
        items: [
          "Press Showcase Day when it charges: training runs x3 for 25 seconds.",
          "Hold your best kids for Deadline Day, which arrives every few minutes and pays x1.5 on every fee for 50 seconds."
        ]
      },
      {
        heading: "Moving your academy up through the Reputation box",
        items: [
          "Earn the region target, then move the academy up in the Reputation box: kids, cash and facilities stay behind, the star is forever."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "The fixed ceiling and the fading promise premium",
        items: [
          "Every kid has a fixed ceiling, hidden until your scouts or his pack tier tell you where it sits. Training slows as he approaches it and can never pass it.",
          "The promise premium fades from age 21 and is gone at 23. At 24 a kid still in the academy leaves on a free. Promoted players follow the longer first-team career."
        ]
      },
      {
        heading: "How a senior trains, ages and eventually retires",
        items: [
          "A senior trains at half the academy rate through age 27, holds his rating at 28 and 29, then loses 1.2 rating at each birthday from 30. A senior year lasts fifteen watched academy minutes. He retires at 34 for no fee, and nobody ages while you are away."
        ],
        subsections: [
          {
            heading: "Working out a senior's transfer fee",
            items: [
              "Senior fees use the same rating, potential, position and academy bonuses as youth fees. The age multiplier stays at one through 27, then falls to 0.90 at 28, 0.78 at 29, 0.64 at 30, 0.50 at 31, 0.36 at 32 and 0.22 at 33. The next-birthday quote assumes no further training and keeps today's fee multiplier, so a later Deadline Day can change the actual offer."
            ]
          }
        ]
      },
      {
        heading: "What your first team does in Stadium Tycoon matches",
        items: [
          "The first team reduces opponents' scoring chances in Stadium Tycoon. Each rating point above 60 helps, across up to five players. Selling a senior funds academy upgrades but removes his contribution immediately. The first team travels with you when you move the academy up or sell the ground."
        ]
      },
      {
        heading: "Full beds, reputation stars and region ceilings",
        items: [
          "A full academy stops scouting: beds come from the Dorms.",
          "Reputation stars pay +15% training speed and +10% on every fee, each, forever.",
          "Each region raises the ceilings scouts can find. The World Stage can produce a 99."
        ]
      },
      {
        heading: "Progress while you are away and how saves work",
        items: [
          "Away from the game, scouting and training run at half speed for up to 8 hours, and nobody ages while you are gone. Nothing sells itself either.",
          "Progress saves on this device. No sign-up."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Scouting a young midfielder with a wide ceiling range",
        paragraphs: [
          "Say the scouts drop off a 17 year old midfielder rated 58, and your level 3 scouts read his ceiling as somewhere between 68 and 75. Selling on the spot pays a modest fee: decent rating, healthy promise premium."
        ]
      },
      {
        heading: "Watching the promise premium shrink as he grows older",
        paragraphs: [
          "You leave him with the coaches while you upgrade the Agent office. By the time he is 19 he is rated 71 and the growth has visibly slowed, which tells you the ceiling is close. His card now quotes about a quarter more than the day one fee: the rating grew, but the promise premium shrank with his age."
        ]
      },
      {
        heading: "Selling into Deadline Day for the fee bonus",
        paragraphs: [
          "Deadline Day lights up. You press Sell inside the window and the fee pays half as much again. That one sale funds two Scouting levels, and the next kid through the door is found faster and read more precisely."
        ]
      },
      {
        heading: "Weighing a bigger fee against your defensive edge",
        paragraphs: [
          "For a first-team decision, picture five graduates rated 80. Their combined edge cuts the opponent's scoring chance by twenty percent before the match minimum. Selling one funds facilities but drops that edge to sixteen percent. A player nearing 28 may still help win a title even as his resale multiplier begins to fall, so the bigger fee and the stronger team are different rewards."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Selling fast early before your Scouting improves",
        items: [
          "Early on, sell quickly and often: volume beats patience until Coaching has some levels.",
          "Scouting level 3 changes the game. Knowing the ceiling range tells you who is worth the wait."
        ]
      },
      {
        heading: "Knowing when a kid stops earning you anything more",
        items: [
          "A kid within a point of his ceiling has stopped earning you anything by waiting. Sell him on the next Deadline Day."
        ]
      },
      {
        heading: "Keeping Dorms full and spending before you move up",
        items: [
          "Dorms are quietly the best value when your academy keeps sitting full: a stopped scout earns nothing.",
          "Spend before you move up. Cash, facilities and every kid stay behind when the academy moves, and the next region's target counts from zero, so money left in the bank on moving day is simply gone."
        ]
      }
    ],
    faqs: [
      { q: "Are the players real?", a: "No. Every kid is generated, names and all, and the game checks its generated names against every real player on the site so a made up kid can never wear a real name." },
      { q: "What do reputation stars do?", a: "Each star is +15% training speed and +10% on every fee, forever, and stars also unlock the next region, where scouts find kids with higher ceilings." },
      { q: "Do I lose everything when I move up?", a: "Cash, facility levels and the kids still in academy beds stay behind. Your promoted first team, stars and career totals travel with you." },
      { q: "Does the game progress while I am away?", a: "Scouting and training keep running at half speed for up to 8 hours, and the calendar pauses so nobody ages out while you sleep. Sales are always yours to make, so no money moves while you are gone." },
      { q: "When exactly should I sell?", a: "A trained academy kid can keep gaining value up to the eve of his 24th birthday, so watch the fee and the birthday together. First-team players create a different choice: their sale multiplier falls from 28, but keeping a strong graduate can still help win matches. Compare the current fee, the next-birthday quote and your title race." }
    ]
  }
};

// src/data/gameContent/aussieRulesManagement.ts
var AUSSIE_RULES_MANAGEMENT_CONTENT = {
  "/aussie-rules-manager": {
    intro: [
      "Aussie Rules Manager hands you one of eighteen fictional clubs and as many seasons as you want to give it. Each season is 23 rounds, then the finals, a Grand Final, a summer of birthdays and retirements, and a national draft that fills your list back up for next year. Goals are worth six, behinds one, and the ladder runs on four points a win.",
      "The clubs, players, ratings and results are all made up. The shape of the competition is real where we could check it against two sources: the 2026 finals add a wildcard week, where 7th plays 10th and 8th plays 9th, before the final eight that has run since 2000. Playing 23 rounds with no byes, lists of 36 and the summer growth are this game's own rules, not the real AFL fixture or a prediction of anything. The draft order follows the real 2026 one.",
      "You can play without an account. Your career is kept in this browser when storage is available, mid match included. Every season you finish records a play rather than adding ranked points. A season takes as long as you like: three taps a round if you let the list manager pick and play each match in one go, or a quarter at a time if you want to call it."
    ],
    headings: {
      howToPlay: "How to Play Aussie Rules Manager",
      rules: "Aussie Rules Manager Match and Season Rules",
      example: "Aussie Rules Manager Worked Example",
      tips: "Aussie Rules Manager Squad and Tactics Tips",
      faq: "Aussie Rules Manager Questions"
    },
    howToPlay: [
      "Choose a club from the menu. The clubs are grouped from contenders down to battlers, so you can pick an easy start or a long rebuild. Every club has thirty-six generated players with a skill, a ceiling, an age and a fitness level.",
      "Before each match your list manager picks the best eighteen starters and five interchange players on current form: skill, less what fatigue takes off. You can change any spot in Squad, then choose to train or rest. Training adds eight preparation and eight fatigue to every player; rest takes thirty fatigue off.",
      "Pick a tactic and play one quarter at a time, or play the whole match in one tap with the same tactic. At each quarter break you can make up to five same-role changes from the bench.",
      "After the match you see the round's other results. The hub boxes show your next match, your ladder spot with points and percentage, your squad, your honour board, and the finals bracket once September comes round.",
      "Finish in the top ten to play the finals. Win the Grand Final for the flag. Then the summer ages everyone a year, some veterans retire, and on draft night you pick young players to fill your list back to thirty-six before the next season starts."
    ],
    rules: [
      "A goal adds six points and a behind adds one. A displayed score of 6.8 means six goals and eight behinds, for 44 points. Compare totals to find the winner.",
      "A match has four quarters. The 2026 match rules use eighteen players on the field, five interchange players and centre throw-ups. The five bench players do not include a separate substitute.",
      "A league win earns four ladder points, a draw earns two for each club and a loss earns none. Percentage is total points scored divided by total points conceded, multiplied by one hundred. Clubs are ranked by ladder points, then percentage. An exact tie uses the club list order as this game's final tiebreak.",
      "The season is 23 rounds of nine games, so every club plays every other club once and six of them twice, home and away. The draw changes every season. Real seasons have an opening round and byes; this game leaves them out.",
      "The finals follow the 2026 system: a wildcard week where 7th hosts 10th and 8th hosts 9th, with the higher placed winner taking the 7th spot. Then qualifying finals 1st v 4th and 2nd v 3rd, where the winners rest a week and the losers drop to a semi final, and elimination finals 5th and 6th against the wildcard winners, where the losers go out. Preliminary finals and the Grand Final follow. A drawn final, the Grand Final included, plays two 3 minute periods of extra time, and two more until somebody leads, with no golden score. Real periods add time on; this game keeps them a flat 3 minutes.",
      "Our squad selection uses six backs, five midfielders, one ruck and six forwards, plus five bench players. Same-role swaps and the limit of five swaps per break are game constraints. They are not presented as official restrictions on all real-world positional changes.",
      "Bench changes are offered at quarter breaks. AFL Regulation 12.8 excludes changes during those intervals from the counted interchange limit. There is no pretend interchange counter for changes that do not count toward it.",
      "The summer is this game's rule. Players under 22 grow two to five points a year toward their ceiling, the mid twenties grow a little, the late twenties hold, and from thirty they slow down. Retirement starts at 31 and nobody plays past 35. The draft order is the real 2026 one: clubs that missed the finals first, worst first, then finalists by the week they went out, with the runner up and the premier last. Every list must keep seven backs, six midfielders, two rucks and seven forwards.",
      "Your local save belongs to this browser. Reloading a finished season does not earn another completion. Private browsing, denied storage or clearing site data can prevent a career from being kept, so the game does not promise a cloud save."
    ],
    example: [
      "Imagine your club reaches half time on 6.8 (44), while the opponent has 7.2 (44). They have kicked one more goal, but the match is level on points. You use the break to bring a fresh midfielder on for a tired one.",
      "Suppose the match ends 12.10 (82) to 11.12 (78). Your club wins by four points and takes four ladder points. Over the season, 1850 points for and 1700 against gives a percentage of 1850 / 1700 x 100 = 108.8, which splits you from a club on the same points with 104.3.",
      "Now say you finish 3rd. You meet 2nd in a qualifying final. Win, and you rest a week before a preliminary final. Lose, and you still get a semi final against an elimination final winner. Finish 8th instead and you host 9th in the wildcard week, then need four more wins for the flag."
    ],
    tips: [
      "Read fatigue alongside skill. Twenty three rounds is long, and a team that trains every week runs out of legs by the back half. Rest when the matchday group is tired.",
      "Read the tactic matchup before each quarter. In this simulation, Control counters Direct, Direct counters Pressure, and Pressure counters Control. The opponent read shows their usual style. They stick with it about half the quarters and switch the rest, so countering it helps but never locks in a win.",
      "Percentage matters. Two clubs on the same points are split by it, so a big win in round three can decide who plays a home final in September.",
      "Think about the draft before it comes. If a ruck or two are near the end, the list must keep two rucks, and a pick that would leave you short is refused. Ceilings on draft night are your scouts' range, not a promise.",
      "Young players with room to grow are the long game. A nineteen year old with a high ceiling can be your best player in three seasons."
    ],
    faqs: [
      { q: "Does Aussie Rules Manager use real AFL players or clubs?", a: "No. Clubs, players, skills and match results are generated for this fictional league. They are labeled as game data rather than passed off as a verified real roster." },
      { q: "How do goals and behinds work?", a: "Goals are worth six points and behinds are worth one. The total wins the match. For example, 12.8 (80) beats 11.10 (76) even though it came from one fewer scoring shot." },
      { q: "Why are there five players on the bench?", a: "The 2026 AFL matchday setup has eighteen players on the field and five interchange players. This game keeps that shape and lets you swap same-role players at the breaks." },
      { q: "Does this use the real AFL draw and finals?", a: "The finals, yes in shape: the 2026 wildcard week for 7th to 10th, then the final eight. The draw, no: this game plays 23 rounds with no byes and makes a new fixture each season between eighteen fictional clubs." },
      { q: "Can I resume my season?", a: "Yes. Your whole career, every season of it, is kept in local browser storage when storage is available, including a match paused at a quarter break. An older ten round season from the first version of this game still opens where you left it." },
      { q: "Does finishing add points to the leaderboard?", a: "Each finished season records a completed play with no ranked score. A restored season does not record again." }
    ]
  }
};

// src/data/gameContent/stadiumManagement.ts
var STADIUM_MANAGEMENT_CONTENT = {
  "/stadium-tycoon": {
    intro: [
      "Stadium Tycoon is an idle game about the part of football nobody streams: the turnstiles. You start with a fence and ninety loyal fans, and you grow that into a ground that hums, one upgrade at a time, while a live toy match plays out on screen and pays you for every goal.",
      "It is built to be alive. The crowd fills the stand seat by seat as your real attendance grows, money floats off everything that earns, goals throw confetti, and a win streak lights a flame that multiplies the lot. Leave the tab and the turnstiles keep spinning at half speed for up to eight hours.",
      "And it goes deep. Your ground plays in a league with a real table, and winning it climbs a ladder of ten divisions that multiply everything you earn, a payroll of eight staff earns around the clock, a golden whistle drifts in with five different prizes, and 47 badges each add a permanent two percent. Selling up resets the club but never the badges, so every run starts faster than the last.",
      "There is a second room too. The Academy tab runs a youth academy right beside the ground, on its own save, and once you have opened it the kids keep training and ageing while you watch the match."
    ],
    headings: {
      howToPlay: "How to play Stadium Tycoon, a free idle football stadium game",
      rules: "Stadium Tycoon rules: crowds, divisions, gems and time away",
      example: "A Stadium Tycoon walkthrough, from the fence to the first sell up",
      tips: "Stadium Tycoon tips for a faster idle build",
      faq: "Stadium Tycoon FAQ: selling up, gems and the golden whistle"
    },
    howToPlaySections: [
      {
        heading: "Turnstiles, taps and the upgrade tiles",
        items: [
          "Watch the money counter climb. Every fan in the ground pays you every second.",
          "Tap the stadium for instant cash. The Megaphone track makes every tap stronger."
        ],
        subsections: [
          {
            heading: "What each upgrade tile does",
            items: [
              "Buy upgrades from the nine tiles: Stands add seats, Ticket Office, Snack Bar and Club Shop raise what each fan spends, Parking pays flat money, Floodlights and Academy grow the fanbase, Squad wins matches, Megaphone boosts taps."
            ]
          }
        ]
      },
      {
        heading: "Live matches and the league ladder",
        items: [
          "Follow the match at the top of the pitch. Goals pay a bonus scaled by the crowd, wins extend your streak, and the streak multiplies income and pulls in new fans.",
          "Win your league to climb the divisions. Each division is a small league of named rival clubs with a table on the League tab, and only the champion goes up. Every division multiplies all income up to five and a half times, each promotion pays a bonus on the spot, and higher divisions send tougher opponents."
        ]
      },
      {
        heading: "Staff, whistles and set piece offers",
        items: [
          "Hire from the payroll: eight staff from a Turnstile Steward to a Club Legend Ambassador, each level adding steady income of its own before the multipliers touch it."
        ],
        subsections: [
          {
            heading: "Catching the golden whistle",
            items: [
              "Catch the golden whistle when it drifts onto the pitch. You get about twelve seconds, and it carries one of five prizes, from seven times the income to fifteen minutes of income in one lump."
            ]
          },
          {
            heading: "Taking a penalty or free kick",
            items: [
              "Open a penalty or free-kick offer during a watched match. You have twelve seconds to open it, then choose your aim, power and curve while the match clock keeps running. Opening uses that match's one attempt, even if you leave or reload."
            ]
          }
        ]
      },
      {
        heading: "Selling up for Reputation stars",
        items: [
          "When lifetime earnings fill the yellow bar, sell up and move grounds: the club resets, but Reputation stars (plus 50 percent income each, forever), your badges and your club records all survive."
        ]
      },
      {
        heading: "The Academy tab and its graduates",
        items: [
          "Open the Academy tab to run your youth academy beside the stadium."
        ],
        subsections: [
          {
            heading: "Promoting players into the first team",
            items: [
              "Promote academy players aged 18 to 23 into five first-team places. A graduate frees his bed, keeps developing and helps reduce the opposition's scoring chances. Open First team in the Academy to compare his current fee with the fee at his next birthday."
            ]
          },
          {
            heading: "Boots from the boot room",
            items: [
              "League titles earn fictional boots and kit upgrades. Open First team, then Boot room, to equip a graduate or improve a pair. Boots add to match rating for defense while leaving every transfer fee unchanged. Move a pair to another player whenever you like; it stays with the club when its wearer leaves."
            ]
          }
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Attendance, the match clock and the win streak",
        items: [
          "Attendance is the smaller of your seats and the supporters who want a ticket. On Standard and Community that is your whole fanbase, and on Premium it is 75 percent of it. So Stands matter only when the ground is full and spending tracks matter only when it is not.",
          "The Ticket offer tile sets your matchday price, and switching is free at any time. Community takes 15 percent off the gate money each fan pays and grows your supporters 50 percent faster. Premium adds 25 percent to the gate money each fan pays, draws 75 percent of your supporters and grows them 25 percent slower. Snacks, the shop, parking and the payroll keep their own rates. A new 120 seat ground with 90 supporters draws 67 on Premium and earns less than Standard, and Premium earns more once 75 percent of your supporters still fill the ground.",
          "Matches run about two real minutes. Your Squad level drives your goal chance. A division's rivals stay as strong as they were when you arrived, so a club that can compete there can always win it in time, but every division up is tougher, and the longer the club has played the tougher each new division is.",
          "A win extends the streak, a draw keeps it alive without extending it, a loss ends it. The streak multiplier caps at ten wins."
        ],
        subsections: [
          {
            heading: "Charging Matchday Hype",
            items: [
              "Matchday Hype charges over eight minutes of play; pressing it doubles your income for sixty seconds and lifts your taps with it, though goal and win bonuses are not doubled. It never charges or burns while you are away, and it cannot stack."
            ]
          }
        ]
      },
      {
        heading: "How promotion up the divisions works",
        items: [
          "Divisions are earned by winning the league at your current ground. The bottom three divisions are six clubs playing each other once, five matchdays; the middle three are eight clubs home and away, and the top four ten clubs home and away. The table is ordered by points, then goal difference, then goals scored. Only the champion goes up, nobody goes down, and a title at The Summit pays the promotion bonus again. Selling up drops you back to the bottom league, though your best division and your league titles are remembered forever."
        ]
      },
      {
        heading: "Whistle timing and permanent badges",
        items: [
          "The golden whistle appears only while you are actually playing, roughly every couple of minutes, and its timed prizes (DERBY DAY at seven times income, CROWD SURGE at twenty five times taps) cannot stack with each other.",
          "Badges pay no cash. Each of the 47 is a permanent two percent income multiplier, earned exactly once per career, and they never reset."
        ],
        subsections: [
          {
            heading: "What the ground earns while you are away",
            items: [
              "Away earnings run at half your unboosted income rate, with hype and golden whistles excluded, capped at eight hours, and only count after you have been gone at least thirty seconds.",
              "Matchdays keep playing while you are away, one for every half hour of the trip and inside the same cap. They pay no goal or win bonuses, and the final matchday of a season always waits for you, so every title is won with you watching."
            ]
          }
        ]
      },
      {
        heading: "Gems, graduates and scored set pieces",
        items: [
          "Gems are earned only by results: three for a watched win, one for a watched draw, one for a win played while you were away, twenty for a league title and six for second place. They open packs of generated kids in the Academy tab, every pack prints its odds before you open it, and gems can never be bought."
        ],
        subsections: [
          {
            heading: "How graduates help in watched and away matches",
            items: [
              "Your first team helps in watched and away matches. Each rating point above 60 adds to its defensive edge. With five players rated 80, opponents get twenty percent fewer chances before the minimum chance is applied. This changes the odds, not a match's guaranteed result."
            ]
          },
          {
            heading: "When a scored kick counts",
            items: [
              "A scored set piece before full time adds one goal and the usual goal bonus. A miss, save or block costs nothing. A saved shot result cannot pay twice, and a kick left open past full time cannot change the next match. Away matches have no kick offers; these kicks have no daily record or direct gem reward."
            ]
          },
          {
            heading: "Training and ageing after the academy",
            items: [
              "First-team players train at half the academy rate through age 27. Their years take fifteen watched academy minutes, compared with five minutes for academy kids. They hold their rating at 28 and 29, lose 1.2 rating at each birthday from 30, and retire at 34 without a fee. Away time trains them without ageing them."
            ]
          }
        ]
      },
      {
        heading: "Saves and what survives a sell up",
        items: [
          "Progress saves on this device automatically. Selling up resets the ground while Reputation, badges, club records and lifetime totals survive. Your academy save, including its first team, stays with you."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Opening the gates and the Ticket Office",
        paragraphs: [
          "You open the game to 90 fans paying five cents each, $4.50 a second. The first Stands level costs 30 and adds 40 seats nobody fills yet, so you buy the Ticket Office instead and watch the rate tick up."
        ]
      },
      {
        heading: "A full ground and the Muddy Meadows title",
        paragraphs: [
          "Once Floodlights pull your fanbase past your seats, the ground is full and Stands become the best purchase on the board. With 280 in the ground a goal pays a 168 dollar bonus before any streak, and the league's fifth matchday comes about ten minutes in: top the table then and the Muddy Meadows title lifts you into the Gravel Lane League, with a promotion bonus and a bigger multiplier on every dollar after it."
        ]
      },
      {
        heading: "The yellow bar and the first star",
        paragraphs: [
          "Around a quarter of an hour in, lifetime earnings crest four million and the yellow bar glows. You sell up, keep a star, and the ninety-fan fence starts again at one and a half times the speed."
        ]
      },
      {
        heading: "A penalty offer with the scores level",
        paragraphs: [
          "You are drawing 1-1 when a penalty offer appears. Open it and aim inside the right post with medium power. If it beats the keeper before full time, your club leads 2-1 and gets its normal goal bonus. If the keeper saves it, the score stays 1-1. The match carries on either way."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Seats, spending and the Squad track",
        items: [
          "Balance seats against spend. A full ground with a poor Snack Bar wastes fans; a rich concourse with empty seats wastes upgrades.",
          "Squad is quietly the best economy track: goals pay crowd-scaled bonuses, the streak multiplier compounds everything else, and wins are what climb the division ladder."
        ]
      },
      {
        heading: "When to cash in and move grounds",
        items: [
          "Do not sit on the sell-up button. The first star is worth more than a few minutes of squeezing the old ground, and the badges you earned come with you."
        ]
      },
      {
        heading: "Tapping big crowds and whistle prizes",
        items: [
          "Tap during big crowds. Taps scale with your income rate, so a tap at 400 fans is worth many times a tap at 90, and a CROWD SURGE whistle makes thirty seconds of tapping the whole show.",
          "Never let a golden whistle drift past. Even the smallest prize beats nothing, and DERBY DAY during a full house with a streak going is the best moment the game can deal you."
        ]
      },
      {
        heading: "Staff for idle income",
        items: [
          "Staff are the idle half of the build: upgrade tracks need you watching the board, but a deep payroll earns at full rate while you only tap."
        ]
      }
    ],
    faqs: [
      {
        q: "Do I lose everything when I sell up?",
        a: "Levels, money, fanbase, staff, your ticket offer and your place on the division ladder reset. Reputation stars, all 47 badges, club records and lifetime totals stay, along with the separate academy and its first team. Each star is a permanent 50 percent income boost and each badge a permanent two percent, so runs get faster every time."
      },
      {
        q: "What is the golden whistle?",
        a: "A catchable bonus that drifts onto the pitch every couple of minutes while you play. Catch it inside about twelve seconds for one of five prizes: DERBY DAY (income pays seven times over for 77 seconds), CROWD SURGE (taps pay 25 times for 30 seconds), TV WINDFALL (fifteen minutes of income at once), WONDERGOAL GOES VIRAL (a fanbase jump) or SPONSOR GIFT (a free upgrade level)."
      },
      {
        q: "Does it earn while the tab is closed?",
        a: "Yes, at half rate for up to eight hours, paid out the next time you open the game on the same device. The league keeps going too: leave for an hour and two matchdays play without you, though the final matchday of a season always waits for you."
      },
      {
        q: "Can the opponents be beaten forever?",
        a: "Each division is tougher than the last, and a division drawn later in a club's life is tougher again, so eventually the next title stops coming. That is the signal the current ground has peaked and the sell-up bar is the way forward."
      },
      {
        q: "Can I buy gems?",
        a: "No. Gems only come from match results at your ground, and all they do is open packs of generated academy kids, each pack showing its odds before you open it. No real money ever touches them."
      },
      {
        q: "Is anything in it real players or clubs?",
        a: "No. Stadium Tycoon is entirely our own toy world, which is exactly why the crowd can throw confetti at whatever it likes."
      },
      {
        q: "Is Wonderkid Factory part of this now?",
        a: "Yes. The Academy tab runs the same academy with the same save, and the Wonderkid Factory page still works too."
      }
    ]
  }
};

// src/data/gameContent/clubManagement.ts
var CLUB_MANAGEMENT_CONTENT = {
  "/club-manager": {
    intro: [
      "Club Manager is the site's big one: a full management sim in your browser. 438 real clubs across 26 leagues in 20 countries, from the Premier League, Serie B, Ligue 2 and the Segunda Divisi\xF3n to the Danish Superliga, the Swiss Super League, Croatia's SuperSport HNL, Brazil's Serie A, Liga MX and the A-League Men, over 4,500 real players with their real 2026 ages and market values, and a board that talks like a board.",
      "Pick when you start too: today's game, or one of four real past seasons. 2020-21 is Haaland and Bellingham at Dortmund, Mbapp\xE9 and Neymar at PSG and Bruno Fernandes at United, with that summer's big moves already made (Havertz and Werner at Chelsea, Thiago at Liverpool, Su\xE1rez at Atl\xE9tico). 2015-16 is the year Leicester won it at 5000 to 1, with Vardy and Mahrez at their real pre-title values and MSN at Barcelona. 2010-11 is prime Messi and Rooney, and now Klopp's young Dortmund, Ibrahimovic's Milan and Lille's double too. 2005-06 is Ronaldinho's Ballon d'Or Barcelona with a 17 year old Messi, Mourinho's back to back Chelsea and Henry's Arsenal. All four past seasons hold all 98 clubs of their year's big five, the Premier League, La Liga, Serie A, the Bundesliga and Ligue 1 (in 2015-16 Juventus mid five-in-a-row, Lewandowski at Bayern, Ibrahimovic and Di Maria at PSG; in 2005-06 the Juventus of Buffon, Cannavaro, Nedved and Ibrahimovic, Ballack's Bayern and Juninho's Lyon); every one carries hundreds of real players at their real ages and values from that year. Or found a club of your own: name it, design the crest, name the stadium, choose the money, and build it up by signing real players."
    ],
    headings: {
      howToPlay: "How to play Club Manager, a free online football management game",
      rules: "Club Manager rules: the board, the meters and the money",
      example: "Club Manager walkthrough: a Newcastle season and a brand new club",
      tips: "Club Manager tips for fitness, tactics and building a club",
      faq: "Club Manager FAQ: the sack, saves, transfer windows and wages"
    },
    howToPlaySections: [
      {
        heading: "Pick an era, a nation and a real club",
        items: [
          "Pick your era (today, 2020-21, 2015-16, 2010-11 or 2005-06), then your nation, your league, and your club. Every tile quotes what that board will actually demand."
        ],
        subsections: [
          {
            heading: "Or found a club of your own",
            items: [
              "Or tap Create your own club: your name, your crest (shape, pattern, colors, initials), your stadium, and one of three budgets. Your club takes the league place of the division's weakest side."
            ]
          },
          {
            heading: "Or move clubs between leagues with the world editor",
            items: [
              "In today's world, the World editor tile on the nation step lets you rebuild the map before you pick: tap a club, then tap the club in another league it swaps with. Every move is a swap, so every league keeps its real size, its fixtures and its places, and you can make as many as you like, from one club to a whole super league.",
              "Example: swap Celtic with Brentford and take Celtic. You play a full Premier League season and the FA Cup, Brentford play in Scotland, and both boards judge their club against its new league, so Brentford are asked to win the Scottish Premiership and Celtic are asked to stay up. Your first season's Europe goes to the clubs who really qualified last season, wherever they play now; after that your edited tables decide it, and the edited leagues promote and relegate like any other. Reset puts the real world back."
            ]
          }
        ]
      },
      {
        heading: "Match days: team sheet, Play Live or Quick Sim",
        items: [
          "Before each match set formation, mentality and your starting XI, or use auto pick, and give a team talk when it matters.",
          "Play the match one of two ways: Play Live puts it on the pitch with the dressing room at the break, and Quick Sim goes straight to the report with the coach making your subs. Then read the report, answer the press, and manage the dressing room between games."
        ],
        subsections: [
          {
            heading: "Sim ahead on the calendar",
            items: [
              "Or open the calendar, tap any day and sim to it: every match up to that day plays in one go, and the run stops early only for a transfer window opening, the season review, the sack or a club's approach. The four fast forwards (next match, about a month, to the window, rest of season) are the same tap on a chosen day."
            ]
          }
        ]
      },
      {
        heading: "Transfer windows and the staff room",
        items: [
          "Buy and sell in the summer and January windows: negotiate fees, pay release clauses, take loans, and field bids for your own stars before rival clubs close your targets.",
          "Run the staff room: hire an attack, defence or goalkeeping coach and a lead scout, promote one of your own academy staff for nothing, pay somebody off, and decide whether to match a rival's offer when they come calling."
        ]
      },
      {
        heading: "The board's market asks and the confidence meter",
        items: [
          "Meet the two asks your board makes in the market. They are on the board screen under In the market, with the line that says how each is judged, and every number in them is worked out from your squad, your pot and your era.",
          "Keep the confidence meter alive, hit the board's objectives, collect trophies, and roll into next season while the whole world ages around you."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "What the board expects each season",
        items: [
          "Boards demand the actual prize, never a number: win the league, qualify for the Champions League or Europa League, reach mid table, or stay up, plus cup targets, a rival to finish above, and squad-building mandates.",
          "On top of those, every board makes two specific asks a season, and they are the ones you go out and buy: get one more player from the club's own country into the squad, keep one more aged 30 or over, sign somebody in the thinnest line of your squad, sign somebody 21 or under at a rating floor, or spend a set fee or more on one signing. Which two you get is fixed for your club and your season, and every threshold is read off the market and the money you really have, so the pair can always be met and never costs more than the pot. Countries come from the same per-era map the market screen puts a flag next to his name with, so anyone it has no country for counts for nobody."
        ],
        subsections: [
          {
            heading: "Your inbox and what each reply moves",
            items: [
              "Your inbox is not just the dressing room. The board chase an ask you have not met and you can take their money, give them your word or tell them no; an agent writes about a player of yours with a year left; your assistant argues about the training plan when it is wrong for the squad; the supporters trust write when the tickets are on premium; and a reporter wants a line on whether the squad is good enough. Each answer moves something with a screen behind it: the kitty, the board meter, a contract, the plan, the ticket price or the press mood. A word given to the board settles in the summer, three points of next season's opening confidence either way."
            ]
          }
        ]
      },
      {
        heading: "League lengths, past eras and created clubs",
        items: [
          "Every league plays its real length: 38 rounds in the Premier League, 46 in the Championship, 34 in the Bundesliga, with the domestic cup from a round of 16 to the final and a full Champions League on top for qualified clubs.",
          "Serie B (20 clubs), Ligue 2 (18) and the Segunda Divisi\xF3n (20) sit under Serie A, Ligue 1 and La Liga, so the bottom three of Serie A and La Liga and the bottom two of Ligue 1 really go down and swap with the top of the division below every summer. The Segunda plays 20 of its real 22 clubs: Real Sociedad B and Celta Fortuna are reserve sides that don't play the Copa del Rey, so they're left out. The promotion playoffs, Serie B's playout and the French barrages aren't played, so it's a straight swap. Most second division squads are thin in the game's data (only Pisa and Verona in Serie B, Nantes, Saint-\xC9tienne and Reims in Ligue 2, and Girona and Mallorca in the Segunda have eight or more real players), so the rest get topped up with made up youth players, marked as made up. These squads are last season's players that each club's 2026-27 squad list still names, so summer signings at these clubs aren't in yet.",
          "Brazil's Serie A is 20 clubs over 38 rounds with four going down and the Copa do Brasil as its cup. Three simplifications: it plays on the game's August to May calendar like MLS does rather than Brazil's own January to December one, the Copa Libertadores is not modelled, so a Brazilian club's season is the league and the cup, and clubs level on points are split by goal difference then goals scored, where the real table looks at wins first.",
          "Liga MX is 18 clubs and nobody goes down, because relegation is suspended for 2026-27. Three simplifications: the Apertura and the Clausura are played as one 34 round double round robin with one champion, the Liguilla is not played (the board still asks a playoff club to finish in the top eight, the places that reach it), and clubs level on points are split by goal difference then goals scored, the real table's first two steps, and the game stops there. There is no cup, because the Copa MX has not been played since 2020, and the Leagues Cup is not modelled.",
          "The A-League Men is 12 clubs and nobody goes down, since Australia has no relegation. The real season is 26 games each (home and away plus four third meetings), and last season's finals series took the top six. Here it's a 22 round double round robin and the finals aren't played, so whoever tops the table wins it, and the board asks a contender to make the top six. The Australia Cup is for Australian clubs only from 2026, so Auckland FC and Wellington Phoenix play no cup at all, and with ten clubs in the draw six of them go straight to the quarter-finals. The squads are the twelve real 2026-27 squads, read in October 2026, and a player with no market value starts at the bottom of the rating scale rather than at a made up number. No Asian competition is modelled."
        ],
        subsections: [
          {
            heading: "Each past season is a sealed world",
            items: [
              "Each past era is a sealed world: real players and values from its own year, thin squads topped up with marked youth, no Conference League because it did not exist back then, and no 2026 player can leak into your market. Each era's giants rate like the legends they were, above anyone today: Messi and Ronaldo in 2015-16 and 2010-11, Ronaldinho and Henry in 2005-06. Money in 2020-21 was close to today's, so its stars rate about where they would now, Mbapp\xE9 level with the best of 2026. Leicester still start 2015-16 at their honest pre-title level and 2005-06 boards still call the second European prize the UEFA Cup."
            ]
          },
          {
            heading: "Starting from 24 generated players",
            items: [
              "A club you create starts with 24 generated players, honestly marked as made up. Every real player stays real, and the transfer market is where you sign them. Budgets run 15, 40 or 90 million pounds, and your backing sets your wage room. Start with a better squad than the money buys and it plays that well, but your made up players sell on at that money's squad prices, still rising as they improve. Every real player carries his real nationality, filterable by nation with real flags, resolved per era so a 2010 name never wears a 2026 flag."
            ]
          }
        ]
      },
      {
        heading: "The board meter, the fan meter and the sack race",
        items: [
          "Two meters sit under the club name on every tab, words by default and the number out of 100 on tap. The board meter is the sack race itself: it opens at 60 in your first season, anywhere from 35 to 82 after that depending on how the last one went, and swings with results, cup runs, promises to the press and position against expectation. Safe is 60 and above, Under pressure is 10 to 59, under 10 reads One bad week from the sack, and at zero you are sacked. Only a result can sack you: a press answer or a handshake with another club can take the board to its last point, never to zero. The fan meter is read off this season's results (recent ones count most), your position against the club's expectation, the ticket policy and the trophies lifted this season: Singing at 65 and above, Grumbling from 40 to 64, Turning under 40, Hopeful before a ball is kicked."
        ]
      },
      {
        heading: "League tables, the match engine and contracts",
        items: [
          "Every league table shows goals for and against as a pair, 25-23, beside the goal difference those two make.",
          "A Champions League knockout that is still level when the 90 minutes run out plays thirty minutes of extra time before it goes to penalties: the final when it is level on the night, a second leg when the tie is level on aggregate. In the seasons before 2021-22 away goals came first, so a tie level on aggregate but not on away goals is over at 90 with no extra time, and an away goal scored in extra time still counts as one, which leaves the home side needing two. The live match and the report mark it AET, and the bracket says the tie went to extra time. The domestic cup still goes straight to penalties, because the real cups do not all play extra time and the game does not guess which ones do.",
          "Live matches and quick sims use the same match engine. In a quick sim, the coach replaces injured players when a legal bench player and a substitution are available. At the break, the coach can also replace up to two tired or low-morale players with fresher ones who play that position, keeping one of the game's three substitutions for a later injury. Calendar fast forwards use the same coach. Play live to make those calls yourself. The full time report names both clubs and shows the actual substitutions, stoppage time, possession and momentum.",
          "For example, if your defender gets injured after 20 minutes and a fit defender is on the bench, quick sim brings him on at that point. The report shows who went off, who came on and when. If all three substitutions are already used, or nobody on the bench can play, the injured player cannot be replaced. Quick simming a match you paused only makes changes from the saved clock onward."
        ],
        subsections: [
          {
            heading: "Wages, renewals and release clauses",
            items: [
              "Players carry contracts, wages, form, fitness and opinions. They retire, walk on expired deals unless you re-sign them at the contracts desk, and your academy feeds the first team if you invest in it. A renewal can trade 12 percent of the wage for a release clause at 1.5 times his value that day: any club can pay it, it cannot be refused, and only a later full price renewal deletes it."
            ]
          }
        ]
      },
      {
        heading: "Facilities, finances and your backroom staff",
        items: [
          "The club has four facilities, stadium, training ground, medical and dressing room, each level 1 to 10 and each starting where the club's stature puts it: the giants on 8 to 10, most clubs on 1 or 2. Level 1 does nothing. Each level up is a small real lift (faster growth for players with room under their ceiling, shorter injury spells, quicker morale recovery, more food and drink money a head) paid from the transfer kitty at a price that climbs every level."
        ],
        subsections: [
          {
            heading: "The finances desk and shirt sponsors",
            items: [
              "The finances desk sets ticket and food prices the fans and the board react to, takes one of four shirt sponsors (three honest shapes marked local or global, or a bad brand that pays 1.35 times the safe cheque and takes 6 off the fan meter for as long as the shirt carries it), lets you push any offer for six percent more until the brand walks, and projects the season's books to the last day: tickets, food, sponsor and sales in, player wages, staff wages, travel, signings, facilities and staff fees out. Wages and travel are running costs the board covers and never leave the transfer kitty."
            ]
          },
          {
            heading: "Coaches and the lead scout",
            items: [
              "The staff room holds four made up people: an attack coach, a defence coach, a goalkeeping coach and a lead scout, each with a level 1 to 10 and a ceiling he can still reach, each starting where the club's stature puts it. Level 1 does nothing at all and neither does an empty chair, so the desk can only ever add. The attack coach speeds up the forwards and the number ten, the defence coach the back line and the holding midfielder, the goalkeeping coach the keepers, and the two coaches split the middle of the park between them, with nobody ever growing past his own ceiling. The lead scout lifts what your scouts bring back from the road. Hiring costs a fee and paying somebody off costs severance, both from the transfer kitty, or you can promote from your own academy staff for nothing and grow him yourself. Rival clubs come in for the good ones, you can match two offers a season, and an approach you ignore for two weeks takes the man with it."
            ]
          }
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Newcastle and a Europa League target",
        paragraphs: [
          "You take Newcastle and the board asks you to qualify for the Europa League. A summer winger signing and a cup run to the semis keep confidence healthy even in seventh."
        ]
      },
      {
        heading: "Founding an Eredivisie club on the biggest budget",
        paragraphs: [
          "Or you found a club in the Eredivisie on the biggest budget, and the board wants the title from day one, because a squad built with 90 million should win that league. In the Premier League the same money gets told to survive first, because that league is deeper than any wallet."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Fitness, mentality and the treatment room",
        items: [
          "Fitness is a resource. Starters drain it every match and recover on rest weeks, so rotate early.",
          "Attacking mentality raises goals at both ends, defensive strangles the game. Match it to the opponent.",
          "Injured starters get auto replaced, so check the treatment room before kickoff."
        ]
      },
      {
        heading: "Choosing a league for a created club",
        items: [
          "Creating a club? The weaker the league you choose, the faster your money turns into trophies."
        ]
      }
    ],
    faqs: [
      {
        q: "How exactly do I get sacked?",
        a: "The board meter in the header hits zero at a final whistle. Losses, sitting below the expected position, cup exits and promises to the press you broke drain it, while wins, trophies and cup runs refill it. Tap the meter for the number: under 10 it reads One bad week from the sack, and one bad week can genuinely take that much."
      },
      {
        q: "Does my career save?",
        a: "Yes, on this device, and you can keep three managers going at once, each in its own slot. Close the tab mid season and the game resumes where you stopped."
      },
      {
        q: "Are the players real?",
        a: "Yes, with real market values, in both eras. The only invented players are the ones the game clearly marks: youth padding, deep-future projections, and the starting squad of a club you create yourself."
      },
      {
        q: "When do the transfer windows close?",
        a: "The calendar marks both. The summer window is open from kickoff and shuts at the final whistle of your fourth match (in 2020-21, which really kicked off late, it stays open until your last match before the real deadline of 5 October, a few matches longer); the January window opens in January and shuts after your third match from there, on the first Saturday of the new year in most leagues and a little later in a long one like the 24 club Championship, whose fixture list reaches January on its own. Deadline day wears a padlock on the grid, and every fast forward is a tap on a day that goes through the same rule."
      },
      {
        q: "Do wages come out of my transfer budget?",
        a: "No. The projected finances screen lists player wages, staff wages and travel because a club pays them, but the board covers them and holds you to a wage ceiling on the contracts desk instead. Tickets, food and drink, the sponsor, transfers, facility upgrades and the fees and pay offs on the staff desk are the lines that move the kitty."
      },
      {
        q: "Does quick simming a match give me a worse result than playing it?",
        a: "There is no quick sim penalty. Both ways use the same match engine, but quick sim now makes legal substitutions for injuries and tired players. Those changes can affect the result, just as your own substitutions can in a live match. Play live if you want to choose the changes, shape and team talk yourself."
      },
      {
        q: "The board wants a signing I cannot afford. Is that a bug?",
        a: "It should never happen, and there is a harness that walks every club in every era to prove it. Both asks are worked out from the market that save really has and the money you really hold, with spare targets on top, and the two together are checked against your pot before either goes on the board. If you genuinely cannot see a way to meet one, report it: the board is meant to ask for hard things, not impossible ones."
      },
      {
        q: "Why does the board ask for a 21 year old rated 80 rather than one who will reach 90?",
        a: "Because you can see age and rating on the market screen and you cannot see potential, so an ask about potential would be a lottery ticket rather than a target. The ceiling is still what the board is buying: a signing of 21 or under can add up to ten rating points as he grows, and about one in twelve is carrying a lot more than that."
      },
      {
        q: "Are the sponsors real companies?",
        a: "No. Every brand on the desk is invented, the good ones and the bad ones, and a harness checks the whole list against real sponsors, kit makers and bookmakers."
      }
    ]
  }
};

// src/data/gameContent/soccer1.ts
var SOCCER_CONTENT_1 = {
  "/budget-builder": {
    intro: [
      "Budget Builder gives you a huge pot of transfer money and one job: sign the best eleven the market allows. Prices are real market values, so every superstar you grab starves another position.",
      "The twist is the budget. The Today market gives you a flat billion, well short of the priciest possible XI on the full world market, and the 2015 and 2007 markets cap you at 62 percent of their own priciest XI, so there you can never buy the best name for every slot."
    ],
    headings: {
      howToPlay: "How to play $1B Budget Builder, a free soccer squad building game",
      rules: "$1B Budget Builder rules: the budget, team rating and final score",
      example: "$1B Budget Builder walkthrough: a Today market XI built around Haaland",
      tips: "$1B Budget Builder tips for spending the cap on the right shirts",
      faq: "$1B Budget Builder FAQ: the billion and the Money XI"
    },
    howToPlaySections: [
      {
        heading: "Picking a market: Today, 2015 or 2007 values",
        items: [
          "Pick a market: Today's 2026 values, or the 2015 or 2007 market where the money and names change completely."
        ]
      },
      {
        heading: "Choosing a formation and narrowing the pool",
        items: [
          "Choose one of 9 formations. In the Today market you can also narrow the pool, say Premier League only."
        ]
      },
      {
        heading: "Shopping each position you can afford",
        items: [
          "Tap a slot to shop that position. Only players you can currently afford are listed."
        ],
        subsections: [
          {
            heading: "Releasing a signing for a full refund",
            items: [
              "Sign someone and their value leaves your budget. Release anyone for a full refund."
            ]
          }
        ]
      },
      {
        heading: "Filling all eleven for the Money XI final",
        items: [
          "Fill all eleven for your team rating, then play the Money XI final."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "How your budget is set in each market",
        items: [
          "The Today market is a flat 1,000 million, one billion. The 2015 and 2007 markets cap you at 62 percent of the priciest possible XI for your formation, rounded to the nearest 10 million and never below 100 million. Your budget is always shown on screen."
        ]
      },
      {
        heading: "Team rating on a curve that tops out at 96",
        items: [
          "Team rating is the average of your eleven ratings, on a ratings curve that tops out at 96."
        ]
      },
      {
        heading: "One daily board demand worth 10 points",
        items: [
          "One board demand runs per day in each market, worth 10 bonus points if the finished XI meets it. It never blocks a signing."
        ]
      },
      {
        heading: "Final score: rating, savings and the series",
        items: [
          "Final score is your team rating, plus 1 point for every full 200 million left unspent, plus 10 for meeting the board demand, plus 15 for a series win or 5 for a draw."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Blowing half the cap on a Haaland front line",
        paragraphs: [
          "You take the Today market in a 4-3-3 and blow half the cap on the front line, Haaland through the middle. The defense budget looks grim, so you release a winger and bargain hunt for fullbacks."
        ]
      },
      {
        heading: "Bargain fullbacks and a 2 legs to 1 win",
        paragraphs: [
          "The XI rates 82, the daily demand wanted two players under 15 million, and your fullbacks tick it. You edge the Money XI 2 legs to 1 for the full haul."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Saving money at fullback and in goal",
        items: [
          "Strikers and wingers eat budgets. Cheap quality lives at fullback and in goal."
        ]
      },
      {
        heading: "Veterans as the market's best bargains",
        items: [
          "Veterans are bargains: a 33 year old star costs a fraction of his prime price and still rates well."
        ]
      },
      {
        heading: "Building toward the demand before spending",
        items: [
          "Check the board demand before spending. Demands like six nationalities are easier to build toward than to retrofit."
        ]
      }
    ],
    faqs: [
      {
        q: "Is the budget really a billion dollars?",
        a: "On the Today board, yes: exactly one billion, in dollars, which is the currency the real market values are recorded in. On the full world market the priciest possible XI costs well past it, so the squeeze is real. The 2015 and 2007 boards recompute their cap from their own smaller market, 62 percent of the priciest possible XI rounded to the nearest 10 million and never below 100 million, so those eras force the same choices."
      },
      {
        q: "What is the Money XI?",
        a: "The squad money would buy with no cap at all: the priciest available player in every slot. Your capped team faces it over three legs."
      }
    ]
  },
  "/rebuild": {
    intro: [
      "Rebuild Challenge drops you into a real club's 2026 squad with a pot sized to the badge and a wheel that decides which shirt you judge next. Spin, keep or sell the man it lands on, and leave the place better than you found it.",
      "The target scales with the job: elite squads need a nudge, modest ones a renovation. Two envelopes land before the first spin, the board's and the finance department's, more arrive as the window goes on, punishment cards wait behind every missed demand, and two computer managers rebuild rival clubs beside you.",
      "Up to four can play on one phone: pass and play, against the CPU, or a mix. Each seat rebuilds its own club through the same window, then every finished XI plays one simulated season, with a table, records and trophies at the end."
    ],
    headings: {
      howToPlay: "How to play Rebuild Challenge, a free online football rebuild game",
      rules: "Rebuild Challenge rules: seats, envelopes and the rebuild target",
      example: "Rebuild Challenge walkthrough: a modest club chasing Job Done",
      tips: "Rebuild Challenge tips for spins, sales and bidding wars",
      faq: "Rebuild Challenge FAQ: seats, saves and the finance envelopes"
    },
    howToPlaySections: [
      {
        heading: "Choosing your seats for solo or pass and play",
        items: [
          "Say who is playing: just you, or two to four seats on one phone. Seat one is you; tap any other seat to make it a friend (pass and play) or the CPU. The seats lock once the first club is picked."
        ]
      },
      {
        heading: "Setting a market restriction before the draft",
        items: [
          "Pick a market restriction first: the open market, the top five leagues only, under 25s only, wonderkids only (21 and under) or the bargain bin (nobody over 30 million). It locks the moment you pick a club."
        ],
        subsections: [
          {
            heading: "Drafting a real club and two opening envelopes",
            items: [
              "Pick a real club, tiered from elite down to modest (only clubs with a complete 2026 squad are offered, so the list moves with the data). At a fuller table each human picks in seat order, no club can be taken twice, and the CPU seats draw clubs from the same tier as the first pick. The board's envelope is open on the desk: its mood, its money and its demands. Then pick one of twenty finance envelopes blind and live with it."
            ]
          }
        ]
      },
      {
        heading: "Hiring a manager before the first spin",
        items: [
          "Hire a manager or keep the man you have for free. Each of the three candidates gets more out of one kind of player (the under 25s, the over 30s, the defence or the attack), and the number beside each name is what your XI reads with him in charge."
        ]
      },
      {
        heading: "Spinning the wheel and deciding each shirt",
        items: [
          "SPIN. The wheel draws one of your eleven shirts in a hidden order, and every shirt comes up once (only the second spin power up brings the wheel back to a shirt you already settled).",
          "Keep the man it landed on, or sell him at market value. Selling is final: the scouts bring three prices (a marquee, a solid buy and a cheap seat), promoting a fit from your own squad costs nothing, and a 40 overall is always there for the shirt if you cannot or will not pay."
        ]
      },
      {
        heading: "Closing the window and kicking off the season",
        items: [
          "When all eleven shirts are settled, the final whistle brings the reckoning: on your own, the rivals' windows and the season sim follow at once. At a fuller table your window shuts, a hand over screen asks for the next player (or the CPU plays its whole window on the spot), and the season kicks off when the last window is shut."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Sharing a table of two to four seats",
        items: [
          "At a table of two to four, the windows run one at a time and every seat gets the same eleven spins, plus any second spin its envelopes hand it. No two seats can hold the same club or end up with the same player: everyone at the table's own squad is off your market, and a man an earlier seat signed is gone by the time your list is dealt. The hand over screen shows the shut windows as numbers only, never a board, so nobody sees another seat's XI mid window."
        ]
      },
      {
        heading: "Running the shared season once every window shuts",
        items: [
          "The shared season is every finished XI plus neutral clubs from the first pick's tier to make six, home and away on a real calendar, with the same goal model as the solo season. It hands out the title, the Golden Boot, the best defence and Rebuild of the year, and records each squad's biggest win, longest unbeaten run and top scorer. Every line is a simulated result or tally and nothing more."
        ]
      },
      {
        heading: "Setting the pot from the club's tier and the board's mood",
        items: [
          "Pots scale with the club: 200 million at elite clubs, 140 at strong, 100 at mid, 65 at modest. The board's envelope then adds or takes up to 35 million depending on its mood (scaled to the club), sales add to it, and the manager's fee, war premiums and bad envelopes eat it.",
          "The board's mood runs from horrible to great. A great board drops one demand and tops the pot up. A horrible board cuts the pot and adds a fourth demand. Where a club's own money story is documented (Barcelona's sponsorship deal) the envelope says so; everywhere else the board speaks in general terms."
        ],
        subsections: [
          {
            heading: "Running the wallet into a small overdraft",
            items: [
              "The wallet can run 60 million past zero. Finish in debt and settled shirts are force sold at random, each swapped for the cheapest fit going, until the books balance."
            ]
          }
        ]
      },
      {
        heading: "Missing demands, punishment cards and new envelopes",
        items: [
          "Demands are things like three under 25s, two marquee buys, a clearout or money in the bank. They are judged on the window as you closed it, before the board's own clawback. Every miss draws a punishment card from a five card deck, without replacement: a forced sale of your best, a random exit, a 25 million clawback, a dressing room turn worth two rating points, and exactly one card that lets it go.",
          "Every second deal, another envelope arrives: from a 40 million TV windfall to a 25 million sponsor scandal, or a power up instead of money (the eight are below)."
        ]
      },
      {
        heading: "Playing the eight power ups",
        items: [
          "A power up sits in your pocket until you play it, and each one is used up when you do. The finance envelope can hold one, and so can any envelope that lands as you go.",
          "Fresh list: ask the scouts for a new three, once, whenever their list is open (not during a part exchange). 20 percent off: your next signing costs a fifth under his value. No war: the rivals stay out of your next signing.",
          "Second spin: between spins, bring the wheel back to a shirt you already settled (not one you bought or borrowed). A man you kept is sold, a squad man you promoted goes back to the bench, and the scouts deal a new list for the shirt.",
          "Veto: at the whistle the board's punishment cards come up face first. Send one back and it is shuffled in with the cards the board has not dealt, and one comes out in its place. It can be the same card, so it is a gamble, and you can always take the cards as they fell instead. You hold one veto at a time, because the whistle only takes one.",
          "Part exchange: when the wheel lands on a man, see the scouts' three before you decide. Take one and your man goes the other way, with the new man 25 percent under his value. Call it off and he stays, but the exchange is gone.",
          "Loan: when the scouts' list is open (not during a part exchange), borrow one of the three for the season at 40 percent of his value. He plays, nobody can sell him, he goes back after the season, and he does not count as a signing for the board's demands.",
          "Sneak peek: see the next envelope before it lands, money or power up, so you know how hard to spend. It lands after your next transfer move or two (a sale, a signing, a loan or a promotion), so the peek is only offered while one can still come, and if the whistle goes first it never arrives."
        ]
      },
      {
        heading: "Bidding wars, the rebuild target and saving your run",
        items: [
          "Signing a star rated 72 or higher can spark a bidding war. The rival's hidden ceiling is 112 to 157 percent of value: outbid it or walk away, and a man you walk away from is gone from your market for good.",
          "The target is your starting rating plus 2 for elite clubs, 3 for strong, 5 for mid and 7 for modest. A manager's lift only lands on the players who fit him, so no hire covers the target on its own.",
          "The run is written to this phone after every move, not at the end, so a refresh or a locked screen comes back to the same window, and at a table to the same seats and the same seat's turn. One run at a time, on that phone only. Starting again clears it, and a save that cannot be read back exactly opens a fresh run rather than a half restored one."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Setting a modest club's target on a tight pot",
        paragraphs: [
          "A modest club with a 74 rated XI makes the target 81 on a 65 million pot. The board is in a plain mood, the finance envelope is a sell on clause worth 20 million, and you hire the youth coach for 5 million. The first spin lands on the 68 rated left back: an easy sale at 4 million, and the scouts' solid option is a 74 for 18 million."
        ]
      },
      {
        heading: "Playing the power ups, worked through",
        paragraphs: [
          "Part exchange: the wheel lands on your 71 rated right back, worth 20 million. You play the exchange and the scouts show a 76 rated right back worth 40 million. Take him and he costs 30 million, your man's 20 goes the other way, so the swap costs you 10 million net for five points in the shirt.",
          "Loan: the scouts' three for a hole at centre back include an 80 rated man worth 50 million you could never buy. A loan puts him in the XI for 20 million. If the board wants three signings, though, he is not one of them.",
          "Second spin: you promoted a 66 rated squad man at left wing early, then an envelope brought 30 million. Play the second spin on that shirt, he goes back to the bench, and the new list has a 74 you can now afford.",
          "Veto: you missed two demands and drew The big sale and The clawback. Send The big sale back and it is shuffled in with itself and the three cards the board has not dealt (Somebody goes, The dressing room turns, The board lets it go). It is about a one in four chance it comes straight back and about one in four it is the safe card, while The dressing room turns costs two points of rating, so it is a real call.",
          "Sneak peek: you are about to go 40 million into the overdraft on a striker. Peek first: the next envelope is a 25 million sponsor scandal, so you take the cheaper option and finish out of debt."
        ]
      },
      {
        heading: "Deciding whether to keep or sell the star striker",
        paragraphs: [
          "Three spins later the wheel finds your 84 rated striker. Keep him and the rating holds, sell him and 70 million funds two upgrades elsewhere. You keep him, finish 12 million in debt, and one forced sale later the XI still lands on 82. Job Done."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Reading the board's demands before you spin",
        items: [
          "Read the board's demands before the first spin. Three under 25s changes who the scouts' marquee should be, and so does the manager you hired."
        ]
      },
      {
        heading: "Selling early to fund the late upgrades",
        items: [
          "Sell early, spend late. Money banked from the first spins buys real answers when the wheel finds your weakest shirts."
        ]
      },
      {
        heading: "Treating the overdraft as a last resort, not a plan",
        items: [
          "The overdraft is a tool, not a plan. Two or three forced sales can undo a whole window's work."
        ]
      },
      {
        heading: "Avoiding costly wars and thin squad gaps",
        items: [
          "Walk away from wars over players you only half want. Overpaying twice sinks rebuilds.",
          "A 40 overall in one shirt costs you about four rating points across the XI. Promote from the bench first if anyone fits."
        ]
      }
    ],
    faqs: [
      {
        q: "What order does the wheel spin in?",
        a: "A seeded order fixed when you pick the club, hidden from you, every shirt once. There is no re-spinning to reach your striker early: the second spin power up only brings the wheel back to a shirt you already settled."
      },
      {
        q: "What is in the envelopes?",
        a: "The board's envelope carries its mood, a change to the pot and the demands. The finance envelope is one of twenty you pick blind: best case is a 60 million takeover, worst is a 35 million clause nobody read, and eight of them hold a power up instead of money. The deck order is seeded per run, so there is no re-rolling your luck."
      },
      {
        q: "What happens if I miss a board demand?",
        a: "Each miss draws one punishment card from the five card deck, and cards do not go back. Only one of the five is merciful, so a second miss is drawing from four cards that all hurt."
      },
      {
        q: "What do the grades mean?",
        a: "Target plus 3 or more is Legendary Rebuild, hitting it is Job Done, improving short of it is Some Progress. Level or worse, the game says so."
      },
      {
        q: "Are the managers real people?",
        a: "No. The three candidates are generated, with a name, a style and a fee, because this game will not put a rating on a real manager it cannot back with a record. Real names as hire options are on the list for a later round, once there is documented data behind them."
      },
      {
        q: "Who are the rival managers?",
        a: "Two computer personas who rebuild same tier clubs after your window closes, then face you in a simulated six team season, ten games each."
      },
      {
        q: "Can I play with friends?",
        a: "Yes, on one phone. Pick two to four seats before the first club, make each extra seat a friend or the CPU, and pass the phone between windows. The CPU seat plays the same thinking policy the game's own test harness measures, so it reads the board, prices the scouts' bands and walks away from wars it cannot win. Online play across two phones is not built yet."
      },
      {
        q: "Can I put the phone down in the middle of a window?",
        a: "Yes. Every move is saved to that phone as you make it, so a refresh, a locked screen or a closed tab comes back to the same window: the same club, the same money, the same settled shirts, the same demands, and at a table the same seats and whoever's turn it was. One run is kept at a time and it never leaves the phone, so starting again clears it and picking the game up on another device starts fresh."
      }
    ]
  },
  "/dart-draft": {
    intro: [
      "Dart Draft turns squad building into a test of nerve. Call a position, throw a timed dart at a real world map, and draft one of the stuck country's actual players for that slot.",
      "Eleven throws build your XI. Gold ocean zones pay legends and wonderkids, red zones bite, plain water means a hopeless trialist, then you face The Machine."
    ],
    headings: {
      howToPlay: "How to play Dart Draft, a free online football dart throwing game",
      rules: "Dart Draft rules: throws, accuracy points and the map zones",
      example: "Dart Draft walkthrough: a safe striker and a legend gamble",
      tips: "Dart Draft tips for picking countries and positions",
      faq: "Dart Draft FAQ: nations, positions and The Machine"
    },
    howToPlaySections: [
      {
        heading: "Picking Current Stars, World Cup or All Time mode",
        items: [
          "Pick a mode: Current Stars, World Cup 2026 where only qualified nations count, or All Time with legends."
        ]
      },
      {
        heading: "Choosing which formation slot to throw for",
        items: [
          "Choose which of the 11 slots in your 4-3-3 to throw for."
        ]
      },
      {
        heading: "Locking the sweeping line left to right and top to bottom",
        items: [
          "Lock the sweeping line twice, left to right then top to bottom. Tap or press space."
        ]
      },
      {
        heading: "Hitting a country and picking a player at your position",
        items: [
          "Hit a country and pick from up to 8 of its best players at your position."
        ]
      },
      {
        heading: "Filling all eleven and facing The Machine",
        items: [
          "Fill all eleven, then play The Machine over three legs."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Getting 11 throws with a faster sweeping crosshair",
        items: [
          "11 throws per game. The camera alternates between the world map and zoomed continent rounds, and the crosshair sweeps faster every throw."
        ]
      },
      {
        heading: "Scoring accuracy points by country size",
        items: [
          "Accuracy points: 12 to 55 for a country, smaller ones paying more, 40 for a gold zone, 0 for water and red zones."
        ],
        subsections: [
          {
            heading: "Landing on gold zones, red zones and open water",
            items: [
              "Gold zones offer legends, under 21 wonderkids, a free pick or a mystery gamble. Red zone sharks and storms punish greed."
            ]
          }
        ]
      },
      {
        heading: "Falling back on the trialist and your one retry",
        items: [
          "Ocean throws and wasted darts hand you a 40 rated trialist, unless you spend the one lifeboat re-throw per game."
        ]
      },
      {
        heading: "Scoring the series and the letter grade bands",
        items: [
          "Final score is accuracy plus XI rating plus 120 for a series win or 60 for a draw. Grades run S at 85 down to F below 54."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Opening on the striker slot with a safe country",
        paragraphs: [
          "First throw, striker slot, world map. You lock the vertical line late, stick France, and take a proven forward."
        ]
      },
      {
        heading: "Gambling on a legend ring and paying for it",
        paragraphs: [
          "Later you aim greedily at the tiny LEGEND ring over the Atlantic and it lands: an all time keeper joins. Your last dart splashes into open water, lifeboat already spent, and the trialist at left back suffers all series."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Weighing big countries against tiny ones",
        items: [
          "Big countries are safe darts, tiny ones pay more accuracy points."
        ]
      },
      {
        heading: "Checking the map first in World Cup mode",
        items: [
          "In World Cup mode check the map first. A dart in a non qualified nation is worth nothing."
        ]
      },
      {
        heading: "Avoiding costly out of position picks",
        items: [
          "Out of position picks lose 8 rating, so a misplaced superstar can be worse than a natural fit."
        ]
      }
    ],
    faqs: [
      {
        q: "What if my country has nobody at my position?",
        a: "Every nation still fields a squad: you get its academy prospect, rated 40 to 52 by squad depth, plus real players out of position."
      },
      {
        q: "Who is The Machine?",
        a: "An AI opponent that drafts its own XI from the same pool after your last throw, then plays you over three legs."
      }
    ]
  },
  "/career-ladder": {
    intro: [
      "Career Ladder shows a mystery footballer's career one stop at a time, earliest club first. Each rung lists the club, season, stats and that season's market value. Name the player before the ladder runs out.",
      "Early guesses are worth a fortune, late ones are worth crumbs, so every reveal is a small surrender. Play the shared daily or grind Unlimited with its two difficulty pools."
    ],
    headings: {
      howToPlay: "How to play Career Ladder, a free daily soccer career quiz",
      rules: "Career Ladder rules: guesses, scoring and the daily pool",
      example: "Career Ladder walkthrough: naming Cristiano Ronaldo early",
      tips: "Career Ladder tips for reading value and nationality clues",
      faq: "Career Ladder FAQ: reveal costs and the Legend difficulty"
    },
    howToPlaySections: [
      {
        heading: "Choosing Daily or Unlimited mode",
        items: [
          "Pick Daily for the one ladder everyone shares today, or Unlimited for endless rounds."
        ]
      },
      {
        heading: "Studying the first career stint",
        items: [
          "Study the first stint: a club, a season, appearances, goals and a value."
        ]
      },
      {
        heading: "Typing a name from the suggestion list",
        items: [
          "Type at least 2 letters and pick a name from the list. Only listed names submit, so typos never cost you."
        ]
      },
      {
        heading: "Letting wrong guesses reveal the next stop",
        items: [
          "Wrong guesses reveal the next career stop automatically. You can also reveal one on purpose, for a price."
        ]
      },
      {
        heading: "Naming the player before the guesses run out",
        items: [
          "Name the player before the guesses run out, and early enough to protect the score."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Getting six wrong guesses per ladder",
        items: [
          "You get 6 wrong guesses per ladder. The sixth miss ends the round."
        ]
      },
      {
        heading: "Scoring from 1000 with wrong guesses and reveals",
        items: [
          "Scoring starts at 1000. Wrong guesses cost 100 each, reveals cost points scaled to career length, and the floor is 100. Giving up scores 0."
        ],
        subsections: [
          {
            heading: "Revealing the whole career in one go",
            items: [
              "Revealing the whole career burns about 90 percent of the base score whether the ladder has 4 stops or 14."
            ]
          }
        ]
      },
      {
        heading: "Getting a nationality flag hint at the halfway point",
        items: [
          "A nationality flag hint appears once half the career is showing."
        ]
      },
      {
        heading: "Resetting the daily ladder and the Legend pool",
        items: [
          "The daily flips at midnight Eastern Time and leans toward the harder half of the pool two days in three. Unlimited adds a Legend pool of pure deep cuts."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Reading a promising first rung at Sporting CP",
        paragraphs: [
          "The first rung reads Sporting CP, a teenager scoring a handful of goals. Promising, but you buy one reveal. The next rung says Manchester United, and the ladder can only really be one man."
        ]
      },
      {
        heading: "Confirming the name with two stints showing",
        paragraphs: [
          "You type three letters, pick Cristiano Ronaldo, and the ladder unrolls to confirm it. Two stints showing, zero misses, nearly the full 1000 banked."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Reading the value column as a difficulty meter",
        items: [
          "The value column is a difficulty meter. A ladder peaking at 8 million is a journeyman story, not a superstar."
        ]
      },
      {
        heading: "Spotting nationality clues in the youth clubs",
        items: [
          "Youth clubs and first leagues leak the nationality long before the flag hint appears."
        ]
      },
      {
        heading: "Buying a cheap reveal over risky guesses",
        items: [
          "A cheap reveal often beats two expensive wrong guesses. Torn between three names? Buy the next rung."
        ]
      }
    ],
    faqs: [
      {
        q: "How does the reveal cost work?",
        a: "The button always shows the exact price of the next rung. Costs are bigger per rung on short careers, so a full reveal burns about the same anywhere."
      },
      {
        q: "What is the Legend difficulty in Unlimited?",
        a: "It draws only from the harder half of the pool by peak market value. Same rules, lower fame, much harder ladders."
      }
    ]
  },
  "/who-am-i": {
    intro: [
      "Somewhere in the player pool a secret footballer is hiding, and every guess tells you how warm you are. Name anyone, and the game scores the similarity between your guess and the secret man from 0 to 100.",
      "Nationality, position, club, age and market value all feed the score, and clue chips show exactly which parts of your guess matched. Follow the heat until 100 clicks."
    ],
    headings: {
      howToPlay: "How to play Who Am I?, a free online soccer guessing game",
      rules: "Who Am I? rules: scoring weights and the similarity chips",
      example: "Who Am I? walkthrough: closing in on a South American striker",
      tips: "Who Am I? tips for guesses, value arrows and teammates",
      faq: "Who Am I? FAQ: guess budgets, fame levels and the pool"
    },
    howToPlaySections: [
      {
        heading: "Picking a Casual or Expert guess budget",
        items: [
          "Pick a guess budget: Casual gives you 25 tries, Expert only 10."
        ]
      },
      {
        heading: "Setting the fame level for the secret player",
        items: [
          "Set the fame level: Easy draws from the most famous third, Hard from the least famous third, Normal from the whole pool."
        ]
      },
      {
        heading: "Opening with any big name from the database",
        items: [
          "Open with any big name. Type 2 or more letters and pick anyone from the database."
        ]
      },
      {
        heading: "Reading the color coded chips and arrows",
        items: [
          "Read the chips: green matches, yellow is close, arrows point older, younger, pricier or cheaper."
        ],
        subsections: [
          {
            heading: "Triangulating until the name clicks",
            items: [
              "Keep triangulating until you name him or run dry."
            ]
          }
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Drawing the secret from the top 400 players",
        items: [
          "The secret is always one of the top 400 current players by market value. Guesses can be anyone among over 27,000 names."
        ]
      },
      {
        heading: "Weighting nationality, position, club, age and value",
        items: [
          "Weights: nationality 22, position group 18 plus 10 for the exact position, same club 25, shared former club 10, up to 15 for age closeness, up to 20 for value closeness."
        ]
      },
      {
        heading: "Zeroing out those closeness points at the far edge",
        items: [
          "Age points hit zero at 12 years apart, value points hit zero once the values are 10 times apart."
        ],
        subsections: [
          {
            heading: "Reserving the perfect 100 for the right answer",
            items: [
              "Only the right player scores 100. Everyone else caps at 99."
            ]
          }
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Opening with Haaland for a warm 38",
        paragraphs: [
          "You open with Haaland and get a 38: position chip green, nation gray, both arrows pointing down. So the secret is a forward, but cheaper, younger and from somewhere else."
        ]
      },
      {
        heading: "Zeroing in through a shared club link",
        paragraphs: [
          "A young South American striker scores 74 with a past club link. Two forwards later the board flashes 100, with 19 guesses to spare on Casual."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Spending early guesses on famous, varied names",
        items: [
          "Spend the first three guesses on famous names from different continents and positions. Cheap information beats hero shots."
        ]
      },
      {
        heading: "Following the value arrow as your compass",
        items: [
          "The value arrow is the strongest compass. A 10x gap zeroes those points, so move up or down the market fast."
        ]
      },
      {
        heading: "Checking teammates after a high scoring guess",
        items: [
          "Same club pays 25. When a guess lands high, run through the teammates first."
        ]
      }
    ],
    faqs: [
      {
        q: "What does a score in the 80s tell me?",
        a: "Usually nationality, position group and club all matched, or two of those plus close age and value. The chip still gray is your answer."
      },
      {
        q: "Does the difficulty setting change my guesses?",
        a: "No. Easy, Normal and Hard only decide how famous the secret is. The 25 or 10 guess budget comes from Casual or Expert."
      }
    ]
  },
  "/world-xi": {
    intro: [
      "World XI deals you eleven random nations, one per slot of your formation, and asks the same question eleven times: can you name a real player from this country who plays this position?",
      "Brazil in goal is a gift. A wing back from a country you have never watched is the whole game. A slot machine reel spins each nation in, so the next headache is always a surprise."
    ],
    headings: {
      howToPlay: "How to play World XI, a free online soccer nation guessing game",
      rules: "World XI rules: respins, position families and the timer",
      example: "World XI walkthrough: easy slots and one tough respin",
      tips: "World XI tips for time, respins and reading suggestions",
      faq: "World XI FAQ: chemistry bonuses and the season simulation"
    },
    howToPlaySections: [
      {
        heading: "Picking a formation, a timer and a respin budget",
        items: [
          "Pick one of 9 formations, a timer (none, 90 seconds or 60 seconds for the whole XI), and your respin budget."
        ]
      },
      {
        heading: "Drawing your nations in random slot order",
        items: [
          "Hit draw and the reel reveals your nations in random slot order."
        ]
      },
      {
        heading: "Typing a player who covers the nation and slot",
        items: [
          "Type 2 or more letters and pick a player of that nationality who covers the slot."
        ],
        subsections: [
          {
            heading: "Bouncing off wrong position picks",
            items: [
              "Wrong position picks bounce off harmlessly with an explanation. Confirmed picks lock for good."
            ]
          }
        ]
      },
      {
        heading: "Filling all eleven and simulating a season",
        items: [
          "Fill all 11 to win, then check squad value and chemistry, and simulate a season if you are curious. The report has a month by month tab, a player stats tab and a share card with your finish, top scorer and player of the season."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Drafting only nations with real squad depth",
        items: [
          "Every slot gets a different nation, and only countries with depth make the draw: at least 2 goalkeepers, 2 centre backs, 3 defenders, 3 midfielders and 2 strikers in the database."
        ]
      },
      {
        heading: "Spending a shared respin budget on tough nations",
        items: [
          "Respins reroll a nation you cannot solve, shared across all slots. You choose your budget before the draw: none, 3, 5 or 10, with 3 as the default."
        ]
      },
      {
        heading: "Matching position families and beating the clock",
        items: [
          "Position families count: wingers cover both flanks, central midfielders cover holding and attacking slots, strikers and centre forwards swap freely, full backs cover wing back slots. Front line winger slots take wingers and wide midfielders only, never wing backs.",
          "The timer covers the whole run, and zero on the clock ends it. The season sim rates your XI out of 100 across a 38 game, 20 team league.",
          "The season report runs month by month with a standout each month, gives every player his appearances, goals, assists, average rating and, for the keeper and back line, the clean sheets in the games he played (goals and assists add up to the team totals), hands out player, young player and goal of the season, and names the one shape or respin the sim says would have moved the finish most, as arithmetic on the same rolls and never a promise. Nobody real is quoted in it."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Filling the easy goalkeeper and striker slots",
        paragraphs: [
          "A 4-3-3 on the 90 second clock. Brazil lands on the goalkeeper slot and Alisson is typed before the reel settles. France at striker is just as friendly."
        ]
      },
      {
        heading: "Spending a respin to save the centre back slot",
        paragraphs: [
          "Then a nation you barely know lands at centre back. You spend a respin, draw a football heavyweight instead, and squeeze the last name in with four seconds left. The sim rates the squad 78 and hands you a cup."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Banking time on the easy slots first",
        items: [
          "Bank time on the easy slots. In timed modes the clock is the real opponent."
        ]
      },
      {
        heading: "Spending respins on the thinnest nations",
        items: [
          "Spend respins on goalkeepers and centre backs, where thin footballing nations truly have nobody famous."
        ]
      },
      {
        heading: "Reading an empty suggestion list correctly",
        items: [
          "Suggestions only show players from the drawn country, so an empty list means wrong spelling or wrong idea."
        ]
      }
    ],
    faqs: [
      {
        q: "What is the chemistry bonus?",
        a: "Extra points for pairs of picked players who share a club or a league. Bragging rights on top of the finish, not a requirement."
      },
      {
        q: "Is the season simulation random?",
        a: "No. It is seeded by your exact eleven, so the same squad always produces the same rating, finish and storylines. Swap one player and everything reshuffles."
      }
    ]
  },
  "/player-bingo": {
    intro: [
      "Player Bingo hands you a 5 by 5 board of hard football categories, then reveals real players one at a time, name only. No club, no flag, no position. Tap a tile the player fits to lock it, and complete any line of five for bingo.",
      "The tension is in the taps. A wrong one costs a strike and three strikes end the game, so knowing a player won the Champions League beats vaguely feeling it."
    ],
    headings: {
      howToPlay: "How to play Player Bingo, a free online soccer bingo game",
      rules: "Player Bingo rules: strikes, lines and the blackout bonus",
      example: "Player Bingo walkthrough: a defender tile and a risky gamble",
      tips: "Player Bingo tips for lines, skips and banking early",
      faq: "Player Bingo FAQ: fitting tiles and the category types"
    },
    howToPlaySections: [
      {
        heading: "Scanning the 24 category tiles and the free square",
        items: [
          "Scan the board: 24 category tiles around a free centre square."
        ]
      },
      {
        heading: "Deciding whether a revealed player truly fits",
        items: [
          "A name appears. Decide whether he truly fits a tile you actually need."
        ]
      },
      {
        heading: "Tapping a tile to lock it, or skipping free",
        items: [
          "Tap a tile to lock it with his name, or skip. Skips are free and unlimited."
        ]
      },
      {
        heading: "Completing a line and banking the win",
        items: [
          "Complete a row, column or diagonal for bingo, then bank the win or keep the board alive."
        ],
        subsections: [
          {
            heading: "Pushing on for extra lines and the blackout",
            items: [
              "Push on for 100 points per line, a bonus strike, and the full board blackout."
            ]
          }
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Ending a run after three wrong taps",
        items: [
          "3 strikes end a standard run, and only wrong taps cost strikes."
        ]
      },
      {
        heading: "Counting all twelve possible lines",
        items: [
          "12 lines are possible: 5 rows, 5 columns and 2 diagonals. The free centre gives four of them a head start."
        ]
      },
      {
        heading: "Banking the first line or chasing a blackout",
        items: [
          "Your first line banks the win on the spot. Continuing grants a 4th strike and pays 100 points per completed line.",
          "Filling all 24 tiles is a blackout: a 500 point bonus and an instant win."
        ]
      },
      {
        heading: "Keeping a banked win safe from later busts",
        items: [
          "The deck of players is finite, and busting on strikes after a bingo never takes the banked win away."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Choosing the tile that completes a row",
        paragraphs: [
          "A veteran defender's name comes up. He fits your Champions League Winner tile and a defender tile, but only the defender tile sits on a row with three locks already, so that is the tap. Two players later, bingo."
        ]
      },
      {
        heading: "Gambling on a second line after a bingo",
        paragraphs: [
          "You gamble on continuing. A rash tap on Played With Messi burns strike three, but the bonus strike keeps you breathing, and a second line takes you out at 200 points with the win safe."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Playing for lines, not for single tiles",
        items: [
          "Play lines, not tiles. A correct tap that helps no line is a wasted player."
        ]
      },
      {
        heading: "Skipping freely when a fit feels unsure",
        items: [
          "When less than sure, skip. The deck is long, the strikes are not."
        ]
      },
      {
        heading: "Building the centre row, column and both diagonals",
        items: [
          "The centre row, centre column and both diagonals need only four real tiles each. Build there first."
        ]
      },
      {
        heading: "Banking early when two strikes are showing",
        items: [
          "Bank the first bingo if you are already carrying two strikes."
        ]
      }
    ],
    faqs: [
      {
        q: "Is every revealed player guaranteed to fit my board?",
        a: "No. Plenty of names fit nothing you have open, which is why skips are free and confident wrong taps are the real killer."
      },
      {
        q: "What kinds of categories appear?",
        a: "Clubs a player has appeared for, nationalities, positions, value bands, age brackets, World Cup and Champions League winners, and quirks like sharing a pitch with Messi."
      }
    ]
  },
  "/alphabet-sprint": {
    intro: [
      "A letter drops, you name a footballer whose surname starts with it, and the clock does not care about your feelings. Alphabet Sprint is pure recall at speed: no suggestions, no autocomplete, no safety net.",
      "Every correct name is a point, streaks pay bonuses, and each player can only be used once per run. It is the rare trivia game where typing speed is a real skill."
    ],
    headings: {
      howToPlay: "How to play Alphabet Sprint, a free online soccer naming game",
      rules: "Alphabet Sprint rules: scoring, letters and the streak bonus",
      example: "Alphabet Sprint walkthrough: a fast Classic mode streak",
      tips: "Alphabet Sprint tips for speed, letters and skipping",
      faq: "Alphabet Sprint FAQ: rejected answers and impossible letters"
    },
    howToPlaySections: [
      {
        heading: "Picking a Relaxed, Classic or Insane pace",
        items: [
          "Pick a pace: Relaxed is 75 seconds, Classic is 45, Insane is 20."
        ]
      },
      {
        heading: "Typing a surname for the letter shown",
        items: [
          "A big letter appears. Type a player whose surname starts with it and press Enter."
        ],
        subsections: [
          {
            heading: "Adding a first name when a surname is shared",
            items: [
              "A bare surname works when it can only mean one player. If several share it, the game asks for the full name without saying who they are."
            ]
          }
        ]
      },
      {
        heading: "Skipping a letter for free at a cost",
        items: [
          "Skip any letter for free, but the skip resets your streak."
        ]
      },
      {
        heading: "Racking up names until the clock dies",
        items: [
          "Rack up names until the clock dies, then chase your saved best."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Scoring points and the every fifth streak bonus",
        items: [
          "Scoring is 1 point per correct player, and every 5th correct answer in a row pays 2."
        ]
      },
      {
        heading: "Reading the letter from a player's surname",
        items: [
          "Surnames decide the letter: Kylian Mbappe answers M, not K, and suffixes are skipped, so Vinicius Junior counts under V."
        ]
      },
      {
        heading: "Weighting letters and grading Gold, Silver, Bronze",
        items: [
          "Letters are weighted by how many unused players they hold, never repeat back to back, and any letter with fewer than 5 pool players never appears.",
          "The pool is every named player in this season's market table, about 5,500 of them, so if he is playing somewhere real right now he counts. Cover every playable letter for Gold, 75 percent for Silver, 50 percent for Bronze."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Chaining a fast start on Classic mode",
        paragraphs: [
          "Classic mode, 45 seconds. M drops and Mbappe is in before the letter finishes animating. S brings Saka, B brings Bellingham, and the streak builds."
        ]
      },
      {
        heading: "Skipping a blank and still earning a badge",
        paragraphs: [
          "Your fifth straight answer pays double. Then K lands, your mind goes blank, and you skip, swallowing the streak reset. Eleven names later it is 13 points and a Silver badge."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Typing surnames only to save seconds",
        items: [
          "Type surnames only. Haaland beats Erling Haaland by half a second, and seconds are the currency."
        ]
      },
      {
        heading: "Keeping fallback names ready for deep letters",
        items: [
          "Keep go-to names ready for the deep letters, because the wheel favors letters with lots of players left."
        ]
      },
      {
        heading: "Resolving the ambiguity message quickly",
        items: [
          "If the ambiguity message appears, add a first name to the most famous option and resubmit. Do not freeze."
        ]
      },
      {
        heading: "Skipping instead of freezing on a blank",
        items: [
          "Skipping is not failing. Four blank seconds cost more than any streak bonus returns."
        ]
      }
    ],
    faqs: [
      {
        q: "Why was my answer rejected?",
        a: "Usually the surname does not start with the shown letter, the player was already used this run, or he is not in this season's market table (about 5,500 current players; retired players and youth prospects without a value are not in it). Accents and hyphens are forgiven."
      },
      {
        q: "Do impossible letters like Q or X come up?",
        a: "No. Letters with fewer than 5 pool players are removed from the wheel before the run starts, so you are never stuck on an unanswerable letter."
      }
    ]
  },
  "/clue-auction": {
    intro: [
      "Clue Auction is a detective game with a budget. A secret footballer is drawn, you hold a bank of 100 points, and every scrap of information has a price. Whatever you have not spent when you name him is your score.",
      "Buy nothing and guess cold for the perfect 100, or shop your way to certainty and keep the change. Wrong guesses burn points too, so bravado is not free either."
    ],
    headings: {
      howToPlay: "How to play Clue Auction, a free online soccer guessing game",
      rules: "Clue Auction rules: the bank, clue prices and the secret pool",
      example: "Clue Auction walkthrough: cheap clues and a club initial",
      tips: "Clue Auction tips for buying clues and timing your guess",
      faq: "Clue Auction FAQ: unavailable clues and the secret player pool"
    },
    howToPlaySections: [
      {
        heading: "Browsing the eight priced clues in the shop",
        items: [
          "Browse the clue shop: eight clues, each priced, each selling once."
        ]
      },
      {
        heading: "Buying the clues your scouting values most",
        items: [
          "Buy what your inner scout values, maybe the age bracket for 10 or the current club for 35."
        ]
      },
      {
        heading: "Guessing the secret player at any time",
        items: [
          "Guess whenever you like: type 2 or more letters and pick a name from the list."
        ],
        subsections: [
          {
            heading: "Losing points on a miss, banking on a hit",
            items: [
              "Miss and you lose 10 points but keep digging. Hit and you bank everything left."
            ]
          }
        ]
      },
      {
        heading: "Watching the case close at zero points",
        items: [
          "If the bank reaches zero, the case closes and the secret man walks."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Starting the bank at 100 points",
        items: [
          "The bank starts at 100 and doubles as your final score. Wrong guesses cost 10 each."
        ]
      },
      {
        heading: "Setting a price on all eight clues",
        items: [
          "Clue prices: nationality 25, current club 35, one former club 30, club initial 20, position 15, age bracket 10, value band 10, career club count 10.",
          "The menu totals 155 against your 100, so buying everything is impossible, and a clue can only be bought while you hold more than its price."
        ]
      },
      {
        heading: "Drawing the secret from the top 400 players",
        items: [
          "The secret is one of the top 400 current players by value. Clues with no real data, like a former club for a one club man, show as unavailable rather than invented."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Buying the two cheapest clues first",
        paragraphs: [
          "You open with the two cheapest clues. Age bracket says 21 to 24, value band says 80 to 120 million dollars. That is a short list of wonderkids, and you still hold 80."
        ]
      },
      {
        heading: "Settling the case with the club initial",
        paragraphs: [
          "A confident stab misses, down to 70. The club initial for 20 settles the argument, and you name him with 50 banked. Middling, but far better than bankruptcy."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Buying the cheap clues for the best value",
        items: [
          "The 10 point clues are the value buys. Age plus value band shrinks the pool enormously for the price of two misses."
        ]
      },
      {
        heading: "Saving the current club clue for last",
        items: [
          "Save the 35 point current club for last. The cheap clues often make it unnecessary."
        ]
      },
      {
        heading: "Guessing once the field is down to two",
        items: [
          "Down to two candidates? A guess costs the same 10 as a cheap clue and settles it instantly."
        ]
      }
    ],
    faqs: [
      {
        q: "Why is a clue locked as not available?",
        a: "There is no real data behind it, most often a former club for a player who has only ever had one club. The game never invents information."
      },
      {
        q: "Who can the secret player be?",
        a: "One of the top 400 current players by market value, the same pool the Who Am I game uses. New cases never repeat the previous secret, and your best win saves on this device."
      }
    ]
  },
  "/rarity-round": {
    intro: [
      "Rarity Round flips trivia upside down. Anyone can name a Ballon d'Or winner. The question is whether you can name one nobody else would think of, because here the obvious answer scores worst.",
      "Five categories per run, every answer checked against real soccer data, plus a mirror mode called Crowd Says where fame wins instead. Same prompts, opposite instincts."
    ],
    headings: {
      howToPlay: "How to play Rarity Round, a free daily soccer trivia game",
      rules: "Rarity Round rules: fame ranks, Goalless runs and the daily set",
      example: "Rarity Round walkthrough: a forgotten Ballon d'Or winner",
      tips: "Rarity Round tips for obscurity and the Crowd Says mode",
      faq: "Rarity Round FAQ: valid answers and the daily ranking"
    },
    howToPlaySections: [
      {
        heading: "Choosing Daily or Unlimited categories",
        items: [
          "Choose Daily for the 5 categories everyone shares today, or Unlimited for a random 5."
        ]
      },
      {
        heading: "Picking Rarity Round or Crowd Says scoring",
        items: [
          "Pick a scoring mode: Rarity Round rewards obscurity, Crowd Says rewards fame."
        ]
      },
      {
        heading: "Typing a valid answer for each prompt",
        items: [
          "Read the prompt, type 2 or more letters and pick a valid answer. Names that do not fit the category cannot be submitted at all."
        ],
        subsections: [
          {
            heading: "Locking in to see the fame rank",
            items: [
              "Lock it in to see your pick's fame rank, the best possible answer, and what everyone else said."
            ]
          }
        ]
      },
      {
        heading: "Finishing five rounds and checking your rank",
        items: [
          "Finish all 5 rounds for your total, then check your rank among today's players."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Scoring every answer by its fame rank",
        items: [
          "Each answer scores 0 to 100 by fame rank in the category's full pool: the most famous valid answer scores 100, the most obscure 0."
        ]
      },
      {
        heading: "Chasing a Goalless run or the 500 ceiling",
        items: [
          "In Rarity mode points are bad and 0 across 5 rounds is the perfect Goalless run. In Crowd Says points are good and 500 is the ceiling."
        ]
      },
      {
        heading: "Resetting the daily categories at midnight",
        items: [
          "The daily set changes every day at midnight Eastern Time, drawn from 36 categories covering clubs, nationalities, positions, price tags and Ballon d'Or winners.",
          "Only valid answers can be locked in, so the risk is never being wrong, only being obvious."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Digging up a forgotten Ballon d'Or winner",
        paragraphs: [
          "The prompt asks for a Ballon d'Or winner. Messi is what the planet says, near maximum points, a disaster in Rarity mode. You dig up a forgotten winner instead, someone like Igor Belanov from 1986, and score close to zero. Beautiful."
        ]
      },
      {
        heading: "Naming a rotation defender over the galacticos",
        paragraphs: [
          "Next: name a player who has played for Real Madrid. You skip the galacticos for a rotation defender from a decade ago, and your five round total of 74 lands top ten today."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Thinking in decades for near zero answers",
        items: [
          "Think in decades. Long retired and briefly relevant names are where the near zero answers live."
        ]
      },
      {
        heading: "Trusting the first name in Crowd Says",
        items: [
          "In Crowd Says, do not overthink. The first name a casual fan would blurt out is usually the right play."
        ]
      },
      {
        heading: "Reading every reveal to sharpen the next run",
        items: [
          "Read every reveal. Seeing the rarest answer and the crowd's picks is how your next run gets sharper."
        ]
      }
    ],
    faqs: [
      {
        q: "What is a Goalless run?",
        a: "The Rarity mode perfect game: five valid answers so obscure they each scored 0. Rare enough that the result screen treats it like a trophy."
      },
      {
        q: "How does the daily ranking work?",
        a: "When you finish, your total is compared against everyone who completed today's run, and you get a live standing, like number 4 of 31 players today."
      }
    ]
  },
  "/missing-xi": {
    intro: [
      "One famous real lineup, ten names showing, one tile blank. Missing XI asks the simplest question in football trivia: who is missing? Champions League finals, World Cup finals, Euros deciders and iconic title run-ins all take a turn.",
      "You get three guesses and a ladder of hints that never repeat what the card already shows. Nail it first time for the full 100."
    ],
    headings: {
      howToPlay: "How to play Missing XI, a free daily soccer lineup quiz",
      rules: "Missing XI rules: scoring, hints and the daily puzzle",
      example: "Missing XI walkthrough: naming Mascherano at centre back",
      tips: "Missing XI tips for reading lineups and formations",
      faq: "Missing XI FAQ: real lineups and the daily reset"
    },
    howToPlaySections: [
      {
        heading: "Reading the match card details",
        items: [
          "Read the match card: competition, score line, venue, formation and whose XI you are looking at."
        ]
      },
      {
        heading: "Studying the pitch for the blank tile",
        items: [
          "Study the pitch. Ten tiles carry names, one shows only a position and a question mark."
        ]
      },
      {
        heading: "Searching the database for your guess",
        items: [
          "Search the player database and lock in your guess for the missing man."
        ],
        subsections: [
          {
            heading: "Unlocking a new hint after each miss",
            items: [
              "Each miss unlocks a new hint before the next try. Three misses reveals the answer."
            ]
          }
        ]
      },
      {
        heading: "Playing the daily lineup or the archive",
        items: [
          "Play the shared daily lineup, then raid the archive in Unlimited."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Scoring three guesses on a falling scale",
        items: [
          "3 guesses per puzzle: 100 points on the first, 70 on the second, 40 on the third, 0 for a miss or a give up."
        ]
      },
      {
        heading: "Unlocking hints that never repeat the card",
        items: [
          "Hints add new information only: a club lineup hints the missing player's nationality, a national team lineup hints his club at the time, then comes the first letter of his surname."
        ]
      },
      {
        heading: "Sharing the daily puzzle and the Unlimited archive",
        items: [
          "The daily puzzle is the same lineup and same blanked player for everyone, changing at midnight Eastern Time.",
          "Unlimited draws from an archive of over 200 hand checked real lineups, with the blanked position varying between runs. Repeating a name you already tried never burns a guess."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Reading a 2011 Champions League final card",
        paragraphs: [
          "The card reads 2011 Champions League Final, Barcelona 3-1 Manchester United, Wembley. The blank sits at centre back beside Pique. Puyol is the reflex answer, but he started that night on the bench."
        ]
      },
      {
        heading: "Naming Mascherano over the reflex answer",
        paragraphs: [
          "The actual partner was Javier Mascherano, a midfielder moonlighting at centre back in a European final. Land it first try for the full 100 and a fact to correct people with forever."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Reciting the famous XI before searching",
        items: [
          "Recite the famous XI before searching. The blank is usually the name memory skips, a full back or the holding midfielder, not the star."
        ]
      },
      {
        heading: "Reading the formation label for a clue",
        items: [
          "Use the formation label. A 4-2-3-1 tells you exactly what job the blank tile is doing."
        ]
      },
      {
        heading: "Waiting for the hint before guess two",
        items: [
          "Never rush guess two. Wait for the hint, cross reference the era, then commit."
        ]
      }
    ],
    faqs: [
      {
        q: "Are the lineups actually real?",
        a: "Yes. Every XI is a hand checked starting lineup from a real match, surprise selections included, which is what makes some blanks so cruel."
      },
      {
        q: "Is my daily puzzle the same as everyone's?",
        a: "Same lineup, same hidden player, worldwide, until the next puzzle arrives at midnight Eastern Time."
      }
    ]
  },
  "/sports-bingo": {
    intro: [
      "Sports Bingo hands you a 5 by 5 card of football conditions, a goalkeeper, a Brazilian, someone worth 100M plus, and opens ten packs of real players on a timer. Your job is spotting which squares each pack can claim before it closes.",
      "The marking is the whole skill. Nothing is claimed for you: a pack sits open for fifteen seconds, you scan five real players and their real attributes, and every square you can justify, you tap. When the next pack opens, the old one is gone for good.",
      "Play the shared daily card, run unlimited fresh cards, race a CPU on the same card with the same packs and its own board, or pass one phone round a table of two to four, each with your own card, all hearing the same packs, with your own pick of what the squares can be."
    ],
    headings: {
      howToPlay: "How to play Sports Bingo, a free daily football pack opening game",
      rules: "Sports Bingo rules: conditions, scoring and the versus mode",
      example: "Sports Bingo walkthrough: one player claiming five squares",
      tips: "Sports Bingo tips for scanning packs and timing closes",
      faq: "Sports Bingo FAQ: the daily card and completable packs"
    },
    howToPlaySections: [
      {
        heading: "Picking daily, unlimited, versus CPU or pass the device",
        items: [
          "Pick a mode: the daily card (one shared card and pack run per day), unlimited, versus the CPU at one of three levels, or pass the device for two to four of you on one phone."
        ]
      },
      {
        heading: "Setting up a shared phone table",
        items: [
          "Choose two to four seats and name them. Any seat can be a CPU instead, at casual, sharp or ruthless. Then pick which families the squares may come from (positions, ages, values, goals and assists, nationalities, leagues), a difficulty (relaxed, standard or quick, which is how long a pack stays open), and what wins: first line or full card."
        ],
        subsections: [
          {
            heading: "Taking turns and passing the phone",
            items: [
              "Everyone gets their own card and the same ten packs. On every pack each seat takes a turn in order: the hand over screen shows only whose turn is next, you tap ready, turn the pack up one player at a time, claim every square a player turned up satisfies before the clock runs out, then pass the phone. CPU seats take their turn on their own."
            ]
          }
        ]
      },
      {
        heading: "Opening ten timed packs of five players",
        items: [
          "Ten packs of five real players open one at a time, each on a fifteen second timer. You can close a pack early once you have milked it."
        ],
        subsections: [
          {
            heading: "Tapping every square a pack satisfies",
            items: [
              "While a pack is open, tap every square that someone in the pack satisfies. A wrong tap shakes and costs nothing but time."
            ]
          }
        ]
      },
      {
        heading: "Scoring squares, lines and the blackout",
        items: [
          "After the tenth pack the card is scored: squares, lines and the blackout bonus."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Reading the 24 conditions and free centre",
        items: [
          "The card holds 24 conditions plus a free centre. Conditions cover position, age, market value, nationality, league, and season output, all read from the same verified player data the rest of the site runs on."
        ]
      },
      {
        heading: "Claiming a square only while its pack is open",
        items: [
          "A square can only be claimed while a pack containing a matching player is open. Closed packs never come back."
        ]
      },
      {
        heading: "Awarding points and facing off against the CPU",
        items: [
          "Scoring: 3 points per marked square, 2 per completed row, column or diagonal, and a blackout lands exactly 100.",
          "Versus mode: the CPU plays the identical card and packs on its own board, and most squares after pack ten wins."
        ]
      },
      {
        heading: "Guaranteeing every card is completable",
        items: [
          "Every card is completable: the pack run is checked at deal time so each condition on the card has at least one matching player somewhere in the ten packs. At a table that holds for every seat's card against the shared packs."
        ]
      },
      {
        heading: "Winning with friends on one phone, and the tie rule",
        items: [
          "First line means a full row, column or diagonal, the free centre counting. Full card means most squares after pack ten, and a blackout ends it early. The game ends after the round in which somebody met the goal, so every seat has heard the same packs.",
          "Level on the goal, the seat that got there having turned up fewer players wins. Still level, more squares wins. Still level, the win is shared. If nobody met the goal in ten packs, most squares wins, shared when level."
        ]
      },
      {
        heading: "Custom cards and what happens when a pick is too thin",
        items: [
          "The bank holds 33 conditions in six families. Only a pick worth 24 or more can fill a card by itself, so you can drop nationalities, or leagues, or positions, or one or two of ages, values and goals and assists. A thinner pick fills what it can and tops every card up from the families you dropped, and both the setup screen and the turn screen say exactly how many squares that is. A card is never dealt short."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Claiming five squares from one loaded player",
        paragraphs: [
          "Pack three opens: a 21 year old Brazilian winger worth 45M with 11 goals. That one player claims Age 21 or younger, A Brazilian, A winger, Worth 40M plus and 10 plus goals, if all five sit on your card and you spot them in time."
        ]
      },
      {
        heading: "Missing one square and losing to the CPU",
        paragraphs: [
          "You tap four of them before the clock runs out, miss the goals square, and the pack closes. Seven packs later you finish on 19 squares and 4 lines: 65 points, and the ruthless CPU beat you by two squares."
        ]
      },
      {
        heading: "Two seats, first line, and the fewer players rule",
        paragraphs: [
          "Sam and Ana set up a two seat table, first line, standard pace, with nationalities dropped: the five remaining families offer 25 conditions, so both cards fill without a top up. Pack four opens for Sam. She turns up three players and the third, a 31 year old Premier League centre back worth 25M, completes her top row through Age 30 or older. That is 18 players turned up in all, three full packs and three of this one, so her card is marked as done at 18.",
          "Ana takes her turn on the same pack, turns up all five and completes a diagonal off the fifth: 20 players. The round is over and both have a line, so the game ends. Sam got there having turned up fewer players, so Sam wins. Had both needed all five, more squares would have decided it, and level on that too it would be shared."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Reading the card before the first pack",
        items: [
          "Read the card before the first pack opens. Knowing your rare squares (a goalkeeper, worth 100M plus) means you never let one slip by."
        ]
      },
      {
        heading: "Scanning every attribute line, not just the name",
        items: [
          "One great player can claim four or five squares. Scan every attribute line, not just the name."
        ]
      },
      {
        heading: "Waiting to close packs with squares still open",
        items: [
          "Do not close packs early while broad squares are still open. The timer is generous exactly so the scan is doable."
        ]
      },
      {
        heading: "Claiming as you turn players up at a table",
        items: [
          "At a table, claim as you go rather than turning the whole pack up first: a line completed on the third player beats one completed on the fifth."
        ]
      }
    ],
    faqs: [
      {
        q: "Is the daily card the same for everyone?",
        a: "Yes. One card and one pack sequence per Eastern Time date, shared worldwide, so daily scores compare fairly."
      },
      {
        q: "Can we play on one phone?",
        a: "Yes. Pass the device seats two to four people on one phone, with CPU tempers filling any seat you like. Everyone gets their own card and hears the same ten packs, turns run seat by seat on every pack, and the hand over screen shows only whose turn is next. A game you leave mid way is offered again when you come back."
      },
      {
        q: "Can we choose what the squares are about?",
        a: "Yes, at a pass the device table. Keep or drop any of the six families. A pick that cannot fill 24 squares is topped up from the dropped families and the screen says how many squares that is."
      },
      {
        q: "Are the players real?",
        a: "Every player in every pack is a real footballer from the same verified market data the rest of the site uses, and every condition reads their real attributes."
      },
      {
        q: "Can the card be impossible?",
        a: "No. At deal time the ten packs are checked against the card, and any condition nothing satisfies gets a matching player dealt in."
      }
    ]
  }
};

// src/data/gameContent/soccer2.ts
var SOCCER_CONTENT_2 = {
  "/manager-hot-seat": {
    intro: [
      "Manager Hot Seat is the short, sharp version of Club Manager. You walk into a real club on a bad run, the board give you five league games and a points target, and you either hit it or you are sacked.",
      "It runs on the Club Manager engine, so every match, every meter and every press question is the same one the full game plays. Before each match you pick a shape and a team talk, and after it the board, the fans and the dressing room all react.",
      "There is a daily, the same club and the same target for everyone, and a free play mode where you can take any club you like."
    ],
    headings: {
      howToPlay: "How to play Manager Hot Seat, the free five game sack race",
      rules: "Manager Hot Seat rules: the target, the board and the fans",
      example: "A Manager Hot Seat walkthrough, five games to save the job",
      tips: "Manager Hot Seat tips for keeping your job",
      faq: "Manager Hot Seat FAQ: the engine, the daily and the leaderboard"
    },
    howToPlaySections: [
      {
        heading: "Pick the daily club or your own",
        items: [
          "Pick today's hot seat for the shared daily club, or open free play and choose any club, or let the game pick one at random."
        ]
      },
      {
        heading: "The takeover briefing",
        items: [
          "The engine plays the season up to the day the job opens, then shows you the table place, the recent form and the board's target."
        ]
      },
      {
        heading: "Before every match",
        items: [
          "Tap Take the job and the first match comes up with a read on the game from the dugout."
        ],
        subsections: [
          {
            heading: "Picking a shape",
            items: ["Pick a shape: defensive, balanced or attacking."]
          },
          {
            heading: "Picking a team talk",
            items: ["Pick a team talk: calm them, fire them up, demand more, the hairdryer, or say nothing at all."]
          }
        ]
      },
      {
        heading: "After the final whistle",
        items: [
          "Kick off. The result comes back with what it did to the board, the fans and the dressing room.",
          "When the press have a question, answer it before the next match.",
          "Keep going until you hit the target, run out of league games, or the board run out of patience."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "How the job opens",
        items: [
          "The job opens after the worst run of form the simulated season produced between league weeks 6 and 14.",
          "The board start on 30 out of 100, whatever they thought of the last manager."
        ]
      },
      {
        heading: "The points target",
        items: [
          "The target is a number of points from your next 5 league games.",
          "It is read off those five fixtures: more is asked at home and against weaker sides, less away and against stronger ones.",
          "Cup and European ties still get played and still move the meters, but only league points count toward the target."
        ]
      },
      {
        heading: "Board, fans and dressing room",
        items: [
          "The dressing room meter is the average morale of the eleven the engine picks, and morale feeds straight into how well they play."
        ],
        subsections: [
          {
            heading: "Keeping or losing the job",
            items: [
              "Hit the target and you keep the job straight away, even with games to spare.",
              "Finish one point short with the fan meter at 65 or above and the fans save you.",
              "If the board meter hits zero at any final whistle, you are sacked on the spot.",
              "If even winning every league game left could not get you within a point of the target, the board do not wait for the last game."
            ]
          }
        ]
      },
      {
        heading: "The daily and the leaderboard",
        items: [
          "The daily is the same club, the same takeover week and the same target for everyone, and every match on the day draws from the same seeded stream, so the difference between two players is the calls they made.",
          "Manager Hot Seat records that you played but puts no points on the leaderboard for now, while the points system is being rebuilt."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Walking into a slump",
        paragraphs: [
          "Say today's club is a mid table side that has taken two points from its last five. The job opens 15th after 11 games, the board expect 9th, and the target is 7 points from 5 league games."
        ]
      },
      {
        heading: "The first two league games",
        paragraphs: [
          "Game one is at home to a weaker side. The read says the dressing room is flat, so you go balanced and say nothing. A 2 to 0 win puts 3 on the board and lifts the fans.",
          "Game two is away at a stronger side. You sit deep with a defensive shape and take a 1 to 1 draw. That is 4. The press ask about the board and you back yourself."
        ]
      },
      {
        heading: "A cup tie in the middle",
        paragraphs: [
          "A cup tie comes next. It does not count, but a bad defeat still costs board confidence, so you play it properly and go out on penalties."
        ]
      },
      {
        heading: "Hitting the target early",
        paragraphs: [
          "Game three is at home and you need 3 points from 3 games. Balanced with a fire them up talk, and a 2 to 1 win makes it 7. Target hit, job kept, two league games to spare."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Reading the room",
        items: [
          "Read the line under the fixture before you pick a talk. It is the dugout's honest read of the mood and the odds.",
          "Saying the same thing every week stops working, and after a few in a row it starts to grate."
        ]
      },
      {
        heading: "Chasing or protecting",
        items: [
          "Attacking means more goals at both ends. Chase with it when you need wins, not when a draw will do.",
          "Defensive means fewer goals and more draws. It is the shape for protecting a point you can afford."
        ]
      },
      {
        heading: "The press and the cup",
        items: [
          "The press answers move morale and the board a little. Promising a win out loud fires the other lot up and costs you if you do not deliver.",
          "Do not throw the cup games. They do not count toward the target, but a bad exit takes a chunk out of the board meter."
        ]
      },
      {
        heading: "Fans as a safety net",
        items: [
          "One point short is not always the end. Keep the fans onside with results and they can buy you the job."
        ]
      }
    ],
    faqs: [
      { q: "Is Manager Hot Seat the same as Club Manager?", a: "It runs on the same engine. The clubs, squads, fixtures, match simulation, board meter, fan meter, team talks and press room all come from Club Manager unchanged. Hot Seat is the short version: one job, five league games, one target." },
      { q: "Why did I take over a club near the top of the table?", a: "The job opens after the worst run of form between league weeks 6 and 14, so a strong side can still be in a slump. The target is set from the fixtures, so a good side gets asked for more." },
      { q: "Are the results real?", a: "No. The clubs and squads are the real ones Club Manager uses, but every match is simulated, and so is the season before you arrive. Nothing that happens here is a claim about the real club." },
      { q: "Can I replay today's hot seat?", a: "The daily is one go per day, and a refresh picks up where you left off. Free play has no limit." },
      { q: "Does it count on the leaderboard?", a: "Not yet. It records that you played, but it puts no points on the leaderboard for now." }
    ]
  },
  "/deadline-day": {
    intro: [
      "Deadline Day puts you in charge of recruitment at a real club on the last day of the summer transfer window. The board have picked out three or four places in the side that need an upgrade, left you a budget, and the window shuts at 11pm.",
      "It runs on the Club Manager transfer desk, so every asking price, counter, patience count, valuation read, rival bid and agent's demand is the same one the full game plays. What is new is the clock: twelve hours, and every bid costs one of them.",
      "There is a daily, the same club, the same list and the same budget for everyone, and a free play mode at any club you like."
    ],
    headings: {
      howToPlay: "How to play Deadline Day, the free transfer window game",
      rules: "Deadline Day rules: the clock, the fee table and the grade",
      example: "A Deadline Day walkthrough, four signings before 11pm",
      tips: "Deadline Day tips for beating the clock without overpaying",
      faq: "Deadline Day FAQ: real players, the daily and the leaderboard"
    },
    howToPlaySections: [
      {
        heading: "Choosing the daily club or free play",
        items: [
          "Open today's window for the shared daily club, or pick any club in free play, or let the game pick one at random."
        ]
      },
      {
        heading: "Reading the board's brief",
        items: [
          "Read the brief. Each need is a place in your current eleven, with who starts there now and the rating that would count as an upgrade.",
          "Under each need are two or three real players who could fill it, cheapest first, each with what your recruitment desk thinks he is worth."
        ]
      },
      {
        heading: "Working a deal",
        items: [
          "Tap a player to open his deal, then call his club. The call is free and their asking price comes straight back."
        ],
        subsections: [
          {
            heading: "Bidding at the fee table",
            items: ["Type a bid and watch the meter, or use the quick buttons to lowball, haggle or meet the ask. Sending it takes an hour."]
          },
          {
            heading: "Agreeing personal terms",
            items: ["Once the fee is agreed, his agent names a contract length, a weekly wage and a signing bonus. Offering terms takes an hour too."]
          }
        ]
      },
      {
        heading: "Selling to raise money",
        items: [
          "Short of money? Sell one of your bench players to a club that has made an offer. Each sale takes an hour and the fee goes straight into the budget."
        ]
      },
      {
        heading: "Finishing the day",
        items: [
          "Keep going until every need is filled, or shut the window yourself when you are done."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "The clock and the brief",
        items: [
          "The window opens at 11am and shuts at 11pm, so you have 12 hours.",
          "Calling a club and walking away cost no time. Every bid, every offer of terms and every sale costs one hour.",
          "The board want 3 or 4 places filled. A need is filled by a signing who can play that place and is rated at or above its line.",
          "The budget is about what the cheapest man for each need would cost at his listed price plus the signing bonus his agent asks for. The dearest man for every need would cost more than you have.",
          "Your desk gives a range for what each player is worth, and what he is really worth is always inside it."
        ]
      },
      {
        heading: "How the selling club answers",
        items: [
          "Bid 97 percent of their ask or more and the fee is agreed.",
          "Between 75 and 97 percent they counter: the ask comes 40 percent of the way down to your bid, and it costs one round of their patience.",
          "Under 75 percent is an insult. The ask goes up 4 percent and it costs two rounds. Under 55 percent they end the talks on the spot.",
          "A selling club starts with 4 or 5 rounds of patience. Run it out and the deal is dead."
        ]
      },
      {
        heading: "The agent and the budget",
        items: [
          "His agent hears 3 offers at most. An offer that adds up to what he asked for signs him, a near miss gets a lower wage demand back, and a poor one costs two tries or ends the meeting.",
          "The board will not go over the wage or the contract length he asks for, so you cannot pay him more a week to skip the signing bonus.",
          "The signing bonus comes out of the same budget as the fee. A bid or an offer you cannot afford is refused before the hour is spent, so the budget never goes below zero."
        ]
      },
      {
        heading: "Rival clubs moving in",
        items: [
          "Rival clubs move for players on your list. If a rival is in for a man and you do not push his deal that hour, there is a 30 percent chance they sign him.",
          "If a rival is in at the fee table, your bid has to beat theirs. Bid at or under their number and there is a 30 percent chance they close the deal there and then.",
          "Walk away from a deal with a rival circling and they usually take him."
        ]
      },
      {
        heading: "When the window shuts",
        items: [
          "When the window shuts, any deal still in talks or at the terms table collapses, and none of its money is spent."
        ],
        subsections: [
          {
            heading: "How the grade adds up",
            items: [
              "The grade is out of 100: 50 for needs filled, 30 for value for money and 20 for budget left.",
              "Value for money is full for a fee at or under what the player is really worth and nothing at 1.5 times it, averaged over your signings.",
              "Budget points are the share of the budget you kept times the share of needs you filled, so a window that signs nobody scores nothing.",
              "The letters are A+ from 90, A from 80, B from 65, C from 50 and D from 35. Anything lower is an F."
            ]
          }
        ]
      },
      {
        heading: "The daily and the leaderboard",
        items: [
          "The daily is the same club, the same list, the same budget and the same dice for everyone on an Eastern day. One go per day, and a refresh picks up where you left off.",
          "Deadline Day records that you played but puts no points on the leaderboard for now, while the points system is being rebuilt."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "The board's shopping list",
        paragraphs: [
          "Say today's club needs a goalkeeper, a central midfielder, a right winger and a striker, and the board have left you \xA329m."
        ]
      },
      {
        heading: "Haggling for the keeper",
        paragraphs: [
          "You start with the keeper. His club are asking \xA33.6m, your desk says he is worth \xA32.4m to \xA33.2m, and you bid \xA33.1m. That is a counter: they come down to \xA33.4m and one round of patience is gone. It is noon.",
          "You bid \xA33.3m, inside 97 percent of their ask, and the fee is agreed. His agent wants 4 years at 10k a week and a \xA31.8m bonus. You offer exactly that and he signs. It is 2pm and you have \xA323.9m left."
        ]
      },
      {
        heading: "A rival steals a target",
        paragraphs: [
          "While you were on the phone, a rival came in for the dearest keeper on your list at noon and signed him at 2pm. It did not matter this time, but the same thing can happen to the striker you were saving for last."
        ]
      },
      {
        heading: "The striker with an hour to spare",
        paragraphs: [
          "By 8pm the midfielder and the winger are in, three hours each. The striker's club will not budge much and a rival is in for him, so you bid over the rival's number and inside 97 percent of the ask. Fee agreed at 9pm, terms signed at 10pm, an hour to spare."
        ]
      },
      {
        heading: "Grading the window",
        paragraphs: [
          "Four needs out of four. The keeper cost \xA33.3m for a \xA33m player, 10 percent over his real worth, which keeps 80 percent of his share of the value points, and say the other three went about 10 percent over too. That is 50 for needs, 24 for value and, with \xA31m of the \xA329m left, 0.7 for budget: 75 out of 100, a B."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Using the free phone calls",
        items: [
          "Call every club on your list early. The call is free, and it puts every asking price in front of you before you spend an hour."
        ]
      },
      {
        heading: "Pricing off your desk",
        items: [
          "Open around the middle of your desk's range, never under 75 percent of their ask, then come about half way up to their number each round. Every fee at or under his real worth keeps your value points whole.",
          "A haggle costs an hour and a round of patience. With plenty of clock, pitch low and come up. With the window closing, pay near the ask and get it done.",
          "Do not insult a club unless you mean it. Under 75 percent of the ask costs two rounds and pushes the price up."
        ]
      },
      {
        heading: "Leaving room for the bonus",
        items: [
          "On a cheap player the signing bonus can be more than half the fee, so leave room for it before you agree the fee."
        ]
      },
      {
        heading: "Seeing off the rivals",
        items: [
          "When a rival comes in, deal with that player next. Every hour you leave him alone they have a 30 percent shot at signing him."
        ]
      },
      {
        heading: "Raising money from the bench",
        items: [
          "If the sums do not add up, sell a bench player early, so the money is there when the fee table needs it."
        ]
      },
      {
        heading: "What the grade rewards",
        items: [
          "Money left only scores once the needs are filled, so a full window at a fair price beats a cheap half window.",
          "Shutting the window early earns nothing for the hours you did not use. Unused money counts, unused time does not."
        ]
      }
    ],
    faqs: [
      { q: "Is Deadline Day the same as Club Manager?", a: "It runs on the same transfer desk. The clubs, squads, market, asking prices, patience, valuation desk, rival bids and personal terms all come from Club Manager unchanged. Deadline Day is one day of it against the clock." },
      { q: "Are the players and the deals real?", a: "The players, their clubs, ratings, ages and values are the real ones Club Manager uses. The negotiations, the rival bids and the signings are simulated, so nothing that happens here is a claim about a real transfer." },
      { q: "What happens to a deal at 11pm?", a: "If you are still haggling, or the fee is agreed but his terms are not signed, the deal collapses and none of the money is spent." },
      { q: "Can I replay today's window?", a: "The daily is one go per day, and a refresh picks up where you left off. Free play has no limit, and every free play window is a fresh one." },
      { q: "Does it count on the leaderboard?", a: "Not yet. It records that you played, but it puts no points on the leaderboard for now." }
    ]
  },
  "/sign-the-player": {
    intro: [
      "Three bidders, one billion pounds each: you, The Sheikh, and Moneyball Mike. Twenty two players go under the hammer across two passes, eleven journeymen wait to fill the gaps, and a simulated mini league decides who spent it best.",
      "The auction runs the way a real room does: lots come up in a random position order at real list price, a contested lot turns into a live bidding war, an unwanted one decays until somebody snaps the bargain, and the most valuable player in the room headlines the final lot."
    ],
    headings: {
      howToPlay: "How to play Sign the Player, a free online soccer auction game",
      rules: "Sign the Player rules: bidding, passes and the journeyman fill",
      example: "Sign the Player walkthrough: a striker war and a title race",
      tips: "Sign the Player tips for beating The Sheikh and Moneyball Mike",
      faq: "Sign the Player FAQ: bidding, passing and the showdown score"
    },
    howToPlaySections: [
      {
        heading: "Choosing your auction theme",
        items: [
          "Pick a theme: Current Stars, All-Time Legends, or World Cup 2026."
        ]
      },
      {
        heading: "How the two bidding passes run",
        items: [
          "Pass one is a lot per position from the middle band in a random order; pass two is the elite band, with the single most valuable player held back to headline the close. Until a position has come up, the room shows the running order, never the names."
        ]
      },
      {
        heading: "Bidding steps and winning a lot",
        items: [
          "Bid in steps of 5, 10, or 25 million, or pass. If you are the only one who wants him, you get him at the list price."
        ]
      },
      {
        heading: "Filling the last empty chairs",
        items: [
          "When the last hammer falls, every open chair on every squad is filled from the journeyman list at a fee, so nobody plays the showdown a man short."
        ]
      },
      {
        heading: "Simulating the showdown season",
        items: [
          "Once all three squads hit 11, the showdown simulates the league and crowns a champion."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "The auction pool and starting funds",
        items: [
          "Every bidder starts with 1 billion pounds. Twenty two auction lots cover the 11 positions twice, middle band then elite, and eleven journeymen fill whatever stays open at the end."
        ]
      },
      {
        heading: "How a war or a lone bid sets the price",
        items: [
          "Two bidders or more on the same lot and it is a war, so it always finishes above list. Exactly one bidder and he takes him for the list price, not a penny over."
        ],
        subsections: [
          {
            heading: "When nobody bids at list price",
            items: [
              "If nobody bids at list price, the price falls step by step; anyone can snap it mid fall, and a lot that reaches thirty percent of list is withdrawn unsold."
            ]
          }
        ]
      },
      {
        heading: "Filling empty chairs after the auction",
        items: [
          "An end of auction fill costs just under half the player's list price, minimum 5 million."
        ]
      },
      {
        heading: "The showdown format and your final score",
        items: [
          "The showdown is a double round robin, 4 matches per club, ranked by points then goal difference.",
          "Score is a place bonus (300, 150, or 50) plus 3 per point of squad rating plus 1 per 10 million left in the bank."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "A striker war during the first pass",
        paragraphs: [
          "A striker lot opens mid running order at his real list price. The Sheikh wants him, so you nudge the price once and let go; he wins the war at 240 million, and when the elite striker headlines the close he is too broke to fight you."
        ]
      },
      {
        heading: "The showdown decides the title",
        paragraphs: [
          "The leftover striker goes to Mike, fee and all. The sim hands you the title on goal difference, and the unspent money pads your score."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Taxing The Sheikh's overpays",
        items: [
          "The Sheikh overpays, so tax him on lots you do not want, then step away."
        ]
      },
      {
        heading: "Fighting Moneyball Mike for value",
        items: [
          "Moneyball Mike passes on superstars and hunts value, so fight him for the mid priced lots."
        ]
      },
      {
        heading: "Why passing everything still costs you",
        items: [
          "Passing everything still costs you: the end of auction fill charges a fee for every open chair, and journeymen do not win showdowns."
        ]
      }
    ],
    faqs: [
      {
        q: "Do I bid against real people?",
        a: "No, both rivals are AI moguls: The Sheikh pays over the odds, Moneyball Mike only spends where he sees value."
      },
      {
        q: "What happens if I pass on everything?",
        a: "Your squad never has holes: missed positions get the leftover player, fee and all, so full passing buys the worst XI in the room."
      },
      {
        q: "Is it a daily game?",
        a: "No. Every run builds a fresh 33 player pool for your chosen theme, so no two auctions repeat."
      }
    ]
  },
  "/gauntlet-draft": {
    intro: [
      "Gauntlet Draft is the draft mode: a formation is drawn, each of its eleven slots deals you five real players from a genuine star to a bargain, and you keep exactly one per slot.",
      "Then the cup begins. Your finished XI runs five knockout rounds against ever stronger opposition, rated 70 up to 89, with extra time and penalties when the ninety minutes are level.",
      "The run is decided entirely by the squad you drafted: the same XI always runs the same gauntlet, so every pick is the game."
    ],
    headings: {
      howToPlay: "How to play Gauntlet Draft: Soccer, a free online card draft game",
      rules: "Gauntlet Draft: Soccer rules for cards, the knockout and opposition ratings",
      example: "Gauntlet Draft: Soccer walkthrough of a striker pick and a four round run",
      tips: "Gauntlet Draft: Soccer tips for drafting a squad that lifts the trophy",
      faq: "Gauntlet Draft: Soccer FAQ on the daily draft, real players and replays"
    },
    howToPlaySections: [
      {
        heading: "Choosing daily or unlimited mode",
        items: [
          "Pick the daily gauntlet (the same five card choices for everyone today) or unlimited for a fresh draft."
        ]
      },
      {
        heading: "Drafting one card per slot",
        items: [
          "For each slot, read the five cards, star to bargain, and tap the one you keep. Position families apply, so a winger card can cover either flank."
        ]
      },
      {
        heading: "How the knockout starts on its own",
        items: [
          "After pick eleven the knockout starts on its own: five rounds, one match each, revealed one at a time."
        ]
      },
      {
        heading: "Scoring survival points and the trophy",
        items: [
          "Survive a round for 16 points; lift the trophy for exactly 100."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Real players against invented opponents",
        items: [
          "Every card is a real player from the same verified market data the rest of the site uses; every opponent club is invented on purpose."
        ]
      },
      {
        heading: "Card spread and no repeat picks",
        items: [
          "The five cards per slot are spread across the value bands, so a star and a bargain are always both on the table."
        ],
        subsections: [
          {
            heading: "Never dealt the same player twice",
            items: [
              "No player is dealt twice in one draft."
            ]
          }
        ]
      },
      {
        heading: "Why every replay stays deterministic",
        items: [
          "The knockout is deterministic in your XI: goals come from the rating gap, level games go to extra time and then penalties, and replaying the same squad replays the same cup."
        ]
      },
      {
        heading: "Climbing opposition ratings by round",
        items: [
          "Opposition ratings climb 70, 76, 81, 85, 89. A bargain draft usually falls in the first two rounds, an elite one reaches the final as a slight underdog, and even a perfect draft lifts the trophy about one run in eight."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "A striker slot with five cards to choose",
        paragraphs: [
          "The draw hands you a 4-3-3 and the striker slot deals a 91 rated superstar next to an 84, a 79, a 74 and a 68. You pay nothing for any of them, so the 91 is the pick unless you are chasing a story."
        ]
      },
      {
        heading: "Four rounds survived and one regret",
        paragraphs: [
          "Your finished XI rates 84. The Qualifier ends 3-0, the Last Sixteen 2-1, the Quarter Final needs penalties, and the Semi Final ends the run 1-2. Four rounds survived, 64 points, and the draft you would redo is the 74 you took at left back."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Why the keeper slot matters as much",
        items: [
          "The keeper card matters as much as the striker card: one weak slot drags the whole rating."
        ]
      },
      {
        heading: "Bargain cards versus chasing the score",
        items: [
          "The bargain cards exist for flavor runs, not for winning. If the score is the goal, draft the biggest number that fits."
        ]
      },
      {
        heading: "Watching your running rating climb",
        items: [
          "Champions need a squad in the high eighties. Check your running rating under the cards as you go."
        ]
      }
    ],
    faqs: [
      { q: "Is the daily draft the same for everyone?", a: "Yes. One shared set of five card choices per Eastern Time date, so daily scores compare fairly." },
      { q: "Are the opponents real clubs?", a: "No, and that is deliberate: every gauntlet opponent is an invented club, so no real badge or name is borrowed. The players you draft are real." },
      { q: "Can the same squad get a different cup run?", a: "No. The run is computed from your finished XI, so the draft is the whole game and replaying the same eleven replays the same matches." }
    ]
  },
  "/footle": {
    intro: [
      "Footle gives you 8 guesses to name a mystery soccer player. Each guess is a real player, and colored tiles compare it to the answer across eight attributes, from club to kit number.",
      "You get eight goes at one mystery player and every guess comes back colour coded: arrows say whether the answer is older, scores more, or wears a higher number. Everyone gets the same new player every day."
    ],
    headings: {
      howToPlay: "How to play Footle, a free daily soccer guessing game",
      rules: "Footle rules: guesses, yellow tiles and the difficulty tiers",
      example: "Footle walkthrough: from Bellingham to a Barcelona academy graduate",
      tips: "Footle tips for narrowing down the mystery player fast",
      faq: "Footle FAQ: daily resets, difficulty tiers and unlimited mode"
    },
    howToPlaySections: [
      {
        heading: "Typing a name from the suggestions",
        items: [
          "Type a player's name and pick him from the suggestions."
        ]
      },
      {
        heading: "Reading the color coded tiles",
        items: [
          "Read the tiles: green is an exact match, yellow is close, white is a miss."
        ]
      },
      {
        heading: "Following the up or down arrows",
        items: [
          "Follow the arrows: up means the answer's value is higher than your guess."
        ]
      },
      {
        heading: "Narrowing by continent, league and position",
        items: [
          "Narrow by continent, league, and position group before sweating exact numbers."
        ],
        subsections: [
          {
            heading: "Solving within your eight guesses",
            items: [
              "Get the name within 8 guesses and share your emoji grid."
            ]
          }
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Eight guesses in every mode",
        items: [
          "You get 8 guesses in both daily and unlimited mode."
        ]
      },
      {
        heading: "What counts as a close yellow tile",
        items: [
          "Yellow means close: same continent, same league, within 3 goals, assists, or kit number, within 2 years of age, within 5 million dollars of value, or the same position group."
        ]
      },
      {
        heading: "Daily difficulty split and unlimited choice",
        items: [
          "The daily tier is shared: about 40 percent of days are Easy, 55 Hard, 5 Insane.",
          "In unlimited mode you choose Easy, Hard, or Insane, and the answer always comes from that tier."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Opening with a famous midfielder",
        paragraphs: [
          "Open with Jude Bellingham. Club comes back yellow, so the answer is La Liga but not Real Madrid. Position is green, a midfielder, and the age tile points down."
        ]
      },
      {
        heading: "Zeroing in on a young La Liga midfielder",
        paragraphs: [
          "Young La Liga midfielders scream Barcelona. Pedri turns club green, kit number and goals steer the last step, and Gavi lights the board on guess three."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Starting on someone you know cold",
        items: [
          "Open with someone you know cold so the arrows mean something."
        ]
      },
      {
        heading: "Category tiles before chasing the stats",
        items: [
          "Category tiles carve the pool faster than stats: continent, then league, then position group."
        ]
      },
      {
        heading: "Why the kit number tile is sneaky useful",
        items: [
          "Kit number is sneaky useful. A yellow pins the shirt to within 3."
        ]
      },
      {
        heading: "Probing with famous names on Insane",
        items: [
          "In unlimited Insane, still probe with famous names. Guessing stays open to the full pool."
        ]
      }
    ],
    faqs: [
      {
        q: "When does the daily Footle reset?",
        a: "At midnight Eastern Time, everyone flips to the same new puzzle. Your finished result stays saved in your browser until then."
      },
      {
        q: "What are the difficulty tiers?",
        a: "Easy is the 80 most valuable players in the world right now plus the all-time greats, Hard is squad players at big clubs, Insane is obscure pros from smaller leagues. A banner shows the daily tier before your first guess. Easy goes on market value rather than fame, so a teenager who has not made his name yet can still turn up there."
      },
      {
        q: "Can I keep playing after the daily?",
        a: "Yes, unlimited mode deals endless rounds at any difficulty, and it never touches your daily result."
      }
    ]
  },
  "/career": {
    intro: [
      "A player's whole career sits in front of you, season by season, with almost everything covered up. Work out who it is while revealing as few boxes as you can.",
      "Only the season years start visible. Club, appearances, goals, assists, and market value hide behind tappable boxes. It is a memory test for anyone who has watched a decade of transfer windows."
    ],
    headings: {
      howToPlay: "How to play Career Quiz, a free soccer career reveal puzzle",
      rules: "Career Quiz rules: guesses, hints and the hidden columns",
      example: "Career Quiz walkthrough: from a Juventus box to naming Zlatan",
      tips: "Career Quiz tips for reading a career table fast",
      faq: "Career Quiz FAQ: daily puzzles, hints and unlimited tiers"
    },
    howToPlaySections: [
      {
        heading: "Tapping boxes to reveal the table",
        items: [
          "Tap any hidden box to reveal that cell of the career table."
        ]
      },
      {
        heading: "Using Give Hint for four boxes at once",
        items: [
          "Press Give Hint to open 4 random boxes at once, as often as you like."
        ]
      },
      {
        heading: "Typing a guess at any time",
        items: [
          "Guess by typing a name in the search bar, any time, even with zero boxes open."
        ],
        subsections: [
          {
            heading: "Why revealing boxes is always free",
            items: [
              "Wrong guesses burn one of your 8 chances. Revealing boxes never does."
            ]
          }
        ]
      },
      {
        heading: "What the game logs when you solve it",
        items: [
          "Solve it and the game logs both your guess count and your box count."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Eight guesses before the run ends",
        items: [
          "You get 8 guesses, and 8 wrong guesses ends the run."
        ]
      },
      {
        heading: "Hints and the five hidden columns",
        items: [
          "Each hint opens exactly 4 random boxes.",
          "Five columns hide per season: club, appearances, goals, assists, and market value."
        ]
      },
      {
        heading: "Daily puzzle versus unlimited difficulty tiers",
        items: [
          "The daily is shared by everyone. Unlimited mode adds Easy, Normal, and Hard tiers, splitting the pool by peak market value."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "A Juventus club box mid career",
        paragraphs: [
          "You open one club box mid career and get Juventus. Big list, so you open the market value cell on that row: star money, a player in his prime. One more club box near the top shows Ajax."
        ]
      },
      {
        heading: "Naming Zlatan in one guess",
        paragraphs: [
          "Ajax to Juventus with superstar value narrows it fast. You type Zlatan Ibrahimovic and win in 1 guess with 3 boxes revealed, the kind of line worth sharing."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Why club boxes are the biggest tell",
        items: [
          "Club boxes are the biggest tell. A distinctive transfer route can solve it in two reveals."
        ]
      },
      {
        heading: "Market value peaks and prime years",
        items: [
          "Market value peaks mark the prime years and split superstars from journeymen."
        ]
      },
      {
        heading: "Reading goals and appearances by position",
        items: [
          "Goals in the twenties every season screams striker. Big appearances with few goals hints at defenders and keepers."
        ]
      },
      {
        heading: "Taking your time with no clock running",
        items: [
          "No clock is running, so sit with the pattern before you spend a guess."
        ]
      }
    ],
    faqs: [
      {
        q: "Do revealed boxes count against me?",
        a: "No, only wrong guesses spend your 8 chances. Boxes just appear in the final stat line, where fewer looks better."
      },
      {
        q: "Is there a daily puzzle?",
        a: "Yes, one shared puzzle a day, plus unlimited practice with difficulty tiers you can replay forever."
      },
      {
        q: "Can I guess with no boxes open?",
        a: "Yes, the search works from the first second. A zero box solve is the rarest flex in the game."
      }
    ]
  },
  "/higher-lower": {
    intro: [
      "Most higher or lower games hide a number and make you call it. This one flips the table: your player's stats are face up, the challenger's are hidden, and you pick the battleground.",
      "Three career totals are in play: appearances, goals and international caps. Choose the one stat where your player beats the mystery opponent. One bad read ends the run."
    ],
    headings: {
      howToPlay: "How to play Soccer Higher or Lower, a free career stats comparison game",
      rules: "Soccer Higher or Lower rules: ties, career totals and one wrong pick",
      example: "Soccer Higher or Lower walkthrough: Maldini's appearances start a streak",
      tips: "Soccer Higher or Lower tips for picking the safest career stat",
      faq: "Soccer Higher or Lower FAQ: ties, streaks and hidden opponents"
    },
    howToPlaySections: [
      {
        heading: "Studying your player's three stats",
        items: [
          "Study your player's three revealed career stats."
        ]
      },
      {
        heading: "Picking the stat that beats the opponent",
        items: [
          "Tap the one stat where you think your player is at least as high as the hidden opponent."
        ]
      },
      {
        heading: "Watching the reveal either way",
        items: [
          "The reveal shows both cards for a few seconds either way."
        ],
        subsections: [
          {
            heading: "How a correct pick grows your streak",
            items: [
              "Correct picks grow your streak, and the opponent becomes your next player."
            ]
          }
        ]
      },
      {
        heading: "What happens after a wrong pick",
        items: [
          "A wrong pick ends the game. Share the streak and go again."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Three career totals decide every matchup",
        items: [
          "All three stats are career totals."
        ]
      },
      {
        heading: "Why a tie still counts as a win",
        items: [
          "Ties count for you: a pick is correct when your number is higher than or equal to the opponent's."
        ]
      },
      {
        heading: "No lives, no timer, one wrong pick",
        items: [
          "One wrong pick ends the run. There are no lives and no timer."
        ]
      },
      {
        heading: "Every matchup is winnable by design",
        items: [
          "Every matchup is winnable by design, with at least one stat where your player is not behind.",
          "International caps are senior full internationals, and a card says on the reveal when its number comes from one publisher rather than two."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Picking appearances for a defender",
        paragraphs: [
          "Your card is Paolo Maldini. Goals is a trap for a defender who played 25 years at the back, so you tap appearances, and 902 games holds up against almost anybody."
        ]
      },
      {
        heading: "The streak climbs against a striker",
        paragraphs: [
          "The reveal shows a striker with a monster goal column and a short career. Streak to 7, and now you play as that striker, hunting his one strong column."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Why appearances reward long careers",
        items: [
          "Appearances reward longevity, so keepers and one club legends quietly dominate that column."
        ]
      },
      {
        heading: "Remembering who might be hiding",
        items: [
          "Remember who might be hiding: the pool mixes recent names with retired icons carrying finished, giant totals."
        ]
      },
      {
        heading: "Why a merely solid stat can be safest",
        items: [
          "Ties go to you, so a merely solid stat can still be the safest pick."
        ]
      },
      {
        heading: "Chasing your best streak of the session",
        items: [
          "Your best streak of the session stays on screen. Chase it while the pool is fresh in your head."
        ]
      }
    ],
    faqs: [
      {
        q: "How is this different from classic higher or lower?",
        a: "You pick the stat instead of calling a hidden number higher or lower. Choosing the battleground is the whole skill."
      },
      {
        q: "Does a tie end my run?",
        a: "No, a level stat counts as a win and the streak continues."
      },
      {
        q: "What is the score?",
        a: "The streak itself: 1 per correct pick, with your session best shown as the target to beat."
      }
    ]
  },
  "/connections": {
    intro: [
      "Sixteen players, four secret groups, and a board built to trick you. Sort all 16 names into their hidden categories of four before your lives run out.",
      "The connections range from friendly, like a shared club, to evil, like a common shirt number or award. Each solved group shows a difficulty color, and purple is usually the trap."
    ],
    headings: {
      howToPlay: "How to play Soccer Connections, a free football players grouping puzzle",
      rules: "Soccer Connections rules: lives, hints and the four difficulty colors",
      example: "Soccer Connections walkthrough: four AC Milan legends and one swap",
      tips: "Soccer Connections tips for spotting the trap player early",
      faq: "Soccer Connections FAQ: daily puzzles, hints and your win streak"
    },
    howToPlaySections: [
      {
        heading: "Tapping four players and submitting",
        items: [
          "Tap four players you think belong together and hit Submit."
        ]
      },
      {
        heading: "Locking in a correct category",
        items: [
          "Correct sets lock in with their category name and color."
        ]
      },
      {
        heading: "What a wrong guess costs you",
        items: [
          "Wrong sets cost one of your 4 lives. If 3 of the 4 were right, the game says you were one away."
        ],
        subsections: [
          {
            heading: "Spending a hint on the easiest group",
            items: [
              "Spend a hint to reveal the category name of the easiest unsolved group."
            ]
          }
        ]
      },
      {
        heading: "Finding all four groups to win",
        items: [
          "Find all four groups before the lives run out."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Sixteen players in four hidden groups",
        items: [
          "Always 16 players forming exactly 4 groups of 4."
        ]
      },
      {
        heading: "Four lives and what a miss costs",
        items: [
          "You have 4 lives, and every wrong submission costs one."
        ]
      },
      {
        heading: "Hints reveal names, and the difficulty colors",
        items: [
          "Up to 4 hints, and they reveal category names only, never players.",
          "Colors mark difficulty: green easy, yellow medium, blue hard, purple insane."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Locking in four AC Milan legends",
        paragraphs: [
          "You spot Kaka, Maldini, Van Basten, and Gullit and submit them as AC Milan players. Locked, green. Then four Ballon d'Or winners come back one away: someone belongs to a sneakier group."
        ]
      },
      {
        heading: "Swapping one name to finish clean",
        paragraphs: [
          "Swap one name for Modric and it locks. The last eight should sort themselves, but you triple check anyway, because winning with all 4 lives intact is the real flex."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Never submitting your first idea",
        items: [
          "Never submit your first idea. Hunt the trap player who fits two categories."
        ]
      },
      {
        heading: "Locking your surest group first",
        items: [
          "Lock your surest group first. Every solve shrinks the board."
        ]
      },
      {
        heading: "What one away really means",
        items: [
          "One away means change exactly one player, not two."
        ]
      },
      {
        heading: "Saving hints for the trickiest groups",
        items: [
          "Save hints for the last two groups, where the categories get strange."
        ]
      }
    ],
    faqs: [
      {
        q: "Is there a new puzzle every day?",
        a: "Yes, the shared daily changes at midnight Eastern Time, and unlimited mode serves more puzzles from the full pool whenever you want."
      },
      {
        q: "Do hints cost a life?",
        a: "No, hints and lives are separate budgets of 4 each. A hint names a category; finding its four players is still on you."
      },
      {
        q: "How does the streak work?",
        a: "Each solve adds 1, any loss resets it to zero, and it is stored in your browser between visits."
      }
    ]
  },
  "/build-your-xi": {
    intro: [
      "Build Your XI hands you a formation, then a slot machine assigns a random club or country to every position. Your job is naming a player from that exact team who fits each slot.",
      "When the eleventh name lands, an AI referee grades the lineup and writes a short scouting report, then a season report plays a full year out with your XI: league finish, points, trophies and a top scorer. No two teams ever come out alike."
    ],
    headings: {
      howToPlay: "How to play Build Your XI, a free soccer lineup builder game",
      rules: "Build Your XI rules: positions, duplicates and chemistry points",
      example: "Build Your XI walkthrough: a Liverpool heavy lineup gets rated",
      tips: "Build Your XI tips for a lineup that scores well with the AI",
      faq: "Build Your XI FAQ: rerolls, positions and the rating verdict"
    },
    howToPlaySections: [
      {
        heading: "Choosing one of six formations",
        items: [
          "Choose one of 6 formations: 4-3-3, 4-4-2, 3-5-2, 4-2-3-1, 3-4-3, or 5-3-2."
        ]
      },
      {
        heading: "Spinning a club or country per slot",
        items: [
          "Tap a position. The spinner shows which club or national team that slot is locked to."
        ]
      },
      {
        heading: "Typing a player who fits the slot",
        items: [
          "Type a player from that team who fits. The game verifies the answer before it counts."
        ],
        subsections: [
          {
            heading: "Rerolling an assignment you hate",
            items: [
              "Hate an assignment? Reroll it for a different team."
            ]
          }
        ]
      },
      {
        heading: "Submitting your finished XI for a rating",
        items: [
          "Fill all 11 slots, check the role fit, chemistry and balance tiles under the pitch, then submit for the AI rating."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Wrong answers cost nothing to retry",
        items: [
          "Wrong answers are rejected with a reason but cost nothing. Retry until a valid name lands."
        ]
      },
      {
        heading: "Which nearby positions a slot accepts",
        items: [
          "A slot takes a player who plays there or right beside it: full backs and wing backs cover each other, wingers count on both flanks, CM covers CDM and CAM, strikers cover each other. A keeper only ever goes in goal."
        ]
      },
      {
        heading: "No duplicate players in your lineup",
        items: [
          "No duplicate players across your XI."
        ]
      },
      {
        heading: "Scoring chemistry and the offline backup judge",
        items: [
          "Chemistry: two players standing next to each other on the pitch who are at the same club on our data add +0.6 to the side, from the same country +0.2, up to +2 in all.",
          "If the AI judge is unreachable, a built in offline judge grades you instead, so a run never dead ends."
        ]
      },
      {
        heading: "Role fit and balance in the season sim",
        items: [
          "Role fit: a player in a slot his recorded positions cover plays at full value. Next door, like a right back at left back, costs 2 rating points on him, averaged over the eleven. The slot check never lets anyone further out of position than that.",
          "Balance: no defensive midfielder in a CM or CDM slot costs the side 1, and a wide slot held by someone who is not a wide player, like a centre back at full back, costs 0.5 for that flank.",
          "The season report says what role fit, chemistry and balance were each worth in league points, by replaying the same season without each one."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Alisson and Saka fill a Liverpool heavy XI",
        paragraphs: [
          "You take 4-3-3. Liverpool lands on the goalkeeper slot, so Alisson goes in. Arsenal on the right wing is Saka. Then the striker slot spins a national team, and you weigh Harry Kane against saving England for a harder slot."
        ]
      },
      {
        heading: "A verdict that praises the spine",
        paragraphs: [
          "Two men from the same club end up side by side in your back line, so chemistry pays you for it, and the verdict praises the spine while roasting your left back. You run it back in a 3-5-2."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Rerolling thin assignments before typing",
        items: [
          "Reroll thin assignments before typing, knowing the spin can land somewhere worse."
        ]
      },
      {
        heading: "Naming goalkeepers from small clubs",
        items: [
          "Small club on the wheel? Goalkeepers are easy to name, elite wingers are not."
        ]
      },
      {
        heading: "Putting clubmates side by side for chemistry",
        items: [
          "Two players from the same club or country only link when they stand next to each other, so use your slot choice to put them side by side."
        ]
      },
      {
        heading: "Letting autocomplete fix a rejected spelling",
        items: [
          "If a right sounding name is rejected, let the search autocomplete the spelling for you."
        ]
      }
    ],
    faqs: [
      {
        q: "Who checks my answers?",
        a: "A club pick you choose from the list is checked against our own records on the spot. A country pick is confirmed by an answer checker. If a check cannot complete, or answer checking runs out for the day, only that pick is skipped: try again, pick someone else or reroll. It never fills a slot with a wrong answer."
      },
      {
        q: "Can I reroll more than once?",
        a: "Yes, rerolls are unlimited, and each spin picks a team not already used in your lineup."
      },
      {
        q: "Can I put a goalkeeper in midfield?",
        a: "No. The game checks each pick's own position against the slot before anything else, so a keeper is refused everywhere except goal and nobody else can take the goal. Nearby positions are fine: a centre back can shift to right back, a defensive mid can fill a CM slot."
      },
      {
        q: "What does the rating look like?",
        a: "A rating headline, a short written analysis of your picks, and your role fit, chemistry and balance tiles. Under it comes a season report: a squad rating out of 100, where you finish in a 20 team league, points, trophies and a top scorer, plus how your defence, midfield and attack compare and what role fit, chemistry and balance were each worth in points. Two tabs open the season month by month and give every pick his appearances, goals, assists and average rating, and one line says what a different shape or a stronger pick in your weakest slot would have changed on the same rolls. Every player is judged at his peak, so retired greats are not marked down for being retired."
      }
    ]
  },
  "/football-connect-4": {
    intro: [
      "This is the Connect 4 you grew up with, except every square is earned with a soccer answer. Blue against Red on one board, four in a row wins.",
      "Each of the 7 columns and 6 rows carries an attribute. To claim a cell you name a player matching both, and gravity still applies: pieces fall to the lowest open row."
    ],
    headings: {
      howToPlay: "How to play Soccer Connect 4, a free football trivia and four in a row game",
      rules: "Soccer Connect 4 rules: columns, rows and rejected answers",
      example: "Soccer Connect 4 walkthrough: Ronaldinho blocks a winning line",
      tips: "Soccer Connect 4 tips for choosing columns over trivia recall",
      faq: "Soccer Connect 4 FAQ: turns, rejected names and network errors"
    },
    howToPlaySections: [
      {
        heading: "Alternating turns as Blue or Red",
        items: [
          "Grab an opponent. Blue and Red alternate turns on the same device, Blue first."
        ]
      },
      {
        heading: "Picking a column to drop your piece",
        items: [
          "Pick a column and the game highlights where your piece would drop."
        ]
      },
      {
        heading: "Naming a player who fits both clues",
        items: [
          "Name a player fitting both the column attribute and the row attribute."
        ],
        subsections: [
          {
            heading: "What a valid or rejected answer does",
            items: [
              "A valid answer claims the cell. A rejection lets you try another name or cancel."
            ]
          }
        ]
      },
      {
        heading: "Winning with four in a row",
        items: [
          "Connect 4 of your color in any direction to win."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "A board of seven columns and six rows",
        items: [
          "The board is 7 columns by 6 rows."
        ]
      },
      {
        heading: "Each name only works once per game",
        items: [
          "Each player name works once per game, for either side."
        ]
      },
      {
        heading: "Skipping turns, draws and rejected answers",
        items: [
          "You can skip a turn, and a full board with no winner is a draw.",
          "Answers are AI verified. Rejections do not pass your turn, and network errors never count against you."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Blocking a line with Ronaldinho",
        paragraphs: [
          "The column says Played for Barcelona, the row says World Cup Winner, and the drop spot blocks Red's line. Ronaldinho verifies, and the threat dies."
        ]
      },
      {
        heading: "Roberto Carlos keeps a diagonal alive",
        paragraphs: [
          "Red answers Brazilian plus Champions League Winner with Roberto Carlos to keep a diagonal alive. Every answer is also a tactical move, and knowing the name is only half the battle."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Playing the board before the trivia",
        items: [
          "Play the board first, trivia second. A brilliant answer in a useless column is wasted."
        ]
      },
      {
        heading: "Why center columns matter most",
        items: [
          "Center columns touch the most lines of four, so spend your deepest knowledge there."
        ]
      },
      {
        heading: "Tracking which names are already burned",
        items: [
          "Track burned names. Spending a do everything legend early starves your endgame."
        ]
      },
      {
        heading: "When skipping beats a bad drop",
        items: [
          "Skipping beats dropping a piece that sets up your opponent."
        ]
      }
    ],
    faqs: [
      {
        q: "Can I play solo?",
        a: "There is no AI opponent; it is built for two people sharing a screen. Playing both sides yourself works fine as practice."
      },
      {
        q: "What is the daily mode?",
        a: "Everyone gets the same daily board, and your game in progress saves in your browser. Unlimited mode deals random boards for rematches."
      },
      {
        q: "What if a correct player is rejected?",
        a: "The AI referee is strict and occasionally wrong. A rejection never ends your turn, so rephrase or pick someone else, and report the cell if a fair answer got robbed."
      }
    ]
  },
  "/soccer-grid": {
    intro: [
      "Soccer Grid is the team grid idea rebuilt for football: a daily 3x3 board where every cell needs a player who satisfies its row and its column at once.",
      "Filling it is half the game. Every correct answer shows how many others picked the same name, and the flex is a low rarity score from picks nobody thought of."
    ],
    headings: {
      howToPlay: "How to play Soccer Grid, a free daily soccer grid puzzle",
      rules: "Soccer Grid rules: guesses, timers and the rarity score",
      example: "Soccer Grid walkthrough: Benzema, then a nine for nine finish",
      tips: "Soccer Grid tips for keeping your rarity score low",
      faq: "Soccer Grid FAQ: daily resets, rare picks and Overtime"
    },
    howToPlaySections: [
      {
        heading: "Locking your tier and timer on guess one",
        items: [
          "Pick a difficulty tier and optional timer; your first guess locks both for the day."
        ]
      },
      {
        heading: "Reading a cell's two requirements",
        items: [
          "Tap a cell to see its two requirements, like a club crossed with a nationality."
        ]
      },
      {
        heading: "Submitting a player for a rarity score",
        items: [
          "Search a player and submit. Correct answers turn green with a rarity percentage."
        ],
        subsections: [
          {
            heading: "Budgeting fifteen guesses across nine cells",
            items: [
              "Budget carefully: 15 guesses for 9 cells, and every submission spends one."
            ]
          }
        ]
      },
      {
        heading: "Finishing and sharing the emoji board",
        items: [
          "Finish, or run out of guesses or clock, then share the emoji board."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Fifteen guesses and six allowed misses",
        items: [
          "15 guesses total, and correct answers consume guesses too, leaving room for 6 misses."
        ]
      },
      {
        heading: "Choosing a timer from unlimited to forty seconds",
        items: [
          "Timers: Unlimited, 90, 60, or 40 seconds, starting on your first guess."
        ]
      },
      {
        heading: "What easy and hard grids ask for",
        items: [
          "Easy grids lean on clubs, leagues, and positions. Hard brings awards plus Champions League and World Cup winners."
        ]
      },
      {
        heading: "How rarity score is worked out",
        items: [
          "Rarity score is the average pick percentage across your correct cells. Lower is better.",
          "If the checker cannot verify an answer, you retry free with no guess burned."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Benzema solves Real Madrid and France",
        paragraphs: [
          "Real Madrid crossed with France makes Karim Benzema the obvious green, at 44 percent. For Barcelona and Brazil you skip Neymar and submit Rivaldo: 6 percent, beautiful."
        ]
      },
      {
        heading: "Kaka finishes a nine for nine grid",
        paragraphs: [
          "The last corner wants a Champions League winner who played in Serie A. One miss, then Kaka clicks in: 9 for 9, rarity 19 percent."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Saving rare picks for the easy cells",
        items: [
          "Spend rare picks on the easy cells. Rarity is won where everyone answers."
        ]
      },
      {
        heading: "Journeymen cover the weird crossings",
        items: [
          "Journeymen who hopped leagues and countries cover the weird crossings."
        ]
      },
      {
        heading: "Planning all nine cells before a timer starts",
        items: [
          "On a timer, plan all nine cells before your first submission starts the clock."
        ]
      },
      {
        heading: "What Overtime does to your score",
        items: [
          "Overtime lets you keep filling leftover cells with no effect on your recorded score."
        ]
      }
    ],
    faqs: [
      {
        q: "When does a new grid come out?",
        a: "Every day at midnight Eastern Time, and everyone on your difficulty tier sees the same grid."
      },
      {
        q: "What counts as a rare answer?",
        a: "Under 5 percent of the field is rare, 5 to 25 uncommon, over 25 standard. Your score averages the percentages across correct cells."
      },
      {
        q: "Can I change settings mid puzzle?",
        a: "No, both lock at your first guess, so the clock cannot be dodged and the grid cannot be rerolled."
      },
      {
        q: "What is Overtime?",
        a: "An optional period after the round ends: unlimited guesses on the leftover cells while your recorded score stays frozen."
      }
    ]
  },
  "/world-cup-bracket": {
    intro: [
      "The 2026 World Cup has been played: Spain beat Argentina 1-0 after extra time in the final at MetLife Stadium on July 19. Build your bracket here anyway, then score it against what really happened, group by group and round by round, awards included.",
      "The 2026 World Cup runs 48 teams, 12 groups, and 104 matches, and this predictor lets you call all of it: every group game by exact score, every knockout winner, and the awards.",
      "The field is the real one, playoff winners included, and the format follows FIFA's: top two per group advance plus the 8 best third place teams into a round of 32."
    ],
    headings: {
      howToPlay: "How to play World Cup 2026 Bracket, a free soccer predictor and bracket game",
      rules: "World Cup 2026 Bracket rules: groups, standings and the round of 32",
      example: "World Cup 2026 Bracket walkthrough: a Group J tiebreak and a Brazil upset",
      tips: "World Cup 2026 Bracket tips for filling a sharper bracket",
      faq: "World Cup 2026 Bracket FAQ: scoring, groups and the real result"
    },
    howToPlaySections: [
      {
        heading: "Locking in scores for every group match",
        items: [
          "Type exact scores for the 6 matches in each group. Standings update live.",
          "Watch the colors: green rows are through, yellow marks a possible best third."
        ]
      },
      {
        heading: "Confirming your eight third place teams",
        items: [
          "Confirm your 8 third place qualifiers and generate the bracket."
        ]
      },
      {
        heading: "Advancing picks through the knockout bracket",
        items: [
          "Pick winners from the round of 32 through the final, third place game included."
        ]
      },
      {
        heading: "Naming the awards and reading your score",
        items: [
          "Call the Golden Boot, Golden Glove, and Golden Ball, then share it all.",
          "Read your score at the bottom: every qualifier, knockout team, the champion and each award checked against the real results, out of 166 points."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "How group matches and scoring work",
        items: [
          "12 groups of 4 make 72 group matches, and score inputs go up to 9 goals a side."
        ]
      },
      {
        heading: "Ranking standings by points and goals",
        items: [
          "Standings use the real rules: 3 points a win, 1 a draw, then goal difference, then goals scored."
        ]
      },
      {
        heading: "Which teams reach the round of 32",
        items: [
          "32 teams advance: 12 winners, 12 runners up, and your 8 chosen thirds."
        ],
        subsections: [
          {
            heading: "Auto filling results with By Rank",
            items: [
              "By Rank auto fill uses real FIFA rankings: the higher ranked side wins 65 percent of sims, the underdog 20, and 15 percent draw."
            ]
          }
        ]
      }
    ],
    exampleSections: [
      {
        heading: "A tiebreak battle in Group J",
        paragraphs: [
          "In Group J you hand Argentina three routine wins, then pencil an Austria and Algeria draw that leaves third place hanging on goal difference."
        ]
      },
      {
        heading: "Brazil survives a semifinal collision",
        paragraphs: [
          "By the knockouts your France and Brazil picks collide in a semifinal, so somebody goes home early. You send Brazil through, save the bracket, and drop the link in the group chat."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Splitting hand picks from the auto tools",
        items: [
          "Fill groups you know by hand, and save the auto tools for matchups you have no read on."
        ]
      },
      {
        heading: "Why third place slots swing brackets",
        items: [
          "Third place picks quietly decide brackets. A soft third in the right slot gifts your favorite an easy round of 32."
        ]
      },
      {
        heading: "Pricing draws low and fixing one group",
        items: [
          "Draws are rarer than instinct says. The simulator prices them at 15 percent.",
          "Reset one group instead of wiping everything when you change your mind."
        ]
      }
    ],
    faqs: [
      {
        q: "Do I need an account?",
        a: "Not to build a bracket; it stores in your browser as you go. Signing in is only for saving a bracket to a share link others can open."
      },
      {
        q: "Are the groups real?",
        a: "Yes, the 12 groups are the 48 teams that played, playoff winners included, and the auto fill rankings are the FIFA list from just before the tournament."
      },
      {
        q: "Is my bracket scored?",
        a: "Yes, since the tournament was played. The panel under the bracket checks your qualifiers, every knockout round, the champion and the three awards against the real 2026 results, out of 166 points. There is no pool and nothing is submitted anywhere."
      }
    ]
  },
  "/soccer-conquest": {
    intro: [
      "The imperialism map format comes to football. Ninety six clubs from the Premier League, La Liga, Serie A, the Bundesliga and Ligue 1 sit on one map of Europe, every region starts in the hands of the nearest club of its own country, and when two clubs meet the winner takes everything the loser owns.",
      "Nothing here is typed. Club strength is real squad market value, so Real Madrid open as the giants and a promoted side like Le Mans opens as the long shot, which is exactly the club you want to be riding when the upset lands."
    ],
    headings: {
      howToPlay: "How to play Soccer Conquest, a free online soccer strategy map game",
      rules: "Soccer Conquest rules: regions, scoring and the Daily Challenge",
      example: "Soccer Conquest walkthrough: Brentford topples Bayern Munich",
      tips: "Soccer Conquest tips for reading the odds and surviving wipeouts",
      faq: "Soccer Conquest FAQ: strength ratings, playoffs and daily runs"
    },
    howToPlaySections: [
      {
        heading: "Picking your club from all 96",
        items: [
          "Pick your club from all 96, grouped by league. The tile shows the squad value its strength comes from."
        ]
      },
      {
        heading: "Calling each matchday's 48 games",
        items: [
          "Each matchday pairs the whole continent into 48 games. Before it plays, call your club's game. The card shows each side's win odds."
        ]
      },
      {
        heading: "Playing the matchday and redrawing the map",
        items: [
          "Play the matchday. Winners annex everything the losers held, and the map redraws in one swing."
        ]
      },
      {
        heading: "Surviving ten matchdays into the playoffs",
        items: [
          "Survive 10 matchdays. The top 8 empires by region make the playoffs, record breaking ties."
        ],
        subsections: [
          {
            heading: "Winning the knockout to rule the map",
            items: [
              "Win the Quarter-finals, the Semi-finals and the Imperial Final to rule the map."
            ]
          }
        ]
      }
    ],
    ruleSections: [
      {
        heading: "The matchday format and knockout bracket",
        items: [
          "10 regular matchdays, then an 8 club knockout bracket."
        ]
      },
      {
        heading: "How the 154 regions are laid out",
        items: [
          "154 regions: 96 club home areas plus the countryside between them, which opens in the hands of the nearest club of the same country."
        ]
      },
      {
        heading: "Scoring calls, regions and the crown",
        items: [
          "Scoring: 25 points per correct call, 3 per region held at the end, 200 for the crown, 50 for making the playoffs."
        ]
      },
      {
        heading: "Wiped out clubs and level game penalties",
        items: [
          "Wiped out clubs keep playing, and one win takes back a whole empire.",
          "Level games go to penalties, so there are no draws, ever."
        ]
      },
      {
        heading: "Squad value strength and the Daily Challenge",
        items: [
          "Strength is the 2026 squad market value on record, mapped onto the same 55 to 95 band the other conquest maps use. The value is the sum of the players the table holds for that club, so every tile says how many that is, and a club with only a handful on record is rated on those few and says partial data."
        ],
        subsections: [
          {
            heading: "Daily Challenge versus Free Play",
            items: [
              "The Daily Challenge deals every player the same date seeded season: same opening map, same fixtures, same results. One scored run per day with streaks. Free Play is unlimited and fully random."
            ]
          }
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Brentford calls an upset over Bayern Munich",
        paragraphs: [
          "You ride Brentford. Matchday 1 pairs you with Bayern Munich, the odds sit under fifty, you call the upset anyway and it lands on penalties: Bavaria is yours."
        ]
      },
      {
        heading: "Falling to Lecce and clawing back from Genoa",
        paragraphs: [
          "By matchday 6 you hold a strip from west London to the Alps, then lose the lot to Lecce in ninety minutes. Matchday 8 you take an empire back off Genoa, sneak in as the eighth seed, and the bracket gets interesting."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Trusting the odds over your heart",
        items: [
          "Call games with the odds, not your heart. The percentages come from real squad values."
        ]
      },
      {
        heading: "Bouncing back after getting wiped out",
        items: [
          "Landless is one good night from owning a coastline. Do not panic when you get wiped."
        ]
      },
      {
        heading: "Watching seeding and beatable giants late",
        items: [
          "Check the standings late. Seeding goes by regions, so the last matchdays are about protecting your count.",
          "A big empire gets overextended and a landless club fights harder, so a giant on a losing run is beatable."
        ]
      }
    ],
    faqs: [
      { q: "How does the Daily Challenge work?", a: "Everyone gets the same season today: identical opening map, identical fixtures, identical results. Your score comes from which club you back and how well you call its games. One scored run per day, streaks build if you show up daily, and a fresh map drops at midnight Eastern. Free Play stays unlimited." },
      { q: "Where do the strengths come from?", a: "From the 2026 squad market values on record for each club, summed and mapped onto a 55 to 95 band. Nothing is hand rated. Every tile says how many players the sum covers, and a promoted club with only a handful on record is rated on those few and says partial data." },
      { q: "Why is the map made of hexagons?", a: "It is a cartogram: every region is one hex, laid out so the five countries sit where they do in Europe. Most club home hexes are named after the real district the ground is in; where two clubs share a city, Milan and Rome, they split it north and south; the rest are named after the real countryside between them." },
      { q: "Can the season end early?", a: "Yes. If one club annexes every region before matchday 10, total conquest crowns it immediately." },
      { q: "How do the playoffs work?", a: "The top 8 empires seed a knockout: Quarter-finals, Semi-finals, then the Imperial Final. Regions decide seeding, record breaks ties." }
    ]
  },
  "/soccer-career": {
    intro: [
      "Every soccer career simulator promises the same fantasy: start as a nobody, retire as a legend. This one makes the middle the good part. You begin at 16 in a youth academy and live season by season through contracts, transfers, injuries, feuds, trophies, and increasingly questionable purchases, until the game hands down a legacy verdict.",
      "It is the most played game on DoUKnowBall, and it sits closer to a life sim than to a match engine. You never dribble anyone. You make decisions, and the sim turns them into a story that is different every run.",
      "Your save lives in your browser, one career at a time, so choices carry weight into the years that follow them.",
      "You build your player's actual face before kickoff: skin tone, hairstyle and colour, facial hair, a boot line, an accessory, and a signature celebration that gets described every time you score. That look follows you onto the Ballon d'Or stage and into your retirement send off.",
      "There is a dirty side too. Bent officials, betting syndicates, kickbacks, offshore accounts and laundering fronts all sit there waiting, each one heating up a hidden investigation meter. Take enough envelopes and the dawn raid comes, then the trial, then a season inside and a comeback from nothing."
    ],
    headings: {
      howToPlay: "How to play Soccer Career, a free football career simulation game",
      rules: "Soccer Career rules: growth, legacy and the corruption meter",
      example: "Soccer Career walkthrough: a striker's rise to a Ballon d'Or revenge arc",
      tips: "Soccer Career tips for growing stats and building your legacy",
      faq: "Soccer Career FAQ: saves, the Ballon d'Or and corruption mode"
    },
    howToPlaySections: [
      {
        heading: "Creating your player and building your look",
        items: [
          "Create your player: name, one of 50 nationalities, one of 10 positions, and a starting era from the 1990s to the 2020s.",
          "Build your look in the appearance editor: 12 skin tones, 23 hairstyles, 16 hair colours, 14 beard styles, 16 accessories, 18 boot lines, and 19 signature celebrations, or hit Surprise me."
        ]
      },
      {
        heading: "Rolling potential and customizing your build",
        items: [
          "Roll your starting potential, somewhere in the mid 50s to high 60s, and reroll as many times as you like. Rerolls are free and there is no limit on them.",
          "Open Customize your build to set your starting overall anywhere from 40 to 99, move points between the six attribute families, shape the specifics under each family, and set your height and weight."
        ]
      },
      {
        heading: "Starting in the academy and turning pro",
        items: [
          "Begin in an academy matched to your nationality and talent. Pro contract offers arrive from age 17."
        ]
      },
      {
        heading: "Advancing seasons through the training ground",
        items: [
          "Advance season by season through simulated stats, newspaper headlines, random events, and decisions.",
          "Want to see it happen? The \u{1F4FA} Week by week button plays the same season match by match, with your rating every game and the league table after every matchday, then hands you back to the newspaper. Its ? button has the rules and worked examples.",
          "Up to three times a season the clock stops and the moment is yours to play on your training ground board (look for \u{1F3AF} on the fixtures): a YOUR CALL decides how that match went, with the return game taking the other side so your final table and season totals never move, and a RECREATE replays what the record says you did, for stars that bank into next season's growth.",
          "Open the training ground (the dumbbell button, bottom right) once a season. Your position picks a drill you actually play: keepers hold and drag a glove save dive, centre backs, full backs and defensive midfielders time a tackle on a moving ball, central and attacking midfielders thread a through ball onto a runner before he is offside, and everyone else times a wall shot through a gap that opens and closes. Today's ten rounds are the same for everyone at your position and count once; practice is unlimited and banks nothing."
        ]
      },
      {
        heading: "Working transfer windows and the shop aisles",
        items: [
          "Work the transfer windows: stay, extend, request a move, or weigh rival offers and dream club pay cuts.",
          "Spend the money in 8 shop aisles: property, vehicles, investments, lifestyle, performance, flex, family, and a shady aisle that only appears once you have something to hide."
        ],
        subsections: [
          {
            heading: "Retiring into management, punditry or ownership",
            items: [
              "Retire, on your terms or your body's, collect the legacy verdict, then carry on as a manager, pundit, or owner if you want."
            ]
          }
        ]
      }
    ],
    ruleSections: [
      {
        heading: "How stats grow through your prime",
        items: [
          "Stats grow slowly and honestly: 1 to 3 points a year through the academy and your prime, less once you pass 86, and barely at all above 90. Reaching world class is a decade of work, not three good seasons.",
          "Growth fades once your hidden prime type (early, normal, late, or extended) ends, with decline turning brutal from 38."
        ]
      },
      {
        heading: "Your boyhood club and retirement age",
        items: [
          "The club that raised you always offers you a first team deal when you turn pro, so you can spend a whole career at your boyhood club, and it can call you home again from 27.",
          "Retirement is suggested from age 30 once you drop 10 off your peak or hit 75 overall, forced below 50 overall at 33 or older, and automatic at 45."
        ]
      },
      {
        heading: "The World Cup cycle and your legacy score",
        items: [
          "The World Cup comes every 4 years. Top nations qualify about 90 percent of the time, while a small nation mostly needs a world class you.",
          "Legacy runs 0 to 100: 90 is GOAT, 80 LEGEND, 70 GREAT, 60 SOLID PRO, and less is JOURNEYMAN. The verdict also knows the overall you started at, so climbing from 54 to 91 scores better than being handed 91 on the creation screen."
        ]
      },
      {
        heading: "Starting overall and your growth ceiling",
        items: [
          "There is no cap on your starting overall, but a high start eats the room you had to grow into, and if you are already world class as a teenager you pick up far more injuries before you turn 24.",
          "Your ceiling is not welded shut. Two seasons in a row that are both elite and decorated, while you are already pressed against it, buy one point back at a time. 99 is the hard wall and nothing gets past it."
        ],
        subsections: [
          {
            heading: "How a position drill trains your attributes",
            items: [
              "A position drill is ten rounds and its session score is wins times ten. 50 pays +1 to the drill's attribute with next season's growth (shooting for the wall shot, defending for the tackle, passing for the through ball, reflexes for the glove save) and 80 pays +2, capped at the room between your overall and your ceiling, so a drill never lifts you past it. It shares the one training session a season with the cone slalom, sprint burst, passing gates and penalty sessions."
            ]
          }
        ]
      },
      {
        heading: "Physical stats, morale and integrity",
        items: [
          "Height and weight are real numbers, not decoration: a tall heavy player wins more in the air and is stronger, and is slower off the mark and less agile for it.",
          "Morale runs 0 to 100 and moves with events and choices, while scandals feed an integrity ledger worth minus 30 to plus 20 legacy points at the end."
        ],
        subsections: [
          {
            heading: "A pay cut, an injury and a rival's Ballon d'Or",
            items: [
              "A statistically dominant season cannot be snubbed at the Ballon d'Or. Outscore the whole shortlist while winning a major and the trophy is yours, and any 45 goal or 55 goal involvement season finishes on the podium at worst."
            ]
          },
          {
            heading: "Corruption heat and dirty money",
            items: [
              "Corruption heat runs 0 to 100 and cools 8 a year when you stay clean. Past 70 the financial crimes unit can raid you, and past 90 comes a conviction, seized money, and a season in prison that wrecks your stats.",
              "Unexplained money keeps generating heat every season until you wash it through a shady business or declare it and eat the tax."
            ]
          }
        ]
      },
      {
        heading: "Derby days against your club's rivals",
        items: [
          "Derbies: if your club has a real rival in the same league, you meet them twice a season in the league. We only count a rivalry two separate sources back, in leagues and years where we checked how often the clubs meet, so some clubs have none yet.",
          "You play the derbies you are picked for, roughly in line with your league appearances. Each one you win adds 2 popularity and 2 morale, each one you lose takes 2 off both, a draw changes nothing, the swing is capped every season and your rating is never touched.",
          "Score the goal that puts you ahead for good in a derby win and the season counts as a Derby Hero season, worth 2 more popularity. Example: at Arsenal you beat Tottenham 2-1 at home with the winner and draw 1-1 away, so that is +4 popularity, +2 morale and a Derby Hero."
        ]
      },
      {
        heading: "Your domestic cup run",
        items: [
          "Every season your club plays its country's domestic cup as a run, from the early rounds to the final, and the cup carries its real name (the FA Cup, the Copa del Rey, the DFB-Pokal) wherever two sources back it; a cup that was not played that season cannot be won.",
          "Go out early and your season summary names the round and the club that knocked you out. Win it and the celebration walks you through the run, and your trophy chip names the cup."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "A Nigerian striker breaks out as a teenager",
        paragraphs: [
          "Take a Nigerian striker rolled at 63, a Gifted start. Two academy years push him past 70, and at 18 a bidding war breaks out. He takes minutes over money, bags 20 league goals, and the papers crown him the next superstar."
        ]
      },
      {
        heading: "A dream transfer and a torn hamstring",
        paragraphs: [
          "At 22 a dream club calls with a pay cut, and he signs anyway. A league title lands in year two, then a torn hamstring eats half a season, and a moral dilemma offers a shady shortcut back to fitness. He refuses, banking integrity, while the rival the game spawned at his debut, a preening Brazilian winger, lifts the Ballon d'Or. The snub becomes fuel."
        ]
      },
      {
        heading: "A revenge arc ends in LEGEND tier retirement",
        paragraphs: [
          "The revenge arc peaks at 26: a Champions League, a World Cup semifinal carrying Nigeria, then the Ballon d'Or, where he thanks the rival from the stage. An extended prime runs to 36, the fortune buys his boyhood club, and he retires at 38 with a legacy of 84, LEGEND tier, one Champions League short of GOAT talk."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Rerolling your potential before you start",
        items: [
          "Reroll your potential to 62 or better. The gap between a Promising start and a Gifted one echoes for a decade."
        ]
      },
      {
        heading: "Training sessions and steering growth events",
        items: [
          "The training ground is the dumbbell button, one session a season. The older sessions (cone slalom, sprint burst, passing gates, penalties or shot stopping) pay +1 at 50 and +2 at 80; the position drill pays the same but stops at your ceiling. Beyond that, growth follows your age curve, and you steer it through event choices, lifestyle purchases, and the social media detox, worth plus 2 to every stat next season.",
          "In goal the same drills train keeper skills: the cone slalom is footwork and pays Positioning, the sprint burst pays Sweeping Speed, the passing gates pay Distribution and shot stopping pays Reflexes. Outfield players train Dribbling, Pace, Passing and Shooting from the same four tiles."
        ]
      },
      {
        heading: "Paying for a trainer and the recovery clinic",
        items: [
          "Money matters: a personal trainer adds a stat point per season, and the recovery clinic halves injury layoffs."
        ]
      },
      {
        heading: "Weighing the doping risk, your agent and loyalty",
        items: [
          "The doping storyline boosts every stat but risks a 20 percent failed test each season it runs, and failing means a 1 season ban and a wrecked reputation.",
          "Your personality and your agent shape the whole run. The Showman grows followers 60 percent faster, The Professor earns brand trust, and super agent Zara Blackwood opens dream club doors for a 10 percent cut.",
          "Loyalty pays: a decade at one club is worth about as much legacy as two and a half league titles."
        ]
      }
    ],
    faqs: [
      {
        q: "How do I save my career?",
        a: "Automatically, in your browser, after every decision. There is one career per browser, and starting fresh permanently deletes the old save. An optional account adds site stats and leaderboards, but the career lives on your device."
      },
      {
        q: "How do I win the Ballon d'Or?",
        a: "Post the best season in the world and the voters have to give it to you. If you outscore every player on the shortlist and win a league, Champions League, or World Cup, you win it outright, and any season of 45 goals or 55 goal involvements finishes top 3 at worst. Trophies still decide the close years, and a second place finish becomes next season's fuel."
      },
      {
        q: "What happens after retirement?",
        a: "Four paths: read your legacy breakdown and walk away, farm controversy as a TV pundit, chase trophies as a manager, or buy a lower league club and run it as owner."
      },
      {
        q: "What is the highest legacy score?",
        a: "100, with GOAT starting at 90. Expect to need multiple Ballon d'Ors and Champions Leagues, a World Cup, huge totals, and a clean record, since one scandal can separate GOAT from LEGEND."
      },
      {
        q: "Can I play for the club I came through as a youth player?",
        a: "Yes. The senior side of your academy club always puts a contract on the table when you turn pro, usually on slightly lower wages because they know you would sign for free. Staying gives you a popularity and morale boost and unlocks the homegrown legend storylines. From 27 they can also call you back for a homecoming transfer."
      },
      {
        q: "What is corruption mode and can it end my career?",
        a: "It is the dirty half of the game and yes, it absolutely can. Taking envelopes from a betting syndicate, paying a referee's brother in law, buying Ballon d'Or votes, or laundering cash through your own nightclub all raise a hidden heat meter. Stay hot too long and you get raided, then convicted, then you serve a season in prison while your stats rot. There is always a way out: confess, take the tax amnesty, or just stop, and heat cools every clean season."
      },
      {
        q: "Is this a football career sim game or a management game?",
        a: "A career sim first: you steer one player's life and story, not tactics. The manager and owner modes afterward add a taste of the other side."
      }
    ]
  },
  "/fantasy-draft": {
    intro: [
      "You and an AI rival take turns raiding one player pool until you have each drafted a full XI. Then a season is simulated, both squads get dissected, and the community votes on who built better.",
      "The wrinkle is the daily criteria: one squad building rule per day, and it is enforced, not decorative. Picks that break it are blocked for you and the AI alike."
    ],
    headings: {
      howToPlay: "How to play Fantasy Draft, a free online soccer draft game",
      rules: "Fantasy Draft rules: the shared pool, daily criteria and voting",
      example: "Fantasy Draft walkthrough: an Under 25s rule and a keeper steal",
      tips: "Fantasy Draft tips for outdrafting the AI rival",
      faq: "Fantasy Draft FAQ: criteria, voting and legal picks"
    },
    howToPlaySections: [
      {
        heading: "Reading today's squad building criteria",
        items: [
          "Read today's criteria first. It shapes the whole draft."
        ]
      },
      {
        heading: "Drafting snake style against the AI",
        items: [
          "Draft snake style: 22 alternating picks, with a coin flip deciding who starts."
        ]
      },
      {
        heading: "Covering every position on the pitch",
        items: [
          "Cover every position, goalkeeper included."
        ]
      },
      {
        heading: "Simulating the season and voting on the winner",
        items: [
          "At 11 apiece, hit Simulate Season for the story of each team's year.",
          "Read the strengths and weaknesses report, then vote for the winner."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "One shared pool for both drafters",
        items: [
          "Both sides draft 11 players from one shared pool, so a taken player is gone for both."
        ]
      },
      {
        heading: "The daily criteria's exact numbers",
        items: [
          "Rules come with exact numbers: Under 25s, a 1 billion pound squad cap, One Nation (max 3 per country), Bargain Hunt (60 million or less each), Wonderkids (outfielders 21 or under), or Galacticos (outfielders 80 million plus)."
        ]
      },
      {
        heading: "Blocked picks are relaxed automatically",
        items: [
          "Illegal picks are blocked with the reason shown, relaxing only when no legal option remains."
        ],
        subsections: [
          {
            heading: "Signing in before you vote",
            items: [
              "Voting requires signing in, so nobody stuffs the ballot."
            ]
          }
        ]
      }
    ],
    exampleSections: [
      {
        heading: "An Under 25s rule blocks your opening pick",
        paragraphs: [
          "The rule is Under 25s, so your 27 year old superstar opener dies on contact: blocked. Round one becomes a wonderkid land grab, and the AI, which leans expensive, snaps up the priciest young forward on the board."
        ]
      },
      {
        heading: "Grabbing a keeper late while the AI stalls",
        paragraphs: [
          "You counter with a young keeper, because the AI leaves goalkeepers late. By pick 22 both rosters are packed with kids, and the vote breaks your way."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Drafting against what the AI values",
        items: [
          "Draft against the AI's taste: it chases market value, so grab the cheap positional glue it ignores."
        ]
      },
      {
        heading: "Spreading money under a budget cap",
        items: [
          "Under a budget cap, one megastar eats a third of your money. Spread it."
        ]
      },
      {
        heading: "Scarcity, speed and keeping a shortlist ready",
        items: [
          "Scarcity beats stardom mid draft. Two keepers left is a pick, not a luxury.",
          "The AI picks in about 2 seconds, so keep a shortlist ready for every position."
        ]
      }
    ],
    faqs: [
      {
        q: "Who decides the winner?",
        a: "The community. After the season stories and analysis, players vote for the squad they rate higher, and the totals are shown. One vote per signed in account."
      },
      {
        q: "Does the criteria change?",
        a: "Yes, a fresh rule arrives each day, spanning age caps, budget caps, price floors, and nationality limits. Both sides live under it."
      },
      {
        q: "Can the AI cheat the rule?",
        a: "No, its picks pass the same legality check as yours. It relaxes for either side only when the pool has no legal option left, so every draft can finish."
      }
    ]
  },
  "/transfer-path": {
    intro: [
      "Two players sit at opposite ends of a chain, and you link them through shared dressing rooms. It is six degrees of separation for football.",
      "The catch: teammates means actual teammates. Two stars who wore the same shirt years apart do not count. Every link needs the same club in the same season."
    ],
    headings: {
      howToPlay: "How to play Transfer Path, a free daily soccer chain puzzle",
      rules: "Transfer Path rules: valid links, scoring and special rules",
      example: "Transfer Path walkthrough: Gerrard to Messi through Luis Suarez",
      tips: "Transfer Path tips for chaining teammates fast",
      faq: "Transfer Path FAQ: rejected links, hints and scoring"
    },
    howToPlaySections: [
      {
        heading: "Reading the start, target and optimal steps",
        items: [
          "Check the start player, the target, and the optimal step count on the card."
        ]
      },
      {
        heading: "Typing teammates to build the chain",
        items: [
          "Type a player who was a club teammate of the start player. Real links join the chain with the shared club labeled."
        ]
      },
      {
        heading: "Connecting to your chain's most recent name",
        items: [
          "Keep connecting to the most recent name in your chain."
        ]
      },
      {
        heading: "Reaching the target and closing the chain",
        items: [
          "Reach the target to win. If a new player also links to the target, the chain closes automatically."
        ]
      },
      {
        heading: "Taking a hint or giving up",
        items: [
          "Stuck? Take the hint, or give up to see a full working path."
        ],
        subsections: [
          {
            heading: "Picking a special rule for a harder chain",
            items: [
              "Want it harder? Pick a special rule above the card: Active players only, or Europe only. The optimal on the card changes with the rule."
            ]
          }
        ]
      }
    ],
    ruleSections: [
      {
        heading: "What counts as a valid club link",
        items: [
          "A valid link is the same club in the same season, not the same club ever."
        ]
      },
      {
        heading: "Scoring from 1000 down to a floor of zero",
        items: [
          "Scoring starts at 1000 for the optimal path and drops 100 per extra step, with a floor of 0."
        ]
      },
      {
        heading: "Free retries and the daily versus unlimited puzzle",
        items: [
          "Invalid names cost nothing. No attempt limit, no timer.",
          "One shared daily puzzle, plus unlimited practice puzzles."
        ]
      },
      {
        heading: "How the special rules change your optimal",
        items: [
          "Active players only: every name in the chain, the start and the target included, is in our verified 2026 active-player records. Europe only: every club a link goes through is a European club. Each rule has its own optimal, worked out on the players that rule leaves in play."
        ],
        subsections: [
          {
            heading: "When the harder rule reaches the daily puzzle",
            items: [
              "A special rule reaches the daily only when today's pair has a route under it; otherwise the daily plays the everyday rule and the rule waits for you in unlimited. The daily score still counts steps against the everyday optimal, so a rule is a harder road to the same finish line. Unlimited scores against the rule's own optimal."
            ]
          }
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Gerrard to Messi through Luis Suarez",
        paragraphs: [
          "Say it is Steven Gerrard to Lionel Messi, optimal in 2 steps. Gerrard played with Luis Suarez at Liverpool, and Suarez spent years beside Messi at Barcelona, so you type Suarez and the chain autocompletes for the full 1000."
        ]
      },
      {
        heading: "A longer chain still wins at a lower score",
        paragraphs: [
          "Wander through four or five names instead and you still win, just at 800 or 700. The share line shows your steps against the optimal."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Thinking in well traveled player hubs",
        items: [
          "Think in well traveled hubs: serial movers like Zlatan Ibrahimovic connect whole leagues by themselves."
        ]
      },
      {
        heading: "Working backwards to meet in the middle",
        items: [
          "Work backwards from the target too. Meeting in the middle beats a blind march."
        ]
      },
      {
        heading: "Matching eras and testing free hunches",
        items: [
          "Match eras before clubs. A clever link fails if the careers never overlapped there.",
          "Wrong attempts are free, so test hunches instead of agonizing."
        ]
      }
    ],
    faqs: [
      {
        q: "Why was my link rejected when both played for the same club?",
        a: "Timing. Cristiano Ronaldo and Kylian Mbappe both wore Real Madrid white, but six years apart, so they never link."
      },
      {
        q: "What happens if I give up?",
        a: "You see a real shortest path through the player pool, and a surrendered daily still counts as played for the day."
      },
      {
        q: "How is it scored?",
        a: "1000 points for matching the optimal step count shown up front, minus 100 for each extra step your chain took."
      },
      {
        q: "Why does a name get refused under a special rule when the two really were teammates?",
        a: "Because the rule removed it. With Active players on, anyone outside the verified 2026 active-player records is off the board. With Europe only enabled, a season shared at a club outside Europe does not count as a link. The refusal says which rule got in the way."
      }
    ]
  },
  "/squad-deal": {
    intro: [
      "Squad Deal crosses building an XI with a blind box gamble. Every position is a wall of mystery boxes, you claim one blind, and a banker keeps ringing with tempting named alternatives.",
      "You never quite know what you are holding until it is too late, which is the point. The finished squad gets simulated, graded, and logged on a leaderboard saved to your device."
    ],
    headings: {
      howToPlay: "How to play Squad Deal, a free online soccer box opening game",
      rules: "Squad Deal rules: box odds, chemistry and the letter grades",
      example: "Squad Deal walkthrough: a Traffic Cone and a Premier League B",
      tips: "Squad Deal tips for reading the banker's offers",
      faq: "Squad Deal FAQ: grading, extras and your leaderboard"
    },
    howToPlaySections: [
      {
        heading: "Setting up your theme, formation and modes",
        items: [
          "Set up: Current Stars or All-Time Legends, an optional theme like Premier League only, one of 9 formations, and whether meme players can lurk in the boxes."
        ]
      },
      {
        heading: "Picking a hidden box for each position",
        items: [
          "Tap a position, face up to 10 hidden players, and keep one box sight unseen."
        ]
      },
      {
        heading: "Opening rounds and the banker's offers",
        items: [
          "Open the rest in short rounds. Between rounds the banker offers a named player: accept to fill the slot or keep opening."
        ]
      },
      {
        heading: "Finishing slots and simulating for a grade",
        items: [
          "Refuse everything and you finish the slot from the last unopened boxes.",
          "After the XI, play the 5 extras, then simulate for your grade."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "How boxes are seeded top to bottom",
        items: [
          "Boxes are seeded stars to scrubs: on a full board of 10, a couple come from the top of the pool and a couple from the bottom."
        ]
      },
      {
        heading: "How the banker sweetens later rounds",
        items: [
          "Offers strengthen in later rounds, roughly 1 in 4 is a sweetener near the best player left, and the banker never repeats an offer."
        ]
      },
      {
        heading: "Final rating and the letter grades",
        items: [
          "Final rating: players 82 percent, chemistry 18 percent, plus extras. Chemistry counts shared clubs and nationalities."
        ],
        subsections: [
          {
            heading: "The grade cutoffs from A+ to D",
            items: [
              "Grades: 84 and up is A+, 76 is A, 66 is B, 55 is C, below that D."
            ]
          }
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Declining the banker's mid 80s offer at striker",
        paragraphs: [
          "At striker you keep box 4. Two scrubs and a star flip out, the banker offers a solid mid 80s name, and you decline. Next round burns another elite option, and his follow up is weaker, because the field left in play got worse."
        ]
      },
      {
        heading: "The Traffic Cone lands but chemistry saves the grade",
        paragraphs: [
          "You ride it to the end and out comes The Traffic Cone. Your all Premier League chemistry still drags the sim to a B, logged with formation and date."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Judging the banker against what remains",
        items: [
          "Judge the banker against what is left, not what is gone. His offer tracks the unopened average."
        ]
      },
      {
        heading: "Taking early offers at thin positions",
        items: [
          "Take early offers at thin positions like goalkeeper. Deep positions can afford greed."
        ]
      },
      {
        heading: "Legends mode safety and Meme mode chaos",
        items: [
          "In Legends mode every box holds an all time great, so gambling to the last box is far safer.",
          "Meme mode is chaos on purpose: a few joke players are secretly elite, most are Sunday league."
        ]
      }
    ],
    faqs: [
      {
        q: "How does grading work?",
        a: "The sim averages your XI's ratings, blends chemistry, applies extras, and the letter falls out of the number: A+ needs 84, under 55 is a D."
      },
      {
        q: "What are the extras?",
        a: "Five mini deal boards: Manager, Stadium, Fan Base, Transfer Budget, and Home Kit, each with 6 options carrying rating and chemistry modifiers. Keep a case, watch 3 flip, then deal, stay, or swap."
      },
      {
        q: "Where does my score go?",
        a: "A leaderboard on your device logs each run's grade, rating, formation, and era. No account needed."
      }
    ]
  },
  "/player-stock-market": {
    intro: [
      "The Player Stock Market is the anonymous portfolio game: the market opens in a real past season, hands you 200M, and asks you to fill the 4-3-3's eleven slots on nothing but the numbers.",
      "Every card is anonymous while you shop. You see the position, the age, and that season's matches, goals, assists and cards, plus the price, which is the player's real market value that year. Never a name, a country or a club, because knowing who a player is would be the whole answer.",
      "When the XI is full the years roll forward one at a time to the latest season, every holding moves as it really moved, and only then do the cards turn over. Every number on every screen is real market history."
    ],
    headings: {
      howToPlay: "How to play Player Stock Market, a free soccer investing game",
      rules: "Player Stock Market rules: the wallet, scoring and missing rows",
      example: "Player Stock Market walkthrough: a cheap card outgrows a star",
      tips: "Player Stock Market tips for reading age over the name",
      faq: "Player Stock Market FAQ: real prices, seasons and going broke"
    },
    howToPlaySections: [
      {
        heading: "Choosing the daily market or an unlimited season",
        items: [
          "Pick the daily market (the same season and the same cards for everyone today) or unlimited, where you choose the season the market opens in, 2015 to 2022, or let it roll one."
        ]
      },
      {
        heading: "Buying anonymous cards to fill your XI",
        items: [
          "Fill the XI position by position. Each slot deals four anonymous cards from the opening season, from an expensive bet to a cheap punt. Read the age, the matches and the output, then buy exactly one at its real price."
        ]
      },
      {
        heading: "How the wallet reserves money for later slots",
        items: [
          "The wallet always reserves enough for the remaining slots' punts, so a run can never strand you."
        ]
      },
      {
        heading: "Stepping through the seasons after your buys",
        items: [
          "After the eleventh buy, step through the seasons one at a time. Each step shows what every holding is worth that year against what it was, and says plainly when a player has no row for a year rather than making one up."
        ],
        subsections: [
          {
            heading: "Reaching the reveal and your final score",
            items: [
              "At the end the reveal names all eleven, prices the portfolio at the latest season's real values, and scores the run."
            ]
          }
        ]
      }
    ],
    ruleSections: [
      {
        heading: "The 200M wallet and real market prices",
        items: [
          "The wallet is 200M for the whole XI, and prices are real market values from the opening season."
        ]
      },
      {
        heading: "Why every card's career reaches the latest season",
        items: [
          "Cards come only from careers the data tracks through to the latest season, stated here on purpose: you are choosing among players whose story the table can finish, and a value can still crater."
        ]
      },
      {
        heading: "How each slot's four cards span the market",
        items: [
          "A slot's four cards always span the market: one from the top of that season's range, two from the middle, and a punt the wallet can always cover. They are dealt in a shuffled order, so the price band cannot be read off where a card sits."
        ]
      },
      {
        heading: "Scoring your return between the worst and best XI",
        items: [
          "Scoring is the return on the whole 200M. What your eleven are worth at the end is placed between the worst and the best eleven that the same 200M could really have bought from the same cards, so 100 means you played the wallet perfectly and 0 means you could not have done worse with it."
        ]
      },
      {
        heading: "Empty wallets and missing season rows",
        items: [
          "Money you never spend buys nothing. Sitting on the wallet is not a safe play, it is a low score, because the cash you kept could have been eleven careers instead.",
          "A season with no row for a player is shown as exactly that. Nothing is ever filled in between two real values."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Choosing a 21 year old over a 29 year old striker",
        paragraphs: [
          "The market opens in 2018, the striker slot. One card reads age 21, 34 matches, 14 goals, 6 assists, 24M. Another reads age 29, 41 matches, 22 goals, 5 assists, 60M. The kid costs less than half; you take the age and the rate."
        ]
      },
      {
        heading: "The cheap card climbs past the expensive one",
        paragraphs: [
          "You step through 2019, 2020 and on, watching the 24M card climb past the 60M one, and the reveal says the kid became a superstar worth several times what you paid. The portfolio closes well over 200M and the score lands in the eighties."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Reading age as the loudest number",
        items: [
          "Age is the loudest number on the card. A 21 year old with real minutes is the market telling you where it is going; a 31 year old at 60M is a value with mostly one direction left."
        ]
      },
      {
        heading: "Judging the rate, not the raw count",
        items: [
          "Read the rate, not the raw count. Ten goals in 20 matches beats fourteen in 40."
        ]
      },
      {
        heading: "Spending the wallet on purpose",
        items: [
          "Spend the wallet, but spend it on purpose. A 60M splash is ten cheap seats later, and eleven punts is a portfolio that barely moves. The reserve rule keeps you solvent either way."
        ]
      },
      {
        heading: "Keepers, defenders and guessing a name",
        items: [
          "Keepers and defenders show few goals, so age and matches are their story.",
          "Yes, a fan might guess who the 130M card is. The game is won on the cheap seats, where age and the rate are the only edge you have."
        ]
      }
    ],
    faqs: [
      { q: "Are the numbers real?", a: "Yes, every price, stat and season value is a real row from the market value history the rest of the site runs on. Nothing is authored, and a season with no row says so." },
      { q: "Why can I never see the names while buying?", a: "That is the game. Knowing the name would be the answer; the format is investing on stats alone, and the reveal at the end names everyone." },
      { q: "Which seasons can the market open in?", a: "2015 to 2022. Earlier seasons do not carry enough players the data still tracks today to give real choice at every position, and a later start would be too short a story to roll through." },
      { q: "Can I go bankrupt mid draft?", a: "No. Every slot always deals a punt the wallet can cover, and the buy button reserves the future punts' prices before letting you splash." }
    ]
  },
  "/search-and-discard": {
    intro: [
      "Search and Discard is the squad building duel: two managers, one shared pool of real footballers, both filling the same 4-3-3. On your turn you search three players, keep exactly one, and the other two are discarded from the whole game.",
      "That discard is the heart of it. A striker you bin can never reach the other squad, so every search is two decisions at once: who makes your XI, and who you refuse to let make theirs.",
      "When both XIs are full, the arguing stops and a simulated 38 game season settles it, derbies included. Play the CPU or pass one screen between two people."
    ],
    headings: {
      howToPlay: "How to play Search and Discard, a free soccer squad building duel",
      rules: "Search and Discard rules: positions, discards and season scoring",
      example: "Search and Discard walkthrough: a scarce keeper wins the duel",
      tips: "Search and Discard tips for guarding scarce positions",
      faq: "Search and Discard FAQ: multiplayer, ratings and repeat picks"
    },
    howToPlaySections: [
      {
        heading: "Picking the CPU or a second player",
        items: [
          "Pick your opponent: the CPU, or a second person on the same screen."
        ]
      },
      {
        heading: "Seeing three real players on your turn",
        items: [
          "On your turn, three real players appear. At least one always fits an open slot in your 4-3-3."
        ]
      },
      {
        heading: "Keeping one player and binning the rest",
        items: [
          "Tap the one you keep, then tap the slot he plays. The other two are binned for good, for both squads."
        ]
      },
      {
        heading: "Alternating turns until the season decides",
        items: [
          "Eleven keeps each, alternating turns. Then both XIs play the same simulated season and the table decides."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Building an identical formation from one pool",
        items: [
          "Both managers build the identical 4-3-3 from one shared pool, real players and real market values throughout."
        ]
      },
      {
        heading: "Which nearby positions each slot accepts",
        items: [
          "Position rules use the sitewide families: wingers cover both flanks, central mids cover the holding and attacking slots, a keeper is only ever a keeper."
        ]
      },
      {
        heading: "Discarding a player out of the entire game",
        items: [
          "A discarded player is out of the entire game. He cannot be searched again by either side."
        ]
      },
      {
        heading: "A deterministic settle decides the season",
        items: [
          "The settle is deterministic: the same two finished XIs always produce the same season, so the draft is the game."
        ],
        subsections: [
          {
            heading: "How your season score is worked out",
            items: [
              "Season scoring: 36 league games against a spread of opposition plus two head to head derbies, 3 points a win, 1 a draw. Your season score is your points as a share of the 114 available."
            ]
          }
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Taking the scarce keeper over the tempting winger",
        paragraphs: [
          "Your search deals an 89 rated winger, an 84 keeper and a 76 full back, with your goalkeeper slot still open. Keeping the winger is tempting, but keepers are scarce in a shrinking pool, so you take the 84 and bin the other two, and the 89 winger is gone from the duel entirely."
        ]
      },
      {
        heading: "A four point season win between two full squads",
        paragraphs: [
          "Ten turns later both squads stand at 11. Yours rates 82, theirs 80, the derbies split, and your side edges the season by four points."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Guarding the scarcest positions early",
        items: [
          "Guard the scarce slots. Keepers and centre backs dry up fastest in a shared pool; a late empty GK slot is a disaster."
        ]
      },
      {
        heading: "Binning with intent late in the draft",
        items: [
          "Bin with intent. When your slots are nearly full, the keep matters less than which star you deny the other side."
        ]
      },
      {
        heading: "Why real market value drives the ratings",
        items: [
          "Ratings follow real market value with an age correction, so a famous veteran is often worth more than his price tag suggests."
        ]
      }
    ],
    faqs: [
      { q: "Can both squads end up with the same player?", a: "No. A kept player is off the pool, and a discarded player is out of the whole game, so the two XIs never overlap." },
      { q: "Is the season a coin flip?", a: "No. Win chances follow the rating gap game by game, and the same two squads always settle the same way. Better drafts win more, but a two point rating edge is an edge, not a guarantee." },
      { q: "Is there online multiplayer?", a: "Not yet. Online rooms need real backend work, so today it is the CPU or two people passing one screen." }
    ]
  },
  "/free-kick": {
    intro: [
      "Every other game here asks you a question. This one asks you to hit it. Ten free kicks, a wall that grows, and a keeper who leans one way before you strike.",
      "Aim across the goal, bend it with the inside or the outside, and stop the power bar where you dare. Smash it and it sprays. Roll it and he reaches it. The corners are the only safe place and they are the hardest to find.",
      "Shot lab keeps the same distance, wall and keeper while you work on a kick. Set aim, power and bend, then retry with your settings still in place. Identical settings repeat exactly, so changing one setting shows what it did to the actual flight. Compare your latest two kicks, or change setup for a fresh wall and keeper. A shot stopped by the wall has no goal crossing to compare. The lab earns no points and saves no records."
    ],
    headings: {
      howToPlay: "How to play Free Kick, a free online soccer shooting game",
      rules: "Free Kick rules: power, accuracy and how goals are scored",
      example: "Free Kick walkthrough: bending a shot past a four man wall",
      tips: "Free Kick tips for reading the keeper and the power bar",
      faq: "Free Kick FAQ: the daily run, aiming and missed corners"
    },
    howToPlaySections: [
      {
        heading: "Aiming with the keys or by dragging",
        items: [
          "Aim with the arrow keys, or drag the pitch with a finger or the mouse."
        ]
      },
      {
        heading: "Bending the flight with Q and E",
        items: [
          "Q and E bend the flight. The slower you hit it, the more it bends."
        ]
      },
      {
        heading: "Charging and releasing the power bar",
        items: [
          "Hold space, or hold the strike button, to charge. The power bar sweeps up and down and you get the number you let go on."
        ]
      },
      {
        heading: "Ten kicks that get harder as you go",
        items: [
          "Ten kicks a run, each one further out than the last, with more defenders in the wall and a better keeper."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Trading power against accuracy",
        items: [
          "Power beats the keeper but costs accuracy, and the cost grows faster than the power does, so a full blooded strike misses far more than it scores."
        ]
      },
      {
        heading: "Lifting the ball past the wall",
        items: [
          "The wall only blocks what stays low. Lift it and the wall is irrelevant, but the keeper is not."
        ]
      },
      {
        heading: "How goals are scored by distance and corner",
        items: [
          "Goals pay by distance, by the size of the wall you beat and by how close to the corner you finished. A tap into the middle pays least."
        ],
        subsections: [
          {
            heading: "Daily kicks versus unlimited practice",
            items: [
              "The daily deals the same ten kicks to everyone and keeps your score for the day. Unlimited deals fresh ones for ever."
            ]
          }
        ]
      }
    ],
    exampleSections: [
      {
        heading: "An open penalty rewards a corner, not power",
        paragraphs: [
          "Kick one is a penalty with nobody in the wall. The temptation is to smash it; the points are in rolling it into a corner where the keeper is not."
        ]
      },
      {
        heading: "Lifting and bending past a four man wall",
        paragraphs: [
          "Kick seven is twenty metres out with four in the wall and the keeper leaning right. Lift it over the wall, bend it back toward the left post, and take about two thirds power so the bend still has time to work."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Reading which way the keeper leans",
        items: [
          "Watch the keeper before you strike. He is already leaning, and the far side is the side he left you."
        ]
      },
      {
        heading: "Why two thirds power is the best trade",
        items: [
          "Two thirds power is usually the best trade: enough to reach from distance, slow enough to bend and straight enough to land where you aimed."
        ]
      },
      {
        heading: "Beating a big wall with height and width",
        items: [
          "Height beats the wall, width beats the keeper. From distance with a big wall you need both, which is why those kicks pay the most."
        ]
      }
    ],
    faqs: [
      { q: "Is the daily the same for everyone?", a: "Yes. The ten kicks come from the date, so every player gets the same run, and your score is kept for the day." },
      { q: "Do I need a keyboard?", a: "No. Drag the pitch to aim and let go to strike, which works the same on a phone." },
      { q: "Why did my perfect corner go wide?", a: "Because of how hard you hit it. Power sprays the ball off the spot you picked, and near the post there is no room to spray into." }
    ]
  },
  "/contract-chaos": {
    intro: [
      "Contract Chaos is a free soccer agent game. Your client's contract is up, his club wants him back, other clubs want him away, and you decide where he signs.",
      "The offers pull against each other on purpose: the title chasers pay less and bench more, the rebuilds pay more and promise the shirt, and a release clause can turn a small club into a stepping stone. Then five seasons play out and show whether you got it right.",
      "Every player and every club is generated. The offers run on the same contract market as the free agency window in the site's career games."
    ],
    headings: {
      howToPlay: "How to play Contract Chaos, a free soccer agent game",
      rules: "Contract Chaos rules for offers, pushes and scoring",
      example: "Contract Chaos walkthrough: one wonderkid, three offers",
      tips: "Contract Chaos tips for picking the right deal",
      faq: "Contract Chaos FAQ: generated players, the daily and scores"
    },
    howToPlaySections: [
      {
        heading: "Opening the daily deal or free play",
        items: ["Open today's offers or deal yourself a client in free play."]
      },
      {
        heading: "Reading your client's card",
        items: ["Read your client first: his age, his rating, his potential and what he is worth a year."]
      },
      {
        heading: "Comparing offers one tile at a time",
        items: ["Tap each offer to read the full terms, then use the back button to compare the next one."],
        subsections: [
          { heading: "Pushing for a better wage", items: ["Push any offer for more money once, if you think he has the leverage."] }
        ]
      },
      {
        heading: "Signing and playing five seasons",
        items: ["Sign one deal and play the five seasons one at a time, or skip straight to the verdict."]
      }
    ],
    ruleSections: [
      {
        heading: "What every offer on the table carries",
        items: ["Every offer shows the wage, the length, a signing bonus, a trophy bonus, a release clause if there is one, the promised role, how safe the manager is, home or abroad, the size of the city and how ambitious the club is."]
      },
      {
        heading: "How each kind of club pays",
        items: ["Title chasers pay below his market value, top half clubs pay about the market and rebuilds pay above it.", "A rebuild always promises the starting spot, while a title chaser's bench is crowded."]
      },
      {
        heading: "Negotiation and walkouts",
        items: ["A push works more often for a highly rated player and less often for a veteran past his peak.", "A failed push can make an outside club walk away, but your own club never walks and the last offer on the table never walks."]
      },
      {
        heading: "Promises, sackings and settling abroad",
        items: ["The promised role holds only while the manager who signed him keeps his job, and a hot seat manager is sacked half the time.", "Moving abroad costs a few games in the first season while he settles in."]
      },
      {
        heading: "Release clauses and expiring deals",
        items: ["If he outgrows his club and his contract has a release clause, a title chaser can pay it and take him.", "Every career is judged over five seasons. If his deal ends sooner he signs on somewhere at whatever he is worth by then."]
      },
      {
        heading: "Scoring out of 100",
        items: ["The score is out of 100: 30 for growth, 25 for minutes, 25 for trophies and 20 for money."],
        subsections: [
          { heading: "Growth measured against age", items: ["Growth is judged against his age, so a kid is measured on how close he got to his potential and a veteran on how well he held off the decline."] },
          { heading: "When a medal counts", items: ["A trophy only counts if he played at least a fifth of the minutes that season."] }
        ]
      },
      {
        heading: "Streaks, points and generated names",
        items: ["Plays count toward your streak and your games played, but there is no leaderboard score for this game yet.", "Every player and every club in the game is made up."]
      }
    ],
    exampleSections: [
      {
        heading: "Meeting a nineteen year old winger",
        paragraphs: ["Today's client is a 19 year old winger rated 74 with a potential of 88, worth about \u20AC1.6M a year."]
      },
      {
        heading: "Three offers side by side",
        paragraphs: ["His club offers \u20AC1.4M for three years. A title chaser offers \u20AC1.3M for two years as a rotation player at a squad strength of 91. A rebuild offers \u20AC1.9M for four years, the starting spot and a \u20AC1.1M signing bonus."]
      },
      {
        heading: "The push and the release clause",
        paragraphs: ["You push the rebuild and they come up to \u20AC2.1M. You sign. He plays nearly every minute, climbs to 84 by his third season, and a title chaser pays his release clause to take him on a much bigger wage."]
      },
      {
        heading: "The verdict five seasons on",
        paragraphs: ["Five seasons later he is rated 87 with a league title, about \u20AC26M earned and a score of 83, a Great call. The roads not taken show his old club would have scored far less."]
      }
    ],
    tipSections: [
      {
        heading: "Minutes before badges for a kid",
        items: ["For a young player, minutes matter more than the badge on the shirt. A kid on the bench at a giant grows slower than a kid starting every week."]
      },
      {
        heading: "Money and minutes for a veteran",
        items: ["For a veteran, the money and the minutes are most of the score, because growth is mostly about slowing the decline."]
      },
      {
        heading: "Treating the clause as upside",
        items: ["A release clause is upside, not a risk. If he outgrows the club, it is his ticket to a bigger one."]
      },
      {
        heading: "Reading the manager's seat",
        items: ["Check the manager's seat before you trust a promised role. A hot seat promise can be gone by season two."]
      },
      {
        heading: "Choosing which offer to push",
        items: ["Push the offers you would be happy to lose, and think twice before pushing the one you want."]
      },
      {
        heading: "Short contracts as a growth bet",
        items: ["Short deals are a bet on growth. If he improves, the next contract pays for it; if he gets hurt, it does not."]
      }
    ],
    faqs: [
      { q: "Are the players and clubs real?", a: "No. Every player and club is generated, so no real footballer's contract is being guessed at." },
      { q: "Why is there no leaderboard score?", a: "Plays are recorded without a score while the site's points are rebuilt. Your best and average are kept on this device." },
      { q: "Is the daily the same for everyone?", a: "Yes. Same client, same offers, same push results and the same five seasons for the same choice. You get one signature a day." },
      { q: "Can I see what would have happened with another offer?", a: "Yes. The verdict screen plays every offer out over the same five seasons and ranks them, with yours marked." },
      { q: "Why did my promised starting spot disappear?", a: "The manager who promised it got sacked. The new manager picks on form and rating, not on promises he never made." }
    ]
  }
};

// src/data/gameContent/football.ts
var FOOTBALL_CONTENT = {
  "/perfect-season-nfl": {
    intro: [
      "Spin a wheel of real pro football team seasons from 1999 to 2024, draft one player wherever it lands, and build a cross-era offense the sim then runs through a 17 game season.",
      "The fun is the mash-up: a 2007 Randy Moss catching passes from a 2013 Peyton Manning, rated on what each actually did that exact year."
    ],
    headings: {
      howToPlay: "How to play 17-0 NFL Perfect Season, a free online football draft simulator",
      rules: "17-0 NFL Perfect Season rules: eras, ratings and the playoff push",
      example: "17-0 NFL Perfect Season walkthrough: a cross era draft and a 15 win season",
      tips: "17-0 NFL Perfect Season tips for building a stacked roster",
      faq: "17-0 NFL Perfect Season FAQ: daily mode, eras and the playoffs"
    },
    howToPlaySections: [
      {
        heading: "Choosing Classic, Hard or Daily mode",
        items: [
          "Pick a mode. Classic shows ratings, Hard hides them until the sim ends, Daily gives everyone the same wheel once a day."
        ]
      },
      {
        heading: "Spinning the wheel for a team season",
        items: [
          "Spin. The wheel stops on a real team season and lists that squad's draftable players."
        ]
      },
      {
        heading: "Filling your eight roster slots",
        items: [
          "Draft one player into an open slot. You fill 8: QB, RB, two receivers, tight end, flex, defense unit, head coach."
        ],
        subsections: [
          {
            heading: "Using your two rerolls on a dud squad",
            items: [
              "Repeat until the roster is full. No name repeats, and you get 2 rerolls per run for dud squads."
            ]
          }
        ]
      },
      {
        heading: "Watching the season sim and sharing it",
        items: [
          "Watch the 17 game sim reveal, then share the result or run it back."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "The wheel's full era span",
        items: [
          "The wheel spans 1999 through 2024. Decade Mode can pin Classic and Hard runs to the 2000s, 2010s, or 2020s."
        ]
      },
      {
        heading: "How ratings come from real stats",
        items: [
          "Ratings run 40 to 99, built from real per game stats with an era adjustment."
        ]
      },
      {
        heading: "Reaching the playoffs at 12 wins",
        items: [
          "Win 12 or more games to enter the playoffs: Wild Card, Divisional Round, Conference Championship, Super Bowl."
        ]
      },
      {
        heading: "Daily mode and the midnight reset",
        items: [
          "Daily is one attempt that locks when the result lands. A fresh themed wheel arrives at midnight Eastern."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "A cross era draft comes together",
        paragraphs: [
          "Your first spin lands on the 2007 Patriots, so you grab Randy Moss. Later the 2013 Broncos deliver Peyton Manning, and a reroll digs up an elite defense for the last slot."
        ]
      },
      {
        heading: "The finished squad's 15 win season",
        paragraphs: [
          "The finished 87 overall squad, better than nine drafts in ten, starts 9 and 0, drops one game by a field goal, and lands at 15-2. Division winner, playoff run, no banner. At 87 a 17-0 comes about one run in 25, so you spin again."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Spending big at the quarterback slot",
        items: [
          "Spend big on quarterback. That slot is weighted heaviest in your team overall."
        ]
      },
      {
        heading: "Not punting on defense and coach",
        items: [
          "Do not punt on defense and coach. A bad sideline drags every Sunday down."
        ]
      },
      {
        heading: "Treating 15 wins as a great run",
        items: [
          "A typical well drafted roster, around 82, goes 17-0 about one run in 1,100, and even an 88 only about one run in 14, so treat 15 wins as a good day."
        ]
      }
    ],
    faqs: [
      {
        q: "What seasons can the wheel land on?",
        a: "Real team seasons from 1999 through 2024, with era-correct names like the San Diego Chargers."
      },
      {
        q: "What happens after the regular season?",
        a: "Reach 12 wins and the sim plays four playoff rounds. Win them all for a banner and a Super Bowl MVP named from your roster."
      },
      {
        q: "How is Hard mode different?",
        a: "Ratings show as question marks until the sim ends, so you draft on reputation alone."
      }
    ]
  },
  "/front-office": {
    intro: [
      "Somebody has to make the hard calls, and here that somebody is you. Take over any of the 32 clubs and run it all: the cap, free agency, trades, the draft.",
      "The league moves around you: rivals sign players, stars get hurt in December, dynasties get built one contract at a time."
    ],
    headings: {
      howToPlay: "How to play NFL Front Office, a free online NFL GM simulation game",
      rules: "NFL Front Office rules: the cap, the mandate and the draft",
      example: "NFL Front Office walkthrough: a rebuild that reaches the one seed",
      tips: "NFL Front Office tips for building a roster that contends",
      faq: "NFL Front Office FAQ: trades, firing and real rosters"
    },
    howToPlaySections: [
      {
        heading: "Picking a franchise under the salary cap",
        items: [
          "Pick a franchise and you get the whole club: every man on its real 53 (kickers, punters and long snappers sit out for now) plus its practice squad. Every player carries a fictional contract, and all 53 fit under a 301.2 million dollar cap that rises 5 percent each season."
        ]
      },
      {
        heading: "Reading your ownership mandate",
        items: [
          "Read the ownership mandate. A loaded roster is told to win the Super Bowl, a mid one to make the playoffs, a bare one to hit an honest win number. It resets every offseason from where your roster really stands."
        ]
      },
      {
        heading: "Shaping the roster with cuts, signings and trades",
        items: [
          "Shape the roster: cut bloated deals, sign free agents, and take trades to the phone: the other GM counters like a person, asking for a pick, offering a lesser man, or hanging up."
        ],
        subsections: [
          {
            heading: "Playing weeks with a live pace read",
            items: [
              "Play week by week as scores, injuries, and rival moves roll in, with a live read on whether you are on pace for the mandate."
            ]
          }
        ]
      },
      {
        heading: "Setting the depth chart from the roster",
        items: [
          "Open the depth chart from the Roster box: 8 position groups (QB, RB, WR, TE, OL, DL, LB, DB), each in the order the sim reads. Tap a man, then tap the one to swap him with. The men marked starts are the ones team strength counts, so benching a better man costs you and promoting a hidden gem pays. Injured men are skipped and the next man steps up. Anyone who joins later (a signing, a pick, a trade) slots in by his rating, so a better newcomer starts right away, and Sort by rating hands a group back to the sim."
        ]
      },
      {
        heading: "Working a 53 man roster and the practice squad",
        items: [
          "The Roster box opens on one tile per position group plus one for the practice squad, so fifty men never turn into one long list. The men at the top of each group's depth chart start, the bench steps in when a starter gets hurt, and the practice squad sits off the cap until you call a man up. A call-up needs a roster spot and room for his displayed fictional salary, including dead money. The roster holds 53: at the limit you cut or trade before you can sign anybody."
        ]
      },
      {
        heading: "Drafting rookies after the Super Bowl",
        items: [
          "After the Super Bowl, use the draft picks your team still owns. Trading a pick away costs a selection in your next draft. If you traded them all away, decide the franchise tag, then run the league draft and offseason. Scout grades can lie. Defensive picks join your roster like every other selection."
        ]
      },
      {
        heading: "Using the franchise tag before free agency",
        items: [
          "On the draft screen, before your last pick opens free agency, tag one man whose deal is up. The card shows every expiring contract with its tag price, and the button says why when a tag is refused."
        ]
      },
      {
        heading: "Running the GM desk: a coach, a contract and a deadline deal",
        items: [
          "Under the hub's own boxes sit four more: Staff, Re-sign desk, Draft picks and Trade desk. A new franchise opens with them on, and an older save plays on as it did until you open one. Say you hire a level 7 offensive coordinator off the Staff shortlist: his points land on the offense, which is 72 percent of how this game rates a team, so the club gets a little stronger every week. The computer clubs have no staff edge, so even the staff you start with is a step up on them. Your first round pick's rookie deal runs out this spring, so the Re-sign desk offers his fifth year option: one guaranteed season, priced off his rating. Pick it up, or keep him at his ask, push once with your own number, or let him go. At Week 8 you call a club that is well out of the playoff places, which makes it a seller: it marks its veterans down and wants picks and young players. So you send a young depth receiver and a third rounder for its veteran corner. Where you sit in the standings changes nothing in the price, only where they sit does. The receiver's contract goes with him, and 15 percent of his salary for every season he had left stays on your cap this year as dead money, never more than cutting him would have left. Wait until Week 10 is played and the deadline has shut every deal until the season is over. The money is this game's own, never a real contract."
        ]
      },
      {
        heading: "Running the offseason between titles",
        items: [
          "Run the offseason, where young players grow and veterans fade, then chase the next title. Seasons are unlimited, as long as ownership keeps you."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "The 17 week regular season",
        items: [
          "The season runs 17 weeks: home and away against your division rivals plus 11 crossover games."
        ]
      },
      {
        heading: "The real 14 team playoff format",
        items: [
          "Playoffs use the real 14 team format: 7 seeds per conference, byes for the 1 seeds, four knockout rounds."
        ]
      },
      {
        heading: "How trade grades favor quarterbacks",
        items: [
          "Trades are judged on rating, age, and position, with quarterbacks at a premium. The AI only accepts a clear win."
        ]
      },
      {
        heading: "Grade misses, injuries and the roster floor",
        items: [
          "Grades can miss by up to 4 points either way, injuries cost players 1 to 4 weeks, and rosters cannot drop below six players."
        ]
      },
      {
        heading: "Cutting a player and the dead money",
        items: [
          "A cut is not free. Half the man's salary stays on this season's cap as dead money, a quarter lands on next season's if he had years left, and you cannot sign him back until the offseason. A tagged man is fully guaranteed, so cutting him puts his whole salary on the cap."
        ]
      },
      {
        heading: "Tagged stars and who walks",
        items: [
          "One franchise tag per offseason, built on the real NFL rule: a one year, fully guaranteed deal at the average of the 5 largest salaries at his position across the league or 120 percent of his current salary, whichever is more. A man tagged two years running costs at least 120 percent of the first tag. A tagged man cannot leave in free agency. Rival clubs tag too, roughly a third of them each offseason. Untagged men whose deals are up can walk: role players rated under 76 half the time, stars 15 percent of the time."
        ]
      },
      {
        heading: "How your starters set team strength",
        items: [
          "Team strength reads starters off the depth chart. Each group puts up the men at the top of its order (1 quarterback, 2 backs, 3 receivers, 1 tight end, 2 linemen, and 2 each of DL, LB and DB), and the sim counts the quarterback, the best 5 of those 6 skill men, both linemen and all 6 defenders. Rating decides how many of the skill slots each group gets; your order decides who fills them. A chart you have not touched is the order by rating. The bench only plays when a starter is hurt or you move a backup up the chart, so carrying the whole 53 changes nobody's strength. A five man line and real formations are still to come.",
          "A save started before full rosters keeps its fifteen men and reads every healthy lineman, exactly as it always did. It is never topped up: start a new front office to get the whole club."
        ]
      },
      {
        heading: "The 53 man limit and the offseason refill",
        items: [
          "Every offseason each position group is refilled to its real size. The club calls up its own practice squad first and only signs a generated depth man when the squad has nobody left at that spot. A computer club the draft takes over 53 releases its lowest rated men who do not start, dead money and all, never a starter. Your club is never cut behind your back: if your picks take you over 53, the board tells you how many you owe and Play waits until you have cut down yourself. The Giants open at 54, because a starter on injured reserve still counts, so a Giants GM owes one cut before Week 1."
        ]
      },
      {
        heading: "Trust upstairs and getting fired",
        items: [
          "Trust upstairs runs 0 to 100. Beating the mandate raises it, missing it drops it, a championship fixes almost anything, and at zero you are fired and the save ends. A fresh GM always survives one bad year, never three."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Rebuilding a bad roster from scratch",
        paragraphs: [
          "You inherit a 6-11 roster with no cap room, cut an aging receiver, and sign the best lineman available. When your quarterback goes down, you flip a backup and a pick for a veteran starter."
        ]
      },
      {
        heading: "Riding a late blooming pick to the one seed",
        paragraphs: [
          "You sneak in as a 7 seed, lose the Wild Card game, then watch a 90 grade tackle turn out an 84 while the round 3 receiver you almost skipped blooms into an 86. Two years on, you are the 1 seed."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Building the roster around your quarterback",
        items: [
          "Build around the quarterback. Team strength leans on that slot more than anything else."
        ]
      },
      {
        heading: "Betting on upside over aging veterans",
        items: [
          "Young players with hidden upside beat expensive 31 year olds, because decline starts there and never stops."
        ]
      },
      {
        heading: "Knowing when you hold trade leverage",
        items: [
          "In trade talks, stand firm only when you hold leverage: a young piece, or a partner thin at his position. Push a weak hand and the price goes up."
        ]
      }
    ],
    faqs: [
      {
        q: "Are the players real?",
        a: "The opening names and roster places come from a dated 2026 snapshot. New franchise OVRs are original simulation estimates, not official ratings or historical statistics. One position-specific method covers starters, backups and practice players using 2023 to 2025 evidence, recent seasons weighted more heavily. Passing efficiency, receiving and rushing production, playing time and limited defensive measures inform the estimate; small samples have less weight and missing metrics are not zeros. Linemen use participation and draft priors, which cannot measure blocking. An e marks limited evidence, and a player's row explains his opening basis. Later development belongs to your saved simulation. Existing franchises keep their own ratings and contracts. Salaries, trades, future prospects and game outcomes are fictional."
      },
      {
        q: "Can I get fired?",
        a: "Yes. Ownership sets a mandate from your roster's honest strength, grades it every season, and tracks trust from 0 to 100. Miss badly enough for long enough and the seat goes, the save ends, and you take another front office."
      },
      {
        q: "Does my franchise save?",
        a: "Automatically, in your browser, after every move. The abandon button wipes it for a fresh start."
      }
    ]
  },
  "/nfl-my-career": {
    intro: [
      "Every draft night some kid hugs his mom and walks into an unwritten life. Here you get that life: create a fictional prospect, get drafted by a real team, and play a whole career, up to three big calls every offseason.",
      "Seasons produce realistic stat lines from your rating, health, and team. Between them come up to three crossroads, one at a time, drawn from over a hundred of them: contracts, trade requests, surgeries, rookie hazing, a mural in your name, and a podcast invite the front office will hate.",
      "You build your player's actual face before the draft, and there is a dirty side waiting whenever you want it. Selling the injury report to an offshore book, a bounty pool in the meeting room, a clinic in Arizona running a program the league cannot test for yet. Every dirty choice raises a hidden league security meter, and at the top of it sits an indefinite suspension and a comeback from the minimum."
    ],
    headings: {
      howToPlay: "How to play NFL My Career, a free online NFL career simulation game",
      rules: "NFL My Career rules: growth, aging and the security meter",
      example: "NFL My Career walkthrough: a quarterback's road to a ring",
      tips: "NFL My Career tips for building a Hall of Fame legacy",
      faq: "NFL My Career FAQ: positions, free agency and the Bank"
    },
    howToPlaySections: [
      {
        heading: "Creating your player",
        items: [
          "Create your player: name, one of 8 positions (QB, RB, WR, TE, LB, CB, EDGE, K), and an archetype like Cannon Arm, Island Corner, Speed Bender or Ice in December that sets ceiling and durability."
        ],
        subsections: [
          {
            heading: "Picking today's NFL or the 2005 throwback",
            items: [
              "Pick your league: today's NFL, or the 2005 throwback with the Raiders in Oakland, the Chargers in San Diego and the Rams in St. Louis."
            ]
          },
          {
            heading: "Building your look or hitting surprise me",
            items: [
              "Build your look: skin tone, hair, beard, accessories and a signature celebration, or hit Surprise me."
            ]
          }
        ]
      },
      {
        heading: "Entering the draft and winning a job",
        items: [
          "Enter the draft. Your hidden rating decides the slot, and a real team calls your name."
        ],
        subsections: [
          {
            heading: "Winning your job over the incumbent",
            items: [
              "Check the depth chart. Top twelve picks open as starters; everyone else fights the incumbent in camp, every single summer, and backup seasons are spot duty until you take the job."
            ]
          }
        ]
      },
      {
        heading: "Playing seasons one tap at a time",
        items: [
          "Play each season with one tap: yards, touchdowns, awards, how far the team went.",
          "Open Career Log and pick a year to review its saved overview, regular season and postseason. Changes compare with the previous saved season; older missing values say Not recorded. Back to seasons returns to the year tiles, and Review seasons is available after retirement."
        ],
        subsections: [
          {
            heading: "Working a real free agency window",
            items: [
              "When the deal expires, work a real free agency window: competing offers from named teams with their own money, length and roster quality, and one push for more on any of them."
            ]
          }
        ]
      },
      {
        heading: "Making tough offseason calls",
        items: [
          "Make up to three offseason calls, one card at a time: train skills or body, fix the knee or play through it, take the envelope or report it. Only the first card of a summer can move your rating, and a card you just saw rests for a while before it comes back (press moments follow your season, so those can come right back).",
          "After a normal offseason choice, the result shows the actual changes. Expand it for any extra changes, then Continue opens the next card, or takes you back to your career after the last one, without applying the choice again."
        ],
        subsections: [
          {
            heading: "Banking, investing and the card school",
            items: [
              "Open the Bank between seasons. Savings pays 2.5% a season and never loses, five things you can put money into each have a price that moves every season whether you look or not (a fund, flats back home, two shares and a coin that halves as often as it doubles), the statement keeps your last 12 moves, and the card school in the locker room is one sitting a season on odds that are printed before you sit in."
            ]
          },
          {
            heading: "Spending money across seven store aisles",
            items: [
              "Spend the money in 7 aisles: home, rides, investments, body, flex, family, and a shady aisle that only appears once you have something to hide."
            ]
          }
        ]
      },
      {
        heading: "Following the news through retirement",
        items: [
          "Read the News box. The paper writes up every season in your own position's stat, the SocialGram shows followers read off your fanbase with three fan comments under the latest post, and the rival's card keeps the head to head against the player drafted the same year as you.",
          "From 30, a falling rating brings the retirement talk: stop now, play one more year, or announce a farewell season. Then the legacy verdict, and the Hall of Fame wait one ballot at a time."
        ],
        subsections: [
          {
            heading: "Filling the Trophy Case with badges",
            items: [
              "Collect badges in the Trophy Case: 25 of them, from a first ring and Rookie of the Year to 10,000 passing yards, a 20 sack season and $100M to your name, each lit the moment the facts of your career say so."
            ]
          },
          {
            heading: "Answering your phone on the football calendar",
            items: [
              "Answer your phone. Texts from your agent, the head coach, the GM, a teammate or your mom land on the beats of the football year: draft night, camp, the bye, the trade deadline, the playoffs if you get there, the offseason, and the summer before the last year of your deal. Every text says which beat and which year it came in on, and how you answer moves your karma, morale, fanbase or bank."
            ]
          },
          {
            heading: "Making the call when your rival forces one",
            items: [
              "Some seasons your rival puts a decision in front of you instead of a story: a late hit you can answer or let go, a debate show offering real money, a youth camp his foundation wants you to co-host. Every button prints exactly what it moves, and a gamble prints its odds."
            ]
          }
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Growth, ratings and aging by position",
        items: [
          "You start at 22 on a 4 year rookie deal. Growth is slow and honest, 1 to 2 rating points a year through age 26 with a late bloomer chance after that, and the last few points above 88 are the hardest in the game."
        ],
        subsections: [
          {
            heading: "How each position ages and declines",
            items: [
              "Every position has its own stat line, its own awards and its own aging curve. Running backs fall off at 28, corners at 30, quarterbacks at 34, kickers at 39. Defenders chase Defensive Player of the Year instead of MVP, and kickers chase neither.",
              "Decline starts at 31, or 28 for running backs, and it hits them harder."
            ]
          }
        ]
      },
      {
        heading: "Money rules and the league security meter",
        items: [
          "The league security meter runs 0 to 100 and cools 9 a year while you stay clean. Unexplained money keeps it warm. At 65 they open a file on you, at 90 you are suspended indefinitely, you lose the season, the money is seized, and you come back on a minimum deal if anyone calls.",
          "Money has rules of its own. There is a 1% fee on both sides of every trade and a $100k floor in the account that cannot be invested away; a season that leaves you under the floor is covered out of savings first, then by a forced sale of holdings at whatever the price is that day. Cards win 42% of hands and a win pays 1.15x the stake, the most you can stake is $50k or 4% of your cash, and once you are $500k down for your career the guys stop dealing you in for good. Keep sitting in while you are losing and somebody at home notices, which costs morale and fanbase."
        ]
      },
      {
        heading: "Injuries and when retirement is forced",
        items: [
          "Injuries can erase 2 to 10 games a season and leave permanent wear on your health bar.",
          "Retirement is forced at rating 64, age 40, 34 for backs, or 19 seasons. Before that, from 30, slipping 8 points off your best (or down to 70) brings the talk: retire now, one more year, or a farewell season that ends the career after it. You can walk away after 6, and progress saves automatically.",
          "Hall of Fame voters weigh the hardware first (rings, the major awards, All-Pro years), then your seasons and your numbers, and a career total near the top of this game's books in a stat your position really piles up (passing yards for a quarterback, catches for a receiver, interceptions for a corner, tackles for a linebacker, though a kicker and an edge rusher get none) earns a push of its own, up to 390 legacy points.",
          "Example: take a corner with ordinary numbers and one with the same hardware and more interceptions than 99 of 100 corners this game has seen. The second scores at least 300 legacy points more, which can be the whole gap between a long wait and the Hall. A career you already retired keeps the ballot it was told."
        ],
        subsections: [
          {
            heading: "Why the depth chart never guesses at fairness",
            items: [
              "The depth chart is real: the man ahead of you is as good as your team is, camps have memory (a starter is not benched over a small gap, a backup does not need a miracle), backup quarterbacks hold clipboards, and signing with a stacked contender can cost a mid player the job. Kickers never sit."
            ]
          }
        ]
      },
      {
        heading: "How the press and fans read your season",
        items: [
          "The press reads your actual season: win it all and you take the podium, collapse and you face the accountability scrum, ride the bench and someone asks the role question. Every presser is three answers, safe, honest or fiery, and the fiery one genuinely gambles your fanbase.",
          "The fans nag you for the thing your position is judged on and never the other way round: a quarterback hears touchdowns, a corner hears lock down that side, a kicker hears just make the kicks."
        ]
      },
      {
        heading: "The phone's calendar and your rival's choices",
        items: [
          "Texts only arrive on beats your season really had. No playoff texts in a year you went home in January, no contract year texts with years left on the deal, and draft night's text lands before you play a down. One text a beat, up to three a season, fewer while old ones sit unanswered, and the same text never comes twice in a career.",
          "A season with no rival story has a 45% shot at a rival choice instead, never both in one year, and you see every choice once before any of them comes round again. A button does exactly what it says: morale, fanbase, net worth, karma or the heat of the feud. Morale carries straight into how well you play next season."
        ]
      },
      {
        heading: "Playing inside the 2005 sealed world",
        items: [
          "The 2005 throwback is a sealed world: all 32 franchises exactly as they stood that season, verified against the real records, and every draft, trade and signing stays inside it. Contracts pay 2005 money, about a third of today's."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Reading an actual capped change",
        paragraphs: [
          "Say Health is 98 before a recovery choice that adds 10. The 100 cap makes the result 98 to 100, so the card shows +2. Continue moves you on (to the next card, or back to your career after the last one) with Health still at 100."
        ]
      },
      {
        heading: "A Dual Threat quarterback's rookie leap",
        paragraphs: [
          "You make a Dual Threat quarterback and go 12th overall to a shaky roster. The leap comes at 25: 4,000 plus yards, an All-Pro nod, a run that dies in the Championship game. At contract time you take the discount."
        ]
      },
      {
        heading: "Playing through a knee injury to a ring",
        paragraphs: [
          "At 28 the knee starts talking. You play through it, lose four games, and demand a trade. The ring comes at 31, you retire at 35 with one MVP, and the verdict reads Hall of Famer."
        ]
      },
      {
        heading: "Answering your rival's late hit",
        paragraphs: [
          "Your rival drills you a second after the whistle and the card asks what you do about it. Settle it next time heats the feud and usually pays Morale +8, but it carries a 30% chance you draw the flag yourself (Morale -5, Fanbase -5, Net worth -$100k). Shake it off on camera is Fanbase +5, Karma +5 and the feud cools. You pick say nothing and watch the film: Morale +6, the feud heats up, and those six points ride into next season's stat line."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Cashing in early at running back",
        items: [
          "Running back careers are a sprint. Cash in early, because the cliff at 28 is real."
        ]
      },
      {
        heading: "Why body work protects everything else",
        items: [
          "Body work is boring and correct. Health protects games played, and games played protect everything else."
        ]
      },
      {
        heading: "MVPs and rings over stat padding",
        items: [
          "MVPs move the legacy score most, rings close behind. Stat padding on bad teams only goes so far."
        ]
      },
      {
        heading: "Choosing between a contender and the money",
        items: [
          "In free agency the contender offers less and the rebuild offers more. The roster number on the card is the exact quality your next seasons run on, so you are choosing between money and January."
        ]
      }
    ],
    faqs: [
      {
        q: "Which positions can I play?",
        a: "Eight of them: QB, RB, WR, TE, LB, CB, EDGE and K, each with its own archetypes, stat line, awards and aging curve."
      },
      {
        q: "Can I start in a different era?",
        a: "Yes. The create screen has a 2005 throwback: the league exactly as it stood that season, with the Raiders in Oakland, the Chargers in San Diego and the Rams in St. Louis. An era career never meets a franchise that did not exist yet, and the money is 2005 sized."
      },
      {
        q: "How does free agency work?",
        a: "When your deal is up you get a window of real offers: your team's re-sign number plus named suitors, each with its own salary, length and roster quality. Contenders lowball because they can, rebuilds overpay because they must. You can push any offer for more once, but push a weak case and it can be pulled. Your own team never walks away, so you always have somewhere to sign."
      },
      {
        q: "Why am I not starting?",
        a: "Because the man ahead of you is better, for now. Late picks usually open on the bench behind an incumbent whose level tracks your team's quality. Grow your rating and you will win a camp; backup years are spot duty with slower fame and sagging morale, which is exactly why they sting. A rebuild with a bare roster is the fastest route to the job."
      },
      {
        q: "What decides the legacy verdict?",
        a: "Rings, MVPs, All-Pro nods, seasons played, and stat totals, on a scale from cup of coffee to inner circle immortal."
      },
      {
        q: "What is in the Bank?",
        a: "Four tabs. Account holds your cash, a savings account that pays 2.5% a season, and a statement of your last 12 moves. Market is five prices that move every season, each with its own risk word and a read on whether it is cheap or dear against what it usually goes for. Cards is the locker room card school, one sitting a season, on odds the screen prints before you play. Shop is the 7 aisles. It is the same engine Soccer Career's phone runs on, in dollars."
      },
      {
        q: "Who is my rival?",
        a: "A generated player drafted the same year at your position. He plays his own seasons on the same scale you do, can win a ring before you and retire before you, and the head to head is kept for good. He is fictional, like your own player, so no real player's career is being simulated."
      },
      {
        q: "How do I earn badges?",
        a: "By doing the thing. Each of the 25 badges is a test on the facts of your career, checked every time you open the case: a ring, an MVP, ten thousand yards, five full seasons without a missed game, a million dollars to your name. The three single season badges sit just under the real records, 5,000 passing yards against Peyton Manning's 5,477, 2,000 rushing yards against Eric Dickerson's 2,105 and 20 sacks against Myles Garrett's 23, and the ten All-Pro badge is the mark Jerry Rice and Jim Otto share."
      }
    ]
  },
  "/football-grid": {
    intro: [
      "The grid looks harmless: three rows, three columns, nine cells. Each row and column is a pro football criterion, a franchise, a position group, a draft story, a Super Bowl ring, and every cell needs a player who satisfies both. Then you learn that naming an undrafted Cowboys quarterback is harder than it sounds.",
      "If daily team grids ever owned your mornings, this is that same itch with a twist: a rarity score that rewards deep cuts over obvious answers. Anyone can finish a grid with superstars. Finishing it with the forgotten third receiver from 2009 is the flex.",
      "A new puzzle drops at midnight Eastern, and everyone plays the same one."
    ],
    headings: {
      howToPlay: "How to play NFL Grid, a free online NFL trivia grid puzzle",
      rules: "NFL Grid rules: guesses, rarity scores and the daily puzzle",
      example: "NFL Grid walkthrough: chasing rarity across nine cells",
      tips: "NFL Grid tips for filling every cell without wasting guesses",
      faq: "NFL Grid FAQ: rarity scores, guesses and categories"
    },
    howToPlaySections: [
      {
        heading: "Reading the row and column criteria",
        items: [
          "Read the three row and three column criteria. A cell crossing Played for Packers with Won Super Bowl needs a player who did both."
        ]
      },
      {
        heading: "Typing a name into each cell",
        items: [
          "Tap a cell, start typing a name, and pick the player from the suggestions."
        ]
      },
      {
        heading: "Watching cells lock green or flash red",
        items: [
          "Correct answers lock in green with a rarity percentage. Wrong ones flash red."
        ]
      },
      {
        heading: "Budgeting your 15 guesses",
        items: [
          "Budget carefully: you get 15 guesses for all 9 cells, and every submission counts, so you can only afford 6 misses."
        ],
        subsections: [
          {
            heading: "Finishing the grid and sharing your score",
            items: [
              "Fill all nine cells to complete the grid, then share the emoji board and your rarity score."
            ]
          }
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Why every answer must fit twice",
        items: [
          "Every answer must match its row and its column at the same time."
        ]
      },
      {
        heading: "The 15 guess budget and unlimited practice",
        items: [
          "You get 15 total guesses, right or wrong. An unlimited guesses toggle exists for stress-free practice."
        ]
      },
      {
        heading: "How your Rarity Score gets calculated",
        items: [
          "Each correct pick shows what percent of players chose that same name for that cell. Your Rarity Score is the average across your correct cells, and lower is better."
        ]
      },
      {
        heading: "Checking answers against 22,000 careers",
        items: [
          "Every answer is checked against a career record of 22,000 players going back to 1970, right in your browser, so a guess is judged the instant you pick it."
        ],
        subsections: [
          {
            heading: "One shared daily puzzle with saved progress",
            items: [
              "One shared puzzle per day, with your progress saved if you leave and come back."
            ]
          }
        ]
      }
    ],
    exampleSections: [
      {
        heading: "The trap of a double eligible answer",
        paragraphs: [
          "Take rows of Patriots, Cowboys, and Packers against columns of Quarterback, Undrafted, and Won a Super Bowl. Most people type Tony Romo for the Cowboys quarterback cell and collect a fat common percentage; he answers the undrafted cell just as well, and using him twice is not allowed, so you have to choose."
        ]
      },
      {
        heading: "Finding rarer names for busy cells",
        paragraphs: [
          "Patriots plus Won a Super Bowl is a Tom Brady magnet, so you go Corey Dillon, who carried the 2004 champs, and score single digits. Packers plus Undrafted has Tramon Williams waiting, and Packers plus Won a Super Bowl is Aaron Rodgers for everyone else, so you pick James Jones, the receiver from the 2010 champs, and the search box shows him with his seasons beside his name because four James Joneses have played in the league."
        ]
      },
      {
        heading: "Nine cells closed and one final score",
        paragraphs: [
          "You close it 9 for 9 with two guesses to spare, and the nine percentages average out to 24. That number goes straight to the group chat."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Scanning for the hardest crossing first",
        items: [
          "Scan the whole grid before guessing. Find the hardest crossing and save your flexible answers for it."
        ]
      },
      {
        heading: "Why journeymen cover more cells",
        items: [
          "Journeymen are gold. A four franchise veteran covers cells a one team legend never could."
        ]
      },
      {
        heading: "Changing angles after a missed guess",
        items: [
          "If a name misses, change angles. Do not spend a second guess on a teammate from the same hunch."
        ]
      },
      {
        heading: "Choosing a finished grid over rare picks",
        items: [
          "Chasing rarity is fun, but 9 of 9 with boring answers always beats 7 of 9 with cool ones."
        ]
      }
    ],
    faqs: [
      {
        q: "How does the rarity score work?",
        a: "Every correct cell shows the percentage of players who picked that same name there, based on real picks on the same puzzle. Your score averages those numbers, so lower means rarer, and rarer is the brag."
      },
      {
        q: "Do correct answers use up guesses too?",
        a: "Yes. The 15 guess budget counts every submission, so a perfect game spends 9 and leaves room for exactly 6 mistakes."
      },
      {
        q: "What categories show up?",
        a: "All 32 franchises, with relocations folded in so the Oilers count as the Titans, plus position groups, draft stories like undrafted or first round, and Super Bowl winners. Every one is answered from a career record of 22,000 players going back to 1970, so a cell never depends on a guess about a guess."
      },
      {
        q: "What happens when I run out of guesses?",
        a: "The grid ends and you keep the cells you filled plus their rarity score. A fresh grid lands at midnight Eastern."
      },
      {
        q: "Is this the same as the baseball grid?",
        a: "Same core idea, pointed at football history instead, with crowd sourced rarity built in and an unlimited mode for practice."
      }
    ]
  },
  "/nfl-career": {
    intro: [
      "One mystery pro football player, six career clues, and a score that shrinks every time you need another hint. You start with nothing but a draft round and a year, and it becomes a staring contest with your own memory.",
      "The clue order is the difficulty curve. Draft info could be thousands of guys. The full team history should feel obvious, which is exactly why solving early feels so good."
    ],
    headings: {
      howToPlay: "How to play NFL Career Path, a free daily NFL guessing game",
      rules: "NFL Career Path rules: clues, scoring and difficulty",
      example: "NFL Career Path walkthrough: solving a sixth round mystery",
      tips: "NFL Career Path tips for reading every clue right",
      faq: "NFL Career Path FAQ: daily puzzles and hard mode"
    },
    howToPlaySections: [
      {
        heading: "Reading the draft round and year clue",
        items: [
          "Read clue one: the round and year the mystery player was drafted."
        ]
      },
      {
        heading: "Typing a guess whenever you feel sure",
        items: [
          "Type a guess in the search box whenever you feel sure."
        ]
      },
      {
        heading: "Unlocking clues in a fixed order",
        items: [
          "Every wrong guess reveals the next clue, in a fixed order: draft, college, first team, career stat, team history, jersey numbers."
        ],
        subsections: [
          {
            heading: "Scoring more points for an early solve",
            items: [
              "Solve early for more points. A first clue solve scores 6, and each extra clue costs one."
            ]
          }
        ]
      },
      {
        heading: "What happens after the sixth clue",
        items: [
          "A wrong guess after the sixth clue ends the game and reveals the player."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Six clues and six total guesses",
        items: [
          "There are 6 clues and 6 guesses, one wrong answer per clue."
        ]
      },
      {
        heading: "Scoring from six points down to one",
        items: [
          "Scoring runs from 6 points for a first clue solve down to 1 on the last."
        ]
      },
      {
        heading: "Daily puzzles versus unlimited mode",
        items: [
          "Daily serves everyone the same mystery player, fresh every day. Unlimited deals random players back to back."
        ],
        subsections: [
          {
            heading: "How Hard mode hides the early clues",
            items: [
              "Hard mode hides the earliest clues once new ones arrive, so you cannot lean on the whole stack."
            ]
          }
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Narrowing a sixth round draft class",
        paragraphs: [
          "Clue one says Round 6, 2000. One sixth rounder from that class towers over the rest, but you wait for clue two anyway: Michigan. That settles it."
        ]
      },
      {
        heading: "Naming Tom Brady on the second clue",
        paragraphs: [
          "You type Tom Brady and take 5 points for a two clue solve. In hindsight the first clue was enough, and the missing point will bother you all day."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Reading draft position as a loaded clue",
        items: [
          "Draft position is loaded information. A first overall pick narrows to one name, and a famous late rounder often is the whole answer."
        ]
      },
      {
        heading: "Treating the stat clue as a style hint",
        items: [
          "Read the career stat clue as a style hint. It usually points at what made the player famous."
        ]
      },
      {
        heading: "Avoiding wasted early guesses",
        items: [
          "Do not spray early guesses. Each miss costs a point, and the search will not let you repeat one."
        ]
      }
    ],
    faqs: [
      {
        q: "What if I am stuck on the last clue?",
        a: "Think as long as you like, give up to see the answer, or take one final swing. A wrong guess there ends at zero."
      },
      {
        q: "Are the players current or retired?",
        a: "Both. The pool mixes active stars with legends, and the clue trail works the same either way."
      },
      {
        q: "Does Hard mode change the scoring?",
        a: "No. It only hides the early clues from view once later ones arrive."
      }
    ]
  },
  "/nfl-higher-lower": {
    intro: [
      "Two players, one stat, one tap. A pair of pros sit side by side under a question like who threw for more career yards, and your gut answers before your brain finishes the math.",
      "The category rotates every round: touchdowns, then receptions, then rushing yards. Ten rounds later you find out how well you really know the record book."
    ],
    headings: {
      howToPlay: "How to play NFL Higher or Lower, a free online NFL stats game",
      rules: "NFL Higher or Lower rules: scoring, streaks and the player pool",
      example: "NFL Higher or Lower walkthrough: a photo finish streak run",
      tips: "NFL Higher or Lower tips for picking the bigger career number",
      faq: "NFL Higher or Lower FAQ: hard mode, streaks and career data"
    },
    howToPlaySections: [
      {
        heading: "Reading the rotating stat category",
        items: [
          "Read the stat question at the top. Rounds rotate through touchdowns scored, passing yards, passing touchdowns, rushing yards, receiving yards, and receptions."
        ]
      },
      {
        heading: "Checking each player before you tap",
        items: [
          "Check each player's position, teams, and final season, then tap the one with the bigger career number."
        ]
      },
      {
        heading: "Revealing totals round by round",
        items: [
          "Watch both totals reveal, then roll into the next round."
        ]
      },
      {
        heading: "Finishing all ten rounds",
        items: [
          "Finish all 10 rounds and post your score."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Scoring points and the streak bonus",
        items: [
          "Each correct answer scores 10 points, and consecutive correct answers stack a growing streak bonus of 5 points per extra step."
        ]
      },
      {
        heading: "The maximum 325 point perfect game",
        items: [
          "A perfect 10 for 10 with an unbroken streak maxes out at 325."
        ]
      },
      {
        heading: "Why careers start in 2000 or later",
        items: [
          "Career numbers come from real play by play data, using careers that started in 2000 or later so every total is complete."
        ],
        subsections: [
          {
            heading: "Daily mode versus unlimited Hard mode",
            items: [
              "Daily is the same 10 rounds for everyone, once per day. Unlimited is random, and its Hard toggle pairs the closest values. Rare exact ties count as correct either way."
            ]
          }
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Misjudging a close touchdown battle",
        paragraphs: [
          "Round one asks career touchdowns and shows LaDainian Tomlinson against Adrian Peterson. Feels close, but LT finished with 162 to Peterson's 126, and the wrong pick kills your streak at zero."
        ]
      },
      {
        heading: "Building a six round streak to the finish",
        paragraphs: [
          "You settle down, run off six straight, and the streak bonus starts doing real work. A coin flip finish lands right, and you close at 8 of 10, well past 100 points."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Why longevity beats a short peak",
        items: [
          "Longevity beats peak. A very good 15 year player usually out-totals a legend who burned bright for 8."
        ]
      },
      {
        heading: "Matching player type to the stat",
        items: [
          "Match the player type to the stat. Volume receivers stack receptions, deep threats stack yards."
        ]
      },
      {
        heading: "Protecting a live scoring streak",
        items: [
          "Protect a live streak. When a round feels like a coin flip, slow down, because the bonus is where big scores live."
        ]
      }
    ],
    faqs: [
      {
        q: "What is Hard mode?",
        a: "An unlimited mode toggle that builds nothing but photo finishes, pairing players with the smallest gaps it can find."
      },
      {
        q: "Why are older legends missing?",
        a: "The pool only uses careers starting in 2000 or later, where the play by play data is complete, so nobody's total is silently short."
      },
      {
        q: "Can both answers be right?",
        a: "On an exact tie, yes, either pick scores. The game avoids building tie pairs, so it almost never comes up."
      }
    ]
  },
  "/nfl-connections": {
    intro: [
      "Twenty pro football players sit in a grid, hiding four groups of five that share something: a franchise, a college, a draft slot, a milestone. Find all four groups before four wrong guesses find you.",
      "The cruelty is the overlap. That quarterback fits the LSU group and the number one picks group, but he only belongs to one."
    ],
    headings: {
      howToPlay: "How to play NFL Connections, a free online NFL grouping puzzle",
      rules: "NFL Connections rules: groups, lives and color difficulty",
      example: "NFL Connections walkthrough: untangling an LSU overlap",
      tips: "NFL Connections tips for spotting the real theme fast",
      faq: "NFL Connections FAQ: group sizes, colors and daily play"
    },
    howToPlaySections: [
      {
        heading: "Scanning twenty names for a shared theme",
        items: [
          "Scan the 20 names for anything five of them share."
        ]
      },
      {
        heading: "Tapping five players and submitting",
        items: [
          "Tap exactly 5 players and hit submit."
        ]
      },
      {
        heading: "Locking a group or losing a life",
        items: [
          "A real group locks in with its theme and color. A miss costs one of your 4 lives."
        ]
      },
      {
        heading: "Clearing the board of all four groups",
        items: [
          "Solved groups leave the board, making the rest easier to read. Clear all four to win."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Groups of five and exact matches",
        items: [
          "Groups are five players each, and a submission must match exactly. Four right and one wrong is still wrong."
        ]
      },
      {
        heading: "Four lives and no hint system",
        items: [
          "You get 4 lives for the whole puzzle, and there is no one away hint."
        ]
      },
      {
        heading: "What the yellow, green, blue and purple colors mean",
        items: [
          "Colors mark difficulty: yellow is gentlest, then green, then blue, and purple is the trap."
        ],
        subsections: [
          {
            heading: "Losing all your lives and the daily puzzle",
            items: [
              "Lose all lives and the remaining groups reveal themselves. Daily is one shared puzzle with saved progress, and Unlimited pulls random ones."
            ]
          }
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Locking an easy shared team group",
        paragraphs: [
          "You spot five players who all wore a Patriots uniform and lock the yellow group. Then an LSU group looks obvious, except six names fit, which means one of them belongs somewhere else."
        ]
      },
      {
        heading: "Untangling an LSU overlap trap",
        paragraphs: [
          "You guess wrong once, swap the receiver for the safety you forgot went to LSU, and it locks. From ten names the rest sorts itself, and you finish with 2 lives left."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Counting candidates before you submit",
        items: [
          "Count candidates before submitting. Six names fitting a theme means you have not found the real theme yet."
        ]
      },
      {
        heading: "Locking your surest group first",
        items: [
          "Lock your surest group first, not the first one you noticed. Every solve removes noise."
        ]
      },
      {
        heading: "Resolving a fight between two groups",
        items: [
          "When two groups fight over one player, work out where the other four names in each group come from."
        ]
      }
    ],
    faqs: [
      {
        q: "How is this different from other connections games?",
        a: "It runs bigger: four groups of five instead of four, so 20 players on the board and more overlap traps."
      },
      {
        q: "What themes show up?",
        a: "Shared franchises, colleges, draft slots, and career milestones like passing yard thresholds. The purple group leans on the sneakiest link."
      },
      {
        q: "Do I lose progress if I close the tab?",
        a: "No. The daily puzzle saves as you go and picks up where you left off."
      }
    ]
  },
  "/nfl-connect-4": {
    intro: [
      "It is Connect 4, the childhood classic, except every disc has a price: before a piece drops you must name a player matching both the column you picked and the row where it lands.",
      "You block lines and build threats like normal, while wondering if you can produce a Steelers Defensive Player of the Year on command. Sometimes the best square is a question you cannot answer."
    ],
    headings: {
      howToPlay: "How to play NFL Connect 4, a free online NFL trivia board game",
      rules: "NFL Connect 4 rules: boards, criteria and reused players",
      example: "NFL Connect 4 walkthrough: stealing a lane late in the game",
      tips: "NFL Connect 4 tips for winning with smart column picks",
      faq: "NFL Connect 4 FAQ: opponents, verification and eras"
    },
    howToPlaySections: [
      {
        heading: "Choosing one of six curated boards",
        items: [
          "Start a game. Each of the 6 curated boards, like Dynasties or Steel Curtain, mixes franchises with achievements."
        ]
      },
      {
        heading: "Picking a column and reading the row",
        items: [
          "Pick a column. Gravity drops your piece to the lowest empty row, and that row's criterion is the one to satisfy."
        ]
      },
      {
        heading: "Naming a player who fits both criteria",
        items: [
          "Name a player matching both. A verified answer claims the cell in your color."
        ]
      },
      {
        heading: "Alternating turns with a friend",
        items: [
          "Red and blue alternate. Pass the device to a friend or play both sides."
        ],
        subsections: [
          {
            heading: "Winning with four in a row",
            items: [
              "First to four in a row, any direction, wins. A full board is a draw."
            ]
          }
        ]
      }
    ],
    ruleSections: [
      {
        heading: "The seven by six board and its criteria",
        items: [
          "The board is 7 columns by 6 rows, with criteria like League MVP, 100+ Career Sacks, or Undrafted."
        ]
      },
      {
        heading: "Why a wrong answer costs nothing",
        items: [
          "Wrong answers place nothing and do not lose your turn. Rethink, try another name, or hit skip to pass."
        ]
      },
      {
        heading: "Using every player only once",
        items: [
          "Every player can only be used once per game, by either side."
        ],
        subsections: [
          {
            heading: "Counting relocated franchises as one history",
            items: [
              "Franchise history counts across relocations, so Oilers greats count for the Titans."
            ]
          }
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Opening the Field Generals board",
        paragraphs: [
          "On the Field Generals board, red opens in the Super Bowl MVP column, lands on the Packers row, and claims it with Bart Starr. Blue answers on the Saints row with Drew Brees."
        ]
      },
      {
        heading: "Stealing a lane with a backup answer",
        paragraphs: [
          "Ten turns later red needs one cell on 40,000+ Career Passing Yards crossed with the Chargers, but Philip Rivers is already used. Red blanks and skips, and blue steals the lane with Dan Fouts."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Checking where your piece will land",
        items: [
          "Look down before answering. What matters is the row your piece will actually land in."
        ]
      },
      {
        heading: "Saving your most flexible players",
        items: [
          "Save your universal players. A name that fits many cells is worth most late."
        ]
      },
      {
        heading: "Steering play toward your opponent's gaps",
        items: [
          "Steer the game toward columns your opponent cannot answer. That is as good as a block."
        ]
      }
    ],
    faqs: [
      {
        q: "Is there a computer opponent?",
        a: "No, it is two players on one screen. Grab a friend, or play both colors as a trivia workout."
      },
      {
        q: "Who checks the answers?",
        a: "An AI referee checks each name against both criteria before the piece drops. If it cannot verify right now, nothing is placed and you retry."
      },
      {
        q: "Can I use players from any era?",
        a: "Yes. Suggestions cover 2002 to today, but you can type any older legend's full name directly."
      }
    ]
  },
  "/missing-eleven": {
    intro: [
      "You remember the game, the score, maybe the halftime show. Missing Eleven bets you do not remember who started. It shows a real Super Bowl starting lineup, offense or defense, with one name blanked out, and gives you 3 guesses.",
      "Every lineup is verified against official starter tables, which is exactly why this hurts. The famous name you remember was often coming off the bench that night."
    ],
    headings: {
      howToPlay: "How to play Missing Eleven, a free daily NFL guessing game",
      rules: "Missing Eleven rules: guesses, hints and scoring",
      example: "Missing Eleven walkthrough: the Super Bowl LI running back mystery",
      tips: "Missing Eleven tips for naming the real starter",
      faq: "Missing Eleven FAQ: accuracy, offense and defense lineups"
    },
    howToPlaySections: [
      {
        heading: "Reading the Super Bowl and the final score",
        items: [
          "Read the card: which Super Bowl, the final score, and whose starting unit you are looking at."
        ]
      },
      {
        heading: "Finding the blank starter's position",
        items: [
          "Find the blank among the 11 starters. The position shows, the name is the mystery."
        ]
      },
      {
        heading: "Typing a guess from the suggestions",
        items: [
          "Type a guess. Suggestions search the whole league, and a last name alone works."
        ]
      },
      {
        heading: "Earning hints after each miss",
        items: [
          "Miss and you get a hint, miss again for another. The third miss ends it."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Three guesses and their point values",
        items: [
          "You get 3 guesses, scoring 100 points on the first, 70 on the second, and 40 on the third."
        ]
      },
      {
        heading: "What each missed guess reveals",
        items: [
          "The first miss reveals the player's nationality, the second reveals the first letter of the last name."
        ]
      },
      {
        heading: "When a last name alone is enough",
        items: [
          "A surname on its own counts when it is at least 4 letters."
        ],
        subsections: [
          {
            heading: "Hard mode and the daily lineup",
            items: [
              "Hard mode removes hints, suggestions, and position labels. Daily is one shared puzzle a day, and Unlimited deals random lineups."
            ]
          }
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Guessing wrong on a famous name",
        paragraphs: [
          "The card reads Super Bowl LI, Patriots 34, Falcons 28 in overtime, with the blank at running back for New England. Your brain screams LeGarrette Blount, or maybe James White, who scored the overtime winner."
        ]
      },
      {
        heading: "Finding the real starter on the last guess",
        paragraphs: [
          "Both wrong. The actual starter that night was Dion Lewis, and White came off the bench for his three touchdowns. You take 40 points on the final guess and stop trusting your memory."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Thinking starter, not star",
        items: [
          "Think starter, not star. The trap is almost always a famous name who began the night on the sideline."
        ]
      },
      {
        heading: "Using the visible names to pin the season",
        items: [
          "Use the ten visible names to pin down the exact season, then run that year's depth chart in your head."
        ]
      },
      {
        heading: "Watching the positions memory forgets",
        items: [
          "On offense, watch for linemen and second receivers. On defense, safeties are where memory gets fuzzy."
        ]
      }
    ],
    faqs: [
      {
        q: "Are the lineups actually accurate?",
        a: "Yes. Each one was checked against official box score starters and cross verified. When the answer surprises you, that is the point."
      },
      {
        q: "Is it always the offense?",
        a: "No. The pool includes starting defenses too, and the card tells you which side of the ball you have."
      },
      {
        q: "Do I have to spell the full name?",
        a: "No. Spelling is forgiving, and a last name of 4 or more letters is accepted on its own."
      }
    ]
  },
  "/nfl-gauntlet-draft": {
    intro: [
      "The draft mode, NFL style: seven picks, one per starting offense slot, five real players a pick from a genuine star to a bargain, and you keep exactly one.",
      "Then the cup begins. Your finished offense runs five knockout rounds against ever stronger invented opposition, rated 78 up to 99, and overtime when the game is level.",
      "The run is decided entirely by the offense you drafted: the same seven always runs the same gauntlet, so every pick is the game."
    ],
    headings: {
      howToPlay: "How to play Gauntlet Draft: NFL, a free online NFL card draft game",
      rules: "Gauntlet Draft: NFL rules: cards, positions and the knockout",
      example: "Gauntlet Draft: NFL walkthrough: a quarterback pick and a title run",
      tips: "Gauntlet Draft: NFL tips for building a title winning offense",
      faq: "Gauntlet Draft: NFL FAQ: daily drafts, positions and opponents"
    },
    howToPlaySections: [
      {
        heading: "Choosing the daily or unlimited draft",
        items: [
          "Pick the daily gauntlet (the same five card choices for everyone today) or unlimited for a fresh draft."
        ]
      },
      {
        heading: "Drafting each of your seven slots",
        items: [
          "For each of the seven slots (QB, two RB, three WR, TE) read the five cards, star to bargain, and tap the one you keep."
        ]
      },
      {
        heading: "Watching the knockout begin on its own",
        items: [
          "After the seventh pick the knockout starts on its own: five rounds, one match each, revealed one at a time."
        ]
      },
      {
        heading: "Scoring survival points and the trophy",
        items: [
          "Survive a round for 16 points; lift the trophy for exactly 100."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Real players against invented opponents",
        items: [
          "Every card is a real player off the same 2026 roster data NFL Front Office plays; every opponent club is invented on purpose."
        ]
      },
      {
        heading: "Why the draft covers four skill positions",
        items: [
          "The draft is scoped to the four skill positions (QB, RB, WR, TE) on purpose: their ratings are built from real production, the way the position data's own generator describes it, and every slot deals a genuine star-to-bargain spread. Offensive line and defense lean on draft position and years played instead, so they stay out of the draft rather than padding it with picks that are not a real choice."
        ]
      },
      {
        heading: "A star to bargain spread in every slot",
        items: [
          "The five cards per slot are spread across the pool's rating range, so a top-tier card and a bargain are always both on the table."
        ],
        subsections: [
          {
            heading: "Never dealt the same player twice",
            items: [
              "No player is dealt twice in one draft."
            ]
          }
        ]
      },
      {
        heading: "A knockout that replays the same way",
        items: [
          "The knockout is deterministic in your offense: scoring comes from the rating gap, level games go to overtime, and replaying the same seven replays the same cup."
        ]
      },
      {
        heading: "Opposition ratings climbing round by round",
        items: [
          "Opposition ratings climb 78, 85, 90, 95, 99. A bargain offense usually falls in the first round, an elite one reaches the final as a slight underdog, and even a perfect draft lifts the trophy roughly one run in nine."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Five cards at the quarterback slot",
        paragraphs: [
          "The quarterback slot deals a 97 rated MVP season next to an 88, an 82, a 76 and a 68. There is no cost to any of them, so the 97 is the pick unless you are chasing a specific team on the card."
        ]
      },
      {
        heading: "Two rounds survived and one regret",
        paragraphs: [
          "Your finished offense rates 94. The Qualifier wins big, the Last Sixteen is tight, the Quarter Final needs overtime, and the Semi Final ends the run. Two rounds survived, 32 points, and the card you would redo is the 76 you took at the third receiver spot."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Why the quarterback card carries the most weight",
        items: [
          "The quarterback card carries the most weight of any single pick: a weak one drags the whole rating."
        ]
      },
      {
        heading: "Bargain cards for flavor, not for winning",
        items: [
          "The bargain cards exist for flavor runs, not for winning. If the score is the goal, draft the biggest number that fits."
        ]
      },
      {
        heading: "Watching your running rating climb",
        items: [
          "Champions need an offense in the mid nineties. Check your running rating under the cards as you go."
        ]
      }
    ],
    faqs: [
      { q: "Is the daily draft the same for everyone?", a: "Yes. One shared set of five card choices per Eastern Time date, so daily scores compare fairly." },
      { q: "Are the opponents real teams?", a: "No, and that is deliberate: every gauntlet opponent is an invented club, so no real logo or name is borrowed. The players you draft are real, off the same roster data NFL Front Office plays." },
      { q: "Why seven slots instead of eleven?", a: "The real position data behind this game groups linemen and defenders more broadly than it splits out quarterbacks, running backs, receivers and tight ends, so those four skill positions are where every pick is a genuinely graded choice. A full eleven man lineup is possible future scope; this round scoped it to what the data actually supports." },
      { q: "Is this the same game as the soccer Gauntlet Draft?", a: "Same engine, NFL's own pool and positions. Seven picks instead of eleven, and the ladder is tuned to this pool's own, much wider rating spread." }
    ]
  },
  "/conquest": {
    intro: [
      "Picture America painted in 32 team colors, every state owned by its nearest stadium. Now play a season where each result redraws the borders, because in this football conquest game every winner annexes the loser's entire empire. Part season sim, part sports battle map, all chaos.",
      "The headline mode is Imperialism, the format the internet fell in love with: empires balloon, collapse, and flip on one upset. Arcade mode keeps the original play by play battles, player steals, and power ups.",
      "You do not just watch. You pick a team, call their game each week, and ride your empire to the final map."
    ],
    headings: {
      howToPlay: "How to play NFL Conquest, a free online NFL map conquest game",
      rules: "NFL Conquest rules: scoring, playoffs and the Daily Challenge",
      example: "NFL Conquest walkthrough: an empire lost and won back",
      tips: "NFL Conquest tips for surviving the imperialism map",
      faq: "NFL Conquest FAQ: territories, Arcade mode and comebacks"
    },
    howToPlaySections: [
      {
        heading: "Picking your team on the 56 region map",
        items: [
          "Pick your team in Imperialism mode. The map seeds every territory to the closest stadium, 56 regions covering the lower 48."
        ]
      },
      {
        heading: "Calling the winner of your team's game",
        items: [
          "Each week all 32 teams pair off, and you call the winner of your team's game, with records and win odds on the card."
        ]
      },
      {
        heading: "Watching the map redraw after each week",
        items: [
          "Play the week and watch the map redraw. Every winner absorbs everything the loser owned."
        ]
      },
      {
        heading: "Reaching the playoffs after 18 weeks",
        items: [
          "Survive 18 weeks, and the top 8 empires by territory enter the playoffs: Quarterfinals, Semifinals, Imperial Championship."
        ],
        subsections: [
          {
            heading: "Losing an empire in the playoff bracket",
            items: [
              "Playoff losers hand over their whole empire, so the bracket consolidates the map until one team rules America."
            ]
          }
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Winner takes all, every single game",
        items: [
          "Winner takes all, every game. A one point squeaker annexes as completely as a blowout, and overtime means no ties."
        ]
      },
      {
        heading: "How a wiped out team can come back",
        items: [
          "Wiped out teams keep playing their schedule, and one win seizes their conqueror's entire empire. Comebacks are the soul of the format."
        ]
      },
      {
        heading: "Ending the season early with a full map",
        items: [
          "If a team owns the whole map before week 18, the season ends on the spot."
        ]
      },
      {
        heading: "Seeding the playoffs by territory",
        items: [
          "Playoff seeding is territory first, with season record breaking ties."
        ],
        subsections: [
          {
            heading: "How points get scored across the season",
            items: [
              "Scoring: 3 points per state held at the end, 25 per correct call, 50 for making the playoffs, 200 if your team takes the crown."
            ]
          }
        ]
      },
      {
        heading: "The Daily Challenge versus Free Play",
        items: [
          "The Daily Challenge deals every player the same date-seeded season: same starting map, same fixtures, same results. One scored run per day with streaks. Free Play is unlimited and fully random."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Growing an empire across the middle of the map",
        paragraphs: [
          "You pick the Chiefs, who start with a slice of the middle of the map. Week 1 they beat the Broncos and the whole mountain empire flips red in an afternoon. By week 6 you stretch toward the Pacific, because your victims had already eaten their neighbors."
        ]
      },
      {
        heading: "Losing a twenty state kingdom in one week",
        paragraphs: [
          "Then week 9: a 3 point loss to the Bears hands your 20 state kingdom to Chicago, and your NFL imperialism map dream is suddenly a gray footnote. You still sit at 6 and 3. You just own nothing."
        ]
      },
      {
        heading: "Clawing back to the Imperial Championship",
        paragraphs: [
          "One win the next week puts you back in business, because your new victim sat on 14 states. You claw to the 3 seed, win two playoff rounds, and drop the Imperial Championship to a juggernaut. Final tally: 41 states, 11 correct calls, playoff bonus banked. You immediately run it back."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Not panicking after getting erased",
        items: [
          "Do not panic when you get erased. One win against a fat empire is the fastest growth in the game."
        ]
      },
      {
        heading: "Respecting close win odds when calling games",
        items: [
          "Respect close win odds when calling games. Those 25 point picks quietly decide your final score."
        ]
      },
      {
        heading: "Watching the standings, not just the colors",
        items: [
          "Watch the standings, not just the colors. Record breaks playoff ties, so a hot streak matters late."
        ]
      },
      {
        heading: "Trying Arcade mode for a slower burn",
        items: [
          "Try Arcade when you want a slower burn: battles, player steals, and a 99 rated franchise legend power up."
        ]
      }
    ],
    faqs: [
      {
        q: "How does the Daily Challenge work?",
        a: "Everyone on the planet gets the same season today: identical starting map, identical fixtures, identical results. Your score comes from which empire you back and how well you call the games, so comparing scores is a fair fight. One scored run per day, streaks build if you show up daily, and a fresh map drops at midnight Eastern. Free Play stays unlimited."
      },
      {
        q: "How does the imperialism format work?",
        a: "Every territory starts with its nearest stadium. Each winner annexes every state the loser owned, wiped out teams stay on the schedule and can reclaim an empire with one win, and after 18 weeks the top 8 empires play a knockout bracket."
      },
      {
        q: "How many territories are on the map?",
        a: "56: the lower 48 with the crowded football states split, California and Florida in three pieces, Texas, Ohio, Pennsylvania, and New Jersey in two, so every franchise starts with a home region."
      },
      {
        q: "Does margin of victory matter?",
        a: "Never. Winning by 1 and winning by 30 both take everything, which is why late upsets feel like earthquakes."
      },
      {
        q: "What is Arcade mode?",
        a: "The original formula: a random team spins a compass direction and attacks the nearest enemy or grabs neutral land, battles play out with real player names and a box score, winners steal a player from the loser, and power ups sit on marked states. Last team standing wins."
      },
      {
        q: "Can my team win after being wiped out?",
        a: "Yes. Getting erased costs land, not life. Win once to inherit an empire, and if you crack the top 8 by week 18 the title is still live."
      }
    ]
  }
};

// src/data/gameContent/college.ts
var COLLEGE_CONTENT = {
  "/cbb-grid": {
    intro: [
      "The College Basketball Grid is a daily 3x3 puzzle about who suited up where. Rows are programs like Kentucky, Kansas or Indiana. Columns are career achievements: 1,500 career points, 700 rebounds, 350 assists, 120 games, a position, or an era. Each of the nine cells needs one player who satisfies both.",
      "It is built on nearly 40,000 college careers across 407 programs, and every crossing on the board has at least ten real answers behind it, so no cell is a dead end. That floor is checked against the live data rather than assumed.",
      "One grid a day, the same for everyone, nine guesses. A fresh board arrives at midnight Eastern, and unlimited mode deals a new one whenever you want another."
    ],
    headings: {
      howToPlay: "How to play College Basketball Grid, a free daily hoops puzzle",
      rules: "College Basketball Grid rules for rows, columns and guesses",
      example: "College Basketball Grid walkthrough: Calbert Cheaney fills Indiana",
      tips: "College Basketball Grid tips for scanning columns and guesses",
      faq: "College Basketball Grid FAQ: schools, achievements and daily resets"
    },
    howToPlaySections: [
      {
        heading: "Tapping a cell to see its requirements",
        items: [
          "Tap an empty cell. The game names both requirements, like Kentucky plus 1,500+ Career Points."
        ]
      },
      {
        heading: "Typing a name from the suggestion list",
        items: [
          "Type a player name. Suggestions appear after a couple of letters, drawn from the same career database the answers are checked against."
        ]
      },
      {
        heading: "What a correct or wrong pick does",
        items: [
          "Correct picks lock the cell green. Wrong picks flash red and cost a guess."
        ]
      },
      {
        heading: "Spending each player once on the board",
        items: [
          "Each player can only be used once on the board, so a name that fits two cells has to be spent on one."
        ]
      },
      {
        heading: "Filling all nine cells before guesses run out",
        items: [
          "Fill all nine cells or run out of guesses, then share your emoji grid."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Nine guesses to fill the nine cells",
        items: [
          "Nine guesses to fill nine cells. A wrong guess costs a guess and leaves the cell empty."
        ]
      },
      {
        heading: "Matching both the row and the column",
        items: [
          "A cell only accepts a player who satisfies its row and its column at the same time."
        ]
      },
      {
        heading: "Rows are schools and columns are achievements",
        items: [
          "Rows are always schools. Columns are always achievements, never a second school."
        ]
      },
      {
        heading: "Using each name once per board",
        items: [
          "Every name can be used once per board."
        ]
      },
      {
        heading: "The shared daily grid and unlimited mode",
        items: [
          "Daily is the same grid for everybody and saves your progress. Unlimited generates a new grid on demand."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Calbert Cheaney opens Indiana and 1500 points",
        paragraphs: [
          "Say the rows are Indiana, Kentucky and Kansas, and the columns are 1,500+ Career Points, 700+ Career Rebounds and Played in the 1990s. You open on Indiana plus 1,500+ Career Points and type Calbert Cheaney, who scored 2,613 for the Hoosiers between 1989 and 1993. Green."
        ]
      },
      {
        heading: "Choosing between two cells Cheaney could fill",
        paragraphs: [
          "Cheaney also grabbed 710 rebounds, so he would have fitted the middle column too, but each name is spent once, so you have to choose. That is the whole tension of the board: your best answer usually solves more than one cell."
        ]
      },
      {
        heading: "Saving the tightest crossings for last",
        paragraphs: [
          "The 1990s column is the friendliest on the grid, because it takes anyone whose career touched the decade at all. Save the tight crossings, like a rebounding total at a guard heavy program, for while you still have guesses in hand."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Starting with the widest open column",
        items: [
          "Start with the column that fits the most people. Games played and the era columns are far wider than the scoring and rebounding ones."
        ]
      },
      {
        heading: "Matching player archetype to the column",
        items: [
          "Big men solve rebound cells and guards solve assist cells. Match the archetype to the column before you reach for a famous name."
        ],
        subsections: [
          {
            heading: "Why four year players beat one and dones",
            items: [
              "A four year player beats a one and done here. The columns are career totals, so somebody who stayed will clear them and a freshman phenomenon usually will not."
            ]
          }
        ]
      },
      {
        heading: "Spending a shared name on the harder cell",
        items: [
          "If a name fits two cells, spend it on the harder one. The easy cell will have another answer."
        ]
      },
      {
        heading: "Filling in what you already know first",
        items: [
          "Nine guesses for nine cells means there is no budget for guessing. Fill what you know first."
        ]
      }
    ],
    faqs: [
      {
        q: "Why are the columns achievements instead of a second school?",
        a: "Because the data says a school against school board would not work. Professional players change franchises constantly, which is what makes the NBA and NHL grids possible. College players mostly attend one school: among the thirty best represented programs, only 36 pairs share three or more players, and the best pair in the whole set is Utah with Utah State at eight. A school by school college grid would be mostly cells nobody could answer, so this board crosses schools with achievements instead, where the thinnest crossing still holds ten players."
      },
      {
        q: "Which schools can appear?",
        a: "Only programs where every single achievement column has at least ten qualifying players, which works out at 106 of the 407 programs in the data. That list is recomputed from the database rather than kept by hand, so a program that grows into eligibility is included automatically and nothing goes stale."
      },
      {
        q: "How far back does the player pool go?",
        a: "It covers careers across the modern era of college basketball, which is why the era columns exist. Some columns depend on statistics that were not tracked in the earliest years, so the achievements used here are the ones the records support for everybody."
      },
      {
        q: "Does a transfer count for both schools?",
        a: "Yes. Roughly a quarter of the players in the pool suited up for more than one program, and each of those schools counts, which is what makes a transfer a useful answer when a crossing looks thin."
      },
      {
        q: "Is it the same grid for everyone?",
        a: "In daily mode, yes. The board is generated from the date, so every player gets the same nine cells and your progress is saved if you leave and come back. Unlimited mode deals a random board whenever you want one and does not save."
      }
    ]
  },
  "/college-grid": {
    intro: [
      "The College Football Grid is a daily 3x3 puzzle for fans who remember where guys played on Saturdays. Rows are schools like Alabama, LSU or Notre Dame. Columns are positions, the Heisman and draft picks. Each of the 9 cells needs one player who fits both.",
      "If you came looking for a college football grid, this is that idea built on where players went to school. Every answer is checked against our own records: NFL draft picks back to 1936, NFL careers from 1970 on, and every Heisman winner since 1935. The columns run from Quarterback and Defensive Back to Heisman Winner, First Round Pick and Top 5 Pick.",
      "One grid a day, the same for everyone, 15 guesses, and a rarity score for style points. A fresh college football grid game lands every day at midnight Eastern."
    ],
    headings: {
      howToPlay: "How to play College Grid, a free daily football guessing game",
      rules: "College Grid rules for positions, Heisman and draft picks",
      example: "College Grid walkthrough: Derrick Henry solves Alabama",
      tips: "College Grid tips for rarity scores and thin columns",
      faq: "College Grid FAQ: guesses, rarity and repeat players"
    },
    howToPlaySections: [
      {
        heading: "Tapping a cell for its two requirements",
        items: [
          "Tap an empty cell. The game spells out both requirements, like Alabama plus Heisman Winner."
        ]
      },
      {
        heading: "Picking a name from the record backed list",
        items: [
          "Start typing a name and pick him from the list. The list only offers players in our records, and when two players share a name it adds his school or his years so you get the right guy."
        ]
      },
      {
        heading: "What a green or red pick means",
        items: [
          "A pick that fits locks in green with a rarity percentage. A pick the records say doesn't fit flashes red and costs a guess."
        ]
      },
      {
        heading: "When the records cannot settle a pick",
        items: [
          "If the records can't settle it either way, nothing is charged. You see what they do have on him, and you can try someone else."
        ]
      },
      {
        heading: "Filling all nine cells for a Rarity Score",
        items: [
          "Fill all 9 cells or run out of guesses, then share your Rarity Score and emoji grid."
        ],
        subsections: [
          {
            heading: "A new grid every midnight Eastern",
            items: [
              "Come back tomorrow. A new grid arrives at midnight Eastern."
            ]
          }
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Fifteen guesses to fill nine cells",
        items: [
          "You get 15 guesses to fill 9 cells, and correct answers use a guess too."
        ]
      },
      {
        heading: "Matching the row and the column at once",
        items: [
          "A cell only takes a player who matches its row and its column at the same time."
        ]
      },
      {
        heading: "When a guess costs you nothing",
        items: [
          "A guess costs a turn only when the records say no. If they can't tell, it's free."
        ]
      },
      {
        heading: "Spending each player once per grid",
        items: [
          "Each player goes on the board once. Pick someone who's already on your grid and you just get a reminder."
        ]
      },
      {
        heading: "Rows for schools and columns for positions",
        items: [
          "Rows are schools. Columns are one of eight positions (Quarterback, Running Back, Wide Receiver, Tight End, Offensive Lineman, Defensive Lineman, Linebacker, Defensive Back), Heisman Winner, or a draft column: First Round Pick, Top 10 Pick or Top 5 Pick.",
          "Draft columns go by overall pick number. A player drafted twice counts his best pick, and First Round Pick means that pick came inside that year's first round."
        ],
        subsections: [
          {
            heading: "Rarity scores from how common your pick was",
            items: [
              "Each correct answer shows a rarity percentage, the share of players who used the same name there. Your Rarity Score averages your correct cells, and lower is better."
            ]
          }
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Derrick Henry opens Alabama and Heisman Winner",
        paragraphs: [
          "Say the rows are Alabama, Ohio State and LSU, and the columns are Quarterback, Heisman Winner and First Round Pick. You open with Alabama plus Heisman Winner and type Derrick Henry, who won it in 2015. Green, with a rarity percentage next to his name."
        ]
      },
      {
        heading: "Banking Chase Young and saving Joe Burrow for Ohio State",
        paragraphs: [
          "Ohio State plus First Round Pick has plenty of answers, so you bank Chase Young. For LSU plus Quarterback you skip Joe Burrow, since everybody types him, and go with JaMarcus Russell, the first overall pick in 2007. Burrow still has a job, though: our records have him at Ohio State too, so he fills Ohio State plus Quarterback."
        ]
      },
      {
        heading: "Jalen Hurts closes out a nine for nine board",
        paragraphs: [
          "Alabama plus Quarterback goes to Jalen Hurts, who the records have at Alabama as well as Oklahoma. Two picks come back red along the way because the records say they don't fit, and those cost a guess each. You close the rest with names you're sure of and finish 9 for 9 with guesses to spare."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Fighting the obvious first instinct",
        items: [
          "Fight the first instinct. The obvious name is the one everyone types, and rarity rewards the road less traveled."
        ]
      },
      {
        heading: "Heisman Winner as the tightest column",
        items: [
          "Heisman Winner is the tightest column on the board. There's one winner a year, so even the big programs only have a handful."
        ]
      },
      {
        heading: "Where First Round Pick beats the deeper rounds",
        items: [
          "First Round Pick is usually the roomiest draft column. Top 10 Pick and Top 5 Pick get thin fast."
        ]
      },
      {
        heading: "Transfers and spending a name on the harder cell",
        items: [
          "Players who changed schools count for every school our records have them at, which can open up a thin cell.",
          "Each player goes on the board once, so if a name fits two cells, spend him on the harder one."
        ]
      }
    ],
    faqs: [
      {
        q: "How is this different from the NFL grid?",
        a: "Same 3x3 bones, different angle. The NFL grid asks which team a player suited up for. This one asks where he went to school, crossed with his position, the Heisman or where he went in the draft."
      },
      {
        q: "Why didn't that guess cost me anything?",
        a: "A guess only costs a turn when our records say no. If they can't settle it, like a player with no position on file, you get a note saying what they do have on him and your guess count stays put. A school we don't have him at is never charged either, because our records of players moving between schools aren't complete."
      },
      {
        q: "What does the rarity percentage mean?",
        a: "The share of players who answered that cell with the same name. 3 percent means almost nobody thought of your guy. Lower averages make better Rarity Scores."
      },
      {
        q: "Can I use the same player in more than one cell?",
        a: "No. Each player goes on the board once. Joe Burrow can fill LSU plus Quarterback or Ohio State plus Quarterback, but not both."
      },
      {
        q: "What counts as a position?",
        a: "The spots the draft, roster and college stat records list him at. Some players are listed at two, and then either one counts: Chase Young fits Ohio State plus Defensive Lineman and Ohio State plus Linebacker. Scott Frost played quarterback at Nebraska and defensive back in the NFL, so he fits Nebraska plus Quarterback and Nebraska plus Defensive Back."
      },
      {
        q: "Do I need an account?",
        a: "No. A free account is optional and only matters for keeping your stats."
      }
    ]
  },
  "/guess-the-college": {
    intro: [
      "Somewhere in Division 1 there is one school the game has in mind, and your job is to name it before the clues run out. You start with a single vibe word and end, if it goes badly, at the school colors.",
      "Guess early and look like a savant, or ride to clue 11 and scrape out 100 points."
    ],
    headings: {
      howToPlay: "How to play Guess The College, a free daily college trivia game",
      rules: "Guess The College rules: clues, points and skips",
      example: "Guess The College walkthrough: an SEC clue leads to LSU",
      tips: "Guess The College tips for reading clues and saving points",
      faq: "Guess The College FAQ: modes, difficulty and daily resets"
    },
    howToPlaySections: [
      {
        heading: "Reading the first vibe word clue",
        items: [
          "Read clue 1, a one word vibe for the mystery school."
        ]
      },
      {
        heading: "Typing a guess at any time",
        items: [
          "Type a guess anytime. The school name, a nickname, or the mascot all count."
        ]
      },
      {
        heading: "Where a miss or a skip leads next",
        items: [
          "A wrong guess or a Skip reveals the next clue. There are 11 in all, then the answer."
        ],
        subsections: [
          {
            heading: "How points drop as the clues stack",
            items: [
              "Points drop as clues stack: 1200 on clue 1, 1000 on clue 2, then 100 less per clue down to 100."
            ]
          }
        ]
      },
      {
        heading: "Choosing a mode and a difficulty",
        items: [
          "Pick Daily, Unlimited with a streak counter, or Conference mode, and set Easy (Power 4) or Hard (all of Division 1)."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "The fixed order of all eleven clues",
        items: [
          "The 11 clues follow a fixed order, from vibe and region through conference and sports history to the school colors."
        ]
      },
      {
        heading: "A wrong guess costs the same as a skip",
        items: [
          "A wrong guess costs the same as a skip, one clue. A wrong guess on clue 11 ends the run."
        ]
      },
      {
        heading: "The daily school and its midnight flip",
        items: [
          "The daily school comes from the Power 4 pool and flips at midnight Eastern."
        ]
      },
      {
        heading: "Earning streak badges in unlimited mode",
        items: [
          "Unlimited streaks earn badges at 3, 5, and 10 straight."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Working through the SEC clue to LSU",
        paragraphs: [
          "You skip the early clues. Clue 5 says SEC, so you swing on Georgia. Red. Clue 6 is basketball history, skip. Then clue 7 counts four poll era football titles and talks up the 2019 team and it clicks: LSU."
        ]
      },
      {
        heading: "Five hundred points for a clean save",
        paragraphs: [
          "The card flips: 500 points for solving on clue 7, plus a fun fact about the school. Not the hero guess, but a clean save."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Guessing on a hunch instead of skipping",
        items: [
          "Never skip when you have a hunch. A guess costs the same clue and might just be right."
        ]
      },
      {
        heading: "The conference clue as the pivot point",
        items: [
          "Clue 5, the conference, is the pivot. Run the whole league in your head before the points drop again."
        ]
      },
      {
        heading: "Letting school colors settle it at the end",
        items: [
          "Still alive at clue 11? Colors settle it. Crimson and cream is not scarlet and gray."
        ]
      }
    ],
    faqs: [
      {
        q: "What is the difference between Easy and Hard?",
        a: "Easy sticks to Power 4 schools; Hard opens all of Division 1 for Unlimited and Conference play. The daily always uses Power 4."
      },
      {
        q: "Does a wrong guess hurt more than skipping?",
        a: "No. Either way you move one clue down the point ladder."
      },
      {
        q: "When does the daily school change?",
        a: "At midnight Eastern, and everyone gets the same school. Progress is saved in your browser, so you can finish later that day."
      }
    ]
  },
  "/guess-cbb-team": {
    intro: [
      "One college basketball program is hiding behind six locked clues, and the points shrink with every clue you need. Solve it off the vibe word for 1000, or limp home at the mascot clue for 100.",
      "The pool spans blue bloods like Duke, Kentucky, and Kansas and mid-major regulars like Gonzaga, so do not assume a power conference. Play the shared daily or keep pulling programs in unlimited."
    ],
    headings: {
      howToPlay: "How to play Guess The CBB Program, a free daily basketball trivia game",
      rules: "Guess The CBB Program rules for clues and points",
      example: "Guess The CBB Program walkthrough: three guesses to Kansas",
      tips: "Guess The CBB Program tips for clues and guessing fast",
      faq: "Guess The CBB Program FAQ: guesses, scoring and daily play"
    },
    howToPlaySections: [
      {
        heading: "Starting with a single vibe word clue",
        items: [
          "Start with clue 1, a single vibe word for the program."
        ]
      },
      {
        heading: "Typing a guess with autocomplete help",
        items: [
          "Type a guess. Autocomplete pulls from the full program list, and common short names count."
        ]
      },
      {
        heading: "What each wrong guess unlocks next",
        items: [
          "Every wrong guess unlocks the next clue: region and state, conference, tournament history, championships, then the mascot."
        ],
        subsections: [
          {
            heading: "Why guessing sooner pays more points",
            items: [
              "Guess sooner for more points, from 1000 on clue 1 down to 100 on clue 6."
            ]
          }
        ]
      },
      {
        heading: "Choosing Daily Challenge or Unlimited",
        items: [
          "Pick Daily Challenge for the shared puzzle or Unlimited for a random program every time."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Six clues worth six different point totals",
        items: [
          "There are 6 clues, worth 1000, 800, 600, 400, 200, and 100 points in order."
        ]
      },
      {
        heading: "At most six guesses before the game ends",
        items: [
          "Each wrong guess reveals the next clue, so you get at most 6 guesses. A wrong answer on clue 6 ends the game."
        ]
      },
      {
        heading: "What Give Up does to your score",
        items: [
          "Give Up shows the answer and scores zero."
        ]
      },
      {
        heading: "The same daily puzzle for everyone",
        items: [
          "A new daily puzzle arrives every day, the same for everyone."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Burning three guesses on the plains",
        paragraphs: [
          "Clue 1 hands you a vibe word that could mean anything, so you fire a guess to open the region clue. It points to the plains. Kansas State feels right. Wrong, and clue 3 says Big 12. Baylor. Wrong again, so you spend one more miss on Texas Tech."
        ]
      },
      {
        heading: "Four national titles point to Kansas",
        paragraphs: [
          "That unlocks clue 5, championships, and it mentions four national titles. There is the fingerprint: Kansas. Correct on clue 5 banks 200 points, and the mascot clue never gets used."
        ]
      }
    ],
    tipSections: [
      {
        heading: "No skip button, so every guess must count",
        items: [
          "There is no skip button. A wrong guess is the only key to the next clue, so make every guess a real one."
        ]
      },
      {
        heading: "Championship counts as a fingerprint clue",
        items: [
          "Championship counts are fingerprints. Few programs share the same number of banners."
        ]
      },
      {
        heading: "Reciting a league's heavyweights at the conference clue",
        items: [
          "When the conference clue lands, recite that league's heavyweights before you type."
        ]
      }
    ],
    faqs: [
      {
        q: "How many guesses do I get?",
        a: "Up to 6, one per clue. Guess right at any point and you score whatever that clue is worth."
      },
      {
        q: "Is the daily the same for everyone?",
        a: "Yes, one shared program per day, so scores compare fairly. Unlimited deals random programs for practice."
      },
      {
        q: "What kinds of programs show up?",
        a: "Programs with real basketball pedigree, from championship blue bloods to mid-majors with March credentials."
      }
    ]
  },
  "/cfb-higher-lower": {
    intro: [
      "Two quarterbacks, one question: who threw for more career passing yards in college? Not the NFL, college. That flip is the whole game, because the record books belong to four-year starters in pass-happy systems, not the legends you watched on Sundays.",
      "Tom Brady left Michigan with 4,773 yards. Case Keenum left Houston with 19,217, the record. Every pair is a little logic puzzle about eras, offenses, and who actually held the job."
    ],
    headings: {
      howToPlay: "How to play CFB Higher or Lower, a free college football trivia game",
      rules: "CFB Higher or Lower rules for rounds, streaks and ties",
      example: "CFB Higher or Lower walkthrough: Case Keenum tops Tom Brady",
      tips: "CFB Higher or Lower tips for spotting the real passing leader",
      faq: "CFB Higher or Lower FAQ: streaks, ties and daily pairs"
    },
    howToPlaySections: [
      {
        heading: "Reading each quarterback pair",
        items: [
          "Look at the two quarterbacks, their schools, and the years they played."
        ]
      },
      {
        heading: "Tapping the higher passing total",
        items: [
          "Tap the one you think threw for more career college passing yards."
        ]
      },
      {
        heading: "Seeing both totals before the next pair",
        items: [
          "Both totals flash for a couple of seconds, then the next pair loads."
        ],
        subsections: [
          {
            heading: "Protecting a streak across ten rounds",
            items: [
              "Play all 10 rounds and protect your streak for bonus points."
            ]
          }
        ]
      },
      {
        heading: "Daily pairs versus Unlimited and Hard mode",
        items: [
          "Daily gives everyone the same 10 pairs. Unlimited deals random pairs; its Hard toggle picks close-gap pairs."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Ten points for every correct round",
        items: [
          "10 rounds, 10 points per correct answer."
        ]
      },
      {
        heading: "How the streak bonus keeps growing",
        items: [
          "Streaks pay a growing bonus: the second straight correct adds 5 extra, the third 10, the fourth 15, and so on. A miss resets the ladder."
        ]
      },
      {
        heading: "A perfect run scores the max",
        items: [
          "A perfect 10 for 10 scores 325, the max."
        ]
      },
      {
        heading: "Ties always count as correct",
        items: [
          "Ties count as correct no matter which side you pick."
        ]
      },
      {
        heading: "The daily set and where Hard mode lives",
        items: [
          "The daily set flips at midnight Eastern. Hard mode lives in Unlimited only."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Refusing the Tom Brady bait for Case Keenum",
        paragraphs: [
          "Round 1 pairs Tom Brady with Case Keenum and you refuse the bait: 19,217 buries 4,773. The next three land too, worth 15, 20, and 25 as the streak grows."
        ]
      },
      {
        heading: "A coin flip miss resets the ladder",
        paragraphs: [
          "Round 5 is two system guys you cannot separate, and the coin flip misses. Ladder reset. You grind out four of the last five and finish 8 of 10 for 140 points."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Career length beats fame every time",
        items: [
          "Length of career beats fame. A four-year starter in an air raid out-throws a two-year phenom nearly every time."
        ]
      },
      {
        heading: "Checking the years before you tap",
        items: [
          "Check the years. Passing totals ballooned through the 2000s and 2010s, so an older great can trail a modern system guy."
        ]
      },
      {
        heading: "Why NFL fame is a trap here",
        items: [
          "NFL resumes are traps. Plenty of famous pros sat early, split snaps, or ran the ball in college."
        ]
      }
    ],
    faqs: [
      {
        q: "What happens on a tie?",
        a: "You get credit either way, whichever side you picked."
      },
      {
        q: "How does the streak bonus work?",
        a: "Each correct answer is 10 points. Consecutive correct answers add a bonus that grows by 5 each step, so one long run beats scattered singles. A perfect game hits 325."
      },
      {
        q: "Are the passing yard totals real?",
        a: "Yes, career college passing yards under the official NCAA counting convention, which is why some famous names look small."
      }
    ]
  },
  "/cfb-dynasty": {
    intro: [
      "CFB Dynasty hands you a real college football program and an open-ended job: win now, recruit forever, stack championships. The 44 schools are real. The players are not: every athlete is a generated recruit with a class year, so rosters age and churn.",
      "Each season runs into conference championships and the 12-team Playoff, then an NIL and portal offseason before you run it back."
    ],
    headings: {
      howToPlay: "How to play CFB Dynasty, a free college football GM sim",
      rules: "CFB Dynasty rules for the Playoff, NIL and recruiting",
      example: "CFB Dynasty walkthrough: Boise State chases a title run",
      tips: "CFB Dynasty tips for the portal and the recruiting board",
      faq: "CFB Dynasty FAQ: saves, real players and Group of Five teams"
    },
    howToPlaySections: [
      {
        heading: "Picking a program by its prestige rating",
        items: [
          "Pick a program. Its prestige rating drives your talent pipeline and NIL budget."
        ]
      },
      {
        heading: "Playing one week of the season at a time",
        items: [
          "Play one week at a time: 12 games, weeks 1 to 4 out of conference, weeks 5 to 11 in it, and week 12 is rivalry week.",
          "Week 12 is rivalry week, and every program plays its rival, even one from another conference. Your rival is a school from your own state when one is free to pair with you, otherwise a pairing the game made, and the game tells you which. Florida has three schools on the board, so Florida and Miami get each other and Florida State gets a pairing the game made.",
          "The rivalry winner carries 0.5 to 1.5 points of extra strength into the title games and the Playoff, the loser drops the same, and a margin of 21 or more swings the full 1.5."
        ]
      },
      {
        heading: "Reaching the conference title game",
        items: [
          "Finish top two in your conference to reach its title game; win it for an automatic Playoff bid.",
          "The conference table goes by conference winning percentage, not raw wins, because not everyone plays the same number of league games: a program whose rival is in another conference spends week 12 outside the league."
        ],
        subsections: [
          {
            heading: "Surviving the twelve team Playoff bracket",
            items: [
              "Survive the 12-team bracket, single elimination from the first round to the national championship."
            ]
          }
        ]
      },
      {
        heading: "Spending NIL points on recruits and the portal",
        items: [
          "Spend NIL points across an 18-player high school board and an 8-player portal, then start the next season.",
          "The same offseason screen holds your two coordinators, one for the offense and one for the defense. Each moves his side of the ball by up to 3 rating points either way: 70 is neutral, 95 is the full plus 3, 45 the full minus 3, and an empty chair is called by a grad assistant who counts as a 50.",
          "In a game each side scores 1.5 more points for every point its offensive coordinator's edge beats the other side's defensive coordinator's.",
          "Keep your coordinators, let one go and get his pay back, or shop three candidates per chair, one rated below your program's level, one around it and one above it. A hire costs the difference between his pay and the pay of the man he replaces, and is refused if the pot cannot cover it.",
          "A coordinator rated 85 or better can be hired away as a head coach after any season, and his chair stays empty until you fill it."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Twelve teams make the Playoff field",
        items: [
          "The Playoff field is 12: the 5 conference champions plus 7 at-larges, seeded by ranking, byes for the top four.",
          "On the same record the better resume ranks higher: strength of schedule, the average strength of every opponent actually played, title game included, plus the team's own strength. The 7 at-large spots and the seeds come off that ranking, and the Schedule tab shows your number and where it ranks."
        ]
      },
      {
        heading: "Scouting error on high school grades",
        items: [
          "High school grades carry scouting error of up to 4 points either way. Portal transfers show true ratings and arrive as sophomores."
        ]
      },
      {
        heading: "How the NIL budget resets each offseason",
        items: [
          "NIL resets each offseason from prestige plus wins, and every signing spends against it.",
          "Rivalry week moves that budget: a win adds 3 to 8 points and a loss takes 3 to 8 away, with a margin of 21 or more swinging the full 8.",
          "Your two coordinators are paid first out of the same budget, from 3 points a season for a 45 to 16 for a 95, and what is left is your NIL money. If the budget cannot cover them, the dearest walks until it can."
        ]
      },
      {
        heading: "Seniors graduating and juniors declaring early",
        items: [
          "Seniors graduate and juniors rated 88 or higher often declare early."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Boise State runs the table for an automatic bid",
        paragraphs: [
          "You take Boise State, prestige 78. One September loss, then you run the league, finish 11-1, and win the conference title game for the automatic bid.",
          "Week 12 is rivalry week against Tulane, a pairing the game made because no other Idaho school is on the board. You win it by 24, so Boise State carries 1.5 extra points of strength into the title game and the Playoff, and the trail opens with 8 more budget points."
        ]
      },
      {
        heading: "A junior quarterback declares after the semifinal",
        paragraphs: [
          "You win a first-round game, stun a bye team in the quarterfinals, and lose the semifinal. Then your 89-rated junior quarterback declares, so you sign a portal passer rated exactly 81 and roll the dice on a 5-star scouted at 83 who might really be a 79. Or an 87."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Portal needs versus high school ceilings",
        items: [
          "Shop the portal for needs, the high school board for ceilings. Transfers are exactly as rated; freshmen develop longest."
        ]
      },
      {
        heading: "Never starting a season without a real quarterback",
        items: [
          "Never enter a season without a real quarterback; the sim weighs your starter heavily."
        ]
      },
      {
        heading: "Recruiting to the holes the offseason notes list",
        items: [
          "Recruit to the holes. The offseason notes list who graduated and who declared."
        ]
      }
    ],
    faqs: [
      {
        q: "Are the players real athletes?",
        a: "No. Schools and format are real; every player is fictional."
      },
      {
        q: "Does my dynasty save?",
        a: "Yes, automatically, in your browser, one slot. The fire yourself button wipes it for good."
      },
      {
        q: "Can a Group of Five team win it all?",
        a: "Yes. Its champion is one of the 5 automatic qualifiers, and single elimination does not care about prestige."
      }
    ]
  },
  "/cbb-dynasty": {
    intro: [
      "CBB Dynasty is the college hoops program sim: 40 real schools, six leagues, fictional players, and a season built to set up March. You can have the best roster in the country and still lose everything in one bad night.",
      "Six leagues cover the sport, from the ACC and Big East to a Mid-Major group built for Cinderella runs. The one-and-done era means your best freshman is probably a rental."
    ],
    headings: {
      howToPlay: "How to play CBB Dynasty, a free college basketball GM sim",
      rules: "CBB Dynasty rules for March, seeding and early departures",
      example: "CBB Dynasty walkthrough: a thirteen seed crashes the Final Four",
      tips: "CBB Dynasty tips for recruiting and mid major runs",
      faq: "CBB Dynasty FAQ: real players, Cinderella runs and March"
    },
    howToPlaySections: [
      {
        heading: "Picking one of forty real programs",
        items: [
          "Pick one of 40 programs. Prestige sets your pipeline and NIL power."
        ]
      },
      {
        heading: "Playing two games in every round",
        items: [
          "Play 10 rounds of two games each, one league matchup and one cross-country test.",
          "Round 10's league night is rivalry night, and every program plays its rival, even one from another league. Your rival is a school from your own state when one is free to pair with you, otherwise a pairing the game made, and the game tells you which. Duke and North Carolina, Kentucky and Louisville, and Purdue and Indiana are in-state games; UConn has no state on file here, so its rival is a pairing the game made.",
          "The rivalry winner carries 0.5 to 1.5 points of extra strength into the conference tournament and March, the loser drops the same, and a margin of 25 or more swings the full 1.5."
        ]
      },
      {
        heading: "Dancing automatically as a tournament champion",
        items: [
          "Finish top four in your league for the conference tournament; win it and you dance automatically."
        ],
        subsections: [
          {
            heading: "Surviving five rounds of March",
            items: [
              "Survive March: 32 teams, single elimination, five rounds from the Round of 32 to the title game."
            ]
          }
        ]
      },
      {
        heading: "Recruiting each spring from two boards",
        items: [
          "Recruit each spring from a 14-player high school board and a 7-player portal, then run it back.",
          "The same offseason screen holds your two assistant coaches, one for the offense and one for the defense. Each moves his end of the floor by up to 3 rating points either way: 70 is neutral, 95 is the full plus 3, 45 the full minus 3, and an empty chair is covered by a grad assistant who counts as a 50.",
          "In a game each side scores 1.5 more points for every point its offensive assistant's edge beats the other side's defensive assistant's.",
          "Keep your assistants, let one go and get his pay back, or shop three candidates per chair, one rated below your program's level, one around it and one above it. A hire costs the difference between his pay and the pay of the man he replaces, and is refused if the pot cannot cover it.",
          "An assistant rated 85 or better can be hired away as a head coach after any season, and his chair stays empty until you fill it.",
          "Your NIL budget each spring comes from prestige plus wins, and rivalry night moves it: a win adds 3 to 8 points and a loss takes 3 to 8 away, with a margin of 25 or more swinging the full 8.",
          "Your two assistants are paid first out of that budget, from 3 points a season for a 45 to 16 for a 95, and what is left is your NIL money. If the budget cannot cover them, the dearest walks until it can."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Thirty two teams make the March field",
        items: [
          "The field is 32 teams: six tournament champions plus 26 at-larges, seeded 1 through 32 by record first, strength second.",
          "The committee also reads strength of schedule, the average strength of every regular season opponent you actually played, and weighs it the same as the eye test, so on the same record and the same strength the tougher schedule ranks higher. The 26 at-large bids and the seeds come off that ranking, and the Schedule tab shows your number and where it ranks."
        ]
      },
      {
        heading: "When freshmen go one and done",
        items: [
          "Freshmen rated 88 or higher go one-and-done almost every time, upperclassmen rated 90 or higher often declare, and seniors graduate."
        ]
      },
      {
        heading: "High school grades carry real scouting error",
        items: [
          "High school grades can be off by up to 4 points either way; portal players show true ratings and arrive as sophomores."
        ]
      },
      {
        heading: "Cinderella runs and automatic browser saves",
        items: [
          "A Cinderella flag fires when a 10 seed or worse crashes the Final Four. Saves are automatic in your browser."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "VCU sneaks into the conference tournament",
        paragraphs: [
          "You take VCU, prestige 79. The season is bumpy, but you sneak into the league's top four, win both tournament games, and grab the automatic bid.",
          "Round 10's league night is rivalry night against Dayton, a pairing the game made since the board has no state on file for either school. You win it by 27, so VCU carries 1.5 extra points of strength into the league tournament and March, and the trail opens with 8 more budget points."
        ]
      },
      {
        heading: "A thirteen seed crashes the Final Four",
        paragraphs: [
          "March seeds you 13th. You win a nervy opener, shock a top-four seed in the Sweet 16, and crash the Final Four, earning the Cinderella tag. The semifinal ends it. Then your 90-rated sophomore declares, and NIL has to rebuild half a rotation."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Signing the elite freshman anyway",
        items: [
          "Sign the 88-plus freshman anyway. One superstar season is how March gets survived; just plan the replacement early."
        ]
      },
      {
        heading: "Stacking your starting five first",
        items: [
          "Your top five carries three quarters of team strength, so stack the starting lineup first."
        ]
      },
      {
        heading: "Why mid majors live through the league tournament",
        items: [
          "Mid-major life runs through the league tournament: win it and at-large math never matters."
        ]
      }
    ],
    faqs: [
      {
        q: "Are these real players?",
        a: "No. The programs are real, the players fictional."
      },
      {
        q: "What counts as a Cinderella?",
        a: "A 10 seed or worse in the Final Four. The recap calls it out by seed and school."
      },
      {
        q: "Can I miss March entirely?",
        a: "Yes. Only 32 of 40 make the field, and the recap will read Missed the field."
      }
    ]
  }
};

// src/data/gameContent/basketball.ts
var BASKETBALL_CONTENT = {
  "/buzzer-beater": {
    intro: [
      "Most of this site asks you a question. This one asks you to make the shot. Ten jump shots, you back up on every single one, and there is a hand coming at you on nine of them.",
      "The whole game is the arc. A basket is a hole you drop the ball into from above, so how steeply the ball arrives decides how much room it has. Come in flat and there is almost nothing to go through. Come in steep and there is room, but you have to throw it harder to get there, and a hard release goes where it wants rather than where you pointed it."
    ],
    headings: {
      howToPlay: "How to play Buzzer Beater, a free NBA jump shot arcade game",
      rules: "Buzzer Beater rules for the arc, the bar and the hand",
      example: "Buzzer Beater walkthrough: a free throw and a contested shot",
      tips: "Buzzer Beater tips for arc, fade and release strength",
      faq: "Buzzer Beater FAQ: daily shots, controls and the physics"
    },
    howToPlaySections: [
      {
        heading: "Dialing in the shot arc",
        items: [
          "Set the arc with the up and down arrows, or by dragging up and down on the court. The readout shows the angle you are shooting at."
        ]
      },
      {
        heading: "Fading off the defender's hand",
        items: [
          "Fade off the closeout with left and right. The ring in the corner shows where you are pointing across the hoop."
        ]
      },
      {
        heading: "Charging the release before you let go",
        items: [
          "Hold space, or hold the shoot button, to load the strength bar, and let go. The bar sweeps up and down and you get the number you release on."
        ]
      },
      {
        heading: "Ten shots with the hand climbing higher",
        items: [
          "Ten shots a run, from the free throw line out past the arc, with a higher hand in your face every time."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "The ring, the ball and the shrinking window",
        items: [
          "The ring is 18 inches across on the inside and the ball is a little under 9 and a half, which is the real difference and the reason arc matters. Seen along your shot the ring keeps its width but loses its depth, so the room you have to be short or long shrinks as the shot flattens and runs out entirely near 32 degrees."
        ]
      },
      {
        heading: "The strength bar has no single sweet spot",
        items: [
          "The strength bar is absolute, not a percentage of what this shot needs. The right place to stop it is different from the free throw line than it is from the arc, so there is no single spot that works all night."
        ],
        subsections: [
          {
            heading: "Why a hard release sprays the shot",
            items: [
              "A hard release sprays. It costs you accuracy side to side and a little pace either way, and the cost grows faster than the strength does, so the top of the bar is where the misses live."
            ]
          }
        ]
      },
      {
        heading: "Going over the hand or fading around it",
        items: [
          "The hand only blocks what stays low. Go over it, or fade off it, and either way you have given something up to do it."
        ]
      },
      {
        heading: "How each basket gets scored",
        items: [
          "Baskets pay by distance, by the hand you shot over and by how cleanly the ball went through. A free throw pays least."
        ]
      },
      {
        heading: "Daily shots versus unlimited practice",
        items: [
          "The daily deals the same ten shots to everyone and keeps your score for the day. Unlimited deals fresh ones for ever."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "A free throw with nobody in your face",
        paragraphs: [
          "Shot one is a free throw with nobody near you. It only needs a gentle release, so a big arc costs you nothing: put it up around 60 degrees, stop the bar low, and the ball comes down almost on top of the ring with plenty of room."
        ]
      },
      {
        heading: "A far shot with a hand closing in",
        paragraphs: [
          "Shot ten is 8.6 metres out with a hand reaching over three metres, closing to within a metre of you. That same 60 degree arc now has to be thrown hard enough to spray, so flatten it a little, clear the hand by the smallest margin you dare, and accept that this one is close to a coin flip. It is also worth about three times what the free throw paid."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Go high from close, flatten out further back",
        items: [
          "High from close, flatter as you back up. It is the opposite of what feels right, and it is the single biggest thing to learn here."
        ]
      },
      {
        heading: "Trust the dashed line and the angle readout",
        items: [
          "Read the dashed line before you load the bar. It shows the shape this release would take with nothing going wrong, so if it is already passing under the ring, fix the arc rather than hoping.",
          "The angle readout after every shot is the honest feedback. Anything under about 40 degrees was never going in, however well you aimed it."
        ]
      },
      {
        heading: "Fading only when you truly have to",
        items: [
          "Fading is expensive. Only fade when the hand is genuinely too high to go over, because every centimetre of fade is a centimetre off the middle of the ring."
        ]
      }
    ],
    faqs: [
      { q: "Is the daily the same for everyone?", a: "Yes. The ten shots come from the date, so every player gets the same run, and your score is kept for the day." },
      { q: "Do I need a keyboard?", a: "No. Drag the court to set the arc and the fade, then let go to shoot, which works the same on a phone." },
      { q: "Why did a shot that looked perfect rattle out?", a: "Almost always the angle. Check the entry number on the result: a flat shot is aiming at a slot rather than a hole, and there is barely a centimetre in it." },
      { q: "Is the physics real?", a: "The flight and the rim geometry are, and so are the rim, ball and release heights. The tolerances are widened on purpose, because nobody hits a centimetre with a sweeping bar and a thumb." }
    ]
  },
  "/perfect-season-nba": {
    intro: [
      "The wheel owns your draft board. Every spin stops on a real NBA team season, 1950s to today, and you take exactly one player from that roster.",
      "Six picks build a cross era starting five plus a sixth man, then the simulator plays all 82 games. The name says 82-0, but the real chase is the best record you can post, and every result prints your odds of going unbeaten."
    ],
    headings: {
      howToPlay: "How to play 82-0 NBA Perfect Season, a free online draft simulator",
      rules: "82-0 NBA Perfect Season rules: spins, rerolls and the simulated playoffs",
      example: "82-0 NBA Perfect Season walkthrough: a Lakers spin and a playoff run",
      tips: "82-0 NBA Perfect Season tips for drafting a title worthy roster",
      faq: "82-0 NBA Perfect Season FAQ: daily mode, ratings and going undefeated"
    },
    howToPlaySections: [
      {
        heading: "Choosing Classic, Hard or Daily mode",
        items: [
          "Choose a mode. Classic shows player ratings, Hard hides them until the sim ends, and Daily gives everyone the same wheel with one attempt per day."
        ]
      },
      {
        heading: "Drafting one player per spin",
        items: [
          "Spin, then draft one player from the team season you land on. Ratings run 40 to 99 and come from the player's actual stats that year."
        ]
      },
      {
        heading: "Filling six roster slots",
        items: [
          "Repeat until all six slots are filled: PG, SG, SF, PF, C and a sixth man who can be anyone."
        ]
      },
      {
        heading: "Playing out the season or skipping ahead",
        items: [
          "Watch the season play out, or skip straight to the final record."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Spin limits and no repeat picks",
        items: [
          "One player per spin, 2 rerolls per run, and no player can be drafted twice."
        ]
      },
      {
        heading: "How the season plays out",
        items: [
          "The sim plays a full 82 game season based on your team overall."
        ],
        subsections: [
          {
            heading: "Reaching the simulated playoffs",
            items: [
              "Win 55 games or more to reach the simulated playoffs."
            ]
          }
        ]
      },
      {
        heading: "Daily mode's single attempt",
        items: [
          "Daily mode locks after one attempt and resets every day at midnight Eastern."
        ]
      },
      {
        heading: "Decade Mode versus the full wheel",
        items: [
          "Decade Mode limits every spin to one era. Daily always uses the full wheel."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "A first spin on a classic Lakers season",
        paragraphs: [
          "Your first spin lands on the 1986-87 Lakers, so you take the best guard available. Four spins later your overall sits at 88."
        ]
      },
      {
        heading: "A hot start that stalls in the Conference Finals",
        paragraphs: [
          "You finish at 88 overall. The sim opens 14-0, cools off after the break and closes 69-13, then you sweep the First Round and fall in the Conference Finals. At 88 an 82-0 comes about one run in 110 million, so 69 wins is the brag."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Sixth man rating carries less weight",
        items: [
          "The sixth man slot counts slightly less toward your overall, so park your weakest pick there."
        ]
      },
      {
        heading: "Ratings reward one big season, not a career",
        items: [
          "Ratings reflect single seasons, not careers. One giant year can outrate a legend's farewell season."
        ]
      },
      {
        heading: "What an 85 overall team usually wins",
        items: [
          "An 85 overall team averages around 58 wins. A 95 goes 82-0 about one run in 600 and a 99 about one in five, and the wheel almost never deals a 95, so most drafts land in the mid 80s where 82-0 does not happen. The chase is the win total, not perfection."
        ]
      }
    ],
    faqs: [
      { q: "Is 82-0 actually possible?", a: "Yes, but barely. Even a 99 overall lineup averages about 80 wins, so you need a monster draft and a lucky sim on the same run." },
      { q: "Where do the ratings come from?", a: "Ratings come from the player's real points, rebounds and assists per 36 minutes that season, adjusted slightly for the era's pace." },
      { q: "What happens after the regular season?", a: "55 wins or more triggers a simulated bracket, four best of 7 rounds through the NBA Finals, with a Finals MVP from your roster if you win it all." }
    ]
  },
  "/stat-detective": {
    intro: [
      "Somewhere in the NBA record books there is a season with the name scrubbed off. You get the decade, the position and the per 36 minute stat line. That is the whole case file.",
      "Name the player within 8 guesses. Clues drip out as you miss, and the pool runs from all time greats to guys only real heads remember."
    ],
    headings: {
      howToPlay: "How to play Stat Detective, an NBA player guessing game",
      rules: "Stat Detective rules for clues, guesses and the case file",
      example: "Stat Detective walkthrough: cracking a case with two clues",
      tips: "Stat Detective tips for reading stat lines like a detective",
      faq: "Stat Detective FAQ: difficulty, clues and how cases repeat"
    },
    howToPlaySections: [
      {
        heading: "Choosing Stars or Deep Cuts difficulty",
        items: [
          "Pick a difficulty. Stars is famous seasons rated 85 or higher, Deep Cuts covers starters and cult heroes rated 60 to 84."
        ]
      },
      {
        heading: "Reading the case file's stat line",
        items: [
          "Read the case file: era, position, minutes played, and points, rebounds and assists per 36 minutes."
        ]
      },
      {
        heading: "Typing a name and picking a suspect",
        items: [
          "Type 2 or more letters and pick a player from the suggestions."
        ],
        subsections: [
          {
            heading: "How each miss unlocks a new clue",
            items: [
              "Each miss unlocks a new clue, starting with the player's career span."
            ]
          }
        ]
      },
      {
        heading: "Closing the case within eight guesses",
        items: [
          "Name the player within 8 guesses to close the case."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Eight guesses to crack the case",
        items: [
          "You get 8 guesses per case."
        ]
      },
      {
        heading: "What a wrong guess still tells you",
        items: [
          "Wrong guesses show whether your guess ever played for the mystery player's franchise."
        ]
      },
      {
        heading: "The clue order from miss to miss",
        items: [
          "Clues unlock after every miss: career span, surname initial, franchise count, team, first initial, then the exact season after miss 6."
        ]
      },
      {
        heading: "When steals and blocks start showing up",
        items: [
          "Steals and blocks only appear on cases from 1973-74 onward, because the league did not track them before that."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "A first guess and the shared franchise chip",
        paragraphs: [
          "The file says 1980s, point guard, 11 assists per 36. Your first guess misses, but the chip says shared franchise, so those two wore the same uniform at some point."
        ]
      },
      {
        heading: "Narrowing it down with the career span clue",
        paragraphs: [
          "Then the career span clue narrows the field to one generation of playmakers. With the franchise hint on top, guess three closes the case."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Doing the era math before you guess",
        items: [
          "Do the era math first. A career span ending in 1991 rules out half your instincts."
        ]
      },
      {
        heading: "Trusting the franchise chip across relocations",
        items: [
          "The franchise chip is quiet gold. Relocations count as the same franchise, so a Sonics guess can match a Thunder mystery."
        ]
      },
      {
        heading: "Watching for pace inflated rebound numbers",
        items: [
          "Big rebound numbers from the 1960s are inflated by pace. Do not assume only legends grabbed 15 boards."
        ]
      }
    ],
    faqs: [
      { q: "Why per 36 minutes instead of per game?", a: "The underlying season data stores totals and minutes, so per 36 rates are the honest version. They also make eras comparable, since a bench player's rate line reads the same as a starter's." },
      { q: "How many cases are there?", a: "Thousands. Every qualifying season from 1951-52 to today is a case candidate, split into Stars and Deep Cuts by season rating." },
      { q: "Does it repeat cases?", a: "Cases draw at random, and the game never serves the same case twice in a row." }
    ]
  },
  "/nba-stat-line": {
    intro: [
      "Someone in NBA history put up this exact line. Your job is to rebuild it from parts: a target of points, rebounds and assists per 36 minutes, a shooting split, and in the modern eras steals and blocks too.",
      "You get five real player seasons, any five you can dig out of the record books. Their combined line is minutes weighted, so a 3,000 minute monster season pulls your blend way harder than a 600 minute cameo."
    ],
    headings: {
      howToPlay: "How to play NBA Stat Line, a daily basketball stat blending game",
      rules: "NBA Stat Line rules for seasons, minutes and the shooting split",
      example: "NBA Stat Line walkthrough: blending a high usage wing's target",
      tips: "NBA Stat Line tips for leverage, archetypes and shooting splits",
      faq: "NBA Stat Line FAQ: modes, minutes and eligible seasons"
    },
    howToPlaySections: [
      {
        heading: "Daily target or Unlimited practice",
        items: [
          "Pick a mode. Daily gives everyone the same target with one scored run per day, Unlimited deals a fresh target every time."
        ]
      },
      {
        heading: "Reading FG%, FT% or 3P% in the target",
        items: [
          "Read the target line. Every number is per 36 minutes, and the shooting split might be FG%, FT% or 3P% depending on the target."
        ]
      },
      {
        heading: "Searching real players and picking a season",
        items: [
          "Search any NBA player and pick one of their real seasons. Each pick shows its own per 36 line so you can see what it adds."
        ]
      },
      {
        heading: "Watching your combined line update live",
        items: [
          "Watch your combined line update as you go. It is the minutes weighted blend of your five picks."
        ]
      },
      {
        heading: "Submitting all five slots for a score",
        items: [
          "Fill all five slots, then submit for a similarity score out of 100."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Five seasons, none repeated",
        items: [
          "Exactly five seasons per run, no season picked twice."
        ]
      },
      {
        heading: "What counts as a qualifying season",
        items: [
          "Only seasons with 500 or more minutes qualify, and combined traded rows do not appear, every pick is a real single team season."
        ]
      },
      {
        heading: "Older eras and stats the league never tracked",
        items: [
          "When the target includes steals or blocks, only seasons from 1973-74 on can be picked, because the league did not track those stats before then. A 3P% target limits picks to 1979-80 on for the same reason."
        ]
      },
      {
        heading: "How the shooting split and final score are built",
        items: [
          "The combined shooting split is recalculated from total makes and attempts across your five picks, never by averaging the five percentages."
        ],
        subsections: [
          {
            heading: "What ninety or better means",
            items: [
              "Each stat scores by how close you land, and the final score is the average across all target stats. 90 or better counts as nailing the line."
            ]
          }
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Chasing a high usage wing's target line",
        paragraphs: [
          "The target reads 24.1 points, 6.0 rebounds, 4.5 assists, 1.3 steals, 0.4 blocks and 48.2 FG% per 36. That smells like a high usage wing, so you grab two scoring guards from the 1990s."
        ]
      },
      {
        heading: "Rounding out the blend to land a 91",
        paragraphs: [
          "Your blend sits at 27 points and only 4 rebounds, too hot and too thin on the glass. You round it out with a glue forward and two mid usage seasons, submit at 24.8 and 5.7, and land a 91."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Using minutes as leverage on the blend",
        items: [
          "Minutes are leverage. If your line is close, add low minute seasons so the blend barely moves; if it is way off, a heavy minute season drags it fastest."
        ]
      },
      {
        heading: "Thinking in scorer, rebounder and connector archetypes",
        items: [
          "Do not chase one stat at a time. Every pick moves all six numbers, so think in archetypes: scorers, rebounders, connectors."
        ]
      },
      {
        heading: "Old big man seasons as rebound rocket fuel",
        items: [
          "Old big man seasons are rebound rocket fuel, 1960s pace inflated boards for everyone. One pick from that era can fix a rebound deficit on its own."
        ]
      },
      {
        heading: "Why attempts drive your final percentage",
        items: [
          "The shooting split blends by attempts, not evenly. A high volume shooter moves your percentage much more than a low volume one at the same clip."
        ]
      }
    ],
    faqs: [
      { q: "Why per 36 minutes instead of per game?", a: "Per game averages need games played, and the historical season data here stores totals and minutes without game counts. Per 36 rates are exact from what the record does carry, and they make a 1965 season and a 2025 season readable on the same scale." },
      { q: "Is a perfect 100 possible?", a: "Every target is the real per 36 line of an actual season, so a blend that lands the target exists in the pool. Hitting 100 on the nose means matching every stat almost exactly, which is brutally hard with five picks, 90 plus is the realistic brag." },
      { q: "Why can I not pick 1960s seasons on some targets?", a: "Steals and blocks were first tracked in 1973-74 and the three point line arrived in 1979-80. When the target includes those stats, earlier seasons have no honest number to contribute, so they sit out. Targets without them open the whole pool back to 1951-52." },
      { q: "Do steals and blocks always appear?", a: "Only when the season behind the target comes from 1973-74 or later. Older targets score on points, rebounds, assists and the shooting split alone." }
    ]
  },
  "/nba-starting-5": {
    intro: [
      "One spin sets the mission: build a starting five with the highest career scoring, or the lowest, or whatever the stat wheel demands.",
      "The catch: each of your five picks must come from a random NBA franchise, so your plan is only as good as your memory of who played where."
    ],
    headings: {
      howToPlay: "How to play NBA Starting 5, a franchise lineup guessing game",
      rules: "NBA Starting 5 rules for slots, teams and rerolls",
      example: "NBA Starting 5 walkthrough: an easy pick and two rude ones",
      tips: "NBA Starting 5 tips for journeymen and reading the challenge",
      faq: "NBA Starting 5 FAQ: player pool, positions and verdicts"
    },
    howToPlaySections: [
      {
        heading: "Spinning the stat challenge",
        items: [
          "Spin the stat challenge. It might be highest career PPG, lowest career fouls, most championships, tallest lineup, anything from a pool of 13 stats."
        ]
      },
      {
        heading: "Choosing a position to fill",
        items: [
          "Pick one of the five positions: PG, SG, SF, PF or C."
        ]
      },
      {
        heading: "Naming a player from the random team",
        items: [
          "A random NBA team appears. Name a player who suited up for that franchise, picking from the suggestions as you type."
        ]
      },
      {
        heading: "Filling all five slots and tracking your total",
        items: [
          "Repeat until all five slots are filled, watching your running stat total."
        ]
      },
      {
        heading: "Submitting the lineup for a verdict",
        items: [
          "Submit the lineup for a verdict: a rating, a headline and a short breakdown."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Five slots drawn from thirty franchises",
        items: [
          "Five slots, one random team per pick, drawn from all 30 NBA franchises."
        ]
      },
      {
        heading: "Suggestions only show real former players",
        items: [
          "Only players who really played for the shown team will appear in the suggestions."
        ],
        subsections: [
          {
            heading: "How guards, forwards and centers slot in",
            items: [
              "Guards fill PG or SG, forwards fill SF or PF, centers fill C."
            ]
          }
        ]
      },
      {
        heading: "No repeating a player in one lineup",
        items: [
          "No player can appear twice in one lineup."
        ]
      },
      {
        heading: "Rerolling a team as often as you like",
        items: [
          "Hit reroll to swap the current team, as often as you like."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "An easy call at shooting guard",
        paragraphs: [
          "The wheel says highest career PPG. Your first slot is SG from the Bulls, and you do not overthink Michael Jordan."
        ]
      },
      {
        heading: "Two tougher franchises and a rough verdict",
        paragraphs: [
          "Then it gets rude: PF from the Grizzlies, C from the Hornets. You dig up the best scorers you can remember, submit a total in the high 90s, and the verdict roasts your weakest link."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Reading the challenge direction twice",
        items: [
          "Read the direction twice. On a lowest challenge, the stars you love are suddenly poison."
        ]
      },
      {
        heading: "Journeymen as a five team cheat code",
        items: [
          "Journeymen are cheat codes. A player with five career stops gives you outs on five different team spins."
        ]
      },
      {
        heading: "Rerolling early instead of late",
        items: [
          "Reroll early, not late. A bad team fit hurts more when only one slot is left."
        ]
      }
    ],
    faqs: [
      { q: "Do the players have to be current?", a: "No. The pool spans thousands of players across NBA history, as long as they played for the shown franchise." },
      { q: "Why will the game not accept my guy at point guard?", a: "Position data is coarse: guards fit either guard slot, forwards fit either forward slot, and centers fit center. If a player is listed as a forward, he cannot fill your PG hole." },
      { q: "How is my lineup judged?", a: "Each pick gets a value for the challenge stat, then the game writes a short verdict with a rating and headline you can share." }
    ]
  },
  "/nba-connect-4": {
    intro: [
      "Connect 4 with receipts. The board is the classic 7 wide by 6 tall grid, but you cannot just drop a piece. You have to earn the cell with an NBA answer.",
      "Every column and row carries a label, things like Lakers, MVP Winner or 20+ PPG Career. To claim a cell, you need one player who matches both."
    ],
    headings: {
      howToPlay: "How to play NBA Connect 4, a two player basketball trivia game",
      rules: "NBA Connect 4 rules for the grid, names and rejected answers",
      example: "NBA Connect 4 walkthrough: a Warriors clear and a Lakers block",
      tips: "NBA Connect 4 tips for reading rows and burning answers early",
      faq: "NBA Connect 4 FAQ: solo play, wrong calls and board variety"
    },
    howToPlaySections: [
      {
        heading: "Grabbing a friend for two player play",
        items: [
          "Grab a friend. It is a two player game, red against blue, on one screen."
        ]
      },
      {
        heading: "Picking a column and watching the piece fall",
        items: [
          "On your turn, pick a column. Your piece will fall to the lowest empty row."
        ],
        subsections: [
          {
            heading: "Committing to the column's and row's labels",
            items: [
              "That landing spot commits you to two labels: the column's and the row's."
            ]
          }
        ]
      },
      {
        heading: "Naming a player and passing the fact check",
        items: [
          "Name an NBA player who fits both. A fact check reviews the claim before the piece is placed."
        ]
      },
      {
        heading: "Winning with four in a row",
        items: [
          "First to four in a row wins: across, down or diagonal."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "A seven by six grid of trivia labels",
        items: [
          "The grid is 7 columns by 6 rows, each with its own trivia label."
        ]
      },
      {
        heading: "Each player name usable once by either side",
        items: [
          "Each player name can only be used once per game, by either side."
        ]
      },
      {
        heading: "What a rejected answer costs you",
        items: [
          "A rejected answer does not place a piece and does not end your turn. Try someone else or hit skip."
        ]
      },
      {
        heading: "Filling all forty two cells with no winner",
        items: [
          "Fill all 42 cells with no winner and it is a draw."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Clearing the Warriors and Champion crossing",
        paragraphs: [
          "You drop into the Warriors column and the landing row says Champion. Andre Iguodala fits both, the check clears it, and your red piece locks in."
        ]
      },
      {
        heading: "Blue blanks on Lakers and DPOY Winner",
        paragraphs: [
          "Later, blue needs the Lakers column to block you, but the waiting row says DPOY Winner and they blank. They skip, you finish the diagonal."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Thinking one row ahead as columns fill",
        items: [
          "Think one row ahead. The label your piece lands on changes as the column fills."
        ]
      },
      {
        heading: "Burning common answers before your rival does",
        items: [
          "Burn common answers early. If both of you are saving the same superstar, whoever needs him second is stuck."
        ]
      },
      {
        heading: "Playing the board and not just the trivia",
        items: [
          "Play the board, not just the trivia. A boring cell that blocks four in a row beats a clever one that does not."
        ]
      },
      {
        heading: "Treating skip as a real move",
        items: [
          "The skip button is a real move. Losing a turn beats feeding a wrong guess streak."
        ]
      }
    ],
    faqs: [
      { q: "Can I play alone?", a: "There is no bot, so solo play means running both sides. It works fine as trivia practice." },
      { q: "What if the checker rejects a correct answer?", a: "You keep your turn, so try again or pick another player. There is also a report button on the page if a call looks wrong." },
      { q: "Do the boards change?", a: "Yes. Each new game draws one of several curated boards, from Legends and Dynasties to Draft Pedigree, so the label combinations stay fresh." }
    ]
  },
  "/nba-chain": {
    intro: [
      "Every NBA career is a web of teammates, and this game makes you walk it. Start from one star, then name a teammate of his, then a teammate of that guy, on and on.",
      "One wrong link ends the run. The deeper you go, the more names you burn, and the more you find yourself trading superstars for that one backup center who played everywhere."
    ],
    headings: {
      howToPlay: "How to play NBA Chain, a free teammate connection game",
      rules: "NBA Chain rules for links, mistakes and the two modes",
      example: "NBA Chain walkthrough: from Dirk Nowitzki to a broken link",
      tips: "NBA Chain tips for journeymen and playing it safe",
      faq: "NBA Chain FAQ: teammates, verification and saved streaks"
    },
    howToPlaySections: [
      {
        heading: "Starting from a famous first player",
        items: [
          "The game hands you a starting player, someone famous like LeBron James or Kevin Garnett."
        ]
      },
      {
        heading: "Naming a teammate of the current player",
        items: [
          "Name any player who was an NBA teammate of the current player."
        ],
        subsections: [
          {
            heading: "How the link gets verified and shown",
            items: [
              "The link gets verified, and the shared team shows up on the chain."
            ]
          }
        ]
      },
      {
        heading: "Connecting each new link to the last",
        items: [
          "Keep adding links. Each new player must connect to the one right before them."
        ]
      },
      {
        heading: "Choosing Endless or Round mode",
        items: [
          "Play Endless to chase a record, or Round mode for a fixed 10 pick challenge against par."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "What instantly ends a run",
        items: [
          "A wrong link ends the game instantly. So does repeating any player already in the chain."
        ]
      },
      {
        heading: "Endless mode and its saved streak",
        items: [
          "Endless mode: build until you break, and your best streak saves on your device."
        ]
      },
      {
        heading: "Round mode's ten picks and par of seven",
        items: [
          "Round mode: exactly 10 picks, with par set at 7."
        ]
      },
      {
        heading: "Banking a score before you risk it",
        items: [
          "You can end a run voluntarily and bank the score."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Starting from Dirk Nowitzki and the title Mavs",
        paragraphs: [
          "Start: Dirk Nowitzki. You go Jason Kidd from the title Mavs, then from Kidd's Nets years you pull Vince Carter, and from Carter's Raptors days you grab Tracy McGrady."
        ]
      },
      {
        heading: "Gambling on a half remembered teammate",
        paragraphs: [
          "Eight links deep, you gamble on a teammate you half remember. No shared team. Chain of 8."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Routing through six stop journeymen",
        items: [
          "Route through journeymen. A guy with six career stops opens six directions."
        ]
      },
      {
        heading: "Long careers as bridges between eras",
        items: [
          "Long careers are bridges between eras. Veterans who played 18 plus seasons connect generations."
        ]
      },
      {
        heading: "Avoiding a one team dead end",
        items: [
          "Do not chain into a dead end. A one team legend late in the run leaves you only his teammates."
        ]
      },
      {
        heading: "Playing it safe in Round mode",
        items: [
          "In Round mode you just need 10 clean links, so take the safest connection every time."
        ]
      }
    ],
    faqs: [
      { q: "What counts as teammates?", a: "The two players must have shared an NBA team, and the check tells you which one. Overlapping on the roster is the standard, so pick pairs you are sure actually crossed paths." },
      { q: "Do I lose if the connection cannot be verified due to a network hiccup?", a: "No. If verification fails for technical reasons, nothing is added and nothing ends. You just try the same link again." },
      { q: "Where is my best streak stored?", a: "On your device. Play on the same browser and the game keeps showing the record you are chasing." }
    ]
  },
  "/nba-higher-lower": {
    intro: [
      "Two legends, one question: who scored more career points? That is the entire game, and it is much harder than it sounds.",
      "The pool is the top 80 scorers in NBA history, so there are no easy outs. Everyone on screen scored a mountain of points. You are just deciding whose mountain is taller."
    ],
    headings: {
      howToPlay: "How to play NBA Higher or Lower, a daily scoring trivia game",
      rules: "NBA Higher or Lower rules for rounds, streaks and ties",
      example: "NBA Higher or Lower walkthrough: Kobe, Jordan and era math",
      tips: "NBA Higher or Lower tips for longevity and guarding streaks",
      faq: "NBA Higher or Lower FAQ: scoring totals and the player pool"
    },
    howToPlaySections: [
      {
        heading: "Reading the two player cards",
        items: [
          "Look at the two player cards: name, position, franchises and final season."
        ]
      },
      {
        heading: "Tapping the player with more career points",
        items: [
          "Tap the player you think finished with more career points."
        ]
      },
      {
        heading: "Watching the totals flip and the next pair load",
        items: [
          "The totals flip over, your answer gets marked, and the next pair loads."
        ]
      },
      {
        heading: "Surviving all ten rounds",
        items: [
          "Survive all 10 rounds and post your score."
        ]
      },
      {
        heading: "Playing Daily then switching to Unlimited",
        items: [
          "Play the Daily, then switch to Unlimited if you want more."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Ten rounds worth ten points each",
        items: [
          "Each game is 10 rounds, and every correct answer is worth 10 points."
        ]
      },
      {
        heading: "How the streak bonus grows",
        items: [
          "Consecutive correct answers earn a growing streak bonus. A perfect 10 for 10 run scores 325."
        ],
        subsections: [
          {
            heading: "Why exact ties always count",
            items: [
              "Exact ties count as correct no matter which side you pick."
            ]
          }
        ]
      },
      {
        heading: "Daily mode's shared pairs at midnight",
        items: [
          "Daily mode serves everyone the same pairs, once per day, with a fresh set every day at midnight Eastern."
        ]
      },
      {
        heading: "Hard mode in Unlimited only",
        items: [
          "Hard mode pairs players with close totals, and it only applies in Unlimited."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Kobe Bryant against Michael Jordan",
        paragraphs: [
          "Round one gives you Kobe Bryant against Michael Jordan. Feels like a coin flip, but Kobe played 20 seasons and finished ahead, 33,643 to 32,292."
        ]
      },
      {
        heading: "Era math and a streak that snaps",
        paragraphs: [
          "Then comes a 1960s name against a 2010s star, and era math takes over. An eight answer streak builds, round nine snaps it, and you close at 230."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Longevity usually beats a short peak",
        items: [
          "Longevity beats peak. A 19 year career of good scoring usually outpoints a short brilliant one."
        ]
      },
      {
        heading: "Reading the final season for career length",
        items: [
          "Check the final season on the card. It quietly tells you how long the career ran."
        ]
      },
      {
        heading: "Multiple franchises as a longevity clue",
        items: [
          "Multiple franchises often means a long career, which means more total points."
        ]
      },
      {
        heading: "Guarding your streak in the final rounds",
        items: [
          "Guard your streak late. Rounds eight through ten carry the biggest bonuses."
        ]
      }
    ],
    faqs: [
      { q: "Is it always career points?", a: "Yes, this one is pure career regular season scoring totals. No averages, no playoff points, just the full body of work." },
      { q: "What is the highest possible score?", a: "325. That is all 10 correct with the streak never breaking, since each consecutive answer stacks a bigger bonus on the base 10 points." },
      { q: "Who can show up?", a: "Only the top 80 career scorers in league history, from active stars to names your dad swears by." }
    ]
  },
  "/nba-grid": {
    intro: [
      "Nine cells, nine guesses, zero mercy. This is the NBA team grid formula: every cell sits at the crossroads of a row and a column, and you need one player whose career satisfies both.",
      "Sometimes that means two franchises, sometimes a franchise plus a milestone like 10,000 points. The obvious names run out fast."
    ],
    headings: {
      howToPlay: "How to play NBA Franchise Grid, a daily basketball guessing game",
      rules: "NBA Franchise Grid rules for guesses, franchises and milestones",
      example: "NBA Franchise Grid walkthrough: Shaquille O'Neal and Scottie Pippen",
      tips: "NBA Franchise Grid tips for scanning and milestone journeymen",
      faq: "NBA Franchise Grid FAQ: answers, difficulty and daily resets"
    },
    howToPlaySections: [
      {
        heading: "Reading the row and column labels",
        items: [
          "Read the three row labels and three column labels. They are NBA franchises or career milestones."
        ]
      },
      {
        heading: "Tapping a cell and typing a name",
        items: [
          "Tap any empty cell and type a player name."
        ]
      },
      {
        heading: "Picking a suggestion that matches both labels",
        items: [
          "Pick from the suggestions. If the career matches both labels, the cell turns green."
        ]
      },
      {
        heading: "What a wrong answer costs you",
        items: [
          "A wrong answer costs one of your 9 guesses and leaves the cell empty."
        ]
      },
      {
        heading: "Filling all nine cells before guesses run out",
        items: [
          "Fill all nine cells before the guesses run out."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Nine guesses for nine cells",
        items: [
          "You get 9 total guesses for 9 cells, so a perfect game has zero misses."
        ]
      },
      {
        heading: "Each player usable once per grid",
        items: [
          "Each player can only be used once per grid."
        ]
      },
      {
        heading: "The pool of franchises and milestones",
        items: [
          "Categories come from a pool of 16 franchises plus three milestones: 10,000+ career points, 5,000+ career rebounds and 900+ games played."
        ]
      },
      {
        heading: "The daily grid and its saved progress",
        items: [
          "The daily grid is the same for everyone and your progress saves. A new one drops every day at midnight Eastern."
        ],
        subsections: [
          {
            heading: "Unlimited mode's difficulty tiers",
            items: [
              "Unlimited mode adds difficulty tiers: easy uses two milestone lines, normal uses one, hard is all franchises."
            ]
          }
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Lakers and Celtics resolved by Shaquille O'Neal",
        paragraphs: [
          "Top left wants Lakers plus Celtics. You take a second, then remember Shaquille O'Neal finished up in Boston. Green."
        ]
      },
      {
        heading: "Saving Jordan and spending Scottie Pippen instead",
        paragraphs: [
          "Next, Bulls plus 10,000+ career points. Jordan is the reflex, but you save him in case a tougher Bulls cell shows up, and spend Scottie Pippen instead. That little hesitation is the whole game."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Scanning the grid before your first guess",
        items: [
          "Scan the full grid before guessing. The hardest intersection should get your rarest player."
        ]
      },
      {
        heading: "Journeymen as the milestone cheat code",
        items: [
          "Journeymen with 900+ games are the milestone cheat code, and they are rarely anyone's first thought."
        ]
      },
      {
        heading: "Trusting the instant career data check",
        items: [
          "Answers check against career data instantly, so this is a memory game, not a debate."
        ]
      },
      {
        heading: "Why short careers struggle with milestones",
        items: [
          "Short careers ruin milestone cells. A five year star probably misses the games played bar."
        ]
      }
    ],
    faqs: [
      { q: "Does every cell have an answer?", a: "Yes. Every pairing in the pool has at least 25 qualifying players, so a blank cell is a you problem, not a board problem." },
      { q: "Why are some famous franchises missing?", a: "The pool sticks to 16 franchises whose history lives under one code, so relocation heavy teams like the Thunder and Grizzlies sit out to keep answers clean." },
      { q: "Do wrong guesses reveal anything?", a: "No hints, just a red flash and one fewer guess. Treat every submission like it is your last." }
    ]
  },
  "/nba-connections": {
    intro: [
      "Twenty NBA players sit in a grid, and they are not random. Hiding inside are four groups of five, each tied by one connection: a shared franchise, a milestone, a birth country, a draft slot. Find all four before your lives run out.",
      "If you came from the word puzzle world, one warning: this NBA connections game runs bigger than the format you know. Groups are five deep instead of four, so there are twenty names to sort and a fifth guy to find for every theme. The easy four come quick. The fifth is where doubt moves in.",
      "Equal parts trivia and logic, and that mix is what makes a basketball connections puzzle sticky. Knowing a player is step one. Knowing which part of his career the board cares about is the game."
    ],
    headings: {
      howToPlay: "How to play NBA Connections, a free online basketball trivia puzzle",
      rules: "NBA Connections rules: groups, lives and the daily puzzle",
      example: "NBA Connections walkthrough: a Miami Heat group and its imposter",
      tips: "NBA Connections tips for finding the fifth player every time",
      faq: "NBA Connections FAQ: daily puzzles, lives and player groups"
    },
    howToPlaySections: [
      {
        heading: "Reading the board before you touch anything",
        items: [
          "Read all 20 names before you touch anything. First instincts are good, first submissions are not."
        ]
      },
      {
        heading: "Selecting five players you believe connect",
        items: [
          "Tap 5 players you believe share a connection. Tap again to deselect."
        ],
        subsections: [
          {
            heading: "What happens when a group locks in",
            items: [
              "Hit Submit. A correct five locks in, shows its theme, and leaves the board."
            ]
          }
        ]
      },
      {
        heading: "What a wrong guess costs you",
        items: [
          "A wrong five shakes the board and costs one of your 4 lives."
        ]
      },
      {
        heading: "Group colors from easiest to hardest",
        items: [
          "Group colors run yellow, green, blue, purple, from easiest to hardest."
        ]
      },
      {
        heading: "Clearing all four groups to win",
        items: [
          "Clear all four groups to win. Run out of lives and the remaining answers are revealed."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Board size: four groups of five",
        items: [
          "Every puzzle is exactly 4 groups of 5 players, 20 names total."
        ]
      },
      {
        heading: "Four lives and the cost of a miss",
        items: [
          "You have 4 lives, and every wrong submission costs one."
        ]
      },
      {
        heading: "One group per player, never two",
        items: [
          "Each player belongs to exactly one group in the puzzle. No name ever fits two answers."
        ]
      },
      {
        heading: "Daily puzzle versus unlimited boards",
        items: [
          "The daily puzzle is identical for everyone, progress saves, and a fresh one lands every day at midnight Eastern. Unlimited deals random boards from the pool."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "A Miami Heat group hides an imposter",
        paragraphs: [
          "Say the board includes Dwyane Wade, Alonzo Mourning, Udonis Haslem, Chris Bosh and Tim Hardaway. Heat, obviously. Except Hardaway was a point guard with big assist numbers, and you suspect an assists group too. That collision is the whole puzzle."
        ]
      },
      {
        heading: "Counting career assists to settle it",
        paragraphs: [
          "So you count. Hardaway sits comfortably short of 10,000 career assists, while John Stockton, Jason Kidd and Steve Nash all cleared it. Hardaway goes back in the Heat pile, and both groups lock in clean."
        ]
      },
      {
        heading: "Career scorers untangled from a draft group",
        paragraphs: [
          "The last trap is the scorers. Karl Malone, Kobe Bryant, Dirk Nowitzki and Carmelo Anthony scream career points, and your eye wants Allen Iverson as the fifth. Except Iverson was a number one overall pick, and Yao Ming and Zion Williamson are sitting there looking suspiciously like a draft group. Save Iverson for them, and the real fifth scorer appears by elimination. Lesson learned: verify the fifth name, always."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Proving the fifth name before you submit",
        items: [
          "Find the fifth before you submit. Anyone can spot four Lakers. The theme is only proven when a fifth fits."
        ]
      },
      {
        heading: "Reading an overlap as a warning sign",
        items: [
          "If one player fits two of your working themes, one theme is wrong. Treat the overlap as a compass."
        ]
      },
      {
        heading: "Where star scorers like to hide",
        items: [
          "Star scorers hide in draft and country groups. Check where a player was born and picked before filing him under points."
        ]
      },
      {
        heading: "Choosing which group to submit first",
        items: [
          "Start with the group you would bet a life on, whatever its color. Five names off the board makes everything else easier to see.",
          "Down to two groups and unsure? Submit your stronger read. If it hits, the last group solves itself."
        ]
      }
    ],
    faqs: [
      { q: "How is this different from other connections games?", a: "Three ways: it is all basketball, groups are five players instead of four, and you get 4 lives. Bigger groups make themes easier to spot but harder to complete." },
      { q: "Is there a one away warning?", a: "No. A wrong submission costs a life even if four of five were right, which is why the fifth name deserves the most thought." },
      { q: "Is everyone solving the same puzzle?", a: "In daily mode, yes, the whole world gets the same 20 players, and progress saves if you leave. Unlimited deals random boards." },
      { q: "What kinds of connections show up?", a: "Franchises, career milestones like 28,000 points or 2,000 threes, birth countries like France or Canada, and draft slots like number one overall. Every grouping is checked against real career data." },
      { q: "Do I need an account to play?", a: "No. An account is optional and only matters if you want saved stats and leaderboards. The daily puzzle itself needs nothing." }
    ]
  },
  "/nba-career": {
    intro: [
      "A mystery NBA player is hiding behind a stack of clues, and the first one is nearly useless on purpose. You start with just a position and 1,000 points on the table.",
      "Every clue you flip makes the answer easier and the payout smaller. The whole game is one question: how early do you dare to guess?"
    ],
    headings: {
      howToPlay: "How to play NBA Career Path, a free NBA guessing game",
      rules: "NBA Career Path rules: the score ladder and free guesses",
      example: "NBA Career Path walkthrough: guessing Hakeem Olajuwon",
      tips: "NBA Career Path tips for cracking the clues fast",
      faq: "NBA Career Path FAQ: scoring, hard mode and last names"
    },
    howToPlaySections: [
      {
        heading: "Starting with the position clue",
        items: [
          "Start with the position clue and a pot of 1,000 points."
        ]
      },
      {
        heading: "Guessing for free at any time",
        items: [
          "Guess whenever you like. Wrong guesses are free, so swing away."
        ]
      },
      {
        heading: "Revealing clues one at a time",
        items: [
          "Stuck? Reveal the next clue: country, then draft info, then teams, then career stats, then awards."
        ]
      },
      {
        heading: "What each reveal costs you",
        items: [
          "Each reveal costs 150 points, down to a floor of 100."
        ]
      },
      {
        heading: "Banking points or giving up",
        items: [
          "Name the player to bank whatever is left, or give up to see the answer."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "The score ladder from 1000 down to 100",
        items: [
          "The score ladder runs 1000, 850, 700, 550, 400, 250, 100 depending on clues used."
        ]
      },
      {
        heading: "Free guesses, costly reveals",
        items: [
          "Wrong guesses cost nothing. Only revealed clues eat your score."
        ]
      },
      {
        heading: "A last name counts as correct",
        items: [
          "A last name alone counts as a correct guess."
        ]
      },
      {
        heading: "Daily mode and hard mode's hidden clues",
        items: [
          "Daily mode gives everyone the same player each day, and hard mode hides the two easiest clues."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "A center from Nigeria narrows the field",
        paragraphs: [
          "The position says center. That could be anyone, so you flip country: Nigeria. Interesting. One more flip, draft info: first overall pick, 1984."
        ]
      },
      {
        heading: "Two clues in, the answer is obvious",
        paragraphs: [
          "Now it is obvious. Hakeem Olajuwon, guessed with two clues used, banks 700 points. Greedy players flip nothing and gamble at 1,000. Cowards flip five and keep 250. Pick your identity."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Guessing early costs you nothing",
        items: [
          "Guess early and often, since misses are free. Even a wild swing at 1,000 costs nothing."
        ]
      },
      {
        heading: "Why the draft clue breaks the case",
        items: [
          "The draft clue is usually the code breaker. Year plus pick number narrows history fast."
        ],
        subsections: [
          {
            heading: "Spotting a one team legend instantly",
            items: [
              "Teams reveal one franchise at a time, so a one team legend gets exposed instantly."
            ]
          }
        ]
      },
      {
        heading: "Practicing stat lines in unlimited mode",
        items: [
          "In unlimited mode, practice reading stat lines. Career numbers have a shape, and shapes have names."
        ]
      }
    ],
    faqs: [
      { q: "Do wrong guesses lower my score?", a: "No. You can guess as many times as you want at no cost. The only thing that drains the pot is revealing clues, at 150 points each." },
      { q: "Can I just type the last name?", a: "Yes. The game accepts the surname on its own, so no need to remember exactly how a first name is spelled." },
      { q: "What does hard mode change?", a: "It hides the two gimme clues, position and country, so you are working from draft info, teams, stats and awards. Scoring stays the same." }
    ]
  },
  "/missing-five": {
    intro: [
      "You remember the game. The shot, the score, the confetti. This one bets you do not remember who actually started.",
      "Missing Five shows a real starting five from a famous NBA Finals night with one name blanked. Every lineup is verified against the official box score, and the blanks are chosen to hurt."
    ],
    headings: {
      howToPlay: "How to play Missing Five, a free NBA Finals lineup game",
      rules: "Missing Five rules: guesses, hints and hard mode",
      example: "Missing Five walkthrough: the 2016 Finals Game 7 blank",
      tips: "Missing Five tips for naming the missing starter fast",
      faq: "Missing Five FAQ: real lineups, hints and surname guesses"
    },
    howToPlaySections: [
      {
        heading: "Reading the game context first",
        items: [
          "Read the game context: the matchup, the date, the final score, the venue."
        ]
      },
      {
        heading: "Spotting the blank starter on the court",
        items: [
          "Look at the court. Four starters are named, one is a glowing blank with only the position showing."
        ]
      },
      {
        heading: "Typing your guess within three tries",
        items: [
          "Type the missing starter. You have 3 guesses."
        ]
      },
      {
        heading: "What each miss unlocks",
        items: [
          "Each miss unlocks a hint, starting with the player's nationality, then the first letter of the surname."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Scoring across three guesses",
        items: [
          "3 guesses per lineup: 100 points on the first, 70 on the second, 40 on the third."
        ]
      },
      {
        heading: "When a surname alone is enough",
        items: [
          "The surname alone counts, as long as it is at least four letters."
        ]
      },
      {
        heading: "What hard mode strips away",
        items: [
          "Hard mode strips the hints, the name suggestions, and even the position labels."
        ]
      },
      {
        heading: "Daily lineups versus unlimited mode",
        items: [
          "The daily lineup is the same for everyone and changes every day at midnight Eastern. Unlimited mode keeps dealing new ones."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "A confident guess that was hurt that night",
        paragraphs: [
          "The card reads 2016 NBA Finals, Game 7, Warriors starting five, and the blank is at center. You type Andrew Bogut with full confidence. Wrong. Bogut was hurt and never played that night."
        ]
      },
      {
        heading: "The nationality hint that unlocks the answer",
        paragraphs: [
          "The hint says Nigeria, and somewhere in your brain a backup big raises his hand. Second guess lands. 70 points and a story."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Weighing injuries before the famous name",
        items: [
          "Think about injuries and matchups before you type the famous name. Finals coaches loved a surprise starter."
        ]
      },
      {
        heading: "Why the score line pins the exact night",
        items: [
          "The score line and date matter. They pin the exact night, not just the series."
        ]
      },
      {
        heading: "Role players start title games more than you think",
        items: [
          "Role players who started title games are the answer more often than superstars. The stars are usually already on the card."
        ],
        subsections: [
          {
            heading: "Leaning into a surprising nationality hint",
            items: [
              "If the nationality hint surprises you, lean into it. It usually eliminates your whole shortlist at once."
            ]
          }
        ]
      }
    ],
    faqs: [
      { q: "Are these lineups real?", a: "Yes, every five was checked against the official box score for that exact game. When the answer feels wrong, that is the point: the real starter is often not the guy history remembers." },
      { q: "Why is the answer sometimes a nobody?", a: "Coaches made one night changes in huge games, and those starters are forgotten. The gap between memory and box score is the whole game." },
      { q: "Do I have to spell the full name?", a: "No. The surname on its own works, and outside hard mode the suggestion list helps with spelling." }
    ]
  },
  "/perfect-lineup-nba": {
    intro: [
      "Five slots, and the game has opinions. Three of them come stamped with a constraint, a franchise or a decade, and only players matching the tag can go there.",
      "The pool is a curated set of greats and current stars, so every pick is good. The puzzle is squeezing the best combination through the constraints while keeping the roster connected."
    ],
    headings: {
      howToPlay: "How to play Perfect Lineup: NBA, a free starting five builder",
      rules: "Perfect Lineup: NBA rules: constraints, chemistry and grades",
      example: "Perfect Lineup: NBA walkthrough: a Lakers double link",
      tips: "Perfect Lineup: NBA tips for building real chemistry",
      faq: "Perfect Lineup: NBA FAQ: the player pool, daily sets and grading"
    },
    howToPlaySections: [
      {
        heading: "Checking the five slots and their constraints",
        items: [
          "Check the five slots: PG, SG, SF, PF and C. Three carry a constraint like Lakers or 1990s."
        ]
      },
      {
        heading: "Picking eligible players for each slot",
        items: [
          "Tap a slot and pick from the eligible players. Constrained slots only list players who fit the tag."
        ]
      },
      {
        heading: "Filling all five and watching chemistry",
        items: [
          "Fill all five, watching for chemistry links between picks."
        ]
      },
      {
        heading: "Simulating for a scoreline and a grade",
        items: [
          "Hit Simulate for a scoreline, a grade and a chemistry rating."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Three constrained slots, four eligible players",
        items: [
          "Exactly 3 of the 5 slots carry a team or era constraint, and every constraint leaves at least 4 eligible players."
        ]
      },
      {
        heading: "How positions flex one step",
        items: [
          "Positions flex one step: the PG slot also takes shooting guards, the C slot also takes power forwards."
        ]
      },
      {
        heading: "The rating split between quality and chemistry",
        items: [
          "Your final rating is 80 percent player quality and 20 percent chemistry."
        ],
        subsections: [
          {
            heading: "Where chemistry links come from",
            items: [
              "Chemistry comes from sharing a franchise or an era with at least one other pick."
            ]
          }
        ]
      },
      {
        heading: "Grades from A+ down to D",
        items: [
          "Grades run from A+ at a 92 rating down to D. The daily constraint set is the same for everyone and changes every day."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Kareem and Magic lock a double link",
        paragraphs: [
          "Say the center slot demands Lakers and the point guard slot demands 1980s. Kareem Abdul-Jabbar takes center, and Magic Johnson at point becomes a double link: same team, same decade."
        ]
      },
      {
        heading: "Two modern wings round out the five",
        paragraphs: [
          "Two modern wings and a 90s power forward round it out. Chemistry lifts a decent roster to an A and a green and yellow emoji row."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Building around the constraints first",
        items: [
          "Build around the constraints first. The two free slots fix whatever the tags forced on you."
        ]
      },
      {
        heading: "Chasing two links for double chemistry",
        items: [
          "Chase double links. A pick sharing both team and era with a teammate feeds chemistry twice."
        ]
      },
      {
        heading: "Why a connected roster beats five strangers",
        items: [
          "Do not draft five strangers. A weaker player who connects often beats a loner star."
        ]
      }
    ],
    faqs: [
      { q: "Who is in the player pool?", a: "About 66 curated stars across every era, from Magic and Kareem to current MVPs. Not the full history books, which keeps every slot a real decision." },
      { q: "Can I redo my daily lineup?", a: "Yes. After simulating you can edit the same constraint set and run it again, chasing a better grade all day." },
      { q: "How exact is the scoring?", a: "Your five ratings average into 80 percent of the score, chemistry is the other 20, and the result maps to a grade and a shareable scoreline." }
    ]
  },
  "/nba-gauntlet-draft": {
    intro: [
      "The draft mode, NBA style: five picks, one per starting five slot, five real players a pick from a genuine star to a bargain, and you keep exactly one.",
      "Then the cup begins. Your finished five runs five knockout rounds against ever stronger invented opposition, rated 85 up to 101, and overtime when the game is level.",
      "The run is decided entirely by the five you drafted: the same lineup always runs the same gauntlet, so every pick is the game."
    ],
    headings: {
      howToPlay: "How to play Gauntlet Draft: NBA, a free online card draft game",
      rules: "Gauntlet Draft: NBA rules: cards, the knockout and ratings",
      example: "Gauntlet Draft: NBA walkthrough: a center pick and a title run",
      tips: "Gauntlet Draft: NBA tips for drafting a title worthy five",
      faq: "Gauntlet Draft: NBA FAQ: the daily draft and real players"
    },
    howToPlaySections: [
      {
        heading: "Picking daily or unlimited mode",
        items: [
          "Pick the daily gauntlet (the same five card choices for everyone today) or unlimited for a fresh draft."
        ]
      },
      {
        heading: "Drafting one card per slot",
        items: [
          "For each slot, PG through C, read the five cards, star to bargain, and tap the one you keep. Positions flex the same way Perfect Lineup's do: an SG slot also takes a PG or an SF."
        ]
      },
      {
        heading: "How the knockout begins after pick five",
        items: [
          "After pick five the knockout starts on its own: five rounds, one match each, revealed one at a time."
        ]
      },
      {
        heading: "Scoring survival points and the trophy",
        items: [
          "Survive a round for 16 points; lift the trophy for exactly 100."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Real players against invented opponents",
        items: [
          "Every card is a real player from the same curated pool Perfect Lineup: NBA plays, roughly 66 names across every era; every opponent club is invented on purpose."
        ]
      },
      {
        heading: "How the five cards spread across ratings",
        items: [
          "The five cards per slot are spread across the pool's rating range, so a top-tier card and a bargain are always both on the table."
        ],
        subsections: [
          {
            heading: "Never dealt the same player twice",
            items: [
              "No player is dealt twice in one draft."
            ]
          }
        ]
      },
      {
        heading: "Why every replay stays deterministic",
        items: [
          "The knockout is deterministic in your five: scoring comes from the rating gap, level games go to overtime, and replaying the same lineup replays the same cup."
        ]
      },
      {
        heading: "Opposition ratings climbing round by round",
        items: [
          "Opposition ratings climb 85, 89, 93, 97, 101. A bargain five usually falls in the first two rounds, an elite one reaches the final as a slight underdog, and even a perfect draft lifts the trophy about one run in ten."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "A center slot with five cards to choose",
        paragraphs: [
          "The center slot deals a 98 rated all timer next to a 91, an 88, a 86 and an 84. There is no cost to any of them, so the 98 is the pick unless you are chasing a specific team or era on the card."
        ]
      },
      {
        heading: "Two rounds survived and one regret at power forward",
        paragraphs: [
          "Your finished five rates 96. The Qualifier wins big, the Last Sixteen is close, the Quarter Final needs extra time, and the Semi Final ends the run. Two rounds survived, 32 points, and the card you would redo is the 88 you took at power forward."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Why the center card matters as much as guard",
        items: [
          "The center card matters as much as the point guard card: one weak slot drags the whole rating."
        ]
      },
      {
        heading: "Bargain cards versus chasing the score",
        items: [
          "The bargain cards exist for flavor runs, not for winning. If the score is the goal, draft the biggest number that fits."
        ]
      },
      {
        heading: "Watching your running rating climb",
        items: [
          "Champions need a five in the high nineties. Check your running rating under the cards as you go."
        ]
      }
    ],
    faqs: [
      { q: "Is the daily draft the same for everyone?", a: "Yes. One shared set of five card choices per Eastern Time date, so daily scores compare fairly." },
      { q: "Are the opponents real teams?", a: "No, and that is deliberate: every gauntlet opponent is an invented club, so no real logo or name is borrowed. The players you draft are real, from the same pool Perfect Lineup: NBA plays." },
      { q: "Is this the same game as the soccer Gauntlet Draft?", a: "Same engine, NBA's own pool and positions. Five picks instead of eleven, because a basketball lineup is five players, and the ladder is tuned to this pool's own rating range." }
    ]
  },
  "/conquest-nba": {
    intro: [
      "Pick a team, inherit the land around its arena, and try to own the entire country. This is the NBA imperialism map format: every game swallows empires whole.",
      "A loss does not cost a border town. It costs everything, every territory, straight into the winner's hands. Fourteen rounds later the map is a few giant blobs with grudges."
    ],
    headings: {
      howToPlay: "How to play NBA Conquest, a free NBA territory takeover game",
      rules: "NBA Conquest rules: annexing empires and scoring predictions",
      example: "NBA Conquest walkthrough: Denver's empire rises and falls",
      tips: "NBA Conquest tips for calling games and reading the map",
      faq: "NBA Conquest FAQ: the Daily Challenge and losing everything"
    },
    howToPlaySections: [
      {
        heading: "Picking your team in Imperialism mode",
        items: [
          "Pick your team in Imperialism mode. Every territory on the map starts owned by its nearest NBA arena."
        ]
      },
      {
        heading: "Calling the winner of the featured game",
        items: [
          "Each round, all 30 teams play. Before it runs, you call the winner of the featured game, your team's whenever they play."
        ]
      },
      {
        heading: "Watching the map redraw after each round",
        items: [
          "Watch the results redraw the map as losers hand over entire empires."
        ]
      },
      {
        heading: "Surviving 14 rounds to reach the playoffs",
        items: [
          "Survive 14 rounds. The top 8 empires by territory make the playoffs."
        ]
      },
      {
        heading: "Winning three rounds to rule America",
        items: [
          "Win the Quarterfinals, Semifinals and Imperial Finals to rule America."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "How annexation works each round",
        items: [
          "Winners annex everything the loser owned, every single round.",
          "Wiped off the map does not mean out: one win takes your conqueror's whole empire back."
        ]
      },
      {
        heading: "Scoring predictions and territory",
        items: [
          "Correct predictions pay 25 points each. Final score adds 3 per territory held, 50 for making the playoffs, 200 if your team takes the title."
        ]
      },
      {
        heading: "How playoff seeding is decided",
        items: [
          "Playoff seeding is territories first, season record as the tiebreaker."
        ]
      },
      {
        heading: "What Arcade mode adds",
        items: [
          "Arcade mode is the original formula: battles, stealing a player from every beaten team, and power-ups."
        ]
      },
      {
        heading: "How the Daily Challenge is seeded",
        items: [
          "The Daily Challenge deals every player the same date-seeded season: same starting map, same fixtures, same results. One scored run per day with streaks. Free Play is unlimited and fully random."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Denver's empire falls in round six",
        paragraphs: [
          "You take Denver. Two early wins triple your land, then the Mavericks flatten you in round six and the whole empire changes color."
        ]
      },
      {
        heading: "A revenge win sets up an Imperial Finals run",
        paragraphs: [
          "Round eight, Denver beats Dallas in overtime and takes back everything they own, half of Texas included. You sneak in as the 7 seed and fall in the Imperial Finals to a Celtics empire covering the East Coast. Run it back!"
        ]
      }
    ],
    tipSections: [
      {
        heading: "Predictions as steady income",
        items: [
          "Predictions are steady income. Territories can vanish in one night, but called games are banked forever."
        ]
      },
      {
        heading: "Reading the win percentage before you call it",
        items: [
          "Check the win percentage on each matchup before calling it. Upsets happen, but math is math."
        ],
        subsections: [
          {
            heading: "Why playoff seeding sneaks up fast",
            items: [
              "Peek at the standings. Playoff seeding sneaks up fast, and territories decide it."
            ]
          }
        ]
      }
    ],
    faqs: [
      {
        q: "How does the Daily Challenge work?",
        a: "Everyone on the planet gets the same season today: identical starting map, identical fixtures, identical results. Your score comes from which empire you back and how well you call the games, so comparing scores is a fair fight. One scored run per day, streaks build if you show up daily, and a fresh map drops at midnight Eastern. Free Play stays unlimited."
      },
      { q: "What happens when my team loses everything?", a: "You stay in the game. Landless teams keep playing, and the moment they win they seize their conqueror's entire empire. The best runs start from zero." },
      { q: "Can the season end before round 14?", a: "Yes. If one team conquers every territory, the season ends right there with a total conquest." },
      { q: "How do the two modes differ?", a: "Imperialism is the map format with predictions and annexed empires. Arcade is the original battle mode with player steals and power-ups." }
    ]
  },
  "/nba-front-office": {
    intro: [
      "Running an NBA franchise looks easy from the couch. This sim hands you a curated roster snapshot, a cap sheet and 29 rivals so you can find out.",
      "Waive the deadweight, sign the bargains, swing trades the computer actually weighs, and steer the season toward the bracket and maybe a banner. Dynasties are the real scoreboard."
    ],
    headings: {
      howToPlay: "How to play NBA Front Office, a free NBA GM simulator",
      rules: "NBA Front Office rules: the cap, trades and the play in",
      example: "NBA Front Office walkthrough: a rebuild that reaches game 7",
      tips: "NBA Front Office tips for building a lasting contender",
      faq: "NBA Front Office FAQ: rosters, trades and getting fired"
    },
    howToPlaySections: [
      {
        heading: "Inheriting a roster from 30 franchises",
        items: [
          "Pick any of the 30 franchises. New games use original opening estimates from 2024-25 and 2025-26 regular-season inputs. The e marker means defense and role evidence is limited; unmatched players use a marked game prior. Ages, potential and contracts are simulated. Existing saves keep their ratings and development."
        ]
      },
      {
        heading: "Reading the ownership mandate",
        items: [
          "Read the ownership mandate: a loaded roster is told to win the Finals, a mid one to make the playoffs, a thin one to hit an honest win number. It resets every offseason."
        ]
      },
      {
        heading: "Working the roster with waivers and trades",
        items: [
          "Work the roster. Waive contracts, sign free agents with your cap room, and propose trades."
        ]
      },
      {
        heading: "Simming the season in 20 stretches",
        items: [
          "Sim the season in 20 short stretches, watching the conference standings tighten and the mandate's live pace read."
        ]
      },
      {
        heading: "Making the playoffs, then chasing a repeat",
        items: [
          "Finish top 6 for a direct playoff seed, or 7th through 10th for the play-in.",
          "Win four best of 7 rounds, then draft and rebuild for the repeat, as long as ownership keeps you."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Cap room and roster size limits",
        items: [
          "The cap starts at the real 2026-27 figure, just under 165 million, and rises 7 percent every season in the game. You can waive down to 8 players during the year, but the season cannot tip off with fewer than 14 or more than 15: short of 14 the league fills the gap with minimum deals (2 million each in a new league, rising with the cap) and tells you who, and above 15 the first round waits until you waive down.",
          "New deals are priced in the money of the season they start in. Re-signings, rookie deals, the minimum and free agent asks all rise with the cap, so payrolls stop falling seven percent a year behind the tax line. They still drop over the first couple of seasons, because computer teams let expiring depth walk (all of it when they face a bill) and refill only on minimum deals, so expect fewer taxpayers than a new league opens with; from about the third season payrolls hold steady against the line. A contract already signed keeps its number until it runs out."
        ]
      },
      {
        heading: "Season lines and the five awards",
        items: [
          "Every game writes a box score off the result already decided. Open Roster, then Set rotation to choose five starters and three bench players; selecting someone already chosen swaps their slots. Starters supply 72 percent of strength and the bench 28 percent. The eight slots get 36, 34, 33, 32, 30, 28, 26 and 21 simulated minutes. Injured choices get healthy cover and return when recovered; departed players are replaced. Automatic uses the highest-rated healthy eight. Those same players earn the season lines, their points add up to the team's score, and the winner outscored the loser. If nobody is healthy, the current engine uses its best eight for an emergency box score, even if injured, a simplified injury exception rather than a real NBA rule. These are this save's sim seasons, not real NBA stats.",
          "At season close the league names five awards by fixed rules, and a man needs four in five of an average team's games to qualify (about 64 of 80). MVP: points plus rebounds plus assists a game, plus 20 times his club's winning share. All-League First Team: the five best by the MVP score, any position. Rookie of the Year: points plus rebounds plus assists a game, among first year men drafted in this league, so a new league's first season has none. Defensive Player of the Year: steals plus blocks plus half his rebounds a game, among men whose club allowed fewer points than the league average. Sixth Man of the Year: points a game, among men who started fewer than half the games they played.",
          "The close screen shows the awards, the points, rebounds and assists leaders and your own club's lines. Winners wear the award on their roster card, and the Standings box keeps every season's champion and awards. A save from before season lines plays out its current season without them and starts keeping them next season."
        ]
      },
      {
        heading: "The luxury tax, the aprons and the repeater rate",
        items: [
          "The real league put its 2026-27 tax line at 200.4 million, but the salaries here are the game's own and run richer at the top, so every new league sets its line from its own payrolls instead: enough clubs over it to look like a real season (eight paid tax in 2023-24), but nobody facing a bill above 190 million, about the most any club has ever been billed. The opening line is 226.7 million, with five clubs over it once minimum deals fill the rosters. Your cap panel shows current contracts and a separate tipoff forecast that includes those missing deals. The line rises 7 percent a season with the cap.",
          "Every dollar of payroll over the line, dead money included, is taxed at season close in brackets about 3 percent of the line wide (6.9 million in a new league), at the league's real rates: 1.00 and 1.25 on the first two brackets, 3.50 and 4.75 on the next two, then half a dollar more per bracket. Pay tax in three of the previous four seasons and you are a repeater, taxed at 3.00, 3.25, 5.50 and 6.75 on the same brackets.",
          "The cap panel shows the projected bill all season. At close the bill is listed beside the results, ownership takes one point of trust per 6 million of it (never more than 20), and the money is held back from next season's cap room. Above the first apron (236.4 million in a new league) a trade has to send out at least the salary it brings back. Computer teams that pay tax let their expiring depth walk the next summer, so the line moves the whole league, not just you. A save from before the tax plays out its current season untaxed and gets its line that summer."
        ]
      },
      {
        heading: "How trade negotiations play out",
        items: [
          "Trades are a negotiation now: open talks and the other GM answers with a handshake, a pick demand, a lesser man, or the dial tone. You can stand firm exactly once per call, and it genuinely gambles: they blink and the price drops, or they dig in and it rises."
        ]
      },
      {
        heading: "Reaching the play in for seeds seven to ten",
        items: [
          "The play-in covers seeds 7 through 10, with one last game deciding the 8 seed."
        ]
      },
      {
        heading: "Draft classes and scouting uncertainty",
        items: [
          "Each club starts with 2 simulation picks. Trades can leave you with fewer or more choices, and each selection spends one owned pick. With none left, finish the draft and offseason. The pool has at least 24 prospects, and rivals get two batches of up to five eligible selections in this abbreviated draft. Scouting grades can miss the truth by a few points either way."
        ]
      },
      {
        heading: "How aging and decline work each summer",
        items: [
          "Everyone ages each summer: young players develop toward potential, decline starts at 32, veterans retire."
        ],
        subsections: [
          {
            heading: "What moves the trust meter",
            items: [
              "Trust upstairs runs 0 to 100: beat the mandate and it climbs, miss it and it falls, a banner fixes almost anything, and at zero you are fired and the save ends."
            ]
          }
        ]
      },
      {
        heading: "Waiving a player and the dead money",
        items: [
          "Waiving a man is not free. Half his salary stays on this season's cap as dead money, a quarter lands on next season's if he had years left, and you cannot sign him back until the offseason."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Trading an aging star for a young pick",
        paragraphs: [
          "You take a bubble team and ship an aging star for a 24 year old, pick attached. The season starts ugly."
        ]
      },
      {
        heading: "A 9 seed run that ends in the conference finals",
        paragraphs: [
          "Then the kid pops. You sneak in at the 9 seed, win two play-in games, upset the 1 seed in seven, and lose the conference finals. The rookie scouted at 91 comes in at 87. Run it back."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Why age is the real trade currency",
        items: [
          "Age is currency. The trade engine pays a premium for anyone 24 and under, so shop aging names early."
        ]
      },
      {
        heading: "Bench quality matters when injuries hit",
        items: [
          "Your best five carry most of the load, but bench quality is real when injuries hit."
        ]
      },
      {
        heading: "A champion roster is never truly finished",
        items: [
          "A champion is never finished. Contracts expire, and some role players walk every summer."
        ]
      }
    ],
    faqs: [
      { q: "Are the rosters real?", a: "The players are real, about ten curated per franchise in a roster snapshot. OVR is an original simulation estimate, with limited box-score defense and unchanged seed roles. Prior-only and unmeasured estimates are marked separately. Contracts, salaries and ages are simulated, and later ratings come from your saved career." },
      { q: "Why did my trade get rejected?", a: "The engine values rating adjusted for age and wants to come out ahead. Offer youth, take back age, or add a pick." },
      { q: "Can I get fired?", a: "Yes. Ownership grades the mandate every season and tracks trust from 0 to 100. Losing the play-in when the ask was a banner costs real trust, a luxury tax bill costs a point per 6 million of it, and at zero the save ends and you take another job." },
      { q: "What happens if I start the season with 12 players?", a: "The league fills you to 14 at tip off with the lowest rated free agents in the pool on one year minimum deals (2 million each in a new league, rising with the cap), and the feed names them. Sign who you actually want before you press play. With 16 or more you cannot start until you waive down to 15." },
      { q: "Does my save persist?", a: "Yes, the league auto saves in your browser across unlimited seasons. Clearing site data wipes the franchise." },
      { q: "Are the season stats and awards real?", a: "No. The rosters use real names, but every line, leader and award comes from the games your save simulated. A star on a losing club can lose the MVP to a smaller line on a winner, because the rule counts his club's record." }
    ]
  },
  "/nba-my-career": {
    intro: [
      "Draft night is where it starts: a made up prospect with your name, landing in a real NBA locker room. Where it ends is up to your summers.",
      "Each season prints a stat line shaped by your rating, archetype, health and team quality. Each summer drops up to three decisions on your desk, one card at a time, drawn from over a hundred of them: contracts, surgeries, trade demands, tunnel fits, a rookie who idolises you, a mural in your neighborhood.",
      "You build your player's actual face before the draft, and there is a dirty side waiting whenever you want it. Taking the under on your own rebound totals, faking load management for a bettor, tanking in March, an agent advance you were never supposed to mention. Every dirty choice raises a hidden league integrity meter, and at the top of it is an indefinite suspension and a comeback on the minimum."
    ],
    headings: {
      howToPlay: "How to play NBA My Career, a free NBA basketball career sim",
      rules: "NBA My Career rules: ratings, the rotation and the bank",
      example: "NBA My Career walkthrough: rookie drama to a title run",
      tips: "NBA My Career tips for building a lasting legacy",
      faq: "NBA My Career FAQ: real teams, free agency and badges"
    },
    howToPlaySections: [
      {
        heading: "Creating your player and picking a league",
        items: [
          "Create your player: name, one of 5 positions (PG, SG, SF, PF, C), and one of 15 archetypes, from Point God to Movement Sniper to Paint Beast.",
          "Pick your league: today's NBA, or the 2003-04 throwback with the SuperSonics in Seattle, the Nets in New Jersey, the Hornets in New Orleans and no Charlotte yet."
        ],
        subsections: [
          {
            heading: "Building your player's look",
            items: [
              "Build your look: skin tone, hair, beard, accessories and a signature celebration, or hit Surprise me."
            ]
          }
        ]
      },
      {
        heading: "Managing your money between seasons",
        items: [
          "Open the Bank between seasons. Savings pays 2.5% a season and never loses, five things you can put money into each have a price that moves every season whether you look or not (a fund, flats back home, two shares and a coin that halves as often as it doubles), the statement keeps your last 12 moves, and the card school on the team plane is one sitting a season on odds that are printed before you sit in."
        ],
        subsections: [
          {
            heading: "Spending across seven aisles",
            items: [
              "Spend the money in 7 aisles: home, rides, investments, body, flex, family, and a shady aisle that only appears once you have something to hide."
            ]
          }
        ]
      },
      {
        heading: "Following your career in the News box",
        items: [
          "Read the News box. The paper writes up every season in your own position's stat, the SocialGram shows followers read off your fanbase with three fan comments under the latest post, and the rival's card keeps the head to head against the player drafted the same year as you."
        ],
        subsections: [
          {
            heading: "Collecting badges in the Trophy Case",
            items: [
              "Collect badges in the Trophy Case: 23 of them, from a first ring and Rookie of the Year to an All-Star nod, 30,000 career points, a triple double season and $100M to your name, each lit the moment the facts of your career say so."
            ]
          },
          {
            heading: "Answering your phone on the basketball calendar",
            items: [
              "Answer your phone. Texts from your agent, the head coach, the GM, a teammate or your mom land on the beats of the basketball year: draft night and your first summer league, camp, the trade deadline, the All-Star break, the playoffs if you get there, the offseason, and the summer before the last year of your deal. Every text says which beat and which year it came in on, and how you answer moves your karma, morale, fanbase or bank."
            ]
          },
          {
            heading: "Making the call when your rival forces one",
            items: [
              "Some seasons your rival hands you a decision instead of a headline: a flagrant you can answer or let go, a debate show offering real money, a youth camp his foundation wants you to co-host, an All-Star vote his team is buying ads for. Every button prints exactly what it moves, and a gamble prints its odds."
            ]
          }
        ]
      },
      {
        heading: "Getting drafted and cracking the rotation",
        items: [
          "Get drafted by a real NBA team. Stronger prospects go higher and earn more.",
          "Check the rotation. Top five picks open in the starting five; everyone else fights for the spot in camp every fall, and second-unit seasons come in bench minutes until you crack the five."
        ]
      },
      {
        heading: "Playing seasons and handling the offseason",
        items: [
          "Sim each season for a full line: games, minutes, points, rebounds, assists, steals, blocks, awards, team result.",
          "Press \u{1F4FA} Week by week instead of Play the season to watch that season one game at a time, with your stat line and your team's record after every game. It is the same season either way.",
          "Throwback careers play against unnamed teams, and the real seasons that were not a full 82 games (2011-12, 2012-13, 2019-20 and 2020-21) have no game by game view. The game tells you before you press.",
          "Handle the summer, up to three decisions one card at a time. Only the first card can move your rating, and a card you just saw rests for a while (press moments follow your season, so those can come right back).",
          "After a normal offseason choice, the result shows the actual changes. Expand it for any extra changes, then Continue opens the next card, or takes you back to your career after the last one, without applying the choice again.",
          "Open Career Log and pick a year to review its saved overview, regular season and postseason. Changes compare with the previous saved season; older missing values say Not recorded. Back to seasons returns to the year tiles, and Review seasons is available after retirement."
        ],
        subsections: [
          {
            heading: "Working a real free agency window",
            items: [
              "When the contract runs out, work a real free agency window: competing offers from named franchises with their own money, length and roster quality, and one push for more on any of them."
            ]
          },
          {
            heading: "Retiring and facing the legacy verdict",
            items: [
              "From 31, a falling rating brings the retirement talk: stop now, one more year, or a farewell season that ends the career after it. Then face the legacy verdict and the Hall of Fame wait."
            ]
          }
        ]
      }
    ],
    ruleSections: [
      {
        heading: "How archetypes and ratings work together",
        items: [
          "Archetypes shape the stat engine: Point Gods pile up assists, Paint Beasts eat rebounds, Bucket Getters score but break down more.",
          "From 2023-24, MVP and All-NBA eligibility use the 65 game rule. Rating alone does not promise an award: your season production, role and team record matter."
        ],
        subsections: [
          {
            heading: "How growth and decline unfold",
            items: [
              "Growth runs to age 25, decline starts at 32, and health erodes late unless you invest in it."
            ]
          }
        ]
      },
      {
        heading: "How real the rotation actually is",
        items: [
          "The rotation is real: the man ahead of you is as good as your roster is, camps have memory both ways, bench seasons run at about 60 percent of a starter's numbers, and Sixth Man of the Year goes to actual second-unit seasons now. Joining a loaded contender can cost a mid player his spot in the five."
        ]
      },
      {
        heading: "How the press reads your season",
        items: [
          "The press reads your actual season: a banner puts you on the podium, a collapse puts you in the scrum, a second-unit year brings the role question. Three answers every time, safe, honest or fiery, and the fiery one gambles your fanbase for real."
        ],
        subsections: [
          {
            heading: "When a career finally ends",
            items: [
              "Careers end at 41, after 21 seasons, or when the rating craters. You can also walk anytime.",
              "Hall of Fame voters weigh the hardware first (rings, MVPs, Finals MVPs, All-NBA years), then your seasons and your numbers, and a career total near the top of this game's books in a stat your position really piles up (points, rebounds or assists) earns a push of its own, up to 390 legacy points.",
              "Example: take a point guard with ordinary numbers and one with the same hardware and more assists than 99 of 100 point guards this game has seen. The second scores at least 300 legacy points more, which can be the whole gap between a long wait and the Hall. A career you already retired keeps the ballot it was told."
            ]
          }
        ]
      },
      {
        heading: "Playing inside the 2003 throwback world",
        items: [
          "The 2003-04 throwback is a sealed 29 team world, verified against the real season: every draft, trade and signing stays inside it, and contracts pay 2003 money, about a third of today's."
        ]
      },
      {
        heading: "Money rules in the Bank and what fans nag about",
        items: [
          "Money has rules of its own. There is a 1% fee on both sides of every trade and a $100k floor in the account that cannot be invested away; a season that leaves you under the floor is covered out of savings first, then by a forced sale of holdings at whatever the price is that day. Cards win 42% of hands and a win pays 1.15x the stake, the most you can stake is $50k or 4% of your cash, and once you are $500k down for your career the guys stop dealing you in for good. Keep sitting in while you are losing and somebody at home notices, which costs morale and fanbase.",
          "The fans nag you for the thing your position is judged on and never the other way round: a point guard hears more assists, a center hears own the glass, and nobody hears about a three, because the season line does not count one."
        ]
      },
      {
        heading: "How your rival's choices work",
        items: [
          "A season where your rival makes no headline has a 45% shot at a rival choice instead, never both in the same year, and every choice shows up once before any of them repeats. The buttons move only what they print: morale, fanbase, net worth, karma or the heat of the feud, and morale feeds straight into next season's box score."
        ]
      },
      {
        heading: "How the phone's calendar works",
        items: [
          "Texts only arrive on beats your season really had. No playoff texts in a year you went home in April, no contract year texts until one year is left on the deal, and draft night's texts land before you play a game. Summer league comes round twice at most: the July after draft night and the one after your rookie year. One text a beat, up to three a season, fewer while old ones sit unanswered, and the same text never comes twice in a career.",
          "The season the game retires you (41, 21 seasons, or a rating that craters) sends nothing about a year you will not play: no summer runs, no early lifts, no extension talk."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Reading an actual capped change",
        paragraphs: [
          "Say Health is 98 before a recovery choice that adds 10. The 100 cap makes the result 98 to 100, so the card shows +2. Continue moves you on (to the next card, or back to your career after the last one) with Health still at 100."
        ]
      },
      {
        heading: "A Rookie of the Year season turns sour",
        paragraphs: [
          "You roll a Two-Way Menace guard, go 11th, and win Rookie of the Year on a bad team. Year three, morale craters and you demand a trade. Villain arc unlocked."
        ]
      },
      {
        heading: "A title, a Finals MVP and a Hall of Fame verdict",
        paragraphs: [
          "The new team contends. You take the discount at 28, win it all at 30, and grab Finals MVP. Decline arrives at 33, surgery buys two more years, and the verdict reads first ballot Hall of Famer. The GOAT tier stays out of reach. It usually does."
        ]
      },
      {
        heading: "Answering your rival's flagrant",
        paragraphs: [
          "Your rival takes you out on a drive and the refs upgrade it to a flagrant. Give it right back heats the feud and usually pays Morale +8, but it carries a 30% chance you are the one who gets tossed (Morale -5, Fanbase -5, Net worth -$100k). Help him up on camera is Fanbase +5, Karma +5 and the feud cools. You pick say nothing and watch the film: Morale +6, the feud heats up, and those six points ride into next season's box score."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Choosing an archetype built to last",
        items: [
          "Pick the archetype for the career you want to live. Durability differences are real."
        ]
      },
      {
        heading: "Why low health is worth fixing fast",
        items: [
          "Do not sit on low health. Injuries shred seasons, and awards need games played."
        ]
      },
      {
        heading: "Free agency as a basketball decision, not just money",
        items: [
          "Team quality moves your stats and playoff odds. Free agency is a basketball decision, not just money: the contender offers less than the rebuild, and the roster number on the card is what your next seasons actually run on."
        ]
      }
    ],
    faqs: [
      { q: "Can I play as a real NBA star?", a: "No, your player is fictional by design. The teams around you are real, 30 of them today and 29 in the throwback, but the career is yours to invent." },
      { q: "Can I start in a different era?", a: "Yes. The create screen has a 2003-04 throwback: the 29 team league with the Seattle SuperSonics, the New Jersey Nets and the New Orleans Hornets, and no Charlotte franchise yet. An era career never meets a team that did not exist then." },
      { q: "How does free agency work?", a: "An expired deal opens a window of real offers: your team's re-sign number plus named suitors, each with its own salary, years and roster quality. You can push any offer for more once. A weak case can get an offer pulled, but your own team never walks, so there is always a deal to sign." },
      { q: "Why am I coming off the bench?", a: "Because the starter is better, for now. Late picks usually open with the second unit behind an incumbent whose level tracks the roster's quality. Grow your rating and you will crack the five; until then bench minutes mean smaller numbers, slower fame and a real shot at Sixth Man of the Year. A thin rebuild is the fastest route to starting." },
      { q: "What does the legacy score reward most?", a: "MVPs and rings move it hardest, then Finals MVPs and All-NBA nods, plus longevity and points. The top verdict is the GOAT conversation, and it takes a stacked case." },
      { q: "What is in the Bank?", a: "Four tabs. Account holds your cash, a savings account that pays 2.5% a season, and a statement of your last 12 moves. Market is five prices that move every season, each with its own risk word and a read on whether it is cheap or dear against what it usually goes for. Cards is the card school on the team plane, one sitting a season, on odds the screen prints before you play. Shop is the 7 aisles. It is the same engine Soccer Career's phone runs on, in dollars." },
      { q: "Who is my rival?", a: "A generated player drafted the same year at your position. He plays his own seasons on the same scale you do, can win a ring before you and retire before you, and the head to head is kept for good. He is fictional, like your own player, so no real player's career is being simulated." },
      { q: "How do I earn badges?", a: "By doing the thing. Each of the 23 badges is a test on the facts of your career, checked every time you open the case: a ring, an MVP, an All-Star nod, twenty thousand points, five seasons with all 82 games played, a million dollars to your name. The 30 point season badge sits a long way under the single season scoring record, Wilt Chamberlain's 50.4 a game in 1961-62, which is where it belongs." },
      { q: "Is my career saved?", a: "Yes, progress auto saves in your browser. One career at a time, and starting fresh means retiring first." }
    ]
  }
};

// src/data/gameContent/baseball.ts
var BASEBALL_CONTENT = {
  "/perfect-season-mlb": {
    intro: [
      "The wheel spins across a century of baseball and stops on a real team season, maybe the 1927 Yankees, maybe a club nobody remembers. You draft one player, then spin again.",
      "Eleven picks later you own a lineup stitched from every era, and the sim makes you sweat all 162 games. The number to chase is 116 wins, the big league record shared by the 1906 Cubs and the 2001 Mariners."
    ],
    headings: {
      howToPlay: "How to play 162-0 MLB Perfect Season, a free baseball draft simulation",
      rules: "162-0 MLB Perfect Season rules: rerolls, modes and lineup slots",
      example: "162-0 MLB Perfect Season walkthrough: an all era dream lineup",
      tips: "162-0 MLB Perfect Season tips for rerolls, the DH slot and Hard mode",
      faq: "162-0 MLB Perfect Season FAQ: perfect runs and daily mode"
    },
    howToPlaySections: [
      {
        heading: "Spinning the wheel for a real team season",
        items: [
          "Spin the wheel. It stops on a real team season from 1901 onward."
        ]
      },
      {
        heading: "Drafting one player into an open lineup slot",
        items: [
          "Draft one player into an open slot. Ratings run 40 to 99, built from real stats that year."
        ],
        subsections: [
          {
            heading: "Filling all eleven lineup slots",
            items: [
              "Repeat until all 11 slots are filled: eight fielders, a DH, a starting pitcher and a relief ace."
            ]
          }
        ]
      },
      {
        heading: "Using a reroll when a spin misses",
        items: [
          "Hate a spin? Use a reroll, you get 2 per run."
        ]
      },
      {
        heading: "Watching the season simulate game by game",
        items: [
          "When the lineup is full, the season simulates win by win. Skip ahead any time."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Eleven slots, one draft, no repeat names",
        items: [
          "11 lineup slots, one draft per spin, no player name used twice."
        ]
      },
      {
        heading: "Two rerolls and the full season length",
        items: [
          "2 rerolls per run, and every season is a full 162 games."
        ]
      },
      {
        heading: "Classic, Hard and Daily modes explained",
        items: [
          "Three modes: Classic shows ratings, Hard hides them until the season ends, Daily gives everyone the same wheel and one attempt per day."
        ],
        subsections: [
          {
            heading: "The daily's theme and its midnight reset",
            items: [
              "The daily has a theme limiting which team seasons the wheel can hit, and it resets at midnight Eastern."
            ]
          }
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Drafting Lou Gehrig, Bob Gibson and Ken Griffey Jr.",
        paragraphs: [
          "Your first spin lands on the 1927 Yankees, so Lou Gehrig locks in at first base. Later stops bring Bob Gibson off the 1968 Cardinals, then Ken Griffey Jr. from the 1997 Mariners for center field."
        ]
      },
      {
        heading: "A strong draft takes a run at 116 wins",
        paragraphs: [
          "The finished squad rates 84 overall, better than nine well drafted lineups in ten. The sim never cools off and the board reads 131-31, fifteen wins past the record. A perfect 162-0 at 84 comes about one run in more than a trillion, so 131 is the brag."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Saving rerolls for the endgame",
        items: [
          "Save rerolls for the endgame. Early spins always offer someone useful, but one stubborn open slot late can strand you."
        ]
      },
      {
        heading: "Filling the DH slot last",
        items: [
          "Fill DH last. Any qualified bat is eligible there, the perfect parking spot for a monster whose position is taken."
        ]
      },
      {
        heading: "Reading stat lines in Hard mode",
        items: [
          "In Hard mode, read the stat lines. A tiny ERA or a 40 homer season says plenty while ratings are hidden."
        ]
      }
    ],
    faqs: [
      { q: "Is 162-0 actually possible?", a: "On paper. A 95 lineup goes 162-0 about one run in 41, but the wheel almost never deals one: we drafted 200,000 lineups the way a good player would, and the best one in a hundred rated about 86, where 162-0 comes about one run in 27 billion. The real chase is 116 wins, and about one well drafted lineup in four gets there." },
      { q: "How does daily mode work?", a: "Everyone spins the same wheel under the same theme, one attempt per day, locked until midnight Eastern. Classic and Hard stay unlimited." }
    ]
  },
  "/baseball-career": {
    intro: [
      "One mystery player, six clues, and a score that shrinks every time you peek. Career Path starts you with nothing but a position and dares you to name the player before the easy clues arrive.",
      "The ladder runs from draft info through teams, stats and awards. Diehards nail it in two clues. The rest of us wait for the trophy case."
    ],
    headings: {
      howToPlay: "How to play MLB Career Path, a free guess the baseball player game",
      rules: "MLB Career Path rules for clues, points and hard mode",
      example: "MLB Career Path walkthrough: naming Mike Trout from the draft clue",
      tips: "MLB Career Path tips for draft year, teams and free guesses",
      faq: "MLB Career Path FAQ: clue order, hard mode and daily play"
    },
    howToPlaySections: [
      {
        heading: "Reading the opening position clue",
        items: [
          "Read the opening clue. You always start with the player's position."
        ]
      },
      {
        heading: "Typing a free guess at any time",
        items: [
          "Type a guess whenever you have a hunch. Wrong guesses cost nothing, so swing freely."
        ]
      },
      {
        heading: "Revealing clues from draft details to awards",
        items: [
          "Stuck? Reveal the next clue: draft details, first team, career teams one at a time, then stats and awards."
        ],
        subsections: [
          {
            heading: "Banking points at your current clue level",
            items: [
              "Guess correctly to bank the points shown for your current clue level."
            ]
          }
        ]
      },
      {
        heading: "Choosing Daily or Unlimited mode",
        items: [
          "Play the daily or switch to Unlimited for random players."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Scoring 1000 on the opening clue",
        items: [
          "A correct guess on the opening clue scores 1000 points."
        ]
      },
      {
        heading: "What each reveal costs you",
        items: [
          "Each of the first five reveals costs 150 points, stepping you down to 250. The sixth and final reveal still leaves 100 on the table."
        ],
        subsections: [
          {
            heading: "Wrong guesses staying free and unlimited",
            items: [
              "Wrong guesses are free and unlimited. Only reveals cost points."
            ]
          }
        ]
      },
      {
        heading: "Last names counting as a correct answer",
        items: [
          "Typing just the last name counts as a correct answer."
        ]
      },
      {
        heading: "Hard mode and the midnight reset",
        items: [
          "Hard mode hides the two easiest clues. The daily resets at midnight Eastern."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Naming Mike Trout off the draft clue",
        paragraphs: [
          "The position says center field, which narrows nothing. The draft clue shows a 2009 first round pick, then the first team: the Angels. A certain kind of fan types Mike Trout right there and banks 700 points."
        ]
      },
      {
        heading: "Seeing the stats clue worth far less",
        paragraphs: [
          "The stats clue would have made it obvious anyway, but at 400. That gap is the whole game."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Draft year plus first team as the killer combo",
        items: [
          "Draft year plus first team is the killer combo. Most players are solvable right there at 700."
        ]
      },
      {
        heading: "Reading an early journeyman stop as a fingerprint",
        items: [
          "Career teams appear one at a time, and an early journeyman stop is often the best fingerprint."
        ]
      },
      {
        heading: "Never skipping the free swing",
        items: [
          "Never skip the free swing. A wild guess at 1000 costs you nothing."
        ]
      }
    ],
    faqs: [
      { q: "What do the clues reveal, in order?", a: "Position, then draft details, first MLB team, career teams added one by one, career stats, and finally awards." },
      { q: "Does hard mode change the scoring?", a: "No. It only hides the two easiest clue rows, so you are working from the first team onward while the points stay the same." },
      { q: "Is there a new player every day?", a: "Yes. The daily serves everyone the same player and flips at midnight Eastern. Unlimited deals random players all day." }
    ]
  },
  "/mlb-higher-lower": {
    intro: [
      "Two legends side by side, one question: who hit more career home runs? Easy, right up until Frank Robinson is staring at Mark McGwire and the real gap is three homers.",
      "The pool is finished careers only, Ruth through Ortiz, so every number is final. No active stars with totals still moving."
    ],
    headings: {
      howToPlay: "How to play MLB Higher or Lower, a free daily home run trivia game",
      rules: "MLB Higher or Lower rules for rounds, streaks and ties",
      example: "MLB Higher or Lower walkthrough: Griffey, Ruth and an exact tie",
      tips: "MLB Higher or Lower tips for eras, tiers and streaks",
      faq: "MLB Higher or Lower FAQ: the player pool, scoring and ties"
    },
    howToPlaySections: [
      {
        heading: "Reading two players with no totals shown",
        items: [
          "Each round shows two players with their era and seasons played, but no totals."
        ]
      },
      {
        heading: "Tapping the player with more home runs",
        items: [
          "Tap the one you think finished with more career home runs."
        ]
      },
      {
        heading: "Watching the reveal and the next pair load",
        items: [
          "The real numbers flash, your score updates, and the next pair rolls in."
        ]
      },
      {
        heading: "Surviving all ten rounds",
        items: [
          "Survive all 10 rounds, then share your score."
        ],
        subsections: [
          {
            heading: "Choosing Daily or Unlimited pairs",
            items: [
              "Play Daily for the same 10 pairs as everyone else, or Unlimited for random pairs."
            ]
          }
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Ten rounds worth ten points each",
        items: [
          "10 rounds per game and 10 points for every correct answer."
        ]
      },
      {
        heading: "Stacking bonus points on a streak",
        items: [
          "Streaks pay extra: the second straight correct adds 5 bonus points, the third adds 10, and so on. A perfect 10 for 10 scores exactly 325."
        ]
      },
      {
        heading: "Exact ties counting either way",
        items: [
          "Exact ties count as correct no matter which side you pick."
        ]
      },
      {
        heading: "Hard mode and the midnight flip",
        items: [
          "Hard mode builds close-gap pairs and only runs in Unlimited. The daily flips at midnight Eastern."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Griffey over Thome and Ruth over Sosa",
        paragraphs: [
          "Round one deals Ken Griffey Jr. against Jim Thome. Feels close. You back Junior and the reveal reads 630 to 612. A few rounds later Babe Ruth lands opposite Sammy Sosa and you cruise, 714 beats 609."
        ]
      },
      {
        heading: "Splitting an exact tie at 521 homers",
        paragraphs: [
          "Then it gets mean: Ted Williams against Willie McCovey. Both men finished on exactly 521, so either tap scores. You close at 8 for 10 with the streak bonus padding the total."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Weighing seasons played against era",
        items: [
          "Seasons played matter as much as era. A 22 year career from the 1950s can out-homer a short modern peak."
        ]
      },
      {
        heading: "Learning who cleared 600 home runs",
        items: [
          "Learn the tiers. Knowing who cleared 600 and who stalled in the 500s decides the coin flip rounds."
        ]
      },
      {
        heading: "Protecting your streak in the late rounds",
        items: [
          "Protect your streak late. The bonus grows with every consecutive answer, so the last rounds are worth the most thought."
        ]
      }
    ],
    faqs: [
      { q: "Why are there no active players?", a: "Career totals only make sense once the career is over, so the pool sticks to finished careers and every total is the real final number." },
      { q: "What is the highest possible score?", a: "325. That is 100 points for going 10 for 10 plus 225 in streak bonuses for never missing." },
      { q: "What happens on an exact tie?", a: "You get credit either way. Ted Williams, Willie McCovey and Frank Thomas all retired on 521 home runs, so it really does come up." }
    ]
  },
  "/mlb-grid": {
    intro: [
      "Nine cells, nine legends. Every cell crosses two categories, and you need a player whose career checks both boxes. Think of it as an MLB team grid tuned for the legends era.",
      "The whole answer pool finished playing by 2019, so this is a history test, not a current-roster quiz."
    ],
    headings: {
      howToPlay: "How to play MLB Franchise Grid, a free daily baseball guessing game",
      rules: "MLB Franchise Grid rules for guesses, milestones and franchises",
      example: "MLB Franchise Grid walkthrough: Babe Ruth and Harmon Killebrew",
      tips: "MLB Franchise Grid tips for journeymen and famous names",
      faq: "MLB Franchise Grid FAQ: franchises, validation and difficulty"
    },
    howToPlaySections: [
      {
        heading: "Reading franchise and milestone labels",
        items: [
          "Read the row and column labels: franchises like the Yankees or Cardinals, plus career milestones like 2,000 hits."
        ]
      },
      {
        heading: "Tapping a cell and typing a name",
        items: [
          "Tap any empty cell, type a player name, and pick them from the list."
        ],
        subsections: [
          {
            heading: "Locking in a cell that matches both labels",
            items: [
              "If the career matches both the row and the column, the cell locks in."
            ]
          }
        ]
      },
      {
        heading: "What a missed guess costs you",
        items: [
          "Miss and you burn one of your 9 guesses. Correct answers never cost a guess."
        ]
      },
      {
        heading: "Filling all nine cells before guesses run out",
        items: [
          "Fill all 9 cells before the guesses run out."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Nine guesses for the whole grid",
        items: [
          "You get 9 wrong guesses for the whole grid, and each player can only be used once."
        ]
      },
      {
        heading: "What counts as a milestone",
        items: [
          "Milestones are 2,000 or more hits, 300 or more home runs, and 2,000 or more games played."
        ]
      },
      {
        heading: "Franchise history across relocations",
        items: [
          "Franchise history counts across relocations, so a Brooklyn Dodger counts for the Dodgers."
        ]
      },
      {
        heading: "Why active stars will not validate",
        items: [
          "Active stars will not validate, the pool ends at 2019."
        ],
        subsections: [
          {
            heading: "Daily, easy, normal and hard modes",
            items: [
              "Daily gives everyone the same grid and saves your board until midnight Eastern. Unlimited deals random grids in easy, normal or hard."
            ]
          }
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Saving Babe Ruth for a harder cell",
        paragraphs: [
          "Your grid crosses a Yankees row with a Red Sox column, and Babe Ruth is the reflex. He works, but a name that big might fit other cells, so you hold him until nothing else fits."
        ]
      },
      {
        heading: "Locking Jim Thome and Harmon Killebrew",
        paragraphs: [
          "Then Cleveland meets 300 home runs. Jim Thome, lock. The last cell, Twins plus 2,000 games played, eats two guesses before Harmon Killebrew completes the nine."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Why journeymen beat superstars",
        items: [
          "Journeymen beat superstars. A well-traveled veteran with 2,500 hits covers strange franchise pairings that one-club icons never will."
        ]
      },
      {
        heading: "Targeting stars from the 80s through 2000s",
        items: [
          "With the pool capped at 2019, stars of the 80s, 90s and 2000s are the sweet spot."
        ]
      },
      {
        heading: "Spending famous names only when needed",
        items: [
          "Spend famous names only where nothing else works. Each player plays once per grid."
        ]
      }
    ],
    faqs: [
      { q: "Do relocated franchises count?", a: "Yes, franchise identity survives every move. Boston, Milwaukee and Atlanta Braves all count as one franchise." },
      { q: "Why will a current star not validate?", a: "The pool is careers that wrapped by 2019, so you never waste guesses on players whose numbers are still growing." },
      { q: "Is the daily grid harder than unlimited?", a: "The daily always uses the normal mix, one milestone plus five franchises. Unlimited lets you pick easy with two milestones, normal, or hard with franchises only." }
    ]
  },
  "/mlb-gauntlet-draft": {
    intro: [
      "The draft mode, baseball style: eleven picks, one per spot on the lineup card, five real players a pick from a genuine star to a bargain, and you keep exactly one.",
      "Then October begins. Your finished lineup runs five knockout rounds against ever stronger invented opposition, rated 74 up to 97, with extra innings when the game is level.",
      "The run is decided entirely by the lineup you drafted: the same lineup always runs the same postseason, so every pick is the game."
    ],
    headings: {
      howToPlay: "How to play Gauntlet Draft: MLB, a free daily lineup draft game",
      rules: "Gauntlet Draft: MLB rules for cards, ratings and the knockout",
      example: "Gauntlet Draft: MLB walkthrough: an 89 rated lineup runs October",
      tips: "Gauntlet Draft: MLB tips for pitching cards and the DH spot",
      faq: "Gauntlet Draft: MLB FAQ: daily drafts, opponents and abbreviations"
    },
    howToPlaySections: [
      {
        heading: "Choosing the daily gauntlet or unlimited",
        items: [
          "Pick the daily gauntlet (the same five card choices for everyone today) or unlimited for a fresh draft."
        ]
      },
      {
        heading: "Reading five cards for each lineup spot",
        items: [
          "For each spot, catcher through closer, read the five cards, star to bargain, and tap the one you keep."
        ],
        subsections: [
          {
            heading: "Why a catcher can turn up at DH",
            items: [
              "The spots follow real baseball. The corner outfield cards take either corner, center field does not, and the designated hitter card takes any position player at all, so a catcher turning up as your DH is correct rather than a glitch."
            ]
          }
        ]
      },
      {
        heading: "Watching the postseason start on its own",
        items: [
          "After the eleventh pick the postseason starts on its own: five rounds, one game each, revealed one at a time."
        ]
      },
      {
        heading: "Scoring points for each round survived",
        items: [
          "Survive a round for 16 points; win the Series for exactly 100."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Real players off real 2026 rosters",
        items: [
          "Every card is a real player off a real 2026 roster, 30 clubs and 13 players each, the same data MLB Front Office plays. Every opponent club is invented on purpose."
        ]
      },
      {
        heading: "How ratings come from real production",
        items: [
          "Ratings are derived from real production, not opinion: hitters from their 2025 OPS percentile, pitchers from a fielding independent percentile, closers with a save load nudged up a little."
        ]
      },
      {
        heading: "A star and a bargain in every spot",
        items: [
          "The five cards per spot are spread across the pool's rating range, so a star and a bargain are always both on the table."
        ],
        subsections: [
          {
            heading: "No player dealt twice in one draft",
            items: [
              "No player is dealt twice in one draft."
            ]
          }
        ]
      },
      {
        heading: "A deterministic knockout built on the rating gap",
        items: [
          "The knockout is deterministic in your lineup: scoring comes from the rating gap, level games go to extra innings, and replaying the same lineup replays the same October."
        ]
      },
      {
        heading: "Climbing opposition ratings through October",
        items: [
          "Opposition ratings climb 74, 81, 87, 92, 97. A bargain lineup usually goes out in the first two rounds, an elite one reaches the Series, and even a perfect draft takes the title about one run in four."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Picking the highest rated shortstop card",
        paragraphs: [
          "The shortstop spot deals a 94 next to an 88, an 84, a 79 and a 71. Nothing costs anything, so the 94 is the pick unless you are collecting one club."
        ]
      },
      {
        heading: "Running an 89 rated lineup through October",
        paragraphs: [
          "Your finished lineup rates 89. The Wild Card is comfortable, the Division Series goes to extra innings, the Championship Series is a shutout win, and the Pennant ends the run. Three rounds survived, 48 points, and the card you would take back is the 71 you shrugged at in right field."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Weighing pitching cards as heavily as bats",
        items: [
          "The pitching cards move the rating as much as the bats do. A 96 starter next to a 70 is the single biggest swing on the card."
        ]
      },
      {
        heading: "Why the DH spot often hides the best card",
        items: [
          "The designated hitter spot is dealt last and can hand you anybody, so it is often where the best remaining card of the whole draft turns up."
        ]
      },
      {
        heading: "Watching the running rating as you build",
        items: [
          "Titles need a lineup in the mid nineties. Watch the running rating under the cards as you fill the order."
        ]
      }
    ],
    faqs: [
      { q: "Is the daily draft the same for everyone?", a: "Yes. One shared set of five card choices per Eastern Time date, so daily scores compare fairly." },
      { q: "Are the opponents real teams?", a: "No, and that is deliberate: every opponent is an invented club, so no real logo or name is borrowed. The players you draft are real, off real 2026 rosters." },
      { q: "Why does the card say LAD instead of the club's full name?", a: "The abbreviation is what the roster data itself carries, and it keeps the page light. Any baseball fan reads it at a glance." },
      { q: "Is this the same game as the soccer Gauntlet Draft?", a: "Same engine, baseball's own roster data, lineup card and postseason ladder. Eleven picks, the same depth as the soccer XI, because a lineup card is nine plus the arms that decide a modern game." }
    ]
  },
  "/mlb-connect-4": {
    intro: [
      "Connect 4 with a baseball brain. Every column and row carries a category, and claiming a cell means naming a player who fits both at once.",
      "It is built for two, red against blue on one screen, first to four in a row. Playing both sides solo works fine as practice."
    ],
    headings: {
      howToPlay: "How to play MLB Connect 4, a free two player baseball trivia game",
      rules: "MLB Connect 4 rules for the board, answers and rejected calls",
      example: "MLB Connect 4 walkthrough: Cooperstown Row to Cal Ripken Jr.",
      tips: "MLB Connect 4 tips for blocking, columns and obscure names",
      faq: "MLB Connect 4 FAQ: solo play, the checker and active players"
    },
    howToPlaySections: [
      {
        heading: "Picking a column as red goes first",
        items: [
          "Red goes first. Pick a column and your piece targets the lowest empty cell, classic Connect 4 gravity."
        ]
      },
      {
        heading: "Naming a player who fits both labels",
        items: [
          "Name a player who matches both the column heading and the landing row."
        ],
        subsections: [
          {
            heading: "What a valid answer or a miss does",
            items: [
              "A valid answer drops your piece and ends your turn. A miss keeps your turn, so try again."
            ]
          }
        ]
      },
      {
        heading: "Skipping your turn when you are stuck",
        items: [
          "Out of ideas? Hit skip and hand the turn over."
        ]
      },
      {
        heading: "Winning with four in a row",
        items: [
          "Four in a row, across, down or diagonal, wins. A full board is a draw."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "A six by seven board of unique names",
        items: [
          "The board is 6 rows by 7 columns, and each player name can only be used once per game."
        ]
      },
      {
        heading: "Answering with any era, active or retired",
        items: [
          "Answers come from any era. Suggestions show retired legends, but you can type any current star and submit."
        ]
      },
      {
        heading: "What happens when the checker cannot verify",
        items: [
          "An AI validator checks every answer. If it cannot verify one, nothing is placed and you just try again, no penalty."
        ]
      },
      {
        heading: "Six themed boards dealt at random",
        items: [
          "Six themed boards rotate, from October Legends to Cooperstown Row, dealt at random each new game."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Stan Musial and George Brett on Cooperstown Row",
        paragraphs: [
          "On the Cooperstown Row board, blue drops into the MVP Winner column and lands on the Cardinals row: Stan Musial, easy money. Red answers with George Brett where 3,000 hits meets the Royals."
        ]
      },
      {
        heading: "Cal Ripken Jr. wins it at the Orioles cell",
        paragraphs: [
          "A few turns later blue needs one cell to finish, where Only One MLB Team crosses the Orioles. Cal Ripken Jr. ends it, four in a row."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Playing the board over showing off trivia",
        items: [
          "Play the board, not the trivia. Blocking three in a row beats showing off a deep cut."
        ]
      },
      {
        heading: "Fighting for the center columns",
        items: [
          "Fight for the center columns, they touch the most winning lines."
        ]
      },
      {
        heading: "Banking obscure answers for later",
        items: [
          "Bank your obscure answers. A used name is gone for both teams, so do not spend a rare fit on a throwaway cell."
        ]
      }
    ],
    faqs: [
      { q: "Do I need a second player?", a: "It shines as a pass and play duel on one device, but solo you can control both sides." },
      { q: "What if the checker rejects a right answer?", a: "It says so, places nothing, and lets you retry without losing your turn. Try the full name and submit again." },
      { q: "Can I answer with active players?", a: "Yes, any era counts. The autocomplete only suggests retired legends, so type a current player's full name and press enter." }
    ]
  },
  "/conquest-mlb": {
    intro: [
      "The imperialism format comes to the ballpark. Every territory starts out belonging to its nearest MLB park, and when two clubs meet, the winner takes everything the loser owns.",
      "Two clubs start with nothing. Toronto invades from across the border and San Diego gets boxed out by the California carve-up. One win hands either of them an entire empire."
    ],
    headings: {
      howToPlay: "How to play MLB Conquest, a free daily territory takeover game",
      rules: "MLB Conquest rules for scoring, empires and extra innings",
      example: "MLB Conquest walkthrough: the Blue Jays claw back to October",
      tips: "MLB Conquest tips for calling games and reading standings",
      faq: "MLB Conquest FAQ: the Daily Challenge, landless teams and playoffs"
    },
    howToPlaySections: [
      {
        heading: "Picking a team from all thirty clubs",
        items: [
          "Pick your team from all 30 clubs and watch the map carve itself up."
        ]
      },
      {
        heading: "Calling your game before each round plays",
        items: [
          "Each round pairs the whole league into games. Before it plays, call your team's game. The card shows each side's win odds."
        ],
        subsections: [
          {
            heading: "Watching winners annex the losers' land",
            items: [
              "Play the round. Winners annex everything the losers held, and the map redraws in one swing."
            ]
          }
        ]
      },
      {
        heading: "Surviving fourteen rounds to reach the playoffs",
        items: [
          "Survive 14 rounds. The top 8 empires by territory make the playoffs, record breaking ties."
        ]
      },
      {
        heading: "Winning three rounds to rule the map",
        items: [
          "Win the Division Round, the Pennant Round and the Imperial World Series to rule the map."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Fourteen rounds into an eight team bracket",
        items: [
          "14 regular rounds, then an 8 team knockout bracket."
        ]
      },
      {
        heading: "How points are scored across a season",
        items: [
          "Scoring: 25 points per correct call, 3 per territory held at the end, 200 for the crown, 50 for making the playoffs."
        ]
      },
      {
        heading: "A landless team can still reclaim it all",
        items: [
          "Wiped-out teams keep playing, and one win takes back a whole empire."
        ]
      },
      {
        heading: "Extra innings settled by a single run",
        items: [
          "Extra-inning games are decided by a single run, and there are no ties, ever."
        ]
      },
      {
        heading: "The Daily Challenge and Free Play modes",
        items: [
          "The Daily Challenge deals every player the same date-seeded season: same starting map, same fixtures, same results. One scored run per day with streaks. Free Play is unlimited and fully random."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "The Blue Jays annexing a whole empire",
        paragraphs: [
          "You ride the Blue Jays, landless at first pitch. Round 1 pairs Toronto with a fat empire, you call the upset, and it hits: the Jays annex the whole thing."
        ]
      },
      {
        heading: "Clawing back into the eighth seed",
        paragraphs: [
          "By round 9 you hold a chunk of the continent, then lose every acre to a one-run heartbreaker in extras. You claw back in round 12, sneak into the eighth seed, and October gets interesting."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Calling games with the odds, not your heart",
        items: [
          "Call games with the odds, not your heart. The percentages come from real team ratings."
        ]
      },
      {
        heading: "Why landless is one good night away",
        items: [
          "Do not panic when you get wiped. Landless is one good night from owning a coastline."
        ]
      },
      {
        heading: "Checking standings in the last rounds",
        items: [
          "Check standings late. Seeding goes by territories, so the last rounds are about protecting your count."
        ]
      }
    ],
    faqs: [
      {
        q: "How does the Daily Challenge work?",
        a: "Everyone on the planet gets the same season today: identical starting map, identical fixtures, identical results. Your score comes from which empire you back and how well you call the games, so comparing scores is a fair fight. One scored run per day, streaks build if you show up daily, and a fresh map drops at midnight Eastern. Free Play stays unlimited."
      },
      { q: "Why do the Blue Jays and Padres start with no land?", a: "The map splits by nearest park. Toronto sits outside the border and San Diego loses the California split, so both open as invaders." },
      { q: "Can the season end early?", a: "Yes. If any club annexes the entire map before round 14, total conquest crowns them immediately." },
      { q: "How do the playoffs work?", a: "The top 8 empires seed a knockout: Division Round, Pennant Round, then the Imperial World Series. Territories decide seeding, record breaks ties." }
    ]
  },
  "/mlb-my-career": {
    intro: [
      "Draft day, age 21, one made-up prospect: you. My Career drops a fictional player into the real 30 team league to live every season from draft hype to farewell tour.",
      "Your archetype shapes the ride. A Flamethrower touches triple digits while his elbow prays nightly. A Crafty Lefty ages forever. A Masher is 45 homers or bust.",
      "You build your player's actual face before the draft, and there is a dirty side waiting whenever you want it. A camera in center field and a trash can behind the dugout, something on the glove that adds 300 rpm, a clinic in Florida that ships in unmarked boxes, tipping pitches to a man who likes first innings. Every dirty choice raises a hidden commissioner meter, and this is the sport that hands out lifetime bans."
    ],
    headings: {
      howToPlay: "How to play MLB My Career, a free baseball career simulation game",
      rules: "MLB My Career rules for aging, money and the press",
      example: "MLB My Career walkthrough: from draft day to a Hall of Famer verdict",
      tips: "MLB My Career tips for durability, training and surgery",
      faq: "MLB My Career FAQ: verdicts, free agency and the Bank"
    },
    howToPlaySections: [
      {
        heading: "Creating your player and picking an archetype",
        items: [
          "Create your player: name, one of 11 positions (SP, RP, C, 1B, 2B, 3B, SS, LF, CF, RF, DH), and one of 33 archetypes, from Flamethrower to The Framer to Pure Masher."
        ]
      },
      {
        heading: "Choosing today's league or the 2004 throwback",
        items: [
          "Pick your league: today's MLB, or the 2004 throwback with the Expos in Montreal, the Anaheim Angels, the Florida Marlins and the Devil Rays."
        ],
        subsections: [
          {
            heading: "Building your look and spending in seven aisles",
            items: [
              "Build your look, then spend the money in 7 aisles including a shady one that only appears once you have something to hide."
            ]
          }
        ]
      },
      {
        heading: "Managing the Bank between seasons",
        items: [
          "Open the Bank between seasons. Savings pays 2.5% a season and never loses, five things you can put money into each have a price that moves every season whether you look or not (a fund, flats back home, two shares and a coin that halves as often as it doubles), the statement keeps your last 12 moves, and the card school in the clubhouse is one sitting a season on odds that are printed before you sit in."
        ],
        subsections: [
          {
            heading: "Reading the News box and the rival's card",
            items: [
              "Read the News box. The paper writes up every season in your own position's stat, the SocialGram shows followers read off your fanbase with three fan comments under the latest post, and the rival's card keeps the head to head against the player drafted the same year as you."
            ]
          },
          {
            heading: "Collecting badges in the Trophy Case",
            items: [
              "Collect badges in the Trophy Case: 26 of them, from a first ring and Rookie of the Year to 500 home runs, 3,000 strikeouts and $100M to your name, each lit the moment the facts of your career say so."
            ]
          },
          {
            heading: "Answering your phone on the baseball calendar",
            items: [
              "Answer your phone. Texts from your agent, the manager, the GM, a teammate or your mom land on the beats of the baseball year: draft day, spring training, the All-Star break, the trade deadline, September, October if you get there, the offseason, an arbitration winter and the winter you hit free agency. Every text says which beat and which year it came in on, and how you answer moves your karma, morale, fanbase or bank."
            ]
          },
          {
            heading: "Making the call when your rival forces one",
            items: [
              "Some seasons your rival puts a decision on your plate instead of a story: benches clearing that you can answer or calm down, a debate show offering real money, a youth clinic his foundation wants you to co-host, an All-Star vote his club is buying ads for. Every button prints exactly what it moves, and a gamble prints its odds."
            ]
          }
        ]
      },
      {
        heading: "Entering the draft and playing full seasons",
        items: [
          "Enter the draft, land on a real club, and play seasons for full stat lines: average, homers and RBI, or wins, ERA and strikeouts.",
          "Open Career Log and pick a year to review its saved overview, regular season and postseason. Changes compare with the previous saved season; older missing values say Not recorded. Back to seasons returns to the year tiles, and Review seasons is available after retirement."
        ],
        subsections: [
          {
            heading: "Climbing the lineup card from the bench",
            items: [
              "Check the lineup card. Top ten picks play from Opening Day; everyone else fights the veteran in spring, with bench bats and long-relief arms waiting on spot starts until the job flips. Relievers climb their own bullpen ladder instead."
            ]
          },
          {
            heading: "Handling offseason events",
            items: [
              "Handle the winter, up to three decisions one card at a time: winter training, surgery calls, trade rumors. Only the first card can move your rating, and a card you just saw rests for a while (press moments follow your season, so those can come right back).",
              "After a normal offseason choice, the result shows the actual changes. Expand it for any extra changes, then Continue opens the next card, or takes you back to your career after the last one, without applying the choice again."
            ]
          }
        ]
      },
      {
        heading: "Hitting the open market and closing your career",
        items: [
          "When team control ends, hit the open market for real: competing offers from named clubs with their own money, length and roster quality, and one push for more on any of them.",
          "Stack awards and rings, fight aging, answer the retirement talk when the rating slips, and retire to a verdict and the Hall of Fame ballot."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Starting at 21 with six years of control",
        items: [
          "You start at 21 in 2026 with 6 years of team control before free agency. The throwback starts in 2004 instead, inside a sealed 30 team league verified against the real season, with 2004 sized contracts."
        ]
      },
      {
        heading: "Tracking morale, fanbase and health",
        items: [
          "Three meters run your life: morale, fanbase and health. Low health means shortened seasons."
        ]
      },
      {
        heading: "How your rival's choices work",
        items: [
          "Any season your rival stays out of the news carries a 45% chance of a rival choice instead, never both in one season, and you meet every choice once before one comes back. Each button moves exactly what it prints: morale, fanbase, net worth, karma or the heat of the feud. Morale goes straight into next season's numbers, at the plate or on the mound."
        ]
      },
      {
        heading: "How the phone's calendar works",
        items: [
          "Texts only arrive on beats your season really had. No October texts in a year your club went home in September, arbitration only in the winters after your third, fourth and fifth seasons while your deal still has years on it, free agency only the winter your deal runs out, and draft day's text lands before you see a pitch. One text a beat, up to three a season, fewer while old ones sit unanswered, and the same text never comes twice in a career.",
          "The season the game retires you (42, 21 seasons, or a rating that craters) sends nothing about a year you will not play: no winter ball offer, no bat and glove deal, no arbitration or free agency talk."
        ]
      },
      {
        heading: "How real playing time gets decided",
        items: [
          "The lineup card is real: a bench season is about half the games, a spot starter gets a dozen turns, springs have memory both ways, and signing with a stacked contender can cost a mid player the everyday job."
        ],
        subsections: [
          {
            heading: "What the press asks after each season",
            items: [
              "The press reads your actual season: a ring puts you on the podium, missing October badly puts you in the scrum, a bench year brings the role question. Three answers each time, safe, honest or fiery, and fiery gambles your fanbase for real."
            ]
          }
        ]
      },
      {
        heading: "Growing to your potential, then aging",
        items: [
          "Players grow toward their potential through age 26 and decline from 32 on, faster after 37."
        ],
        subsections: [
          {
            heading: "Retiring at 42 or walking away at season 6",
            items: [
              "Retirement hits at 42, after 21 seasons, or when your rating collapses. Before that, from 32, slipping 8 points off your best (or down to 68) brings the talk: retire now, one more year, or a farewell season. You can walk away after season 6.",
              "Hall of Fame voters weigh the hardware first (rings, the major awards, All-Star years), then your seasons and your numbers, and a career total near the top of this game's books in a stat your position really piles up (home runs, RBI, steals, wins or strikeouts, though a reliever gets none) earns a push of its own, up to 390 legacy points.",
              "Example: take a center fielder with ordinary numbers and one with the same hardware and more steals than 99 of 100 center fielders this game has seen. The second scores at least 300 legacy points more, which can be the whole gap between a long wait and the Hall. A career you already retired keeps the ballot it was told."
            ]
          }
        ]
      },
      {
        heading: "The Bank's rules on fees, floors and card odds",
        items: [
          "Money has rules of its own. There is a 1% fee on both sides of every trade and a $100k floor in the account that cannot be invested away; a season that leaves you under the floor is covered out of savings first, then by a forced sale of holdings at whatever the price is that day. Cards win 42% of hands and a win pays 1.15x the stake, the most you can stake is $50k or 4% of your cash, and once you are $500k down for your career the guys stop dealing you in for good. Keep sitting in while you are losing and somebody at home notices, which costs morale and fanbase."
        ],
        subsections: [
          {
            heading: "What the fans nag your position for",
            items: [
              "The fans nag you for the thing your position is judged on and never the other way round: a starter hears go deeper into games, a closer hears shut the door, a catcher hears more pop from behind the plate. No arm is ever asked for home runs, no bat is ever asked for an ERA, and the three spots with no speed in them are never asked to run."
            ]
          },
          {
            heading: "Saving one career automatically",
            items: [
              "One career at a time, saved automatically in your browser."
            ]
          }
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Reading an actual capped change",
        paragraphs: [
          "Say Health is 98 before a recovery choice that adds 10. The 100 cap makes the result 98 to 100, so the card shows +2. Continue moves you on (to the next card, or back to your career after the last one) with Health still at 100."
        ]
      },
      {
        heading: "Drafting a Slugging Shortstop at 12th overall",
        paragraphs: [
          "You build a Slugging Shortstop who goes 12th overall. Year two brings the breakout, year five a ring. When control ends, the hometown club offers a discount while the market whispers bigger money elsewhere."
        ]
      },
      {
        heading: "Chasing the money to a Hall of Famer verdict",
        paragraphs: [
          "You chase the money, the new fanbase starts cold, and the decline grinds. At 38 you retire with 430 homers, a ring and five All-Star nods. Verdict: Hall of Famer."
        ]
      },
      {
        heading: "When the benches clear on your rival",
        paragraphs: [
          "Both benches empty after a pitch up and in, your rival is first out of his dugout, and the card asks what you do about it. Answer it on the field heats the feud and usually pays Morale +8, but it carries a 30% chance you are the one who gets tossed (Morale -5, Fanbase -5, Net worth -$100k). Play peacemaker on camera is Fanbase +5, Karma +5 and the feud cools. You pick say nothing and watch the tape: Morale +6, the feud heats up, and those six points ride into next season's numbers."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Why durability wins careers",
        items: [
          "Durability wins careers. Steadier archetypes stay on the field while flashy builds collect injury notes."
        ]
      },
      {
        heading: "Spending winter training while you are young",
        items: [
          "Spend winter training on your ceiling while young. From 32 it quietly turns into maintenance, so bank gains early."
        ]
      },
      {
        heading: "Taking the elbow surgery as a pitcher",
        items: [
          "Pitchers, take the elbow surgery. Playing through a bad MRI turns every start into a gamble."
        ]
      }
    ],
    faqs: [
      { q: "What decides the legacy verdict?", a: "One score from rings, MVPs or Cy Youngs, All-Star nods, seasons and stats. Reach 500 and Cooperstown calls. At 900 you are inner circle, first ballot." },
      { q: "Can I change teams?", a: "Yes. Low morale can trigger trade rumors where you ask out, and when the contract expires you get a real market: named clubs bidding with their own money, years and roster quality, plus your own club's re-sign number. You can push any offer for more once, and your own club never walks away." },
      { q: "Is the player real?", a: "No, the prospect is fictional on purpose. The 30 teams are real, the career is yours." },
      { q: "Why am I on the bench?", a: "Because the veteran is better, for now. Late picks usually open as bench bats or long-relief arms behind an incumbent whose level tracks the roster. Grow your rating and you take the job in spring. Relievers never sit; the bullpen ladder is about whether you become the closer, which is your archetype's fight." },
      { q: "Can I start in a different era?", a: "Yes. The create screen has a 2004 throwback: the league in the Expos' last Montreal summer, with the Anaheim Angels, the Florida Marlins, the Tampa Bay Devil Rays and the Oakland Athletics. An era career never meets a franchise identity that did not exist then." },
      { q: "What is in the Bank?", a: "Four tabs. Account holds your cash, a savings account that pays 2.5% a season, and a statement of your last 12 moves. Market is five prices that move every season, each with its own risk word and a read on whether it is cheap or dear against what it usually goes for. Cards is the clubhouse card school, one sitting a season, on odds the screen prints before you play. Shop is the 7 aisles. It is the same engine Soccer Career's phone runs on, in dollars." },
      { q: "Who is my rival?", a: "A generated player drafted the same year at your position. He plays his own seasons on the same scale you do, can win a ring before you and retire before you, and the head to head is kept for good. He is fictional, like your own player, so no real player's career is being simulated." },
      { q: "How do I earn badges?", a: "By doing the thing. Each of the 26 badges is a test on the facts of your career, checked every time you open the case: a ring, an MVP or a Cy Young, 500 home runs, 300 wins, a million dollars to your name. The single season badges sit under the real records because the sim's own ceilings do: 50 home runs against the record 73, a .330 average when nobody has hit .400 since Ted Williams' .406 in 1941, and 50 stolen bases against the record 130. The strikeout badge is the real 3,000 club, and the career record there is Nolan Ryan's 5,714." }
    ]
  },
  "/mlb-front-office": {
    intro: [
      "Running a front office sounds fun until the payroll page loads. This is a full GM sim of the real 30 team league, every club carrying its real 26 man roster and every player rated off his real 2026 numbers.",
      "The problems are real: a tax line that will not move, aging veterans, scouts who lie, and 29 rivals that never stop churning."
    ],
    headings: {
      howToPlay: "How to play MLB Front Office, a free MLB general manager simulation",
      rules: "MLB Front Office rules for the tax line, trades and trust",
      example: "MLB Front Office walkthrough: a division title, then a scouting miss",
      tips: "MLB Front Office tips for payroll, age and October depth",
      faq: "MLB Front Office FAQ: contracts, the tax line and trades"
    },
    howToPlaySections: [
      {
        heading: "Inheriting a franchise's lineup and bullpen",
        items: [
          "Choose a franchise and inherit its real 26: the lineup and bench, a five man rotation and the bullpen, as the club stood on the last day of the 2026 regular season.",
          "The roster box shows who the sim plays: your best healthy 8 bats, 3 starters and 2 relievers. Everyone else is depth, and depth is who plays the day a starter hits the IL."
        ]
      },
      {
        heading: "Reading the ownership mandate each offseason",
        items: [
          "Read the ownership mandate: a stacked roster is told to win the World Series, a mid one to make October, a thin one to hit an honest win number. It resets every offseason."
        ],
        subsections: [
          {
            heading: "Working trades, free agents and DFAs",
            items: [
              "Work the roster: DFA dead weight, sign free agents, and take trades to the phone, where the other GM counters with pick demands and lesser returns instead of a flat yes or no."
            ]
          }
        ]
      },
      {
        heading: "Playing the season in weekly stretches",
        items: [
          "Play the 162 in stretches: each round simulates about a week and a half of baseball, 27 rounds total, with a live read on whether you are on pace."
        ]
      },
      {
        heading: "Making October and seeding the bracket",
        items: [
          "Make October. Division winners seed 1 to 3, three wild cards follow, and the top two seeds skip the Wild Card round."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "The tax line and its hard cap",
        items: [
          "The tax line starts at 244 million, matching the real 2026 threshold, and it is a hard cap, rising 3 percent a season."
        ]
      },
      {
        heading: "How the playoff format is seeded",
        items: [
          "Playoffs use the real format: best-of-3 Wild Card, best-of-5 Division Series, best-of-7 LCS and World Series."
        ]
      },
      {
        heading: "What trades weigh most",
        items: [
          "Trades weigh rating, age and position, with premiums on aces, shortstops and catchers."
        ],
        subsections: [
          {
            heading: "Draft picks and scouting error",
            items: [
              "Each club starts with 2 simulation picks. Trades can leave you with fewer or more choices, and each selection spends one owned pick. With none left, finish the draft and offseason. Rivals get two batches of up to five eligible selections in this abbreviated draft. Scout grades carry error; true ratings show only after you pick."
            ]
          }
        ]
      },
      {
        heading: "Injuries and automatic franchise saves",
        items: [
          "Injuries cost one to four rounds on the IL, and your franchise saves automatically."
        ]
      },
      {
        heading: "Roster size and depth deals",
        items: [
          "A new franchise carries 26 and can hold 22 to 28. The 13 men the sim plays earn their rating's price, the other 13 start on depth deals at 0.7 million until those deals run out, and then they re-sign at their rating's price like anybody else. The roster box flags a cheap deal in its last year with what he will cost, so the jump never lands by surprise.",
          "If the draft takes you past 28, you DFA down to 28 before Round 1, dead money and all, and Play waits until you have. The CPU clubs cut their own lowest rated depth men the same way.",
          "A save started before the full rosters keeps its 13 man roster and its old limits of 9 to 16."
        ]
      },
      {
        heading: "Designating a player and the dead money",
        items: [
          "A DFA is not free. Half the man's salary stays on this season's payroll as dead money, a quarter lands on next season's if he had years left, and you cannot sign him back until the offseason."
        ]
      },
      {
        heading: "Trust upstairs and getting fired",
        items: [
          "Trust upstairs runs 0 to 100: beat the mandate and it climbs, miss it and it falls, a ring fixes almost anything, and at zero you are fired and the save ends."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Trading an aging ace for a young shortstop",
        paragraphs: [
          "You take a club 8 million under the line. A DFA clears a bloated deal, the savings sign a 79 rated reliever, and your aging ace becomes a 26 year old shortstop."
        ]
      },
      {
        heading: "Winning the division, losing the LCS in six",
        paragraphs: [
          "You win the division, take the bye, and still lose the LCS in six. Next spring your 84 grade pick arrives as an 80. Scouts, man."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Treating payroll room as a roster spot",
        items: [
          "Payroll room is a roster spot. One dumped albatross often buys two useful arms."
        ]
      },
      {
        heading: "Why age drives value",
        items: [
          "Age drives value. A decent 24 year old can outpull a 33 year old star, so sell veterans early."
        ]
      },
      {
        heading: "Spending on lineup first, then pitching",
        items: [
          "The sim weighs your lineup most, then rotation, then bullpen. Spend in that order."
        ]
      },
      {
        heading: "Building for repeat October trips",
        items: [
          "October is a variance machine, so build for repeat trips, not one all-in year."
        ]
      }
    ],
    faqs: [
      { q: "Are the contracts real?", a: "Rosters and ratings come from real data, but every salary, contract and transaction in the sim is fictional." },
      { q: "Where do the rosters come from?", a: "MLB's own data: each club's major league roster on September 27, 2026, the last day of the regular season. The 26 are the 13 hitters and 13 pitchers who carried the most of that club's season. Hitters are rated off their 2026 OPS and pitchers off a number built from strikeouts, walks and homers, and a rating built on very few games says thin 2026 data next to it." },
      { q: "Can I go over the tax line?", a: "No. Moves that break the line do not go through. That squeeze is most of the job." },
      { q: "Why did my trade get rejected?", a: "The AI wants a premium on rating, age and position. Use a pick you still own, or offer someone younger." },
      { q: "Can I get fired?", a: "Yes. Ownership grades the mandate every season and tracks trust from 0 to 100. A 70 win season on a win-the-World-Series payroll costs real trust, and at zero the save ends and you take another job." }
    ]
  },
  "/missing-nine": {
    intro: [
      "A real World Series starting nine sits in front of you, in batting order, one name blanked out. You know this game, you watched it or grew up hearing about it. So who actually started?",
      "That word, actually, is the trap. Memory promotes the heroes and forgets the starters, and the most famous moment of the night often came off the bench."
    ],
    headings: {
      howToPlay: "How to play Missing Nine, a free daily World Series lineup game",
      rules: "Missing Nine rules for guesses, scoring and hard mode",
      example: "Missing Nine walkthrough: Kirk Gibson's card and Mickey Hatcher's answer",
      tips: "Missing Nine tips for reading lineups and positions",
      faq: "Missing Nine FAQ: verified lineups, games and last names"
    },
    howToPlaySections: [
      {
        heading: "Reading the series, score and venue card",
        items: [
          "Read the card: the series, the year, the final score, the venue and the team."
        ]
      },
      {
        heading: "Studying the blank's spot and position",
        items: [
          "Study the order. The blank shows its spot in the lineup and its fielding position."
        ]
      },
      {
        heading: "Typing the missing starter's name",
        items: [
          "Type the missing starter. Full name or just the surname both count."
        ],
        subsections: [
          {
            heading: "Unlocking hints after two misses",
            items: [
              "Your first two misses each unlock a hint: the player's nationality, then the first letter of the surname."
            ]
          }
        ]
      },
      {
        heading: "Solving it or waiting for tomorrow",
        items: [
          "Solve it or run dry, then come back tomorrow for a new lineup."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "How points drop with each guess",
        items: [
          "First guess scores 100 points, second 70, third 40. Giving up scores zero."
        ]
      },
      {
        heading: "Three guesses per lineup",
        items: [
          "3 guesses per lineup, no more."
        ]
      },
      {
        heading: "Lineups verified against the real box score",
        items: [
          "Every lineup is a real World Series starting nine verified against the box score, and the reveal includes a verified fact about the player."
        ]
      },
      {
        heading: "Hard mode hiding hints until the reveal",
        items: [
          "Hard mode hides hints, name suggestions and fielding positions until the reveal."
        ],
        subsections: [
          {
            heading: "Daily and Unlimited lineup modes",
            items: [
              "The daily gives everyone the same blank and resets at midnight Eastern. Unlimited deals random lineups."
            ]
          }
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Wanting Kirk Gibson on the 1988 Dodgers card",
        paragraphs: [
          "Picture the 1988 Game 1 Dodgers card. The blank sits third, left field, and every bone in you wants Kirk Gibson. That is the trap: Gibson never started that night, his walk-off homer came as a pinch hitter."
        ]
      },
      {
        heading: "Naming Mickey Hatcher on the first guess",
        paragraphs: [
          "The real answer is Mickey Hatcher, who homered in the first inning and got erased by history anyway. Landing that on the first guess is a 100 point flex."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Trusting who played nine innings, not highlights",
        items: [
          "Think about who the manager trusted for nine innings, not who made the highlight reel."
        ]
      },
      {
        heading: "Reading the nine spot in a no DH game",
        items: [
          "In National League park games with no DH, a blank in the nine-hole is usually the starting pitcher."
        ]
      },
      {
        heading: "Using catcher as the sharpest position hint",
        items: [
          "Use the position hard. A blank at catcher narrows a whole roster to two names fast."
        ]
      }
    ],
    faqs: [
      { q: "Are these lineups accurate?", a: "Yes. Every batting order was checked against the official box score for that exact game, traps included." },
      { q: "Which games are in the pool?", a: "Famous World Series nights from both dugouts, including 1986 Game 6, 1988 Game 1, 2001 Game 7, 2013 Game 6 and 2016 Game 7." },
      { q: "Does the last name alone count?", a: "Yes. Just the surname works, no sweating full spellings." }
    ]
  },
  "/baseball-connections": {
    intro: [
      "Twenty players, four hidden groups, one wall of trouble. Connections hands you a grid of names and asks what secretly ties them together: a franchise, an award, a country.",
      "The twist is size. Groups run five deep instead of four, which means more cover for the traps and a better feeling when one locks in."
    ],
    headings: {
      howToPlay: "How to play MLB Connections, a free daily baseball grouping puzzle",
      rules: "MLB Connections rules for groups, lives and the daily puzzle",
      example: "MLB Connections walkthrough: a Yankees overlap and a purple finish",
      tips: "MLB Connections tips for reading themes and the leftovers",
      faq: "MLB Connections FAQ: group size, colors and running out of lives"
    },
    howToPlaySections: [
      {
        heading: "Scanning twenty names for a theme",
        items: [
          "Scan all 20 names and hunt for a theme you trust."
        ]
      },
      {
        heading: "Selecting five players and submitting",
        items: [
          "Tap exactly 5 players to select them, then hit submit."
        ],
        subsections: [
          {
            heading: "What a correct or wrong five does",
            items: [
              "A correct five locks in with its theme and color. A wrong five costs a life."
            ]
          }
        ]
      },
      {
        heading: "Reading the four difficulty colors",
        items: [
          "Colors grade the difficulty: yellow is the gentle one, then green, blue, and purple for the group built to hurt."
        ]
      },
      {
        heading: "Clearing all four groups before your lives end",
        items: [
          "Find all four groups before your 4 lives run out."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Four groups of five players each",
        items: [
          "Each puzzle holds exactly 4 groups of 5, and every player belongs to exactly one group."
        ]
      },
      {
        heading: "Four lives, spent only on wrong guesses",
        items: [
          "You get 4 lives, and only a wrong submission costs one."
        ]
      },
      {
        heading: "What happens when your lives run out",
        items: [
          "Run out of lives and the remaining groups reveal themselves."
        ]
      },
      {
        heading: "The daily puzzle and Unlimited mode",
        items: [
          "The daily puzzle is the same for everyone and flips at midnight Eastern. Unlimited deals random puzzles from the pool."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Spotting the overlap in the Yankees group",
        paragraphs: [
          "You spot five obvious Yankees and nearly submit, then notice one of them also fits a cluster of 500 homer guys. That overlap is the whole puzzle. So you chase the safest read first, and it locks in yellow."
        ]
      },
      {
        heading: "Working backward to solve purple last",
        paragraphs: [
          "A life dies on the Yankees trap later, but the miss exposes the decoy. You work the leftovers backward and purple falls last, two lives to spare."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Never submitting the first theme you see",
        items: [
          "Never submit the first theme you see. These puzzles are built so a name or two straddles two believable groups."
        ]
      },
      {
        heading: "Clearing the leftovers when themes tangle",
        items: [
          "Work from the leftovers. When three themes feel tangled, find the five that fit nowhere else and clear them first."
        ]
      },
      {
        heading: "Shuffling names for free before submitting",
        items: [
          "Selecting and deselecting is free. Shuffle names between candidate groups until only one arrangement makes sense."
        ]
      }
    ],
    faqs: [
      { q: "Why five per group instead of four?", a: "This version scales the format up to 20 players in four groups of 5. Bigger groups leave more room for overlap bait." },
      { q: "What do the colors mean?", a: "Difficulty. Yellow is the easiest connection, green and blue sit in the middle, and purple is the sneakiest, usually hiding behind a decoy theme." },
      { q: "What happens when I run out of lives?", a: "The unsolved groups reveal themselves so you can see what you missed, and the daily locks until a new puzzle arrives the next day." }
    ]
  }
};

// src/data/gameContent/hockey.ts
var HOCKEY_CONTENT = {
  "/perfect-season-nhl": {
    intro: [
      "The wheel owns your draft. Every spin lands on a real NHL franchise and one decade of its history, and you take exactly one player before it moves on.",
      "Fill six slots from a century of hockey, then the sim plays the 82 game season. 82-0 does happen, but it takes a stacked lineup and some luck, and every result prints your odds."
    ],
    headings: {
      howToPlay: "How to play 82-0 NHL Perfect Season, a free hockey wheel and draft game",
      rules: "82-0 NHL Perfect Season rules: the wheel, the slots and the 82 games",
      example: "82-0 NHL Perfect Season walkthrough: a spin, a reroll and a near miss",
      tips: "82-0 NHL Perfect Season tips for building a run that stays perfect",
      faq: "82-0 NHL Perfect Season FAQ: rerolls, Hard mode and the Daily"
    },
    howToPlaySections: [
      {
        heading: "Choose Classic, Hard or Daily mode",
        items: [
          "Pick a mode: Classic, Hard (ratings hidden) or Daily (one shared attempt)."
        ]
      },
      {
        heading: "Spin for a franchise and its era",
        items: [
          "Spin the wheel. It stops on a franchise and era, like the 1980s Oilers."
        ]
      },
      {
        heading: "Draft skaters and goalies into six slots",
        items: [
          "Draft one player from that squad into an open slot. Skaters rate 40 to 99 off real career scoring; goalies rate on draft pedigree.",
          "Repeat until you have a center, both wings, two defensemen and a goalie."
        ],
        subsections: [
          {
            heading: "Use a reroll when a squad falls short",
            items: [
              "Use your 2 rerolls if a squad gives you nothing."
            ]
          }
        ]
      },
      {
        heading: "Watch the sim play out all 82 games",
        items: [
          "Let the sim run all 82 games and hand down your record."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Six slots with the goalie weighted heaviest",
        items: [
          "6 lineup slots, with the goalie weighted heaviest in your team overall."
        ]
      },
      {
        heading: "One player per spin and two rerolls",
        items: [
          "One player per spin, no player in two slots, and 2 rerolls per run."
        ]
      },
      {
        heading: "Simulated games and the Daily attempt",
        items: [
          "The season is 82 simulated games; a higher overall wins more, but perfection also needs luck.",
          "Daily mode allows one attempt per day with a rotating theme and resets at midnight Eastern."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "An early spin lands the 1980s Oilers",
        paragraphs: [
          "Say the first spin lands on the 1980s Oilers and you grab a 99 rated center. Two spins later a thin squad costs a reroll, and you settle for an 85 defenseman."
        ]
      },
      {
        heading: "A 93 overall falls one win short of perfect",
        paragraphs: [
          "You finish at 93 overall. The sim rips off 38 straight, drops game 39, and closes 80-2. The result card says so close, two bad nights, and reminds you that at 93 an 82-0 comes about one run in 19. You wanted the banner."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Never settle for a weak goalie",
        items: [
          "Never settle in net. A weak goalie sinks five good skaters."
        ]
      },
      {
        heading: "Save rerolls for late and stay flexible",
        items: [
          "Spend rerolls late, when only a slot or two remains open.",
          "Players listed at F or W can cover several forward slots, which keeps early spins flexible."
        ]
      },
      {
        heading: "Trust the eras when playing Hard mode",
        items: [
          "In Hard mode, trust eras: dead puck 2000s scorers get a quiet ratings boost, while inflated 1980s numbers get trimmed."
        ]
      }
    ],
    faqs: [
      {
        q: "How realistic is an actual 82-0 run?",
        a: "It depends on your overall, and the goalie counts most. An 88 lineup goes 82-0 about one run in 3,900, a 90 about one run in 250 and a 93 about one run in 19. Most well drafted lineups land between 81 and 91, and the result card prints the odds for the lineup you actually drafted."
      },
      {
        q: "What does Hard mode change?",
        a: "Ratings show as question marks until the season ends. You draft on names, eras and gut."
      },
      {
        q: "Can I replay the Daily?",
        a: "No. One attempt, the same wheel for everyone, and your result locks until the next puzzle at midnight Eastern."
      }
    ]
  },
  "/puck-detective": {
    intro: [
      "Somewhere on a current NHL roster hides the mystery player, and you get 8 guesses to name him.",
      "Every guess is a real player, and every guess talks back: five chips compare team, position, nationality, age and jersey number against the secret answer. Solve the shared daily puzzle, or grind win streaks in unlimited mode."
    ],
    headings: {
      howToPlay: "How to play Puck Detective, a free NHL mystery player guessing game",
      rules: "Puck Detective rules: clues, chips and the daily mystery player",
      example: "Puck Detective walkthrough: reading the chips on an NHL guess",
      tips: "Puck Detective tips for narrowing the NHL mystery player fast",
      faq: "Puck Detective FAQ: difficulty tiers, saves and the daily reset"
    },
    howToPlaySections: [
      {
        heading: "Type a player and read the five chips",
        items: [
          "Type an NHL player and pick him from the suggestions.",
          "Read the chips. A green check means an exact match, a gray X means no match."
        ]
      },
      {
        heading: "Watch position, age and jersey number clues",
        items: [
          "Position can show a yellow dash: right group (forward, defense or goalie), wrong spot.",
          "Arrows on age and jersey point toward the mystery player: up means his number is higher than your guess."
        ]
      },
      {
        heading: "Narrow it down within eight guesses",
        items: [
          "Keep narrowing and land the exact player within 8 guesses."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Eight guesses and five clues each time",
        items: [
          "8 guesses per puzzle, in both daily and unlimited.",
          "Five clues per guess: team, position, nationality, age and jersey number."
        ]
      },
      {
        heading: "Exact matches except for one close tier",
        items: [
          "Team and nationality are exact or nothing; only position has a close tier."
        ]
      },
      {
        heading: "Unlimited mode tracks your streaks",
        items: [
          "Unlimited mode tracks your current and best win streak, with Easy, Normal and Hard pools."
        ],
        subsections: [
          {
            heading: "The daily player resets at midnight",
            items: [
              "The daily player is the same for everyone and changes at midnight Eastern."
            ]
          }
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Opening with Sidney Crosby",
        paragraphs: [
          "Say you open with Sidney Crosby. The team chip stays gray, position flashes yellow, Canada goes green, the age arrow points down and the jersey arrow points up."
        ]
      },
      {
        heading: "Reading the arrows into a winger guess",
        paragraphs: [
          "Translation: a younger Canadian forward who is not a center and wears a bigger number than 87. Two probing winger guesses later, the whole row turns green on guess five."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Open with a name you know cold",
        items: [
          "Open with a player you know cold. The information matters more than the guess itself."
        ]
      },
      {
        heading: "Bracket the age with two guesses",
        items: [
          "Bracket the numbers: one older guess and one younger guess pin the age range fast."
        ]
      },
      {
        heading: "Read gray countries and yellow positions",
        items: [
          "A green country is nice, but a gray one is bigger; it deletes whole nations from the pool.",
          "Yellow on position means stay in the group. Swap center for winger before abandoning forwards."
        ]
      }
    ],
    faqs: [
      {
        q: "Does the team chip ever show yellow for a rival?",
        a: "No. Team is exact or gray. Only the position chip has a close tier."
      },
      {
        q: "What do the difficulty tiers change?",
        a: "Unlimited only. Easy draws skaters with 250 or more career points, Hard draws players under 75 points plus goalies, and Normal uses the full pool. The daily always uses everyone."
      },
      {
        q: "I closed the tab mid puzzle. Did I lose my guesses?",
        a: "No. Daily progress saves in your browser, so you can finish any time before the reset."
      }
    ]
  },
  "/hockey-grid": {
    intro: [
      "Nine cells, nine chances to prove your hockey memory runs deeper than last season.",
      "Every row and column is a franchise or a career milestone, and each cell wants a player who satisfies both. If you have played a team grid before, this is the NHL one, built on a full all-era career database."
    ],
    headings: {
      howToPlay: "How to play NHL Franchise Grid, a free hockey trivia grid game",
      rules: "NHL Franchise Grid rules: guesses, categories and the daily board",
      example: "NHL Franchise Grid walkthrough: nine cells and one hunch",
      tips: "NHL Franchise Grid tips for naming players under pressure",
      faq: "NHL Franchise Grid FAQ: guesses, eligible players and the daily grid"
    },
    howToPlaySections: [
      {
        heading: "Read where a row meets a column",
        items: [
          "Look at where a row meets a column, like Bruins plus Canadiens, or Oilers plus 500+ Career Points."
        ]
      },
      {
        heading: "Type a player who fits both categories",
        items: [
          "Tap the cell and type a player whose career fits both."
        ]
      },
      {
        heading: "Lock in green or burn a guess",
        items: [
          "A correct pick locks the cell in green. A miss burns one of your 9 guesses."
        ],
        subsections: [
          {
            heading: "Use every player name only once",
            items: [
              "Each player name can only be used once per board."
            ]
          }
        ]
      },
      {
        heading: "Fill all nine cells before you run out",
        items: [
          "Fill all 9 cells before the misses run out."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Nine guesses and only misses count",
        items: [
          "You get 9 guesses, and only wrong answers spend one; correct answers are free."
        ]
      },
      {
        heading: "Franchises and career milestone categories",
        items: [
          "Categories come from a pool of 16 franchises plus three milestones: 500+ career points, 300+ career goals and 1000+ games played."
        ]
      },
      {
        heading: "The daily board and unlimited tiers",
        items: [
          "The daily grid mixes one milestone with five franchises, and everyone gets the same board until midnight Eastern.",
          "Unlimited mode adds difficulty tiers: Easy runs two milestone lines, Hard goes all franchises."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Rows of Leafs, Oilers and Bruins",
        paragraphs: [
          "Imagine rows of Maple Leafs, Oilers and Bruins against columns of Red Wings, Canadiens and 500+ Career Points. Oilers plus 500 points is a layup: Jari Kurri."
        ]
      },
      {
        heading: "Closing it out nine for nine",
        paragraphs: [
          "Maple Leafs plus Red Wings takes a traveler like Larry Murphy, and Bruins plus Canadiens rewards remembering that Mark Recchi wore both sweaters. You burn one guess on a hunch who never actually played in Detroit, then close it out 9 for 9."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Franchise cells reward late career trades",
        items: [
          "Franchise pair cells love journeymen. Think late career trades, not one club legends."
        ]
      },
      {
        heading: "Milestone cells are your safety valve",
        items: [
          "Milestone cells are your safety valve; every franchise in the pool has plenty of 500 point scorers.",
          "There is no rarity bonus, so play the safest name you know."
        ]
      },
      {
        heading: "Any era counts in the career database",
        items: [
          "Answers check instantly against the career database, and any era counts, from Original Six days to last season."
        ]
      }
    ],
    faqs: [
      {
        q: "Do correct answers use up guesses?",
        a: "No. Only misses, unknown names and repeated names cost one of the 9."
      },
      {
        q: "Which players are eligible?",
        a: "Anyone in the all-era NHL career database, thousands of skaters across every decade, not just current rosters."
      },
      {
        q: "Does the daily grid have difficulty settings?",
        a: "No. Tiers only apply to unlimited grids. The daily is one shared board for everybody."
      }
    ]
  },
  "/hockey-career": {
    intro: [
      "One mystery player, a stack of clues and a score that shrinks every time you peek.",
      "Career Path opens with just the position. From there you choose: swing early for the full 1000 points, or buy clues about country, draft, teams, stats and awards until the answer is staring at you."
    ],
    headings: {
      howToPlay: "How to play NHL Career Path, a free mystery hockey player guessing game",
      rules: "NHL Career Path rules: scoring, clues and the daily hockey player",
      example: "NHL Career Path walkthrough: two clues to Connor McDavid",
      tips: "NHL Career Path tips for scoring big on the mystery hockey player",
      faq: "NHL Career Path FAQ: guesses, names and Hard mode"
    },
    howToPlaySections: [
      {
        heading: "Start from the position clue alone",
        items: [
          "Start with a single clue: the position."
        ]
      },
      {
        heading: "Guess anytime for free",
        items: [
          "Guess by typing a name whenever you like; wrong guesses cost nothing."
        ]
      },
      {
        heading: "Reveal clues at a cost to your score",
        items: [
          "Or reveal the next clue. Each reveal knocks 150 points off your potential score."
        ],
        subsections: [
          {
            heading: "Clues arrive in a fixed order",
            items: [
              "Clues arrive in order: country, draft, teams (one more team per reveal), career stats, then awards."
            ]
          }
        ]
      },
      {
        heading: "Land the name or give up to see it",
        items: [
          "Land the name for the remaining points, or give up to see the answer."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Scoring from 1000 down to a floor of 100",
        items: [
          "Scoring starts at 1000, drops 150 per revealed clue and never goes below 100.",
          "There are up to 6 reveals beyond the starting position clue."
        ]
      },
      {
        heading: "Wrong guesses cost you nothing",
        items: [
          "Wrong guesses are unlimited and free, and a last name alone counts."
        ]
      },
      {
        heading: "The daily player and Hard mode",
        items: [
          "The daily player is shared worldwide, saves in your browser and flips at midnight Eastern; unlimited deals random players.",
          "Hard mode hides the two easiest clues from the board without touching the scoring."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "A thin position clue points to a country",
        paragraphs: [
          "Say the position reads center. Too thin, so you reveal country: Canada. Still huge, so you buy the draft clue: first overall, 2015."
        ]
      },
      {
        heading: "Two reveals spent, seven hundred banked",
        paragraphs: [
          "That is Connor McDavid and you know it. Two reveals spent means 700 points on the table, and typing McDavid banks all of them."
        ]
      }
    ],
    tipSections: [
      {
        heading: "The draft clue is the loudest tell",
        items: [
          "The draft clue is the loudest tell. A famous year and pick can end the game on the spot."
        ]
      },
      {
        heading: "Guess constantly, reveal sparingly",
        items: [
          "Guess constantly. Wrong answers are free, reveals are not."
        ]
      },
      {
        heading: "Teams reveal in career order",
        items: [
          "Teams appear in career order, so the first club revealed is where it all started.",
          "The 100 point floor means you should never quit; a fully revealed win still pays something."
        ]
      }
    ],
    faqs: [
      {
        q: "Do wrong guesses lower my score?",
        a: "No. Only clue reveals cost points. Fire away between reveals."
      },
      {
        q: "Do I need the full name?",
        a: "No. The last name works, so typing Crosby matches Sidney Crosby."
      },
      {
        q: "What exactly does Hard mode hide?",
        a: "The position and country clues stay off the board. Scoring is identical; you just work with less."
      }
    ]
  },
  "/hockey-higher-lower": {
    intro: [
      "Two players side by side, one question: who ended up with more career points?",
      "Ten quick rounds, a streak bonus that snowballs, and a daily set of matchups the whole site sweats together. It sounds easy until a pure sniper meets a quiet playmaker."
    ],
    headings: {
      howToPlay: "How to play NHL Higher or Lower, a free hockey trivia comparison game",
      rules: "NHL Higher or Lower rules: scoring, streaks and the daily matchups",
      example: "NHL Higher or Lower walkthrough: Jagr's points against Hull's goals",
      tips: "NHL Higher or Lower tips for reading career point totals",
      faq: "NHL Higher or Lower FAQ: scoring, ties and Hard mode"
    },
    howToPlaySections: [
      {
        heading: "Compare two players side by side",
        items: [
          "Look at the two players: name, position, country and teams."
        ]
      },
      {
        heading: "Pick the higher career point total",
        items: [
          "Tap the one you think has more career points, meaning goals plus assists."
        ]
      },
      {
        heading: "Watch the totals reveal before the next pair",
        items: [
          "Both totals flash up for a couple of seconds, then the next pair skates in."
        ],
        subsections: [
          {
            heading: "Score points and build a streak bonus",
            items: [
              "Correct picks pay 10 points each, and streaks pay extra on top."
            ]
          }
        ]
      },
      {
        heading: "Finish ten rounds and share your score",
        items: [
          "Ten rounds, then share your score."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Ten rounds worth ten points each",
        items: [
          "10 rounds per game and 10 points per correct answer."
        ]
      },
      {
        heading: "A growing streak bonus tops out at 325",
        items: [
          "The streak bonus grows: your second straight correct adds 5, the third adds 10, and so on.",
          "A perfect 10 with an unbroken streak scores exactly 325."
        ]
      },
      {
        heading: "Ties count and the daily matchups reset",
        items: [
          "Dead ties count as correct no matter which side you pick.",
          "Daily serves the same 10 matchups to everyone until midnight Eastern; Hard mode, unlimited only, builds close-gap pairs."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Jagr's points beat Hull's goals",
        paragraphs: [
          "Round one, say it is Jaromir Jagr against Brett Hull. Hull's 741 goals scream at you, but points is the stat, and Jagr's 1921 buries Hull's 1391."
        ]
      },
      {
        heading: "Six straight before a coin flip pair",
        paragraphs: [
          "You ride that logic to six straight before a coin flip pair snaps the run. Final: 8 of 10 with a fat streak bonus, plus one matchup you will argue about all day."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Points means goals plus assists",
        items: [
          "Points means goals plus assists. Playmakers sneak past pure goal scorers."
        ]
      },
      {
        heading: "Longevity beats a short hot streak",
        items: [
          "Longevity wins these. Twenty seasons of good usually beats eight seasons of great."
        ]
      },
      {
        heading: "Watch positions and guard your streak",
        items: [
          "Watch positions: an offensive defenseman can out-point a checking forward, but forwards win most pairs.",
          "Guard a live streak. The bonus grows every round it survives, so the late rounds are worth the most."
        ]
      }
    ],
    faqs: [
      {
        q: "Is it goals or points?",
        a: "Career points, meaning goals and assists combined."
      },
      {
        q: "What is the maximum score?",
        a: "325. That is all 10 correct with the streak never breaking: 100 in base points plus 225 in bonus."
      },
      {
        q: "What does Hard mode do?",
        a: "Unlimited only. It pairs players with close career totals, so the gimmes disappear."
      }
    ]
  },
  "/nhl-connections": {
    intro: [
      "Twenty NHL players, four hidden groups and just enough overlap to wreck your confidence.",
      "Each group of five shares a connection, maybe a franchise, maybe a career milestone. Find all four on 4 lives, then come back tomorrow and do it again."
    ],
    headings: {
      howToPlay: "How to play NHL Connections, a free hockey grouping puzzle game",
      rules: "NHL Connections rules: groups, lives and the daily puzzle",
      example: "NHL Connections walkthrough: five Penguins and a hidden trap",
      tips: "NHL Connections tips for spotting the overlap trap",
      faq: "NHL Connections FAQ: group size, lives and the reset"
    },
    howToPlaySections: [
      {
        heading: "Study the board of twenty names",
        items: [
          "Study the board of 20 names."
        ]
      },
      {
        heading: "Submit five players who share a link",
        items: [
          "Select exactly 5 players you believe share a connection and submit."
        ]
      },
      {
        heading: "Lock in a group or lose a life",
        items: [
          "A correct five locks in with its color and theme. A wrong five costs one of your 4 lives."
        ],
        subsections: [
          {
            heading: "Colors rank the four groups by difficulty",
            items: [
              "Colors rank difficulty: yellow easiest, then green, blue and purple."
            ]
          }
        ]
      },
      {
        heading: "Clear every group before the lives run out",
        items: [
          "Clear all four groups before the lives run out."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Twenty players, four groups of five",
        items: [
          "The board is always 20 players forming exactly four groups of 5."
        ]
      },
      {
        heading: "Four lives and no partial hints",
        items: [
          "You have 4 lives, every wrong submission costs one, and there are no partial hints."
        ]
      },
      {
        heading: "A reveal at zero lives and the daily reset",
        items: [
          "Losing the last life reveals the remaining groups so you can see what got you.",
          "The daily puzzle is identical for everyone and rolls over at midnight Eastern; unlimited mode deals random boards from the pool."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Five Penguins look automatic",
        paragraphs: [
          "Say you spot five Penguins right away: Crosby, Malkin, Lemieux, Jagr and Fleury. Feels automatic, except the purple group on this imagined board is 1,000 point scorers, and Jagr fits both worlds."
        ]
      },
      {
        heading: "Letting elimination settle the trap",
        paragraphs: [
          "The safe play is solving the scorers first and letting elimination sort Jagr out. That is the whole game in one decision."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Submit the group you can name in full",
        items: [
          "Submit the group where you can name all five, not the one with three locks and two hopes."
        ]
      },
      {
        heading: "Assume the overlap is intentional",
        items: [
          "Assume the overlap is intentional. The player who fits two themes is the trap.",
          "Think about purple early. Spotting the sneaky link protects your easy groups."
        ]
      },
      {
        heading: "Let elimination settle a shared name",
        items: [
          "When two groups fight over one name, solve the other group first and let elimination decide."
        ]
      }
    ],
    faqs: [
      {
        q: "Groups of five, not four?",
        a: "Yes. Five players per group and 20 on the board, a little bigger and meaner than the puzzle that inspired it."
      },
      {
        q: "Do I get a warning when I am one player off?",
        a: "No. Any wrong five costs a life, no matter how close it was."
      },
      {
        q: "What happens at zero lives?",
        a: "The unsolved groups reveal themselves, your daily result locks for the day, and a fresh board arrives tomorrow."
      }
    ]
  },
  "/conquest-nhl": {
    intro: [
      "Every patch of the US map starts loyal to its nearest NHL arena, and none of it is safe.",
      "This is imperialism rules on ice: win a game, annex the loser's entire empire. Lose everything and you keep playing, because one win takes it all back. Five clubs even start with nothing."
    ],
    headings: {
      howToPlay: "How to play NHL Conquest, a free hockey territory prediction game",
      rules: "NHL Conquest rules: scoring, seeding and the Daily Challenge",
      example: "NHL Conquest walkthrough: an empire lost and won back",
      tips: "NHL Conquest tips for picking winners and holding territory",
      faq: "NHL Conquest FAQ: the Daily Challenge, landless teams and the map"
    },
    howToPlaySections: [
      {
        heading: "Pick your team from all 32 clubs",
        items: [
          "Pick your team from all 32."
        ]
      },
      {
        heading: "Call your featured game each round",
        items: [
          "Each round, call the winner of your featured game before it plays. Correct calls pay 25 score."
        ]
      },
      {
        heading: "Watch every loser hand over its land",
        items: [
          "Watch the whole league's results redraw the map; every loser hands over every territory it owned."
        ],
        subsections: [
          {
            heading: "Survive 16 rounds to seed a playoff",
            items: [
              "Survive 16 rounds. The top 8 empires seed a playoff."
            ]
          }
        ]
      },
      {
        heading: "Win three rounds to lift the Imperial Cup",
        items: [
          "Win the Quarterfinals, Semifinals and the Imperial Cup Final to rule the map."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Every loss transfers the whole empire",
        items: [
          "16 regular rounds, and every game transfers the loser's entire empire to the winner."
        ]
      },
      {
        heading: "Five clubs start landless as invaders",
        items: [
          "Toronto, Ottawa, Edmonton, Vancouver and Buffalo start landless as the invaders."
        ]
      },
      {
        heading: "Seeding, scoring and how goals fall",
        items: [
          "Playoff seeding takes the 8 biggest empires, with win-loss record breaking ties.",
          "Final score: 3 per territory held, 25 per correct call, 50 for making the playoffs, 200 for winning it all.",
          "Winners score 2 to 7 goals, overtime games finish one goal apart, and ties do not exist."
        ]
      },
      {
        heading: "The Daily Challenge and Free Play",
        items: [
          "The Daily Challenge deals every player the same date-seeded season: same starting map, same fixtures, same results. One scored run per day with streaks. Free Play is unlimited and fully random."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "An empire vanishes in one night",
        paragraphs: [
          "Say you ride the Avalanche. Round 3 they lose a coin flip and the whole empire vanishes in one night. Round 5 they win, and because that opponent had been hoarding, you inherit more land than you lost."
        ]
      },
      {
        heading: "A landless team swallows an empire whole",
        paragraphs: [
          "Meanwhile Edmonton, landless since round 1, finally wins in round 9 and swallows an empire whole. That is the invader life: nothing to lose, everything to take."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Call favorites for the safest points",
        items: [
          "Call favorites. Upsets pay the same 25, and the percentages shown come from team strength plus home ice."
        ]
      },
      {
        heading: "Never quit on a wiped out team",
        items: [
          "Never quit on a wiped-out team. The format is built for comebacks."
        ]
      },
      {
        heading: "Territory decides seeding, even in the playoffs",
        items: [
          "Check the standings: territories decide seeding first, so a fat empire matters more than a pretty record.",
          "Playoff games transfer land too, so the eventual champion usually ends up owning most of the map."
        ]
      }
    ],
    faqs: [
      {
        q: "How does the Daily Challenge work?",
        a: "Everyone on the planet gets the same season today: identical starting map, identical fixtures, identical results. Your score comes from which empire you back and how well you call the games, so comparing scores is a fair fight. One scored run per day, streaks build if you show up daily, and a fresh map drops at midnight Eastern. Free Play stays unlimited."
      },
      {
        q: "My team got erased in round 2. Is my run over?",
        a: "No. Wiped-out clubs keep their full schedule, and beating any landowner hands you everything they hold."
      },
      {
        q: "Why do five teams start with nothing?",
        a: "Territories go to the nearest NHL arena, and those five clubs lose that geography, so they open as invaders."
      },
      {
        q: "Can the season end before round 16?",
        a: "Yes. If one club paints the entire map, total conquest ends the season immediately."
      }
    ]
  },
  "/nhl-my-career": {
    intro: [
      "You start as a name on a draft board and end, if it all breaks right, with a call from the Hall in Toronto.",
      "Your player is fictional. The league is real: 32 NHL teams, real trophies, a whole career of season stat lines in between.",
      "You build your player's actual face before the draft, and there is a dirty side waiting whenever you want it. An envelope on the bench with a bounty in it, a twelve year contract whose tail years everyone knows you will never play, a doctor in Europe with a suitcase, and a man who pays for the starting goalie an hour before anyone announces it. Every dirty choice raises a hidden league meter, and at the top of it is an indefinite suspension that costs you a full season."
    ],
    headings: {
      howToPlay: "How to play NHL My Career, a free hockey career simulation game",
      rules: "NHL My Career rules: aging, money and the legacy score",
      example: "NHL My Career walkthrough: a Sniper's road to the Cup",
      tips: "NHL My Career tips for durability, morale and free agency",
      faq: "NHL My Career FAQ: eras, badges and the rival player"
    },
    howToPlaySections: [
      {
        heading: "Create your player",
        items: [
          "Create your player: name, one of 5 positions (C, LW, RW, D, G), and one of 17 archetypes, from Generational Talent to The Agitator to The Workhorse in net."
        ],
        subsections: [
          {
            heading: "Pick today's NHL or the old 2006 throwback",
            items: [
              "Pick your league: today's NHL, or the 2006-07 throwback with the Thrashers in Atlanta and the Coyotes in Phoenix, before Vegas or Seattle existed."
            ]
          }
        ]
      },
      {
        heading: "Shop your look and work the Bank",
        items: [
          "Build your look, then spend the money in 7 aisles including a shady one that only appears once you have something to hide.",
          "Open the Bank between seasons. Savings pays 2.5% a season and never loses, five things you can put money into each have a price that moves every season whether you look or not (a fund, flats back home, two shares and a coin that halves as often as it doubles), the statement keeps your last 12 moves, and the card school at the back of the plane is one sitting a season on odds that are printed before you sit in."
        ]
      },
      {
        heading: "Read the News box and chase badges",
        items: [
          "Read the News box. The paper writes up every season in your own position's stat, the SocialGram shows followers read off your fanbase with three fan comments under the latest post, and the rival's card keeps the head to head against the player drafted the same year as you.",
          "Collect badges in the Trophy Case: 23 of them, from a first Cup and the Calder to 500 goals, a 50 goal season and $100M to your name, each lit the moment the facts of your career say so."
        ],
        subsections: [
          {
            heading: "Answer your phone on the hockey calendar",
            items: [
              "Answer your phone. Texts from your agent, the head coach, the GM, a teammate or your mom land on the beats of the hockey year: draft day, camp, the World Juniors while you are young enough to go, the All-Star break, the trade deadline, the playoffs if you get there, the offseason, and the summer before the last year of your deal. Every text says which beat and which year it came in on, and how you answer moves your karma, morale, fanbase or bank."
            ]
          },
          {
            heading: "Make the call when your rival forces one",
            items: [
              "Some seasons your rival forces a decision instead of making a headline: a cheap shot after the whistle you can settle or shrug off, a debate show offering real money, a youth clinic his foundation wants you to co-host, an All-Star vote his club is buying ads for. Every button prints exactly what it moves, and a gamble prints its odds."
            ]
          }
        ]
      },
      {
        heading: "Get drafted and win the lineup battle",
        items: [
          "Get drafted by a real club; your slot reflects your starting ability.",
          "Check the lineup. Top ten skaters step straight in; everyone else fights the incumbent in camp every fall. Goalies always apprentice first, because no rookie walks into a number one crease."
        ]
      },
      {
        heading: "Play seasons, offseasons and free agency",
        items: [
          "Play each season: skaters post goals, assists and points, goalies post wins and save percentage.",
          "Face up to three offseason decisions each year, one card at a time: training, trade requests, media noise. Only the first card can move your rating, and a card you just saw rests for a while (press moments follow your season, so those can come right back).",
          "After a normal offseason choice, the result shows the actual changes. Expand it for any extra changes, then Continue opens the next card, or takes you back to your career after the last one, without applying the choice again.",
          "Open Career Log and pick a year to review its saved overview, regular season and postseason. Changes compare with the previous saved season; older missing values say Not recorded. Back to seasons returns to the year tiles, and Review seasons is available after retirement.",
          "When the deal expires, hit July 1 for real: competing offers from named clubs with their own money, length and roster quality, and one push for more on any of them.",
          "Age, decline, answer the retirement talk, then read the legacy verdict and wait on the Hall of Fame ballot."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Careers start young and can run long",
        items: [
          "Careers start in 2026 at age 18 or 19 and last up to 22 seasons. The throwback starts in 2006 instead, inside a sealed 30 team league verified against the real season, with 2006 sized contracts.",
          "You improve toward your potential through age 25; decline starts at 31 for skaters, 34 for goalies."
        ]
      },
      {
        heading: "The lineup and the press are both real",
        items: [
          "The lineup is real: fourth-line seasons run on half the ice time, a backup goalie gets twenty-odd starts, camps have memory both ways, and signing with a stacked Cup contender can cost a mid player his spot.",
          "The press reads your actual season: lift the Cup and you take the podium, miss badly and you face the scrum, sit down the lineup and the role question finds you. Three answers each time, safe, honest or fiery, and fiery gambles your fanbase for real."
        ]
      },
      {
        heading: "Your rival's choices and what they move",
        items: [
          "When your rival makes no headline in a season, there is a 45% chance he puts a choice in front of you instead, never both in one season, and each choice comes up once before any repeats. A button only moves what it prints: morale, fanbase, net worth, karma or the heat of the feud. Morale rides straight into next season's points or save percentage."
        ]
      },
      {
        heading: "How the phone's calendar works",
        items: [
          "Texts only arrive on beats your season really had. No playoff texts in a year your club missed, World Juniors texts only in a season you start at 19 or younger, no contract year texts until one year is left on the deal, and draft day's text lands before you play a shift. One text a beat, up to three a season, fewer while old ones sit unanswered, and the same text never comes twice in a career.",
          "The season the game retires you (40 for skaters, 41 for goalies, 22 seasons, or a rating that collapses) sends nothing about a year you will not play: no summer skates, no new stick and skate deal, no extension talk."
        ]
      },
      {
        heading: "Retirement and the legacy score",
        items: [
          "Retirement hits at 40 for skaters, 41 for goalies, or earlier if your rating collapses. Before that, from 31, slipping 8 points off your best (or down to 69) brings the talk: retire now, one more year, or a farewell season. You can walk away after 6 seasons.",
          "The legacy score weighs Cups, majors (Hart, Norris or Vezina), Conn Smythes, All-Star nods, seasons and production; 500 or more means the Hall of Fame.",
          "Hall of Fame voters weigh the hardware first (Cups, the major awards, All-Star years), then your seasons and your numbers, and a career total near the top of this game's books in a stat your position really piles up (goals, assists, points or a goalie's wins) earns a push of its own, up to 390 legacy points.",
          "Example: take a winger with ordinary numbers and one with the same hardware and more assists than 99 of 100 wingers this game has seen. The second scores at least 300 legacy points more, which can be the whole gap between a long wait and the Hall. A career you already retired keeps the ballot it was told."
        ]
      },
      {
        heading: "Money has rules of its own",
        items: [
          "Money has rules of its own. There is a 1% fee on both sides of every trade and a $100k floor in the account that cannot be invested away; a season that leaves you under the floor is covered out of savings first, then by a forced sale of holdings at whatever the price is that day. Cards win 42% of hands and a win pays 1.15x the stake, the most you can stake is $50k or 4% of your cash, and once you are $500k down for your career the boys stop dealing you in for good. Keep sitting in while you are losing and somebody at home notices, which costs morale and fanbase."
        ]
      },
      {
        heading: "What the fans nag you about, and your one save",
        items: [
          "The fans nag you for the thing your position is judged on and never the other way round: a center hears more points, a winger hears bury more chances, the man on the blue line hears move the puck and keep it out, and a goalie only ever hears make the saves.",
          "One career saves automatically in your browser; a new one replaces it."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Reading an actual capped change",
        paragraphs: [
          "Say Health is 98 before a recovery choice that adds 10. The 100 cap makes the result 98 to 100, so the card shows +2. Continue moves you on (to the next card, or back to your career after the last one) with Health still at 100."
        ]
      },
      {
        heading: "A Sniper winger breaks out at 23",
        paragraphs: [
          "Say your Sniper winger goes 23rd overall to a rebuilding club. Year one is 24 goals and silence. At 23 you erupt for 47 with an All-Star nod, but the losing wrecks your morale, so you force a trade to a contender."
        ]
      },
      {
        heading: "A Cup, then a Hall of Fame near miss",
        paragraphs: [
          "At 27 you win the Cup. The legs go at 33, you switch to maintenance summers, grab two more years and retire at 38: one Cup, six All-Star nods, a franchise icon verdict. The Hall says not quite."
        ]
      },
      {
        heading: "Answering a cheap shot after the whistle",
        paragraphs: [
          "Your rival gets away with a cheap shot after the whistle, no call, and the card asks what you do about it. Settle it next game heats the feud and usually pays Morale +8, but it carries a 30% chance you are the one who gets the penalty (Morale -5, Fanbase -5, Net worth -$100k). Shrug it off on camera is Fanbase +5, Karma +5 and the feud cools. You pick say nothing and watch the tape: Morale +6, the feud heats up, and those six points ride into next season's line."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Durability comes from the archetype",
        items: [
          "Durability is baked into the archetype. Power forwards break down; two-way types last."
        ]
      },
      {
        heading: "Skills coach summers change with age",
        items: [
          "Skills coach summers add rating while you are young; from 31 on they quietly become body maintenance."
        ]
      },
      {
        heading: "Morale, money and the free agency choice",
        items: [
          "Morale feeds the stat engine, so playing miserable costs real production.",
          "In free agency the rebuild pays the most and the contender pays the least. The roster number on each offer is the exact quality your next seasons run on, so the choice is money against playoff springs."
        ]
      }
    ],
    faqs: [
      {
        q: "Am I playing as a real NHL player?",
        a: "No. You are a fictional prospect dropped into the real league."
      },
      {
        q: "What is the highest verdict?",
        a: "900 or more reads as Rushmore of the sport. The Hall of Fame line sits at 500."
      },
      {
        q: "Can a goalie reach the Hall?",
        a: "Yes. Wins, Vezinas and Cups carry goalie legacies."
      },
      {
        q: "Why am I the backup goalie?",
        a: "Because that is how goalies come up: nobody hands a rookie the crease, top pick or not. You open behind the veteran, take your twenty-odd starts, and win the number one job in camp when your level passes his. Skaters fight the same fight for top-line minutes; a fourth-line year is half the ice time and it wears on you."
      },
      {
        q: "Can I start in a different era?",
        a: "Yes. The create screen has a 2006-07 throwback: the 30 team league with the Atlanta Thrashers and the Phoenix Coyotes, before Vegas, Seattle or Utah existed. An era career never meets a franchise that did not exist then."
      },
      {
        q: "What is in the Bank?",
        a: "Four tabs. Account holds your cash, a savings account that pays 2.5% a season, and a statement of your last 12 moves. Market is five prices that move every season, each with its own risk word and a read on whether it is cheap or dear against what it usually goes for. Cards is the card school at the back of the plane, one sitting a season, on odds the screen prints before you play. Shop is the 7 aisles. It is the same engine Soccer Career's phone runs on, in dollars."
      },
      {
        q: "Who is my rival?",
        a: "A generated player drafted the same year at your position. He plays his own seasons on the same scale you do, can lift a Cup before you and retire before you, and the head to head is kept for good. He is fictional, like your own player, so no real player's career is being simulated."
      },
      {
        q: "How do I earn badges?",
        a: "By doing the thing. Each of the 23 badges is a test on the facts of your career, checked every time you open the case: a Cup, a major, 500 goals, 1,000 points, a million dollars to your name. The single season badges sit under the real records and say so: 50 goals against Wayne Gretzky's 92 in 1981-82, 100 points against his 215 in 1985-86, and a 40 win season against the 48 that Martin Brodeur and Braden Holtby share."
      }
    ]
  },
  "/nhl-front-office": {
    intro: [
      "Running an NHL club is a math problem with feelings, and now the math is yours.",
      "You get a curated roster snapshot, original simulation ratings, a points race and a divisional bracket. New opening estimates use 2024-25 and 2025-26 regular-season inputs: offensive production for forwards, offense and usage proxies for defensemen, and save-rate proxies for goalies. Contracts, potential and future events are simulated."
    ],
    headings: {
      howToPlay: "How to play NHL Front Office, a free hockey GM simulation game",
      rules: "NHL Front Office rules: the cap, trades and trust upstairs",
      example: "NHL Front Office walkthrough: a Buffalo rebuild on the phone",
      tips: "NHL Front Office tips for building a roster that keeps winning",
      faq: "NHL Front Office FAQ: trades, firing and how long a save lasts"
    },
    howToPlaySections: [
      {
        heading: "Pick a club and inherit its roster",
        items: [
          "Pick any of the 32 clubs from the roster snapshot. Read each opening estimate note: the e marker means limited evidence, and an unmeasured game prior means the model lacks a usable observation. These estimates do not measure every skill. Existing saves keep their grades and development."
        ],
        subsections: [
          {
            heading: "Read the ownership mandate each offseason",
            items: [
              "Read the ownership mandate: a contender is told to win the Cup, a bubble club to make the bracket, a rebuild to hit an honest win number. It resets every offseason from where the roster really stands."
            ]
          }
        ]
      },
      {
        heading: "Waive, sign and work the phone on trades",
        items: [
          "Shape it: waive players, sign free agents, and work the phone on trades, where the other GM counters with pick demands and lesser returns instead of a flat yes or no."
        ]
      },
      {
        heading: "Hire a staff, settle contracts and build packages",
        items: [
          "Under the hub's own boxes sit four more: Staff, Re-sign desk, Draft picks and Trade desk. A new franchise opens with them switched on. An older save plays on exactly as it did until you open one of them.",
          "Staff: a head coach, a special teams assistant, a goalie coach, a scouting director and a head athletic therapist, each rated 1 to 10. Hire off a shortlist, pay off the man you do not want, and match or let go when another club comes in for a good one.",
          "Re-sign desk: every player whose deal runs out this summer gets a tile. Keep him at his ask, push once with your own number, or let him go. Anyone you leave open is settled by your staff's own rule when the summer starts, never by a coin flip.",
          "Trade desk: build a package of up to five pieces a side, players and picks, and keep paying part of a salary to make the money work. It shuts at the deadline."
        ]
      },
      {
        heading: "Choose who contributes to your simulation rating",
        items: [
          "Open Roster and choose your simulation contributors: six healthy forwards, four healthy defensemen and one healthy goalie. If a group has fewer available players, use all of them. Uncheck a selected forward or defenseman before choosing his replacement.",
          "Stage your changes, then Apply contributors to save them. Use automatic goes back to the highest rated healthy players. These groups feed the rating model; they are not full lines, defensive pairs or ice time."
        ]
      },
      {
        heading: "Sim the season and watch your pace",
        items: [
          "Sim the season in 20 rounds of roughly four games each, with a live read on whether you are on pace."
        ]
      },
      {
        heading: "Qualify, then win the Stanley Cup",
        items: [
          "Qualify for the playoffs: top three per division plus two wild cards per conference.",
          "Win four best-of-7 rounds to lift the Stanley Cup, then draft and go again, as long as ownership keeps you."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "A hard cap that rises every season",
        items: [
          "The cap starts at 104M and rises about 9 percent a season in this simulation. Free-agent offers must fit your room, including dead money. The existing salary-matching trade rules can allow a club above the cap; this is a limit of the game's model. New-model future offers use one fixed rating curve; unexpired signed contracts keep their price."
        ]
      },
      {
        heading: "Real points and a roster floor and ceiling",
        items: [
          "Points are real: 2 for a win, 1 for an overtime loss, and roughly a quarter of losses go to overtime.",
          "Rosters run between 8 and 15 players, floor and ceiling both enforced."
        ]
      },
      {
        heading: "Trades and the draft carry real risk",
        items: [
          "Phone trades are player for player plus an optional pick, and the AI prices age, rating and position before saying yes. Bigger packages live on the Trade desk box.",
          "Each club starts with 2 simulation picks. Trades can leave you with fewer or more choices, and each selection spends one owned pick. With none left, finish the draft and offseason. Rivals get two batches of up to five eligible selections in this abbreviated draft. Scouting grades carry error; the true rating appears only after you commit. In new-model franchises, rival clubs follow the scouting order and choose an affordable contract against the next cap, keeping unavailable choices in the pool. A contract price depends on the underlying simulated ability, so it is not a scout-only knowledge model."
        ]
      },
      {
        heading: "Waiving a player and the dead money",
        items: [
          "Waiving a man is not free. Half his salary stays on this season's cap as dead money, a quarter lands on next season's if he had years left, and you cannot sign him back until the offseason."
        ]
      },
      {
        heading: "Trust upstairs runs from zero to 100",
        items: [
          "Trust upstairs runs 0 to 100: beat the mandate and it climbs, miss it and it falls, a Cup fixes almost anything, and at zero you are fired and the save ends."
        ]
      },
      {
        heading: "Deadline day, restricted free agents and retained salary",
        items: [
          "The trade deadline falls after round 15 of 20. The break after round 15 is deadline day, your last chance to deal, and once round 16 is played every deal is shut, phone calls and packages alike, until the summer. The real one falls in early March. At the deadline clubs in a playoff place, or close to one, are buyers who pay up for veterans; clubs well out of it are sellers who want picks and young players.",
          "A draft pick signs an entry level deal, three seasons from 18 to 21. When it runs out, a player under 27 with fewer than seven seasons is a restricted free agent: a qualifying offer keeps his rights, and a rival with a roster spot may table an offer sheet you either match or let go for the picks it carries. Everyone else is unrestricted. The money is this game's own figures, not real contracts.",
          "Your club's picks now run three drafts deep, two rounds each in this game's short draft, and any of them can be traded. A club can keep paying up to half of a traded player's salary, carry three retained deals at a time, and one contract can be retained on twice.",
          "Staff effects are small and capped. The head coach adds rating points on attack and defense, the goalie coach on the goalies, and the special teams assistant counts at a fifth because this game has no power play of its own. A better scouting director misses by less on a prospect's grade, and the therapist shortens injuries. Ownership gives the staff 8M each summer for fees and pay offs; wages sit outside the cap."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "What a goalie change does in the model",
        paragraphs: [
          "For a fictional rating example, keep your forwards and defensemen unchanged and replace a healthy 80 rated goalie with a healthy 85 rated goalie. The goalie group has a 20 percent weight, so your simulation strength rises by one point. Apply commits that choice; it changes your odds, not a promised result."
        ]
      },
      {
        heading: "A goalie coach, an RFA tender and a deadline buy",
        paragraphs: [
          "Open Staff and hire a level 7 goalie coach off the shortlist. Level 7 is two rating points on the goalie, and the goalie carries a fifth of your strength, so the club gets 0.4 stronger on every night. That is a nudge to your odds, not a promised result.",
          "Your 21 year old winger's entry deal runs out this summer, so he is a restricted free agent on the Re-sign desk. Tender him the qualifying offer and he stays a season at the money he earns now. If a rival has tabled an offer sheet, the tile says so: match it and he stays on the sheet's terms, or let him go and the picks on the sheet come to you.",
          "At round 14 you sit in a wild card place, which makes you a buyer. On the Trade desk you send a depth winger and a second rounder two drafts out to a club well out of it for its veteran center, keeping half the winger's salary so the cap works. Wait until round 16 is played and the box just reads Deadline passed."
        ]
      },
      {
        heading: "Working the phone for a Buffalo blueliner",
        paragraphs: [
          "Say you take Buffalo. You waive a fading winger, sign a 79 rated defenseman, then package your third line center plus a pick for a younger blueliner. The AI takes the deal because the value clears its price."
        ]
      },
      {
        heading: "A wild card sweat and a draft grade that slips",
        paragraphs: [
          "The season becomes a wild card sweat decided by overtime loser points. You sneak in, stun a division winner, then die in the division final. At the draft an 88 grade center turns out to be an 84."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Overtime loser points decide close races",
        items: [
          "Overtime loser points decide races. A team hovering around .500 can still make the bracket on them."
        ]
      },
      {
        heading: "Strength math behind your team rating",
        items: [
          "Strength math: your selected forwards carry half your rating, your defensemen 30 percent and your goalie 20 percent. Automatic selection uses the top six healthy forwards, top four healthy defensemen and best healthy goalie. An empty group uses a rating of 62 in this game's model.",
          "If a selected player is injured or leaves your roster, the game keeps your other valid choices and fills the gap with the highest rated healthy option. A player who recovers needs to be selected again if you want him back in the group."
        ]
      },
      {
        heading: "Hoard players who still have upside",
        items: [
          "Players 23 and under develop toward their potential every offseason. Hoard them."
        ]
      }
    ],
    faqs: [
      {
        q: "Why does the AI keep rejecting my trades?",
        a: "It wants a premium. Centers cost the most, age tanks value fast, and adding a pick often flips a no into a yes."
      },
      {
        q: "Can I get fired?",
        a: "Yes. Ownership grades the mandate every season and tracks trust from 0 to 100. Missing the bracket with a Cup-or-bust roster costs real trust, and at zero the save ends and you take another chair."
      },
      {
        q: "How long can one franchise run?",
        a: "As long as ownership keeps you. Seasons chain through the draft and offseason, the game autosaves in your browser, and your Cup count carries over."
      },
      {
        q: "Do my contributor choices survive a reload?",
        a: "Yes, after Apply contributors they live in your existing franchise save. Unsaved changes are only a preview. Old saves use automatic selection, and Use automatic clears your manual choices. You cannot select an injured player, somebody from another club or the same player twice."
      }
    ]
  },
  "/nhl-connect-4": {
    intro: [
      "Connect 4 grew a hockey brain. The gravity is the same and four in a row still wins, but every cell must be earned by naming a real NHL player.",
      "Grab a friend for pass and play, pick a column, and answer the trivia question waiting on the row where your piece lands."
    ],
    headings: {
      howToPlay: "How to play NHL Connect 4, a free hockey trivia board game",
      rules: "NHL Connect 4 rules: boards, names and the AI referee",
      example: "NHL Connect 4 walkthrough: a diagonal win on a Hart Trophy",
      tips: "NHL Connect 4 tips for blocking and naming players fast",
      faq: "NHL Connect 4 FAQ: opponents, referees and missed answers"
    },
    howToPlaySections: [
      {
        heading: "Red and blue take turns",
        items: [
          "Red and blue take turns on one device."
        ]
      },
      {
        heading: "Drop a piece into a column",
        items: [
          "Pick a column. Your piece falls to the lowest open row."
        ]
      },
      {
        heading: "Name a player who fits both labels",
        items: [
          "Name a player matching both labels, like Canadiens plus Hall of Famer."
        ],
        subsections: [
          {
            heading: "A miss costs nothing, so retry or skip",
            items: [
              "A verified answer claims the cell. A miss costs nothing, so retry or hit Skip."
            ]
          }
        ]
      },
      {
        heading: "Connect four to win the board",
        items: [
          "Connect four of your color in any direction to win; a full board is a draw."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Seven columns, six rows and themed boards",
        items: [
          "The board is 7 columns by 6 rows, dealt from a set of themed boards: Original Six matchups, trophies, birth countries, goalies."
        ]
      },
      {
        heading: "Every name works once, wrong answers are free",
        items: [
          "Every player name can be used exactly once per game.",
          "Wrong answers never cost your turn; only Skip passes it."
        ]
      },
      {
        heading: "Relocated franchises and the AI referee",
        items: [
          "Franchise history survives relocation: Nordiques answers count for the Avalanche, Whalers for the Hurricanes, Thrashers for the Jets.",
          "An AI referee checks each answer, and when it cannot verify one, nothing is placed and you simply try again."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Red opens on a Hall of Famer",
        paragraphs: [
          "Say the Original Six board comes up. Red opens in the Canadiens column and lands on the Hall of Famer row: Patrick Roy, easy money. Blue answers Penguins plus 500+ Career Goals with Mario Lemieux."
        ]
      },
      {
        heading: "Mark Messier closes it on a diagonal",
        paragraphs: [
          "Ten moves later red needs one diagonal cell, and the landing row is Hart Trophy under the Rangers column. Mark Messier, the 1992 Hart winner as a Ranger, ends it."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Think one stack height ahead",
        items: [
          "Think one row ahead. The stack height decides which row your answer must satisfy, so a column's question changes with every drop."
        ]
      },
      {
        heading: "Ration your universal legends",
        items: [
          "Ration your universal legends. A name that answers many cells is gone for the whole game once played."
        ]
      },
      {
        heading: "Type goalie names in full, and block often",
        items: [
          "Goalies are missing from the suggestion list; type the full name and press Enter.",
          "Block like it is real Connect 4. Sometimes the right move is claiming a cell just to deny the row."
        ]
      }
    ],
    faqs: [
      {
        q: "Is there a computer opponent?",
        a: "No. It is pass and play for two people, or you can run both colors and battle yourself."
      },
      {
        q: "What happens if the referee cannot verify my answer?",
        a: "It fails safe. No piece is placed, no turn is lost, and you can try the same cell again."
      }
    ]
  },
  "/perfect-lineup-nhl": {
    intro: [
      "Three forwards, two defensemen, a goalie. Easy, except the game names the terms before you pick a single player.",
      "Half your slots arrive locked to a franchise or a decade, and the dream line gets built around them from a pool of all-time greats. Then the sim grades the whole thing."
    ],
    headings: {
      howToPlay: "How to play Perfect Lineup: NHL, a free dream line builder game",
      rules: "Perfect Lineup: NHL rules: slots, chemistry and grading",
      example: "Perfect Lineup: NHL walkthrough: an Oilers and Avalanche line",
      tips: "Perfect Lineup: NHL tips for filling constrained slots first",
      faq: "Perfect Lineup: NHL FAQ: daily resets, redos and the player pool"
    },
    howToPlaySections: [
      {
        heading: "Read your six slots and their constraints",
        items: [
          "Read your six slots: LW, C, RW, two D and a G. Three carry a constraint tag like Oilers or 1990s."
        ]
      },
      {
        heading: "Pick from the eligible legends list",
        items: [
          "Tap a slot and pick from the eligible legends; the list only shows players who fit the position and the tag."
        ]
      },
      {
        heading: "Build chemistry across team and era",
        items: [
          "No player fills two slots, and picks sharing a team or era build chemistry."
        ],
        subsections: [
          {
            heading: "Fill every slot and hit Simulate",
            items: [
              "Fill all six and hit Simulate."
            ]
          }
        ]
      },
      {
        heading: "Share your grade or run it back",
        items: [
          "Share the scoreline and grade, or tweak the lineup and run it back."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Six slots, three of them constrained",
        items: [
          "6 slots, and exactly 3 of them are constrained to a franchise or an era."
        ]
      },
      {
        heading: "Rating weighs talent over chemistry",
        items: [
          "Your final rating is 80 percent talent, 20 percent chemistry.",
          "Chemistry counts picks who share a team or era with at least one other pick."
        ]
      },
      {
        heading: "Grades from A+ down, and the daily reset",
        items: [
          "Grades: A+ at 92 or better, A at 84, B at 74, C at 62, D below that.",
          "Daily constraints refresh every day, and unlimited mode rerolls random ones whenever you want."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Gretzky, Jagr and Makar fill the constraints",
        paragraphs: [
          "Say the daily locks the center slot to the Oilers, the right wing to the 1990s and one defense slot to the Avalanche. Gretzky takes the middle, Jagr the wing, Cale Makar the blue line."
        ]
      },
      {
        heading: "Chemistry links turn the lineup into an A",
        paragraphs: [
          "Now the chemistry play: Paul Coffey doubles up with Gretzky on team and era, and Patrick Roy links to Makar through the Avalanche tag. The sim spits out a 5-0 and an A."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Fill the constrained slots first",
        items: [
          "Fill the constrained slots first. Their lists are short, and a flexible star wasted early can block them."
        ]
      },
      {
        heading: "Stack a dynasty core for chemistry",
        items: [
          "Stack a dynasty core. Two or three picks from one team and era move the chemistry needle fast."
        ]
      },
      {
        heading: "Do not chase chemistry over talent",
        items: [
          "Do not chase chemistry into bad ratings; talent is most of the math.",
          "In unlimited, reroll until constraints overlap. An Oilers slot next to a 1980s slot is a gift."
        ]
      }
    ],
    faqs: [
      {
        q: "Is the daily lineup the same for everyone?",
        a: "Yes, everyone works with the same constraint set each day. Unlimited rolls are random."
      },
      {
        q: "Can I redo my daily after simulating?",
        a: "Yes. Edit the lineup and simulate again as often as you like."
      },
      {
        q: "Who is in the player pool?",
        a: "A curated set of NHL greats from Gordie Howe to Connor McDavid, each tagged with one position, franchise and era."
      }
    ]
  },
  "/nhl-gauntlet-draft": {
    intro: [
      "The draft mode, hockey style: eleven picks, two forward lines, two defense pairs and a goalie, five real players a pick from a genuine star to a bargain, and you keep exactly one.",
      "Then the playoffs begin. Your finished lineup runs five knockout rounds against ever stronger invented opposition, rated 77 up to 98, with sudden death overtime when the game is level.",
      "The run is decided entirely by the lineup you drafted: the same eleven always runs the same playoffs, so every pick is the game."
    ],
    headings: {
      howToPlay: "How to play Gauntlet Draft: NHL, a free daily hockey lineup draft game",
      rules: "Gauntlet Draft: NHL rules for cards, ratings and the playoffs",
      example: "Gauntlet Draft: NHL walkthrough: a 91 rated lineup chases the Cup",
      tips: "Gauntlet Draft: NHL tips for goalies, wings and the lineup rating",
      faq: "Gauntlet Draft: NHL FAQ: daily drafts, opponents and overtime"
    },
    howToPlaySections: [
      {
        heading: "Choosing the daily gauntlet or a fresh draft",
        items: [
          "Pick the daily gauntlet (the same five card choices for everyone today) or unlimited for a fresh draft."
        ]
      },
      {
        heading: "Reading five cards for every spot in the lineup",
        items: [
          "For each spot, center, wingers, defense and goal, read the five cards, star to bargain, and tap the one you keep."
        ],
        subsections: [
          {
            heading: "Why a center can fill a wing spot",
            items: [
              "A wing spot takes a winger or a center, because centers slide out to the wing all the time. A center spot only takes a center, and the defense and goalie spots only take their own."
            ]
          }
        ]
      },
      {
        heading: "Watching the playoffs start on their own",
        items: [
          "After the eleventh pick the playoffs start on their own: five rounds, one game each, revealed one at a time."
        ]
      },
      {
        heading: "Scoring points for every round survived",
        items: [
          "Survive a round for 16 points; lift the Cup for exactly 100."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Real players off real NHL rosters",
        items: [
          "Every card is a real player off a real 2026-27 roster, 32 clubs and 13 players each, the same data NHL Front Office plays. Every opponent club is invented on purpose."
        ]
      },
      {
        heading: "How ratings come from real production",
        items: [
          "Ratings come from real 2025-26 production, not opinion: forwards and defensemen from their points per game against others at their position, goalies from save percentage and wins."
        ],
        subsections: [
          {
            heading: "Why four goalies rated 68 sit out",
            items: [
              "The roster data gives anyone without a qualifying 2025-26 season a placeholder rating of 68 and does not say which 68s those are, so the four goalies rated 68 are left out of the deal rather than risk dealing a number their play never produced."
            ]
          }
        ]
      },
      {
        heading: "A star and a bargain at every spot",
        items: [
          "The five cards per spot are spread across the pool's rating range, so a star and a bargain are always both on the table."
        ],
        subsections: [
          {
            heading: "Nobody dealt twice in one draft",
            items: [
              "No player is dealt twice in one draft."
            ]
          }
        ]
      },
      {
        heading: "A knockout decided by the rating gap",
        items: [
          "The knockout is deterministic in your lineup: scoring comes from the rating gap, a level game goes to sudden death overtime, and replaying the same eleven replays the same playoffs."
        ],
        subsections: [
          {
            heading: "No shootouts in playoff hockey",
            items: [
              "There are no shootouts, because playoff hockey does not have them. Overtime goes on until somebody scores."
            ]
          }
        ]
      },
      {
        heading: "Opposition ratings climbing toward the Cup Final",
        items: [
          "Opposition ratings climb 77, 84, 89, 94, 98. A bargain lineup usually goes out in the first two rounds, an elite one often reaches the Cup Final, and even a perfect draft lifts the Cup only about one run in seven."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Taking the best goalie card on offer",
        paragraphs: [
          "The goalie spot deals a 90 next to an 87, an 83, an 81 and a 70. Nothing costs anything, so the 90 is the pick unless you are collecting one club."
        ]
      },
      {
        heading: "A 91 rated lineup runs the playoffs",
        paragraphs: [
          "Your finished lineup rates 91. The Qualifying Round is a 6-0 rout, the First Round a 4-0 shutout, the Second Round goes to overtime and you take it 3-2, and the Conference Final ends the run 4-2. Three rounds survived, 48 points, and the card you would take back is the 82 you settled for on the second defense pair."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Treating the goalie as one card in eleven",
        items: [
          "The goalie counts the same as any other card toward the rating, one eleventh of it, so a weak goalie hurts no more than a weak winger, and no less either."
        ]
      },
      {
        heading: "Spotting centers in the wing picks",
        items: [
          "The wing picks can deal centers, and a center is often the best card in the pick, so do not skip past one in a wing spot."
        ]
      },
      {
        heading: "Building toward a lineup in the mid nineties",
        items: [
          "The Cup only becomes a real chance once your lineup is in the mid nineties. Watch the running rating under the cards as you fill the lines."
        ]
      }
    ],
    faqs: [
      { q: "Is the daily draft the same for everyone?", a: "Yes. One shared set of five card choices per Eastern Time date, so daily scores compare fairly." },
      { q: "Are the opponents real teams?", a: "No, and that is deliberate: every opponent is an invented club, so no real logo or name is borrowed. The players you draft are real, off real 2026-27 rosters." },
      { q: "Why does the card say EDM instead of the club's full name?", a: "The abbreviation is what the roster data itself carries, and it keeps the page light. Any hockey fan reads it at a glance." },
      { q: "Why does a tied game never go to a shootout?", a: "Because this is the playoffs, and the NHL settles playoff games with sudden death overtime, period after period, until somebody scores." },
      { q: "Is this the same game as the soccer Gauntlet Draft?", a: "Same engine, hockey's own roster data, lineup and playoff ladder. Eleven picks, the same depth as the soccer XI and the MLB lineup card." }
    ]
  }
};

// src/data/gameContent/moreSports.ts
var MORE_SPORTS_CONTENT = {
  "/cage-clash": {
    intro: [
      "Cage Clash puts you in control of an original pixel fighter. Move around the cage, find a gap in the guard and decide whether to keep trading shots or take the fight to the ground. Every hit, takedown and submission comes from what happens in the fight.",
      "Pick a balanced fighter, a striker or a grappler, then choose the style you want to face. Each fight lasts up to three short arcade rounds. Play with the touch controls or use the keyboard. No account or download needed.",
      "Circuit turns those skills into a three fight run. Beat a balanced opponent, a striker and a grappler in order. Track your wins in the opponent tiles and adapt your plan for each style."
    ],
    headings: {
      howToPlay: "How to play Cage Clash on phone or keyboard",
      rules: "Cage Clash rules for strikes and grappling",
      example: "Cage Clash example: from clinch to submission",
      tips: "Cage Clash tips for stamina and ground control",
      faq: "Cage Clash FAQ: controls, scoring and pauses"
    },
    howToPlay: [
      "Choose Quick fight, your fighting style and the CPU style, read the controls and start a fight. Choose Practice for four untimed drills with a passive partner.",
      "Hold the movement buttons to get in range. Hold Guard to block. Use Punch, Heavy or Kick when you have an opening and enough stamina.",
      "Get close and use Clinch. The buttons change with your position: try a takedown, strike from the clinch or break away.",
      "On the ground, work for position before chasing a finish. The top fighter can strike, posture up and pass. The bottom fighter can defend, regain guard, sweep or stand.",
      "Hold Submission to build pressure. Watch your stamina and submission progress. The other fighter can resist or escape.",
      "The action buttons show Ready, Move closer, Recover gas or Recovering using your actual range, gas and cooldown. These are hints: you can keep holding a move through recovery, and an out-of-range shot can still miss and spend gas. Paused and Not in drill explain the current controls.",
      "Between rounds, read the scorecard and continue when ready. At the finish, check the result and your score, then try another matchup.",
      "Choose Circuit to take on all three styles. A win unlocks Next opponent; a loss or draw ends the run. Every opponent starts a fresh fight with full health and stamina.",
      "Open Fight stats after a Quick fight or any Circuit fight to compare your shots landed, damage dealt, blocks, takedowns and time on top against the CPU. Back returns to the result so you can start another fight or advance."
    ],
    rules: [
      "A fight has up to three 45 second arcade rounds. Between rounds, the clock waits for you to continue.",
      "Strikes need the correct range. Attacks spend stamina and have a cooldown. Holding a button does not create free attacks.",
      "Guard reduces incoming strike damage and costs stamina. Low stamina weakens your attacks and your defense.",
      "A clinch starts at close range. Takedowns decide who lands on top. Position, style and stamina matter on the ground.",
      "Health reaching zero ends the fight by knockout. Full submission progress ends it by submission. Otherwise, earned round points decide the result.",
      "Your score is out of 100. A win earns 50 points and a winning knockout or submission adds 15. Damage contributes up to 20, while defense or ground control contributes up to 15. A draw earns 25 outcome points.",
      "Pause, opening the rules, losing focus or switching away stops the fight. Resume clears held controls. Quitting or refreshing gives no completion score.",
      "Practice uses the same range, stamina and ground rules with an untimed partner. The practice panel shows earned progress, the next move and the actual result of your last attempt. Learn striking and recovery, an earned takedown, a submission finish or escaping from mount. Only the moves for your drill are active, and practice earns no score.",
      "Circuit records one completion for the run. Add the earned fight scores, divide by three and round to the nearest whole point. Unplayed fights contribute zero. Quitting or refreshing an unfinished circuit earns no points.",
      "These are original fighters and simplified arcade rules. This game does not replay real fights or use real athletes.",
      "Punches, kicks and ground strikes have moving pixel poses. With reduced motion enabled on your device, action poses stay steady and the crowd stays still. The same fighting rules apply.",
      "The ground poses show guard, half guard and mount. Passing and escaping have effort poses, and submission grips tighten as your actual pressure builds. Reduced motion keeps effort poses steady while still showing your current position and submission pressure.",
      "Fight stats describe only the fight you just finished. Damage is rounded to a whole number. Top control is time spent on top, shown in seconds. Opening or closing the recap does not change your score."
    ],
    example: [
      "You choose a grappler against a striker. Walk into punching range with Guard held, then release it when you want to attack. Trading kicks all round lets the opponent keep the fight where they want it.",
      "Get close and use Clinch. Save enough stamina for the takedown. If you land on top, pass into a better position before holding Submission. If you land underneath, defend, regain guard and look for a sweep or an escape.",
      "Submission progress shows actual pressure. If the opponent resists and your stamina gets low, ease off and recover instead of holding the same button until you have nothing left.",
      "A Circuit run with fight scores of 80, 90 and 85 earns 85/100. If the first fight ends in a loss with 30 earned points, the run ends at 10/100 because the two unplayed fights count as zero.",
      "If you landed 12 shots and the CPU landed 8, the Shots landed row shows 12 under You and 8 under CPU. More shots alone do not decide a fight: check the damage, takedowns and top control too.",
      "In the takedown drill, reaching the clinch is the first step. If your partner defends the takedown, the panel shows what happened and keeps the takedown step unfinished. Release the controls to recover gas, then try again. In the escape drill, half guard is progress, but you still need to regain guard before standing up."
    ],
    tips: [
      "Distance is a defense. Step out of punching range when you need a moment to recover.",
      "Mix your strikes. Kicks reach farther, while the closer attacks work when the opponent lets you inside.",
      "Read the position label and button names after a takedown. A button that passed on top becomes a sweep underneath.",
      "Try the same style against different opponents. The CPU uses the same range, stamina and legal action rules you do."
    ],
    faqs: [
      { q: "Can I grapple and submit an opponent?", a: "Yes. Clinch at close range, try a takedown and use the ground controls to pass, sweep, defend or escape. Hold Submission to apply pressure when your position and stamina allow it." },
      { q: "What are the keyboard controls?", a: "Use Left and Right or A and D to move, Space to guard, J, K and L for the upper action row, and U, I and O for the lower row. P or Escape pauses. The buttons show what each action does in your current position." },
      { q: "Does a fight keep running when I switch tabs?", a: "No. Switching away or losing focus pauses it and releases held inputs. Resume when you are ready. Opening the rules pauses it too." },
      { q: "Does my fight save if I refresh?", a: "Refreshing starts over in every mode. Quick fight records its score after a completed fight. Circuit records one score when the run ends; Practice earns no points. Quitting an unfinished fight or circuit earns no score." }
    ]
  },
  "/f1-driver": {
    intro: [
      "Somewhere in Formula 1 history sits a driver, and the game knows exactly who. Guess The F1 Driver hides one of 20 grand prix greats behind six clues that unlock one at a time.",
      "The first clue is a single word, a vibe. The rest get concrete: race wins, world titles, teams, nationality, and one famous career moment. Solve it on clue one for 1000 points; limp to clue six and you're playing for 100."
    ],
    headings: {
      howToPlay: "How to play Guess The F1 Driver, a free Formula 1 guessing game",
      rules: "Guess The F1 Driver rules for clues, guesses and scoring",
      example: "Guess The F1 Driver walkthrough: from a vibe word to Hamilton",
      tips: "Guess The F1 Driver tips for clues, hints and guesses",
      faq: "Guess The F1 Driver FAQ: guesses, hints and signing in"
    },
    howToPlaySections: [
      {
        heading: "Choosing Daily Challenge or Unlimited mode",
        items: [
          "Choose Daily Challenge for the shared mystery driver, or Unlimited for random drivers on repeat."
        ]
      },
      {
        heading: "Reading the one word vibe clue",
        items: [
          "Read the one-word vibe and see if a name jumps out."
        ]
      },
      {
        heading: "Searching for a driver to guess",
        items: [
          "Search and pick a driver to guess. A surname or a HAM style shorthand resolves to the right person."
        ],
        subsections: [
          {
            heading: "How each miss reveals a new clue",
            items: [
              "Every wrong guess reveals the next clue, so a miss always buys information."
            ]
          }
        ]
      },
      {
        heading: "Using the hint button to see ahead",
        items: [
          "The hint button unlocks the next clue without risking a guess, though it lowers your score tier just like a miss."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Six clues and a pool of 20 drivers",
        items: [
          "Six clues per driver, and the answer pool holds 20 drivers."
        ]
      },
      {
        heading: "Scoring from 1000 points down to 100",
        items: [
          "Scoring by clue: 1000, 800, 600, 400, 200, then 100 points."
        ]
      },
      {
        heading: "Why six wrong guesses ends it",
        items: [
          "A wrong guess while the sixth clue is showing ends the game, so six misses is the cap."
        ]
      },
      {
        heading: "Giving up and the daily driver",
        items: [
          "Giving up reveals the driver and scores 0. The daily driver changes every day."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "A first guess at Michael Schumacher",
        paragraphs: [
          "Imagine the vibe word is Dominant. That fits a handful of drivers, so you take a swing at Michael Schumacher. Wrong, and the next clue slides out: 105 race wins, the all-time record."
        ]
      },
      {
        heading: "Landing on Lewis Hamilton for 800 points",
        paragraphs: [
          "Only one driver owns that number. You type Lewis Hamilton on clue two and bank 800 points."
        ]
      },
      {
        heading: "What waiting for the title clue would pay",
        paragraphs: [
          "Waiting for the championship clue to confirm the seven titles would have paid 600. Confidence is worth 200 points here."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Browsing the autocomplete for ideas",
        items: [
          "The autocomplete list only contains drivers who can actually be the answer, so browsing it is a legitimate move."
        ]
      },
      {
        heading: "Why hints are safer than a miss",
        items: [
          "Hints never end your game, but wrong guesses can. Once all six clues are out, guess like it's match point."
        ]
      },
      {
        heading: "Practicing the pool in Unlimited mode",
        items: [
          "Unlimited recycles the same pool, so a few practice runs teach you every possible answer."
        ]
      }
    ],
    faqs: [
      {
        q: "How many guesses do I get?",
        a: "Up to six. Once the sixth clue is out, one more miss ends the round."
      },
      {
        q: "Does the hint button cost points?",
        a: "Indirectly. It reveals the next clue, dropping your potential score to that tier, exactly as a wrong guess would."
      },
      {
        q: "Do I need an account?",
        a: "No. Signing in is optional and only matters for saved stats and leaderboards."
      }
    ]
  },
  "/f1-higher-lower": {
    intro: [
      "Two drivers, one question: who won more Grands Prix? Simple, until the pairings leave the obvious names behind.",
      "The pool is every driver in F1 history with at least 8 career wins, 42 of them, from the 1950s through 2025. Points systems changed too much across eras to compare fairly, so the game runs on race wins, a stat that travels."
    ],
    headings: {
      howToPlay: "How to play F1 Higher or Lower, a daily Formula 1 trivia game",
      rules: "F1 Higher or Lower rules for rounds, streaks and ties",
      example: "F1 Higher or Lower walkthrough: Prost, Senna and Fangio's math",
      tips: "F1 Higher or Lower tips for reading seasons and eras",
      faq: "F1 Higher or Lower FAQ: wins, points and daily matchups"
    },
    howToPlaySections: [
      {
        heading: "Picking Daily or Unlimited matchups",
        items: [
          "Pick Daily for today's shared matchups or Unlimited for endless random pairs."
        ]
      },
      {
        heading: "Reading both driver cards",
        items: [
          "Read both cards: each shows the seasons raced, title count, and teams."
        ]
      },
      {
        heading: "Tapping the driver with more wins",
        items: [
          "Tap the driver you think won more Grands Prix."
        ]
      },
      {
        heading: "Watching the real totals flash up",
        items: [
          "The real totals flash up, then the next pair rolls in after a couple of seconds."
        ],
        subsections: [
          {
            heading: "Stringing wins together for a streak bonus",
            items: [
              "String correct answers together to grow the streak bonus."
            ]
          }
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Ten rounds worth ten points each",
        items: [
          "10 rounds per game, 10 points per correct answer."
        ]
      },
      {
        heading: "How the streak bonus climbs to 325",
        items: [
          "Streaks pay rising bonuses: the second straight correct adds 5 points, the third adds 10, and so on. A perfect 10 for 10 run maxes out at 325."
        ]
      },
      {
        heading: "Why an exact tie still counts",
        items: [
          "Exact ties count as correct no matter which driver you picked."
        ]
      },
      {
        heading: "Hard mode's close win totals",
        items: [
          "Hard mode, Unlimited only, deliberately pairs drivers with close win totals."
        ]
      },
      {
        heading: "The daily matchups and midnight reset",
        items: [
          "The daily is the same 10 matchups for everyone and flips at midnight Eastern."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Prost and Senna agree with the titles",
        paragraphs: [
          "Say round one hands you Alain Prost against Ayrton Senna. Titles say 4 against 3, and the wins agree: Prost 51, Senna 41."
        ]
      },
      {
        heading: "Fangio's short seasons still cash in",
        paragraphs: [
          "Round five is nastier: Juan Manuel Fangio, five-time champion, against David Coulthard, zero titles. But 1950s seasons were short. Fangio sits on 24 wins, Coulthard on 13, so the legend still cashes."
        ]
      },
      {
        heading: "Closing at 155 on a six round streak",
        paragraphs: [
          "You close 8 of 10 with a six-round streak in the middle and post 155. The streak did the heavy lifting."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Why titles can lie about win totals",
        items: [
          "Titles lie. Stirling Moss won 16 races and no championship, while Fangio turned 24 wins into 5 titles."
        ]
      },
      {
        heading: "Watching the seasons raced on the card",
        items: [
          "Watch the seasons on the card. Long modern careers usually mean big win counts."
        ]
      },
      {
        heading: "Relaxing on an identical feeling pair",
        items: [
          "When two drivers feel identical, relax: a dead heat pays either way."
        ]
      },
      {
        heading: "Using Hard mode to study the numbers",
        items: [
          "Use Hard mode as a study tool. Small gaps teach you the actual numbers fast."
        ]
      }
    ],
    faqs: [
      {
        q: "Why compare wins instead of points?",
        a: "Points systems changed massively across eras. A 1950s win paid around 8 points against 25 today, which would make every older driver an automatic low answer."
      },
      {
        q: "What if both drivers have the same win total?",
        a: "The round counts as correct whichever side you tapped."
      },
      {
        q: "Is my daily progress saved?",
        a: "Yes, finished rounds hold for the day. A new set of pairs arrives at midnight Eastern."
      }
    ]
  },
  "/f1-constructor": {
    intro: [
      "This time the mystery isn't a driver, it's a whole team. Guess The Constructor hides one of 31 Formula 1 constructors behind six clues, from the giants of the modern grid to names that vanished decades ago.",
      "Clues arrive in a fixed order: a one-word vibe, the team's country, its era, its championship haul, its livery, and finally a famous driver. Every extra clue cuts your payout."
    ],
    headings: {
      howToPlay: "How to play Guess The Constructor, a free F1 team guessing game",
      rules: "Guess The Constructor rules for clues and scoring tiers",
      example: "Guess The Constructor walkthrough: Iconic, Italy and Ferrari",
      tips: "Guess The Constructor tips for reading country and livery clues",
      faq: "Guess The Constructor FAQ: dead teams and the daily driver link"
    },
    howToPlaySections: [
      {
        heading: "Choosing Daily Challenge or Unlimited teams",
        items: [
          "Pick Daily Challenge for the shared team of the day or Unlimited for random constructors."
        ]
      },
      {
        heading: "Starting from the vibe word clue",
        items: [
          "Start from the vibe word and guess whenever a team feels right."
        ]
      },
      {
        heading: "How each wrong guess unlocks a clue",
        items: [
          "Each wrong guess unlocks the next clue in the sequence."
        ],
        subsections: [
          {
            heading: "Taking a hint without risking a miss",
            items: [
              "Take a hint to see the next clue without risking a miss; the score tier drops just the same."
            ]
          }
        ]
      },
      {
        heading: "Naming the constructor before six clues",
        items: [
          "Name the constructor before the six clues run out."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "A pool of 31 constructors and six clues",
        items: [
          "The pool holds 31 constructors and each puzzle has 6 clues."
        ]
      },
      {
        heading: "Points from 1000 down to 100",
        items: [
          "Points by clue: 1000, 800, 600, 400, 200, 100."
        ]
      },
      {
        heading: "What a final wrong guess costs you",
        items: [
          "A wrong guess with all six clues showing ends the round. Giving up scores 0."
        ]
      },
      {
        heading: "The daily team and the daily driver",
        items: [
          "The daily constructor is picked independently of the daily driver, so the two F1 games never mirror each other."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Waiting out the Iconic clue",
        paragraphs: [
          "Suppose clue one reads Iconic. Half the grid thinks that's them, so you wait. Clue two says Italy, and now it's a short list."
        ]
      },
      {
        heading: "Ferrari confirmed for 800 points",
        paragraphs: [
          "Iconic plus Italy has one obvious owner. Ferrari on clue two banks 800 points."
        ]
      },
      {
        heading: "What the 16 title clue would confirm",
        paragraphs: [
          "Holding out for the championship clue, a count of 16 titles, would have confirmed it at 400. Some clues are worth skipping."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Why Britain alone will not save you",
        items: [
          "Country is the power clue, but Britain won't save you: McLaren, Williams, Lotus and more are all UK based."
        ]
      },
      {
        heading: "Learning the giants' championship counts",
        items: [
          "Learn the championship counts of the giants. Numbers like 16 and 9 are fingerprints."
        ]
      },
      {
        heading: "Guessing before the livery clue lands",
        items: [
          "The livery clue almost always gives it away. If you have any read at all, guess before it appears."
        ]
      },
      {
        heading: "Not anchoring on the current grid",
        items: [
          "Defunct teams are in here too, so don't anchor on the current grid."
        ]
      }
    ],
    faqs: [
      {
        q: "Are dead teams fair game?",
        a: "Yes. The 31-team pool mixes the current grid with historic constructors like Lotus, Brabham and Tyrrell."
      },
      {
        q: "Is the daily team related to the daily driver?",
        a: "No. The two dailies are chosen separately, so solving one gives you no edge on the other."
      }
    ]
  },
  "/perfect-lineup-f1": {
    intro: [
      "Perfect Lineup: F1 hands you five empty driver seats and a catch: three of them come with a constraint. Maybe a seat only accepts Ferrari drivers, or drivers from the 1990s, or Finns.",
      "You fill the seats from a pool of 41 drivers across eras, each rated up to 99, then hit Simulate. The game grades your squad on pace and chemistry and turns it into a season result you can share."
    ],
    headings: {
      howToPlay: "How to play Perfect Lineup: F1 and build a five driver squad",
      rules: "Perfect Lineup: F1 rules for slots, chemistry and grades",
      example: "Perfect Lineup: F1 walkthrough: five legends and one grade jump",
      tips: "Perfect Lineup: F1 tips for constraints and chemistry links",
      faq: "Perfect Lineup: F1 FAQ: squares, duplicate drivers and slots"
    },
    howToPlaySections: [
      {
        heading: "Checking which slots carry constraints",
        items: [
          "Check which of the five slots carry constraints: a team, era, or country tag."
        ]
      },
      {
        heading: "Searching the eligible driver pool",
        items: [
          "Tap a slot and search. The picker only lists eligible drivers, highest rated first."
        ]
      },
      {
        heading: "Chasing links while you pick",
        items: [
          "Chase links while you pick: drivers sharing a team, country, or era boost chemistry."
        ]
      },
      {
        heading: "Simulating once all five seats are filled",
        items: [
          "Clear and swap picks freely, then hit Simulate once all five seats are filled."
        ],
        subsections: [
          {
            heading: "Sharing the result or rolling new constraints",
            items: [
              "Share the result, or roll new constraints with New Lineup."
            ]
          }
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Five slots and three constraints",
        items: [
          "Five slots, 3 of them constrained. Every constraint is guaranteed at least 4 eligible drivers."
        ]
      },
      {
        heading: "How squad rating and chemistry combine",
        items: [
          "Squad rating is 80 percent average driver rating plus 20 percent chemistry."
        ]
      },
      {
        heading: "The grade bands from A+ to D",
        items: [
          "Grades: A+ at a rating of 92 or better, A at 84, B at 74, C at 62, D below."
        ]
      },
      {
        heading: "Daily constraints versus New Lineup",
        items: [
          "Daily mode gives everyone the same constraints once a day; New Lineup rolls random ones anytime."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Star hunting under Ferrari and Finland",
        paragraphs: [
          "Say your constraints are Ferrari, Finland and the 1990s. You go star hunting: Michael Schumacher, Kimi Raikkonen, Ayrton Senna, then Lewis Hamilton and Max Verstappen in the free seats. Average rating: just over 97."
        ]
      },
      {
        heading: "A B grade from five great names",
        paragraphs: [
          "The sim returns a B. Five all-time greats, almost no connections: only the Schumacher and Raikkonen overlap registers, and chemistry lands at 27."
        ]
      },
      {
        heading: "Swapping in Hakkinen for an A grade",
        paragraphs: [
          "Swap Senna for Mika Hakkinen and it flips: two Finns, two Ferrari drivers, a shared era. Chemistry 40, rating 85, grade A. Lesser name, better team."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Why rating still leads the formula",
        items: [
          "Ratings are 80 percent of the formula, so never tank quality for one link. Find picks that do both jobs."
        ]
      },
      {
        heading: "Filling constrained slots before free ones",
        items: [
          "Fill the constrained slots first, then patch chemistry with the free seats."
        ]
      },
      {
        heading: "Why era overlaps are the cheapest links",
        items: [
          "Era overlaps are the cheapest links: same-decade drivers connect even when teams and countries don't."
        ]
      },
      {
        heading: "Rebuilding a daily squad with Edit Lineup",
        items: [
          "In daily mode, Edit Lineup lets you rebuild and simulate again."
        ]
      }
    ],
    faqs: [
      {
        q: "What do the colored squares in my shared result mean?",
        a: "One square per slot: green for a driver rated 88 or higher, yellow for 75 to 87, black below that."
      },
      {
        q: "Can two slots use the same driver?",
        a: "No. Once a driver is seated, they disappear from the other slots' pickers."
      }
    ]
  },
  "/guess-tennis-player": {
    intro: [
      "A mystery tennis player is hiding behind six clues, and they could come from either tour. Men's legends, women's legends, everyone is in the same deck.",
      "Clues unlock in a set order: a one-word vibe, nationality and era, tour, Grand Slam count, slam details, and a famous moment. The sooner you commit, the more you score."
    ],
    headings: {
      howToPlay: "How to play Guess The Player, a free tennis guessing game",
      rules: "Guess The Player rules for clues, tours and scoring",
      example: "Guess The Player walkthrough: closing in on Serena Williams",
      tips: "Guess The Player tips for the tour clue and slam counts",
      faq: "Guess The Player FAQ: ATP, WTA and loading the player list"
    },
    howToPlaySections: [
      {
        heading: "Choosing the daily puzzle or Unlimited",
        items: [
          "Choose the daily puzzle, shared by everyone that day, or Unlimited for random legends."
        ]
      },
      {
        heading: "Taking an early swing at the vibe word",
        items: [
          "Read the vibe word and take an early swing if you're feeling brave."
        ]
      },
      {
        heading: "How each wrong guess reveals a clue",
        items: [
          "Each wrong guess reveals the next clue in the sequence."
        ],
        subsections: [
          {
            heading: "Taking a hint without spending a guess",
            items: [
              "The hint button unlocks the next clue without spending a guess; the score tier drops either way."
            ]
          }
        ]
      },
      {
        heading: "Typing a name from the suggestions",
        items: [
          "Type the player's name and pick from the suggestions to lock it in."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Six clues and the scoring tiers",
        items: [
          "6 clues maximum, with scoring tiers of 1000, 800, 600, 400, 200 and 100 points."
        ]
      },
      {
        heading: "Why the sixth clue ends the round",
        items: [
          "A wrong guess while the sixth clue is showing ends the game."
        ]
      },
      {
        heading: "Giving up and revealing the player",
        items: [
          "Giving up ends the round at 0 and reveals the player."
        ]
      },
      {
        heading: "Accepting common short names",
        items: [
          "Common names work: the game accepts well known short versions of a name."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "An American star with too many candidates",
        paragraphs: [
          "Suppose clue two describes an American who ruled across the 2000s and 2010s. Too many candidates, so you pass. Clue three says WTA, and clue four lands the hammer: 23 Grand Slam singles titles."
        ]
      },
      {
        heading: "Serena Williams confirmed at 23 titles",
        paragraphs: [
          "Only one player in history owns exactly 23. You type Serena Williams on clue four and take 400 points."
        ]
      },
      {
        heading: "What a sharper era read would have paid",
        paragraphs: [
          "A sharper read on the era hint might have gotten you there a clue earlier for 600. That's the game inside the game."
        ]
      }
    ],
    tipSections: [
      {
        heading: "How the tour clue halves the field",
        items: [
          "The tour clue instantly halves the field. Torn between a man and a woman? Wait for it."
        ]
      },
      {
        heading: "Slam counts as fingerprints",
        items: [
          "Slam counts are fingerprints at the top: 24, 23, 22 and 20 each point at one or two legends."
        ]
      },
      {
        heading: "Skimming the suggestion list for ideas",
        items: [
          "The suggestion list doubles as a roster of possible answers. Skim it when you're lost."
        ]
      },
      {
        heading: "Why era knowledge beats forehands",
        items: [
          "Early clues reward era knowledge. Knowing who peaked when beats knowing forehands."
        ]
      }
    ],
    faqs: [
      {
        q: "Are ATP and WTA players both included?",
        a: "Yes. The pool mixes men's and women's greats, and the tour clue tells you which side you're on."
      },
      {
        q: "Can the same player show up twice in Unlimited?",
        a: "Yes. Unlimited picks are random each round, so repeats can happen in a long session."
      },
      {
        q: "Why does the game load before I can start?",
        a: "Puzzles come from the site's own tennis database, so the player list downloads first. If it fails, a retry link appears."
      }
    ]
  },
  "/tennis-chain": {
    intro: [
      "Every tennis great has lost to somebody. Tennis Chain turns that into a game: start from a legend, name a player who beat them at a Grand Slam, then someone who beat that player, for as long as your memory holds.",
      "There's no timer and no guess meter. Just one rule: every answer must be a real Grand Slam defeat of your current player, and one mistake ends the run."
    ],
    headings: {
      howToPlay: "How to play Tennis Chain, a free Grand Slam connection game",
      rules: "Tennis Chain rules for links, points and badges",
      example: "Tennis Chain walkthrough: from Federer to a broken link",
      tips: "Tennis Chain tips for finals and big career hubs",
      faq: "Tennis Chain FAQ: defeats, accounts and connection errors"
    },
    howToPlaySections: [
      {
        heading: "Picking Daily Challenge or Unlimited",
        items: [
          "Pick Daily Challenge, where everyone starts from the same player, or Unlimited for a random starter."
        ]
      },
      {
        heading: "Thinking of a Grand Slam winner",
        items: [
          "Think of anyone who beat the current player at a major."
        ]
      },
      {
        heading: "Searching and submitting a name",
        items: [
          "Search the name and submit. The game verifies the matchup before the link counts."
        ],
        subsections: [
          {
            heading: "How a verified defeat joins the chain",
            items: [
              "Each verified defeat adds the winner to your chain, and they become the new current player."
            ]
          }
        ]
      },
      {
        heading: "Playing on until you miss or cash out",
        items: [
          "Keep going until you miss, repeat a player, or cash out with Give Up."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Every verified link is worth 100 points",
        items: [
          "Every verified link is worth 100 points."
        ]
      },
      {
        heading: "How the multiplier grows the chain",
        items: [
          "Your total is multiplied by 1.5 once the chain reaches 5 links and by 2 at 10."
        ]
      },
      {
        heading: "What ends a run instantly",
        items: [
          "Naming a player already used in the chain ends the run, and so does one wrong answer."
        ]
      },
      {
        heading: "Badges at 3, 5 and 10 links",
        items: [
          "Badges land at 3 links (Club Player), 5 (Pro Circuit) and 10 (Grand Slam Champion)."
        ]
      },
      {
        heading: "Retrying after a connection problem",
        items: [
          "If the checker hits a connection problem, nothing is lost; just retry."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Starting the chain at Roger Federer",
        paragraphs: [
          "Say you start on Roger Federer. Rafael Nadal beat him at Roland Garros more than once: link one. Nadal to Novak Djokovic is just as easy. Link two."
        ]
      },
      {
        heading: "Wawrinka earns the Club Player badge",
        paragraphs: [
          "From Djokovic you remember Stan Wawrinka's 2015 French Open final win. Link three, 300 points, and the Club Player badge is yours."
        ]
      },
      {
        heading: "Where the chain finally breaks",
        paragraphs: [
          "Then you blank on who ever beat Wawrinka at a slam, toss out a name you can't back up, and the run ends at 300."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Thinking of Grand Slam finals first",
        items: [
          "Think finals first. Title matches are the defeats everyone remembers."
        ]
      },
      {
        heading: "Only chaining into losses you can picture",
        items: [
          "Don't chain into a player whose losses you can't picture. You have to escape everyone you name."
        ]
      },
      {
        heading: "Saving your big hubs for later",
        items: [
          "Save the big hubs, players with famous losses across eras, for when you're stuck."
        ]
      }
    ],
    faqs: [
      {
        q: "Does the win have to be a final?",
        a: "No. Any victory over your current player at a Grand Slam counts, first round included."
      },
      {
        q: "Do I need an account for the leaderboard?",
        a: "No account needed. You just type a nickname when you save your score."
      },
      {
        q: "The game couldn't verify my answer. Did I lose?",
        a: "No. That message means a connection hiccup, not a wrong answer. Your chain stays alive and you can resubmit."
      }
    ]
  },
  "/tennis-higher-lower": {
    intro: [
      "Serena or Federer: who won more Grand Slam singles titles? This game asks that kind of question 10 times, and it mixes both tours in one pool on purpose, because cross-tour matchups are where the arguments live.",
      "The pool holds 44 champions, from the pioneers of the 1920s to active stars, with title counts frozen through the 2026 Australian Open."
    ],
    headings: {
      howToPlay: "How to play Tennis Higher or Lower, a daily Grand Slam trivia game",
      rules: "Tennis Higher or Lower rules for rounds, ties and streaks",
      example: "Tennis Higher or Lower walkthrough: Serena, Federer and a tie",
      tips: "Tennis Higher or Lower tips for tie clusters and eras",
      faq: "Tennis Higher or Lower FAQ: cross tour picks and title counts"
    },
    howToPlaySections: [
      {
        heading: "Choosing Daily or Unlimited matchups",
        items: [
          "Choose Daily for the shared matchups or Unlimited for random ones."
        ]
      },
      {
        heading: "Reading each player's title years and tour",
        items: [
          "Read both cards: each shows the years of the player's first and last major and their tour."
        ]
      },
      {
        heading: "Tapping the player with more Grand Slams",
        items: [
          "Tap the player you think won more Grand Slam singles titles."
        ]
      },
      {
        heading: "Watching the real numbers reveal",
        items: [
          "Watch the real numbers reveal, then roll into the next round."
        ],
        subsections: [
          {
            heading: "Chaining correct picks into a streak",
            items: [
              "Chain correct answers to build the streak bonus."
            ]
          }
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Ten rounds and ten points a pick",
        items: [
          "10 rounds, 10 points per correct pick."
        ]
      },
      {
        heading: "How the streak bonus reaches 325",
        items: [
          "Streaks add 5 extra points on the second straight correct answer, 10 on the third, and so on. A flawless game is worth 325."
        ]
      },
      {
        heading: "Why slam count ties still score",
        items: [
          "Ties are common with slam counts and score as correct for either pick."
        ]
      },
      {
        heading: "Hard mode's close matchups",
        items: [
          "Hard mode, Unlimited only, serves up deliberately close matchups."
        ]
      },
      {
        heading: "The daily flip at midnight Eastern",
        items: [
          "The daily flips at midnight Eastern and your progress holds for the day."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Serena Williams edges Roger Federer",
        paragraphs: [
          "Round one: Serena Williams against Roger Federer. Two icons, one number each, 23 against 20. Serena takes it."
        ]
      },
      {
        heading: "Evert and Navratilova end in a tie",
        paragraphs: [
          "Later you draw Chris Evert against Martina Navratilova and freeze. Then you remember it doesn't matter: both won 18, and a tie pays either way."
        ]
      },
      {
        heading: "One miss on an old timer costs a perfect run",
        paragraphs: [
          "You finish 9 of 10 with one bad miss on an old-timer, a reminder that the early greats in this pool won a lot."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Learning the slam count clusters",
        items: [
          "Learn the tie clusters: 24, 22, 18 and 8 all have multiple owners."
        ]
      },
      {
        heading: "Respecting the sport's early legends",
        items: [
          "Respect the ancients. Margaret Court's 24 and Helen Wills' 19 outrank almost everyone modern."
        ]
      },
      {
        heading: "Reading the year range as an era anchor",
        items: [
          "The year range on the card is your era anchor. A long title window usually means a big count."
        ]
      }
    ],
    faqs: [
      {
        q: "Are men and women really compared head to head?",
        a: "Yes. The axis is total Grand Slam singles titles, so Serena against Federer is a fair and intended matchup."
      },
      {
        q: "How current are the title counts?",
        a: "They're locked in through the 2026 Australian Open, so results after that may not be reflected yet."
      }
    ]
  },
  "/guess-the-golfer": {
    intro: [
      "One major champion is hiding behind six clues, and the first is already on the table: the years they were winning majors. From there it's on you.",
      "Wrong guesses unlock the rest in a fixed order: nationality, career major count, which of the four majors they won, initials, then first name. Scoring rewards the brave: a first-clue solve pays 600, and every extra clue costs 100."
    ],
    headings: {
      howToPlay: "How to play Guess The Golfer, a free major champion guessing game",
      rules: "Guess The Golfer rules for guesses, scoring and the pool",
      example: "Guess The Golfer walkthrough: Gary Player and South Africa",
      tips: "Guess The Golfer tips for year spans and nationality clues",
      faq: "Guess The Golfer FAQ: women's champions and old timers"
    },
    howToPlaySections: [
      {
        heading: "Picking Daily or Unlimited champions",
        items: [
          "Pick Daily, the same golfer for everyone, or Unlimited for a fresh champion every round."
        ]
      },
      {
        heading: "Studying the opening year span clue",
        items: [
          "Study the opening clue: the span between their first and last major win."
        ]
      },
      {
        heading: "Typing letters to see name suggestions",
        items: [
          "Type at least two letters to see name suggestions, then tap one to guess."
        ],
        subsections: [
          {
            heading: "How every miss unlocks the next clue",
            items: [
              "Every miss unlocks the next clue in the sequence."
            ]
          }
        ]
      },
      {
        heading: "Solving before the sixth wrong guess",
        items: [
          "Solve it before your sixth wrong guess or the round ends."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Six wrong guesses ends the round",
        items: [
          "Six wrong guesses end the round."
        ]
      },
      {
        heading: "Scoring from 600 down to 100",
        items: [
          "Score starts at 600 for a first-clue solve and drops 100 per extra clue, bottoming out at 100."
        ]
      },
      {
        heading: "The 55 golfer answer pool",
        items: [
          "Answers come from a famous 55-golfer slice: champions with 4 or more majors from any era, plus anyone who won a major in 1980 or later."
        ]
      },
      {
        heading: "A wider 61 champion search list",
        items: [
          "The search list is wider, covering all 61 men's champions with at least 2 career majors."
        ]
      },
      {
        heading: "The daily golfer and the midnight reset",
        items: [
          "The daily golfer resets at midnight Eastern, and your progress is saved for the day."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Missing on Arnold Palmer's year span",
        paragraphs: [
          "Say the first clue reads: won majors between 1959 and 1978. That's a long reign, so you gamble on Arnold Palmer. Miss; his wins sit between 1958 and 1964."
        ]
      },
      {
        heading: "Gary Player confirmed for 500 points",
        paragraphs: [
          "Clue two says South Africa, and the long window suddenly makes sense. Gary Player, nine majors across two decades. You take 500 points on clue two."
        ]
      },
      {
        heading: "Trading a 600 point flex for certainty",
        paragraphs: [
          "Calling the era cold would have been a 600-point flex, but 500 with certainty beats 0 with style."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Memorizing the marquee year spans",
        items: [
          "Memorize the marquee year spans: 1962 to 1986 is Nicklaus, 1997 to 2019 is Tiger."
        ]
      },
      {
        heading: "How nationality slices the pool",
        items: [
          "Any nationality that isn't United States slices the pool down to a handful of names."
        ]
      },
      {
        heading: "Spending wrong guesses on real hypotheses",
        items: [
          "Wrong guesses are your only currency, so spend them on real hypotheses, not shrugs."
        ]
      },
      {
        heading: "Why the initials clue is a gift",
        items: [
          "If you're still alive at the initials clue, the answer is basically gift wrapped. Never lose from there."
        ]
      }
    ],
    faqs: [
      {
        q: "Are women's major champions in the pool?",
        a: "Not currently. The game draws from men's major champions with at least two career majors."
      },
      {
        q: "Can an old-timer still show up?",
        a: "Yes. Anyone with four or more majors qualifies whatever their era, so a Harry Vardon day is possible."
      }
    ]
  },
  "/golf-higher-lower": {
    intro: [
      "Golf's major-count arguments, settled 10 rounds at a time. Two champions appear side by side and you pick the one with more career majors.",
      "The pool runs the entire history of championship golf: 61 players, everyone with at least 2 majors, from Old Tom Morris in the 1860s to Scottie Scheffler."
    ],
    headings: {
      howToPlay: "How to play Golf Higher or Lower, a daily major championship trivia game",
      rules: "Golf Higher or Lower rules for rounds, ties and streak bonuses",
      example: "Golf Higher or Lower walkthrough: Nicklaus, Woods and Hagen",
      tips: "Golf Higher or Lower tips for reading eras and win years",
      faq: "Golf Higher or Lower FAQ: the four majors and Hard mode"
    },
    howToPlaySections: [
      {
        heading: "Choosing Daily or Unlimited pairs",
        items: [
          "Choose Daily for the shared matchups or Unlimited for random pairs."
        ]
      },
      {
        heading: "Reading each golfer's country and win years",
        items: [
          "Each card shows the golfer's country and the years of their first and last major win."
        ]
      },
      {
        heading: "Tapping the golfer with more majors",
        items: [
          "Tap the golfer you believe won more majors."
        ]
      },
      {
        heading: "Watching the real counts reveal",
        items: [
          "The real counts reveal, points land, and the next pair appears."
        ],
        subsections: [
          {
            heading: "Stacking correct picks for streak bonuses",
            items: [
              "Stack correct answers for streak bonuses."
            ]
          }
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Ten rounds and a growing streak bonus",
        items: [
          "10 rounds, 10 points per correct answer, plus a streak bonus growing by 5 with each straight correct after the first. A perfect game is 325."
        ]
      },
      {
        heading: "Why exact ties always score",
        items: [
          "Exact ties score as correct on either side."
        ]
      },
      {
        heading: "Hard mode's close major counts",
        items: [
          "Hard mode lives in Unlimited only and pairs golfers with close major counts."
        ]
      },
      {
        heading: "New matchups at midnight Eastern",
        items: [
          "New daily matchups arrive at midnight Eastern."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Nicklaus edges Tiger Woods",
        paragraphs: [
          "Round one gives you Jack Nicklaus against Tiger Woods, the two biggest names in the sport, and the counts land 18 to 15 for Jack."
        ]
      },
      {
        heading: "Hagen's majors dwarf Mickelson's",
        paragraphs: [
          "Later it's Walter Hagen against Phil Mickelson. Recency pulls you toward Phil, but Hagen's 11 majors dwarf Phil's 6. That's the trap this game sets over and over."
        ]
      },
      {
        heading: "Trusting eras over instinct to close 7 of 10",
        paragraphs: [
          "You stop trusting instinct, start trusting eras, and grind out 7 of 10."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Memorizing the podium of major counts",
        items: [
          "Memorize the podium: Nicklaus 18, Woods 15, Hagen 11."
        ]
      },
      {
        heading: "Trusting old champions over modern ones",
        items: [
          "Early century champions stack majors quietly. When in doubt between eras, old often beats modern."
        ]
      },
      {
        heading: "Spotting the bigger legend in a crowded club",
        items: [
          "The two-major club is crowded and coin-flip rounds happen. Use the win years on the card to spot the bigger legend."
        ]
      },
      {
        heading: "Treating ties as free points",
        items: [
          "Ties pay both ways, so identical-feeling pairs are free points, not landmines."
        ]
      }
    ],
    faqs: [
      {
        q: "Which tournaments count as majors here?",
        a: "Career wins across the four men's majors: the Masters, the PGA Championship, The Open and the U.S. Open."
      },
      {
        q: "Is Hard mode scored differently?",
        a: "No, same rounds and points. It only changes the matchups, pairing golfers with nearly equal counts."
      }
    ]
  },
  "/afl-higher-lower": {
    intro: [
      "Footy's goal kicking arguments, settled 10 rounds at a time. Two VFL/AFL greats appear side by side and you pick the one who kicked more career goals.",
      "The pool is 60 retired legends, everyone from Gordon Coventry in the 1920s to Buddy Franklin, and only retired players make the list so no total ever moves under you."
    ],
    headings: {
      howToPlay: "How to play AFL Higher or Lower, a free footy goal kicking trivia game",
      rules: "AFL Higher or Lower rules for rounds, streaks and hard mode",
      example: "AFL Higher or Lower walkthrough: Lockett, Coventry and career totals",
      tips: "AFL Higher or Lower tips for picking the higher goal kicker",
      faq: "AFL Higher or Lower FAQ: goal totals and the retired player pool"
    },
    howToPlaySections: [
      {
        heading: "Choosing Daily or Unlimited mode",
        items: ["Choose Daily for the shared matchups or Unlimited for random pairs."]
      },
      {
        heading: "Reading each player's card",
        items: ["Each card shows the player's clubs and the years of their career."]
      },
      {
        heading: "Picking the higher career goal kicker",
        items: [
          "Tap the player you believe kicked more career goals.",
          "The real counts reveal, points land, and the next pair appears."
        ]
      },
      {
        heading: "Stacking a streak bonus",
        items: ["Stack correct answers for streak bonuses."]
      }
    ],
    ruleSections: [
      {
        heading: "Scoring ten rounds and a growing streak bonus",
        items: ["10 rounds, 10 points per correct answer, plus a streak bonus growing by 5 with each straight correct after the first. A perfect game is 325."]
      },
      {
        heading: "How exact ties score",
        items: ["Exact ties score as correct on either side, and this pool has real ones: Wayne Carey and Peter Hudson both finished on 727."]
      },
      {
        heading: "Hard mode in Unlimited",
        items: ["Hard mode lives in Unlimited only and pairs players with close goal counts."]
      },
      {
        heading: "New matchups at midnight",
        items: ["New daily matchups arrive at midnight Eastern."]
      }
    ],
    exampleSections: [
      {
        heading: "Tony Lockett against Matthew Lloyd",
        paragraphs: ["Round one gives you Tony Lockett against Matthew Lloyd, and the counts land 1,360 to 926 for Plugger, the only man in history past 1,300."]
      },
      {
        heading: "Gordon Coventry against Jack Riewoldt",
        paragraphs: ["Later it's Gordon Coventry against Jack Riewoldt. Recency pulls you toward Jack, but Coventry kicked 1,299 before World War Two. That's the trap this game sets over and over."]
      },
      {
        heading: "Trusting eras over recency",
        paragraphs: ["You stop trusting recency, start trusting eras, and grind out 7 of 10."]
      }
    ],
    tipSections: [
      {
        heading: "Memorizing the career goal podium",
        items: ["Memorize the podium: Lockett 1,360, Coventry 1,299, Dunstall 1,254."],
        subsections: [
          {
            heading: "The exclusive 1,000 goal club",
            items: ["Only five men have ever kicked 1,000: those three plus Doug Wade and Gary Ablett Sr, with Buddy Franklin's 1,066 among them."]
          }
        ]
      },
      {
        heading: "Weighing eras against each other",
        items: ["Full forwards from the high scoring 80s stack huge numbers. A key forward from the 2010s on the same games usually sits lower."]
      },
      {
        heading: "Trusting ties as free points",
        items: ["Ties pay both ways, so identical-feeling pairs are free points, not landmines."]
      }
    ],
    faqs: [
      {
        q: "Where do the goal totals come from?",
        a: "Career VFL/AFL regular season and finals goals as carried by the all time leading goalkicker records, cross-checked before shipping. Only retired players are included so the numbers are final."
      },
      {
        q: "Why is a current star not in the pool?",
        a: "Active players are left out on purpose. Their totals move every week, and this site does not ship numbers that quietly go wrong."
      }
    ]
  },
  "/guess-nascar-driver": {
    intro: [
      "There's a Cup Series driver on the other side of the screen, and you get six clues to figure out who. It could be a modern playoff regular or a legend from the golden eras of stock car racing.",
      "Clues unlock in a fixed order and get more specific as they go: the years the driver was winning, how many championships they took, what they were driving in a title year, and then three actual races they won, named and dated."
    ],
    headings: {
      howToPlay: "How to play Guess The Driver, a free daily NASCAR trivia game",
      rules: "Guess The Driver rules for clues, scoring and the pool",
      example: "Guess The Driver walkthrough: eras, titles and Richard Petty",
      tips: "Guess The Driver tips for narrowing down a Cup Series legend",
      faq: "Guess The Driver FAQ: clues, the driver pool and giving up"
    },
    howToPlaySections: [
      {
        heading: "Choosing Daily or Unlimited to begin",
        items: ["Pick Daily Challenge to chase the same driver as everyone else, or Unlimited to keep the puzzles coming."]
      },
      {
        heading: "Reading the opening era clue",
        items: ["Read the era clue first and guess whenever conviction strikes."]
      },
      {
        heading: "Guessing wrong reveals the next clue",
        items: ["Every wrong guess reveals the next clue automatically."]
      },
      {
        heading: "Using a hint without losing your guess",
        items: ["Hints unlock the next clue without spending a guess, though the score tier drops the same either way."]
      },
      {
        heading: "Picking a name from the suggestion list",
        items: ["Pick a name from the suggestion list to submit your guess."]
      }
    ],
    ruleSections: [
      {
        heading: "Scoring by which clue you solve on",
        items: ["6 clues per driver, scored 1000, 800, 600, 400, 200 and 100 by the clue you solve on."]
      },
      {
        heading: "What ends a round on the last clue",
        items: ["A wrong guess while clue six is showing ends the round."]
      },
      {
        heading: "Giving up and scoring zero",
        items: ["Give Up reveals the driver and scores 0."]
      },
      {
        heading: "Daily and Unlimited sharing one pool",
        items: ["Daily and Unlimited both pull from the same 59 driver pool."]
      },
      {
        heading: "Every clue built from a real result",
        items: ['Every clue is a fact from a real race result or a real championship season. Nothing about a driver is invented, and where our race records are thin the clue says "on record" instead of claiming a career total.']
      }
    ],
    exampleSections: [
      {
        heading: "Landing in the sport's second golden era",
        paragraphs: ["Clue one says the driver has race wins on record between 1970 and 1984, so you are in the sport's second golden era and you hold your fire."]
      },
      {
        heading: "Narrowing it down on championships",
        paragraphs: ["Clue two says seven Cup Series championships. Only three drivers in history have seven, and one of them raced far later, so you are down to two."]
      },
      {
        heading: "Settling it on the manufacturer",
        paragraphs: ["Clue three says a title year came driving a Plymouth, which settles it: Richard Petty, guessed on clue three for 600 points. The 1973 Daytona 500 was waiting in clue four, and you didn't need it."]
      }
    ],
    tipSections: [
      {
        heading: "Letting championship counts narrow the field",
        items: ["Championship counts cluster at the top, so seven titles narrows it to a very short list before you have seen a single race."]
      },
      {
        heading: "Using the era clue to split generations",
        items: ["The era clue splits the generations cleanly. Use it to rule out most of the field before the race names arrive."]
      },
      {
        heading: "Reading the manufacturer for the decade",
        items: ["The manufacturer in a title year dates a driver closely: Plymouth and Oldsmobile belong to one era, Toyota to another."],
        subsections: [
          {
            heading: "Letting a named race close it out",
            items: ["The named races are the giveaway. If you know who won a particular Daytona 500 or Southern 500, the round is over on that clue."]
          }
        ]
      },
      {
        heading: "Letting the list jog a stuck memory",
        items: ["If a name is stuck on the tip of your tongue, scroll the suggestion list; seeing it usually unlocks it."]
      }
    ],
    faqs: [
      {
        q: "Do I have to type the exact full name?",
        a: "Start typing and pick from the suggestion list, which submits the full name for you. Typing it yourself works too, and a suffix like Jr is optional."
      },
      {
        q: "Where do the clues come from?",
        a: "Real race results and the full list of Cup Series champions, both held in our own database. A clue never totals up a career, because our race records have gaps in the early decades and mix in exhibition races, so each one names a single race in a single year instead."
      },
      {
        q: "Why isn't every famous driver in here?",
        a: "A driver only makes the pool if our records hold enough real wins to build six honest clues, which is 59 of them today. Padding the rest out with made up detail would be worse than leaving them out."
      },
      {
        q: "What happens if I give up?",
        a: "The driver is revealed and the round scores 0. In Unlimited you can start another one right away."
      }
    ]
  },
  "/nascar-chain": {
    intro: [
      "Winning a Cup championship means somebody else didn't. NASCAR Chain runs on that: you get a driver, and you name someone who beat them to a Cup Series title. Then someone who beat that driver to one, and on and on.",
      "It's a memory test of championship seasons more than raw trivia, and one wrong link ends the whole run."
    ],
    headings: {
      howToPlay: "How to play NASCAR Chain, a free Cup Series championship game",
      rules: "NASCAR Chain rules for links, badges and scoring",
      example: "NASCAR Chain walkthrough: Earnhardt Jr. to a broken run",
      tips: "NASCAR Chain tips for remembering championship seasons",
      faq: "NASCAR Chain FAQ: verified links, badges and the leaderboard"
    },
    howToPlaySections: [
      {
        heading: "Choosing Daily or Unlimited to start",
        items: ["Choose Daily Challenge, same starting driver for everyone, or Unlimited for a random start."]
      },
      {
        heading: "Thinking of a driver who beat the champion",
        items: ["Think of a champion who won the Cup while your current driver was chasing it."]
      },
      {
        heading: "Searching a name for the game to verify",
        items: ["Search the name; the game verifies the connection before it counts."],
        subsections: [
          {
            heading: "What happens once a link is verified",
            items: ["Each verified answer joins the chain and becomes your new current driver."]
          }
        ]
      },
      {
        heading: "Saving your score with a nickname",
        items: ["Run it as far as you can, then save your score with a nickname to hit the top 10 board."]
      }
    ],
    ruleSections: [
      {
        heading: "Scoring points with chain multipliers",
        items: ["Each verified link is worth 100 points, with your total multiplied by 1.5 at a chain of 5 and by 2 at 10."]
      },
      {
        heading: "What instantly ends a run",
        items: ["Repeating a driver already in the chain ends the run instantly, and so does a wrong answer."]
      },
      {
        heading: "Earning badges along the chain",
        items: ["Badges: Pit Crew at 3 links, Cup Contender at 5, NASCAR Legend at 10."]
      },
      {
        heading: "Connection problems asking for a retry",
        items: ["Connection problems never kill a run; unverified answers just ask for a retry."]
      }
    ],
    exampleSections: [
      {
        heading: "Starting from Dale Earnhardt Jr.",
        paragraphs: ["Suppose you start on Dale Earnhardt Jr., a superstar who never lifted the Cup. Plenty of drivers beat him to titles, so you open with Jimmie Johnson. Verified, link one."]
      },
      {
        heading: "Chaining through Kyle Busch and Joey Logano",
        paragraphs: ["From Johnson you name Kyle Busch, the 2015 champion. Link two. From Busch you go Joey Logano, the 2018 title. Link three, 300 points, Pit Crew badge."]
      },
      {
        heading: "Blanking on an older era",
        paragraphs: ["Then you blank on the older eras, gamble, and it's over at 300. Steer toward seasons you actually remember."]
      }
    ],
    tipSections: [
      {
        heading: "Anchoring on a championship season",
        items: ["Anchor on seasons. Picture the champion celebrating and who finished behind them."]
      },
      {
        heading: "Steering into the playoff era",
        items: ["The playoff era is fresh memory for most fans, so steer chains toward the 2000s and 2010s."]
      },
      {
        heading: "Saving a rare driver for later",
        items: ["Every driver is single use, so don't spend an obvious champion early if a rarer name also works."]
      },
      {
        heading: "Placing the season before you type",
        items: ["No clock runs, so place the season before you type."]
      }
    ],
    faqs: [
      {
        q: "What counts as beating someone to the title?",
        a: "Winning the Cup championship in a season your current driver competed in. Season rivals, not fender to fender finishes."
      },
      {
        q: "Do I need an account to post a score?",
        a: "No. The leaderboard just asks for a nickname after your run ends."
      },
      {
        q: "My answer wouldn't verify. Is my chain dead?",
        a: "No. A connection problem just means retry; nothing is lost."
      }
    ]
  },
  "/fight-promoter": {
    intro: [
      "Fight Promoter is a free MMA and boxing management sim. Run a fictional MMA organization with contracts, division rankings and championship belts, or play the original boxing matchmaking game. Each mode has its own save.",
      "In MMA mode, open Bout recap on an event result or a saved event from History. Read both fighters' actual landed strikes, takedowns, ground control, submission attempts and round points, then select a played round for its details. Ground control uses this simulation's recorded units, with 20 per takedown. Early finishes end the bout; round points decide fights that reach the final bell. Back returns to the same event without changing the save.",
      "In boxing mode, there are two ways to fill a room and they pull against each other. Put a known fighter in with somebody who cannot live with him and the house is full on the name, the fight is over early and nobody remembers it. Make the fight people actually want and it costs you both purses, and half the time your biggest draw walks out beaten and worth far less next time.",
      "In boxing mode, the money says feed him and your name says make the fight. Measured in that engine, a mismatch takes about 13 percent more at the door tonight and costs you six points of reputation across a career. Every fighter in both modes is invented."
    ],
    headings: {
      howToPlay: "How to play Fight Promoter, MMA and boxing management",
      rules: "Fight Promoter rules for contracts, belts and purses",
      example: "Fight Promoter walkthroughs for MMA and boxing events",
      tips: "Fight Promoter tips for pricing tickets and protecting your draw",
      faq: "Fight Promoter FAQ: fighters, purses and your promotion's name"
    },
    howToPlaySections: [
      {
        heading: "Running your MMA organization",
        items: [
          "Choose MMA and name your promotion. You start with $120,000, twelve signed fighters and three divisions. Every fighter and result is fictional.",
          "MMA: Open Fighters to sign free agents or renew a contract with one fight left. Contracts cover three appearances; the signing bonus and each appearance's purse are separate costs.",
          "MMA: Open Book card, choose a venue and ticket price, then choose two healthy contracted fighters in the same division. Add up to three bouts; each fighter appears only once per card.",
          "MMA: Read the estimated gate, purses and venue cost before running the event. The receipt keeps the actual winners, methods, rounds and financial totals for later review."
        ]
      },
      {
        heading: "Naming your promotion",
        items: ["Boxing: Name the promotion. You start with 0.12m, a name worth 5 out of 100 and ten fighters who will take your calls."]
      },
      {
        heading: "Picking a room for the show",
        items: ["Boxing: Pick a room. Six of them, from a 1,200 seat leisure centre up to a 78,000 seat national stadium, and each one wants a bigger name before it will have you."],
        subsections: [
          {
            heading: "Setting the ticket price",
            items: ["Boxing: Set the ticket price. Too high and you have paid for an empty room, too low and you have given the night away."]
          }
        ]
      },
      {
        heading: "Building the card at matching weights",
        items: ["Boxing: Build the card: pick a fighter, then pick who goes in with him. Both have to make the same weight."]
      },
      {
        heading: "Weighing the appeal before committing",
        items: ["Boxing: Read the appeal number before you commit. Names sell tickets and a fight nobody can call sells tickets, and they are rarely the same match."]
      },
      {
        heading: "Reading the room after the show",
        items: ["Boxing: Put the show on, then read the room. A one sided beating earns you nothing at all."]
      }
    ],
    ruleSections: [
      {
        heading: "MMA recovery, rankings and championship belts",
        items: [
          "MMA regular bouts run up to three rounds, and title bouts up to five. Striking and grappling produce knockouts, submissions or decisions in the seeded fight engine.",
          "MMA: A title fight needs two of your signed division's top four. An existing champion must participate; a champion whose contract expires leaves a vacant belt.",
          "MMA: Fighting uses one contract appearance and adds recovery time. Resting a month advances recovery and costs $2,000. You can rotate fighters while the last card recovers.",
          "MMA: The promotion finishes after twelve events. Your score out of 100 combines reputation (50 points), profitable events (30) and held belts (20). You can also close after an event and take the score you have earned."
        ]
      },
      {
        heading: "Paying purses and covering the room",
        items: [
          "Boxing: Fighters take the greater of their guarantee or 58 percent of the door, so a big night is never a windfall and a room that does not fill still owes the guarantee.",
          "Boxing: The room costs its hire fee whether anybody turns up or not."
        ]
      },
      {
        heading: "Growing your name on bigger buildings",
        items: [
          "Boxing: Your name is what opens bigger buildings: 12 for the town hall, 26 for the ballroom, 45 for the arena, 68 for the dome and 86 for the stadium.",
          "Boxing: Your name grows on the quality of the fights and nothing else. A full house watching a mismatch is worth almost nothing."
        ],
        subsections: [
          {
            heading: "Judging quality by how close a fight was",
            items: ["Boxing: Quality is judged mostly on how close the fight was, counted in rounds won. A knockout in a one sided fight does not rescue it."]
          }
        ]
      },
      {
        heading: "Protecting a record and losing your card",
        items: [
          "Boxing: A loss costs a fighter far more drawing power than a win builds. That is why protecting a record is tempting.",
          "Boxing: Fighters leave a promotion nobody rates, and they take the top of your card with them. A promotion people want to be on replaces its weakest name with somebody better."
        ]
      },
      {
        heading: "Retirement, going broke and no betting",
        items: [
          "Boxing: Nobody fights forever. They leave at 82 damage or at 39, and nobody carrying 80 damage gets matched at all.",
          "Boxing: Go below zero after a show and you are out of the business.",
          "There is no betting anywhere in this game."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Booking a vacant MMA title",
        paragraphs: ["MMA: Choose two healthy contracted light division fighters from the top four and mark the bout as a title fight. The winner takes the belt, both use a contract appearance, and their recovery can prevent an immediate rematch. Check the saved receipt, then sign another contender or rest before the next card."]
      },
      {
        heading: "Filling a leisure centre on a name",
        paragraphs: ["Boxing: Show one is a leisure centre. You put your best man in with a journeyman, the room is two thirds full on his name, and you clear a few thousand. Your name moves almost nothing."]
      },
      {
        heading: "Making the fight instead of feeding him",
        paragraphs: ["Boxing: Four shows later you are still in the leisure centre, because feeding him has not earned you a booking anywhere bigger. So you make the fight: your draw against the best man at his weight."]
      },
      {
        heading: "A close loss that grows your name",
        paragraphs: ["Boxing: He loses a close one. His drawing power halves overnight and the next card is worth less. But the fight was the best thing anyone in that room had seen, your name jumps, and the town hall takes your call."]
      },
      {
        heading: "Reaching the arena twenty shows on",
        paragraphs: ["Boxing: Twenty shows on you are in the arena with fighters who would not have returned your calls at the start, and you are making the same decision again with more money on it."]
      }
    ],
    tipSections: [
      {
        heading: "Feeding somebody in the early shows",
        items: ["Boxing: Early on you have to feed somebody, because you cannot afford a real fight and a bad night closes you."]
      },
      {
        heading: "Watching the projected house move",
        items: ["Boxing: The ticket price has a best answer and it is not the highest one. Watch the projected house move as you drag it."]
      },
      {
        heading: "Matching close fighters and spending your draw",
        items: [
          "Boxing: Two men at the same weight with ratings within about ten points is the fight worth making.",
          "Boxing: Your draw is an asset with a record attached. Spend it deliberately, not by accident."
        ]
      },
      {
        heading: "Why a damaged veteran still sells",
        items: ["Boxing: A damaged veteran still sells. That is exactly why he is still on your books."]
      }
    ],
    faqs: [
      { q: "Can I run an MMA organization?", a: "Yes. Choose MMA to sign fighters, build three bout cards, run division title fights and manage the business across twelve events. Boxing has its own separate save." },
      { q: "Are there submissions in MMA mode?", a: "Yes. Grappling creates takedowns, control and submission attempts, while striking can produce a knockout. Saved results come from the fight engine." },
      { q: "Why did a sold out show still lose money?", a: "In boxing mode, the guarantees and the room. Fighters take the greater of their guarantee or 58 percent of the door, so a small house against big guarantees loses whatever the room looked like." },
      { q: "Why is my name not growing?", a: "In boxing mode, your name grows on the quality of the fights, judged mostly on how close they were. If you are feeding your draw soft opponents, you are selling tickets and building nothing." },
      { q: "Where did my best fighter go?", a: "In boxing mode, he left for somebody bigger. Fighters walk out on a promotion nobody rates, and the better he is, the more likely he is the one who goes." },
      { q: "Are the fighters real?", a: "No. Every fighter is generated. No real boxer is matched, paid, beaten or promoted anywhere in this game, and no real venue is named." },
      { q: "Is this the same as Fight Career and Fight Gym?", a: "Boxing mode uses the same fighters and bouts from those games. MMA mode has its own generated roster, grappling engine, contracts and belts." }
    ]
  },
  "/fight-gym": {
    intro: [
      "Fight Gym is a free boxing management sim. You open a room with two young fighters nobody else wanted and enough money for a few weeks, and you decide what happens to everyone who walks through the door after that.",
      "It runs on the same fighters and the same fights as Fight Career, with one difference that changes everything: the damage lands on somebody else and the money lands on you. A hurt fighter still sells tickets. Nothing stops you putting him in again except what it does to him, and to your name.",
      "Every fighter in it is invented, including the champions and the kids the scout brings you."
    ],
    headings: {
      howToPlay: "How to play Fight Gym, a free boxing management sim",
      rules: "Fight Gym rules for reputation, damage and your roster",
      example: "Fight Gym walkthrough: from two teenagers to two world titles",
      tips: "Fight Gym tips for timing a fighter's exit",
      faq: "Fight Gym FAQ: reputation, retirement and betting"
    },
    howToPlaySections: [
      {
        heading: "Naming your gym",
        items: ["Name the gym. You start with 0.6m, two fighters and a name worth 8 out of 100."]
      },
      {
        heading: "Signing, training or booking each week",
        items: ["Each week you can sign somebody, put a fighter through a training block for 0.035m, or find one of them a fight."]
      },
      {
        heading: "Picking three offers and three looks",
        items: ["A fight comes with three offers. Pick the night, then pick three looks the same way you would in a career."],
        subsections: [
          {
            heading: "Taking your cut of every purse",
            items: ["You take between 20 and 35 percent of every purse. The better your name, the bigger the cut."]
          }
        ]
      },
      {
        heading: "Paying the weekly bills",
        items: ["The bills arrive every week: 0.012m plus 0.009m for each fighter on the books."]
      },
      {
        heading: "Letting a fighter go before the money runs out",
        items: [
          "Let a fighter go when you think he has had enough, or keep cashing him.",
          "Run out of money and the doors close for good."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Your name setting the whole economy",
        items: ["Your name is the whole economy. It sets your cut of a purse and it sets the quality of the fighters who walk in, which runs from about 38 at the bottom to about 72 at the top."]
      },
      {
        heading: "Building reputation slower than losing it",
        items: ["Reputation is hard to build and easy to lose. Gains shrink as you climb, losses do not."],
        subsections: [
          {
            heading: "Charging the decision, not the outcome",
            items: ["Putting a fighter in carrying 55 damage costs you reputation, and 70 costs you more, whatever the result. That is charged on the decision, not the outcome."]
          }
        ]
      },
      {
        heading: "The cost of letting a wrecked man go",
        items: ["Letting a wrecked man go costs you too. There is no clean exit from a fighter you ruined."]
      },
      {
        heading: "Damage that never heals",
        items: [
          "Damage never heals, and it takes a fighter's chin down fastest.",
          "A fighter is finished at 39, or at 34 if he is already carrying 58 damage, or at 82 damage whatever his age."
        ]
      },
      {
        heading: "A faded name, a roster cap and no betting",
        items: [
          "A fighter's purse reflects his record as well as his current form, so a faded name keeps earning long after he should have stopped. That is the trap the whole game is built around.",
          "You can carry at most six fighters.",
          "There is no betting anywhere in this game. Purses are contracts."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Week one with two teenagers",
        paragraphs: ["Week one you have two teenagers and 0.6m. You sign a third for 0.09m because the scout likes him, then start finding six rounders for all three."]
      },
      {
        heading: "Week forty and real prospects walking in",
        paragraphs: ["By week 40 your name is up near 40, the cut is better and real prospects are walking in. One of your out-boxers is ranked 6 and the purses have stopped being small."]
      },
      {
        heading: "Week seventy's costly decision",
        paragraphs: ["Week 70 and your best fighter is carrying 58 damage. He is also the biggest name you have, and the offer on the table is the best money the gym has ever seen. You take it, the crowd sees a hurt man get stopped, and your name drops further than the purse was worth."]
      },
      {
        heading: "Closing the gym at week 160",
        paragraphs: ["You close at week 160 with two world titles, eleven fighters through the door, three of whom got out clean and two who did not. The verdict says Respected, and you know exactly which night cost you Great."]
      }
    ],
    tipSections: [
      {
        heading: "Signing early before the bills arrive",
        items: ["Sign early. An empty gym has no way to earn and the bills do not wait."]
      },
      {
        heading: "Watching the damage number over the record",
        items: [
          "Watch the damage number harder than the record. It is the only thing you cannot undo.",
          "A training block is cheap next to a signing fee. Build the man you have before replacing him."
        ]
      },
      {
        heading: "The pay off that costs more than it earns",
        items: ["The temptation is real and it is measurable: keeping a hurt fighter genuinely pays better in the short run. It just costs you more than it pays."]
      },
      {
        heading: "Letting a man go before 70 damage",
        items: ["Let a man go at around 50 damage rather than 70. The reputation hit for releasing a wrecked fighter is far worse than the purses you gave up."]
      }
    ],
    faqs: [
      { q: "Is this the same game as Fight Career?", a: "Same fighters, same fights, opposite chair. In the career the damage is yours. Here it belongs to somebody who works for you, and you are the one deciding whether he goes out again." },
      { q: "Why did my name drop when I did not lose?", a: "Putting a visibly hurt fighter in costs reputation whatever happens. It is charged on the decision, because that is the part you control." },
      { q: "Can I keep a fighter forever?", a: "No. Everyone finishes, at 39, or at 34 carrying heavy damage, or at 82 damage whenever that arrives." },
      { q: "Are the fighters real?", a: "No. Every fighter, prospect and champion is generated. No real boxer is signed, trained, damaged or retired anywhere in this game." },
      { q: "Does the game have betting?", a: "No. There is no wagering of any kind. Your income is a cut of the purse." }
    ]
  },
  "/fight-career": {
    intro: [
      "Fight Career is a free boxing career sim. You turn professional as a nobody, take one fight at a time, and try to be world champion before your body decides otherwise. Every fighter in it is invented, including the ones you beat, so nothing here is a real person's record being rewritten.",
      "The decision that runs the whole game is which fight you take. Three come in every time: a tune up that is safe and pays almost nothing, an even fight, and a step up that pays well, ranks you fast and can take years off the end of you. Damage never heals. It comes off your chin first, and it decides when you are finished.",
      "Then there is the night itself. Four styles beat each other in a circle, so there is always an answer to the man in front of you, and he adjusts to whatever you keep doing. Give him the same look three times and he will punish it.",
      "And then there is everything between fights. You pick a trainer and a manager when you turn pro, two cards land after every fight (a weight cut, a hand injury, a promoter wanting you exclusively, a move up a division), people text you, a rival in your own division climbs beside you, and whatever your corner leaves of the purse goes in the bank for the camp shop."
    ],
    headings: {
      howToPlay: "How to play Fight Career, a free boxing career sim",
      rules: "Fight Career rules for styles, damage and the ranking climb",
      example: "Fight Career walkthrough: an unranked welterweight to Modern Great",
      tips: "Fight Career tips for style matchups and managing damage",
      faq: "Fight Career FAQ: damage, title shots and betting"
    },
    howToPlaySections: [
      {
        heading: "Creating your fighter's weight class and style",
        items: ["Make your fighter: a name, one of 8 weight classes from flyweight to heavyweight, and one of 4 styles."]
      },
      {
        heading: "Picking a trainer and a manager",
        items: ["Pick a trainer and a manager. The trainer decides which camp weeks count for more and which for less, the manager decides how big your purses are and what he takes out of them. Each tile says its numbers."]
      },
      {
        heading: "Dealing with what happens between fights",
        items: ["After every fight, deal with what comes in before the next offers open: two cards, and sometimes a move by your rival. Every option says exactly what it does, and one on every card changes nothing that can reach a fight."]
      },
      {
        heading: "Reading the three fight offers",
        items: ["Read the three offers. Each one names the opponent, his style, the purse and how far a win moves you up the rankings."]
      },
      {
        heading: "Using the five tiles on the hub",
        items: ["Use the five tiles above the offers whenever you like: Inbox for texts from your corner and your family, Rival for his record and the feud, Bank and shop for camp upgrades, Corner for your trainer, manager, morale and fans, and Badges."]
      },
      {
        heading: "Spending six weeks of camp",
        items: ["Spend 6 weeks of camp across conditioning, power, defence and speed before every fight."]
      },
      {
        heading: "Picking three looks for fight night",
        items: ["Pick three looks for the night. They cycle through the rounds, so three different ones is a plan and one repeated is a gift."]
      },
      {
        heading: "Watching it live before the final verdict",
        items: ["Watch it round by round, or turn that off and take the decision straight away."],
        subsections: [
          {
            heading: "What ends a career and reads the verdict",
            items: ["Keep going until the damage, the years or a run of defeats ends it, then read the verdict on your career."]
          }
        ]
      }
    ],
    ruleSections: [
      {
        heading: "The circle of styles beating each other",
        items: ["Pressure beats an out-boxer, boxing beats a swarmer, countering beats a slugger, and brawling beats a counter-puncher. It closes into a circle, so no look is simply the best one."]
      },
      {
        heading: "An opponent who adjusts to your looks",
        items: ["Your opponent does not stand still. A fighter with real ring IQ will switch into whatever punishes the look you used last round, so repeating yourself is the worst thing you can do."]
      },
      {
        heading: "Damage that never heals",
        items: [
          "Damage is permanent and cumulative. It never heals, it takes your chin down fastest, and at 82 you are done whatever your age says.",
          "You are also finished at 41, or at 35 if you are already carrying 58 damage, or after three straight defeats once you have dropped out of the top 12."
        ]
      },
      {
        heading: "Camp growth against a hidden ceiling",
        items: ["Camp growth runs against a hidden ceiling. Every fighter has one, camp moves you toward it and never past it, and the closer you get the less each camp is worth."],
        subsections: [
          {
            heading: "Why padding a record stalls out",
            items: ["Beating a man well below your level does not move you once you are inside the top 10. Padding a record stalls on purpose."]
          }
        ]
      },
      {
        heading: "Reaching number one for a world title",
        items: [
          "Reach number one and every offer on the table is for a world title, whichever road got you there.",
          "A world champion is drawn from the top of the sport in absolute terms, not from a notch above you, so the belt does not get easier because you did.",
          "There is no betting anywhere in this game. Purses and offers are contracts, not wagers."
        ]
      },
      {
        heading: "The bank, the corner's share and the camp shop",
        items: [
          "Your trainer takes 10% of every purse and your manager takes his own share, 5% to 25% depending on who you hired. The rest goes in the bank. A card can put you on the tab, and the next purse pays it off first.",
          "The camp shop sells five upgrades with three levels each, at 0.05m, 0.25m and 1.00m: sparring partners, a strength coach, a conditioning coach, a pad man and a cut man. Coach bonuses are banked a fraction at a time and paid as whole points, and a camp still never takes you past your ceiling."
        ]
      },
      {
        heading: "Sharpness on fight night",
        items: ["Some cards make you sharper or flatter for the next fight only: each point is added to your power, speed, stamina and defence that night and gone the morning after. Sparring partners add a point a level, and every 10 morale above or below 50 is a point either way. Morale settles 2 back toward 50 after every fight, so a good mood has to be kept up, and karma kept at 70 or more hands 2 back each fight."]
      },
      {
        heading: "Your rival and the grudge match",
        items: ["Your rival is an invented fighter in your division who fights on while you do, wins belts, loses, and retires. When he calls you out and you take it, he replaces the middle offer as a grudge match paying 30% more, and a card that would move you a division or bring a rematch is dropped rather than throw that fight away."]
      },
      {
        heading: "Moving weight and the rematch clause",
        /* Knockouts rising with weight, two sources read 2026-10-02: Physician
           and Sportsmedicine 2024, PMID 37990916 (Europe PMC abstract), and
           scirp.org/journal/paperinformation?paperid=107460. */
        items: ["Moving up a division makes knockouts more likely, moving down makes them rarer, and either way you start the new division unranked and any belt stays behind. Your rival and the man who last beat you stay in the division you left. For 4 fights after a loss, a rematch clause can turn the middle offer into the man who beat you, and a win is worth up to 4 places, one more with the matchmaker."]
      }
    ],
    exampleSections: [
      {
        heading: "Starting as an unranked welterweight",
        paragraphs: ["You start as a 21 year old welterweight out-boxer, unranked, and take the tune up. The purse is small and the win moves you one place, but you come out of it almost unmarked."]
      },
      {
        heading: "Learning the circle at number eleven",
        paragraphs: ["Three even fights later you are ranked 11 and you have learned the circle: the swarmer in front of you gets boxed, and when he starts switching you give him something else instead of the same jab for ten rounds."]
      },
      {
        heading: "Two cards and a call out at number nine",
        paragraphs: ["After your ninth fight your rival goes first: he calls you out, you take it, and the middle offer becomes him at 30% more. Then two cards land. Four pounds over: hiring the nutritionist takes 0.02m from the bank, sweating it out leaves you 3 points flatter on the night, and coming in heavy cuts every purse on the table by 15% but leaves you 1 point sharper. You pay the nutritionist. The second card is the hometown hall, 5 more fans for 15% less money, and you stay on the road. With 0.31m in the bank you buy the cut man for 0.05m, and from now on you carry 4% less damage out of every fight."]
      },
      {
        heading: "Winning the title at number one",
        paragraphs: ["At number one you get three title offers. You take the middle one, put the champion down in the eighth, and win a decision you will feel for the rest of your life. Damage 44, and it is not coming back off."]
      },
      {
        heading: "Retiring a Modern Great",
        paragraphs: ["Four defences later you are 31 with 71 damage, the chin is gone and a challenger you would have beaten at 26 stops you in five. You retire with a title, four defences and a verdict that says Modern Great."]
      }
    ],
    tipSections: [
      {
        heading: "Taking the safe fights early",
        items: ["Take the safe fights early. You are trying to reach a title shot with a chin, not to prove something at 22."]
      },
      {
        heading: "Never repeating the same look twice",
        items: ["Never give the same look twice in a row against anyone who can think. Three different looks beat one good one."],
        subsections: [
          {
            heading: "Reading the damage bar over the record",
            items: ["Watch the damage bar more than the record. A 20-0 fighter carrying 70 damage is closer to the end than a 16-4 who stayed sharp."]
          }
        ]
      },
      {
        heading: "Spreading or piling your camp",
        items: ["Spread your camp when you need to last, and pile it into one area when you need an edge in a fight you should lose."]
      },
      {
        heading: "Why who you beat outweighs how many",
        items: ["Who you beat is worth far more than how many you beat. A long unbeaten run against nobody scores worse than a hard career against contenders."]
      }
    ],
    faqs: [
      { q: "Are the fighters real?", a: "No. Every fighter in the game is generated, including your opponents and the champions. No real boxer is simulated, ranked, aged or beaten anywhere in it." },
      { q: "Can I heal the damage?", a: "No, and that is the point of the game. Damage is permanent, it takes your chin first, and it is the price of every hard fight you took to get where you are." },
      { q: "Why will he not fight me for the title?", a: "Beating opponents well below your level stops moving you once you are in the top 10. You need real wins to reach number one, and once you are there every offer is for the belt." },
      { q: "Is there a daily?", a: "Yes. Fight Night is one three round bout per day, the same fighter and the same opponent for everybody, scored out of 100 on whether you won, how many rounds you took, whether you finished him, how little you took back and how well you read his style." },
      { q: "Does the game have betting?", a: "No. There is no wagering of any kind in it. The purse is what you are paid to fight." },
      { q: "Do the cards between fights change my fights?", a: "Only when the option says so. Every card shows what each answer does, and every card has one answer that changes nothing a fight can feel: pick that every time and your career runs exactly as it would have without the cards." },
      { q: "Who is my rival?", a: "An invented fighter in your own division, named from the same pool as every other boxer in the game. He has his own record, can win a belt before you, and retires when his time comes." }
    ]
  },
  "/ufc": {
    intro: [
      "You get eight guesses to name a mystery UFC fighter, and every guess talks back. Each attempt lights up a row of stats showing exactly how close you landed.",
      "Green means you matched the mystery fighter's stat, yellow means close, red means off target, and little arrows tell you whether the real number sits higher or lower. It's deduction, not luck."
    ],
    headings: {
      howToPlay: "How to play UFC Guesser, a free daily MMA guessing game",
      rules: "UFC Guesser rules for guesses, colors and the fighter pool",
      example: "UFC Guesser walkthrough: from Conor McGregor to Khabib Nurmagomedov",
      tips: "UFC Guesser tips for narrowing down a mystery fighter",
      faq: "UFC Guesser FAQ: stats, ages, the fighter pool and more"
    },
    howToPlaySections: [
      {
        heading: "Choosing Daily or Unlimited mode",
        items: ["Pick Daily for the fighter everyone is chasing today, or Unlimited for a random one each game."]
      },
      {
        heading: "Submitting your opening probe",
        items: ["Search any fighter and submit them as your opening probe."]
      },
      {
        heading: "Reading every stat in the row",
        items: ["Read the row: years active, weight class, nationality, age, wins, losses, draws, knockouts and submissions."]
      },
      {
        heading: "Following the arrows higher or lower",
        items: ["Follow the arrows on numeric stats to aim your next guess higher or lower."]
      },
      {
        heading: "Closing the net within eight guesses",
        items: ["Close the net within 8 guesses, or use Give Up to see the answer."]
      }
    ],
    ruleSections: [
      {
        heading: "Eight guesses in both modes",
        items: ["8 guesses maximum, in both Daily and Unlimited."]
      },
      {
        heading: "What a yellow, close call means",
        items: ["Yellow means close: one weight class off, same continent, within 2 years on age or career length, 3 wins, 2 losses, 1 draw, 3 knockouts or 2 submissions."]
      },
      {
        heading: "Saving progress until midnight",
        items: ["Daily progress is saved through the day and a new fighter arrives at midnight Eastern."]
      },
      {
        heading: "Spanning all nine weight divisions",
        items: ["The pool spans all nine weight divisions, strawweight to heavyweight, women's stars included."]
      }
    ],
    exampleSections: [
      {
        heading: "Opening with Conor McGregor",
        paragraphs: ["Suppose the mystery fighter is Khabib Nurmagomedov and you open with Conor McGregor. Weight class comes back green at lightweight, age and career length green, nationality yellow for the right continent, and the record cells glow red with arrows demanding more wins, fewer losses and more submissions."]
      },
      {
        heading: "Narrowing to a European lightweight",
        paragraphs: ["So you're hunting a European lightweight from McGregor's era with a spotless record and a pile of submissions."]
      },
      {
        heading: "Solving it as Khabib Nurmagomedov",
        paragraphs: ["An undefeated Russian grappler fits every cell. Khabib in two guesses."]
      }
    ],
    tipSections: [
      {
        heading: "Opening with a fighter you know well",
        items: ["Open with a fighter you know inside out so you can interpret every cell."],
        subsections: [
          {
            heading: "Using the weight class arrow as a filter",
            items: ["The weight class arrow is the fastest filter in the game; two guesses can pin the division."]
          }
        ]
      },
      {
        heading: "Reading a red loss cell pointing to zero",
        items: ["A red loss cell pointing down toward zero screams elite champion."]
      }
    ],
    faqs: [
      {
        q: "How is a fighter's age worked out?",
        a: "From their date of birth, on the day you play, so it is always their age today. Years active runs from their first UFC fight to their latest one."
      },
      {
        q: "Are women fighters in the pool?",
        a: "Yes. Amanda Nunes is in there, so don't assume the answer is a man."
      },
      {
        q: "If I close the tab mid-puzzle, do I lose my guesses?",
        a: "No. Progress is stored on your device for the day; the puzzle resets at midnight Eastern."
      }
    ]
  },
  "/ufc-chain": {
    intro: [
      "Fight fans keep receipts. Combat Chain is those receipts turned into a game: name a fighter who beat your current fighter, then a fighter who beat them, building the longest chain of real results you can.",
      "Wins are checked against the game's own record book, and one wrong answer ends the run. No timer, just you and the history of the sport."
    ],
    headings: {
      howToPlay: "How to play Combat Chain, a free MMA fight result game",
      rules: "Combat Chain rules for scoring, badges and Weight Class mode",
      example: "Combat Chain walkthrough: McGregor, Poirier and an unbeaten wall",
      tips: "Combat Chain tips for title fights and undefeated legends",
      faq: "Combat Chain FAQ: verified wins, modes and the leaderboard"
    },
    howToPlaySections: [
      {
        heading: "Picking a mode to start the chain",
        items: ["Pick a mode: Daily (same start for everyone), Unlimited, Weight Class (one division only), or Hall of Fame (legends only)."]
      },
      {
        heading: "Recalling who beat your current fighter",
        items: ["Recall who has actually beaten your current fighter."]
      },
      {
        heading: "Submitting a name for a verified defeat",
        items: ["Submit a name. A verified defeat adds the winner to your chain and hands them the spotlight."]
      },
      {
        heading: "Repeating until you miss or bank it",
        items: ["Repeat until you miss, reuse a fighter, or bank your score with Give Up."]
      },
      {
        heading: "Saving your run for the leaderboard",
        items: ["Save your run with a nickname to enter the top 10 leaderboard."]
      }
    ],
    ruleSections: [
      {
        heading: "Scoring points and a title fight bonus",
        items: ["Each correct link scores 100 points, plus a 50 point bonus when the win came in a championship fight."]
      },
      {
        heading: "Multiplying the total as the chain grows",
        items: ["The total multiplies by 1.5 at a chain of 5 and by 2 at 10."]
      },
      {
        heading: "What a wrong answer reveals",
        items: ["A wrong answer ends the run and reveals a fighter who would have worked."]
      },
      {
        heading: "Weight Class mode's eight divisions",
        items: ["Weight Class mode offers 8 divisions, flyweight through heavyweight."],
        subsections: [
          {
            heading: "Earning badges along the chain",
            items: ["Badges: On A Roll at 3 links, Contender at 5, Champion at 10, GOAT at 15."]
          }
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Starting on Conor McGregor",
        paragraphs: ["Say you start on Conor McGregor. Dustin Poirier stopped him in 2021, so that's a clean first link: 100 points."]
      },
      {
        heading: "Chaining to Khabib Nurmagomedov",
        paragraphs: ["Who beat Poirier? Khabib Nurmagomedov submitted him in a title fight, and championship wins pay extra: 150 more for 250 total."]
      },
      {
        heading: "Hitting an unbeaten legend's dead end",
        paragraphs: ["Now the problem: Khabib retired undefeated, so nobody in the book has beaten him. You cash out at 250. Chaining into an unbeaten legend is a beautiful dead end."]
      }
    ],
    tipSections: [
      {
        heading: "Preferring the championship answer",
        items: ["Title fight wins pay 50 extra, so prefer the championship answer when you have options."]
      },
      {
        heading: "Watching for an undefeated wall",
        items: ["Watch for undefeated walls. A fighter with zero losses ends your chain on the spot."]
      },
      {
        heading: "Saving a well connected name",
        items: ["Fighters are single use per run; don't burn a well connected name early."]
      }
    ],
    faqs: [
      {
        q: "My answer really did beat that fighter. Why didn't it count?",
        a: "The game checks its own built-in fight database, not the whole internet. A bout missing from the book won't verify even if it happened."
      },
      {
        q: "What's different about Hall of Fame mode?",
        a: "Your starter and every answer must be one of the game's flagged legends, so valid links get much scarcer."
      },
      {
        q: "How do I get on the leaderboard?",
        a: "Finish a run and enter a nickname. Chains rank by length, with score breaking ties."
      }
    ]
  }
};

// src/data/gameContent/world.ts
var WORLD_CONTENT = {
  "/rank-em": {
    intro: [
      "One stat, five players, one shot at the right order. Rank 'Em names a career stat, gives you five greats who sit near the top of it, and asks you to place them most to fewest.",
      "Every round is built from verified career totals in the site's database, with no ties anywhere. The order is the order.",
      "There's a daily ranking everyone shares, plus an unlimited mode."
    ],
    headings: {
      howToPlay: "How to play Rank 'Em, a free NBA, NHL and MLB stat ranking game",
      rules: "Rank 'Em rules for scoring, the daily round and unlimited mode",
      example: "Rank 'Em walkthrough: ranking five MLB home run kings",
      tips: "Rank 'Em tips for ordering five career stat leaders",
      faq: "Rank 'Em FAQ: stats, sports and scoring"
    },
    howToPlaySections: [
      {
        heading: "Reading the sport and stat in the header",
        items: [
          "Check the header for the sport and the stat, like NBA career assists or MLB career home runs."
        ]
      },
      {
        heading: "Tapping the five names most to fewest",
        items: [
          "Tap the five names in order, starting with the player you think has the most."
        ]
      },
      {
        heading: "Reviewing and editing your order",
        items: [
          "Changed your mind? Move a picked player up or down, remove a name, or use Undo last while you build your order."
        ]
      },
      {
        heading: "Locking your order of five players",
        items: [
          "Once all five players are in place, review the order and hit Lock order to submit it."
        ]
      },
      {
        heading: "Seeing the true order and the real numbers",
        items: [
          "The reveal shows the true order with each player's real career number beside it."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "One submission locks in the daily attempt",
        items: [
          "You get exactly 1 submission per round, so the daily is one attempt per day."
        ]
      },
      {
        heading: "Scoring extra points for a perfect board",
        items: [
          "Scoring is 200 points for each player in the exact right slot, 1,000 for a perfect 5 for 5."
        ]
      },
      {
        heading: "One daily round shared by everyone",
        items: [
          "The daily round is the same for everyone and flips at midnight Eastern Time."
        ],
        subsections: [
          {
            heading: "Switching to unlimited for random rounds",
            items: [
              "Unlimited mode deals random rounds from the same NBA, NHL and MLB pool."
            ]
          }
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Locking Bonds first and Mays fifth",
        paragraphs: [
          "Say the stat is MLB career home runs and the names are Barry Bonds, Hank Aaron, Babe Ruth, Albert Pujols and Willie Mays. Bonds at 762 feels safe on top, and Mays slots fifth at 660."
        ]
      },
      {
        heading: "Ruth and Aaron flipped in the middle",
        paragraphs: [
          "The middle is the trap. Aaron hit 755, Ruth 714 and Pujols 703, so flipping Ruth above Aaron costs you two slots and leaves you at 3 of 5 for 600 points."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Locking the first and fifth spots first",
        items: [
          "Lock in the two ends first. First and fifth are usually the spots you actually know."
        ]
      },
      {
        heading: "Valuing a long grinding career",
        items: [
          "Career totals reward longevity. A 20-year grinder often out-counts a shorter, brighter prime."
        ]
      },
      {
        heading: "Weighing era for three pointers and steals",
        items: [
          "Think era. Stats like three-pointers and stolen bases skew hard toward certain decades."
        ]
      },
      {
        heading: "Using undo since nothing locks in early",
        items: [
          "Edit freely before you hit Lock order. Adding your fifth player leaves the order open for review."
        ]
      }
    ],
    faqs: [
      {
        q: "Where do the numbers come from?",
        a: "Every ranking uses career totals from the site's stats database, and all five values are always distinct, so there is one clean right order."
      },
      {
        q: "Which sports show up?",
        a: "The NBA, NHL and MLB, with stats like points, assists, rebounds, blocks, goals, home runs, hits and stolen bases."
      },
      {
        q: "Is there partial credit?",
        a: "Yes. Each player placed in the exact right position earns 200 points, even if the rest of your board is chaos."
      }
    ]
  },
  "/teammates": {
    intro: [
      "Two names, one question: did these guys ever play for the same team? Teammates or Not flashes a pair of athletes from the NFL, NBA, MLB, NHL or soccer and you call it, yes or no. Club and league teams are what count here, so a national team or an All-Star game doesn't make two guys teammates.",
      "It sounds easy until you hit the pairs whose careers brushed past each other by a season. That one year in a strange uniform is exactly what this game lives on."
    ],
    headings: {
      howToPlay: "Teammates or Not? Here's how to play this NFL, NBA, MLB, NHL and soccer game",
      rules: "Teammates or Not? rules for rounds, scoring and difficulty",
      example: "Teammates or Not? walkthrough: Kobe and Shaq, Brady and Manning",
      tips: "Teammates or Not? tips for spotting real career overlaps",
      faq: "Teammates or Not? FAQ: sports covered and question pools"
    },
    howToPlaySections: [
      {
        heading: "Checking the two players and the sport badge",
        items: [
          "Look at the two players and the sport badge above them."
        ]
      },
      {
        heading: "Deciding if they shared a team ever",
        items: [
          "Decide whether they were ever on the same club or league team at any point in their careers. For the NFL, NBA, MLB and NHL pairs that means the same team in that league, and for soccer the same club. National teams, the Olympics, All-Star games, the Pro Bowl and college teams don't count."
        ]
      },
      {
        heading: "Tapping yes or no to lock it in",
        items: [
          "Tap YES or NO to lock in your answer."
        ]
      },
      {
        heading: "Reading the fun fact behind the pair",
        items: [
          "Read the fun fact that explains the real story behind the pair."
        ],
        subsections: [
          {
            heading: "Finishing all ten questions for your score",
            items: [
              "Hit Next Question and keep going until all 10 are done, then see your score."
            ]
          }
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Ten questions split easy, medium and hard",
        items: [
          "Each round is 10 questions: 3 easy, 3 medium and 4 hard, drawn fresh from a bigger pool."
        ]
      },
      {
        heading: "Scoring one point per correct call",
        items: [
          "Every correct call is worth 1 point, so a perfect round is 10 out of 10."
        ]
      },
      {
        heading: "Playing with no clock and a give up button",
        items: [
          "There's no timer, and a give up button ends the round early if you want out."
        ]
      },
      {
        heading: "Reshuffling a new set with play again",
        items: [
          "Play again reshuffles a brand new set of pairs, as many rounds as you like."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Kobe and Shaq, then Brady and Manning",
        paragraphs: [
          "Imagine the board serves up Kobe Bryant and Shaquille O'Neal. Easy yes, they won three straight titles together on the Lakers. Next comes Tom Brady and Peyton Manning. They defined a rivalry for years but never played for the same NFL team, so that's a no."
        ]
      },
      {
        heading: "The sneaky pairs about exact timing",
        paragraphs: [
          "The hard ones are sneakier, the pairs where you have to remember exactly when someone left. Get 9 or 10 and you really know your rosters."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Checking timelines over team rosters",
        items: [
          "Timelines beat team lists. Two legends at the same club in different decades were never teammates."
        ]
      },
      {
        heading: "Watching for weird late career moves",
        items: [
          "Remember the weird late-career moves. Stars finishing on random rosters create the best traps."
        ]
      },
      {
        heading: "Questioning an obvious no before tapping",
        items: [
          "Don't rush the obvious no. If a pair feels impossible, ask yourself why the game picked it."
        ]
      }
    ],
    faqs: [
      {
        q: "Are the questions the same every round?",
        a: "No. Each round pulls a fresh mix from the question pool, always 3 easy, 3 medium and 4 hard, so replays stay interesting."
      },
      {
        q: "Which sports are covered?",
        a: "Pairs come from the NFL, the NBA, MLB, the NHL and soccer, and each question shows a sport badge so you know which world you're in."
      },
      {
        q: "Do national teams or All-Star games count as teammates?",
        a: "No. Only club and league teams count. For an NFL, NBA, MLB or NHL pair that means the same team in that league, and for soccer the same club. Playing together for your country, at the Olympics, in an All-Star game or the Pro Bowl, or in college doesn't count here."
      },
      {
        q: "Is this a daily puzzle?",
        a: "No, it's endless. You can play as many 10-question rounds as you want, whenever you want."
      }
    ]
  },
  "/olympics": {
    intro: [
      "A mystery athlete from the Games is hiding behind a stack of clues, and your job is to name them before the clues run out. The Medal Games starts you with just their sport.",
      "Every clue you reveal makes the answer easier and your score smaller, so the game is a staring contest between confidence and greed.",
      "The pool covers Summer and Winter athletes, sprinters to figure skaters."
    ],
    headings: {
      howToPlay: "How to play The Medal Games, a free Olympics guessing game",
      rules: "The Medal Games rules for clues, scoring and daily mode",
      example: "The Medal Games walkthrough: swimming clues to Phelps",
      tips: "The Medal Games tips for reading clues before you guess",
      faq: "The Medal Games FAQ: clue order and Winter athletes"
    },
    howToPlaySections: [
      {
        heading: "Starting from the athlete's sport",
        items: [
          "Start with clue one, the athlete's sport, and see if a name jumps out."
        ]
      },
      {
        heading: "Typing a guess with name suggestions",
        items: [
          "Type a guess any time. Suggestions appear once you've typed a couple of letters, and last names count."
        ]
      },
      {
        heading: "Revealing country, year, host city and more",
        items: [
          "Stuck? Hit Next Clue to reveal country, then the Games year and host city, achievement, career context, medal haul, and finally the athlete's initials."
        ]
      },
      {
        heading: "Guessing again for free after a miss",
        items: [
          "Wrong guesses cost nothing, so fire away and guess again."
        ]
      },
      {
        heading: "Giving up to reveal the athlete",
        items: [
          "Give up if you're done, which reveals the athlete and scores zero."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Seven clue levels paying less each time",
        items: [
          "There are 7 clue levels. Solving on clue 1 scores 1,000, then 850, 700, 550, 400, 250 and 100."
        ]
      },
      {
        heading: "Only clues cost you points",
        items: [
          "Points only drop when you reveal clues. Wrong guesses are free retries."
        ],
        subsections: [
          {
            heading: "Giving up ending the run at zero",
            items: [
              "Giving up ends the run at 0 and shows the answer."
            ]
          }
        ]
      },
      {
        heading: "One daily athlete, unlimited after that",
        items: [
          "The daily athlete is the same for everyone, and unlimited mode deals random athletes forever."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Swimming, USA, then Beijing 2008",
        paragraphs: [
          "Suppose clue one says Swimming. That's a big pool, no pun intended, so you reveal the country: USA. Still wide. Clue three says the 2008 Games in Beijing, and now your brain is screaming one name."
        ]
      },
      {
        heading: "Typing Phelps for 700 points",
        paragraphs: [
          "You type Phelps, and last names count, so that's the win. Three clues used means 700 points."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Guessing early from sport and country",
        items: [
          "Sport plus country solves half the puzzles for big names, so always take a swing before clue three."
        ]
      },
      {
        heading: "Dating the athlete's peak from the host city",
        items: [
          "The Games year and host city date the athlete's peak. Work out the era before guessing blind."
        ]
      },
      {
        heading: "Trying every suspect since guesses are free",
        items: [
          "Because wrong guesses are free, list your suspects and try them all."
        ]
      },
      {
        heading: "Saving give up for a true dead end",
        items: [
          "Save give up for genuine dead ends. Even clue seven pays 100."
        ]
      }
    ],
    faqs: [
      {
        q: "Do wrong guesses lower my score?",
        a: "No. Your score only depends on how many clues you've revealed when you finally get it right. Guess as often as you like."
      },
      {
        q: "Does it include Winter Olympians?",
        a: "Yes. The athlete pool mixes Summer and Winter stars, so expect skiers, skaters and snowboarders alongside the sprinters and swimmers."
      },
      {
        q: "What's the difference between daily and unlimited?",
        a: "Daily gives everyone the same athlete. Unlimited serves random athletes back to back."
      }
    ]
  },
  "/guess-the-year": {
    intro: [
      "Six things happened across the sports world, all in the same year, and you have to figure out which year it was. Guess The Year opens with one clue and lets you climb from there.",
      "Each clue is a different sport, so a World Cup memory can rescue you when the hockey clue means nothing. The earlier you nail it, the bigger the score."
    ],
    headings: {
      howToPlay: "How to play Guess The Year, a free daily sports trivia game",
      rules: "Guess The Year rules for clues, scoring and the answer range",
      example: "Guess The Year walkthrough: McGwire and the 1998 World Cup",
      tips: "Guess The Year tips for narrowing the decade fast",
      faq: "Guess The Year FAQ: clue count and answer range"
    },
    howToPlaySections: [
      {
        heading: "Reading the first sports moment clue",
        items: [
          "Read the first clue describing a famous sports moment."
        ]
      },
      {
        heading: "Setting the year with single and double arrows",
        items: [
          "Set your year with the arrow buttons. Single arrows move 1 year, doubles jump 10."
        ]
      },
      {
        heading: "Hitting guess when you're ready",
        items: [
          "Hit the guess button when you're ready to commit."
        ]
      },
      {
        heading: "Unlocking the next clue on a wrong guess",
        items: [
          "A wrong guess automatically reveals the next clue, so every miss buys more information."
        ]
      },
      {
        heading: "Revealing a clue early or giving up",
        items: [
          "You can also reveal the next clue voluntarily, or give up to see the answer."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Six clues paying less with every reveal",
        items: [
          "There are 6 clues per puzzle. Solving on clue 1 scores 1,000 points, then 800, 600, 400, 200 and 100."
        ]
      },
      {
        heading: "Dropping a tier on every wrong guess",
        items: [
          "Every wrong guess reveals the next clue and drops you a scoring tier."
        ],
        subsections: [
          {
            heading: "Ending the run at zero after six misses",
            items: [
              "The run ends after 6 wrong guesses, or immediately if you give up, both scoring 0."
            ]
          }
        ]
      },
      {
        heading: "Answers between 1972 and 2026 daily",
        items: [
          "Answers range from 1972 to 2026, and a fresh puzzle arrives every day."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "A home run record and a home World Cup",
        paragraphs: [
          "Picture this: clue one says a first baseman shattered a 37-year-old single-season home run record. You're thinking late 90s, so you guess 1997. Wrong, and clue two reveals the host nation won the World Cup on home soil."
        ]
      },
      {
        heading: "Landing on 1998 on the second clue",
        paragraphs: [
          "France at home, McGwire chasing Maris. That's 1998, and getting it on the second clue banks 800 points. Miss again and the year would still be gettable, just cheaper."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Triangulating the decade across sports",
        items: [
          "Triangulate across sports. One clue narrows the decade, another pins the exact year."
        ]
      },
      {
        heading: "Jumping ten years before fine tuning",
        items: [
          "Use the 10-year jump buttons to get in the neighborhood before fine-tuning."
        ]
      },
      {
        heading: "Reading direction from a near miss guess",
        items: [
          "A near-miss guess isn't wasted. The clue it unlocks usually tells you which direction to move."
        ]
      },
      {
        heading: "Anchoring on sure World Cup and Olympic years",
        items: [
          "Anchor on world events you're sure of, like World Cups and Olympics, which only land in certain years."
        ]
      }
    ],
    faqs: [
      {
        q: "Are all six clues really from the same year?",
        a: "Yes. Every clue in a puzzle describes something from that one year, across the NFL, NBA, MLB, NHL, soccer, college sports and more."
      },
      {
        q: "What years can the answer be?",
        a: "Anywhere from 1972 to 2026. The picker won't let you guess outside that range."
      },
      {
        q: "Should I guess early or reveal clues first?",
        a: "Guess. A wrong guess reveals the next clue anyway, so a smart early swing costs the same as skipping and might land 1,000."
      }
    ]
  },
  "/guess-the-nation": {
    intro: [
      "Somewhere on the map is a country with a sporting story, and you're guessing it from the resume alone. Guess The Nation starts with a single vibe word and drips out clues until only one flag fits.",
      "It plays like a detective case: population, medal counts, famous moments, even flag colors. Early solves pay best."
    ],
    headings: {
      howToPlay: "How to play Guess The Nation, a free countries sports trivia game",
      rules: "Guess The Nation rules for clues, scoring and streaks",
      example: "Guess The Nation walkthrough: sprinting clues to Jamaica",
      tips: "Guess The Nation tips for reading the vibe word",
      faq: "Guess The Nation FAQ: clue order and difficulty modes"
    },
    howToPlaySections: [
      {
        heading: "Picking daily, unlimited or a continent filter",
        items: [
          "Pick a mode: Daily Challenge, Unlimited, Summer or Winter focus, or filter by continent."
        ]
      },
      {
        heading: "Choosing easy nations or the full hard pool",
        items: [
          "Choose Easy for famous sporting nations or Hard for the full pool."
        ]
      },
      {
        heading: "Reading the vibe word before you search",
        items: [
          "Read the vibe word, then search and submit a country when you have a hunch."
        ]
      },
      {
        heading: "Revealing clues from a miss or a hint",
        items: [
          "Each wrong guess reveals the next clue. The hint button reveals one too, if you'd rather not burn a guess."
        ]
      },
      {
        heading: "Playing until you name it or give up",
        items: [
          "Keep going until you name it, run out of clues, or give up."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Twelve clue slots ending in the name",
        items: [
          "There are 12 clue slots and the final one is the country's name itself, worth 0."
        ]
      },
      {
        heading: "Paying less with every clue you reveal",
        items: [
          "Scoring starts at 1,200 on clue 1, then 1,100, 1,000, 850, 700, 550, 400, 250, 150, 100, 50 and 0."
        ]
      },
      {
        heading: "Building a streak with badges as you win",
        items: [
          "Consecutive wins build a streak with badges at 3, 5, 10 and 15 wins. A miss or a give up resets it."
        ],
        subsections: [
          {
            heading: "Giving up to reveal the answer",
            items: [
              "Give up any time to reveal the answer and score 0."
            ]
          }
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Sprint, the Caribbean and a track heavy medal count",
        paragraphs: [
          "Say the vibe word is Sprint. Bold guessers type Jamaica immediately for 1,200. You play it safer, revealing the region, the Caribbean, then a medal count won almost entirely on the track."
        ]
      },
      {
        heading: "Committing to Jamaica on the third clue",
        paragraphs: [
          "You commit to Jamaica on clue 3 for 1,000 points. The famous moment clue would have name-dropped a certain 100m world record in Beijing, but you didn't need it."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Eliminating continents from one sharp word",
        items: [
          "The vibe word is sharper than it looks. One word can eliminate four continents."
        ]
      },
      {
        heading: "Reading a big winter haul as a tell",
        items: [
          "Medal totals are the biggest tell. A huge winter haul points north fast."
        ]
      },
      {
        heading: "Narrowing by population and continent",
        items: [
          "Population plus continent narrows brutally. Big country, small medal count is its own clue."
        ]
      },
      {
        heading: "Saving guesses for real suspects",
        items: [
          "Weak hunch? Use the hint button instead of guessing, and save guesses for real suspects."
        ]
      }
    ],
    faqs: [
      {
        q: "What do the clues cover?",
        a: "In order: vibe word, region, population, Games attended, total medals, best sport, famous moment, winter history, gold medals, flag colors, country size, then the name itself."
      },
      {
        q: "What's the difference between Easy and Hard?",
        a: "Easy draws only from well-known sporting nations. Hard opens the entire pool."
      },
      {
        q: "How do streak badges work?",
        a: "Win back to back to climb from Bronze Medalist at 3 straight to Silver at 5, Gold at 10 and All Time Great at 15. One miss resets you."
      }
    ]
  },
  "/hof-or-bust": {
    intro: [
      "No name, no face, just a career stat line. Hall of Fame or Bust shows you the anonymized numbers of a real player and asks for a verdict: legend or letdown?",
      "After you vote, the name drops, the verdict lands, and you see how the community called it. Stats can flatter, and this game is built on that."
    ],
    headings: {
      howToPlay: "Hall of Fame or Bust? Here's how to play this blind stats game",
      rules: "Hall of Fame or Bust? rules for hints, scoring and verdicts",
      example: "Hall of Fame or Bust? walkthrough: 894 goals and a hidden bust",
      tips: "Hall of Fame or Bust? tips for reading a blind stat line",
      faq: "Hall of Fame or Bust? FAQ: verdicts, votes and sports"
    },
    howToPlaySections: [
      {
        heading: "Reading the anonymized career stats",
        items: [
          "Read the anonymized career stats for the mystery player. The sport is shown, the name isn't."
        ]
      },
      {
        heading: "Revealing up to three hints",
        items: [
          "If you're torn, reveal a hint. There are up to 3 per player."
        ]
      },
      {
        heading: "Voting once you've made up your mind",
        items: [
          "Vote Hall of Fame or Bust when you've made up your mind."
        ]
      },
      {
        heading: "Seeing the player, verdict and vote split",
        items: [
          "The reveal shows the player, our call on him, whether he's really in his sport's Hall of Fame (and the year he went in), a fun fact and the community vote split."
        ]
      },
      {
        heading: "Moving from the daily player to unlimited",
        items: [
          "Finish the daily player, then keep going in unlimited mode."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Losing points for every hint you use",
        items: [
          "A correct vote scores 1,000 points minus 100 for each hint you used. A wrong vote scores 0."
        ],
        subsections: [
          {
            heading: "Capping hints at three a player",
            items: [
              "You can reveal up to 3 hints per player, each costing 100 points off a win."
            ]
          }
        ]
      },
      {
        heading: "Three verdicts, with Borderline counting either way",
        items: [
          "Verdicts are Hall of Fame, Bust, or Borderline, and on a Borderline player either vote counts as correct."
        ]
      },
      {
        heading: "One shared player a day, then unlimited",
        items: [
          "One shared mystery player per day, with unlimited mode serving more after that."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "894 goals and four rings, an easy call",
        paragraphs: [
          "Imagine the card reads: 894 career goals, 4 championship rings, played into his 30s. No hints needed, numbers like that belong to one hockey player ever, and Hall of Fame is a free 1,000 points."
        ]
      },
      {
        heading: "Big stats, no titles, a correct Bust vote",
        paragraphs: [
          "The next card is murkier: big counting stats, zero titles, one MVP-ish season. You burn two hints, vote Bust, and you're right for 800. The community split says 61 percent agreed."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Weighing trophies over raw totals",
        items: [
          "Trophies and awards separate legends from compilers faster than raw totals."
        ]
      },
      {
        heading: "Noticing what the stat line leaves out",
        items: [
          "Notice what the stat line leaves out. No titles listed usually means there aren't any."
        ]
      },
      {
        heading: "Guessing from the numbers before a hint",
        items: [
          "Hints cost 100 each, so guess from the numbers first and spend hints only when stuck."
        ]
      },
      {
        heading: "Remembering a Bust is about the hype",
        items: [
          "Busts here mean careers that fell short of the hype, and hype is exactly what the stat line hides."
        ]
      }
    ],
    faqs: [
      {
        q: "What counts as a Bust?",
        a: "The site's verdict measures a career against its expectations. A player can be decent and still be a Bust if the hype said all-time great."
      },
      {
        q: "Are the community votes real?",
        a: "Yes. Every vote cast on a player is stored, and the percentages you see after voting are the actual tallies."
      },
      {
        q: "Which sports appear?",
        a: "Soccer, NFL, NBA, baseball and hockey, with the sport badge always visible so you can judge the numbers in context."
      }
    ]
  },
  "/score-predictor": {
    intro: [
      "You remember who won. But do you remember the score? Score Predictor pulls up a famous match, gives you the teams, the competition, the date and a hint, and asks for the exact final score.",
      "It's a memory test disguised as a prediction game, and the difference between glory and 50 points is usually one goal you forgot about."
    ],
    headings: {
      howToPlay: "How to play Score Predictor, a free soccer, NFL and NBA trivia game",
      rules: "Score Predictor rules for scoring bands and accuracy",
      example: "Score Predictor walkthrough: Brazil versus Germany, 2014",
      tips: "Score Predictor tips for calibrating by sport",
      faq: "Score Predictor FAQ: sports covered and scoring bands"
    },
    howToPlaySections: [
      {
        heading: "Reading the match card and the hint",
        items: [
          "Read the match card: both teams, the competition, the date and a hint about the drama."
        ]
      },
      {
        heading: "Typing a predicted score for each team",
        items: [
          "Type your predicted score for each team."
        ]
      },
      {
        heading: "Locking in one prediction per match",
        items: [
          "Hit Lock In Prediction. One prediction per match, no edits."
        ]
      },
      {
        heading: "Seeing the real score and a fun fact",
        items: [
          "The real score is revealed with a fun fact about the game."
        ]
      },
      {
        heading: "Switching from the daily match to unlimited",
        items: [
          "Play the daily match, then switch to unlimited for more."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Scoring the most for an exact score",
        items: [
          "Exact score scores 1,000 points."
        ],
        subsections: [
          {
            heading: "Staying close scores a shrinking bonus",
            items: [
              "Right result with both team scores within 1 scores 700, within 2 scores 400."
            ]
          }
        ]
      },
      {
        heading: "Paying least for a wrong result",
        items: [
          "Right result but way off on the numbers scores 200, and the wrong result scores 50."
        ]
      },
      {
        heading: "One daily match plus an unlimited archive",
        items: [
          "One featured match per day, plus an unlimited mode with the whole archive of soccer, NFL and NBA classics."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Predicting a big Germany win",
        paragraphs: [
          "Suppose the card shows Brazil against Germany, World Cup semifinal, 2014. You remember Germany humiliated the hosts, so you lock in 1-5."
        ]
      },
      {
        heading: "Landing in the smallest right result tier",
        paragraphs: [
          "The reveal says 1-7. You called the winner and Brazil's goal exactly, but being 2 off on Germany's tally drops you out of the 700 tier and out of the 400 tier too, since both scores need to be close. Right result, 200 points, and a fun fact about the strangest half in World Cup history."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Calibrating goals and points by sport",
        items: [
          "Calibrate by sport. Soccer classics live between 0 and 4 goals, NBA finals scores sit in the 80s to 110s."
        ]
      },
      {
        heading: "Expecting tight scores in famous upsets",
        items: [
          "Famous upsets are usually tight. Blowouts are famous precisely because they're rare."
        ]
      },
      {
        heading: "Reading the hint for the shape of the score",
        items: [
          "The hint often nods at the drama, like a comeback or a shootout, which hints at the shape of the score."
        ]
      },
      {
        heading: "Nailing the winner before the numbers",
        items: [
          "Nail the winner first. That alone is the difference between 200 and 50."
        ]
      }
    ],
    faqs: [
      {
        q: "Can I change my prediction after locking in?",
        a: "No. One lock-in per match is the whole tension of the game, so make it count."
      },
      {
        q: "What sports are included?",
        a: "Legendary matches from soccer, the NFL and the NBA, from World Cup finals to Super Bowls to NBA closeouts."
      },
      {
        q: "How close do I need to be for big points?",
        a: "Exact is 1,000. If you pick the right result, being within 1 goal or point on both teams pays 700, and within 2 pays 400."
      }
    ]
  },
  "/list-quiz": {
    intro: [
      "Pick a list, empty your brain into the box. Name Them All is the classic recall quiz: every Super Bowl MVP, every F1 world champion, every Masters winner, and you versus the blanks.",
      "There are 28 lists across a dozen sports, from Heisman winners to VFL/AFL and NRL premiers, all built from the site's records database, so the answer key is real history."
    ],
    headings: {
      howToPlay: "How to play Name Them All, a free sports recall quiz",
      rules: "Name Them All rules for timers, tiers and guessing",
      example: "Name Them All walkthrough: Super Bowl MVPs on the clock",
      tips: "Name Them All tips for beating the clock",
      faq: "Name Them All FAQ: lists, tiers and spelling"
    },
    howToPlaySections: [
      {
        heading: "Choosing a list from the menu",
        items: [
          "Choose a list from the menu, anything from Heisman winners to Stanley Cup champions."
        ]
      },
      {
        heading: "Picking Relaxed or the timed sprint",
        items: [
          "Pick Relaxed for no clock, or the timed mode for a 3:00 sprint."
        ]
      },
      {
        heading: "Typing names for a green flash",
        items: [
          "Type names into the box. Correct answers flash green and fill in on the board."
        ]
      },
      {
        heading: "Reading yellow repeats and red misses",
        items: [
          "Repeats flash yellow, misses flash red, and neither costs you anything."
        ]
      },
      {
        heading: "Giving up to reveal what's missing",
        items: [
          "Give up any time to reveal what you missed, then retry or grab another list."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Playing with a clock or without one",
        items: [
          "Timed mode gives you exactly 180 seconds. Relaxed mode has no timer at all."
        ]
      },
      {
        heading: "Typing at least three letters or a surname",
        items: [
          "Guesses need at least 3 letters, and surnames or team nicknames count when they're unique to one answer."
        ]
      },
      {
        heading: "Earning Gold, Silver and Bronze tiers",
        items: [
          "Finishing 100 percent of a list earns Gold, 80 percent or better earns Silver, and 60 percent or better earns Bronze."
        ],
        subsections: [
          {
            heading: "Guessing for free with no limit",
            items: [
              "Wrong guesses are free. There's no penalty and no guess limit."
            ]
          }
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Naming quarterbacks first by surname",
        paragraphs: [
          "Say you open Super Bowl MVPs on the 3:00 clock. You hammer out the quarterbacks first, montana, brady, mahomes, all accepted as surnames, and the board starts filling green."
        ]
      },
      {
        heading: "Stalling at seventy two percent for Bronze",
        paragraphs: [
          "Around 40 seconds left you stall, dig up a defender or two, then time hits zero at 72 percent. Bronze tier, and the red misses show exactly what to remember for the Silver run."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Dumping the easy names first",
        items: [
          "Dump the easy names first and save the digging for the back half of the clock."
        ]
      },
      {
        heading: "Typing fast surnames over full names",
        items: [
          "Type surnames. They're faster, and the game only asks for full names when two answers share one."
        ]
      },
      {
        heading: "Working through the list by decade",
        items: [
          "Work by decade. Walking through the years surfaces names that free recall won't."
        ]
      },
      {
        heading: "Spelling out a shared surname in full",
        items: [
          "If a name flashes red, try the full version. Shared surnames need spelling out."
        ]
      }
    ],
    faqs: [
      {
        q: "Does spelling need to be perfect?",
        a: "Accents, punctuation and capitals are all forgiven, so suarez works for Su\xE1rez. The letters themselves still need to be right."
      },
      {
        q: "Is there a daily list?",
        a: "No. All 28 lists are open all the time, and you can retry any of them as often as you like."
      },
      {
        q: "What are the tiers?",
        a: "Gold means you named the entire list, Silver is 80 percent or more, Bronze is 60 percent or more. Below that you just get encouragement."
      }
    ]
  },
  "/champ-or-not": {
    intro: [
      "Champ or Not deals ten claims about champions, one at a time, and every single one sounds right. The Bulls in 1994? The Islanders in 1982? Leicester in 2016? Two of those happened. Your job is knowing which.",
      "Every claim is built from real title history across ten competitions: the Super Bowl, the NBA, the World Series, the Stanley Cup, the WNBA, college football and college hoops, the English title, the VFL/AFL flag and the NRL premiership. The fakes are the cruelest kind: a real champion of that competition, dropped into a year they did not win."
    ],
    headings: {
      howToPlay: "How to play Champ or Not, a free true or false champions game",
      rules: "Champ or Not rules for claims, years and hard mode",
      example: "Champ or Not walkthrough: the 1994 Bulls and the 1982 Islanders",
      tips: "Champ or Not tips for placing an era before you tap",
      faq: "Champ or Not FAQ: leagues covered and split titles"
    },
    howToPlaySections: [
      {
        heading: "Reading the team, title and year",
        items: [
          "Read the claim: a team, a title, a year."
        ]
      },
      {
        heading: "Tapping CHAMP or NOT",
        items: [
          "Tap CHAMP if it really happened, or NOT if it did not."
        ]
      },
      {
        heading: "Seeing the real winner on a fake claim",
        items: [
          "The reveal tells you straight away, and if the claim was fake it names the team that really won that year."
        ]
      },
      {
        heading: "Ten daily claims worth one point each",
        items: [
          "Ten claims per day, one point per correct call, and everyone in the world gets the same ten."
        ]
      },
      {
        heading: "Toggling Hard mode in unlimited sets",
        items: [
          "Unlimited mode deals fresh sets as long as you want to keep calling, and its Hard toggle makes every fake a team that really won a nearby season."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Every team named is a real champion",
        items: [
          "Every team named is a genuine champion of that competition at some point in history. The lie, when there is one, is only ever the year."
        ]
      },
      {
        heading: "Tightening fakes to three seasons in Hard mode",
        items: [
          "Hard mode (Unlimited only) tightens the fakes: the wrong team still won for real, within about three seasons of the year on the card."
        ]
      },
      {
        heading: "Counting a shared college football crown as true",
        items: [
          "Split titles count as true: if two schools share a college football crown, a claim about either one is a real claim."
        ]
      },
      {
        heading: "One shared daily set that locks in",
        items: [
          "The daily set is the same for everyone and locks in your result for the day once you finish."
        ],
        subsections: [
          {
            heading: "One tap per claim, no lifelines",
            items: [
              "No hints, no lifelines, no second guesses. One tap per claim."
            ]
          }
        ]
      }
    ],
    exampleSections: [
      {
        heading: "The 1994 Bulls claim is actually false",
        paragraphs: [
          "The card says: The Chicago Bulls won the 1994 NBA Finals. It smells right, the Bulls won everything in the 90s, but 1994 is the baseball year: Houston won it. You tap NOT and the reveal confirms it, one point."
        ]
      },
      {
        heading: "The 1982 Islanders mid dynasty claim",
        paragraphs: [
          "Next card: The New York Islanders won the Stanley Cup in 1982. That is the middle of the four in a row, so you tap CHAMP. Another point, eight claims to go."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Placing the era before you tap",
        items: [
          "Work out the era first. Most fakes die the moment you remember who owned that stretch of years."
        ]
      },
      {
        heading: "Watching for gaps inside a dynasty",
        items: [
          "Dynasty gaps are the trap: the Bulls did not win in 1994 or 1995, and the Lakers missed 1990 to 1999 entirely."
        ]
      },
      {
        heading: "Learning the correct year from a miss",
        items: [
          "The reveal names the real winner on every fake, so even a wrong call teaches you the year for next time."
        ]
      },
      {
        heading: "Asking if this exact year is a title year",
        items: [
          "Champions repeat. If you know the team has a pile of titles, the question is only whether THIS year is one of them."
        ]
      }
    ],
    faqs: [
      {
        q: "Are the wrong answers made up?",
        a: "No. A false claim names a real winner of that same competition, just attached to a year they did not win. Every team you see genuinely lifted that trophy at some point."
      },
      {
        q: "What about seasons with two champions?",
        a: "College football split its crown a few times, and those years count both schools as true champions. A claim about either one is a real claim, never a trick."
      },
      {
        q: "Where does the history come from?",
        a: "The same records database behind Name Them All, checked season by season against the official record books before any game was allowed to read it."
      }
    ]
  },
  "/whod-they-beat": {
    intro: [
      "History has a short memory and it only keeps one name per year. Who'd They Beat? is about the other name: the team that made the final, shook hands, and watched the confetti fall on somebody else.",
      "We give you the champion and the year, across five competitions: the Super Bowl, the NBA Finals, the World Series, the Stanley Cup and the WNBA Finals. You pick who they beat from four options, and every single option is a real beaten finalist from that competition's record books."
    ],
    headings: {
      howToPlay: "How to play Who'd They Beat?, a free finals trivia game",
      rules: "Who'd They Beat? rules for options and daily scoring",
      example: "Who'd They Beat? walkthrough: the 1994 Rockets and the 1942 Leafs",
      tips: "Who'd They Beat? tips for placing the era and league",
      faq: "Who'd They Beat? FAQ: leagues covered and the data"
    },
    howToPlaySections: [
      {
        heading: "Reading the champion and the year",
        items: [
          "Read the final: a champion and a year."
        ]
      },
      {
        heading: "Picking the loser from four options",
        items: [
          "Pick which of the four teams lost to them."
        ]
      },
      {
        heading: "Seeing the answer and the series result",
        items: [
          "The reveal names the answer and the series result straight away."
        ]
      },
      {
        heading: "Ten daily finals across five leagues",
        items: [
          "Ten finals per day, two from each competition, one point per correct pick."
        ],
        subsections: [
          {
            heading: "Switching to unlimited after the daily set",
            items: [
              "The daily set is the same for everyone. Unlimited mode keeps dealing."
            ]
          }
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Every option is a real finals loser",
        items: [
          "Every option is a genuine finals loser from that same competition. No invented teams, ever."
        ]
      },
      {
        heading: "Mixing in runners up from other years",
        items: [
          "The wrong options are real runners up from other years, which is what makes the near misses cruel: the 1995 Magic show up as an option for the 1994 question."
        ]
      },
      {
        heading: "One pick per final, no second chances",
        items: [
          "One pick per final, no second chances, and the daily locks your result once you finish."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "The 1994 Rockets against the Knicks",
        paragraphs: [
          'The card asks: "The Houston Rockets won the 1994 NBA Finals. Who did they beat?" You remember the Knicks going to seven, pick New York, and the reveal confirms it, series 4-3.'
        ]
      },
      {
        heading: "The 1942 Maple Leafs comeback final",
        paragraphs: [
          "Next card is hockey: the 1942 Maple Leafs. If you know the only final ever won from three games down, you know Detroit was on the wrong end of it."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Placing the era before the league",
        items: [
          "Work out the era first, then the conference or league. Half the wrong options die on geography."
        ]
      },
      {
        heading: "Trusting dynasty years as the easy calls",
        items: [
          "Dynasty years are the easy ones: everyone knows who kept losing to the Bulls. The 40s and 50s are where scores are made."
        ]
      },
      {
        heading: "Picking up who beat whom as you go",
        items: [
          "The reveal teaches the series result too, which quietly makes you better at Champ or Not."
        ]
      },
      {
        heading: "Choosing the option closest to the exact year",
        items: [
          "The trap options are usually from a year or two away. If two answers feel right, pick the one that fits the exact year."
        ]
      }
    ],
    faqs: [
      {
        q: "Are the wrong answers made up?",
        a: "No. Every option genuinely lost a final in that competition at some point. The game is picking the right year's runner up, not spotting a fake team."
      },
      {
        q: "Where does the data come from?",
        a: "The same audited record books behind our Record Books page: every finals loser was verified against independent lists and known history before this game was allowed to ask about it."
      },
      {
        q: "Why these five competitions?",
        a: "They are the ones where our records carry every beaten finalist, all the way back: 121 World Series, 110 Stanley Cup Finals, 80 NBA Finals, 60 Super Bowls and every WNBA Finals since 1997."
      }
    ]
  },
  "/silverware-sort": {
    intro: [
      "Every fan can name the most decorated club in their league. Silverware Sort asks the harder question: can you put five of them in order? The gap between knowing the Yankees lead baseball and knowing whether the Dodgers or the Red Sox come next is where this game lives.",
      "Five teams from one competition, a shuffled pile, and a ladder with the most titles at the top. Every count is counted straight out of the same audited record books the rest of the site runs on, across the Super Bowl, the NBA, the World Series, the Stanley Cup, college football and hoops, the English title, the AFL and the NRL."
    ],
    headings: {
      howToPlay: "How to play Silverware Sort, a free daily sports ranking trivia game",
      rules: "Silverware Sort rules for ties, tries and the reveal",
      example: "Silverware Sort walkthrough: a World Series board and an AFL board",
      tips: "Silverware Sort tips for ranking title counts fast",
      faq: "Silverware Sort FAQ: era names, ties and the WNBA"
    },
    howToPlaySections: [
      {
        heading: "Reading the board's one competition and five teams",
        items: [
          "Read the board: one competition, five teams, one right order."
        ]
      },
      {
        heading: "Building the ladder from most titles to fewest",
        items: [
          "Tap teams into the ladder, most titles at the top, fewest at the bottom."
        ]
      },
      {
        heading: "Submitting for a green lock and a second try",
        items: [
          "Submit. Rungs you placed right lock in green, and you get a second try at the rest."
        ]
      },
      {
        heading: "Scoring one point per rung across three boards",
        items: [
          "One point per correct rung on your final answer, fifteen points across the day's three boards."
        ]
      },
      {
        heading: "Choosing the daily boards or unlimited mode",
        items: [
          "The daily boards are the same for everyone. Unlimited mode keeps dealing fresh ones."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Never facing a tied board",
        items: [
          "No two teams on a board are ever tied. Every board has exactly one right order, so a miss is a miss on the record, never on a coin flip."
        ],
        subsections: [
          {
            heading: "Counting titles under the names our Record Books use",
            items: [
              "Counts follow the names as our Record Books and Name Them All write them: South Melbourne's flags and Sydney's flags are separate stacks."
            ]
          }
        ]
      },
      {
        heading: "Two tries before a board locks in",
        items: [
          "Two tries per board. The first submit locks your greens; the second is final."
        ]
      },
      {
        heading: "Revealing every team's real count",
        items: [
          "The reveal always shows every team's real count, so you leave each board knowing the actual cabinet."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "A World Series board topped by the Yankees",
        paragraphs: [
          "A World Series board deals the Yankees, the Cardinals, the Dodgers, the Cubs and the Marlins. The top is a gift: 27 Yankees titles, then the Cardinals on 11. The bottom half is the game: Dodgers, then Cubs, then the Marlins with 2."
        ]
      },
      {
        heading: "An AFL board where three clubs tie on flags",
        paragraphs: [
          "An AFL board will never hand you Essendon, Carlton and Collingwood together: all three sit on 16 flags, and tied teams never share a board. Same reason a Super Bowl board never deals the Steelers next to the Patriots."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Anchoring the top and bottom rungs first",
        items: [
          "Anchor the ends first. The most decorated team and the clear minnow are usually easy; the middle rungs are where points die."
        ]
      },
      {
        heading: "Watching for era name changes",
        items: [
          "Watch for era names. Eastern Suburbs and the Sydney Roosters are the same club but separate stacks here, and old-name entries usually carry the smaller count."
        ]
      },
      {
        heading: "Treating a first miss as information",
        items: [
          "A first-try miss is information: your greens lock, so the second try is a smaller puzzle. Count what is left before you tap."
        ]
      },
      {
        heading: "Reading the Record Books page for practice",
        items: [
          "Reading the Record Books page once a week is basically training camp for this game."
        ]
      }
    ],
    faqs: [
      {
        q: "What happens if two teams have the same number of titles?",
        a: "They will never appear on the same board. The board builder only picks five teams with strictly different counts, so the right order is always a fact, never a tiebreak we invented."
      },
      {
        q: "Where do the counts come from?",
        a: "Counted row by row from the same audited champion tables behind our Record Books page, the ones verified season by season against the official record. No count on a board is typed in by hand."
      },
      {
        q: "Why is the WNBA not in this game?",
        a: "Its history is real but young: there are not yet five different title counts to build an honest board from. The moment there are, it qualifies automatically."
      }
    ]
  },
  "/hall-of-champions": {
    intro: [
      "Most idle games have you clicking a number until it goes up. This one has you building a museum, and every single thing you hang on the wall actually happened. Acquire Super Bowl I and the plaque tells you which team won it, who they beat and by how much. Acquire the 1985 Bears and it is the 1985 Bears, because the exhibit list is read straight out of our audited record books.",
      "Visitors pay admission every second, admission money buys more history, and more history brings more visitors. Ten wings, hundreds of real champions from the nineteenth century to this year, and the hall keeps earning while your phone is in your pocket."
    ],
    headings: {
      howToPlay: "How to play Hall of Champions, a free idle sports trivia museum game",
      rules: "Hall of Champions rules for plaques, away time and rededicating",
      example: "Hall of Champions walkthrough: opening and completing the Super Bowl wing",
      tips: "Hall of Champions tips for faster wings and better timing",
      faq: "Hall of Champions FAQ: real championships, away earnings and rededicating"
    },
    howToPlaySections: [
      {
        heading: "Acquiring champions oldest first in each wing",
        items: [
          "Acquire champions one at a time, oldest first in each wing. Each costs more and earns more than the last."
        ]
      },
      {
        heading: "Opening wings and doubling their income",
        items: [
          "Every ten exhibits in a wing doubles that wing's income.",
          "Open new wings when the money allows, from the Super Bowl through to the NRL and the AFL."
        ]
      },
      {
        heading: "Tapping the anniversary banner for triple admissions",
        items: [
          "Tap the anniversary banner when it lights up: admissions triple for a few seconds."
        ]
      },
      {
        heading: "Spending on tours, the network, the shop and the vault",
        items: [
          "Spend on tours, the curator's network, the gift shop and the archive vault to raise everything at once."
        ]
      },
      {
        heading: "Rededicating for permanent renown stars",
        items: [
          "Rededicate once the hall is big enough to trade every exhibit for permanent renown stars."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Every exhibit coming from checked champion tables",
        items: [
          "Nothing in this museum is invented. Every year, team and result comes from the same checked champion tables our quiz games and Record Books run on."
        ]
      },
      {
        heading: "Earning while you are away at half speed",
        items: [
          "The hall earns while you are away, at half speed, capped at eight hours. The gift shop raises that rate."
        ]
      },
      {
        heading: "Plaques from finishing a wing",
        items: [
          "Finishing a wing hangs a plaque worth a permanent income bonus, and a plaque survives every rededication."
        ],
        subsections: [
          {
            heading: "What a rededication clears and keeps",
            items: [
              "Rededicating clears the exhibits, the funds, the wings and the upgrades. Renown stars and plaques are the only things that carry over, and they carry over forever."
            ]
          }
        ]
      },
      {
        heading: "Honest prices with no hidden fees",
        items: [
          "The price quoted on a button is the price charged. No hidden fees, no fake discounts."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Opening the Super Bowl wing for ten coins",
        paragraphs: [
          "Your first purchase is the oldest Super Bowl on the books, for ten coins. Ten Super Bowls later that wing pays double, and the money starts arriving fast enough to open the WNBA wing next door."
        ]
      },
      {
        heading: "A permanent plaque once that wing fills up",
        paragraphs: [
          "Sixty Super Bowls in, the wing is complete and its plaque is permanent: a quarter more admissions across the whole museum, forever, even after you rededicate and start the walls again."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Going wide before going deep, then watching milestones",
        items: [
          "Wide beats deep early. Opening a new wing is usually worth more than the next expensive exhibit in your best one.",
          "Watch the milestone counter on each buy button. Being two exhibits away from doubling a wing is the best money in the game."
        ]
      },
      {
        heading: "Timing the anniversary tap after a buying run",
        items: [
          "Save the anniversary tap for right after a big acquisition run, when your per second number is at its highest."
        ]
      },
      {
        heading: "Choosing the gift shop for long time away",
        items: [
          "The gift shop only pays if you actually leave. If you play in long sittings, tours and the network are worth more."
        ]
      },
      {
        heading: "Waiting for the first rededication",
        items: [
          "Do not rush the first rededication. Stars are paid per twenty exhibits, so one late rededication beats two early ones."
        ]
      }
    ],
    faqs: [
      {
        q: "Are the championships real?",
        a: "Every one. The exhibit list is fetched from the same audited tables behind our Record Books page, which were checked season by season against the official record. If a season was never played, it is not in the museum either."
      },
      {
        q: "Does it keep going when I close the tab?",
        a: "Yes, at half speed for up to eight hours, and the gift shop upgrade raises that rate. You get a note on the door when you come back telling you exactly what the hall took while you were out."
      },
      {
        q: "What is the point of rededicating?",
        a: "Renown. You trade a full museum for permanent stars, one per twenty exhibits, each worth ten percent more admissions for the rest of the save. Completed wings keep their plaques too, so a second run through the same history is far faster than the first."
      },
      {
        q: "Do I lose progress if I stop playing?",
        a: "No. The save lives on your device and nothing decays. Come back in a month and the hall is exactly as you left it, plus eight hours of admissions."
      }
    ]
  },
  "/minefield": {
    intro: [
      "The board looks friendly: one category, a wall of names, most of them belong. Some of them are mines. Minefield asks you to click everyone who truly fits while dodging the plausible fakes planted among them.",
      "You know Leicester won the Premier League. You think Newcastle did too. Boom."
    ],
    headings: {
      howToPlay: "How to play Minefield, a free daily sports trivia clicking game",
      rules: "Minefield rules for lives, points and mine counts",
      example: "Minefield walkthrough: a Premier League board and a wrong click",
      tips: "Minefield tips for banking points and dodging mines",
      faq: "Minefield FAQ: lives, mine counts and the daily board"
    },
    howToPlaySections: [
      {
        heading: "Reading the category and its hint",
        items: [
          "Read the category and its hint, like Premier League champions or the MLB 500 home run club."
        ]
      },
      {
        heading: "Clicking tiles that belong to the category",
        items: [
          "Click every tile you believe belongs. Correct picks turn green."
        ]
      },
      {
        heading: "Losing a life on a mine",
        items: [
          "Click a mine and it explodes, costing one of your 2 lives on that board."
        ]
      },
      {
        heading: "Clearing the board for a bonus",
        items: [
          "Find all the correct tiles to clear the board and bank a bonus."
        ]
      },
      {
        heading: "Playing three boards and sharing your score",
        items: [
          "Play 3 boards per run, then see your final score and share it."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Two lives per board",
        items: [
          "Each board has 2 lives. Two mine hits end that board, but the run continues to the next one."
        ]
      },
      {
        heading: "Scoring correct tiles and the clear bonus",
        items: [
          "Every correct tile is worth 10 points, and clearing a full board adds a 30 point bonus."
        ]
      },
      {
        heading: "How big a board can get",
        items: [
          "Boards hold 12 to 16 tiles, with 4 to 6 mines hidden among them."
        ],
        subsections: [
          {
            heading: "Daily boards versus unlimited mode",
            items: [
              "The daily run is identical for everyone and flips at midnight Eastern Time. Unlimited deals random boards."
            ]
          }
        ]
      }
    ],
    exampleSections: [
      {
        heading: "A Premier League board with the easy bankers",
        paragraphs: [
          "Imagine the category is Premier League champions. You click the bankers: Manchester United, Arsenal, Chelsea, Manchester City. Then Blackburn Rovers and Leicester City, both real champions, both green."
        ]
      },
      {
        heading: "A wrong click on Newcastle United",
        paragraphs: [
          "Feeling smart, you click Newcastle United. Boom, never won the Premier League itself. One life left, and the remaining tiles suddenly look a lot more suspicious."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Banking the certain tiles first",
        items: [
          "Bank the certainties first. Every green is 10 points you keep even if the board later explodes."
        ]
      },
      {
        heading: "Reading the hint line for era limits",
        items: [
          "Read the hint line, since era limits change everything about who counts."
        ]
      },
      {
        heading: "Spotting mines among the nearly men",
        items: [
          "Mines are nearly-men: famous finalists, runners-up and almost-dynasties. If a name feels like it should have won, that feeling is the trap."
        ]
      },
      {
        heading: "Slowing down on your last life",
        items: [
          "Down to one life? Slow down and count the board. The found counter tells you how many real ones remain."
        ]
      }
    ],
    faqs: [
      {
        q: "What happens when I run out of lives?",
        a: "That board ends and is revealed, but you keep your points and the run moves on. Only that board's 30 point clear bonus is lost."
      },
      {
        q: "How many mines are on a board?",
        a: "Between 4 and 6, hidden among 12 to 16 tiles. The board shows a running count of how many mines are still out there."
      },
      {
        q: "Is the daily the same for everyone?",
        a: "Yes, everyone gets the same 3 boards in the same order each day, which makes scores properly comparable."
      }
    ]
  },
  "/sports-millionaire": {
    intro: [
      "Fifteen questions stand between you and a million pretend dollars. Sports Millionaire is a climb-the-ladder quiz in the classic TV style: each answer raises the stakes, and one wrong step sends you tumbling.",
      "The money is entirely pretend, no prizes and no cash, but the sweat on question 12 is real. Questions are generated from a live database of footballers."
    ],
    headings: {
      howToPlay: "How to play Sports Millionaire, a free fifteen question money ladder quiz",
      rules: "Sports Millionaire rules for the ladder, havens and lifelines",
      example: "Sports Millionaire walkthrough: a safe haven and a big gamble",
      tips: "Sports Millionaire tips for lifelines, havens and reading the crowd",
      faq: "Sports Millionaire FAQ: real money, questions and lifelines"
    },
    howToPlaySections: [
      {
        heading: "Answering multiple choice questions easiest first",
        items: [
          "Answer multiple-choice questions one at a time, four options each, easiest first."
        ]
      },
      {
        heading: "Climbing the money ladder with each right answer",
        items: [
          "Each correct answer climbs the money ladder toward the top."
        ]
      },
      {
        heading: "Using the three lifelines",
        items: [
          "Use your lifelines: 50:50 removes two wrong options, Ask the Crowd shows a poll, Swap Question trades in the current question."
        ]
      },
      {
        heading: "Walking away with what you have banked",
        items: [
          "Before locking in, you can walk away and keep everything you've banked."
        ]
      },
      {
        heading: "Dropping back to your last safe haven",
        items: [
          "Answer wrong and you drop to the last safe haven you passed."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "How far the ladder climbs in dollars",
        items: [
          "The ladder runs 15 questions, from $100 up to $1,000,000, all in play money."
        ]
      },
      {
        heading: "Where the two safe havens sit",
        items: [
          "Questions 5 and 10 are safe havens worth $1,000 and $32,000. A wrong answer drops you to the last haven you cleared, or $0 if you haven't reached one."
        ],
        subsections: [
          {
            heading: "Using each lifeline once a run",
            items: [
              "Each of the 3 lifelines can be used exactly once per run."
            ]
          }
        ]
      },
      {
        heading: "Daily ladders versus unlimited ladders",
        items: [
          "The daily ladder is the same 15 questions for everyone. Unlimited builds a fresh random ladder every run."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Clearing the second safe haven with a lifeline",
        paragraphs: [
          "Picture gliding to question 9 on football basics. Question 10 for $32,000 is a shirt-number deep cut, so you burn the 50:50, guess right, and lock the haven."
        ]
      },
      {
        heading: "Gambling past a safe haven and falling back",
        paragraphs: [
          "At question 11 you gamble for $64,000, miss, and fall back to $32,000. That banked haven is the difference between a war story and a wipeout."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Treating the safe havens as finish lines",
        items: [
          "Treat questions 5 and 10 like finish lines. Clear them, then gamble freely."
        ]
      },
      {
        heading: "Saving Swap Question for the late rungs",
        items: [
          "Save Swap Question for the late rungs, where every question is brutal."
        ]
      },
      {
        heading: "Reading the crowd's confidence",
        items: [
          "The crowd is confident on easy questions and shaky on hard ones. Trust a landslide, doubt a coin flip."
        ]
      },
      {
        heading: "Walking away as a real strategy",
        items: [
          "Walking away is a real strategy. A banked $16,000 beats a proud $1,000."
        ]
      }
    ],
    faqs: [
      {
        q: "Is any of the money real?",
        a: "No. The dollars are a score with a dollar sign on them. Nothing is wagered, nothing is paid out, it's bragging rights only."
      },
      {
        q: "Where do the questions come from?",
        a: "They're generated from a live football database: clubs, nationalities, positions, market value comparisons and shirt numbers."
      },
      {
        q: "What exactly do the lifelines do?",
        a: "50:50 hides two wrong answers, Ask the Crowd shows a simulated audience poll, and Swap Question deals a new question at the same difficulty. One use each per run."
      }
    ]
  },
  "/quiz-board": {
    intro: [
      "Five categories, five money rows, twenty-five clues, and a scoreboard that goes down as well as up. Sports Quiz Board is the game where the wrong answer doesn't just miss, it costs you the tile's full value.",
      "The dollars are pure scorekeeping, nothing real changes hands. The pain of blowing a $1,000 clue, though, is real."
    ],
    headings: {
      howToPlay: "How to play Sports Quiz Board, a free daily sports trivia board game",
      rules: "Sports Quiz Board rules for scoring, negatives and answer matching",
      example: "Sports Quiz Board walkthrough: an easy clue and a costly miss",
      tips: "Sports Quiz Board tips for sweeping rows and beating the deep cuts",
      faq: "Sports Quiz Board FAQ: negative scores, saving and answer matching"
    },
    howToPlaySections: [
      {
        heading: "Picking any tile in any order",
        items: [
          "Pick any tile on the board, in any order you like."
        ]
      },
      {
        heading: "Reading the clue and typing an answer",
        items: [
          "Read the clue and type your answer in the box."
        ]
      },
      {
        heading: "Scoring right and wrong answers",
        items: [
          "Correct answers add the tile's value to your score. Wrong answers subtract it."
        ]
      },
      {
        heading: "Deferring a clue for free",
        items: [
          "Not sure? Close the clue and come back later, deferring is free."
        ]
      },
      {
        heading: "Finishing all the tiles and sharing your grid",
        items: [
          "Answer all 25 tiles to finish the board and share your result grid."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Five categories and their rising tile values",
        items: [
          "The board is 5 categories with clues at $200, $400, $600, $800 and $1,000 each, 25 tiles total."
        ]
      },
      {
        heading: "Going negative on a wrong answer",
        items: [
          "Wrong answers subtract the full tile value, and your score can go negative."
        ]
      },
      {
        heading: "The same board for everyone each day",
        items: [
          "Everyone gets the same board each day, and your progress saves so you can finish later."
        ],
        subsections: [
          {
            heading: "How forgiving the answer matching is",
            items: [
              "Answer matching is forgiving: surnames of 4 or more letters count, and accents and punctuation are ignored."
            ]
          }
        ]
      }
    ],
    exampleSections: [
      {
        heading: "An easy Ballon d'Or clue in the top row",
        paragraphs: [
          "Say you open a $200 tile in a Ballon d'Or category and it asks for a very recent winner. Easy money. Emboldened, you jump straight to the $1,000 in the same column and meet a winner from decades before you were born."
        ]
      },
      {
        heading: "A costly miss in the deepest tile",
        paragraphs: [
          "You type a surname, it's wrong, and $1,000 evaporates. The lesson sticks: the big tiles reach way back in time, and they're priced that way for a reason."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Sweeping the cheap rows for a cushion",
        items: [
          "Sweep the $200 and $400 rows first to build a cushion before touching the deep cuts."
        ]
      },
      {
        heading: "Using the clock free deferral",
        items: [
          "There's no timer. Close a hard clue, let it stew, and circle back."
        ]
      },
      {
        heading: "Typing surnames instead of full names",
        items: [
          "Type surnames. Full names are only needed when a surname alone is ambiguous."
        ]
      },
      {
        heading: "Respecting the priciest row",
        items: [
          "Respect the $1,000 row. High value means old and obscure, and a miss stings double."
        ]
      }
    ],
    faqs: [
      {
        q: "Can my score really go negative?",
        a: "Yes. Every wrong answer subtracts the tile's value, so a reckless board can finish below zero."
      },
      {
        q: "Do I have to finish in one sitting?",
        a: "No. The day's board and your answers are saved in your browser, so you can leave and pick it up later the same day."
      },
      {
        q: "How strict is the answer box?",
        a: "Pretty relaxed. Capitals, accents and punctuation don't matter, and a surname works when it's 4 or more letters and points to one answer."
      }
    ]
  },
  "/ball-iq": {
    intro: [
      "Twelve questions, ramping from layups to half-court heaves, and at the end a number that claims to measure your sports brain. Ball Knowledge IQ is the daily settle-the-argument machine.",
      "The catch is the weighting. The hard questions at the end are worth the most, so a hot start means nothing if you faceplant on the deep cuts."
    ],
    headings: {
      howToPlay: "How to play Ball Knowledge IQ, a free twelve question sports quiz",
      rules: "Ball Knowledge IQ rules for weighting, ranks and the daily set",
      example: "Ball Knowledge IQ walkthrough: a hot start and a rough finish",
      tips: "Ball Knowledge IQ tips for the back half and eliminating options",
      faq: "Ball Knowledge IQ FAQ: the highest score, weighting and daily play"
    },
    howToPlaySections: [
      {
        heading: "Answering twelve multiple choice questions",
        items: [
          "Answer 12 multiple-choice questions, four options each."
        ]
      },
      {
        heading: "Grading each pick instantly",
        items: [
          "Each pick is graded instantly, green for right, red for wrong, then move on."
        ]
      },
      {
        heading: "Escalating from recent to decades old",
        items: [
          "The questions escalate: recent, famous stuff early, decades-old deep cuts late."
        ]
      },
      {
        heading: "Finishing for an IQ score and rank",
        items: [
          "Finish all 12 to get your IQ score and your rank."
        ]
      },
      {
        heading: "Sharing your squares to challenge a friend",
        items: [
          "Copy the share squares and challenge someone who claims they know ball."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "The fixed ramp of twelve questions",
        items: [
          "The 12 questions follow a fixed ramp: 3 easy, 3 medium, then pairs at rising weights up to the two hardest at the end."
        ]
      },
      {
        heading: "Why the hardest questions move your IQ most",
        items: [
          "Your IQ runs from 55 to 160 and is weighted by question value, so the hard ones move it most."
        ],
        subsections: [
          {
            heading: "The six IQ ranks from casual to certified",
            items: [
              "Ranks: 145 and up is Certified ball knower, 125 is Knows ball, 105 is Solid ball knowledge, 85 is Casual, 70 is Knows of ball, and below that, Does not know ball."
            ]
          }
        ]
      },
      {
        heading: "The same twelve questions every day",
        items: [
          "Everyone gets the same 12 questions each day, and progress saves for the day."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Cruising through the first nine questions",
        paragraphs: [
          "Imagine you cruise through the first nine, recent champions and famous MVPs, no sweat. Then the last two questions ask about winners from long before your time, and you miss both."
        ]
      },
      {
        heading: "Missing the two heaviest questions at the end",
        paragraphs: [
          "Ten of twelve sounds elite, but those were the two heaviest questions on the test. You land around 128, Knows ball. The gap to Certified lives in the deep end."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Budgeting your focus for the back half",
        items: [
          "Budget your focus for the back half. The final questions swing your IQ more than the first six combined."
        ]
      },
      {
        heading: "Eliminating wrong options by detail",
        items: [
          "Wrong options come from the same category and era as the answer, so eliminate by detail, not by vibe."
        ]
      },
      {
        heading: "Shaking off an early red answer",
        items: [
          "A red early answer changes nothing about the questions ahead, so shake it off."
        ]
      }
    ],
    faqs: [
      {
        q: "What is the highest possible IQ?",
        a: "160, which needs a perfect 12 for 12. An all-wrong day scores the floor of 55."
      },
      {
        q: "Why did missing an easy one barely move my score?",
        a: "Scoring is weighted by difficulty. Early questions carry small weights, the final pair the biggest, so the deep cuts decide the number."
      },
      {
        q: "Is it the same test for everyone?",
        a: "Yes, same 12 questions in the same order for everyone each day, which is exactly what makes the share squares worth arguing over."
      }
    ]
  },
  "/emoji-guess": {
    intro: [
      "Can you read football in emoji? Emoji Guess serves five riddles a day, each one a player, club, manager or iconic moment told entirely in little pictures.",
      "Some solve themselves at a glance. Others sit there smugly until the hint arrives and you groan out loud. Five puzzles, three guesses each, and a colored grid to prove how you did."
    ],
    headings: {
      howToPlay: "How to play Emoji Guess, a free daily football emoji trivia game",
      rules: "Emoji Guess rules for scoring, hints and the daily reset",
      example: "Emoji Guess walkthrough: a goat emoji and a cherry emoji",
      tips: "Emoji Guess tips for reading categories and catching puns",
      faq: "Emoji Guess FAQ: accepted answers, scoring and other sports"
    },
    howToPlaySections: [
      {
        heading: "Reading the emoji string and its category",
        items: [
          "Look at the emoji string and the category label above it."
        ]
      },
      {
        heading: "Typing a forgiving surname answer",
        items: [
          "Type your answer. Surnames are fine and spelling is forgiving on accents."
        ]
      },
      {
        heading: "Unlocking a hint after a miss",
        items: [
          "Miss once and a written hint appears under the emoji."
        ]
      },
      {
        heading: "Getting three guesses per puzzle",
        items: [
          "You get 3 guesses per puzzle before the answer is revealed."
        ]
      },
      {
        heading: "Clearing five puzzles and sharing your grid",
        items: [
          "Clear all 5 puzzles, then share your grid of green, yellow, orange and red squares."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Five puzzles at rising difficulty",
        items: [
          "Each day serves 5 puzzles: 2 easy, 2 medium and 1 hard, the same set for everyone."
        ]
      },
      {
        heading: "How the tiered scoring works",
        items: [
          "Scoring per puzzle: 100 points on the first guess, 60 on the second, 30 on the third, 0 for a miss. A perfect day is 500."
        ],
        subsections: [
          {
            heading: "What the hint actually costs you",
            items: [
              "The hint appears after your first wrong guess, at no extra cost beyond the tier you already dropped."
            ]
          }
        ]
      },
      {
        heading: "When the daily set resets",
        items: [
          "The set flips at midnight Eastern Time, and your progress saves for the day."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Solving a goat next to an Argentina flag",
        paragraphs: [
          "Suppose puzzle one is a goat next to an Argentina flag, category Player. You type Messi, first try, 100 points. Puzzle two is a single cherry with the category Club, and you sit there blank."
        ]
      },
      {
        heading: "Cracking a single cherry after a hint",
        paragraphs: [
          "One wrong guess later the hint mentions England's south coast, and it clicks: Bournemouth, the Cherries, 60 points. That's the game in miniature, instant glory or a slow, hint-assisted crawl."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Reading the category label before the emoji",
        items: [
          "Read the category label first. The same emoji means different things for a club than for a moment."
        ]
      },
      {
        heading: "Thinking about crests for club puzzles",
        items: [
          "Club puzzles usually run on nicknames and badges, so think about what's on the crest."
        ]
      },
      {
        heading: "Saying the emoji out loud for puns",
        items: [
          "Say the emoji out loud. Half these riddles are puns that only work in your ears."
        ]
      },
      {
        heading: "Guessing on your last try rather than waiting",
        items: [
          "Down to your last guess, wait for nothing. A 30 beats a zero and keeps the grid respectable."
        ]
      }
    ],
    faqs: [
      {
        q: "What answers are accepted?",
        a: "The full name, common aliases, or a surname on its own. Accents, capitals and punctuation are ignored, so mbappe works fine."
      },
      {
        q: "Do wrong guesses cost points?",
        a: "Only by dropping you a tier. First-guess solves score 100, second 60, third 30, and three misses score 0 for that puzzle."
      },
      {
        q: "Is it only football?",
        a: "Yes, this one is all football: players, clubs, managers and famous moments from the game."
      }
    ]
  },
  "/mystery-box": {
    intro: [
      "Your squad is sitting inside fifteen sealed packs. Mystery Box reveals real footballers one at a time, and you either slot them into your 4-3-3 or bin them and pray the next pack is kinder.",
      "Everyone opens the same packs each day, so luck is no excuse. The gap between your rating and your mate's is pure decision-making."
    ],
    headings: {
      howToPlay: "How to play Mystery Box, a free football pack opening XI builder",
      rules: "Mystery Box rules for bins, pack odds and empty slots",
      example: "Mystery Box walkthrough: an early superstar and a fringe keeper",
      tips: "Mystery Box tips for bins, scarce slots and safe picks",
      faq: "Mystery Box FAQ: pack order, replays and a good rating"
    },
    howToPlaySections: [
      {
        heading: "Opening packs one at a time",
        items: [
          "Open packs one at a time, 15 in total."
        ]
      },
      {
        heading: "Reading a pack's player and tier",
        items: [
          "Each pack reveals a real player with his club, position, rating and market value, plus a tier from fringe to superstar."
        ]
      },
      {
        heading: "Keeping a player in a compatible slot",
        items: [
          "Keep him by tapping a highlighted compatible slot in your 4-3-3."
        ]
      },
      {
        heading: "Binning a player if you can afford it",
        items: [
          "Or bin him, if you can afford to."
        ]
      },
      {
        heading: "Sharing your final rating and best pull",
        items: [
          "After pack 15, your final XI rating and best pull are ready to share."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "How many bins you can actually afford",
        items: [
          "You open 15 packs to fill 11 slots, which means you can only afford 4 bins all run."
        ]
      },
      {
        heading: "The pack odds behind each tier",
        items: [
          "Pack odds per tier: superstar 3 percent, star 9, quality 22, squad player 41, fringe 25."
        ],
        subsections: [
          {
            heading: "Why an empty slot costs you so much",
            items: [
              "Your rating averages all 11 slots, and an empty slot counts as a 45, below even the weakest real player."
            ]
          }
        ]
      },
      {
        heading: "One saved run per day",
        items: [
          "One run per day, the same sequence for everyone, saved as you go."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Keeping an early superstar winger",
        paragraphs: [
          "Imagine pack 2 pops a superstar winger. Instant keep at right wing. Packs 3 through 7 are squad-level bodies, and you bin two chasing better, leaving 2 bins for the rest of the run."
        ]
      },
      {
        heading: "Settling for a fringe goalkeeper pick",
        paragraphs: [
          "Then pack 9 is a fringe goalkeeper. Keeping him feels bad, but there's one goalkeeper slot and no guarantee anything better is coming. You keep him and finish with a full XI in the low 70s."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Counting your bins before you spend them",
        items: [
          "Count your bins. Spend all 4 early and every remaining pack becomes a forced keep."
        ]
      },
      {
        heading: "Guarding the scarcest slots on the pitch",
        items: [
          "Guard the scarce spots. There's one goalkeeper slot and one striker slot, but three central midfield slots."
        ]
      },
      {
        heading: "Filling a hole with a fringe body",
        items: [
          "A fringe body still beats a hole. Empty slots score 45, lower than any real player."
        ]
      },
      {
        heading: "Not betting solid players on a superstar pull",
        items: [
          "Superstars are a 3 percent event. Don't bin solid players betting on one."
        ]
      }
    ],
    faqs: [
      {
        q: "Are the packs random for each player?",
        a: "No, the sequence is fixed for the day. Everyone opens the same 15 players in the same order, only the decisions differ."
      },
      {
        q: "Can I replay if my run goes badly?",
        a: "No, it's one run per day. Decisions save as you go, and a fresh sequence arrives tomorrow."
      },
      {
        q: "What counts as a good rating?",
        a: "Most finished squads land in the 60s or 70s. Higher usually means you landed a superstar and filled all 11 slots."
      }
    ]
  },
  "/idle-arena": {
    intro: [
      "This is the idle game the word usually means. Tap a ball and a number goes up. Spend the number on a squad and it goes up on its own. Spend what the squad makes on a bigger squad, and by the time you look up the number has more letters after it than you expected. There is no end and no losing, just a curve that keeps steepening.",
      "Nobody in the arena is real. The squad is eight archetypes, a Ball Boy, a Sunday Striker, a Point Guard, a Slugger, a Sniper, a Quarterback, an Ace and a Champion, so there is no stat to check and nothing to argue about. That is on purpose: our other three idle games give you a museum, a club or an academy to run, and this one is built on nothing but the number."
    ],
    headings: {
      howToPlay: "How to play Idle Arena, a free tap and build idle sports game",
      rules: "Idle Arena rules for pricing, trophies and time away",
      example: "Idle Arena walkthrough: building a squad and lifting a trophy",
      tips: "Idle Arena tips for pricing, upgrades and time away",
      faq: "Idle Arena FAQ: the endgame, time away and real players"
    },
    howToPlaySections: [
      {
        heading: "Tapping the ball to score points",
        items: [
          "Tap the ball. Every tap scores a point, more once you own the tap upgrades."
        ]
      },
      {
        heading: "Signing a squad that scores every second",
        items: [
          "Sign a squad. Each archetype scores every second, from 0.4 a second for a Ball Boy up to 176,000 a second for a Champion."
        ]
      },
      {
        heading: "Speeding up buys with the toggle",
        items: [
          "Switch the buy toggle to x10 or max when the points are coming faster than you can spend them."
        ],
        subsections: [
          {
            heading: "Unlocking a whole line's bonus",
            items: [
              "Own five of an archetype and its own upgrade appears. Buy it and that whole line scores double."
            ]
          }
        ]
      },
      {
        heading: "Lifting the trophy for a boost that carries over",
        items: [
          "Earn a million in one run and the trophy box lights up. Lift it, the run resets, and every trophy you hold is +5% on everything from then on."
        ]
      },
      {
        heading: "Spending trophies in the trophy room",
        items: [
          "Open the trophy room and spend trophies on perks that never go away. A spent trophy stops paying its 5%, so each perk is a trade, not a free gift."
        ]
      },
      {
        heading: "Earning points while you are away",
        items: [
          "Walk away whenever you like. The squad keeps scoring at half speed for up to eight hours, whether you closed the tab or left it sitting there, and the door tells you what it made when you come back."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Your first archetype costing nothing",
        items: [
          "Your first Ball Boy is free, so something is always scoring, even for somebody who never taps at all."
        ]
      },
      {
        heading: "Costs climbing with every signing",
        items: [
          "Every archetype you sign costs 15% more than the last one of its kind. A Ball Boy costs 15, the tenth one costs 53, the hundredth costs about 15 million."
        ]
      },
      {
        heading: "How trophies are priced by points earned",
        items: [
          "Trophies are paid on points earned in one run, not on points in hand. One trophy at a million, two at four million, three at nine million: the square root of the millions, rounded down."
        ],
        subsections: [
          {
            heading: "What survives a trophy lift",
            items: [
              "Lifting the trophy clears the points, the squad and the upgrades. Trophies, trophy room perks, badges and the all time total are the only things that carry over, and they carry over forever."
            ]
          }
        ]
      },
      {
        heading: "What each perk costs and does",
        items: [
          "Four perks, each with three levels that cost 3, 5 and 8 trophies. Long Night stretches time away from 8 hours to 16, 20 and then 24 hours. Night Shift makes time away run at 70%, 80% and then 95% speed instead of 50%.",
          "Head Start puts a squad on the payroll the moment you lift: 25 Ball Boys and 10 Sunday Strikers at the first level, up to 25 Ball Boys, 25 Sunday Strikers, 25 Point Guards and 10 Sluggers at the third. Scouting Network makes each Sniper, Quarterback, Ace and Champion cost 11%, 8% and then 5% more than the last instead of 15%."
        ]
      },
      {
        heading: "Earning badges from tapping and trophies",
        items: [
          "Ten badges, each worth a permanent +1% on everything. They are earned by tapping, by squad size, by points and by trophies, and they survive every lift."
        ]
      },
      {
        heading: "Away time running at a slower pace",
        items: [
          "Time away runs at half speed and stops after eight hours. That is the same eight hours whether the tab was shut or just sitting in a background window, because being there is what matters, not the tab being open.",
          "Long Night and Night Shift from the trophy room change those two numbers, and nothing else about the rule: one cap for the whole absence, and never full speed."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Building toward your first bigger archetype",
        paragraphs: [
          "You tap eighteen times and sign a second Ball Boy. Two of them make 0.8 a second, which pays for a third in about twenty five seconds, and the three of them save toward a Sunday Striker at 100. Ten minutes in, the squad makes more in a second than your first minute of tapping did."
        ]
      },
      {
        heading: "Reaching the trophy and lifting it",
        paragraphs: [
          "Fifteen or twenty minutes of steady buying gets a run past a million, which is the first trophy. Lift it and the arena empties, but every tap and every archetype now scores 5% more, so the second run reaches the same million faster than the first did, and the third faster still."
        ]
      },
      {
        heading: "Worked example: picking your first perk",
        paragraphs: [
          "Say you hold 30 trophies, which is +150% on everything. Spend 3 of them on Night Shift and you hold 27, so everything scores +135% instead, but every night away now pays at 70% speed rather than 50%. For somebody who leaves it running overnight that is the better deal: the next trophy comes about 15% sooner. For somebody who sits there tapping and never leaves, it is the worse one, because the squad just scores less. Head Start is the reverse: it suits the quick tapping runs and does little for the long nights."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Comparing rate against price before buying",
        items: [
          "Read the rate against the price, not the price alone. A new archetype pays back slower than the tier below it at first, but the tier below has been getting 15% dearer with every signing, so the moment always comes when the bigger name is the better buy."
        ]
      },
      {
        heading: "Reaching the upgrade point for a whole line",
        items: [
          "Five of anything is the magic number. That archetype's upgrade doubles the whole line, so buy to five before you spread out."
        ]
      },
      {
        heading: "Turning taps into squad power",
        items: [
          "Muscle Memory turns taps into a share of the squad's rate. Once the squad is scoring thousands a second, it is the best tap upgrade on the board."
        ]
      },
      {
        heading: "Timing the lift and an overnight run",
        items: [
          "Do not lift at exactly one trophy. Four million pays two, nine million pays three, and the run you are in already has the squad built.",
          "Leave it running before bed. Eight hours at half speed is four hours of income you did not have to be there for."
        ]
      },
      {
        heading: "Picking a perk for the way you play",
        items: [
          "Buy the perk that matches how you actually play. Back once a day: Long Night. Back every morning: Night Shift. Quick tapping runs: Head Start. Long runs where you sign dozens of the top archetypes: Scouting Network. If you tap through every run and never leave, the two away perks do nothing for you, so leave them on the shelf.",
          "The second and third levels cost more than the first, so they pay best once you hold a big cabinet."
        ]
      }
    ],
    faqs: [
      {
        q: "Is there an end to Idle Arena?",
        a: "No. The number keeps growing and the trophies keep stacking. The formatter goes up through K, M, B, T and onward, and the eighth archetype is only the last one we have named so far."
      },
      {
        q: "Does it keep going when I close the tab?",
        a: "Yes, at half speed for up to eight hours, or longer and faster once you buy Long Night or Night Shift in the trophy room. Leaving the tab open in the background is the same deal, because a hidden tab stops running properly anyway. The catch up is worked out from the time your last session saved, so switching phones will not carry it over, but reopening the same browser will."
      },
      {
        q: "Why are there no real players in it?",
        a: "Because a clicker does not need them, and the ones that use real names tend to get the numbers wrong. Our other idle games, Hall of Champions, Stadium Tycoon and Wonderkid Factory, give you something to manage. This one is just the curve."
      },
      {
        q: "Where is the save kept?",
        a: "In your browser, on this device, with no account. It is written every five seconds and again when you leave the page. Clearing site data clears the arena."
      }
    ]
  },
  "/face-off": {
    intro: [
      "Higher or Lower with somebody in the other chair. Two athletes, one career stat, and ten seconds to tap the one with the bigger number. A rival answers every round too, at its own speed, with its own hit rate, and after ten rounds the scoreboard says who knows ball.",
      "The pairs come from every corner of the site: soccer goals, NBA points, home runs, six different NFL stats, NHL points, college passing yards, F1 wins, Grand Slams, golf majors and VFL/AFL goals, never the same sport twice in a row. Every number is a career total that is already on the site in a Higher or Lower game, so nothing was made up for the duel."
    ],
    headings: {
      howToPlay: "How to play Face Off, a free head to head sports stat trivia duel",
      rules: "Face Off rules for scoring, rivals and passing the phone",
      example: "Face Off walkthrough: a tied round and a late buzzer win",
      tips: "Face Off tips for speed, deep pools and picking a rival",
      faq: "Face Off FAQ: the rivals, the daily duel and two player mode"
    },
    howToPlaySections: [
      {
        heading: "Choosing the daily duel, unlimited or pass the phone",
        items: [
          "Pick the daily duel, which is the same ten pairs against The Pro for everyone, Unlimited, where you choose your rival, or Pass the phone, where the rival is whoever is sitting next to you."
        ]
      },
      {
        heading: "Tapping the athlete with the bigger number",
        items: [
          "Read the stat and the two names, then tap the athlete with the bigger number."
        ]
      },
      {
        heading: "Racing the ten second clock",
        items: [
          "Watch the bar. Ten seconds a round, and a right answer scores 100 plus 10 for every whole second you had left."
        ]
      },
      {
        heading: "Reading the reveal after each round",
        items: [
          "The reveal shows both numbers, what the rival picked and how long it took."
        ]
      },
      {
        heading: "Winning after ten rounds or sudden death",
        items: [
          "After ten rounds the higher total wins. Level on points and it goes to sudden death, up to three extra rounds."
        ]
      }
    ],
    ruleSections: [
      {
        heading: "Why a guess always beats no answer",
        items: [
          "Wrong scores nothing. Out of time scores nothing. There is no penalty beyond that, so a guess at the buzzer is always better than no answer."
        ]
      },
      {
        heading: "Facing the same rival performance as everyone",
        items: [
          "The rival is dealt its answers with the pairs, so in the daily duel everyone faces exactly the same rival performance. Beating a friend's score is beating them on the same ten questions."
        ]
      },
      {
        heading: "Three rivals with three different speeds",
        items: [
          "Three rivals. The Rookie takes 3 to 8 seconds and guesses the close ones. The Pro takes 2 to 6 and is sharp on the obvious pairs. The Legend answers inside 5 seconds and almost never misses a wide gap."
        ],
        subsections: [
          {
            heading: "How close a pair is allowed to be",
            items: [
              "No pair is a tie and no pair is a gimme: the bigger number is always at least 4% more than the smaller and never more than 4 times it."
            ]
          }
        ]
      },
      {
        heading: "No repeats within one duel",
        items: [
          "No athlete appears twice in one duel, and the daily can only be played once. Unlimited never runs out."
        ]
      },
      {
        heading: "Passing the phone between two players",
        items: [
          "Pass the phone is two people on one device. Player 1 answers, the pair is hidden while the phone changes hands, Player 2 presses ready to start their own ten seconds, and both picks are revealed together. It is a game between the two of you and it is not booked to your record against the rivals."
        ]
      }
    ],
    exampleSections: [
      {
        heading: "Matching The Pro on career points",
        paragraphs: [
          "Round one: who has more career NBA points, Kareem Abdul-Jabbar or Kobe Bryant. You tap Kareem with six seconds left, which is right, 160 points. The Pro took 3.4 seconds and got it too, 160 points. All square."
        ]
      },
      {
        heading: "Missing together and closing out the lead",
        paragraphs: [
          "Round four is Formula 1 wins and you hesitate, then miss. The Pro misses too, so the round is 0 to 0 and the lead never changes hands. Round nine you tap Gordon Coventry at the buzzer, right with one second left, 110 points. Ten rounds later you have won by 30, because you were right as often and a shade faster."
        ]
      }
    ],
    tipSections: [
      {
        heading: "Treating speed as the second stat",
        items: [
          "Speed is the second stat. Two people who both know the answer are separated by the clock, and a second is ten points."
        ]
      },
      {
        heading: "Not freezing on the close calls",
        items: [
          "Do not freeze on the close ones. A wrong answer costs nothing more than a late one, and the rival is guessing those too."
        ]
      },
      {
        heading: "Learning the deep ends of each pool",
        items: [
          "Learn the deep ends of each pool. The wide gaps are free points; the duel is decided on the pairs where both names are legends."
        ]
      },
      {
        heading: "Trying the daily match before the Rookie",
        items: [
          "Play the daily first. It is against The Pro every day, so your score means the same thing tomorrow and to everyone else.",
          "Start Unlimited against The Rookie and move up when you are winning three in a row. The Legend is there to be beaten, not to be your first game."
        ]
      }
    ],
    faqs: [
      {
        q: "Is the rival a real person?",
        a: "No. The Rookie, The Pro and The Legend are three settings for how fast and how often the computer gets it right, tuned so a decent fan beats the Rookie most of the time and loses to the Legend most of the time. Nobody is playing against you live."
      },
      {
        q: "Is the daily duel the same for everyone?",
        a: "Yes. The ten pairs, the order, and the rival's answers and times are all dealt from the date, so anyone playing today faces exactly the same duel. It rolls over at midnight Eastern like the rest of our dailies."
      },
      {
        q: "Where do the numbers come from?",
        a: "From the same pools our Higher or Lower games use, one per sport. Nothing was added for this game, so if a number is right there it is right here, and if you spot one that is wrong the report button at the bottom of the page reaches us."
      },
      {
        q: "Can two people play?",
        a: "Yes. Pass the phone deals the same ten pairs to both of you, one at a time. Player 1 picks, hands the phone over, Player 2 picks on their own clock, and the reveal shows both. Nobody can see the other pick before their own, because the cards stay hidden during the handoff."
      },
      {
        q: "What happens on a tie?",
        a: "Level on points after ten rounds and you play sudden death, one pair at a time, until somebody leads. If it is still level after three extra rounds it goes down as a draw."
      }
    ]
  }
};

// src/data/gameContent/index.ts
var GAME_CONTENT = {
  ...ACADEMY_MANAGEMENT_CONTENT,
  ...AUSSIE_RULES_MANAGEMENT_CONTENT,
  ...STADIUM_MANAGEMENT_CONTENT,
  ...CLUB_MANAGEMENT_CONTENT,
  ...SOCCER_CONTENT_1,
  ...SOCCER_CONTENT_2,
  ...FOOTBALL_CONTENT,
  ...COLLEGE_CONTENT,
  ...BASKETBALL_CONTENT,
  ...BASEBALL_CONTENT,
  ...HOCKEY_CONTENT,
  ...MORE_SPORTS_CONTENT,
  ...WORLD_CONTENT
};

// src/data/gameContent/guideShape.ts
var sectionItems = (sections) => sections.flatMap((s) => [...s.items, ...(s.subsections ?? []).flatMap((sub) => sub.items)]);
function flatGuide(content) {
  return {
    howToPlay: content.howToPlaySections ? sectionItems(content.howToPlaySections) : content.howToPlay,
    rules: content.ruleSections ? sectionItems(content.ruleSections) : content.rules,
    example: content.exampleSections ? content.exampleSections.flatMap((s) => s.paragraphs) : content.example,
    tips: content.tipSections ? sectionItems(content.tipSections) : content.tips
  };
}

// src/data/gameRegistry.ts
var CATEGORIES = [
  {
    title: "Soccer",
    emoji: "\u26BD",
    games: [
      // retired 2026-07-06 per owner review: "too simple". Page/route kept for direct links; uncomment to revive.
      // { path: '/higher-lower-transfers', label: 'Transfer Market', emoji: '📈', description: 'Higher or lower on real market values', isNew: true },
      // Darts, Stadium Draft, Blind Rank and Start Bench Cut deleted 2026-07-15
      // per owner review (broken/low-effort). Pages, routes and libs removed entirely.
      { path: "/budget-builder", label: "$1B Budget Builder", emoji: "\u{1F4B5}", description: "One billion dollars, real values, eleven slots. Spend it well", addedOn: "2026-07-21" },
      { path: "/rebuild", label: "Rebuild Challenge", emoji: "\u{1F527}", description: "Inherit a real club. Open the envelopes, spin for a shirt, keep him or sell him, answer to the board", addedOn: "2026-07-21" },
      // deleted 2026-08-05 per owner review: "dosent even load and it's just like their tier list game... please delete it".
      // { path: '/grade-transfer', label: 'Grade the Transfer', emoji: '📋', description: 'Grade five real moves A to F, then see how they aged', daily: true, isNew: true },
      { path: "/dart-draft", label: "Dart Draft", emoji: "\u{1F3AF}", description: "Throw timed darts at a real world map: hit a country, draft its players", addedOn: "2026-07-10" },
      { path: "/career-ladder", label: "Career Ladder", emoji: "\u{1FA9C}", description: "Guess the player, one career stop at a time", addedOn: "2026-07-01" },
      { path: "/who-am-i", label: "Who Am I?", emoji: "\u{1F575}\uFE0F", description: "Hunt the secret player with similarity scores", addedOn: "2026-07-02" },
      { path: "/club-manager", label: "Club Manager", emoji: "\u{1F4BC}", description: "Manage any of 438 real clubs across 26 leagues, today or in a real past season: negotiations, board objectives, trophies and the sack race", addedOn: "2026-07-09", featured: true },
      { path: "/manager-hot-seat", label: "Manager Hot Seat", emoji: "\u{1FA91}", description: "Take over a real club on a bad run. Five league games to hit the board's target or you are sacked", daily: true, addedOn: "2026-09-30" },
      { path: "/deadline-day", label: "Deadline Day", emoji: "\u23F0", description: "Run recruitment at a real club on the last day of the window. Fill the board's needs before it shuts, without overpaying", daily: true, addedOn: "2026-10-01" },
      { path: "/soccer-conquest", label: "Soccer Conquest", emoji: "\u{1F5FA}\uFE0F", description: "Imperialism across the top five leagues: 96 clubs on one map of Europe, winners annex whole empires until one club rules the continent", daily: true, addedOn: "2026-09-05" },
      { path: "/stadium-tycoon", label: "Stadium Tycoon", emoji: "\u{1F3DF}\uFE0F", description: "Idle empire: grow a tiny club through live toy matches, ten divisions, reputation stars and a legacy boardroom", addedOn: "2026-08-17" },
      { path: "/wonderkid-factory", label: "Wonderkid Factory", emoji: "\u{1F52D}", description: "Idle academy: scout generated kids, grow them toward hidden ceilings and sell at the perfect moment", addedOn: "2026-08-21" },
      { path: "/contract-chaos", label: "Contract Chaos", emoji: "\u{1F4DD}", description: "Be the agent: compare wages, role and release clauses, sign one deal, then live with five seasons", daily: true, addedOn: "2026-09-30" },
      { path: "/world-xi", label: "World XI", emoji: "\u{1F30D}", description: "Pick a formation, fill 11 random countries", addedOn: "2026-07-02" },
      { path: "/player-bingo", label: "Player Bingo", emoji: "\u{1F3B1}", description: "Complete a line on a 5x5 board before 3 strikes", addedOn: "2026-07-02" },
      { path: "/sports-bingo", label: "Sports Bingo", emoji: "\u{1F3AB}", description: "Open packs of real players on a timer, mark the squares they satisfy", daily: true, addedOn: "2026-08-29" },
      { path: "/alphabet-sprint", label: "Alphabet Sprint", emoji: "\u26A1", description: "Name a player per letter against the clock", addedOn: "2026-07-02" },
      { path: "/clue-auction", label: "Clue Auction", emoji: "\u{1F4B0}", description: "Buy clues, save points, name the secret player", addedOn: "2026-07-02" },
      // Revived 2026-07-15. Retired 2026-07-06 as "you guess one guy and you're
      // done", root cause found: scoreRound was INVERTED for rarity mode, so
      // naming the most famous player in the pool scored a perfect 0 and the
      // winning strategy was the opposite of the premise. Fixed, plus the board
      // reveal (what the rarest answer actually was) is now shown after every
      // round, which is the real payoff of a rarity game and was missing entirely.
      // Overrated or Underrated and Tier List deleted 2026-08-28 per owner
      // review: "two buttons, no game feel" and "same reasoning, and only one
      // list ever playable". Routes redirect (/face-off and home), pages,
      // hooks, components and pool fetch removed, crowd vote tables left in
      // the database for the desktop lane's backend audit to drop or keep.
      { path: "/rarity-round", label: "Rarity Round", emoji: "\u{1F48E}", description: "Name the answer nobody else would. Rarest wins", daily: true, addedOn: "2026-07-03" },
      { path: "/missing-xi", label: "Missing XI", emoji: "\u{1F9E9}", description: "Name the missing player from a famous real lineup", daily: true, addedOn: "2026-07-03" },
      { path: "/sign-the-player", label: "Sign the Player", emoji: "\u{1F528}", description: "A blind auction: outbid two AI moguls, \xA31B each, then sim the showdown", addedOn: "2026-07-03" },
      { path: "/footle", label: "Footle", emoji: "\u{1F3AF}", description: "Guess the soccer player from stats", addedOn: "2025-01-01" },
      { path: "/career", label: "Career Quiz", emoji: "\u{1F4DC}", description: "Guess from career history", addedOn: "2026-02-09" },
      { path: "/higher-lower", label: "Soccer Higher or Lower", emoji: "\u{1F4CA}", description: "Compare all-time career stats", addedOn: "2026-02-09" },
      { path: "/connections", label: "Soccer Connections", emoji: "\u{1F517}", description: "Find groups of 4 connected players", addedOn: "2026-02-09" },
      { path: "/build-your-xi", label: "Build Your XI", emoji: "\u26BD", description: "Create a lineup, get AI rated", addedOn: "2026-02-09" },
      // deleted 2026-08-05 per owner review: "Delete perfect lineup."
      // { path: '/perfect-lineup', label: 'Perfect Lineup', emoji: '⚽', description: 'Build an XI under random league & country constraints, then simulate', daily: true, isNew: true },
      { path: "/football-connect-4", label: "Soccer Connect 4", emoji: "\u{1F534}", description: "Soccer trivia meets Connect 4", addedOn: "2026-02-10" },
      // Revived 2026-07-22. Was deleted 2026-07-08 as "buggy (hint x3 -> blank
      // screen) and too few possible puzzles for a rare event". The bug is
      // root-caused and fixed (useWorldCup.ts: the Answer clue was reachable
      // mid-game, and daily gated on MAX_CLUES=7 vs the real 6 for host-nation
      // puzzles, Beckenbauer/Kempes/Schillaci/Zidane/Klose/Neymar, 9 of 60).
      // The content objection is answered by relaunching UNLIMITED-FIRST (no
      // daily flag here, page defaults to unlimited): 60 puzzles is thin as a
      // headline daily but plenty as a replayable archive.
      // deleted 2026-08-05 per owner review: "Delete World Cup legends too."
      // { path: '/world-cup', label: 'World Cup Legends', emoji: '🏆', description: 'Guess the World Cup legend, clue by clue', isNew: true },
      // deleted 2026-08-05 per owner review: "Delete guess the club."
      // { path: '/guess-soccer-club', label: 'Guess The Club', emoji: '🏟️', description: 'Identify the mystery football club', daily: true, isNew: true },
      { path: "/free-kick", label: "Free Kick", emoji: "\u{1F945}", description: "Aim it, bend it, beat the wall and the keeper", daily: true, addedOn: "2026-09-04" },
      { path: "/soccer-grid", label: "Soccer Grid", emoji: "\u26BD", description: "3\xD73 grid puzzle with rarity scores", daily: true, addedOn: "2026-03-08" },
      { path: "/world-cup-bracket", label: "World Cup 2026 Bracket", emoji: "\u{1F30D}", description: "Build the 2026 bracket and score it against how the World Cup really went", addedOn: "2026-03-28" },
      { path: "/soccer-career", label: "Soccer Career", emoji: "\u26BD", description: "Create your look, sign for your boyhood club, get rich, get shady, retire a legend.", addedOn: "2026-03-28", featured: true },
      { path: "/fantasy-draft", label: "Fantasy Draft", emoji: "\u{1F9D1}\u200D\u{1F4BC}", description: "Draft your ultimate XI against an AI opponent", addedOn: "2026-03-09" },
      // deleted 2026-07-08 per owner review: too easy/boring. Route kept for direct links; uncomment to revive.
      // { path: '/shirt-number', label: 'Shirt Number', emoji: '👕', description: 'Guess the kit number a player wears', daily: true, isNew: true },
      { path: "/transfer-path", label: "Transfer Path", emoji: "\u{1F504}", description: "Connect two players through shared clubs", daily: true, addedOn: "2026-04-10" },
      // deleted 2026-08-05 per owner review: "Guess the value [doesn't] even load and I would say u should delete it."
      // { path: '/guess-transfer-value', label: 'Guess The Value', emoji: '💰', description: 'Guess a player's transfer market value', daily: true, isNew: true },
      // moved from the retired Game Shows tab 2026-07-08 (owner: game-show games belong in their sport)
      { path: "/squad-deal", label: "Squad Deal", emoji: "\u{1F3DF}\uFE0F", description: "Build an XI out of mystery boxes", addedOn: "2026-06-23" },
      { path: "/search-and-discard", label: "Search and Discard", emoji: "\u{1F50E}", description: "The squad duel: keep one, bin two, settle it in a season", addedOn: "2026-08-29" },
      { path: "/gauntlet-draft", label: "Gauntlet Draft: Soccer", emoji: "\u2694\uFE0F", description: "Pick your XI five cards at a time, then survive a five round cup", daily: true, addedOn: "2026-08-29" },
      { path: "/player-stock-market", label: "Player Stock Market", emoji: "\u{1F4C8}", description: "Open a past season, buy an XI on stats alone, then roll the years forward", daily: true, addedOn: "2026-07-22" }
      // deleted 2026-08-05 per owner review: he asked for the standalone box
      // game to go and for Squad Deal to stay.
      // { path: '/deal-or-no-deal', label: 'Mystery Box', emoji: '💼', description: 'Bank or gamble against the Banker', isNew: true },
      // deleted 2026-07-08 per owner review: "discard this". Route kept for direct links; uncomment to revive.
      // { path: '/pack-battle', label: 'Pack Battle', emoji: '🃏', description: 'Call higher or lower before each card flips. One miss busts the pack', daily: true, isNew: true },
    ]
  },
  {
    title: "Pro Football",
    emoji: "\u{1F3C8}",
    games: [
      { path: "/perfect-season-nfl", label: "17-0 NFL Perfect Season", emoji: "\u{1F3C6}", description: "Draft an offense across eras, run the table", addedOn: "2026-07-01" },
      { path: "/front-office", label: "NFL Front Office", emoji: "\u{1F3E2}", description: "Full GM sim with real rosters: cap, trades, drafts, dynasties", addedOn: "2026-08-11", featured: true },
      { path: "/nfl-my-career", label: "NFL My Career", emoji: "\u{1F31F}", description: "Draft night to Canton. 8 positions, 100+ crossroads, and a very tempting envelope", addedOn: "2026-08-11", featured: true },
      { path: "/football-grid", label: "NFL Grid", emoji: "\u{1F3C8}", description: "3\xD73 grid puzzle with rarity scores", daily: true, addedOn: "2026-03-08" },
      // retired 2026-07-08 per owner review: "too easy and boring... unless ur going to add to it, discard it". Route kept for direct links; uncomment to revive.
      // { path: '/football-timeline', label: 'Timeline', emoji: '📅', description: 'Order players by draft year', daily: true },
      // deleted 2026-08-05 per owner review: "Draft guessed is boring and I say delete it."
      // { path: '/football-draft', label: 'Draft Guesser', emoji: '🎰', description: 'Guess the draft round', daily: true },
      { path: "/nfl-career", label: "NFL Career Path", emoji: "\u{1F3C8}", description: "Guess the NFL player from clues", daily: true, addedOn: "2026-02-09" },
      { path: "/nfl-higher-lower", label: "NFL Higher or Lower", emoji: "\u{1F4CA}", description: "Which star scored more career touchdowns?", daily: true, addedOn: "2026-03-08" },
      { path: "/nfl-connections", label: "NFL Connections", emoji: "\u{1F9E9}", description: "Group 20 players into four hidden connections", daily: true, addedOn: "2026-03-08" },
      { path: "/nfl-connect-4", label: "NFL Connect 4", emoji: "\u{1F3C8}", description: "Football trivia meets Connect 4", addedOn: "2026-02-10" },
      { path: "/missing-eleven", label: "Missing Eleven", emoji: "\u{1F575}\uFE0F", description: "Name the missing starter from a famous Super Bowl offense", daily: true, addedOn: "2026-07-22" },
      // retired 2026-07-08 per owner review: "like 40 teams to choose from... get rid of this game". Route kept for direct links; uncomment to revive.
      // { path: '/guess-nfl-team', label: 'Guess The Team', emoji: '🏈', description: 'Identify the NFL franchise', daily: true, isNew: true },
      { path: "/conquest", label: "NFL Conquest", emoji: "\u{1F5FA}\uFE0F", description: "The imperialism map: winners annex whole empires until one team rules America", daily: true, addedOn: "2026-03-14" },
      { path: "/nfl-gauntlet-draft", label: "Gauntlet Draft: NFL", emoji: "\u2694\uFE0F", description: "Pick your offense five cards at a time, then survive a five round cup", daily: true, addedOn: "2026-09-10" }
    ]
  },
  {
    // 2026-07-08: College Football + College Basketball merged into one
    // College Sports tab per owner review ("just put the two together").
    title: "College Sports",
    emoji: "\u{1F393}",
    games: [
      { path: "/college-grid", label: "College Grid", emoji: "\u{1F393}", description: "College football 3\xD73 grid puzzle", daily: true, addedOn: "2026-03-08" },
      { path: "/guess-the-college", label: "Guess The College", emoji: "\u{1F3EB}", description: "Guess the D1 school from clues", daily: true, addedOn: "2026-03-08" },
      { path: "/guess-cbb-team", label: "Guess The CBB Program", emoji: "\u{1F3C0}", description: "Guess the college basketball program", daily: true, addedOn: "2026-03-09" },
      { path: "/cbb-grid", label: "College Basketball Grid", emoji: "\u{1F532}", description: "Fill the 3\xD73 with players who match the school and the achievement", daily: true, addedOn: "2026-07-03" },
      { path: "/cfb-higher-lower", label: "CFB Higher or Lower", emoji: "\u{1F4CA}", description: "Which QB threw for more college yards?", daily: true, addedOn: "2026-03-08" },
      { path: "/cfb-dynasty", label: "CFB Dynasty", emoji: "\u{1F3DF}\uFE0F", description: "Full program sim: NIL recruiting, the portal, the 12-team Playoff, dynasties", addedOn: "2026-08-11", featured: true },
      { path: "/cbb-dynasty", label: "CBB Dynasty", emoji: "\u{1F3C0}", description: "College hoops sim: one-and-dones, conference tournaments, 32-team March, Cinderella", addedOn: "2026-08-11", featured: true }
    ]
  },
  {
    title: "Pro Basketball",
    emoji: "\u{1F3C0}",
    games: [
      { path: "/buzzer-beater", label: "Buzzer Beater", emoji: "\u{1F3C0}", description: "Pick the arc, beat the hand, drop ten jump shots", daily: true, addedOn: "2026-09-04" },
      { path: "/perfect-season-nba", label: "82-0 NBA Perfect Season", emoji: "\u{1F3C6}", description: "Spin team seasons, draft a six man rotation", addedOn: "2026-07-01" },
      { path: "/stat-detective", label: "Stat Detective", emoji: "\u{1F50E}", description: "Name the player behind the mystery stat line", addedOn: "2026-07-02" },
      { path: "/nba-stat-line", label: "NBA Stat Line", emoji: "\u{1F4CA}", description: "Blend five real seasons into a target per 36 line", daily: true, addedOn: "2026-08-29" },
      { path: "/nba-starting-5", label: "NBA Starting 5", emoji: "\u{1F3C0}", description: "Build a lineup with stat challenges", addedOn: "2026-02-09" },
      { path: "/nba-connect-4", label: "NBA Connect 4", emoji: "\u{1F3C0}", description: "NBA trivia meets Connect 4", addedOn: "2026-02-10" },
      { path: "/nba-chain", label: "NBA Chain", emoji: "\u{1F517}", description: "Build a chain of connected players", addedOn: "2026-02-10" },
      { path: "/nba-higher-lower", label: "NBA Higher or Lower", emoji: "\u{1F4CA}", description: "Which legend scored more career points?", daily: true, addedOn: "2026-03-08" },
      { path: "/nba-grid", label: "NBA Franchise Grid", emoji: "\u{1F532}", description: "Fill the 3\xD73 with players who match both teams", daily: true, addedOn: "2026-07-03" },
      { path: "/nba-connections", label: "NBA Connections", emoji: "\u{1F9E9}", description: "Group 20 players into four hidden connections", daily: true, addedOn: "2026-03-08" },
      { path: "/nba-career", label: "NBA Career Path", emoji: "\u{1F4DC}", description: "Guess the NBA player from progressive clues", daily: true, addedOn: "2026-03-08" },
      { path: "/missing-five", label: "Missing Five", emoji: "\u{1F575}\uFE0F", description: "Name the missing starter from a famous real lineup", daily: true, addedOn: "2026-07-22" },
      { path: "/perfect-lineup-nba", label: "Perfect Lineup: NBA", emoji: "\u{1F3C0}", description: "Build a starting 5 under random team & era constraints, then simulate", daily: true, addedOn: "2026-06-14" },
      { path: "/conquest-nba", label: "NBA Conquest", emoji: "\u{1F5FA}\uFE0F", description: "Imperialism mode: winners annex whole empires until one team rules the map", daily: true, addedOn: "2026-03-14" },
      { path: "/nba-front-office", label: "NBA Front Office", emoji: "\u{1F3E2}", description: "Full GM sim: cap, trades, the play-in, best-of-7 wars, dynasties", addedOn: "2026-08-11", featured: true },
      { path: "/nba-my-career", label: "NBA My Career", emoji: "\u{1F31F}", description: "Draft night to the rafters. 5 positions, 100+ crossroads, and one very tempting phone call", addedOn: "2026-08-11", featured: true },
      { path: "/nba-gauntlet-draft", label: "Gauntlet Draft: NBA", emoji: "\u2694\uFE0F", description: "Pick your five, five cards at a time, then survive a five round cup", daily: true, addedOn: "2026-09-10" }
    ]
  },
  {
    title: "Baseball",
    emoji: "\u26BE",
    games: [
      { path: "/perfect-season-mlb", label: "162-0 MLB Perfect Season", emoji: "\u{1F3C6}", description: "Spin, draft across eras, chase 116 wins", addedOn: "2026-07-01" },
      { path: "/baseball-career", label: "MLB Career Path", emoji: "\u26BE", description: "Guess the baseball player", daily: true, addedOn: "2026-03-08" },
      { path: "/mlb-higher-lower", label: "MLB Higher or Lower", emoji: "\u{1F4CA}", description: "Which legend hit more career home runs?", daily: true, addedOn: "2026-03-08" },
      { path: "/mlb-grid", label: "MLB Franchise Grid", emoji: "\u{1F532}", description: "Fill the 3\xD73 with legends who match both teams", daily: true, addedOn: "2026-07-03" },
      { path: "/mlb-connect-4", label: "MLB Connect 4", emoji: "\u26BE", description: "Baseball trivia meets Connect 4", addedOn: "2026-02-10" },
      { path: "/mlb-gauntlet-draft", label: "Gauntlet Draft: MLB", emoji: "\u26BE", description: "Fill the lineup card five cards at a time, then survive October", daily: true, addedOn: "2026-09-11" },
      { path: "/conquest-mlb", label: "MLB Conquest", emoji: "\u{1F5FA}\uFE0F", description: "Imperialism at the ballpark: winners annex whole empires, two invaders start landless", daily: true, addedOn: "2026-08-11" },
      { path: "/mlb-my-career", label: "MLB My Career", emoji: "\u{1F31F}", description: "Draft day to Cooperstown. 11 positions, 100+ crossroads, and a camera in center field", addedOn: "2026-08-11", featured: true },
      { path: "/mlb-front-office", label: "MLB Front Office", emoji: "\u{1F3E2}", description: "Full GM sim with real 2026 rosters: the tax line, trades, October, dynasties", addedOn: "2026-08-11", featured: true },
      { path: "/missing-nine", label: "Missing Nine", emoji: "\u{1F575}\uFE0F", description: "Name the missing starter from a famous World Series batting order", daily: true, addedOn: "2026-07-22" },
      { path: "/baseball-connections", label: "MLB Connections", emoji: "\u26BE", description: "Group baseball players", daily: true, addedOn: "2026-03-08" }
    ]
  },
  {
    title: "Hockey",
    emoji: "\u{1F3D2}",
    games: [
      { path: "/perfect-season-nhl", label: "82-0 NHL Perfect Season", emoji: "\u{1F3C6}", description: "Spin franchises and eras, chase 82-0", addedOn: "2026-07-01" },
      { path: "/puck-detective", label: "Puck Detective", emoji: "\u{1F3D2}", description: "Guess the mystery NHL player with attribute clues", daily: true, addedOn: "2026-07-03" },
      { path: "/hockey-grid", label: "NHL Franchise Grid", emoji: "\u{1F945}", description: "3x3 grid with NHL franchises and career milestones", daily: true, addedOn: "2026-07-03" },
      { path: "/hockey-career", label: "NHL Career Path", emoji: "\u{1F3D2}", description: "Guess the hockey player", daily: true, addedOn: "2026-03-08" },
      { path: "/hockey-higher-lower", label: "NHL Higher or Lower", emoji: "\u{1F3D2}", description: "Compare career points", daily: true, addedOn: "2026-03-08" },
      { path: "/nhl-connections", label: "NHL Connections", emoji: "\u{1F9E9}", description: "Group 20 players into four hidden connections", daily: true, addedOn: "2026-03-08" },
      { path: "/conquest-nhl", label: "NHL Conquest", emoji: "\u{1F5FA}\uFE0F", description: "Imperialism on ice: winners annex whole empires, five invaders start landless", daily: true, addedOn: "2026-08-11" },
      { path: "/nhl-my-career", label: "NHL My Career", emoji: "\u{1F31F}", description: "Draft day to the rafters. 5 positions, 100+ crossroads, and an envelope on the bench", addedOn: "2026-08-11", featured: true },
      { path: "/nhl-front-office", label: "NHL Front Office", emoji: "\u{1F3E2}", description: "Full GM sim with real 2026-27 rosters: hard cap, OT points, the bracket, the Cup", addedOn: "2026-08-11", featured: true },
      { path: "/nhl-connect-4", label: "NHL Connect 4", emoji: "\u{1F3D2}", description: "Hockey trivia meets Connect 4", addedOn: "2026-02-10" },
      { path: "/perfect-lineup-nhl", label: "Perfect Lineup: NHL", emoji: "\u{1F3D2}", description: "Build a dream line under random team & era constraints, then simulate", daily: true, addedOn: "2026-06-14" },
      { path: "/nhl-gauntlet-draft", label: "Gauntlet Draft: NHL", emoji: "\u{1F3D2}", description: "Draft two lines, two pairs and a goalie five cards at a time, then survive the playoffs", daily: true, addedOn: "2026-10-01" }
    ]
  },
  {
    title: "Formula 1",
    emoji: "\u{1F3CE}\uFE0F",
    games: [
      { path: "/f1-driver", label: "Guess The F1 Driver", emoji: "\u{1F3CE}\uFE0F", description: "Guess the mystery F1 driver from clues", daily: true, addedOn: "2026-03-09" },
      { path: "/f1-higher-lower", label: "F1 Higher or Lower", emoji: "\u{1F4CA}", description: "Which driver won more Grands Prix?", daily: true, addedOn: "2026-03-08" },
      { path: "/f1-constructor", label: "Guess The Constructor", emoji: "\u{1F3D7}\uFE0F", description: "Guess the mystery F1 team from clues", daily: true, addedOn: "2026-03-09" },
      { path: "/perfect-lineup-f1", label: "Perfect Lineup: F1", emoji: "\u{1F3CE}\uFE0F", description: "Build a 5-driver dream squad under random team/era/country constraints", daily: true, addedOn: "2026-06-14" }
    ]
  },
  {
    title: "Tennis",
    emoji: "\u{1F3BE}",
    games: [
      { path: "/guess-tennis-player", label: "Guess The Player", emoji: "\u{1F3BE}", description: "Guess the mystery tennis player from clues", daily: true, addedOn: "2026-03-09" },
      { path: "/tennis-chain", label: "Tennis Chain", emoji: "\u{1F517}", description: "Build a chain of Grand Slam defeats", addedOn: "2026-03-09" },
      { path: "/tennis-higher-lower", label: "Tennis Higher or Lower", emoji: "\u{1F4CA}", description: "Which legend won more Grand Slam titles?", daily: true, addedOn: "2026-03-08" }
    ]
  },
  {
    title: "Golf",
    emoji: "\u{1F3CC}\uFE0F",
    games: [
      { path: "/guess-the-golfer", label: "Guess The Golfer", emoji: "\u26F3", description: "A mystery major champion, six clues, fewer is better", daily: true, addedOn: "2026-08-04" },
      { path: "/golf-higher-lower", label: "Golf Higher or Lower", emoji: "\u{1F4CA}", description: "Which legend won more majors?", daily: true, addedOn: "2026-03-08" }
    ]
  },
  {
    title: "Aussie Rules",
    emoji: "\u{1F3C9}",
    games: [
      { path: "/aussie-rules-manager", label: "Aussie Rules Manager", emoji: "\u{1F3C9}", description: "Run one of 18 fictional clubs through 23 rounds, the finals and a draft into next season", addedOn: "2026-10-01" },
      { path: "/afl-higher-lower", label: "AFL Higher or Lower", emoji: "\u{1F4CA}", description: "Which legend kicked more career goals?", daily: true, addedOn: "2026-03-08" }
    ]
  },
  {
    title: "NASCAR",
    emoji: "\u{1F3C1}",
    games: [
      { path: "/guess-nascar-driver", label: "Guess The Driver", emoji: "\u{1F3C1}", description: "Guess the mystery NASCAR driver from clues", daily: true, addedOn: "2026-03-09" },
      { path: "/nascar-chain", label: "NASCAR Chain", emoji: "\u{1F517}", description: "Build a chain of Cup champions", addedOn: "2026-03-09" }
    ]
  },
  {
    title: "Combat Sports",
    emoji: "\u{1F94A}",
    games: [
      { path: "/cage-clash", label: "Cage Clash", emoji: "\u{1F94B}", description: "Pixel MMA action. Strike, clinch, take down and fight for a submission.", addedOn: "2026-10-06" },
      { path: "/fight-career", label: "Fight Career", emoji: "\u{1F44A}", description: "Turn pro, pick your fights and climb to a world title. The damage never heals.", addedOn: "2026-09-16" },
      { path: "/fight-promoter", label: "Fight Promoter", emoji: "\u{1F39F}\uFE0F", description: "Run an MMA or boxing promotion. Sign fighters, build cards and crown champions.", addedOn: "2026-09-16" },
      { path: "/fight-gym", label: "Fight Gym", emoji: "\u{1F94A}", description: "Sign fighters, pick their nights, take your cut, and decide when a man is finished.", addedOn: "2026-09-16" },
      { path: "/ufc", label: "UFC Guesser", emoji: "\u{1F94A}", description: "Guess the UFC fighter", addedOn: "2026-02-10" },
      { path: "/ufc-chain", label: "Combat Chain", emoji: "\u{1F517}", description: "Build a chain of fighters who beat each other", addedOn: "2026-03-09" }
    ]
  },
  {
    title: "World & Olympic Games",
    emoji: "\u{1F30D}",
    games: [
      { path: "/rank-em", label: "Rank 'Em", emoji: "\u{1F4CA}", description: "Put five players in order by a career stat, most to fewest", daily: true, addedOn: "2026-08-04" },
      { path: "/teammates", label: "Teammates or Not?", emoji: "\u{1F91D}", description: "Were they ever teammates?", addedOn: "2026-03-08" },
      { path: "/olympics", label: "The Medal Games", emoji: "\u{1F3C5}", description: "Guess the mystery athlete from clues", daily: true, addedOn: "2026-03-08" },
      { path: "/guess-the-year", label: "Guess The Year", emoji: "\u{1F4C5}", description: "What year did these happen?", daily: true, addedOn: "2026-03-09" },
      { path: "/guess-the-nation", label: "Guess The Nation", emoji: "\u{1F30D}", description: "Identify the mystery sporting nation", daily: true, addedOn: "2026-03-09" },
      { path: "/hof-or-bust", label: "Hall of Fame or Bust?", emoji: "\u{1F3C6}", description: "Is this player a legend or a letdown?", daily: true, addedOn: "2026-04-10" },
      { path: "/champ-or-not", label: "Champ or Not", emoji: "\u{1F3C6}", description: "Ten title claims, true or false. Spot the fakes", daily: true, addedOn: "2026-08-21" },
      { path: "/whod-they-beat", label: "Who'd They Beat?", emoji: "\u{1F948}", description: "The champ is given. Name the team they beat in the finals", daily: true, addedOn: "2026-08-21" },
      { path: "/silverware-sort", label: "Silverware Sort", emoji: "\u{1F947}", description: "Stack five teams in order by real title counts", daily: true, addedOn: "2026-08-21" },
      { path: "/hall-of-champions", label: "Hall of Champions", emoji: "\u{1F3DB}\uFE0F", description: "Idle museum: buy real championships, fill ten wings, earn while you are away", addedOn: "2026-08-21" },
      { path: "/idle-arena", label: "Idle Arena", emoji: "\u{1F446}", description: "Tap to score, sign a squad that scores for you, lift trophies, earn while you are away", addedOn: "2026-08-25" },
      { path: "/face-off", label: "Face Off", emoji: "\u26A1", description: "Two names, one stat, ten seconds. Beat the rival across ten sports", daily: true, addedOn: "2026-08-25" },
      { path: "/score-predictor", label: "Score Predictor", emoji: "\u{1F4CA}", description: "Predict the final score of famous matches", daily: true, addedOn: "2026-04-10" },
      // moved from the retired Game Shows tab 2026-07-08 (owner: game-show games belong with their sport; these two span all sports)
      { path: "/list-quiz", label: "Name Them All", emoji: "\u{1F4DD}", description: "How many champions can you name?", addedOn: "2026-07-01" },
      { path: "/minefield", label: "Minefield", emoji: "\u{1F4A3}", description: "Click everyone who belongs. Some tiles explode", daily: true, addedOn: "2026-07-10" },
      { path: "/sports-millionaire", label: "Sports Millionaire", emoji: "\u{1F4B0}", description: "Climb a 15-question money ladder with lifelines", daily: true, addedOn: "2026-07-06" },
      { path: "/quiz-board", label: "Sports Quiz Board", emoji: "\u{1F393}", description: "Five categories, $200 to $1000. Wrong answers cost you", daily: true, addedOn: "2026-07-21" },
      { path: "/ball-iq", label: "Ball Knowledge IQ", emoji: "\u{1F9E0}", description: "Twelve questions, getting harder. Do you actually know ball?", daily: true, addedOn: "2026-07-21" },
      { path: "/emoji-guess", label: "Emoji Guess", emoji: "\u{1F914}", description: "Five football riddles told entirely in emoji", daily: true, addedOn: "2026-07-21" },
      { path: "/mystery-box", label: "Mystery Box", emoji: "\u{1F4E6}", description: "Open 15 packs, keep or bin, build the best XI your luck allows", daily: true, addedOn: "2026-07-21" }
    ]
  }
  // Game Shows category removed 2026-07-08 per owner review, its games now
  // live inside their sports (Squad Deal + the retired box game → Soccer,
  // Name Them All + Sports Millionaire → World & Olympic Games).
];
var VISIBLE_CATEGORIES = CATEGORIES.filter((c) => c.games.length > 0);
var ALL_GAMES = CATEGORIES.flatMap((c) => c.games);
var FEATURED_GAMES = ALL_GAMES.filter((g) => g.featured);
var TOTAL_GAMES = ALL_GAMES.length;
var GAME_COUNT_LABEL = `${Math.floor(TOTAL_GAMES / 10) * 10}+`;
export {
  CATEGORIES,
  GAME_CONTENT,
  flatGuide
};
