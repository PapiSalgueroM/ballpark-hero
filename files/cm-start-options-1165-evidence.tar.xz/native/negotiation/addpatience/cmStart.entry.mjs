
globalThis.localStorage = { getItem: () => null, setItem: () => {}, removeItem: () => {} };
export const engine = await import('/home/runner/work/ballpark-hero/ballpark-hero/src/lib/clubManager.ts');
export const start = await import('/home/runner/work/_temp/start-options-1165.jpfFUu/evidence/native/negotiation/addpatience/cmStart.control.ts');
