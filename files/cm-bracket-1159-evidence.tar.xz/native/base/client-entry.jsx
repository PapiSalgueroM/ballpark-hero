import React from 'react';
import {createRoot} from 'react-dom/client';
import {BracketSide} from "/home/runner/work/_temp/bracket-1159.E7A7jU/base-root/src/components/club-manager/CupBracketCard.tsx";
export function mount(fixture){
 const input=JSON.parse(JSON.stringify(fixture)); let calls=[],submits=0;
 const root=createRoot(document.getElementById('fixture-root'));
 const snapshot=()=>({fixture:JSON.parse(JSON.stringify(input)),calls:[...calls],submits});
 const publish=()=>{document.getElementById('callback-output').textContent=JSON.stringify(calls);};
 window.__bracket1159={snapshot,reset:()=>{calls=[];publish();}};
 root.render(<form onSubmit={e=>{e.preventDefault();submits++;}}>
  <button type="button" data-sentinel="before">Before bracket</button>
  <section data-bracket-board className="bg-card border border-border rounded-2xl p-3 space-y-2">
   {input.rows.map(row=><div key={row.id} data-bracket-row={row.id}><BracketSide {...row.props} onClubClick={input.interactive?name=>{calls.push(name);publish();}:undefined}/></div>)}
  </section>
  <button type="button" data-sentinel="after">After bracket</button>
  <output id="callback-output" data-callback-output>[]</output>
 </form>);
}