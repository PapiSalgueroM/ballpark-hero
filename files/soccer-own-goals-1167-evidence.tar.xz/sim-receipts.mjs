import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
const root=process.cwd(), e=process.env.E, hash=b=>createHash('sha256').update(b).digest('hex');
const read=f=>JSON.parse(fs.readFileSync(f)), save=(f,x)=>fs.writeFileSync(f,JSON.stringify(x,null,2));
const strip=s=>({...s,games:s.games.map(g=>({...g,events:g.events.map(event=>{const {ownGoalBy,...rest}=event;return rest;})}))});
const rows=[];
function ledger(file,names,exit='0'){
  const got=fs.readFileSync(file,'utf8').trim().split('\n').map(x=>x.split('\t'));
  assert.deepEqual(got.map(x=>x[0]),names);assert(got.every(x=>x[1]===exit));return got;
}
ledger(e+'/sims/cohort-gates.tsv',['seed-0','seed-1','seed-2']);
const kinds=['self','teammate','opponent','points','mine','preceding-mine','assist','origin','mirror','kind','missed','before','after','on','between','empty','duplicates'];
for(const seed of [0,1,2]){
  const folder=e+'/sims/cohorts/seed-'+seed, summary=read(folder+'/summary.json'), m=read(folder+'/measurement.json');
  assert.equal(summary.complete,true);assert.equal(summary.control,null);assert.equal(summary.careers,120);assert.equal(summary.seedset,seed);assert.equal(summary.parentCompared,true);assert(summary.checks>0);
  assert.equal(m.seedset,seed);assert.equal(m.careers,120);assert.equal(m.checks,summary.checks);assert.deepEqual(m.counts,summary.counts);
  assert.equal(m.seasonRows.length,m.seasons);assert.equal(m.careerRows.length,120);
  const sum=(list,key)=>list.reduce((n,r)=>n+r[key],0);
  assert.equal(sum(m.seasonRows,'goals'),m.goals);assert.equal(sum(m.seasonRows,'eligible'),m.eligible.us+m.eligible.them);
  assert.equal(sum(m.seasonRows,'tags'),m.tagged.you+m.tagged.teammate+m.tagged.opponent);assert.equal(sum(m.seasonRows,'self'),m.tagged.you);
  assert.equal(sum(m.careerRows,'seasons'),m.seasons);assert.equal(sum(m.careerRows,'tags'),sum(m.seasonRows,'tags'));assert.equal(sum(m.careerRows,'self'),m.tagged.you);
  assert.equal(sum(m.careerRows,'taggedSeasons'),m.taggedSeasons);assert.equal(sum(m.careerRows,'selfSeasons'),m.selfSeasons);
  assert.equal(m.playingRows,m.seasons+Object.values(m.refused).reduce((n,v)=>n+v,0));assert.equal(m.games,m.playedGames+m.missedGames);
  assert.equal(m.goals,m.excludedAny+m.eligible.us+m.eligible.them);
  assert.equal(m.eligible.them,m.eligible.onPitchThem+m.eligible.offPitchThem+m.eligible.missedThem);
  assert.equal(m.parentDerived,m.seasons);assert.equal(m.tagged.you,m.roleZeroDraws);assert.equal(m.roleDraws.length,11);assert.equal(m.roleOpportunities,m.roleDraws.reduce((n,v)=>n+v,0));
  assert.equal(m.momentMixtures,m.seasonRows.reduce((n,r)=>n+2**r.momentCount,0));assert(m.distinctChangedMixtures>0&&m.distinctChangedMixtures<=m.momentMixtures);
  assert(m.seasons>0&&m.eligible.us>0&&m.eligible.onPitchThem>0);
  assert.equal(summary.counts['parent-derived'],m.seasons);assert.equal(summary.counts['parent-decisions'],m.momentMixtures);
  const log=fs.readFileSync(folder+'/stdout.log','utf8');assert(new RegExp('^simSoccerOwnGoals: '+summary.checks+' checks, 0 failed$','m').test(log));
  const functional=[];
  for(const kind of kinds){
    const f=read(folder+'/functional-'+kind+'.json');
    assert.deepEqual(f.sourceAfter,f.source);assert.deepEqual(f.momentsAfter,f.moments);assert.deepEqual(strip(f.marked),f.source);
    for(const g of f.marked.games)for(const event of g.events)if(event.ownGoalBy){
      assert.equal(event.kind,'goal');assert.equal(event.pts,1);assert(!event.mine);assert(!f.moments.some(x=>x.mirrorMd===g.md||x.md===g.md&&x.minute===event.min));
      assert(!(event.side==='us'&&g.events.some(x=>x.kind==='assist'&&x.mine&&x.min===event.min)));
      assert(event.side==='us'?event.ownGoalBy==='opponent':['you','teammate'].includes(event.ownGoalBy));
      if(event.ownGoalBy==='you')assert(g.played&&event.min>=(g.onAt??1)&&event.min<(g.offAt??91));
    }
    functional.push({kind,key:f.source.key,sha256:hash(fs.readFileSync(folder+'/functional-'+kind+'.json'))});
  }
  const boundaryNames=['played-false','before-on','at-on','at-off','before-off'], keys=[];
  for(const name of boundaryNames){
    const f=read(folder+'/boundary-'+name+'.json');assert.deepEqual(f.sourceAfter,f.source);assert.deepEqual(strip(f.marked),f.source);keys.push(f.source.key);
    const by=f.marked.games[0].events[0].ownGoalBy;assert.equal(by,['at-on','before-off'].includes(name)?'you':'teammate');
  }
  assert.equal(new Set(keys).size,1);assert.equal(keys[0],read(folder+'/functional-self.json').source.key);
  for(const name of ['absent','malformed','stale','used','banked']){
    const f=read(folder+'/ledger-'+name+'.json');assert.deepEqual(f.rawAfter,f.rawBefore);assert.deepEqual(f.actualRead,f.expectedRead);assert.deepEqual(f.actualEntries,f.expectedEntries);
  }
  for(const name of ['events','game']){
    const f=read(folder+'/insertion-'+name+'.json');assert.deepEqual(strip(f.marked),f.source);assert.deepEqual(strip(f.insertedMarked),f.insertedSource);
  }
  rows.push({seed,checks:summary.checks,denominators:m,structural:functional});
}
const intended={points:'eligibility',mine:'eligibility',assist:'eligibility',origin:'eligibility',mirror:'eligibility',kind:'eligibility',pitch:'self-pitch',beneficiary:'beneficiary',role:'local-policy',gate:'local-policy',score:'metadata-inverse',filteredordinal:'local-policy',input:'input-immutable',ordinal:'insertion-stability',rng:'ambient-rng',ledgerdata:'ledger-reader',ledgerkey:'ledger-reader',stream:'parent-derived'};
ledger(e+'/sims/control-gates.tsv',Object.keys(intended));
const controls=[];
for(const [name,check] of Object.entries(intended)){
  const folder=e+'/sims/controls/'+name, result=read(folder+'/control-result.json'), summary=read(folder+'/summary.json'), changes=read(folder+'/candidate/mutations.json');
  assert.equal(summary.complete,true);assert.equal(summary.control,name);assert.equal(result.control,name);assert.equal(result.intendedCheck,check);
  assert.equal(result.changedSource,true);assert.equal(result.failure.name,'AssertionError');assert.equal(result.failure.check,check);
  assert.equal(changes.length,1);const mutation=changes[0], before=fs.readFileSync(folder+'/candidate/control-before.ts','utf8'),after=fs.readFileSync(folder+'/candidate/control-after.ts','utf8');
  assert.equal(hash(before),mutation.beforeSha256);assert.equal(hash(after),mutation.afterSha256);assert.notEqual(before,after);assert.equal(before.split(mutation.from).length-1,1);assert.equal(before.replace(mutation.from,mutation.to),after);
  assert.equal(before,fs.readFileSync(path.join(root,mutation.file),'utf8').replace(/\r\n/g,'\n'));
  const log=fs.readFileSync(folder+'/stdout.log','utf8');assert(log.includes('CONTROL '+name+': effective copied source, intended '+check+' AssertionError'));
  controls.push({name,check,mutation,failure:result.failure});
}
function baseline(name){
  const log=fs.readFileSync(e+'/logs/'+name+'.log','utf8');const sim=name==='agreement-baseline'?'simSeasonCentreAgreement':'simSeasonMoments';
  const match=log.match(new RegExp('^'+sim+': ([0-9]+) checks, 0 failed$','m'));assert(match&&Number(match[1])>0);assert(!/^FAIL /m.test(log));return{sim,checks:Number(match[1]),logSha256:hash(log)};
}
ledger(e+'/sims/moments-control-gates.tsv',['share','closeshort','double'],'1');
const legacyControls=[];
for(const name of ['share','closeshort','double']){
  const log=fs.readFileSync(e+'/sims/moments-'+name+'.stdout.log','utf8'), match=log.match(new RegExp('^simSeasonMoments: ([0-9]+) checks, ([0-9]+) failed \\(control '+name+'\\)$','m'));
  assert(match&&Number(match[1])>0&&Number(match[2])>0);assert(log.includes('CONTROL '+name+':'));assert(/^FAIL (?:\[8\b|8 )/m.test(log),'Intended actual bank check failed: '+name);
  legacyControls.push({name,checks:Number(match[1]),failed:Number(match[2]),stdoutSha256:hash(log),scope:'Unchanged tracked regression command with retained source/stdout/stderr, no legacy bundle-map claim.'});
}
const natural=[];
for(const role of ['you','teammate','opponent']){
  const file=e+'/ui-fixtures/'+role+'.json', f=read(file), game=f.marked.games.find(g=>g.md===f.md);
  assert.equal(f.population.seedset,0);assert(f.population.career>=0&&f.population.career<120);assert.deepEqual(strip(f.marked),f.derived);
  assert.deepEqual(game.events[f.eventIndex],f.event);assert.equal(f.event.ownGoalBy,role);
  assert(!f.plannedMoments.some(m=>m.mirrorMd===f.md||m.md===f.md&&m.minute===f.event.min));
  natural.push({role,file,bytes:fs.statSync(file).size,sha256:hash(fs.readFileSync(file)),population:f.population});
}
save(e+'/sim-receipt.json',{complete:true,cohorts:rows,controls,baselines:[baseline('agreement-baseline'),baseline('moments-baseline')],legacyControls,natural,scope:'Exact finite outcomes and measured fictional exposure; no frequency threshold or policy acceptance. Cohort full seasons are not all returned, raw structural/natural fixtures and per-season denominators are retained.'});
console.log('OwnGoal1167 sim receipt PASS: three actual 120-career cohorts, 18 effective copied-source assertions, unchanged regressions and three natural viewer roles.');
