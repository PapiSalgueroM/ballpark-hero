import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
const root=process.cwd(), e=process.env.E, hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const save=(file,value)=>fs.writeFileSync(file,JSON.stringify(value,null,2)), read=file=>JSON.parse(fs.readFileSync(file));
const nodeBundles=[];
const bundleSpecs=[];
for(const seed of [0,1,2])for(const arm of ['candidate','parent'])bundleSpecs.push({folder:e+'/sims/cohorts/seed-'+seed+'/'+arm,arm});
for(const name of ['points','mine','assist','origin','mirror','kind','pitch','beneficiary','role','gate','score','filteredordinal','input','ordinal','rng','ledgerdata','ledgerkey','stream']){
  bundleSpecs.push({folder:e+'/sims/controls/'+name+'/candidate',arm:'candidate'});
  if(name==='stream')bundleSpecs.push({folder:e+'/sims/controls/'+name+'/parent',arm:'parent'});
}
for(const spec of bundleSpecs){
  const sourceRoot=spec.arm==='candidate'?root:process.env.BASE_ROOT,bundleDir=spec.folder;
  const outfile=path.join(bundleDir,'bundle.cjs'), entry=path.join(bundleDir,'entry.ts'), entryText=fs.readFileSync(entry,'utf8');
  const mutations=read(path.join(bundleDir,'mutations.json'));
  const originalInputs=read(path.join(bundleDir,'inputs.json')), metadata=read(path.join(bundleDir,'metafile.json'));
  assert.equal(Object.keys(metadata.inputs).length,originalInputs.length);
  for(const row of originalInputs){
    const bytes=fs.readFileSync(row.path);assert.equal(bytes.length,row.bytes);assert.equal(hash(bytes),row.sha256);
    assert.equal(row.path,path.resolve(sourceRoot,row.name));assert(Object.hasOwn(metadata.inputs,row.name));
  }
  if(mutations.length){
    assert.equal(mutations.length,1);const m=mutations[0], before=fs.readFileSync(path.join(bundleDir,'control-before.ts'),'utf8'),after=fs.readFileSync(path.join(bundleDir,'control-after.ts'),'utf8');
    assert.equal(hash(before),m.beforeSha256);assert.equal(hash(after),m.afterSha256);assert.equal(before.split(m.from).length-1,1);assert.equal(before.replace(m.from,m.to),after);assert.notEqual(before,after);
  }
  const variantOut=path.join(bundleDir,'provenance');fs.mkdirSync(variantOut,{recursive:true});
const bindBuild = (result, outfile, virtualName, virtualBytes, requiredCore) => {
        const metadata = result.metafile, mapPath = outfile + '.map';
        save(outfile + '.metafile.json', metadata);
        const nodeRoot = fs.realpathSync(path.join(root, 'node_modules')) + path.sep;
        const inputRows = Object.entries(metadata.inputs).map(([input, info]) => {
          const resolved = path.resolve(sourceRoot, input);
          const virtual = !fs.existsSync(resolved) && resolved === path.resolve(sourceRoot, virtualName);
          assert(virtual || fs.statSync(resolved).isFile(), 'Actual regular bundle input: ' + input);
          const file = virtual ? resolved : fs.realpathSync(resolved);
          const originalBytes = fs.readFileSync(file);
          const controlled = mutations.find(row => path.resolve(sourceRoot, row.file) === file);
          const bytes = controlled ? fs.readFileSync(path.join(bundleDir, 'control-after.ts')) : originalBytes;
          if (controlled) {
            assert.equal(hash(originalBytes), controlled.beforeSha256, 'Actual original controlled source');
            assert.equal(hash(bytes), controlled.afterSha256, 'Actual consumed copied source');
          }
          assert.equal(info.bytes, bytes.length, 'Actual consumed input bytes: ' + input);
          return { input, file, virtual, controlled: !!controlled, bytes: bytes.length, sha256: hash(bytes), originalBytes: originalBytes.length, originalSha256: hash(originalBytes) };
        });
        assert.equal(inputRows.filter(row => row.virtual).length, 0, 'Every viewer input is a regular original body');
        assert.equal(inputRows.filter(row=>row.file===fs.realpathSync(entry)&&row.sha256===hash(Buffer.from(entryText))).length,1,'Exact physical retained harness entry consumed');
        save(outfile + '.inputs.json', inputRows);
        const consumed = new Map(inputRows.map(row => [row.file, row]));
        const packageSources = new Map(), mapProviders = [];
        const retainedDir = path.join(variantOut, 'dependency-maps');
        fs.mkdirSync(retainedDir, { recursive: true });
        for (const input of inputRows) {
          if (input.virtual || !input.file.startsWith(nodeRoot)) continue;
          const bytes = fs.readFileSync(input.file);
          assert.equal(hash(bytes), input.sha256);
          const refs = [...bytes.toString('utf8').matchAll(/^[\t ]*\/\/[#@]\s*sourceMappingURL=(\S+)[\t ]*\r?$/gm)];
          const references = [...new Set(refs.map(row => row[1]))];
          assert(references.length <= 1, 'At most one unique actual consumed package map reference');
          if (!references.length) continue;
          const reference = references[0];
          assert(!/^(?:\w+:|\/)/.test(reference), 'Actual relative installed package map reference');
          const mapFile = fs.realpathSync(path.resolve(path.dirname(input.file), reference));
          assert(mapFile.startsWith(nodeRoot) && fs.statSync(mapFile).isFile(), 'Provider map stays inside held installed packages');
          const raw = fs.readFileSync(mapFile), published = JSON.parse(raw);
          assert(Array.isArray(published.sources));
          assert(published.sourcesContent === undefined || Array.isArray(published.sourcesContent));
          if (published.sourcesContent !== undefined) assert.equal(published.sources.length, published.sourcesContent.length);
          assert(published.sourceRoot === undefined || typeof published.sourceRoot === 'string');
          const mapSha256 = hash(raw), retained = path.join(retainedDir, mapSha256 + '.map');
          const inputRetained = path.join(retainedDir, input.sha256 + '.input');
          fs.writeFileSync(retained, raw); fs.writeFileSync(inputRetained, bytes);
          const proof = { input: input.file, inputSha256: input.sha256, sourceMappingURL: reference, mapFile, mapSha256, retained, inputRetained };
          mapProviders.push(proof);
          for (let index = 0; index < published.sources.length; index++) {
            assert.equal(typeof published.sources[index], 'string');
            const name = path.resolve(path.dirname(mapFile), published.sourceRoot ?? '', published.sources[index]);
            let content, contentProof;
            if (typeof published.sourcesContent?.[index] === 'string') {
              content = Buffer.from(published.sourcesContent[index]);
              contentProof = { contentKind: 'published sourcesContent' };
            } else {
              if (!name.startsWith(nodeRoot) || !fs.existsSync(name)) continue;
              const sourceFile = fs.realpathSync(name);
              assert(sourceFile === name && sourceFile.startsWith(nodeRoot) && fs.statSync(sourceFile).isFile(), 'Map-named installed original source remains inside held packages');
              content = fs.readFileSync(sourceFile);
              const sourceRetained = path.join(retainedDir, hash(content) + '.source');
              fs.writeFileSync(sourceRetained, content);
              contentProof = { contentKind: 'published map named installed source', sourceFile, sourceRetained, sourceSha256: hash(content) };
            }
            const contentHash = hash(content);
            packageSources.set(name + '\0' + contentHash, { ...proof, index, ...contentProof });
          }
        }
        save(outfile + '.providers.json', mapProviders);
        const map = JSON.parse(fs.readFileSync(mapPath)), bindings = [], seen = new Set();
        assert.equal(map.sources.length, map.sourcesContent.length);
        for (let i = 0; i < map.sources.length; i++) {
          assert.equal(typeof map.sourcesContent[i], 'string');
          const file = path.resolve(path.dirname(mapPath), map.sources[i]);
          const actualHash = hash(Buffer.from(map.sourcesContent[i]));
          const input = consumed.get(file);
          if (!input) {
            assert(file.startsWith(nodeRoot), 'Missing app/core/entry mapped sources fail closed: ' + file);
            const provider = packageSources.get(file + '\0' + actualHash);
            assert(provider, 'Dependency original must match a consumed actual package map: ' + file);
            bindings.push({ source: map.sources[i], file, sha256: actualHash, virtual: false, kind: 'consumed package map original', provider });
            continue;
          }
          assert.equal(actualHash, input.sha256, 'Actual consumed emitted source content: ' + file);
          for (const source of requiredCore) if (file === path.join(sourceRoot, source)) seen.add(source);
          bindings.push({ source: map.sources[i], file, sha256: actualHash, virtual: input.virtual, kind: input.virtual ? 'retained stdin entry' : 'actual consumed input' });
        }
        assert.deepEqual([...seen].sort(), [...requiredCore].sort(), 'All actual core bodies bound');
        const js = fs.readFileSync(outfile);
        const references = [...js.toString().matchAll(/^[\t ]*\/\/[#@]\s*sourceMappingURL=(\S+)[\t ]*\r?$/gm)].map(row=>row[1]);
        assert(references.length <= 1 && (!references.length || references[0] === path.basename(mapPath)), 'External map output has no contradictory map reference');
        for (const file of [outfile, mapPath]) {
          const outputs = Object.entries(metadata.outputs).filter(([name]) => path.resolve(sourceRoot, name) === file);
          assert.equal(outputs.length, 1, 'Actual emitted metadata output membership');
          assert.equal(outputs[0][1].bytes, fs.statSync(file).size, 'Actual emitted output byte count');
        }
        const record = { js: outfile, jsSha256: hash(js), map: mapPath, mapSha256: hash(fs.readFileSync(mapPath)), inputRows, bindings, requiredCore, mapProviders };
        save(outfile + '.bindings.json', record); return record;
      };
  const requiredCore=['src/lib/soccerCareerEngine.ts','src/lib/season/core.ts','src/lib/season/soccer.ts','src/lib/season/soccerEvents.ts','src/lib/season/momentsSave.ts','src/lib/keyedRng.ts','src/lib/soccerCareerSave.ts'];
  const binding=bindBuild({metafile:metadata},outfile,undefined,undefined,requiredCore);
  assert.equal(binding.inputRows.filter(row=>row.controlled).length,mutations.length);
  const map=read(outfile+'.map');
  const bodies=map.sourcesContent.map((content,index)=>{
    const bytes=Buffer.from(content), row=binding.bindings[index], file=path.join(variantOut,'body-'+index+'.txt');
    assert.equal(hash(bytes),row.sha256);fs.writeFileSync(file,bytes);return{file,source:row.file,bytes:bytes.length,sha256:row.sha256,kind:row.kind};
  });
  nodeBundles.push({folder:bundleDir,arm:spec.arm,binding,bodies,mutations});
}
assert.equal(nodeBundles.length,25);
save(e+'/bundle-provenance.json',{complete:true,bundles:nodeBundles,scope:'All new node harness bundle inputs and emitted sources, controlled copied bodies and concrete consumed dependency providers. Legacy agreement/moments emitted maps are not claimed.'});
console.log('OwnGoal1167 provenance PASS: all25 actual new node bundles, every input and emitted source/provider byte retained.');
