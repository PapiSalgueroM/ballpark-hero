import "/home/runner/work/_temp/own-goals-1167.sj5mbQ/base-root/src/lib/safeStorage";
import React from "react";
import {createRoot} from "react-dom/client";
import SoccerSeasonCentre from "/home/runner/work/_temp/own-goals-1167.sj5mbQ/base-root/src/components/soccer-career/SoccerSeasonCentre";
const fixture=await(await fetch("./fixture.json")).json();
window.__ogInitial=JSON.stringify(fixture);window.__ogFixture=fixture;window.__ogClose=0;
createRoot(document.getElementById("root")).render(<SoccerSeasonCentre career={fixture.career} clubs={fixture.clubs} row={fixture.row} mode="watch" onClose={()=>window.__ogClose++}/>);
