var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/react/cjs/react.production.min.js
var require_react_production_min = __commonJS({
  "node_modules/react/cjs/react.production.min.js"(exports) {
    "use strict";
    var l = Symbol.for("react.element");
    var n = Symbol.for("react.portal");
    var p = Symbol.for("react.fragment");
    var q = Symbol.for("react.strict_mode");
    var r2 = Symbol.for("react.profiler");
    var t = Symbol.for("react.provider");
    var u = Symbol.for("react.context");
    var v = Symbol.for("react.forward_ref");
    var w = Symbol.for("react.suspense");
    var x = Symbol.for("react.memo");
    var y = Symbol.for("react.lazy");
    var z = Symbol.iterator;
    function A(a) {
      if (null === a || "object" !== typeof a) return null;
      a = z && a[z] || a["@@iterator"];
      return "function" === typeof a ? a : null;
    }
    var B2 = { isMounted: function() {
      return false;
    }, enqueueForceUpdate: function() {
    }, enqueueReplaceState: function() {
    }, enqueueSetState: function() {
    } };
    var C2 = Object.assign;
    var D = {};
    function E(a, b, e) {
      this.props = a;
      this.context = b;
      this.refs = D;
      this.updater = e || B2;
    }
    E.prototype.isReactComponent = {};
    E.prototype.setState = function(a, b) {
      if ("object" !== typeof a && "function" !== typeof a && null != a) throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
      this.updater.enqueueSetState(this, a, b, "setState");
    };
    E.prototype.forceUpdate = function(a) {
      this.updater.enqueueForceUpdate(this, a, "forceUpdate");
    };
    function F() {
    }
    F.prototype = E.prototype;
    function G(a, b, e) {
      this.props = a;
      this.context = b;
      this.refs = D;
      this.updater = e || B2;
    }
    var H = G.prototype = new F();
    H.constructor = G;
    C2(H, E.prototype);
    H.isPureReactComponent = true;
    var I = Array.isArray;
    var J = Object.prototype.hasOwnProperty;
    var K = { current: null };
    var L = { key: true, ref: true, __self: true, __source: true };
    function M(a, b, e) {
      var d, c = {}, k = null, h = null;
      if (null != b) for (d in void 0 !== b.ref && (h = b.ref), void 0 !== b.key && (k = "" + b.key), b) J.call(b, d) && !L.hasOwnProperty(d) && (c[d] = b[d]);
      var g = arguments.length - 2;
      if (1 === g) c.children = e;
      else if (1 < g) {
        for (var f = Array(g), m = 0; m < g; m++) f[m] = arguments[m + 2];
        c.children = f;
      }
      if (a && a.defaultProps) for (d in g = a.defaultProps, g) void 0 === c[d] && (c[d] = g[d]);
      return { $$typeof: l, type: a, key: k, ref: h, props: c, _owner: K.current };
    }
    function N(a, b) {
      return { $$typeof: l, type: a.type, key: b, ref: a.ref, props: a.props, _owner: a._owner };
    }
    function O(a) {
      return "object" === typeof a && null !== a && a.$$typeof === l;
    }
    function escape(a) {
      var b = { "=": "=0", ":": "=2" };
      return "$" + a.replace(/[=:]/g, function(a2) {
        return b[a2];
      });
    }
    var P = /\/+/g;
    function Q(a, b) {
      return "object" === typeof a && null !== a && null != a.key ? escape("" + a.key) : b.toString(36);
    }
    function R2(a, b, e, d, c) {
      var k = typeof a;
      if ("undefined" === k || "boolean" === k) a = null;
      var h = false;
      if (null === a) h = true;
      else switch (k) {
        case "string":
        case "number":
          h = true;
          break;
        case "object":
          switch (a.$$typeof) {
            case l:
            case n:
              h = true;
          }
      }
      if (h) return h = a, c = c(h), a = "" === d ? "." + Q(h, 0) : d, I(c) ? (e = "", null != a && (e = a.replace(P, "$&/") + "/"), R2(c, b, e, "", function(a2) {
        return a2;
      })) : null != c && (O(c) && (c = N(c, e + (!c.key || h && h.key === c.key ? "" : ("" + c.key).replace(P, "$&/") + "/") + a)), b.push(c)), 1;
      h = 0;
      d = "" === d ? "." : d + ":";
      if (I(a)) for (var g = 0; g < a.length; g++) {
        k = a[g];
        var f = d + Q(k, g);
        h += R2(k, b, e, f, c);
      }
      else if (f = A(a), "function" === typeof f) for (a = f.call(a), g = 0; !(k = a.next()).done; ) k = k.value, f = d + Q(k, g++), h += R2(k, b, e, f, c);
      else if ("object" === k) throw b = String(a), Error("Objects are not valid as a React child (found: " + ("[object Object]" === b ? "object with keys {" + Object.keys(a).join(", ") + "}" : b) + "). If you meant to render a collection of children, use an array instead.");
      return h;
    }
    function S2(a, b, e) {
      if (null == a) return a;
      var d = [], c = 0;
      R2(a, d, "", "", function(a2) {
        return b.call(e, a2, c++);
      });
      return d;
    }
    function T(a) {
      if (-1 === a._status) {
        var b = a._result;
        b = b();
        b.then(function(b2) {
          if (0 === a._status || -1 === a._status) a._status = 1, a._result = b2;
        }, function(b2) {
          if (0 === a._status || -1 === a._status) a._status = 2, a._result = b2;
        });
        -1 === a._status && (a._status = 0, a._result = b);
      }
      if (1 === a._status) return a._result.default;
      throw a._result;
    }
    var U = { current: null };
    var V = { transition: null };
    var W = { ReactCurrentDispatcher: U, ReactCurrentBatchConfig: V, ReactCurrentOwner: K };
    function X2() {
      throw Error("act(...) is not supported in production builds of React.");
    }
    exports.Children = { map: S2, forEach: function(a, b, e) {
      S2(a, function() {
        b.apply(this, arguments);
      }, e);
    }, count: function(a) {
      var b = 0;
      S2(a, function() {
        b++;
      });
      return b;
    }, toArray: function(a) {
      return S2(a, function(a2) {
        return a2;
      }) || [];
    }, only: function(a) {
      if (!O(a)) throw Error("React.Children.only expected to receive a single React element child.");
      return a;
    } };
    exports.Component = E;
    exports.Fragment = p;
    exports.Profiler = r2;
    exports.PureComponent = G;
    exports.StrictMode = q;
    exports.Suspense = w;
    exports.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = W;
    exports.act = X2;
    exports.cloneElement = function(a, b, e) {
      if (null === a || void 0 === a) throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + a + ".");
      var d = C2({}, a.props), c = a.key, k = a.ref, h = a._owner;
      if (null != b) {
        void 0 !== b.ref && (k = b.ref, h = K.current);
        void 0 !== b.key && (c = "" + b.key);
        if (a.type && a.type.defaultProps) var g = a.type.defaultProps;
        for (f in b) J.call(b, f) && !L.hasOwnProperty(f) && (d[f] = void 0 === b[f] && void 0 !== g ? g[f] : b[f]);
      }
      var f = arguments.length - 2;
      if (1 === f) d.children = e;
      else if (1 < f) {
        g = Array(f);
        for (var m = 0; m < f; m++) g[m] = arguments[m + 2];
        d.children = g;
      }
      return { $$typeof: l, type: a.type, key: c, ref: k, props: d, _owner: h };
    };
    exports.createContext = function(a) {
      a = { $$typeof: u, _currentValue: a, _currentValue2: a, _threadCount: 0, Provider: null, Consumer: null, _defaultValue: null, _globalName: null };
      a.Provider = { $$typeof: t, _context: a };
      return a.Consumer = a;
    };
    exports.createElement = M;
    exports.createFactory = function(a) {
      var b = M.bind(null, a);
      b.type = a;
      return b;
    };
    exports.createRef = function() {
      return { current: null };
    };
    exports.forwardRef = function(a) {
      return { $$typeof: v, render: a };
    };
    exports.isValidElement = O;
    exports.lazy = function(a) {
      return { $$typeof: y, _payload: { _status: -1, _result: a }, _init: T };
    };
    exports.memo = function(a, b) {
      return { $$typeof: x, type: a, compare: void 0 === b ? null : b };
    };
    exports.startTransition = function(a) {
      var b = V.transition;
      V.transition = {};
      try {
        a();
      } finally {
        V.transition = b;
      }
    };
    exports.unstable_act = X2;
    exports.useCallback = function(a, b) {
      return U.current.useCallback(a, b);
    };
    exports.useContext = function(a) {
      return U.current.useContext(a);
    };
    exports.useDebugValue = function() {
    };
    exports.useDeferredValue = function(a) {
      return U.current.useDeferredValue(a);
    };
    exports.useEffect = function(a, b) {
      return U.current.useEffect(a, b);
    };
    exports.useId = function() {
      return U.current.useId();
    };
    exports.useImperativeHandle = function(a, b, e) {
      return U.current.useImperativeHandle(a, b, e);
    };
    exports.useInsertionEffect = function(a, b) {
      return U.current.useInsertionEffect(a, b);
    };
    exports.useLayoutEffect = function(a, b) {
      return U.current.useLayoutEffect(a, b);
    };
    exports.useMemo = function(a, b) {
      return U.current.useMemo(a, b);
    };
    exports.useReducer = function(a, b, e) {
      return U.current.useReducer(a, b, e);
    };
    exports.useRef = function(a) {
      return U.current.useRef(a);
    };
    exports.useState = function(a) {
      return U.current.useState(a);
    };
    exports.useSyncExternalStore = function(a, b, e) {
      return U.current.useSyncExternalStore(a, b, e);
    };
    exports.useTransition = function() {
      return U.current.useTransition();
    };
    exports.version = "18.3.1";
  }
});

// node_modules/react/index.js
var require_react = __commonJS({
  "node_modules/react/index.js"(exports, module) {
    "use strict";
    if (true) {
      module.exports = require_react_production_min();
    } else {
      module.exports = null;
    }
  }
});

// node_modules/scheduler/cjs/scheduler.production.min.js
var require_scheduler_production_min = __commonJS({
  "node_modules/scheduler/cjs/scheduler.production.min.js"(exports) {
    "use strict";
    function f(a, b) {
      var c = a.length;
      a.push(b);
      a: for (; 0 < c; ) {
        var d = c - 1 >>> 1, e = a[d];
        if (0 < g(e, b)) a[d] = b, a[c] = e, c = d;
        else break a;
      }
    }
    function h(a) {
      return 0 === a.length ? null : a[0];
    }
    function k(a) {
      if (0 === a.length) return null;
      var b = a[0], c = a.pop();
      if (c !== b) {
        a[0] = c;
        a: for (var d = 0, e = a.length, w = e >>> 1; d < w; ) {
          var m = 2 * (d + 1) - 1, C2 = a[m], n = m + 1, x = a[n];
          if (0 > g(C2, c)) n < e && 0 > g(x, C2) ? (a[d] = x, a[n] = c, d = n) : (a[d] = C2, a[m] = c, d = m);
          else if (n < e && 0 > g(x, c)) a[d] = x, a[n] = c, d = n;
          else break a;
        }
      }
      return b;
    }
    function g(a, b) {
      var c = a.sortIndex - b.sortIndex;
      return 0 !== c ? c : a.id - b.id;
    }
    if ("object" === typeof performance && "function" === typeof performance.now) {
      l = performance;
      exports.unstable_now = function() {
        return l.now();
      };
    } else {
      p = Date, q = p.now();
      exports.unstable_now = function() {
        return p.now() - q;
      };
    }
    var l;
    var p;
    var q;
    var r2 = [];
    var t = [];
    var u = 1;
    var v = null;
    var y = 3;
    var z = false;
    var A = false;
    var B2 = false;
    var D = "function" === typeof setTimeout ? setTimeout : null;
    var E = "function" === typeof clearTimeout ? clearTimeout : null;
    var F = "undefined" !== typeof setImmediate ? setImmediate : null;
    "undefined" !== typeof navigator && void 0 !== navigator.scheduling && void 0 !== navigator.scheduling.isInputPending && navigator.scheduling.isInputPending.bind(navigator.scheduling);
    function G(a) {
      for (var b = h(t); null !== b; ) {
        if (null === b.callback) k(t);
        else if (b.startTime <= a) k(t), b.sortIndex = b.expirationTime, f(r2, b);
        else break;
        b = h(t);
      }
    }
    function H(a) {
      B2 = false;
      G(a);
      if (!A) if (null !== h(r2)) A = true, I(J);
      else {
        var b = h(t);
        null !== b && K(H, b.startTime - a);
      }
    }
    function J(a, b) {
      A = false;
      B2 && (B2 = false, E(L), L = -1);
      z = true;
      var c = y;
      try {
        G(b);
        for (v = h(r2); null !== v && (!(v.expirationTime > b) || a && !M()); ) {
          var d = v.callback;
          if ("function" === typeof d) {
            v.callback = null;
            y = v.priorityLevel;
            var e = d(v.expirationTime <= b);
            b = exports.unstable_now();
            "function" === typeof e ? v.callback = e : v === h(r2) && k(r2);
            G(b);
          } else k(r2);
          v = h(r2);
        }
        if (null !== v) var w = true;
        else {
          var m = h(t);
          null !== m && K(H, m.startTime - b);
          w = false;
        }
        return w;
      } finally {
        v = null, y = c, z = false;
      }
    }
    var N = false;
    var O = null;
    var L = -1;
    var P = 5;
    var Q = -1;
    function M() {
      return exports.unstable_now() - Q < P ? false : true;
    }
    function R2() {
      if (null !== O) {
        var a = exports.unstable_now();
        Q = a;
        var b = true;
        try {
          b = O(true, a);
        } finally {
          b ? S2() : (N = false, O = null);
        }
      } else N = false;
    }
    var S2;
    if ("function" === typeof F) S2 = function() {
      F(R2);
    };
    else if ("undefined" !== typeof MessageChannel) {
      T = new MessageChannel(), U = T.port2;
      T.port1.onmessage = R2;
      S2 = function() {
        U.postMessage(null);
      };
    } else S2 = function() {
      D(R2, 0);
    };
    var T;
    var U;
    function I(a) {
      O = a;
      N || (N = true, S2());
    }
    function K(a, b) {
      L = D(function() {
        a(exports.unstable_now());
      }, b);
    }
    exports.unstable_IdlePriority = 5;
    exports.unstable_ImmediatePriority = 1;
    exports.unstable_LowPriority = 4;
    exports.unstable_NormalPriority = 3;
    exports.unstable_Profiling = null;
    exports.unstable_UserBlockingPriority = 2;
    exports.unstable_cancelCallback = function(a) {
      a.callback = null;
    };
    exports.unstable_continueExecution = function() {
      A || z || (A = true, I(J));
    };
    exports.unstable_forceFrameRate = function(a) {
      0 > a || 125 < a ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : P = 0 < a ? Math.floor(1e3 / a) : 5;
    };
    exports.unstable_getCurrentPriorityLevel = function() {
      return y;
    };
    exports.unstable_getFirstCallbackNode = function() {
      return h(r2);
    };
    exports.unstable_next = function(a) {
      switch (y) {
        case 1:
        case 2:
        case 3:
          var b = 3;
          break;
        default:
          b = y;
      }
      var c = y;
      y = b;
      try {
        return a();
      } finally {
        y = c;
      }
    };
    exports.unstable_pauseExecution = function() {
    };
    exports.unstable_requestPaint = function() {
    };
    exports.unstable_runWithPriority = function(a, b) {
      switch (a) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
          break;
        default:
          a = 3;
      }
      var c = y;
      y = a;
      try {
        return b();
      } finally {
        y = c;
      }
    };
    exports.unstable_scheduleCallback = function(a, b, c) {
      var d = exports.unstable_now();
      "object" === typeof c && null !== c ? (c = c.delay, c = "number" === typeof c && 0 < c ? d + c : d) : c = d;
      switch (a) {
        case 1:
          var e = -1;
          break;
        case 2:
          e = 250;
          break;
        case 5:
          e = 1073741823;
          break;
        case 4:
          e = 1e4;
          break;
        default:
          e = 5e3;
      }
      e = c + e;
      a = { id: u++, callback: b, priorityLevel: a, startTime: c, expirationTime: e, sortIndex: -1 };
      c > d ? (a.sortIndex = c, f(t, a), null === h(r2) && a === h(t) && (B2 ? (E(L), L = -1) : B2 = true, K(H, c - d))) : (a.sortIndex = e, f(r2, a), A || z || (A = true, I(J)));
      return a;
    };
    exports.unstable_shouldYield = M;
    exports.unstable_wrapCallback = function(a) {
      var b = y;
      return function() {
        var c = y;
        y = b;
        try {
          return a.apply(this, arguments);
        } finally {
          y = c;
        }
      };
    };
  }
});

// node_modules/scheduler/index.js
var require_scheduler = __commonJS({
  "node_modules/scheduler/index.js"(exports, module) {
    "use strict";
    if (true) {
      module.exports = require_scheduler_production_min();
    } else {
      module.exports = null;
    }
  }
});

// node_modules/react-dom/cjs/react-dom.production.min.js
var require_react_dom_production_min = __commonJS({
  "node_modules/react-dom/cjs/react-dom.production.min.js"(exports) {
    "use strict";
    var aa = require_react();
    var ca = require_scheduler();
    function p(a) {
      for (var b = "https://reactjs.org/docs/error-decoder.html?invariant=" + a, c = 1; c < arguments.length; c++) b += "&args[]=" + encodeURIComponent(arguments[c]);
      return "Minified React error #" + a + "; visit " + b + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
    }
    var da = /* @__PURE__ */ new Set();
    var ea = {};
    function fa(a, b) {
      ha(a, b);
      ha(a + "Capture", b);
    }
    function ha(a, b) {
      ea[a] = b;
      for (a = 0; a < b.length; a++) da.add(b[a]);
    }
    var ia = !("undefined" === typeof window || "undefined" === typeof window.document || "undefined" === typeof window.document.createElement);
    var ja = Object.prototype.hasOwnProperty;
    var ka = /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/;
    var la = {};
    var ma = {};
    function oa(a) {
      if (ja.call(ma, a)) return true;
      if (ja.call(la, a)) return false;
      if (ka.test(a)) return ma[a] = true;
      la[a] = true;
      return false;
    }
    function pa(a, b, c, d) {
      if (null !== c && 0 === c.type) return false;
      switch (typeof b) {
        case "function":
        case "symbol":
          return true;
        case "boolean":
          if (d) return false;
          if (null !== c) return !c.acceptsBooleans;
          a = a.toLowerCase().slice(0, 5);
          return "data-" !== a && "aria-" !== a;
        default:
          return false;
      }
    }
    function qa(a, b, c, d) {
      if (null === b || "undefined" === typeof b || pa(a, b, c, d)) return true;
      if (d) return false;
      if (null !== c) switch (c.type) {
        case 3:
          return !b;
        case 4:
          return false === b;
        case 5:
          return isNaN(b);
        case 6:
          return isNaN(b) || 1 > b;
      }
      return false;
    }
    function v(a, b, c, d, e, f, g) {
      this.acceptsBooleans = 2 === b || 3 === b || 4 === b;
      this.attributeName = d;
      this.attributeNamespace = e;
      this.mustUseProperty = c;
      this.propertyName = a;
      this.type = b;
      this.sanitizeURL = f;
      this.removeEmptyString = g;
    }
    var z = {};
    "children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(a) {
      z[a] = new v(a, 0, false, a, null, false, false);
    });
    [["acceptCharset", "accept-charset"], ["className", "class"], ["htmlFor", "for"], ["httpEquiv", "http-equiv"]].forEach(function(a) {
      var b = a[0];
      z[b] = new v(b, 1, false, a[1], null, false, false);
    });
    ["contentEditable", "draggable", "spellCheck", "value"].forEach(function(a) {
      z[a] = new v(a, 2, false, a.toLowerCase(), null, false, false);
    });
    ["autoReverse", "externalResourcesRequired", "focusable", "preserveAlpha"].forEach(function(a) {
      z[a] = new v(a, 2, false, a, null, false, false);
    });
    "allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(a) {
      z[a] = new v(a, 3, false, a.toLowerCase(), null, false, false);
    });
    ["checked", "multiple", "muted", "selected"].forEach(function(a) {
      z[a] = new v(a, 3, true, a, null, false, false);
    });
    ["capture", "download"].forEach(function(a) {
      z[a] = new v(a, 4, false, a, null, false, false);
    });
    ["cols", "rows", "size", "span"].forEach(function(a) {
      z[a] = new v(a, 6, false, a, null, false, false);
    });
    ["rowSpan", "start"].forEach(function(a) {
      z[a] = new v(a, 5, false, a.toLowerCase(), null, false, false);
    });
    var ra = /[\-:]([a-z])/g;
    function sa(a) {
      return a[1].toUpperCase();
    }
    "accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(a) {
      var b = a.replace(
        ra,
        sa
      );
      z[b] = new v(b, 1, false, a, null, false, false);
    });
    "xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(a) {
      var b = a.replace(ra, sa);
      z[b] = new v(b, 1, false, a, "http://www.w3.org/1999/xlink", false, false);
    });
    ["xml:base", "xml:lang", "xml:space"].forEach(function(a) {
      var b = a.replace(ra, sa);
      z[b] = new v(b, 1, false, a, "http://www.w3.org/XML/1998/namespace", false, false);
    });
    ["tabIndex", "crossOrigin"].forEach(function(a) {
      z[a] = new v(a, 1, false, a.toLowerCase(), null, false, false);
    });
    z.xlinkHref = new v("xlinkHref", 1, false, "xlink:href", "http://www.w3.org/1999/xlink", true, false);
    ["src", "href", "action", "formAction"].forEach(function(a) {
      z[a] = new v(a, 1, false, a.toLowerCase(), null, true, true);
    });
    function ta(a, b, c, d) {
      var e = z.hasOwnProperty(b) ? z[b] : null;
      if (null !== e ? 0 !== e.type : d || !(2 < b.length) || "o" !== b[0] && "O" !== b[0] || "n" !== b[1] && "N" !== b[1]) qa(b, c, e, d) && (c = null), d || null === e ? oa(b) && (null === c ? a.removeAttribute(b) : a.setAttribute(b, "" + c)) : e.mustUseProperty ? a[e.propertyName] = null === c ? 3 === e.type ? false : "" : c : (b = e.attributeName, d = e.attributeNamespace, null === c ? a.removeAttribute(b) : (e = e.type, c = 3 === e || 4 === e && true === c ? "" : "" + c, d ? a.setAttributeNS(d, b, c) : a.setAttribute(b, c)));
    }
    var ua = aa.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;
    var va = Symbol.for("react.element");
    var wa = Symbol.for("react.portal");
    var ya = Symbol.for("react.fragment");
    var za = Symbol.for("react.strict_mode");
    var Aa = Symbol.for("react.profiler");
    var Ba = Symbol.for("react.provider");
    var Ca = Symbol.for("react.context");
    var Da = Symbol.for("react.forward_ref");
    var Ea = Symbol.for("react.suspense");
    var Fa = Symbol.for("react.suspense_list");
    var Ga = Symbol.for("react.memo");
    var Ha = Symbol.for("react.lazy");
    Symbol.for("react.scope");
    Symbol.for("react.debug_trace_mode");
    var Ia = Symbol.for("react.offscreen");
    Symbol.for("react.legacy_hidden");
    Symbol.for("react.cache");
    Symbol.for("react.tracing_marker");
    var Ja = Symbol.iterator;
    function Ka(a) {
      if (null === a || "object" !== typeof a) return null;
      a = Ja && a[Ja] || a["@@iterator"];
      return "function" === typeof a ? a : null;
    }
    var A = Object.assign;
    var La;
    function Ma(a) {
      if (void 0 === La) try {
        throw Error();
      } catch (c) {
        var b = c.stack.trim().match(/\n( *(at )?)/);
        La = b && b[1] || "";
      }
      return "\n" + La + a;
    }
    var Na = false;
    function Oa(a, b) {
      if (!a || Na) return "";
      Na = true;
      var c = Error.prepareStackTrace;
      Error.prepareStackTrace = void 0;
      try {
        if (b) if (b = function() {
          throw Error();
        }, Object.defineProperty(b.prototype, "props", { set: function() {
          throw Error();
        } }), "object" === typeof Reflect && Reflect.construct) {
          try {
            Reflect.construct(b, []);
          } catch (l) {
            var d = l;
          }
          Reflect.construct(a, [], b);
        } else {
          try {
            b.call();
          } catch (l) {
            d = l;
          }
          a.call(b.prototype);
        }
        else {
          try {
            throw Error();
          } catch (l) {
            d = l;
          }
          a();
        }
      } catch (l) {
        if (l && d && "string" === typeof l.stack) {
          for (var e = l.stack.split("\n"), f = d.stack.split("\n"), g = e.length - 1, h = f.length - 1; 1 <= g && 0 <= h && e[g] !== f[h]; ) h--;
          for (; 1 <= g && 0 <= h; g--, h--) if (e[g] !== f[h]) {
            if (1 !== g || 1 !== h) {
              do
                if (g--, h--, 0 > h || e[g] !== f[h]) {
                  var k = "\n" + e[g].replace(" at new ", " at ");
                  a.displayName && k.includes("<anonymous>") && (k = k.replace("<anonymous>", a.displayName));
                  return k;
                }
              while (1 <= g && 0 <= h);
            }
            break;
          }
        }
      } finally {
        Na = false, Error.prepareStackTrace = c;
      }
      return (a = a ? a.displayName || a.name : "") ? Ma(a) : "";
    }
    function Pa(a) {
      switch (a.tag) {
        case 5:
          return Ma(a.type);
        case 16:
          return Ma("Lazy");
        case 13:
          return Ma("Suspense");
        case 19:
          return Ma("SuspenseList");
        case 0:
        case 2:
        case 15:
          return a = Oa(a.type, false), a;
        case 11:
          return a = Oa(a.type.render, false), a;
        case 1:
          return a = Oa(a.type, true), a;
        default:
          return "";
      }
    }
    function Qa(a) {
      if (null == a) return null;
      if ("function" === typeof a) return a.displayName || a.name || null;
      if ("string" === typeof a) return a;
      switch (a) {
        case ya:
          return "Fragment";
        case wa:
          return "Portal";
        case Aa:
          return "Profiler";
        case za:
          return "StrictMode";
        case Ea:
          return "Suspense";
        case Fa:
          return "SuspenseList";
      }
      if ("object" === typeof a) switch (a.$$typeof) {
        case Ca:
          return (a.displayName || "Context") + ".Consumer";
        case Ba:
          return (a._context.displayName || "Context") + ".Provider";
        case Da:
          var b = a.render;
          a = a.displayName;
          a || (a = b.displayName || b.name || "", a = "" !== a ? "ForwardRef(" + a + ")" : "ForwardRef");
          return a;
        case Ga:
          return b = a.displayName || null, null !== b ? b : Qa(a.type) || "Memo";
        case Ha:
          b = a._payload;
          a = a._init;
          try {
            return Qa(a(b));
          } catch (c) {
          }
      }
      return null;
    }
    function Ra(a) {
      var b = a.type;
      switch (a.tag) {
        case 24:
          return "Cache";
        case 9:
          return (b.displayName || "Context") + ".Consumer";
        case 10:
          return (b._context.displayName || "Context") + ".Provider";
        case 18:
          return "DehydratedFragment";
        case 11:
          return a = b.render, a = a.displayName || a.name || "", b.displayName || ("" !== a ? "ForwardRef(" + a + ")" : "ForwardRef");
        case 7:
          return "Fragment";
        case 5:
          return b;
        case 4:
          return "Portal";
        case 3:
          return "Root";
        case 6:
          return "Text";
        case 16:
          return Qa(b);
        case 8:
          return b === za ? "StrictMode" : "Mode";
        case 22:
          return "Offscreen";
        case 12:
          return "Profiler";
        case 21:
          return "Scope";
        case 13:
          return "Suspense";
        case 19:
          return "SuspenseList";
        case 25:
          return "TracingMarker";
        case 1:
        case 0:
        case 17:
        case 2:
        case 14:
        case 15:
          if ("function" === typeof b) return b.displayName || b.name || null;
          if ("string" === typeof b) return b;
      }
      return null;
    }
    function Sa(a) {
      switch (typeof a) {
        case "boolean":
        case "number":
        case "string":
        case "undefined":
          return a;
        case "object":
          return a;
        default:
          return "";
      }
    }
    function Ta(a) {
      var b = a.type;
      return (a = a.nodeName) && "input" === a.toLowerCase() && ("checkbox" === b || "radio" === b);
    }
    function Ua(a) {
      var b = Ta(a) ? "checked" : "value", c = Object.getOwnPropertyDescriptor(a.constructor.prototype, b), d = "" + a[b];
      if (!a.hasOwnProperty(b) && "undefined" !== typeof c && "function" === typeof c.get && "function" === typeof c.set) {
        var e = c.get, f = c.set;
        Object.defineProperty(a, b, { configurable: true, get: function() {
          return e.call(this);
        }, set: function(a2) {
          d = "" + a2;
          f.call(this, a2);
        } });
        Object.defineProperty(a, b, { enumerable: c.enumerable });
        return { getValue: function() {
          return d;
        }, setValue: function(a2) {
          d = "" + a2;
        }, stopTracking: function() {
          a._valueTracker = null;
          delete a[b];
        } };
      }
    }
    function Va(a) {
      a._valueTracker || (a._valueTracker = Ua(a));
    }
    function Wa(a) {
      if (!a) return false;
      var b = a._valueTracker;
      if (!b) return true;
      var c = b.getValue();
      var d = "";
      a && (d = Ta(a) ? a.checked ? "true" : "false" : a.value);
      a = d;
      return a !== c ? (b.setValue(a), true) : false;
    }
    function Xa(a) {
      a = a || ("undefined" !== typeof document ? document : void 0);
      if ("undefined" === typeof a) return null;
      try {
        return a.activeElement || a.body;
      } catch (b) {
        return a.body;
      }
    }
    function Ya(a, b) {
      var c = b.checked;
      return A({}, b, { defaultChecked: void 0, defaultValue: void 0, value: void 0, checked: null != c ? c : a._wrapperState.initialChecked });
    }
    function Za(a, b) {
      var c = null == b.defaultValue ? "" : b.defaultValue, d = null != b.checked ? b.checked : b.defaultChecked;
      c = Sa(null != b.value ? b.value : c);
      a._wrapperState = { initialChecked: d, initialValue: c, controlled: "checkbox" === b.type || "radio" === b.type ? null != b.checked : null != b.value };
    }
    function ab(a, b) {
      b = b.checked;
      null != b && ta(a, "checked", b, false);
    }
    function bb(a, b) {
      ab(a, b);
      var c = Sa(b.value), d = b.type;
      if (null != c) if ("number" === d) {
        if (0 === c && "" === a.value || a.value != c) a.value = "" + c;
      } else a.value !== "" + c && (a.value = "" + c);
      else if ("submit" === d || "reset" === d) {
        a.removeAttribute("value");
        return;
      }
      b.hasOwnProperty("value") ? cb(a, b.type, c) : b.hasOwnProperty("defaultValue") && cb(a, b.type, Sa(b.defaultValue));
      null == b.checked && null != b.defaultChecked && (a.defaultChecked = !!b.defaultChecked);
    }
    function db(a, b, c) {
      if (b.hasOwnProperty("value") || b.hasOwnProperty("defaultValue")) {
        var d = b.type;
        if (!("submit" !== d && "reset" !== d || void 0 !== b.value && null !== b.value)) return;
        b = "" + a._wrapperState.initialValue;
        c || b === a.value || (a.value = b);
        a.defaultValue = b;
      }
      c = a.name;
      "" !== c && (a.name = "");
      a.defaultChecked = !!a._wrapperState.initialChecked;
      "" !== c && (a.name = c);
    }
    function cb(a, b, c) {
      if ("number" !== b || Xa(a.ownerDocument) !== a) null == c ? a.defaultValue = "" + a._wrapperState.initialValue : a.defaultValue !== "" + c && (a.defaultValue = "" + c);
    }
    var eb = Array.isArray;
    function fb(a, b, c, d) {
      a = a.options;
      if (b) {
        b = {};
        for (var e = 0; e < c.length; e++) b["$" + c[e]] = true;
        for (c = 0; c < a.length; c++) e = b.hasOwnProperty("$" + a[c].value), a[c].selected !== e && (a[c].selected = e), e && d && (a[c].defaultSelected = true);
      } else {
        c = "" + Sa(c);
        b = null;
        for (e = 0; e < a.length; e++) {
          if (a[e].value === c) {
            a[e].selected = true;
            d && (a[e].defaultSelected = true);
            return;
          }
          null !== b || a[e].disabled || (b = a[e]);
        }
        null !== b && (b.selected = true);
      }
    }
    function gb(a, b) {
      if (null != b.dangerouslySetInnerHTML) throw Error(p(91));
      return A({}, b, { value: void 0, defaultValue: void 0, children: "" + a._wrapperState.initialValue });
    }
    function hb(a, b) {
      var c = b.value;
      if (null == c) {
        c = b.children;
        b = b.defaultValue;
        if (null != c) {
          if (null != b) throw Error(p(92));
          if (eb(c)) {
            if (1 < c.length) throw Error(p(93));
            c = c[0];
          }
          b = c;
        }
        null == b && (b = "");
        c = b;
      }
      a._wrapperState = { initialValue: Sa(c) };
    }
    function ib(a, b) {
      var c = Sa(b.value), d = Sa(b.defaultValue);
      null != c && (c = "" + c, c !== a.value && (a.value = c), null == b.defaultValue && a.defaultValue !== c && (a.defaultValue = c));
      null != d && (a.defaultValue = "" + d);
    }
    function jb(a) {
      var b = a.textContent;
      b === a._wrapperState.initialValue && "" !== b && null !== b && (a.value = b);
    }
    function kb(a) {
      switch (a) {
        case "svg":
          return "http://www.w3.org/2000/svg";
        case "math":
          return "http://www.w3.org/1998/Math/MathML";
        default:
          return "http://www.w3.org/1999/xhtml";
      }
    }
    function lb(a, b) {
      return null == a || "http://www.w3.org/1999/xhtml" === a ? kb(b) : "http://www.w3.org/2000/svg" === a && "foreignObject" === b ? "http://www.w3.org/1999/xhtml" : a;
    }
    var mb;
    var nb = function(a) {
      return "undefined" !== typeof MSApp && MSApp.execUnsafeLocalFunction ? function(b, c, d, e) {
        MSApp.execUnsafeLocalFunction(function() {
          return a(b, c, d, e);
        });
      } : a;
    }(function(a, b) {
      if ("http://www.w3.org/2000/svg" !== a.namespaceURI || "innerHTML" in a) a.innerHTML = b;
      else {
        mb = mb || document.createElement("div");
        mb.innerHTML = "<svg>" + b.valueOf().toString() + "</svg>";
        for (b = mb.firstChild; a.firstChild; ) a.removeChild(a.firstChild);
        for (; b.firstChild; ) a.appendChild(b.firstChild);
      }
    });
    function ob(a, b) {
      if (b) {
        var c = a.firstChild;
        if (c && c === a.lastChild && 3 === c.nodeType) {
          c.nodeValue = b;
          return;
        }
      }
      a.textContent = b;
    }
    var pb = {
      animationIterationCount: true,
      aspectRatio: true,
      borderImageOutset: true,
      borderImageSlice: true,
      borderImageWidth: true,
      boxFlex: true,
      boxFlexGroup: true,
      boxOrdinalGroup: true,
      columnCount: true,
      columns: true,
      flex: true,
      flexGrow: true,
      flexPositive: true,
      flexShrink: true,
      flexNegative: true,
      flexOrder: true,
      gridArea: true,
      gridRow: true,
      gridRowEnd: true,
      gridRowSpan: true,
      gridRowStart: true,
      gridColumn: true,
      gridColumnEnd: true,
      gridColumnSpan: true,
      gridColumnStart: true,
      fontWeight: true,
      lineClamp: true,
      lineHeight: true,
      opacity: true,
      order: true,
      orphans: true,
      tabSize: true,
      widows: true,
      zIndex: true,
      zoom: true,
      fillOpacity: true,
      floodOpacity: true,
      stopOpacity: true,
      strokeDasharray: true,
      strokeDashoffset: true,
      strokeMiterlimit: true,
      strokeOpacity: true,
      strokeWidth: true
    };
    var qb = ["Webkit", "ms", "Moz", "O"];
    Object.keys(pb).forEach(function(a) {
      qb.forEach(function(b) {
        b = b + a.charAt(0).toUpperCase() + a.substring(1);
        pb[b] = pb[a];
      });
    });
    function rb(a, b, c) {
      return null == b || "boolean" === typeof b || "" === b ? "" : c || "number" !== typeof b || 0 === b || pb.hasOwnProperty(a) && pb[a] ? ("" + b).trim() : b + "px";
    }
    function sb(a, b) {
      a = a.style;
      for (var c in b) if (b.hasOwnProperty(c)) {
        var d = 0 === c.indexOf("--"), e = rb(c, b[c], d);
        "float" === c && (c = "cssFloat");
        d ? a.setProperty(c, e) : a[c] = e;
      }
    }
    var tb = A({ menuitem: true }, { area: true, base: true, br: true, col: true, embed: true, hr: true, img: true, input: true, keygen: true, link: true, meta: true, param: true, source: true, track: true, wbr: true });
    function ub(a, b) {
      if (b) {
        if (tb[a] && (null != b.children || null != b.dangerouslySetInnerHTML)) throw Error(p(137, a));
        if (null != b.dangerouslySetInnerHTML) {
          if (null != b.children) throw Error(p(60));
          if ("object" !== typeof b.dangerouslySetInnerHTML || !("__html" in b.dangerouslySetInnerHTML)) throw Error(p(61));
        }
        if (null != b.style && "object" !== typeof b.style) throw Error(p(62));
      }
    }
    function vb(a, b) {
      if (-1 === a.indexOf("-")) return "string" === typeof b.is;
      switch (a) {
        case "annotation-xml":
        case "color-profile":
        case "font-face":
        case "font-face-src":
        case "font-face-uri":
        case "font-face-format":
        case "font-face-name":
        case "missing-glyph":
          return false;
        default:
          return true;
      }
    }
    var wb = null;
    function xb(a) {
      a = a.target || a.srcElement || window;
      a.correspondingUseElement && (a = a.correspondingUseElement);
      return 3 === a.nodeType ? a.parentNode : a;
    }
    var yb = null;
    var zb = null;
    var Ab = null;
    function Bb(a) {
      if (a = Cb(a)) {
        if ("function" !== typeof yb) throw Error(p(280));
        var b = a.stateNode;
        b && (b = Db(b), yb(a.stateNode, a.type, b));
      }
    }
    function Eb(a) {
      zb ? Ab ? Ab.push(a) : Ab = [a] : zb = a;
    }
    function Fb() {
      if (zb) {
        var a = zb, b = Ab;
        Ab = zb = null;
        Bb(a);
        if (b) for (a = 0; a < b.length; a++) Bb(b[a]);
      }
    }
    function Gb(a, b) {
      return a(b);
    }
    function Hb() {
    }
    var Ib = false;
    function Jb(a, b, c) {
      if (Ib) return a(b, c);
      Ib = true;
      try {
        return Gb(a, b, c);
      } finally {
        if (Ib = false, null !== zb || null !== Ab) Hb(), Fb();
      }
    }
    function Kb(a, b) {
      var c = a.stateNode;
      if (null === c) return null;
      var d = Db(c);
      if (null === d) return null;
      c = d[b];
      a: switch (b) {
        case "onClick":
        case "onClickCapture":
        case "onDoubleClick":
        case "onDoubleClickCapture":
        case "onMouseDown":
        case "onMouseDownCapture":
        case "onMouseMove":
        case "onMouseMoveCapture":
        case "onMouseUp":
        case "onMouseUpCapture":
        case "onMouseEnter":
          (d = !d.disabled) || (a = a.type, d = !("button" === a || "input" === a || "select" === a || "textarea" === a));
          a = !d;
          break a;
        default:
          a = false;
      }
      if (a) return null;
      if (c && "function" !== typeof c) throw Error(p(231, b, typeof c));
      return c;
    }
    var Lb = false;
    if (ia) try {
      Mb = {};
      Object.defineProperty(Mb, "passive", { get: function() {
        Lb = true;
      } });
      window.addEventListener("test", Mb, Mb);
      window.removeEventListener("test", Mb, Mb);
    } catch (a) {
      Lb = false;
    }
    var Mb;
    function Nb(a, b, c, d, e, f, g, h, k) {
      var l = Array.prototype.slice.call(arguments, 3);
      try {
        b.apply(c, l);
      } catch (m) {
        this.onError(m);
      }
    }
    var Ob = false;
    var Pb = null;
    var Qb = false;
    var Rb = null;
    var Sb = { onError: function(a) {
      Ob = true;
      Pb = a;
    } };
    function Tb(a, b, c, d, e, f, g, h, k) {
      Ob = false;
      Pb = null;
      Nb.apply(Sb, arguments);
    }
    function Ub(a, b, c, d, e, f, g, h, k) {
      Tb.apply(this, arguments);
      if (Ob) {
        if (Ob) {
          var l = Pb;
          Ob = false;
          Pb = null;
        } else throw Error(p(198));
        Qb || (Qb = true, Rb = l);
      }
    }
    function Vb(a) {
      var b = a, c = a;
      if (a.alternate) for (; b.return; ) b = b.return;
      else {
        a = b;
        do
          b = a, 0 !== (b.flags & 4098) && (c = b.return), a = b.return;
        while (a);
      }
      return 3 === b.tag ? c : null;
    }
    function Wb(a) {
      if (13 === a.tag) {
        var b = a.memoizedState;
        null === b && (a = a.alternate, null !== a && (b = a.memoizedState));
        if (null !== b) return b.dehydrated;
      }
      return null;
    }
    function Xb(a) {
      if (Vb(a) !== a) throw Error(p(188));
    }
    function Yb(a) {
      var b = a.alternate;
      if (!b) {
        b = Vb(a);
        if (null === b) throw Error(p(188));
        return b !== a ? null : a;
      }
      for (var c = a, d = b; ; ) {
        var e = c.return;
        if (null === e) break;
        var f = e.alternate;
        if (null === f) {
          d = e.return;
          if (null !== d) {
            c = d;
            continue;
          }
          break;
        }
        if (e.child === f.child) {
          for (f = e.child; f; ) {
            if (f === c) return Xb(e), a;
            if (f === d) return Xb(e), b;
            f = f.sibling;
          }
          throw Error(p(188));
        }
        if (c.return !== d.return) c = e, d = f;
        else {
          for (var g = false, h = e.child; h; ) {
            if (h === c) {
              g = true;
              c = e;
              d = f;
              break;
            }
            if (h === d) {
              g = true;
              d = e;
              c = f;
              break;
            }
            h = h.sibling;
          }
          if (!g) {
            for (h = f.child; h; ) {
              if (h === c) {
                g = true;
                c = f;
                d = e;
                break;
              }
              if (h === d) {
                g = true;
                d = f;
                c = e;
                break;
              }
              h = h.sibling;
            }
            if (!g) throw Error(p(189));
          }
        }
        if (c.alternate !== d) throw Error(p(190));
      }
      if (3 !== c.tag) throw Error(p(188));
      return c.stateNode.current === c ? a : b;
    }
    function Zb(a) {
      a = Yb(a);
      return null !== a ? $b(a) : null;
    }
    function $b(a) {
      if (5 === a.tag || 6 === a.tag) return a;
      for (a = a.child; null !== a; ) {
        var b = $b(a);
        if (null !== b) return b;
        a = a.sibling;
      }
      return null;
    }
    var ac = ca.unstable_scheduleCallback;
    var bc = ca.unstable_cancelCallback;
    var cc = ca.unstable_shouldYield;
    var dc = ca.unstable_requestPaint;
    var B2 = ca.unstable_now;
    var ec = ca.unstable_getCurrentPriorityLevel;
    var fc = ca.unstable_ImmediatePriority;
    var gc = ca.unstable_UserBlockingPriority;
    var hc = ca.unstable_NormalPriority;
    var ic = ca.unstable_LowPriority;
    var jc = ca.unstable_IdlePriority;
    var kc = null;
    var lc = null;
    function mc(a) {
      if (lc && "function" === typeof lc.onCommitFiberRoot) try {
        lc.onCommitFiberRoot(kc, a, void 0, 128 === (a.current.flags & 128));
      } catch (b) {
      }
    }
    var oc = Math.clz32 ? Math.clz32 : nc;
    var pc = Math.log;
    var qc = Math.LN2;
    function nc(a) {
      a >>>= 0;
      return 0 === a ? 32 : 31 - (pc(a) / qc | 0) | 0;
    }
    var rc = 64;
    var sc = 4194304;
    function tc(a) {
      switch (a & -a) {
        case 1:
          return 1;
        case 2:
          return 2;
        case 4:
          return 4;
        case 8:
          return 8;
        case 16:
          return 16;
        case 32:
          return 32;
        case 64:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
          return a & 4194240;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
        case 67108864:
          return a & 130023424;
        case 134217728:
          return 134217728;
        case 268435456:
          return 268435456;
        case 536870912:
          return 536870912;
        case 1073741824:
          return 1073741824;
        default:
          return a;
      }
    }
    function uc(a, b) {
      var c = a.pendingLanes;
      if (0 === c) return 0;
      var d = 0, e = a.suspendedLanes, f = a.pingedLanes, g = c & 268435455;
      if (0 !== g) {
        var h = g & ~e;
        0 !== h ? d = tc(h) : (f &= g, 0 !== f && (d = tc(f)));
      } else g = c & ~e, 0 !== g ? d = tc(g) : 0 !== f && (d = tc(f));
      if (0 === d) return 0;
      if (0 !== b && b !== d && 0 === (b & e) && (e = d & -d, f = b & -b, e >= f || 16 === e && 0 !== (f & 4194240))) return b;
      0 !== (d & 4) && (d |= c & 16);
      b = a.entangledLanes;
      if (0 !== b) for (a = a.entanglements, b &= d; 0 < b; ) c = 31 - oc(b), e = 1 << c, d |= a[c], b &= ~e;
      return d;
    }
    function vc(a, b) {
      switch (a) {
        case 1:
        case 2:
        case 4:
          return b + 250;
        case 8:
        case 16:
        case 32:
        case 64:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
          return b + 5e3;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
        case 67108864:
          return -1;
        case 134217728:
        case 268435456:
        case 536870912:
        case 1073741824:
          return -1;
        default:
          return -1;
      }
    }
    function wc(a, b) {
      for (var c = a.suspendedLanes, d = a.pingedLanes, e = a.expirationTimes, f = a.pendingLanes; 0 < f; ) {
        var g = 31 - oc(f), h = 1 << g, k = e[g];
        if (-1 === k) {
          if (0 === (h & c) || 0 !== (h & d)) e[g] = vc(h, b);
        } else k <= b && (a.expiredLanes |= h);
        f &= ~h;
      }
    }
    function xc(a) {
      a = a.pendingLanes & -1073741825;
      return 0 !== a ? a : a & 1073741824 ? 1073741824 : 0;
    }
    function yc() {
      var a = rc;
      rc <<= 1;
      0 === (rc & 4194240) && (rc = 64);
      return a;
    }
    function zc(a) {
      for (var b = [], c = 0; 31 > c; c++) b.push(a);
      return b;
    }
    function Ac(a, b, c) {
      a.pendingLanes |= b;
      536870912 !== b && (a.suspendedLanes = 0, a.pingedLanes = 0);
      a = a.eventTimes;
      b = 31 - oc(b);
      a[b] = c;
    }
    function Bc(a, b) {
      var c = a.pendingLanes & ~b;
      a.pendingLanes = b;
      a.suspendedLanes = 0;
      a.pingedLanes = 0;
      a.expiredLanes &= b;
      a.mutableReadLanes &= b;
      a.entangledLanes &= b;
      b = a.entanglements;
      var d = a.eventTimes;
      for (a = a.expirationTimes; 0 < c; ) {
        var e = 31 - oc(c), f = 1 << e;
        b[e] = 0;
        d[e] = -1;
        a[e] = -1;
        c &= ~f;
      }
    }
    function Cc(a, b) {
      var c = a.entangledLanes |= b;
      for (a = a.entanglements; c; ) {
        var d = 31 - oc(c), e = 1 << d;
        e & b | a[d] & b && (a[d] |= b);
        c &= ~e;
      }
    }
    var C2 = 0;
    function Dc(a) {
      a &= -a;
      return 1 < a ? 4 < a ? 0 !== (a & 268435455) ? 16 : 536870912 : 4 : 1;
    }
    var Ec;
    var Fc;
    var Gc;
    var Hc;
    var Ic;
    var Jc = false;
    var Kc = [];
    var Lc = null;
    var Mc = null;
    var Nc = null;
    var Oc = /* @__PURE__ */ new Map();
    var Pc = /* @__PURE__ */ new Map();
    var Qc = [];
    var Rc = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");
    function Sc(a, b) {
      switch (a) {
        case "focusin":
        case "focusout":
          Lc = null;
          break;
        case "dragenter":
        case "dragleave":
          Mc = null;
          break;
        case "mouseover":
        case "mouseout":
          Nc = null;
          break;
        case "pointerover":
        case "pointerout":
          Oc.delete(b.pointerId);
          break;
        case "gotpointercapture":
        case "lostpointercapture":
          Pc.delete(b.pointerId);
      }
    }
    function Tc(a, b, c, d, e, f) {
      if (null === a || a.nativeEvent !== f) return a = { blockedOn: b, domEventName: c, eventSystemFlags: d, nativeEvent: f, targetContainers: [e] }, null !== b && (b = Cb(b), null !== b && Fc(b)), a;
      a.eventSystemFlags |= d;
      b = a.targetContainers;
      null !== e && -1 === b.indexOf(e) && b.push(e);
      return a;
    }
    function Uc(a, b, c, d, e) {
      switch (b) {
        case "focusin":
          return Lc = Tc(Lc, a, b, c, d, e), true;
        case "dragenter":
          return Mc = Tc(Mc, a, b, c, d, e), true;
        case "mouseover":
          return Nc = Tc(Nc, a, b, c, d, e), true;
        case "pointerover":
          var f = e.pointerId;
          Oc.set(f, Tc(Oc.get(f) || null, a, b, c, d, e));
          return true;
        case "gotpointercapture":
          return f = e.pointerId, Pc.set(f, Tc(Pc.get(f) || null, a, b, c, d, e)), true;
      }
      return false;
    }
    function Vc(a) {
      var b = Wc(a.target);
      if (null !== b) {
        var c = Vb(b);
        if (null !== c) {
          if (b = c.tag, 13 === b) {
            if (b = Wb(c), null !== b) {
              a.blockedOn = b;
              Ic(a.priority, function() {
                Gc(c);
              });
              return;
            }
          } else if (3 === b && c.stateNode.current.memoizedState.isDehydrated) {
            a.blockedOn = 3 === c.tag ? c.stateNode.containerInfo : null;
            return;
          }
        }
      }
      a.blockedOn = null;
    }
    function Xc(a) {
      if (null !== a.blockedOn) return false;
      for (var b = a.targetContainers; 0 < b.length; ) {
        var c = Yc(a.domEventName, a.eventSystemFlags, b[0], a.nativeEvent);
        if (null === c) {
          c = a.nativeEvent;
          var d = new c.constructor(c.type, c);
          wb = d;
          c.target.dispatchEvent(d);
          wb = null;
        } else return b = Cb(c), null !== b && Fc(b), a.blockedOn = c, false;
        b.shift();
      }
      return true;
    }
    function Zc(a, b, c) {
      Xc(a) && c.delete(b);
    }
    function $c() {
      Jc = false;
      null !== Lc && Xc(Lc) && (Lc = null);
      null !== Mc && Xc(Mc) && (Mc = null);
      null !== Nc && Xc(Nc) && (Nc = null);
      Oc.forEach(Zc);
      Pc.forEach(Zc);
    }
    function ad(a, b) {
      a.blockedOn === b && (a.blockedOn = null, Jc || (Jc = true, ca.unstable_scheduleCallback(ca.unstable_NormalPriority, $c)));
    }
    function bd(a) {
      function b(b2) {
        return ad(b2, a);
      }
      if (0 < Kc.length) {
        ad(Kc[0], a);
        for (var c = 1; c < Kc.length; c++) {
          var d = Kc[c];
          d.blockedOn === a && (d.blockedOn = null);
        }
      }
      null !== Lc && ad(Lc, a);
      null !== Mc && ad(Mc, a);
      null !== Nc && ad(Nc, a);
      Oc.forEach(b);
      Pc.forEach(b);
      for (c = 0; c < Qc.length; c++) d = Qc[c], d.blockedOn === a && (d.blockedOn = null);
      for (; 0 < Qc.length && (c = Qc[0], null === c.blockedOn); ) Vc(c), null === c.blockedOn && Qc.shift();
    }
    var cd = ua.ReactCurrentBatchConfig;
    var dd = true;
    function ed(a, b, c, d) {
      var e = C2, f = cd.transition;
      cd.transition = null;
      try {
        C2 = 1, fd(a, b, c, d);
      } finally {
        C2 = e, cd.transition = f;
      }
    }
    function gd(a, b, c, d) {
      var e = C2, f = cd.transition;
      cd.transition = null;
      try {
        C2 = 4, fd(a, b, c, d);
      } finally {
        C2 = e, cd.transition = f;
      }
    }
    function fd(a, b, c, d) {
      if (dd) {
        var e = Yc(a, b, c, d);
        if (null === e) hd(a, b, d, id, c), Sc(a, d);
        else if (Uc(e, a, b, c, d)) d.stopPropagation();
        else if (Sc(a, d), b & 4 && -1 < Rc.indexOf(a)) {
          for (; null !== e; ) {
            var f = Cb(e);
            null !== f && Ec(f);
            f = Yc(a, b, c, d);
            null === f && hd(a, b, d, id, c);
            if (f === e) break;
            e = f;
          }
          null !== e && d.stopPropagation();
        } else hd(a, b, d, null, c);
      }
    }
    var id = null;
    function Yc(a, b, c, d) {
      id = null;
      a = xb(d);
      a = Wc(a);
      if (null !== a) if (b = Vb(a), null === b) a = null;
      else if (c = b.tag, 13 === c) {
        a = Wb(b);
        if (null !== a) return a;
        a = null;
      } else if (3 === c) {
        if (b.stateNode.current.memoizedState.isDehydrated) return 3 === b.tag ? b.stateNode.containerInfo : null;
        a = null;
      } else b !== a && (a = null);
      id = a;
      return null;
    }
    function jd(a) {
      switch (a) {
        case "cancel":
        case "click":
        case "close":
        case "contextmenu":
        case "copy":
        case "cut":
        case "auxclick":
        case "dblclick":
        case "dragend":
        case "dragstart":
        case "drop":
        case "focusin":
        case "focusout":
        case "input":
        case "invalid":
        case "keydown":
        case "keypress":
        case "keyup":
        case "mousedown":
        case "mouseup":
        case "paste":
        case "pause":
        case "play":
        case "pointercancel":
        case "pointerdown":
        case "pointerup":
        case "ratechange":
        case "reset":
        case "resize":
        case "seeked":
        case "submit":
        case "touchcancel":
        case "touchend":
        case "touchstart":
        case "volumechange":
        case "change":
        case "selectionchange":
        case "textInput":
        case "compositionstart":
        case "compositionend":
        case "compositionupdate":
        case "beforeblur":
        case "afterblur":
        case "beforeinput":
        case "blur":
        case "fullscreenchange":
        case "focus":
        case "hashchange":
        case "popstate":
        case "select":
        case "selectstart":
          return 1;
        case "drag":
        case "dragenter":
        case "dragexit":
        case "dragleave":
        case "dragover":
        case "mousemove":
        case "mouseout":
        case "mouseover":
        case "pointermove":
        case "pointerout":
        case "pointerover":
        case "scroll":
        case "toggle":
        case "touchmove":
        case "wheel":
        case "mouseenter":
        case "mouseleave":
        case "pointerenter":
        case "pointerleave":
          return 4;
        case "message":
          switch (ec()) {
            case fc:
              return 1;
            case gc:
              return 4;
            case hc:
            case ic:
              return 16;
            case jc:
              return 536870912;
            default:
              return 16;
          }
        default:
          return 16;
      }
    }
    var kd = null;
    var ld = null;
    var md = null;
    function nd() {
      if (md) return md;
      var a, b = ld, c = b.length, d, e = "value" in kd ? kd.value : kd.textContent, f = e.length;
      for (a = 0; a < c && b[a] === e[a]; a++) ;
      var g = c - a;
      for (d = 1; d <= g && b[c - d] === e[f - d]; d++) ;
      return md = e.slice(a, 1 < d ? 1 - d : void 0);
    }
    function od(a) {
      var b = a.keyCode;
      "charCode" in a ? (a = a.charCode, 0 === a && 13 === b && (a = 13)) : a = b;
      10 === a && (a = 13);
      return 32 <= a || 13 === a ? a : 0;
    }
    function pd() {
      return true;
    }
    function qd() {
      return false;
    }
    function rd(a) {
      function b(b2, d, e, f, g) {
        this._reactName = b2;
        this._targetInst = e;
        this.type = d;
        this.nativeEvent = f;
        this.target = g;
        this.currentTarget = null;
        for (var c in a) a.hasOwnProperty(c) && (b2 = a[c], this[c] = b2 ? b2(f) : f[c]);
        this.isDefaultPrevented = (null != f.defaultPrevented ? f.defaultPrevented : false === f.returnValue) ? pd : qd;
        this.isPropagationStopped = qd;
        return this;
      }
      A(b.prototype, { preventDefault: function() {
        this.defaultPrevented = true;
        var a2 = this.nativeEvent;
        a2 && (a2.preventDefault ? a2.preventDefault() : "unknown" !== typeof a2.returnValue && (a2.returnValue = false), this.isDefaultPrevented = pd);
      }, stopPropagation: function() {
        var a2 = this.nativeEvent;
        a2 && (a2.stopPropagation ? a2.stopPropagation() : "unknown" !== typeof a2.cancelBubble && (a2.cancelBubble = true), this.isPropagationStopped = pd);
      }, persist: function() {
      }, isPersistent: pd });
      return b;
    }
    var sd = { eventPhase: 0, bubbles: 0, cancelable: 0, timeStamp: function(a) {
      return a.timeStamp || Date.now();
    }, defaultPrevented: 0, isTrusted: 0 };
    var td = rd(sd);
    var ud = A({}, sd, { view: 0, detail: 0 });
    var vd = rd(ud);
    var wd;
    var xd;
    var yd;
    var Ad = A({}, ud, { screenX: 0, screenY: 0, clientX: 0, clientY: 0, pageX: 0, pageY: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, getModifierState: zd, button: 0, buttons: 0, relatedTarget: function(a) {
      return void 0 === a.relatedTarget ? a.fromElement === a.srcElement ? a.toElement : a.fromElement : a.relatedTarget;
    }, movementX: function(a) {
      if ("movementX" in a) return a.movementX;
      a !== yd && (yd && "mousemove" === a.type ? (wd = a.screenX - yd.screenX, xd = a.screenY - yd.screenY) : xd = wd = 0, yd = a);
      return wd;
    }, movementY: function(a) {
      return "movementY" in a ? a.movementY : xd;
    } });
    var Bd = rd(Ad);
    var Cd = A({}, Ad, { dataTransfer: 0 });
    var Dd = rd(Cd);
    var Ed = A({}, ud, { relatedTarget: 0 });
    var Fd = rd(Ed);
    var Gd = A({}, sd, { animationName: 0, elapsedTime: 0, pseudoElement: 0 });
    var Hd = rd(Gd);
    var Id = A({}, sd, { clipboardData: function(a) {
      return "clipboardData" in a ? a.clipboardData : window.clipboardData;
    } });
    var Jd = rd(Id);
    var Kd = A({}, sd, { data: 0 });
    var Ld = rd(Kd);
    var Md = {
      Esc: "Escape",
      Spacebar: " ",
      Left: "ArrowLeft",
      Up: "ArrowUp",
      Right: "ArrowRight",
      Down: "ArrowDown",
      Del: "Delete",
      Win: "OS",
      Menu: "ContextMenu",
      Apps: "ContextMenu",
      Scroll: "ScrollLock",
      MozPrintableKey: "Unidentified"
    };
    var Nd = {
      8: "Backspace",
      9: "Tab",
      12: "Clear",
      13: "Enter",
      16: "Shift",
      17: "Control",
      18: "Alt",
      19: "Pause",
      20: "CapsLock",
      27: "Escape",
      32: " ",
      33: "PageUp",
      34: "PageDown",
      35: "End",
      36: "Home",
      37: "ArrowLeft",
      38: "ArrowUp",
      39: "ArrowRight",
      40: "ArrowDown",
      45: "Insert",
      46: "Delete",
      112: "F1",
      113: "F2",
      114: "F3",
      115: "F4",
      116: "F5",
      117: "F6",
      118: "F7",
      119: "F8",
      120: "F9",
      121: "F10",
      122: "F11",
      123: "F12",
      144: "NumLock",
      145: "ScrollLock",
      224: "Meta"
    };
    var Od = { Alt: "altKey", Control: "ctrlKey", Meta: "metaKey", Shift: "shiftKey" };
    function Pd(a) {
      var b = this.nativeEvent;
      return b.getModifierState ? b.getModifierState(a) : (a = Od[a]) ? !!b[a] : false;
    }
    function zd() {
      return Pd;
    }
    var Qd = A({}, ud, { key: function(a) {
      if (a.key) {
        var b = Md[a.key] || a.key;
        if ("Unidentified" !== b) return b;
      }
      return "keypress" === a.type ? (a = od(a), 13 === a ? "Enter" : String.fromCharCode(a)) : "keydown" === a.type || "keyup" === a.type ? Nd[a.keyCode] || "Unidentified" : "";
    }, code: 0, location: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, repeat: 0, locale: 0, getModifierState: zd, charCode: function(a) {
      return "keypress" === a.type ? od(a) : 0;
    }, keyCode: function(a) {
      return "keydown" === a.type || "keyup" === a.type ? a.keyCode : 0;
    }, which: function(a) {
      return "keypress" === a.type ? od(a) : "keydown" === a.type || "keyup" === a.type ? a.keyCode : 0;
    } });
    var Rd = rd(Qd);
    var Sd = A({}, Ad, { pointerId: 0, width: 0, height: 0, pressure: 0, tangentialPressure: 0, tiltX: 0, tiltY: 0, twist: 0, pointerType: 0, isPrimary: 0 });
    var Td = rd(Sd);
    var Ud = A({}, ud, { touches: 0, targetTouches: 0, changedTouches: 0, altKey: 0, metaKey: 0, ctrlKey: 0, shiftKey: 0, getModifierState: zd });
    var Vd = rd(Ud);
    var Wd = A({}, sd, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 });
    var Xd = rd(Wd);
    var Yd = A({}, Ad, {
      deltaX: function(a) {
        return "deltaX" in a ? a.deltaX : "wheelDeltaX" in a ? -a.wheelDeltaX : 0;
      },
      deltaY: function(a) {
        return "deltaY" in a ? a.deltaY : "wheelDeltaY" in a ? -a.wheelDeltaY : "wheelDelta" in a ? -a.wheelDelta : 0;
      },
      deltaZ: 0,
      deltaMode: 0
    });
    var Zd = rd(Yd);
    var $d = [9, 13, 27, 32];
    var ae = ia && "CompositionEvent" in window;
    var be = null;
    ia && "documentMode" in document && (be = document.documentMode);
    var ce = ia && "TextEvent" in window && !be;
    var de = ia && (!ae || be && 8 < be && 11 >= be);
    var ee = String.fromCharCode(32);
    var fe = false;
    function ge(a, b) {
      switch (a) {
        case "keyup":
          return -1 !== $d.indexOf(b.keyCode);
        case "keydown":
          return 229 !== b.keyCode;
        case "keypress":
        case "mousedown":
        case "focusout":
          return true;
        default:
          return false;
      }
    }
    function he(a) {
      a = a.detail;
      return "object" === typeof a && "data" in a ? a.data : null;
    }
    var ie = false;
    function je(a, b) {
      switch (a) {
        case "compositionend":
          return he(b);
        case "keypress":
          if (32 !== b.which) return null;
          fe = true;
          return ee;
        case "textInput":
          return a = b.data, a === ee && fe ? null : a;
        default:
          return null;
      }
    }
    function ke(a, b) {
      if (ie) return "compositionend" === a || !ae && ge(a, b) ? (a = nd(), md = ld = kd = null, ie = false, a) : null;
      switch (a) {
        case "paste":
          return null;
        case "keypress":
          if (!(b.ctrlKey || b.altKey || b.metaKey) || b.ctrlKey && b.altKey) {
            if (b.char && 1 < b.char.length) return b.char;
            if (b.which) return String.fromCharCode(b.which);
          }
          return null;
        case "compositionend":
          return de && "ko" !== b.locale ? null : b.data;
        default:
          return null;
      }
    }
    var le = { color: true, date: true, datetime: true, "datetime-local": true, email: true, month: true, number: true, password: true, range: true, search: true, tel: true, text: true, time: true, url: true, week: true };
    function me(a) {
      var b = a && a.nodeName && a.nodeName.toLowerCase();
      return "input" === b ? !!le[a.type] : "textarea" === b ? true : false;
    }
    function ne(a, b, c, d) {
      Eb(d);
      b = oe(b, "onChange");
      0 < b.length && (c = new td("onChange", "change", null, c, d), a.push({ event: c, listeners: b }));
    }
    var pe = null;
    var qe = null;
    function re(a) {
      se(a, 0);
    }
    function te(a) {
      var b = ue(a);
      if (Wa(b)) return a;
    }
    function ve(a, b) {
      if ("change" === a) return b;
    }
    var we = false;
    if (ia) {
      if (ia) {
        ye = "oninput" in document;
        if (!ye) {
          ze = document.createElement("div");
          ze.setAttribute("oninput", "return;");
          ye = "function" === typeof ze.oninput;
        }
        xe = ye;
      } else xe = false;
      we = xe && (!document.documentMode || 9 < document.documentMode);
    }
    var xe;
    var ye;
    var ze;
    function Ae() {
      pe && (pe.detachEvent("onpropertychange", Be), qe = pe = null);
    }
    function Be(a) {
      if ("value" === a.propertyName && te(qe)) {
        var b = [];
        ne(b, qe, a, xb(a));
        Jb(re, b);
      }
    }
    function Ce(a, b, c) {
      "focusin" === a ? (Ae(), pe = b, qe = c, pe.attachEvent("onpropertychange", Be)) : "focusout" === a && Ae();
    }
    function De(a) {
      if ("selectionchange" === a || "keyup" === a || "keydown" === a) return te(qe);
    }
    function Ee(a, b) {
      if ("click" === a) return te(b);
    }
    function Fe(a, b) {
      if ("input" === a || "change" === a) return te(b);
    }
    function Ge(a, b) {
      return a === b && (0 !== a || 1 / a === 1 / b) || a !== a && b !== b;
    }
    var He = "function" === typeof Object.is ? Object.is : Ge;
    function Ie(a, b) {
      if (He(a, b)) return true;
      if ("object" !== typeof a || null === a || "object" !== typeof b || null === b) return false;
      var c = Object.keys(a), d = Object.keys(b);
      if (c.length !== d.length) return false;
      for (d = 0; d < c.length; d++) {
        var e = c[d];
        if (!ja.call(b, e) || !He(a[e], b[e])) return false;
      }
      return true;
    }
    function Je(a) {
      for (; a && a.firstChild; ) a = a.firstChild;
      return a;
    }
    function Ke(a, b) {
      var c = Je(a);
      a = 0;
      for (var d; c; ) {
        if (3 === c.nodeType) {
          d = a + c.textContent.length;
          if (a <= b && d >= b) return { node: c, offset: b - a };
          a = d;
        }
        a: {
          for (; c; ) {
            if (c.nextSibling) {
              c = c.nextSibling;
              break a;
            }
            c = c.parentNode;
          }
          c = void 0;
        }
        c = Je(c);
      }
    }
    function Le(a, b) {
      return a && b ? a === b ? true : a && 3 === a.nodeType ? false : b && 3 === b.nodeType ? Le(a, b.parentNode) : "contains" in a ? a.contains(b) : a.compareDocumentPosition ? !!(a.compareDocumentPosition(b) & 16) : false : false;
    }
    function Me() {
      for (var a = window, b = Xa(); b instanceof a.HTMLIFrameElement; ) {
        try {
          var c = "string" === typeof b.contentWindow.location.href;
        } catch (d) {
          c = false;
        }
        if (c) a = b.contentWindow;
        else break;
        b = Xa(a.document);
      }
      return b;
    }
    function Ne(a) {
      var b = a && a.nodeName && a.nodeName.toLowerCase();
      return b && ("input" === b && ("text" === a.type || "search" === a.type || "tel" === a.type || "url" === a.type || "password" === a.type) || "textarea" === b || "true" === a.contentEditable);
    }
    function Oe(a) {
      var b = Me(), c = a.focusedElem, d = a.selectionRange;
      if (b !== c && c && c.ownerDocument && Le(c.ownerDocument.documentElement, c)) {
        if (null !== d && Ne(c)) {
          if (b = d.start, a = d.end, void 0 === a && (a = b), "selectionStart" in c) c.selectionStart = b, c.selectionEnd = Math.min(a, c.value.length);
          else if (a = (b = c.ownerDocument || document) && b.defaultView || window, a.getSelection) {
            a = a.getSelection();
            var e = c.textContent.length, f = Math.min(d.start, e);
            d = void 0 === d.end ? f : Math.min(d.end, e);
            !a.extend && f > d && (e = d, d = f, f = e);
            e = Ke(c, f);
            var g = Ke(
              c,
              d
            );
            e && g && (1 !== a.rangeCount || a.anchorNode !== e.node || a.anchorOffset !== e.offset || a.focusNode !== g.node || a.focusOffset !== g.offset) && (b = b.createRange(), b.setStart(e.node, e.offset), a.removeAllRanges(), f > d ? (a.addRange(b), a.extend(g.node, g.offset)) : (b.setEnd(g.node, g.offset), a.addRange(b)));
          }
        }
        b = [];
        for (a = c; a = a.parentNode; ) 1 === a.nodeType && b.push({ element: a, left: a.scrollLeft, top: a.scrollTop });
        "function" === typeof c.focus && c.focus();
        for (c = 0; c < b.length; c++) a = b[c], a.element.scrollLeft = a.left, a.element.scrollTop = a.top;
      }
    }
    var Pe = ia && "documentMode" in document && 11 >= document.documentMode;
    var Qe = null;
    var Re = null;
    var Se = null;
    var Te = false;
    function Ue(a, b, c) {
      var d = c.window === c ? c.document : 9 === c.nodeType ? c : c.ownerDocument;
      Te || null == Qe || Qe !== Xa(d) || (d = Qe, "selectionStart" in d && Ne(d) ? d = { start: d.selectionStart, end: d.selectionEnd } : (d = (d.ownerDocument && d.ownerDocument.defaultView || window).getSelection(), d = { anchorNode: d.anchorNode, anchorOffset: d.anchorOffset, focusNode: d.focusNode, focusOffset: d.focusOffset }), Se && Ie(Se, d) || (Se = d, d = oe(Re, "onSelect"), 0 < d.length && (b = new td("onSelect", "select", null, b, c), a.push({ event: b, listeners: d }), b.target = Qe)));
    }
    function Ve(a, b) {
      var c = {};
      c[a.toLowerCase()] = b.toLowerCase();
      c["Webkit" + a] = "webkit" + b;
      c["Moz" + a] = "moz" + b;
      return c;
    }
    var We = { animationend: Ve("Animation", "AnimationEnd"), animationiteration: Ve("Animation", "AnimationIteration"), animationstart: Ve("Animation", "AnimationStart"), transitionend: Ve("Transition", "TransitionEnd") };
    var Xe = {};
    var Ye = {};
    ia && (Ye = document.createElement("div").style, "AnimationEvent" in window || (delete We.animationend.animation, delete We.animationiteration.animation, delete We.animationstart.animation), "TransitionEvent" in window || delete We.transitionend.transition);
    function Ze(a) {
      if (Xe[a]) return Xe[a];
      if (!We[a]) return a;
      var b = We[a], c;
      for (c in b) if (b.hasOwnProperty(c) && c in Ye) return Xe[a] = b[c];
      return a;
    }
    var $e = Ze("animationend");
    var af = Ze("animationiteration");
    var bf = Ze("animationstart");
    var cf = Ze("transitionend");
    var df = /* @__PURE__ */ new Map();
    var ef = "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");
    function ff(a, b) {
      df.set(a, b);
      fa(b, [a]);
    }
    for (gf = 0; gf < ef.length; gf++) {
      hf = ef[gf], jf = hf.toLowerCase(), kf = hf[0].toUpperCase() + hf.slice(1);
      ff(jf, "on" + kf);
    }
    var hf;
    var jf;
    var kf;
    var gf;
    ff($e, "onAnimationEnd");
    ff(af, "onAnimationIteration");
    ff(bf, "onAnimationStart");
    ff("dblclick", "onDoubleClick");
    ff("focusin", "onFocus");
    ff("focusout", "onBlur");
    ff(cf, "onTransitionEnd");
    ha("onMouseEnter", ["mouseout", "mouseover"]);
    ha("onMouseLeave", ["mouseout", "mouseover"]);
    ha("onPointerEnter", ["pointerout", "pointerover"]);
    ha("onPointerLeave", ["pointerout", "pointerover"]);
    fa("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" "));
    fa("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));
    fa("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]);
    fa("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" "));
    fa("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" "));
    fa("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
    var lf = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" ");
    var mf = new Set("cancel close invalid load scroll toggle".split(" ").concat(lf));
    function nf(a, b, c) {
      var d = a.type || "unknown-event";
      a.currentTarget = c;
      Ub(d, b, void 0, a);
      a.currentTarget = null;
    }
    function se(a, b) {
      b = 0 !== (b & 4);
      for (var c = 0; c < a.length; c++) {
        var d = a[c], e = d.event;
        d = d.listeners;
        a: {
          var f = void 0;
          if (b) for (var g = d.length - 1; 0 <= g; g--) {
            var h = d[g], k = h.instance, l = h.currentTarget;
            h = h.listener;
            if (k !== f && e.isPropagationStopped()) break a;
            nf(e, h, l);
            f = k;
          }
          else for (g = 0; g < d.length; g++) {
            h = d[g];
            k = h.instance;
            l = h.currentTarget;
            h = h.listener;
            if (k !== f && e.isPropagationStopped()) break a;
            nf(e, h, l);
            f = k;
          }
        }
      }
      if (Qb) throw a = Rb, Qb = false, Rb = null, a;
    }
    function D(a, b) {
      var c = b[of];
      void 0 === c && (c = b[of] = /* @__PURE__ */ new Set());
      var d = a + "__bubble";
      c.has(d) || (pf(b, a, 2, false), c.add(d));
    }
    function qf(a, b, c) {
      var d = 0;
      b && (d |= 4);
      pf(c, a, d, b);
    }
    var rf = "_reactListening" + Math.random().toString(36).slice(2);
    function sf(a) {
      if (!a[rf]) {
        a[rf] = true;
        da.forEach(function(b2) {
          "selectionchange" !== b2 && (mf.has(b2) || qf(b2, false, a), qf(b2, true, a));
        });
        var b = 9 === a.nodeType ? a : a.ownerDocument;
        null === b || b[rf] || (b[rf] = true, qf("selectionchange", false, b));
      }
    }
    function pf(a, b, c, d) {
      switch (jd(b)) {
        case 1:
          var e = ed;
          break;
        case 4:
          e = gd;
          break;
        default:
          e = fd;
      }
      c = e.bind(null, b, c, a);
      e = void 0;
      !Lb || "touchstart" !== b && "touchmove" !== b && "wheel" !== b || (e = true);
      d ? void 0 !== e ? a.addEventListener(b, c, { capture: true, passive: e }) : a.addEventListener(b, c, true) : void 0 !== e ? a.addEventListener(b, c, { passive: e }) : a.addEventListener(b, c, false);
    }
    function hd(a, b, c, d, e) {
      var f = d;
      if (0 === (b & 1) && 0 === (b & 2) && null !== d) a: for (; ; ) {
        if (null === d) return;
        var g = d.tag;
        if (3 === g || 4 === g) {
          var h = d.stateNode.containerInfo;
          if (h === e || 8 === h.nodeType && h.parentNode === e) break;
          if (4 === g) for (g = d.return; null !== g; ) {
            var k = g.tag;
            if (3 === k || 4 === k) {
              if (k = g.stateNode.containerInfo, k === e || 8 === k.nodeType && k.parentNode === e) return;
            }
            g = g.return;
          }
          for (; null !== h; ) {
            g = Wc(h);
            if (null === g) return;
            k = g.tag;
            if (5 === k || 6 === k) {
              d = f = g;
              continue a;
            }
            h = h.parentNode;
          }
        }
        d = d.return;
      }
      Jb(function() {
        var d2 = f, e2 = xb(c), g2 = [];
        a: {
          var h2 = df.get(a);
          if (void 0 !== h2) {
            var k2 = td, n = a;
            switch (a) {
              case "keypress":
                if (0 === od(c)) break a;
              case "keydown":
              case "keyup":
                k2 = Rd;
                break;
              case "focusin":
                n = "focus";
                k2 = Fd;
                break;
              case "focusout":
                n = "blur";
                k2 = Fd;
                break;
              case "beforeblur":
              case "afterblur":
                k2 = Fd;
                break;
              case "click":
                if (2 === c.button) break a;
              case "auxclick":
              case "dblclick":
              case "mousedown":
              case "mousemove":
              case "mouseup":
              case "mouseout":
              case "mouseover":
              case "contextmenu":
                k2 = Bd;
                break;
              case "drag":
              case "dragend":
              case "dragenter":
              case "dragexit":
              case "dragleave":
              case "dragover":
              case "dragstart":
              case "drop":
                k2 = Dd;
                break;
              case "touchcancel":
              case "touchend":
              case "touchmove":
              case "touchstart":
                k2 = Vd;
                break;
              case $e:
              case af:
              case bf:
                k2 = Hd;
                break;
              case cf:
                k2 = Xd;
                break;
              case "scroll":
                k2 = vd;
                break;
              case "wheel":
                k2 = Zd;
                break;
              case "copy":
              case "cut":
              case "paste":
                k2 = Jd;
                break;
              case "gotpointercapture":
              case "lostpointercapture":
              case "pointercancel":
              case "pointerdown":
              case "pointermove":
              case "pointerout":
              case "pointerover":
              case "pointerup":
                k2 = Td;
            }
            var t = 0 !== (b & 4), J = !t && "scroll" === a, x = t ? null !== h2 ? h2 + "Capture" : null : h2;
            t = [];
            for (var w = d2, u; null !== w; ) {
              u = w;
              var F = u.stateNode;
              5 === u.tag && null !== F && (u = F, null !== x && (F = Kb(w, x), null != F && t.push(tf(w, F, u))));
              if (J) break;
              w = w.return;
            }
            0 < t.length && (h2 = new k2(h2, n, null, c, e2), g2.push({ event: h2, listeners: t }));
          }
        }
        if (0 === (b & 7)) {
          a: {
            h2 = "mouseover" === a || "pointerover" === a;
            k2 = "mouseout" === a || "pointerout" === a;
            if (h2 && c !== wb && (n = c.relatedTarget || c.fromElement) && (Wc(n) || n[uf])) break a;
            if (k2 || h2) {
              h2 = e2.window === e2 ? e2 : (h2 = e2.ownerDocument) ? h2.defaultView || h2.parentWindow : window;
              if (k2) {
                if (n = c.relatedTarget || c.toElement, k2 = d2, n = n ? Wc(n) : null, null !== n && (J = Vb(n), n !== J || 5 !== n.tag && 6 !== n.tag)) n = null;
              } else k2 = null, n = d2;
              if (k2 !== n) {
                t = Bd;
                F = "onMouseLeave";
                x = "onMouseEnter";
                w = "mouse";
                if ("pointerout" === a || "pointerover" === a) t = Td, F = "onPointerLeave", x = "onPointerEnter", w = "pointer";
                J = null == k2 ? h2 : ue(k2);
                u = null == n ? h2 : ue(n);
                h2 = new t(F, w + "leave", k2, c, e2);
                h2.target = J;
                h2.relatedTarget = u;
                F = null;
                Wc(e2) === d2 && (t = new t(x, w + "enter", n, c, e2), t.target = u, t.relatedTarget = J, F = t);
                J = F;
                if (k2 && n) b: {
                  t = k2;
                  x = n;
                  w = 0;
                  for (u = t; u; u = vf(u)) w++;
                  u = 0;
                  for (F = x; F; F = vf(F)) u++;
                  for (; 0 < w - u; ) t = vf(t), w--;
                  for (; 0 < u - w; ) x = vf(x), u--;
                  for (; w--; ) {
                    if (t === x || null !== x && t === x.alternate) break b;
                    t = vf(t);
                    x = vf(x);
                  }
                  t = null;
                }
                else t = null;
                null !== k2 && wf(g2, h2, k2, t, false);
                null !== n && null !== J && wf(g2, J, n, t, true);
              }
            }
          }
          a: {
            h2 = d2 ? ue(d2) : window;
            k2 = h2.nodeName && h2.nodeName.toLowerCase();
            if ("select" === k2 || "input" === k2 && "file" === h2.type) var na = ve;
            else if (me(h2)) if (we) na = Fe;
            else {
              na = De;
              var xa = Ce;
            }
            else (k2 = h2.nodeName) && "input" === k2.toLowerCase() && ("checkbox" === h2.type || "radio" === h2.type) && (na = Ee);
            if (na && (na = na(a, d2))) {
              ne(g2, na, c, e2);
              break a;
            }
            xa && xa(a, h2, d2);
            "focusout" === a && (xa = h2._wrapperState) && xa.controlled && "number" === h2.type && cb(h2, "number", h2.value);
          }
          xa = d2 ? ue(d2) : window;
          switch (a) {
            case "focusin":
              if (me(xa) || "true" === xa.contentEditable) Qe = xa, Re = d2, Se = null;
              break;
            case "focusout":
              Se = Re = Qe = null;
              break;
            case "mousedown":
              Te = true;
              break;
            case "contextmenu":
            case "mouseup":
            case "dragend":
              Te = false;
              Ue(g2, c, e2);
              break;
            case "selectionchange":
              if (Pe) break;
            case "keydown":
            case "keyup":
              Ue(g2, c, e2);
          }
          var $a;
          if (ae) b: {
            switch (a) {
              case "compositionstart":
                var ba = "onCompositionStart";
                break b;
              case "compositionend":
                ba = "onCompositionEnd";
                break b;
              case "compositionupdate":
                ba = "onCompositionUpdate";
                break b;
            }
            ba = void 0;
          }
          else ie ? ge(a, c) && (ba = "onCompositionEnd") : "keydown" === a && 229 === c.keyCode && (ba = "onCompositionStart");
          ba && (de && "ko" !== c.locale && (ie || "onCompositionStart" !== ba ? "onCompositionEnd" === ba && ie && ($a = nd()) : (kd = e2, ld = "value" in kd ? kd.value : kd.textContent, ie = true)), xa = oe(d2, ba), 0 < xa.length && (ba = new Ld(ba, a, null, c, e2), g2.push({ event: ba, listeners: xa }), $a ? ba.data = $a : ($a = he(c), null !== $a && (ba.data = $a))));
          if ($a = ce ? je(a, c) : ke(a, c)) d2 = oe(d2, "onBeforeInput"), 0 < d2.length && (e2 = new Ld("onBeforeInput", "beforeinput", null, c, e2), g2.push({ event: e2, listeners: d2 }), e2.data = $a);
        }
        se(g2, b);
      });
    }
    function tf(a, b, c) {
      return { instance: a, listener: b, currentTarget: c };
    }
    function oe(a, b) {
      for (var c = b + "Capture", d = []; null !== a; ) {
        var e = a, f = e.stateNode;
        5 === e.tag && null !== f && (e = f, f = Kb(a, c), null != f && d.unshift(tf(a, f, e)), f = Kb(a, b), null != f && d.push(tf(a, f, e)));
        a = a.return;
      }
      return d;
    }
    function vf(a) {
      if (null === a) return null;
      do
        a = a.return;
      while (a && 5 !== a.tag);
      return a ? a : null;
    }
    function wf(a, b, c, d, e) {
      for (var f = b._reactName, g = []; null !== c && c !== d; ) {
        var h = c, k = h.alternate, l = h.stateNode;
        if (null !== k && k === d) break;
        5 === h.tag && null !== l && (h = l, e ? (k = Kb(c, f), null != k && g.unshift(tf(c, k, h))) : e || (k = Kb(c, f), null != k && g.push(tf(c, k, h))));
        c = c.return;
      }
      0 !== g.length && a.push({ event: b, listeners: g });
    }
    var xf = /\r\n?/g;
    var yf = /\u0000|\uFFFD/g;
    function zf(a) {
      return ("string" === typeof a ? a : "" + a).replace(xf, "\n").replace(yf, "");
    }
    function Af(a, b, c) {
      b = zf(b);
      if (zf(a) !== b && c) throw Error(p(425));
    }
    function Bf() {
    }
    var Cf = null;
    var Df = null;
    function Ef(a, b) {
      return "textarea" === a || "noscript" === a || "string" === typeof b.children || "number" === typeof b.children || "object" === typeof b.dangerouslySetInnerHTML && null !== b.dangerouslySetInnerHTML && null != b.dangerouslySetInnerHTML.__html;
    }
    var Ff = "function" === typeof setTimeout ? setTimeout : void 0;
    var Gf = "function" === typeof clearTimeout ? clearTimeout : void 0;
    var Hf = "function" === typeof Promise ? Promise : void 0;
    var Jf = "function" === typeof queueMicrotask ? queueMicrotask : "undefined" !== typeof Hf ? function(a) {
      return Hf.resolve(null).then(a).catch(If);
    } : Ff;
    function If(a) {
      setTimeout(function() {
        throw a;
      });
    }
    function Kf(a, b) {
      var c = b, d = 0;
      do {
        var e = c.nextSibling;
        a.removeChild(c);
        if (e && 8 === e.nodeType) if (c = e.data, "/$" === c) {
          if (0 === d) {
            a.removeChild(e);
            bd(b);
            return;
          }
          d--;
        } else "$" !== c && "$?" !== c && "$!" !== c || d++;
        c = e;
      } while (c);
      bd(b);
    }
    function Lf(a) {
      for (; null != a; a = a.nextSibling) {
        var b = a.nodeType;
        if (1 === b || 3 === b) break;
        if (8 === b) {
          b = a.data;
          if ("$" === b || "$!" === b || "$?" === b) break;
          if ("/$" === b) return null;
        }
      }
      return a;
    }
    function Mf(a) {
      a = a.previousSibling;
      for (var b = 0; a; ) {
        if (8 === a.nodeType) {
          var c = a.data;
          if ("$" === c || "$!" === c || "$?" === c) {
            if (0 === b) return a;
            b--;
          } else "/$" === c && b++;
        }
        a = a.previousSibling;
      }
      return null;
    }
    var Nf = Math.random().toString(36).slice(2);
    var Of = "__reactFiber$" + Nf;
    var Pf = "__reactProps$" + Nf;
    var uf = "__reactContainer$" + Nf;
    var of = "__reactEvents$" + Nf;
    var Qf = "__reactListeners$" + Nf;
    var Rf = "__reactHandles$" + Nf;
    function Wc(a) {
      var b = a[Of];
      if (b) return b;
      for (var c = a.parentNode; c; ) {
        if (b = c[uf] || c[Of]) {
          c = b.alternate;
          if (null !== b.child || null !== c && null !== c.child) for (a = Mf(a); null !== a; ) {
            if (c = a[Of]) return c;
            a = Mf(a);
          }
          return b;
        }
        a = c;
        c = a.parentNode;
      }
      return null;
    }
    function Cb(a) {
      a = a[Of] || a[uf];
      return !a || 5 !== a.tag && 6 !== a.tag && 13 !== a.tag && 3 !== a.tag ? null : a;
    }
    function ue(a) {
      if (5 === a.tag || 6 === a.tag) return a.stateNode;
      throw Error(p(33));
    }
    function Db(a) {
      return a[Pf] || null;
    }
    var Sf = [];
    var Tf = -1;
    function Uf(a) {
      return { current: a };
    }
    function E(a) {
      0 > Tf || (a.current = Sf[Tf], Sf[Tf] = null, Tf--);
    }
    function G(a, b) {
      Tf++;
      Sf[Tf] = a.current;
      a.current = b;
    }
    var Vf = {};
    var H = Uf(Vf);
    var Wf = Uf(false);
    var Xf = Vf;
    function Yf(a, b) {
      var c = a.type.contextTypes;
      if (!c) return Vf;
      var d = a.stateNode;
      if (d && d.__reactInternalMemoizedUnmaskedChildContext === b) return d.__reactInternalMemoizedMaskedChildContext;
      var e = {}, f;
      for (f in c) e[f] = b[f];
      d && (a = a.stateNode, a.__reactInternalMemoizedUnmaskedChildContext = b, a.__reactInternalMemoizedMaskedChildContext = e);
      return e;
    }
    function Zf(a) {
      a = a.childContextTypes;
      return null !== a && void 0 !== a;
    }
    function $f() {
      E(Wf);
      E(H);
    }
    function ag(a, b, c) {
      if (H.current !== Vf) throw Error(p(168));
      G(H, b);
      G(Wf, c);
    }
    function bg(a, b, c) {
      var d = a.stateNode;
      b = b.childContextTypes;
      if ("function" !== typeof d.getChildContext) return c;
      d = d.getChildContext();
      for (var e in d) if (!(e in b)) throw Error(p(108, Ra(a) || "Unknown", e));
      return A({}, c, d);
    }
    function cg(a) {
      a = (a = a.stateNode) && a.__reactInternalMemoizedMergedChildContext || Vf;
      Xf = H.current;
      G(H, a);
      G(Wf, Wf.current);
      return true;
    }
    function dg(a, b, c) {
      var d = a.stateNode;
      if (!d) throw Error(p(169));
      c ? (a = bg(a, b, Xf), d.__reactInternalMemoizedMergedChildContext = a, E(Wf), E(H), G(H, a)) : E(Wf);
      G(Wf, c);
    }
    var eg = null;
    var fg = false;
    var gg = false;
    function hg(a) {
      null === eg ? eg = [a] : eg.push(a);
    }
    function ig(a) {
      fg = true;
      hg(a);
    }
    function jg() {
      if (!gg && null !== eg) {
        gg = true;
        var a = 0, b = C2;
        try {
          var c = eg;
          for (C2 = 1; a < c.length; a++) {
            var d = c[a];
            do
              d = d(true);
            while (null !== d);
          }
          eg = null;
          fg = false;
        } catch (e) {
          throw null !== eg && (eg = eg.slice(a + 1)), ac(fc, jg), e;
        } finally {
          C2 = b, gg = false;
        }
      }
      return null;
    }
    var kg = [];
    var lg = 0;
    var mg = null;
    var ng = 0;
    var og = [];
    var pg = 0;
    var qg = null;
    var rg = 1;
    var sg = "";
    function tg(a, b) {
      kg[lg++] = ng;
      kg[lg++] = mg;
      mg = a;
      ng = b;
    }
    function ug(a, b, c) {
      og[pg++] = rg;
      og[pg++] = sg;
      og[pg++] = qg;
      qg = a;
      var d = rg;
      a = sg;
      var e = 32 - oc(d) - 1;
      d &= ~(1 << e);
      c += 1;
      var f = 32 - oc(b) + e;
      if (30 < f) {
        var g = e - e % 5;
        f = (d & (1 << g) - 1).toString(32);
        d >>= g;
        e -= g;
        rg = 1 << 32 - oc(b) + e | c << e | d;
        sg = f + a;
      } else rg = 1 << f | c << e | d, sg = a;
    }
    function vg(a) {
      null !== a.return && (tg(a, 1), ug(a, 1, 0));
    }
    function wg(a) {
      for (; a === mg; ) mg = kg[--lg], kg[lg] = null, ng = kg[--lg], kg[lg] = null;
      for (; a === qg; ) qg = og[--pg], og[pg] = null, sg = og[--pg], og[pg] = null, rg = og[--pg], og[pg] = null;
    }
    var xg = null;
    var yg = null;
    var I = false;
    var zg = null;
    function Ag(a, b) {
      var c = Bg(5, null, null, 0);
      c.elementType = "DELETED";
      c.stateNode = b;
      c.return = a;
      b = a.deletions;
      null === b ? (a.deletions = [c], a.flags |= 16) : b.push(c);
    }
    function Cg(a, b) {
      switch (a.tag) {
        case 5:
          var c = a.type;
          b = 1 !== b.nodeType || c.toLowerCase() !== b.nodeName.toLowerCase() ? null : b;
          return null !== b ? (a.stateNode = b, xg = a, yg = Lf(b.firstChild), true) : false;
        case 6:
          return b = "" === a.pendingProps || 3 !== b.nodeType ? null : b, null !== b ? (a.stateNode = b, xg = a, yg = null, true) : false;
        case 13:
          return b = 8 !== b.nodeType ? null : b, null !== b ? (c = null !== qg ? { id: rg, overflow: sg } : null, a.memoizedState = { dehydrated: b, treeContext: c, retryLane: 1073741824 }, c = Bg(18, null, null, 0), c.stateNode = b, c.return = a, a.child = c, xg = a, yg = null, true) : false;
        default:
          return false;
      }
    }
    function Dg(a) {
      return 0 !== (a.mode & 1) && 0 === (a.flags & 128);
    }
    function Eg(a) {
      if (I) {
        var b = yg;
        if (b) {
          var c = b;
          if (!Cg(a, b)) {
            if (Dg(a)) throw Error(p(418));
            b = Lf(c.nextSibling);
            var d = xg;
            b && Cg(a, b) ? Ag(d, c) : (a.flags = a.flags & -4097 | 2, I = false, xg = a);
          }
        } else {
          if (Dg(a)) throw Error(p(418));
          a.flags = a.flags & -4097 | 2;
          I = false;
          xg = a;
        }
      }
    }
    function Fg(a) {
      for (a = a.return; null !== a && 5 !== a.tag && 3 !== a.tag && 13 !== a.tag; ) a = a.return;
      xg = a;
    }
    function Gg(a) {
      if (a !== xg) return false;
      if (!I) return Fg(a), I = true, false;
      var b;
      (b = 3 !== a.tag) && !(b = 5 !== a.tag) && (b = a.type, b = "head" !== b && "body" !== b && !Ef(a.type, a.memoizedProps));
      if (b && (b = yg)) {
        if (Dg(a)) throw Hg(), Error(p(418));
        for (; b; ) Ag(a, b), b = Lf(b.nextSibling);
      }
      Fg(a);
      if (13 === a.tag) {
        a = a.memoizedState;
        a = null !== a ? a.dehydrated : null;
        if (!a) throw Error(p(317));
        a: {
          a = a.nextSibling;
          for (b = 0; a; ) {
            if (8 === a.nodeType) {
              var c = a.data;
              if ("/$" === c) {
                if (0 === b) {
                  yg = Lf(a.nextSibling);
                  break a;
                }
                b--;
              } else "$" !== c && "$!" !== c && "$?" !== c || b++;
            }
            a = a.nextSibling;
          }
          yg = null;
        }
      } else yg = xg ? Lf(a.stateNode.nextSibling) : null;
      return true;
    }
    function Hg() {
      for (var a = yg; a; ) a = Lf(a.nextSibling);
    }
    function Ig() {
      yg = xg = null;
      I = false;
    }
    function Jg(a) {
      null === zg ? zg = [a] : zg.push(a);
    }
    var Kg = ua.ReactCurrentBatchConfig;
    function Lg(a, b, c) {
      a = c.ref;
      if (null !== a && "function" !== typeof a && "object" !== typeof a) {
        if (c._owner) {
          c = c._owner;
          if (c) {
            if (1 !== c.tag) throw Error(p(309));
            var d = c.stateNode;
          }
          if (!d) throw Error(p(147, a));
          var e = d, f = "" + a;
          if (null !== b && null !== b.ref && "function" === typeof b.ref && b.ref._stringRef === f) return b.ref;
          b = function(a2) {
            var b2 = e.refs;
            null === a2 ? delete b2[f] : b2[f] = a2;
          };
          b._stringRef = f;
          return b;
        }
        if ("string" !== typeof a) throw Error(p(284));
        if (!c._owner) throw Error(p(290, a));
      }
      return a;
    }
    function Mg(a, b) {
      a = Object.prototype.toString.call(b);
      throw Error(p(31, "[object Object]" === a ? "object with keys {" + Object.keys(b).join(", ") + "}" : a));
    }
    function Ng(a) {
      var b = a._init;
      return b(a._payload);
    }
    function Og(a) {
      function b(b2, c2) {
        if (a) {
          var d2 = b2.deletions;
          null === d2 ? (b2.deletions = [c2], b2.flags |= 16) : d2.push(c2);
        }
      }
      function c(c2, d2) {
        if (!a) return null;
        for (; null !== d2; ) b(c2, d2), d2 = d2.sibling;
        return null;
      }
      function d(a2, b2) {
        for (a2 = /* @__PURE__ */ new Map(); null !== b2; ) null !== b2.key ? a2.set(b2.key, b2) : a2.set(b2.index, b2), b2 = b2.sibling;
        return a2;
      }
      function e(a2, b2) {
        a2 = Pg(a2, b2);
        a2.index = 0;
        a2.sibling = null;
        return a2;
      }
      function f(b2, c2, d2) {
        b2.index = d2;
        if (!a) return b2.flags |= 1048576, c2;
        d2 = b2.alternate;
        if (null !== d2) return d2 = d2.index, d2 < c2 ? (b2.flags |= 2, c2) : d2;
        b2.flags |= 2;
        return c2;
      }
      function g(b2) {
        a && null === b2.alternate && (b2.flags |= 2);
        return b2;
      }
      function h(a2, b2, c2, d2) {
        if (null === b2 || 6 !== b2.tag) return b2 = Qg(c2, a2.mode, d2), b2.return = a2, b2;
        b2 = e(b2, c2);
        b2.return = a2;
        return b2;
      }
      function k(a2, b2, c2, d2) {
        var f2 = c2.type;
        if (f2 === ya) return m(a2, b2, c2.props.children, d2, c2.key);
        if (null !== b2 && (b2.elementType === f2 || "object" === typeof f2 && null !== f2 && f2.$$typeof === Ha && Ng(f2) === b2.type)) return d2 = e(b2, c2.props), d2.ref = Lg(a2, b2, c2), d2.return = a2, d2;
        d2 = Rg(c2.type, c2.key, c2.props, null, a2.mode, d2);
        d2.ref = Lg(a2, b2, c2);
        d2.return = a2;
        return d2;
      }
      function l(a2, b2, c2, d2) {
        if (null === b2 || 4 !== b2.tag || b2.stateNode.containerInfo !== c2.containerInfo || b2.stateNode.implementation !== c2.implementation) return b2 = Sg(c2, a2.mode, d2), b2.return = a2, b2;
        b2 = e(b2, c2.children || []);
        b2.return = a2;
        return b2;
      }
      function m(a2, b2, c2, d2, f2) {
        if (null === b2 || 7 !== b2.tag) return b2 = Tg(c2, a2.mode, d2, f2), b2.return = a2, b2;
        b2 = e(b2, c2);
        b2.return = a2;
        return b2;
      }
      function q(a2, b2, c2) {
        if ("string" === typeof b2 && "" !== b2 || "number" === typeof b2) return b2 = Qg("" + b2, a2.mode, c2), b2.return = a2, b2;
        if ("object" === typeof b2 && null !== b2) {
          switch (b2.$$typeof) {
            case va:
              return c2 = Rg(b2.type, b2.key, b2.props, null, a2.mode, c2), c2.ref = Lg(a2, null, b2), c2.return = a2, c2;
            case wa:
              return b2 = Sg(b2, a2.mode, c2), b2.return = a2, b2;
            case Ha:
              var d2 = b2._init;
              return q(a2, d2(b2._payload), c2);
          }
          if (eb(b2) || Ka(b2)) return b2 = Tg(b2, a2.mode, c2, null), b2.return = a2, b2;
          Mg(a2, b2);
        }
        return null;
      }
      function r2(a2, b2, c2, d2) {
        var e2 = null !== b2 ? b2.key : null;
        if ("string" === typeof c2 && "" !== c2 || "number" === typeof c2) return null !== e2 ? null : h(a2, b2, "" + c2, d2);
        if ("object" === typeof c2 && null !== c2) {
          switch (c2.$$typeof) {
            case va:
              return c2.key === e2 ? k(a2, b2, c2, d2) : null;
            case wa:
              return c2.key === e2 ? l(a2, b2, c2, d2) : null;
            case Ha:
              return e2 = c2._init, r2(
                a2,
                b2,
                e2(c2._payload),
                d2
              );
          }
          if (eb(c2) || Ka(c2)) return null !== e2 ? null : m(a2, b2, c2, d2, null);
          Mg(a2, c2);
        }
        return null;
      }
      function y(a2, b2, c2, d2, e2) {
        if ("string" === typeof d2 && "" !== d2 || "number" === typeof d2) return a2 = a2.get(c2) || null, h(b2, a2, "" + d2, e2);
        if ("object" === typeof d2 && null !== d2) {
          switch (d2.$$typeof) {
            case va:
              return a2 = a2.get(null === d2.key ? c2 : d2.key) || null, k(b2, a2, d2, e2);
            case wa:
              return a2 = a2.get(null === d2.key ? c2 : d2.key) || null, l(b2, a2, d2, e2);
            case Ha:
              var f2 = d2._init;
              return y(a2, b2, c2, f2(d2._payload), e2);
          }
          if (eb(d2) || Ka(d2)) return a2 = a2.get(c2) || null, m(b2, a2, d2, e2, null);
          Mg(b2, d2);
        }
        return null;
      }
      function n(e2, g2, h2, k2) {
        for (var l2 = null, m2 = null, u = g2, w = g2 = 0, x = null; null !== u && w < h2.length; w++) {
          u.index > w ? (x = u, u = null) : x = u.sibling;
          var n2 = r2(e2, u, h2[w], k2);
          if (null === n2) {
            null === u && (u = x);
            break;
          }
          a && u && null === n2.alternate && b(e2, u);
          g2 = f(n2, g2, w);
          null === m2 ? l2 = n2 : m2.sibling = n2;
          m2 = n2;
          u = x;
        }
        if (w === h2.length) return c(e2, u), I && tg(e2, w), l2;
        if (null === u) {
          for (; w < h2.length; w++) u = q(e2, h2[w], k2), null !== u && (g2 = f(u, g2, w), null === m2 ? l2 = u : m2.sibling = u, m2 = u);
          I && tg(e2, w);
          return l2;
        }
        for (u = d(e2, u); w < h2.length; w++) x = y(u, e2, w, h2[w], k2), null !== x && (a && null !== x.alternate && u.delete(null === x.key ? w : x.key), g2 = f(x, g2, w), null === m2 ? l2 = x : m2.sibling = x, m2 = x);
        a && u.forEach(function(a2) {
          return b(e2, a2);
        });
        I && tg(e2, w);
        return l2;
      }
      function t(e2, g2, h2, k2) {
        var l2 = Ka(h2);
        if ("function" !== typeof l2) throw Error(p(150));
        h2 = l2.call(h2);
        if (null == h2) throw Error(p(151));
        for (var u = l2 = null, m2 = g2, w = g2 = 0, x = null, n2 = h2.next(); null !== m2 && !n2.done; w++, n2 = h2.next()) {
          m2.index > w ? (x = m2, m2 = null) : x = m2.sibling;
          var t2 = r2(e2, m2, n2.value, k2);
          if (null === t2) {
            null === m2 && (m2 = x);
            break;
          }
          a && m2 && null === t2.alternate && b(e2, m2);
          g2 = f(t2, g2, w);
          null === u ? l2 = t2 : u.sibling = t2;
          u = t2;
          m2 = x;
        }
        if (n2.done) return c(
          e2,
          m2
        ), I && tg(e2, w), l2;
        if (null === m2) {
          for (; !n2.done; w++, n2 = h2.next()) n2 = q(e2, n2.value, k2), null !== n2 && (g2 = f(n2, g2, w), null === u ? l2 = n2 : u.sibling = n2, u = n2);
          I && tg(e2, w);
          return l2;
        }
        for (m2 = d(e2, m2); !n2.done; w++, n2 = h2.next()) n2 = y(m2, e2, w, n2.value, k2), null !== n2 && (a && null !== n2.alternate && m2.delete(null === n2.key ? w : n2.key), g2 = f(n2, g2, w), null === u ? l2 = n2 : u.sibling = n2, u = n2);
        a && m2.forEach(function(a2) {
          return b(e2, a2);
        });
        I && tg(e2, w);
        return l2;
      }
      function J(a2, d2, f2, h2) {
        "object" === typeof f2 && null !== f2 && f2.type === ya && null === f2.key && (f2 = f2.props.children);
        if ("object" === typeof f2 && null !== f2) {
          switch (f2.$$typeof) {
            case va:
              a: {
                for (var k2 = f2.key, l2 = d2; null !== l2; ) {
                  if (l2.key === k2) {
                    k2 = f2.type;
                    if (k2 === ya) {
                      if (7 === l2.tag) {
                        c(a2, l2.sibling);
                        d2 = e(l2, f2.props.children);
                        d2.return = a2;
                        a2 = d2;
                        break a;
                      }
                    } else if (l2.elementType === k2 || "object" === typeof k2 && null !== k2 && k2.$$typeof === Ha && Ng(k2) === l2.type) {
                      c(a2, l2.sibling);
                      d2 = e(l2, f2.props);
                      d2.ref = Lg(a2, l2, f2);
                      d2.return = a2;
                      a2 = d2;
                      break a;
                    }
                    c(a2, l2);
                    break;
                  } else b(a2, l2);
                  l2 = l2.sibling;
                }
                f2.type === ya ? (d2 = Tg(f2.props.children, a2.mode, h2, f2.key), d2.return = a2, a2 = d2) : (h2 = Rg(f2.type, f2.key, f2.props, null, a2.mode, h2), h2.ref = Lg(a2, d2, f2), h2.return = a2, a2 = h2);
              }
              return g(a2);
            case wa:
              a: {
                for (l2 = f2.key; null !== d2; ) {
                  if (d2.key === l2) if (4 === d2.tag && d2.stateNode.containerInfo === f2.containerInfo && d2.stateNode.implementation === f2.implementation) {
                    c(a2, d2.sibling);
                    d2 = e(d2, f2.children || []);
                    d2.return = a2;
                    a2 = d2;
                    break a;
                  } else {
                    c(a2, d2);
                    break;
                  }
                  else b(a2, d2);
                  d2 = d2.sibling;
                }
                d2 = Sg(f2, a2.mode, h2);
                d2.return = a2;
                a2 = d2;
              }
              return g(a2);
            case Ha:
              return l2 = f2._init, J(a2, d2, l2(f2._payload), h2);
          }
          if (eb(f2)) return n(a2, d2, f2, h2);
          if (Ka(f2)) return t(a2, d2, f2, h2);
          Mg(a2, f2);
        }
        return "string" === typeof f2 && "" !== f2 || "number" === typeof f2 ? (f2 = "" + f2, null !== d2 && 6 === d2.tag ? (c(a2, d2.sibling), d2 = e(d2, f2), d2.return = a2, a2 = d2) : (c(a2, d2), d2 = Qg(f2, a2.mode, h2), d2.return = a2, a2 = d2), g(a2)) : c(a2, d2);
      }
      return J;
    }
    var Ug = Og(true);
    var Vg = Og(false);
    var Wg = Uf(null);
    var Xg = null;
    var Yg = null;
    var Zg = null;
    function $g() {
      Zg = Yg = Xg = null;
    }
    function ah(a) {
      var b = Wg.current;
      E(Wg);
      a._currentValue = b;
    }
    function bh(a, b, c) {
      for (; null !== a; ) {
        var d = a.alternate;
        (a.childLanes & b) !== b ? (a.childLanes |= b, null !== d && (d.childLanes |= b)) : null !== d && (d.childLanes & b) !== b && (d.childLanes |= b);
        if (a === c) break;
        a = a.return;
      }
    }
    function ch(a, b) {
      Xg = a;
      Zg = Yg = null;
      a = a.dependencies;
      null !== a && null !== a.firstContext && (0 !== (a.lanes & b) && (dh = true), a.firstContext = null);
    }
    function eh(a) {
      var b = a._currentValue;
      if (Zg !== a) if (a = { context: a, memoizedValue: b, next: null }, null === Yg) {
        if (null === Xg) throw Error(p(308));
        Yg = a;
        Xg.dependencies = { lanes: 0, firstContext: a };
      } else Yg = Yg.next = a;
      return b;
    }
    var fh = null;
    function gh(a) {
      null === fh ? fh = [a] : fh.push(a);
    }
    function hh(a, b, c, d) {
      var e = b.interleaved;
      null === e ? (c.next = c, gh(b)) : (c.next = e.next, e.next = c);
      b.interleaved = c;
      return ih(a, d);
    }
    function ih(a, b) {
      a.lanes |= b;
      var c = a.alternate;
      null !== c && (c.lanes |= b);
      c = a;
      for (a = a.return; null !== a; ) a.childLanes |= b, c = a.alternate, null !== c && (c.childLanes |= b), c = a, a = a.return;
      return 3 === c.tag ? c.stateNode : null;
    }
    var jh = false;
    function kh(a) {
      a.updateQueue = { baseState: a.memoizedState, firstBaseUpdate: null, lastBaseUpdate: null, shared: { pending: null, interleaved: null, lanes: 0 }, effects: null };
    }
    function lh(a, b) {
      a = a.updateQueue;
      b.updateQueue === a && (b.updateQueue = { baseState: a.baseState, firstBaseUpdate: a.firstBaseUpdate, lastBaseUpdate: a.lastBaseUpdate, shared: a.shared, effects: a.effects });
    }
    function mh(a, b) {
      return { eventTime: a, lane: b, tag: 0, payload: null, callback: null, next: null };
    }
    function nh(a, b, c) {
      var d = a.updateQueue;
      if (null === d) return null;
      d = d.shared;
      if (0 !== (K & 2)) {
        var e = d.pending;
        null === e ? b.next = b : (b.next = e.next, e.next = b);
        d.pending = b;
        return ih(a, c);
      }
      e = d.interleaved;
      null === e ? (b.next = b, gh(d)) : (b.next = e.next, e.next = b);
      d.interleaved = b;
      return ih(a, c);
    }
    function oh(a, b, c) {
      b = b.updateQueue;
      if (null !== b && (b = b.shared, 0 !== (c & 4194240))) {
        var d = b.lanes;
        d &= a.pendingLanes;
        c |= d;
        b.lanes = c;
        Cc(a, c);
      }
    }
    function ph(a, b) {
      var c = a.updateQueue, d = a.alternate;
      if (null !== d && (d = d.updateQueue, c === d)) {
        var e = null, f = null;
        c = c.firstBaseUpdate;
        if (null !== c) {
          do {
            var g = { eventTime: c.eventTime, lane: c.lane, tag: c.tag, payload: c.payload, callback: c.callback, next: null };
            null === f ? e = f = g : f = f.next = g;
            c = c.next;
          } while (null !== c);
          null === f ? e = f = b : f = f.next = b;
        } else e = f = b;
        c = { baseState: d.baseState, firstBaseUpdate: e, lastBaseUpdate: f, shared: d.shared, effects: d.effects };
        a.updateQueue = c;
        return;
      }
      a = c.lastBaseUpdate;
      null === a ? c.firstBaseUpdate = b : a.next = b;
      c.lastBaseUpdate = b;
    }
    function qh(a, b, c, d) {
      var e = a.updateQueue;
      jh = false;
      var f = e.firstBaseUpdate, g = e.lastBaseUpdate, h = e.shared.pending;
      if (null !== h) {
        e.shared.pending = null;
        var k = h, l = k.next;
        k.next = null;
        null === g ? f = l : g.next = l;
        g = k;
        var m = a.alternate;
        null !== m && (m = m.updateQueue, h = m.lastBaseUpdate, h !== g && (null === h ? m.firstBaseUpdate = l : h.next = l, m.lastBaseUpdate = k));
      }
      if (null !== f) {
        var q = e.baseState;
        g = 0;
        m = l = k = null;
        h = f;
        do {
          var r2 = h.lane, y = h.eventTime;
          if ((d & r2) === r2) {
            null !== m && (m = m.next = {
              eventTime: y,
              lane: 0,
              tag: h.tag,
              payload: h.payload,
              callback: h.callback,
              next: null
            });
            a: {
              var n = a, t = h;
              r2 = b;
              y = c;
              switch (t.tag) {
                case 1:
                  n = t.payload;
                  if ("function" === typeof n) {
                    q = n.call(y, q, r2);
                    break a;
                  }
                  q = n;
                  break a;
                case 3:
                  n.flags = n.flags & -65537 | 128;
                case 0:
                  n = t.payload;
                  r2 = "function" === typeof n ? n.call(y, q, r2) : n;
                  if (null === r2 || void 0 === r2) break a;
                  q = A({}, q, r2);
                  break a;
                case 2:
                  jh = true;
              }
            }
            null !== h.callback && 0 !== h.lane && (a.flags |= 64, r2 = e.effects, null === r2 ? e.effects = [h] : r2.push(h));
          } else y = { eventTime: y, lane: r2, tag: h.tag, payload: h.payload, callback: h.callback, next: null }, null === m ? (l = m = y, k = q) : m = m.next = y, g |= r2;
          h = h.next;
          if (null === h) if (h = e.shared.pending, null === h) break;
          else r2 = h, h = r2.next, r2.next = null, e.lastBaseUpdate = r2, e.shared.pending = null;
        } while (1);
        null === m && (k = q);
        e.baseState = k;
        e.firstBaseUpdate = l;
        e.lastBaseUpdate = m;
        b = e.shared.interleaved;
        if (null !== b) {
          e = b;
          do
            g |= e.lane, e = e.next;
          while (e !== b);
        } else null === f && (e.shared.lanes = 0);
        rh |= g;
        a.lanes = g;
        a.memoizedState = q;
      }
    }
    function sh(a, b, c) {
      a = b.effects;
      b.effects = null;
      if (null !== a) for (b = 0; b < a.length; b++) {
        var d = a[b], e = d.callback;
        if (null !== e) {
          d.callback = null;
          d = c;
          if ("function" !== typeof e) throw Error(p(191, e));
          e.call(d);
        }
      }
    }
    var th = {};
    var uh = Uf(th);
    var vh = Uf(th);
    var wh = Uf(th);
    function xh(a) {
      if (a === th) throw Error(p(174));
      return a;
    }
    function yh(a, b) {
      G(wh, b);
      G(vh, a);
      G(uh, th);
      a = b.nodeType;
      switch (a) {
        case 9:
        case 11:
          b = (b = b.documentElement) ? b.namespaceURI : lb(null, "");
          break;
        default:
          a = 8 === a ? b.parentNode : b, b = a.namespaceURI || null, a = a.tagName, b = lb(b, a);
      }
      E(uh);
      G(uh, b);
    }
    function zh() {
      E(uh);
      E(vh);
      E(wh);
    }
    function Ah(a) {
      xh(wh.current);
      var b = xh(uh.current);
      var c = lb(b, a.type);
      b !== c && (G(vh, a), G(uh, c));
    }
    function Bh(a) {
      vh.current === a && (E(uh), E(vh));
    }
    var L = Uf(0);
    function Ch(a) {
      for (var b = a; null !== b; ) {
        if (13 === b.tag) {
          var c = b.memoizedState;
          if (null !== c && (c = c.dehydrated, null === c || "$?" === c.data || "$!" === c.data)) return b;
        } else if (19 === b.tag && void 0 !== b.memoizedProps.revealOrder) {
          if (0 !== (b.flags & 128)) return b;
        } else if (null !== b.child) {
          b.child.return = b;
          b = b.child;
          continue;
        }
        if (b === a) break;
        for (; null === b.sibling; ) {
          if (null === b.return || b.return === a) return null;
          b = b.return;
        }
        b.sibling.return = b.return;
        b = b.sibling;
      }
      return null;
    }
    var Dh = [];
    function Eh() {
      for (var a = 0; a < Dh.length; a++) Dh[a]._workInProgressVersionPrimary = null;
      Dh.length = 0;
    }
    var Fh = ua.ReactCurrentDispatcher;
    var Gh = ua.ReactCurrentBatchConfig;
    var Hh = 0;
    var M = null;
    var N = null;
    var O = null;
    var Ih = false;
    var Jh = false;
    var Kh = 0;
    var Lh = 0;
    function P() {
      throw Error(p(321));
    }
    function Mh(a, b) {
      if (null === b) return false;
      for (var c = 0; c < b.length && c < a.length; c++) if (!He(a[c], b[c])) return false;
      return true;
    }
    function Nh(a, b, c, d, e, f) {
      Hh = f;
      M = b;
      b.memoizedState = null;
      b.updateQueue = null;
      b.lanes = 0;
      Fh.current = null === a || null === a.memoizedState ? Oh : Ph;
      a = c(d, e);
      if (Jh) {
        f = 0;
        do {
          Jh = false;
          Kh = 0;
          if (25 <= f) throw Error(p(301));
          f += 1;
          O = N = null;
          b.updateQueue = null;
          Fh.current = Qh;
          a = c(d, e);
        } while (Jh);
      }
      Fh.current = Rh;
      b = null !== N && null !== N.next;
      Hh = 0;
      O = N = M = null;
      Ih = false;
      if (b) throw Error(p(300));
      return a;
    }
    function Sh() {
      var a = 0 !== Kh;
      Kh = 0;
      return a;
    }
    function Th() {
      var a = { memoizedState: null, baseState: null, baseQueue: null, queue: null, next: null };
      null === O ? M.memoizedState = O = a : O = O.next = a;
      return O;
    }
    function Uh() {
      if (null === N) {
        var a = M.alternate;
        a = null !== a ? a.memoizedState : null;
      } else a = N.next;
      var b = null === O ? M.memoizedState : O.next;
      if (null !== b) O = b, N = a;
      else {
        if (null === a) throw Error(p(310));
        N = a;
        a = { memoizedState: N.memoizedState, baseState: N.baseState, baseQueue: N.baseQueue, queue: N.queue, next: null };
        null === O ? M.memoizedState = O = a : O = O.next = a;
      }
      return O;
    }
    function Vh(a, b) {
      return "function" === typeof b ? b(a) : b;
    }
    function Wh(a) {
      var b = Uh(), c = b.queue;
      if (null === c) throw Error(p(311));
      c.lastRenderedReducer = a;
      var d = N, e = d.baseQueue, f = c.pending;
      if (null !== f) {
        if (null !== e) {
          var g = e.next;
          e.next = f.next;
          f.next = g;
        }
        d.baseQueue = e = f;
        c.pending = null;
      }
      if (null !== e) {
        f = e.next;
        d = d.baseState;
        var h = g = null, k = null, l = f;
        do {
          var m = l.lane;
          if ((Hh & m) === m) null !== k && (k = k.next = { lane: 0, action: l.action, hasEagerState: l.hasEagerState, eagerState: l.eagerState, next: null }), d = l.hasEagerState ? l.eagerState : a(d, l.action);
          else {
            var q = {
              lane: m,
              action: l.action,
              hasEagerState: l.hasEagerState,
              eagerState: l.eagerState,
              next: null
            };
            null === k ? (h = k = q, g = d) : k = k.next = q;
            M.lanes |= m;
            rh |= m;
          }
          l = l.next;
        } while (null !== l && l !== f);
        null === k ? g = d : k.next = h;
        He(d, b.memoizedState) || (dh = true);
        b.memoizedState = d;
        b.baseState = g;
        b.baseQueue = k;
        c.lastRenderedState = d;
      }
      a = c.interleaved;
      if (null !== a) {
        e = a;
        do
          f = e.lane, M.lanes |= f, rh |= f, e = e.next;
        while (e !== a);
      } else null === e && (c.lanes = 0);
      return [b.memoizedState, c.dispatch];
    }
    function Xh(a) {
      var b = Uh(), c = b.queue;
      if (null === c) throw Error(p(311));
      c.lastRenderedReducer = a;
      var d = c.dispatch, e = c.pending, f = b.memoizedState;
      if (null !== e) {
        c.pending = null;
        var g = e = e.next;
        do
          f = a(f, g.action), g = g.next;
        while (g !== e);
        He(f, b.memoizedState) || (dh = true);
        b.memoizedState = f;
        null === b.baseQueue && (b.baseState = f);
        c.lastRenderedState = f;
      }
      return [f, d];
    }
    function Yh() {
    }
    function Zh(a, b) {
      var c = M, d = Uh(), e = b(), f = !He(d.memoizedState, e);
      f && (d.memoizedState = e, dh = true);
      d = d.queue;
      $h(ai.bind(null, c, d, a), [a]);
      if (d.getSnapshot !== b || f || null !== O && O.memoizedState.tag & 1) {
        c.flags |= 2048;
        bi(9, ci.bind(null, c, d, e, b), void 0, null);
        if (null === Q) throw Error(p(349));
        0 !== (Hh & 30) || di(c, b, e);
      }
      return e;
    }
    function di(a, b, c) {
      a.flags |= 16384;
      a = { getSnapshot: b, value: c };
      b = M.updateQueue;
      null === b ? (b = { lastEffect: null, stores: null }, M.updateQueue = b, b.stores = [a]) : (c = b.stores, null === c ? b.stores = [a] : c.push(a));
    }
    function ci(a, b, c, d) {
      b.value = c;
      b.getSnapshot = d;
      ei(b) && fi(a);
    }
    function ai(a, b, c) {
      return c(function() {
        ei(b) && fi(a);
      });
    }
    function ei(a) {
      var b = a.getSnapshot;
      a = a.value;
      try {
        var c = b();
        return !He(a, c);
      } catch (d) {
        return true;
      }
    }
    function fi(a) {
      var b = ih(a, 1);
      null !== b && gi(b, a, 1, -1);
    }
    function hi(a) {
      var b = Th();
      "function" === typeof a && (a = a());
      b.memoizedState = b.baseState = a;
      a = { pending: null, interleaved: null, lanes: 0, dispatch: null, lastRenderedReducer: Vh, lastRenderedState: a };
      b.queue = a;
      a = a.dispatch = ii.bind(null, M, a);
      return [b.memoizedState, a];
    }
    function bi(a, b, c, d) {
      a = { tag: a, create: b, destroy: c, deps: d, next: null };
      b = M.updateQueue;
      null === b ? (b = { lastEffect: null, stores: null }, M.updateQueue = b, b.lastEffect = a.next = a) : (c = b.lastEffect, null === c ? b.lastEffect = a.next = a : (d = c.next, c.next = a, a.next = d, b.lastEffect = a));
      return a;
    }
    function ji() {
      return Uh().memoizedState;
    }
    function ki(a, b, c, d) {
      var e = Th();
      M.flags |= a;
      e.memoizedState = bi(1 | b, c, void 0, void 0 === d ? null : d);
    }
    function li(a, b, c, d) {
      var e = Uh();
      d = void 0 === d ? null : d;
      var f = void 0;
      if (null !== N) {
        var g = N.memoizedState;
        f = g.destroy;
        if (null !== d && Mh(d, g.deps)) {
          e.memoizedState = bi(b, c, f, d);
          return;
        }
      }
      M.flags |= a;
      e.memoizedState = bi(1 | b, c, f, d);
    }
    function mi(a, b) {
      return ki(8390656, 8, a, b);
    }
    function $h(a, b) {
      return li(2048, 8, a, b);
    }
    function ni(a, b) {
      return li(4, 2, a, b);
    }
    function oi(a, b) {
      return li(4, 4, a, b);
    }
    function pi(a, b) {
      if ("function" === typeof b) return a = a(), b(a), function() {
        b(null);
      };
      if (null !== b && void 0 !== b) return a = a(), b.current = a, function() {
        b.current = null;
      };
    }
    function qi(a, b, c) {
      c = null !== c && void 0 !== c ? c.concat([a]) : null;
      return li(4, 4, pi.bind(null, b, a), c);
    }
    function ri() {
    }
    function si(a, b) {
      var c = Uh();
      b = void 0 === b ? null : b;
      var d = c.memoizedState;
      if (null !== d && null !== b && Mh(b, d[1])) return d[0];
      c.memoizedState = [a, b];
      return a;
    }
    function ti(a, b) {
      var c = Uh();
      b = void 0 === b ? null : b;
      var d = c.memoizedState;
      if (null !== d && null !== b && Mh(b, d[1])) return d[0];
      a = a();
      c.memoizedState = [a, b];
      return a;
    }
    function ui(a, b, c) {
      if (0 === (Hh & 21)) return a.baseState && (a.baseState = false, dh = true), a.memoizedState = c;
      He(c, b) || (c = yc(), M.lanes |= c, rh |= c, a.baseState = true);
      return b;
    }
    function vi(a, b) {
      var c = C2;
      C2 = 0 !== c && 4 > c ? c : 4;
      a(true);
      var d = Gh.transition;
      Gh.transition = {};
      try {
        a(false), b();
      } finally {
        C2 = c, Gh.transition = d;
      }
    }
    function wi() {
      return Uh().memoizedState;
    }
    function xi(a, b, c) {
      var d = yi(a);
      c = { lane: d, action: c, hasEagerState: false, eagerState: null, next: null };
      if (zi(a)) Ai(b, c);
      else if (c = hh(a, b, c, d), null !== c) {
        var e = R2();
        gi(c, a, d, e);
        Bi(c, b, d);
      }
    }
    function ii(a, b, c) {
      var d = yi(a), e = { lane: d, action: c, hasEagerState: false, eagerState: null, next: null };
      if (zi(a)) Ai(b, e);
      else {
        var f = a.alternate;
        if (0 === a.lanes && (null === f || 0 === f.lanes) && (f = b.lastRenderedReducer, null !== f)) try {
          var g = b.lastRenderedState, h = f(g, c);
          e.hasEagerState = true;
          e.eagerState = h;
          if (He(h, g)) {
            var k = b.interleaved;
            null === k ? (e.next = e, gh(b)) : (e.next = k.next, k.next = e);
            b.interleaved = e;
            return;
          }
        } catch (l) {
        } finally {
        }
        c = hh(a, b, e, d);
        null !== c && (e = R2(), gi(c, a, d, e), Bi(c, b, d));
      }
    }
    function zi(a) {
      var b = a.alternate;
      return a === M || null !== b && b === M;
    }
    function Ai(a, b) {
      Jh = Ih = true;
      var c = a.pending;
      null === c ? b.next = b : (b.next = c.next, c.next = b);
      a.pending = b;
    }
    function Bi(a, b, c) {
      if (0 !== (c & 4194240)) {
        var d = b.lanes;
        d &= a.pendingLanes;
        c |= d;
        b.lanes = c;
        Cc(a, c);
      }
    }
    var Rh = { readContext: eh, useCallback: P, useContext: P, useEffect: P, useImperativeHandle: P, useInsertionEffect: P, useLayoutEffect: P, useMemo: P, useReducer: P, useRef: P, useState: P, useDebugValue: P, useDeferredValue: P, useTransition: P, useMutableSource: P, useSyncExternalStore: P, useId: P, unstable_isNewReconciler: false };
    var Oh = { readContext: eh, useCallback: function(a, b) {
      Th().memoizedState = [a, void 0 === b ? null : b];
      return a;
    }, useContext: eh, useEffect: mi, useImperativeHandle: function(a, b, c) {
      c = null !== c && void 0 !== c ? c.concat([a]) : null;
      return ki(
        4194308,
        4,
        pi.bind(null, b, a),
        c
      );
    }, useLayoutEffect: function(a, b) {
      return ki(4194308, 4, a, b);
    }, useInsertionEffect: function(a, b) {
      return ki(4, 2, a, b);
    }, useMemo: function(a, b) {
      var c = Th();
      b = void 0 === b ? null : b;
      a = a();
      c.memoizedState = [a, b];
      return a;
    }, useReducer: function(a, b, c) {
      var d = Th();
      b = void 0 !== c ? c(b) : b;
      d.memoizedState = d.baseState = b;
      a = { pending: null, interleaved: null, lanes: 0, dispatch: null, lastRenderedReducer: a, lastRenderedState: b };
      d.queue = a;
      a = a.dispatch = xi.bind(null, M, a);
      return [d.memoizedState, a];
    }, useRef: function(a) {
      var b = Th();
      a = { current: a };
      return b.memoizedState = a;
    }, useState: hi, useDebugValue: ri, useDeferredValue: function(a) {
      return Th().memoizedState = a;
    }, useTransition: function() {
      var a = hi(false), b = a[0];
      a = vi.bind(null, a[1]);
      Th().memoizedState = a;
      return [b, a];
    }, useMutableSource: function() {
    }, useSyncExternalStore: function(a, b, c) {
      var d = M, e = Th();
      if (I) {
        if (void 0 === c) throw Error(p(407));
        c = c();
      } else {
        c = b();
        if (null === Q) throw Error(p(349));
        0 !== (Hh & 30) || di(d, b, c);
      }
      e.memoizedState = c;
      var f = { value: c, getSnapshot: b };
      e.queue = f;
      mi(ai.bind(
        null,
        d,
        f,
        a
      ), [a]);
      d.flags |= 2048;
      bi(9, ci.bind(null, d, f, c, b), void 0, null);
      return c;
    }, useId: function() {
      var a = Th(), b = Q.identifierPrefix;
      if (I) {
        var c = sg;
        var d = rg;
        c = (d & ~(1 << 32 - oc(d) - 1)).toString(32) + c;
        b = ":" + b + "R" + c;
        c = Kh++;
        0 < c && (b += "H" + c.toString(32));
        b += ":";
      } else c = Lh++, b = ":" + b + "r" + c.toString(32) + ":";
      return a.memoizedState = b;
    }, unstable_isNewReconciler: false };
    var Ph = {
      readContext: eh,
      useCallback: si,
      useContext: eh,
      useEffect: $h,
      useImperativeHandle: qi,
      useInsertionEffect: ni,
      useLayoutEffect: oi,
      useMemo: ti,
      useReducer: Wh,
      useRef: ji,
      useState: function() {
        return Wh(Vh);
      },
      useDebugValue: ri,
      useDeferredValue: function(a) {
        var b = Uh();
        return ui(b, N.memoizedState, a);
      },
      useTransition: function() {
        var a = Wh(Vh)[0], b = Uh().memoizedState;
        return [a, b];
      },
      useMutableSource: Yh,
      useSyncExternalStore: Zh,
      useId: wi,
      unstable_isNewReconciler: false
    };
    var Qh = { readContext: eh, useCallback: si, useContext: eh, useEffect: $h, useImperativeHandle: qi, useInsertionEffect: ni, useLayoutEffect: oi, useMemo: ti, useReducer: Xh, useRef: ji, useState: function() {
      return Xh(Vh);
    }, useDebugValue: ri, useDeferredValue: function(a) {
      var b = Uh();
      return null === N ? b.memoizedState = a : ui(b, N.memoizedState, a);
    }, useTransition: function() {
      var a = Xh(Vh)[0], b = Uh().memoizedState;
      return [a, b];
    }, useMutableSource: Yh, useSyncExternalStore: Zh, useId: wi, unstable_isNewReconciler: false };
    function Ci(a, b) {
      if (a && a.defaultProps) {
        b = A({}, b);
        a = a.defaultProps;
        for (var c in a) void 0 === b[c] && (b[c] = a[c]);
        return b;
      }
      return b;
    }
    function Di(a, b, c, d) {
      b = a.memoizedState;
      c = c(d, b);
      c = null === c || void 0 === c ? b : A({}, b, c);
      a.memoizedState = c;
      0 === a.lanes && (a.updateQueue.baseState = c);
    }
    var Ei = { isMounted: function(a) {
      return (a = a._reactInternals) ? Vb(a) === a : false;
    }, enqueueSetState: function(a, b, c) {
      a = a._reactInternals;
      var d = R2(), e = yi(a), f = mh(d, e);
      f.payload = b;
      void 0 !== c && null !== c && (f.callback = c);
      b = nh(a, f, e);
      null !== b && (gi(b, a, e, d), oh(b, a, e));
    }, enqueueReplaceState: function(a, b, c) {
      a = a._reactInternals;
      var d = R2(), e = yi(a), f = mh(d, e);
      f.tag = 1;
      f.payload = b;
      void 0 !== c && null !== c && (f.callback = c);
      b = nh(a, f, e);
      null !== b && (gi(b, a, e, d), oh(b, a, e));
    }, enqueueForceUpdate: function(a, b) {
      a = a._reactInternals;
      var c = R2(), d = yi(a), e = mh(c, d);
      e.tag = 2;
      void 0 !== b && null !== b && (e.callback = b);
      b = nh(a, e, d);
      null !== b && (gi(b, a, d, c), oh(b, a, d));
    } };
    function Fi(a, b, c, d, e, f, g) {
      a = a.stateNode;
      return "function" === typeof a.shouldComponentUpdate ? a.shouldComponentUpdate(d, f, g) : b.prototype && b.prototype.isPureReactComponent ? !Ie(c, d) || !Ie(e, f) : true;
    }
    function Gi(a, b, c) {
      var d = false, e = Vf;
      var f = b.contextType;
      "object" === typeof f && null !== f ? f = eh(f) : (e = Zf(b) ? Xf : H.current, d = b.contextTypes, f = (d = null !== d && void 0 !== d) ? Yf(a, e) : Vf);
      b = new b(c, f);
      a.memoizedState = null !== b.state && void 0 !== b.state ? b.state : null;
      b.updater = Ei;
      a.stateNode = b;
      b._reactInternals = a;
      d && (a = a.stateNode, a.__reactInternalMemoizedUnmaskedChildContext = e, a.__reactInternalMemoizedMaskedChildContext = f);
      return b;
    }
    function Hi(a, b, c, d) {
      a = b.state;
      "function" === typeof b.componentWillReceiveProps && b.componentWillReceiveProps(c, d);
      "function" === typeof b.UNSAFE_componentWillReceiveProps && b.UNSAFE_componentWillReceiveProps(c, d);
      b.state !== a && Ei.enqueueReplaceState(b, b.state, null);
    }
    function Ii(a, b, c, d) {
      var e = a.stateNode;
      e.props = c;
      e.state = a.memoizedState;
      e.refs = {};
      kh(a);
      var f = b.contextType;
      "object" === typeof f && null !== f ? e.context = eh(f) : (f = Zf(b) ? Xf : H.current, e.context = Yf(a, f));
      e.state = a.memoizedState;
      f = b.getDerivedStateFromProps;
      "function" === typeof f && (Di(a, b, f, c), e.state = a.memoizedState);
      "function" === typeof b.getDerivedStateFromProps || "function" === typeof e.getSnapshotBeforeUpdate || "function" !== typeof e.UNSAFE_componentWillMount && "function" !== typeof e.componentWillMount || (b = e.state, "function" === typeof e.componentWillMount && e.componentWillMount(), "function" === typeof e.UNSAFE_componentWillMount && e.UNSAFE_componentWillMount(), b !== e.state && Ei.enqueueReplaceState(e, e.state, null), qh(a, c, e, d), e.state = a.memoizedState);
      "function" === typeof e.componentDidMount && (a.flags |= 4194308);
    }
    function Ji(a, b) {
      try {
        var c = "", d = b;
        do
          c += Pa(d), d = d.return;
        while (d);
        var e = c;
      } catch (f) {
        e = "\nError generating stack: " + f.message + "\n" + f.stack;
      }
      return { value: a, source: b, stack: e, digest: null };
    }
    function Ki(a, b, c) {
      return { value: a, source: null, stack: null != c ? c : null, digest: null != b ? b : null };
    }
    function Li(a, b) {
      try {
        console.error(b.value);
      } catch (c) {
        setTimeout(function() {
          throw c;
        });
      }
    }
    var Mi = "function" === typeof WeakMap ? WeakMap : Map;
    function Ni(a, b, c) {
      c = mh(-1, c);
      c.tag = 3;
      c.payload = { element: null };
      var d = b.value;
      c.callback = function() {
        Oi || (Oi = true, Pi = d);
        Li(a, b);
      };
      return c;
    }
    function Qi(a, b, c) {
      c = mh(-1, c);
      c.tag = 3;
      var d = a.type.getDerivedStateFromError;
      if ("function" === typeof d) {
        var e = b.value;
        c.payload = function() {
          return d(e);
        };
        c.callback = function() {
          Li(a, b);
        };
      }
      var f = a.stateNode;
      null !== f && "function" === typeof f.componentDidCatch && (c.callback = function() {
        Li(a, b);
        "function" !== typeof d && (null === Ri ? Ri = /* @__PURE__ */ new Set([this]) : Ri.add(this));
        var c2 = b.stack;
        this.componentDidCatch(b.value, { componentStack: null !== c2 ? c2 : "" });
      });
      return c;
    }
    function Si(a, b, c) {
      var d = a.pingCache;
      if (null === d) {
        d = a.pingCache = new Mi();
        var e = /* @__PURE__ */ new Set();
        d.set(b, e);
      } else e = d.get(b), void 0 === e && (e = /* @__PURE__ */ new Set(), d.set(b, e));
      e.has(c) || (e.add(c), a = Ti.bind(null, a, b, c), b.then(a, a));
    }
    function Ui(a) {
      do {
        var b;
        if (b = 13 === a.tag) b = a.memoizedState, b = null !== b ? null !== b.dehydrated ? true : false : true;
        if (b) return a;
        a = a.return;
      } while (null !== a);
      return null;
    }
    function Vi(a, b, c, d, e) {
      if (0 === (a.mode & 1)) return a === b ? a.flags |= 65536 : (a.flags |= 128, c.flags |= 131072, c.flags &= -52805, 1 === c.tag && (null === c.alternate ? c.tag = 17 : (b = mh(-1, 1), b.tag = 2, nh(c, b, 1))), c.lanes |= 1), a;
      a.flags |= 65536;
      a.lanes = e;
      return a;
    }
    var Wi = ua.ReactCurrentOwner;
    var dh = false;
    function Xi(a, b, c, d) {
      b.child = null === a ? Vg(b, null, c, d) : Ug(b, a.child, c, d);
    }
    function Yi(a, b, c, d, e) {
      c = c.render;
      var f = b.ref;
      ch(b, e);
      d = Nh(a, b, c, d, f, e);
      c = Sh();
      if (null !== a && !dh) return b.updateQueue = a.updateQueue, b.flags &= -2053, a.lanes &= ~e, Zi(a, b, e);
      I && c && vg(b);
      b.flags |= 1;
      Xi(a, b, d, e);
      return b.child;
    }
    function $i(a, b, c, d, e) {
      if (null === a) {
        var f = c.type;
        if ("function" === typeof f && !aj(f) && void 0 === f.defaultProps && null === c.compare && void 0 === c.defaultProps) return b.tag = 15, b.type = f, bj(a, b, f, d, e);
        a = Rg(c.type, null, d, b, b.mode, e);
        a.ref = b.ref;
        a.return = b;
        return b.child = a;
      }
      f = a.child;
      if (0 === (a.lanes & e)) {
        var g = f.memoizedProps;
        c = c.compare;
        c = null !== c ? c : Ie;
        if (c(g, d) && a.ref === b.ref) return Zi(a, b, e);
      }
      b.flags |= 1;
      a = Pg(f, d);
      a.ref = b.ref;
      a.return = b;
      return b.child = a;
    }
    function bj(a, b, c, d, e) {
      if (null !== a) {
        var f = a.memoizedProps;
        if (Ie(f, d) && a.ref === b.ref) if (dh = false, b.pendingProps = d = f, 0 !== (a.lanes & e)) 0 !== (a.flags & 131072) && (dh = true);
        else return b.lanes = a.lanes, Zi(a, b, e);
      }
      return cj(a, b, c, d, e);
    }
    function dj(a, b, c) {
      var d = b.pendingProps, e = d.children, f = null !== a ? a.memoizedState : null;
      if ("hidden" === d.mode) if (0 === (b.mode & 1)) b.memoizedState = { baseLanes: 0, cachePool: null, transitions: null }, G(ej, fj), fj |= c;
      else {
        if (0 === (c & 1073741824)) return a = null !== f ? f.baseLanes | c : c, b.lanes = b.childLanes = 1073741824, b.memoizedState = { baseLanes: a, cachePool: null, transitions: null }, b.updateQueue = null, G(ej, fj), fj |= a, null;
        b.memoizedState = { baseLanes: 0, cachePool: null, transitions: null };
        d = null !== f ? f.baseLanes : c;
        G(ej, fj);
        fj |= d;
      }
      else null !== f ? (d = f.baseLanes | c, b.memoizedState = null) : d = c, G(ej, fj), fj |= d;
      Xi(a, b, e, c);
      return b.child;
    }
    function gj(a, b) {
      var c = b.ref;
      if (null === a && null !== c || null !== a && a.ref !== c) b.flags |= 512, b.flags |= 2097152;
    }
    function cj(a, b, c, d, e) {
      var f = Zf(c) ? Xf : H.current;
      f = Yf(b, f);
      ch(b, e);
      c = Nh(a, b, c, d, f, e);
      d = Sh();
      if (null !== a && !dh) return b.updateQueue = a.updateQueue, b.flags &= -2053, a.lanes &= ~e, Zi(a, b, e);
      I && d && vg(b);
      b.flags |= 1;
      Xi(a, b, c, e);
      return b.child;
    }
    function hj(a, b, c, d, e) {
      if (Zf(c)) {
        var f = true;
        cg(b);
      } else f = false;
      ch(b, e);
      if (null === b.stateNode) ij(a, b), Gi(b, c, d), Ii(b, c, d, e), d = true;
      else if (null === a) {
        var g = b.stateNode, h = b.memoizedProps;
        g.props = h;
        var k = g.context, l = c.contextType;
        "object" === typeof l && null !== l ? l = eh(l) : (l = Zf(c) ? Xf : H.current, l = Yf(b, l));
        var m = c.getDerivedStateFromProps, q = "function" === typeof m || "function" === typeof g.getSnapshotBeforeUpdate;
        q || "function" !== typeof g.UNSAFE_componentWillReceiveProps && "function" !== typeof g.componentWillReceiveProps || (h !== d || k !== l) && Hi(b, g, d, l);
        jh = false;
        var r2 = b.memoizedState;
        g.state = r2;
        qh(b, d, g, e);
        k = b.memoizedState;
        h !== d || r2 !== k || Wf.current || jh ? ("function" === typeof m && (Di(b, c, m, d), k = b.memoizedState), (h = jh || Fi(b, c, h, d, r2, k, l)) ? (q || "function" !== typeof g.UNSAFE_componentWillMount && "function" !== typeof g.componentWillMount || ("function" === typeof g.componentWillMount && g.componentWillMount(), "function" === typeof g.UNSAFE_componentWillMount && g.UNSAFE_componentWillMount()), "function" === typeof g.componentDidMount && (b.flags |= 4194308)) : ("function" === typeof g.componentDidMount && (b.flags |= 4194308), b.memoizedProps = d, b.memoizedState = k), g.props = d, g.state = k, g.context = l, d = h) : ("function" === typeof g.componentDidMount && (b.flags |= 4194308), d = false);
      } else {
        g = b.stateNode;
        lh(a, b);
        h = b.memoizedProps;
        l = b.type === b.elementType ? h : Ci(b.type, h);
        g.props = l;
        q = b.pendingProps;
        r2 = g.context;
        k = c.contextType;
        "object" === typeof k && null !== k ? k = eh(k) : (k = Zf(c) ? Xf : H.current, k = Yf(b, k));
        var y = c.getDerivedStateFromProps;
        (m = "function" === typeof y || "function" === typeof g.getSnapshotBeforeUpdate) || "function" !== typeof g.UNSAFE_componentWillReceiveProps && "function" !== typeof g.componentWillReceiveProps || (h !== q || r2 !== k) && Hi(b, g, d, k);
        jh = false;
        r2 = b.memoizedState;
        g.state = r2;
        qh(b, d, g, e);
        var n = b.memoizedState;
        h !== q || r2 !== n || Wf.current || jh ? ("function" === typeof y && (Di(b, c, y, d), n = b.memoizedState), (l = jh || Fi(b, c, l, d, r2, n, k) || false) ? (m || "function" !== typeof g.UNSAFE_componentWillUpdate && "function" !== typeof g.componentWillUpdate || ("function" === typeof g.componentWillUpdate && g.componentWillUpdate(d, n, k), "function" === typeof g.UNSAFE_componentWillUpdate && g.UNSAFE_componentWillUpdate(d, n, k)), "function" === typeof g.componentDidUpdate && (b.flags |= 4), "function" === typeof g.getSnapshotBeforeUpdate && (b.flags |= 1024)) : ("function" !== typeof g.componentDidUpdate || h === a.memoizedProps && r2 === a.memoizedState || (b.flags |= 4), "function" !== typeof g.getSnapshotBeforeUpdate || h === a.memoizedProps && r2 === a.memoizedState || (b.flags |= 1024), b.memoizedProps = d, b.memoizedState = n), g.props = d, g.state = n, g.context = k, d = l) : ("function" !== typeof g.componentDidUpdate || h === a.memoizedProps && r2 === a.memoizedState || (b.flags |= 4), "function" !== typeof g.getSnapshotBeforeUpdate || h === a.memoizedProps && r2 === a.memoizedState || (b.flags |= 1024), d = false);
      }
      return jj(a, b, c, d, f, e);
    }
    function jj(a, b, c, d, e, f) {
      gj(a, b);
      var g = 0 !== (b.flags & 128);
      if (!d && !g) return e && dg(b, c, false), Zi(a, b, f);
      d = b.stateNode;
      Wi.current = b;
      var h = g && "function" !== typeof c.getDerivedStateFromError ? null : d.render();
      b.flags |= 1;
      null !== a && g ? (b.child = Ug(b, a.child, null, f), b.child = Ug(b, null, h, f)) : Xi(a, b, h, f);
      b.memoizedState = d.state;
      e && dg(b, c, true);
      return b.child;
    }
    function kj(a) {
      var b = a.stateNode;
      b.pendingContext ? ag(a, b.pendingContext, b.pendingContext !== b.context) : b.context && ag(a, b.context, false);
      yh(a, b.containerInfo);
    }
    function lj(a, b, c, d, e) {
      Ig();
      Jg(e);
      b.flags |= 256;
      Xi(a, b, c, d);
      return b.child;
    }
    var mj = { dehydrated: null, treeContext: null, retryLane: 0 };
    function nj(a) {
      return { baseLanes: a, cachePool: null, transitions: null };
    }
    function oj(a, b, c) {
      var d = b.pendingProps, e = L.current, f = false, g = 0 !== (b.flags & 128), h;
      (h = g) || (h = null !== a && null === a.memoizedState ? false : 0 !== (e & 2));
      if (h) f = true, b.flags &= -129;
      else if (null === a || null !== a.memoizedState) e |= 1;
      G(L, e & 1);
      if (null === a) {
        Eg(b);
        a = b.memoizedState;
        if (null !== a && (a = a.dehydrated, null !== a)) return 0 === (b.mode & 1) ? b.lanes = 1 : "$!" === a.data ? b.lanes = 8 : b.lanes = 1073741824, null;
        g = d.children;
        a = d.fallback;
        return f ? (d = b.mode, f = b.child, g = { mode: "hidden", children: g }, 0 === (d & 1) && null !== f ? (f.childLanes = 0, f.pendingProps = g) : f = pj(g, d, 0, null), a = Tg(a, d, c, null), f.return = b, a.return = b, f.sibling = a, b.child = f, b.child.memoizedState = nj(c), b.memoizedState = mj, a) : qj(b, g);
      }
      e = a.memoizedState;
      if (null !== e && (h = e.dehydrated, null !== h)) return rj(a, b, g, d, h, e, c);
      if (f) {
        f = d.fallback;
        g = b.mode;
        e = a.child;
        h = e.sibling;
        var k = { mode: "hidden", children: d.children };
        0 === (g & 1) && b.child !== e ? (d = b.child, d.childLanes = 0, d.pendingProps = k, b.deletions = null) : (d = Pg(e, k), d.subtreeFlags = e.subtreeFlags & 14680064);
        null !== h ? f = Pg(h, f) : (f = Tg(f, g, c, null), f.flags |= 2);
        f.return = b;
        d.return = b;
        d.sibling = f;
        b.child = d;
        d = f;
        f = b.child;
        g = a.child.memoizedState;
        g = null === g ? nj(c) : { baseLanes: g.baseLanes | c, cachePool: null, transitions: g.transitions };
        f.memoizedState = g;
        f.childLanes = a.childLanes & ~c;
        b.memoizedState = mj;
        return d;
      }
      f = a.child;
      a = f.sibling;
      d = Pg(f, { mode: "visible", children: d.children });
      0 === (b.mode & 1) && (d.lanes = c);
      d.return = b;
      d.sibling = null;
      null !== a && (c = b.deletions, null === c ? (b.deletions = [a], b.flags |= 16) : c.push(a));
      b.child = d;
      b.memoizedState = null;
      return d;
    }
    function qj(a, b) {
      b = pj({ mode: "visible", children: b }, a.mode, 0, null);
      b.return = a;
      return a.child = b;
    }
    function sj(a, b, c, d) {
      null !== d && Jg(d);
      Ug(b, a.child, null, c);
      a = qj(b, b.pendingProps.children);
      a.flags |= 2;
      b.memoizedState = null;
      return a;
    }
    function rj(a, b, c, d, e, f, g) {
      if (c) {
        if (b.flags & 256) return b.flags &= -257, d = Ki(Error(p(422))), sj(a, b, g, d);
        if (null !== b.memoizedState) return b.child = a.child, b.flags |= 128, null;
        f = d.fallback;
        e = b.mode;
        d = pj({ mode: "visible", children: d.children }, e, 0, null);
        f = Tg(f, e, g, null);
        f.flags |= 2;
        d.return = b;
        f.return = b;
        d.sibling = f;
        b.child = d;
        0 !== (b.mode & 1) && Ug(b, a.child, null, g);
        b.child.memoizedState = nj(g);
        b.memoizedState = mj;
        return f;
      }
      if (0 === (b.mode & 1)) return sj(a, b, g, null);
      if ("$!" === e.data) {
        d = e.nextSibling && e.nextSibling.dataset;
        if (d) var h = d.dgst;
        d = h;
        f = Error(p(419));
        d = Ki(f, d, void 0);
        return sj(a, b, g, d);
      }
      h = 0 !== (g & a.childLanes);
      if (dh || h) {
        d = Q;
        if (null !== d) {
          switch (g & -g) {
            case 4:
              e = 2;
              break;
            case 16:
              e = 8;
              break;
            case 64:
            case 128:
            case 256:
            case 512:
            case 1024:
            case 2048:
            case 4096:
            case 8192:
            case 16384:
            case 32768:
            case 65536:
            case 131072:
            case 262144:
            case 524288:
            case 1048576:
            case 2097152:
            case 4194304:
            case 8388608:
            case 16777216:
            case 33554432:
            case 67108864:
              e = 32;
              break;
            case 536870912:
              e = 268435456;
              break;
            default:
              e = 0;
          }
          e = 0 !== (e & (d.suspendedLanes | g)) ? 0 : e;
          0 !== e && e !== f.retryLane && (f.retryLane = e, ih(a, e), gi(d, a, e, -1));
        }
        tj();
        d = Ki(Error(p(421)));
        return sj(a, b, g, d);
      }
      if ("$?" === e.data) return b.flags |= 128, b.child = a.child, b = uj.bind(null, a), e._reactRetry = b, null;
      a = f.treeContext;
      yg = Lf(e.nextSibling);
      xg = b;
      I = true;
      zg = null;
      null !== a && (og[pg++] = rg, og[pg++] = sg, og[pg++] = qg, rg = a.id, sg = a.overflow, qg = b);
      b = qj(b, d.children);
      b.flags |= 4096;
      return b;
    }
    function vj(a, b, c) {
      a.lanes |= b;
      var d = a.alternate;
      null !== d && (d.lanes |= b);
      bh(a.return, b, c);
    }
    function wj(a, b, c, d, e) {
      var f = a.memoizedState;
      null === f ? a.memoizedState = { isBackwards: b, rendering: null, renderingStartTime: 0, last: d, tail: c, tailMode: e } : (f.isBackwards = b, f.rendering = null, f.renderingStartTime = 0, f.last = d, f.tail = c, f.tailMode = e);
    }
    function xj(a, b, c) {
      var d = b.pendingProps, e = d.revealOrder, f = d.tail;
      Xi(a, b, d.children, c);
      d = L.current;
      if (0 !== (d & 2)) d = d & 1 | 2, b.flags |= 128;
      else {
        if (null !== a && 0 !== (a.flags & 128)) a: for (a = b.child; null !== a; ) {
          if (13 === a.tag) null !== a.memoizedState && vj(a, c, b);
          else if (19 === a.tag) vj(a, c, b);
          else if (null !== a.child) {
            a.child.return = a;
            a = a.child;
            continue;
          }
          if (a === b) break a;
          for (; null === a.sibling; ) {
            if (null === a.return || a.return === b) break a;
            a = a.return;
          }
          a.sibling.return = a.return;
          a = a.sibling;
        }
        d &= 1;
      }
      G(L, d);
      if (0 === (b.mode & 1)) b.memoizedState = null;
      else switch (e) {
        case "forwards":
          c = b.child;
          for (e = null; null !== c; ) a = c.alternate, null !== a && null === Ch(a) && (e = c), c = c.sibling;
          c = e;
          null === c ? (e = b.child, b.child = null) : (e = c.sibling, c.sibling = null);
          wj(b, false, e, c, f);
          break;
        case "backwards":
          c = null;
          e = b.child;
          for (b.child = null; null !== e; ) {
            a = e.alternate;
            if (null !== a && null === Ch(a)) {
              b.child = e;
              break;
            }
            a = e.sibling;
            e.sibling = c;
            c = e;
            e = a;
          }
          wj(b, true, c, null, f);
          break;
        case "together":
          wj(b, false, null, null, void 0);
          break;
        default:
          b.memoizedState = null;
      }
      return b.child;
    }
    function ij(a, b) {
      0 === (b.mode & 1) && null !== a && (a.alternate = null, b.alternate = null, b.flags |= 2);
    }
    function Zi(a, b, c) {
      null !== a && (b.dependencies = a.dependencies);
      rh |= b.lanes;
      if (0 === (c & b.childLanes)) return null;
      if (null !== a && b.child !== a.child) throw Error(p(153));
      if (null !== b.child) {
        a = b.child;
        c = Pg(a, a.pendingProps);
        b.child = c;
        for (c.return = b; null !== a.sibling; ) a = a.sibling, c = c.sibling = Pg(a, a.pendingProps), c.return = b;
        c.sibling = null;
      }
      return b.child;
    }
    function yj(a, b, c) {
      switch (b.tag) {
        case 3:
          kj(b);
          Ig();
          break;
        case 5:
          Ah(b);
          break;
        case 1:
          Zf(b.type) && cg(b);
          break;
        case 4:
          yh(b, b.stateNode.containerInfo);
          break;
        case 10:
          var d = b.type._context, e = b.memoizedProps.value;
          G(Wg, d._currentValue);
          d._currentValue = e;
          break;
        case 13:
          d = b.memoizedState;
          if (null !== d) {
            if (null !== d.dehydrated) return G(L, L.current & 1), b.flags |= 128, null;
            if (0 !== (c & b.child.childLanes)) return oj(a, b, c);
            G(L, L.current & 1);
            a = Zi(a, b, c);
            return null !== a ? a.sibling : null;
          }
          G(L, L.current & 1);
          break;
        case 19:
          d = 0 !== (c & b.childLanes);
          if (0 !== (a.flags & 128)) {
            if (d) return xj(a, b, c);
            b.flags |= 128;
          }
          e = b.memoizedState;
          null !== e && (e.rendering = null, e.tail = null, e.lastEffect = null);
          G(L, L.current);
          if (d) break;
          else return null;
        case 22:
        case 23:
          return b.lanes = 0, dj(a, b, c);
      }
      return Zi(a, b, c);
    }
    var zj;
    var Aj;
    var Bj;
    var Cj;
    zj = function(a, b) {
      for (var c = b.child; null !== c; ) {
        if (5 === c.tag || 6 === c.tag) a.appendChild(c.stateNode);
        else if (4 !== c.tag && null !== c.child) {
          c.child.return = c;
          c = c.child;
          continue;
        }
        if (c === b) break;
        for (; null === c.sibling; ) {
          if (null === c.return || c.return === b) return;
          c = c.return;
        }
        c.sibling.return = c.return;
        c = c.sibling;
      }
    };
    Aj = function() {
    };
    Bj = function(a, b, c, d) {
      var e = a.memoizedProps;
      if (e !== d) {
        a = b.stateNode;
        xh(uh.current);
        var f = null;
        switch (c) {
          case "input":
            e = Ya(a, e);
            d = Ya(a, d);
            f = [];
            break;
          case "select":
            e = A({}, e, { value: void 0 });
            d = A({}, d, { value: void 0 });
            f = [];
            break;
          case "textarea":
            e = gb(a, e);
            d = gb(a, d);
            f = [];
            break;
          default:
            "function" !== typeof e.onClick && "function" === typeof d.onClick && (a.onclick = Bf);
        }
        ub(c, d);
        var g;
        c = null;
        for (l in e) if (!d.hasOwnProperty(l) && e.hasOwnProperty(l) && null != e[l]) if ("style" === l) {
          var h = e[l];
          for (g in h) h.hasOwnProperty(g) && (c || (c = {}), c[g] = "");
        } else "dangerouslySetInnerHTML" !== l && "children" !== l && "suppressContentEditableWarning" !== l && "suppressHydrationWarning" !== l && "autoFocus" !== l && (ea.hasOwnProperty(l) ? f || (f = []) : (f = f || []).push(l, null));
        for (l in d) {
          var k = d[l];
          h = null != e ? e[l] : void 0;
          if (d.hasOwnProperty(l) && k !== h && (null != k || null != h)) if ("style" === l) if (h) {
            for (g in h) !h.hasOwnProperty(g) || k && k.hasOwnProperty(g) || (c || (c = {}), c[g] = "");
            for (g in k) k.hasOwnProperty(g) && h[g] !== k[g] && (c || (c = {}), c[g] = k[g]);
          } else c || (f || (f = []), f.push(
            l,
            c
          )), c = k;
          else "dangerouslySetInnerHTML" === l ? (k = k ? k.__html : void 0, h = h ? h.__html : void 0, null != k && h !== k && (f = f || []).push(l, k)) : "children" === l ? "string" !== typeof k && "number" !== typeof k || (f = f || []).push(l, "" + k) : "suppressContentEditableWarning" !== l && "suppressHydrationWarning" !== l && (ea.hasOwnProperty(l) ? (null != k && "onScroll" === l && D("scroll", a), f || h === k || (f = [])) : (f = f || []).push(l, k));
        }
        c && (f = f || []).push("style", c);
        var l = f;
        if (b.updateQueue = l) b.flags |= 4;
      }
    };
    Cj = function(a, b, c, d) {
      c !== d && (b.flags |= 4);
    };
    function Dj(a, b) {
      if (!I) switch (a.tailMode) {
        case "hidden":
          b = a.tail;
          for (var c = null; null !== b; ) null !== b.alternate && (c = b), b = b.sibling;
          null === c ? a.tail = null : c.sibling = null;
          break;
        case "collapsed":
          c = a.tail;
          for (var d = null; null !== c; ) null !== c.alternate && (d = c), c = c.sibling;
          null === d ? b || null === a.tail ? a.tail = null : a.tail.sibling = null : d.sibling = null;
      }
    }
    function S2(a) {
      var b = null !== a.alternate && a.alternate.child === a.child, c = 0, d = 0;
      if (b) for (var e = a.child; null !== e; ) c |= e.lanes | e.childLanes, d |= e.subtreeFlags & 14680064, d |= e.flags & 14680064, e.return = a, e = e.sibling;
      else for (e = a.child; null !== e; ) c |= e.lanes | e.childLanes, d |= e.subtreeFlags, d |= e.flags, e.return = a, e = e.sibling;
      a.subtreeFlags |= d;
      a.childLanes = c;
      return b;
    }
    function Ej(a, b, c) {
      var d = b.pendingProps;
      wg(b);
      switch (b.tag) {
        case 2:
        case 16:
        case 15:
        case 0:
        case 11:
        case 7:
        case 8:
        case 12:
        case 9:
        case 14:
          return S2(b), null;
        case 1:
          return Zf(b.type) && $f(), S2(b), null;
        case 3:
          d = b.stateNode;
          zh();
          E(Wf);
          E(H);
          Eh();
          d.pendingContext && (d.context = d.pendingContext, d.pendingContext = null);
          if (null === a || null === a.child) Gg(b) ? b.flags |= 4 : null === a || a.memoizedState.isDehydrated && 0 === (b.flags & 256) || (b.flags |= 1024, null !== zg && (Fj(zg), zg = null));
          Aj(a, b);
          S2(b);
          return null;
        case 5:
          Bh(b);
          var e = xh(wh.current);
          c = b.type;
          if (null !== a && null != b.stateNode) Bj(a, b, c, d, e), a.ref !== b.ref && (b.flags |= 512, b.flags |= 2097152);
          else {
            if (!d) {
              if (null === b.stateNode) throw Error(p(166));
              S2(b);
              return null;
            }
            a = xh(uh.current);
            if (Gg(b)) {
              d = b.stateNode;
              c = b.type;
              var f = b.memoizedProps;
              d[Of] = b;
              d[Pf] = f;
              a = 0 !== (b.mode & 1);
              switch (c) {
                case "dialog":
                  D("cancel", d);
                  D("close", d);
                  break;
                case "iframe":
                case "object":
                case "embed":
                  D("load", d);
                  break;
                case "video":
                case "audio":
                  for (e = 0; e < lf.length; e++) D(lf[e], d);
                  break;
                case "source":
                  D("error", d);
                  break;
                case "img":
                case "image":
                case "link":
                  D(
                    "error",
                    d
                  );
                  D("load", d);
                  break;
                case "details":
                  D("toggle", d);
                  break;
                case "input":
                  Za(d, f);
                  D("invalid", d);
                  break;
                case "select":
                  d._wrapperState = { wasMultiple: !!f.multiple };
                  D("invalid", d);
                  break;
                case "textarea":
                  hb(d, f), D("invalid", d);
              }
              ub(c, f);
              e = null;
              for (var g in f) if (f.hasOwnProperty(g)) {
                var h = f[g];
                "children" === g ? "string" === typeof h ? d.textContent !== h && (true !== f.suppressHydrationWarning && Af(d.textContent, h, a), e = ["children", h]) : "number" === typeof h && d.textContent !== "" + h && (true !== f.suppressHydrationWarning && Af(
                  d.textContent,
                  h,
                  a
                ), e = ["children", "" + h]) : ea.hasOwnProperty(g) && null != h && "onScroll" === g && D("scroll", d);
              }
              switch (c) {
                case "input":
                  Va(d);
                  db(d, f, true);
                  break;
                case "textarea":
                  Va(d);
                  jb(d);
                  break;
                case "select":
                case "option":
                  break;
                default:
                  "function" === typeof f.onClick && (d.onclick = Bf);
              }
              d = e;
              b.updateQueue = d;
              null !== d && (b.flags |= 4);
            } else {
              g = 9 === e.nodeType ? e : e.ownerDocument;
              "http://www.w3.org/1999/xhtml" === a && (a = kb(c));
              "http://www.w3.org/1999/xhtml" === a ? "script" === c ? (a = g.createElement("div"), a.innerHTML = "<script><\/script>", a = a.removeChild(a.firstChild)) : "string" === typeof d.is ? a = g.createElement(c, { is: d.is }) : (a = g.createElement(c), "select" === c && (g = a, d.multiple ? g.multiple = true : d.size && (g.size = d.size))) : a = g.createElementNS(a, c);
              a[Of] = b;
              a[Pf] = d;
              zj(a, b, false, false);
              b.stateNode = a;
              a: {
                g = vb(c, d);
                switch (c) {
                  case "dialog":
                    D("cancel", a);
                    D("close", a);
                    e = d;
                    break;
                  case "iframe":
                  case "object":
                  case "embed":
                    D("load", a);
                    e = d;
                    break;
                  case "video":
                  case "audio":
                    for (e = 0; e < lf.length; e++) D(lf[e], a);
                    e = d;
                    break;
                  case "source":
                    D("error", a);
                    e = d;
                    break;
                  case "img":
                  case "image":
                  case "link":
                    D(
                      "error",
                      a
                    );
                    D("load", a);
                    e = d;
                    break;
                  case "details":
                    D("toggle", a);
                    e = d;
                    break;
                  case "input":
                    Za(a, d);
                    e = Ya(a, d);
                    D("invalid", a);
                    break;
                  case "option":
                    e = d;
                    break;
                  case "select":
                    a._wrapperState = { wasMultiple: !!d.multiple };
                    e = A({}, d, { value: void 0 });
                    D("invalid", a);
                    break;
                  case "textarea":
                    hb(a, d);
                    e = gb(a, d);
                    D("invalid", a);
                    break;
                  default:
                    e = d;
                }
                ub(c, e);
                h = e;
                for (f in h) if (h.hasOwnProperty(f)) {
                  var k = h[f];
                  "style" === f ? sb(a, k) : "dangerouslySetInnerHTML" === f ? (k = k ? k.__html : void 0, null != k && nb(a, k)) : "children" === f ? "string" === typeof k ? ("textarea" !== c || "" !== k) && ob(a, k) : "number" === typeof k && ob(a, "" + k) : "suppressContentEditableWarning" !== f && "suppressHydrationWarning" !== f && "autoFocus" !== f && (ea.hasOwnProperty(f) ? null != k && "onScroll" === f && D("scroll", a) : null != k && ta(a, f, k, g));
                }
                switch (c) {
                  case "input":
                    Va(a);
                    db(a, d, false);
                    break;
                  case "textarea":
                    Va(a);
                    jb(a);
                    break;
                  case "option":
                    null != d.value && a.setAttribute("value", "" + Sa(d.value));
                    break;
                  case "select":
                    a.multiple = !!d.multiple;
                    f = d.value;
                    null != f ? fb(a, !!d.multiple, f, false) : null != d.defaultValue && fb(
                      a,
                      !!d.multiple,
                      d.defaultValue,
                      true
                    );
                    break;
                  default:
                    "function" === typeof e.onClick && (a.onclick = Bf);
                }
                switch (c) {
                  case "button":
                  case "input":
                  case "select":
                  case "textarea":
                    d = !!d.autoFocus;
                    break a;
                  case "img":
                    d = true;
                    break a;
                  default:
                    d = false;
                }
              }
              d && (b.flags |= 4);
            }
            null !== b.ref && (b.flags |= 512, b.flags |= 2097152);
          }
          S2(b);
          return null;
        case 6:
          if (a && null != b.stateNode) Cj(a, b, a.memoizedProps, d);
          else {
            if ("string" !== typeof d && null === b.stateNode) throw Error(p(166));
            c = xh(wh.current);
            xh(uh.current);
            if (Gg(b)) {
              d = b.stateNode;
              c = b.memoizedProps;
              d[Of] = b;
              if (f = d.nodeValue !== c) {
                if (a = xg, null !== a) switch (a.tag) {
                  case 3:
                    Af(d.nodeValue, c, 0 !== (a.mode & 1));
                    break;
                  case 5:
                    true !== a.memoizedProps.suppressHydrationWarning && Af(d.nodeValue, c, 0 !== (a.mode & 1));
                }
              }
              f && (b.flags |= 4);
            } else d = (9 === c.nodeType ? c : c.ownerDocument).createTextNode(d), d[Of] = b, b.stateNode = d;
          }
          S2(b);
          return null;
        case 13:
          E(L);
          d = b.memoizedState;
          if (null === a || null !== a.memoizedState && null !== a.memoizedState.dehydrated) {
            if (I && null !== yg && 0 !== (b.mode & 1) && 0 === (b.flags & 128)) Hg(), Ig(), b.flags |= 98560, f = false;
            else if (f = Gg(b), null !== d && null !== d.dehydrated) {
              if (null === a) {
                if (!f) throw Error(p(318));
                f = b.memoizedState;
                f = null !== f ? f.dehydrated : null;
                if (!f) throw Error(p(317));
                f[Of] = b;
              } else Ig(), 0 === (b.flags & 128) && (b.memoizedState = null), b.flags |= 4;
              S2(b);
              f = false;
            } else null !== zg && (Fj(zg), zg = null), f = true;
            if (!f) return b.flags & 65536 ? b : null;
          }
          if (0 !== (b.flags & 128)) return b.lanes = c, b;
          d = null !== d;
          d !== (null !== a && null !== a.memoizedState) && d && (b.child.flags |= 8192, 0 !== (b.mode & 1) && (null === a || 0 !== (L.current & 1) ? 0 === T && (T = 3) : tj()));
          null !== b.updateQueue && (b.flags |= 4);
          S2(b);
          return null;
        case 4:
          return zh(), Aj(a, b), null === a && sf(b.stateNode.containerInfo), S2(b), null;
        case 10:
          return ah(b.type._context), S2(b), null;
        case 17:
          return Zf(b.type) && $f(), S2(b), null;
        case 19:
          E(L);
          f = b.memoizedState;
          if (null === f) return S2(b), null;
          d = 0 !== (b.flags & 128);
          g = f.rendering;
          if (null === g) if (d) Dj(f, false);
          else {
            if (0 !== T || null !== a && 0 !== (a.flags & 128)) for (a = b.child; null !== a; ) {
              g = Ch(a);
              if (null !== g) {
                b.flags |= 128;
                Dj(f, false);
                d = g.updateQueue;
                null !== d && (b.updateQueue = d, b.flags |= 4);
                b.subtreeFlags = 0;
                d = c;
                for (c = b.child; null !== c; ) f = c, a = d, f.flags &= 14680066, g = f.alternate, null === g ? (f.childLanes = 0, f.lanes = a, f.child = null, f.subtreeFlags = 0, f.memoizedProps = null, f.memoizedState = null, f.updateQueue = null, f.dependencies = null, f.stateNode = null) : (f.childLanes = g.childLanes, f.lanes = g.lanes, f.child = g.child, f.subtreeFlags = 0, f.deletions = null, f.memoizedProps = g.memoizedProps, f.memoizedState = g.memoizedState, f.updateQueue = g.updateQueue, f.type = g.type, a = g.dependencies, f.dependencies = null === a ? null : { lanes: a.lanes, firstContext: a.firstContext }), c = c.sibling;
                G(L, L.current & 1 | 2);
                return b.child;
              }
              a = a.sibling;
            }
            null !== f.tail && B2() > Gj && (b.flags |= 128, d = true, Dj(f, false), b.lanes = 4194304);
          }
          else {
            if (!d) if (a = Ch(g), null !== a) {
              if (b.flags |= 128, d = true, c = a.updateQueue, null !== c && (b.updateQueue = c, b.flags |= 4), Dj(f, true), null === f.tail && "hidden" === f.tailMode && !g.alternate && !I) return S2(b), null;
            } else 2 * B2() - f.renderingStartTime > Gj && 1073741824 !== c && (b.flags |= 128, d = true, Dj(f, false), b.lanes = 4194304);
            f.isBackwards ? (g.sibling = b.child, b.child = g) : (c = f.last, null !== c ? c.sibling = g : b.child = g, f.last = g);
          }
          if (null !== f.tail) return b = f.tail, f.rendering = b, f.tail = b.sibling, f.renderingStartTime = B2(), b.sibling = null, c = L.current, G(L, d ? c & 1 | 2 : c & 1), b;
          S2(b);
          return null;
        case 22:
        case 23:
          return Hj(), d = null !== b.memoizedState, null !== a && null !== a.memoizedState !== d && (b.flags |= 8192), d && 0 !== (b.mode & 1) ? 0 !== (fj & 1073741824) && (S2(b), b.subtreeFlags & 6 && (b.flags |= 8192)) : S2(b), null;
        case 24:
          return null;
        case 25:
          return null;
      }
      throw Error(p(156, b.tag));
    }
    function Ij(a, b) {
      wg(b);
      switch (b.tag) {
        case 1:
          return Zf(b.type) && $f(), a = b.flags, a & 65536 ? (b.flags = a & -65537 | 128, b) : null;
        case 3:
          return zh(), E(Wf), E(H), Eh(), a = b.flags, 0 !== (a & 65536) && 0 === (a & 128) ? (b.flags = a & -65537 | 128, b) : null;
        case 5:
          return Bh(b), null;
        case 13:
          E(L);
          a = b.memoizedState;
          if (null !== a && null !== a.dehydrated) {
            if (null === b.alternate) throw Error(p(340));
            Ig();
          }
          a = b.flags;
          return a & 65536 ? (b.flags = a & -65537 | 128, b) : null;
        case 19:
          return E(L), null;
        case 4:
          return zh(), null;
        case 10:
          return ah(b.type._context), null;
        case 22:
        case 23:
          return Hj(), null;
        case 24:
          return null;
        default:
          return null;
      }
    }
    var Jj = false;
    var U = false;
    var Kj = "function" === typeof WeakSet ? WeakSet : Set;
    var V = null;
    function Lj(a, b) {
      var c = a.ref;
      if (null !== c) if ("function" === typeof c) try {
        c(null);
      } catch (d) {
        W(a, b, d);
      }
      else c.current = null;
    }
    function Mj(a, b, c) {
      try {
        c();
      } catch (d) {
        W(a, b, d);
      }
    }
    var Nj = false;
    function Oj(a, b) {
      Cf = dd;
      a = Me();
      if (Ne(a)) {
        if ("selectionStart" in a) var c = { start: a.selectionStart, end: a.selectionEnd };
        else a: {
          c = (c = a.ownerDocument) && c.defaultView || window;
          var d = c.getSelection && c.getSelection();
          if (d && 0 !== d.rangeCount) {
            c = d.anchorNode;
            var e = d.anchorOffset, f = d.focusNode;
            d = d.focusOffset;
            try {
              c.nodeType, f.nodeType;
            } catch (F) {
              c = null;
              break a;
            }
            var g = 0, h = -1, k = -1, l = 0, m = 0, q = a, r2 = null;
            b: for (; ; ) {
              for (var y; ; ) {
                q !== c || 0 !== e && 3 !== q.nodeType || (h = g + e);
                q !== f || 0 !== d && 3 !== q.nodeType || (k = g + d);
                3 === q.nodeType && (g += q.nodeValue.length);
                if (null === (y = q.firstChild)) break;
                r2 = q;
                q = y;
              }
              for (; ; ) {
                if (q === a) break b;
                r2 === c && ++l === e && (h = g);
                r2 === f && ++m === d && (k = g);
                if (null !== (y = q.nextSibling)) break;
                q = r2;
                r2 = q.parentNode;
              }
              q = y;
            }
            c = -1 === h || -1 === k ? null : { start: h, end: k };
          } else c = null;
        }
        c = c || { start: 0, end: 0 };
      } else c = null;
      Df = { focusedElem: a, selectionRange: c };
      dd = false;
      for (V = b; null !== V; ) if (b = V, a = b.child, 0 !== (b.subtreeFlags & 1028) && null !== a) a.return = b, V = a;
      else for (; null !== V; ) {
        b = V;
        try {
          var n = b.alternate;
          if (0 !== (b.flags & 1024)) switch (b.tag) {
            case 0:
            case 11:
            case 15:
              break;
            case 1:
              if (null !== n) {
                var t = n.memoizedProps, J = n.memoizedState, x = b.stateNode, w = x.getSnapshotBeforeUpdate(b.elementType === b.type ? t : Ci(b.type, t), J);
                x.__reactInternalSnapshotBeforeUpdate = w;
              }
              break;
            case 3:
              var u = b.stateNode.containerInfo;
              1 === u.nodeType ? u.textContent = "" : 9 === u.nodeType && u.documentElement && u.removeChild(u.documentElement);
              break;
            case 5:
            case 6:
            case 4:
            case 17:
              break;
            default:
              throw Error(p(163));
          }
        } catch (F) {
          W(b, b.return, F);
        }
        a = b.sibling;
        if (null !== a) {
          a.return = b.return;
          V = a;
          break;
        }
        V = b.return;
      }
      n = Nj;
      Nj = false;
      return n;
    }
    function Pj(a, b, c) {
      var d = b.updateQueue;
      d = null !== d ? d.lastEffect : null;
      if (null !== d) {
        var e = d = d.next;
        do {
          if ((e.tag & a) === a) {
            var f = e.destroy;
            e.destroy = void 0;
            void 0 !== f && Mj(b, c, f);
          }
          e = e.next;
        } while (e !== d);
      }
    }
    function Qj(a, b) {
      b = b.updateQueue;
      b = null !== b ? b.lastEffect : null;
      if (null !== b) {
        var c = b = b.next;
        do {
          if ((c.tag & a) === a) {
            var d = c.create;
            c.destroy = d();
          }
          c = c.next;
        } while (c !== b);
      }
    }
    function Rj(a) {
      var b = a.ref;
      if (null !== b) {
        var c = a.stateNode;
        switch (a.tag) {
          case 5:
            a = c;
            break;
          default:
            a = c;
        }
        "function" === typeof b ? b(a) : b.current = a;
      }
    }
    function Sj(a) {
      var b = a.alternate;
      null !== b && (a.alternate = null, Sj(b));
      a.child = null;
      a.deletions = null;
      a.sibling = null;
      5 === a.tag && (b = a.stateNode, null !== b && (delete b[Of], delete b[Pf], delete b[of], delete b[Qf], delete b[Rf]));
      a.stateNode = null;
      a.return = null;
      a.dependencies = null;
      a.memoizedProps = null;
      a.memoizedState = null;
      a.pendingProps = null;
      a.stateNode = null;
      a.updateQueue = null;
    }
    function Tj(a) {
      return 5 === a.tag || 3 === a.tag || 4 === a.tag;
    }
    function Uj(a) {
      a: for (; ; ) {
        for (; null === a.sibling; ) {
          if (null === a.return || Tj(a.return)) return null;
          a = a.return;
        }
        a.sibling.return = a.return;
        for (a = a.sibling; 5 !== a.tag && 6 !== a.tag && 18 !== a.tag; ) {
          if (a.flags & 2) continue a;
          if (null === a.child || 4 === a.tag) continue a;
          else a.child.return = a, a = a.child;
        }
        if (!(a.flags & 2)) return a.stateNode;
      }
    }
    function Vj(a, b, c) {
      var d = a.tag;
      if (5 === d || 6 === d) a = a.stateNode, b ? 8 === c.nodeType ? c.parentNode.insertBefore(a, b) : c.insertBefore(a, b) : (8 === c.nodeType ? (b = c.parentNode, b.insertBefore(a, c)) : (b = c, b.appendChild(a)), c = c._reactRootContainer, null !== c && void 0 !== c || null !== b.onclick || (b.onclick = Bf));
      else if (4 !== d && (a = a.child, null !== a)) for (Vj(a, b, c), a = a.sibling; null !== a; ) Vj(a, b, c), a = a.sibling;
    }
    function Wj(a, b, c) {
      var d = a.tag;
      if (5 === d || 6 === d) a = a.stateNode, b ? c.insertBefore(a, b) : c.appendChild(a);
      else if (4 !== d && (a = a.child, null !== a)) for (Wj(a, b, c), a = a.sibling; null !== a; ) Wj(a, b, c), a = a.sibling;
    }
    var X2 = null;
    var Xj = false;
    function Yj(a, b, c) {
      for (c = c.child; null !== c; ) Zj(a, b, c), c = c.sibling;
    }
    function Zj(a, b, c) {
      if (lc && "function" === typeof lc.onCommitFiberUnmount) try {
        lc.onCommitFiberUnmount(kc, c);
      } catch (h) {
      }
      switch (c.tag) {
        case 5:
          U || Lj(c, b);
        case 6:
          var d = X2, e = Xj;
          X2 = null;
          Yj(a, b, c);
          X2 = d;
          Xj = e;
          null !== X2 && (Xj ? (a = X2, c = c.stateNode, 8 === a.nodeType ? a.parentNode.removeChild(c) : a.removeChild(c)) : X2.removeChild(c.stateNode));
          break;
        case 18:
          null !== X2 && (Xj ? (a = X2, c = c.stateNode, 8 === a.nodeType ? Kf(a.parentNode, c) : 1 === a.nodeType && Kf(a, c), bd(a)) : Kf(X2, c.stateNode));
          break;
        case 4:
          d = X2;
          e = Xj;
          X2 = c.stateNode.containerInfo;
          Xj = true;
          Yj(a, b, c);
          X2 = d;
          Xj = e;
          break;
        case 0:
        case 11:
        case 14:
        case 15:
          if (!U && (d = c.updateQueue, null !== d && (d = d.lastEffect, null !== d))) {
            e = d = d.next;
            do {
              var f = e, g = f.destroy;
              f = f.tag;
              void 0 !== g && (0 !== (f & 2) ? Mj(c, b, g) : 0 !== (f & 4) && Mj(c, b, g));
              e = e.next;
            } while (e !== d);
          }
          Yj(a, b, c);
          break;
        case 1:
          if (!U && (Lj(c, b), d = c.stateNode, "function" === typeof d.componentWillUnmount)) try {
            d.props = c.memoizedProps, d.state = c.memoizedState, d.componentWillUnmount();
          } catch (h) {
            W(c, b, h);
          }
          Yj(a, b, c);
          break;
        case 21:
          Yj(a, b, c);
          break;
        case 22:
          c.mode & 1 ? (U = (d = U) || null !== c.memoizedState, Yj(a, b, c), U = d) : Yj(a, b, c);
          break;
        default:
          Yj(a, b, c);
      }
    }
    function ak(a) {
      var b = a.updateQueue;
      if (null !== b) {
        a.updateQueue = null;
        var c = a.stateNode;
        null === c && (c = a.stateNode = new Kj());
        b.forEach(function(b2) {
          var d = bk.bind(null, a, b2);
          c.has(b2) || (c.add(b2), b2.then(d, d));
        });
      }
    }
    function ck(a, b) {
      var c = b.deletions;
      if (null !== c) for (var d = 0; d < c.length; d++) {
        var e = c[d];
        try {
          var f = a, g = b, h = g;
          a: for (; null !== h; ) {
            switch (h.tag) {
              case 5:
                X2 = h.stateNode;
                Xj = false;
                break a;
              case 3:
                X2 = h.stateNode.containerInfo;
                Xj = true;
                break a;
              case 4:
                X2 = h.stateNode.containerInfo;
                Xj = true;
                break a;
            }
            h = h.return;
          }
          if (null === X2) throw Error(p(160));
          Zj(f, g, e);
          X2 = null;
          Xj = false;
          var k = e.alternate;
          null !== k && (k.return = null);
          e.return = null;
        } catch (l) {
          W(e, b, l);
        }
      }
      if (b.subtreeFlags & 12854) for (b = b.child; null !== b; ) dk(b, a), b = b.sibling;
    }
    function dk(a, b) {
      var c = a.alternate, d = a.flags;
      switch (a.tag) {
        case 0:
        case 11:
        case 14:
        case 15:
          ck(b, a);
          ek(a);
          if (d & 4) {
            try {
              Pj(3, a, a.return), Qj(3, a);
            } catch (t) {
              W(a, a.return, t);
            }
            try {
              Pj(5, a, a.return);
            } catch (t) {
              W(a, a.return, t);
            }
          }
          break;
        case 1:
          ck(b, a);
          ek(a);
          d & 512 && null !== c && Lj(c, c.return);
          break;
        case 5:
          ck(b, a);
          ek(a);
          d & 512 && null !== c && Lj(c, c.return);
          if (a.flags & 32) {
            var e = a.stateNode;
            try {
              ob(e, "");
            } catch (t) {
              W(a, a.return, t);
            }
          }
          if (d & 4 && (e = a.stateNode, null != e)) {
            var f = a.memoizedProps, g = null !== c ? c.memoizedProps : f, h = a.type, k = a.updateQueue;
            a.updateQueue = null;
            if (null !== k) try {
              "input" === h && "radio" === f.type && null != f.name && ab(e, f);
              vb(h, g);
              var l = vb(h, f);
              for (g = 0; g < k.length; g += 2) {
                var m = k[g], q = k[g + 1];
                "style" === m ? sb(e, q) : "dangerouslySetInnerHTML" === m ? nb(e, q) : "children" === m ? ob(e, q) : ta(e, m, q, l);
              }
              switch (h) {
                case "input":
                  bb(e, f);
                  break;
                case "textarea":
                  ib(e, f);
                  break;
                case "select":
                  var r2 = e._wrapperState.wasMultiple;
                  e._wrapperState.wasMultiple = !!f.multiple;
                  var y = f.value;
                  null != y ? fb(e, !!f.multiple, y, false) : r2 !== !!f.multiple && (null != f.defaultValue ? fb(
                    e,
                    !!f.multiple,
                    f.defaultValue,
                    true
                  ) : fb(e, !!f.multiple, f.multiple ? [] : "", false));
              }
              e[Pf] = f;
            } catch (t) {
              W(a, a.return, t);
            }
          }
          break;
        case 6:
          ck(b, a);
          ek(a);
          if (d & 4) {
            if (null === a.stateNode) throw Error(p(162));
            e = a.stateNode;
            f = a.memoizedProps;
            try {
              e.nodeValue = f;
            } catch (t) {
              W(a, a.return, t);
            }
          }
          break;
        case 3:
          ck(b, a);
          ek(a);
          if (d & 4 && null !== c && c.memoizedState.isDehydrated) try {
            bd(b.containerInfo);
          } catch (t) {
            W(a, a.return, t);
          }
          break;
        case 4:
          ck(b, a);
          ek(a);
          break;
        case 13:
          ck(b, a);
          ek(a);
          e = a.child;
          e.flags & 8192 && (f = null !== e.memoizedState, e.stateNode.isHidden = f, !f || null !== e.alternate && null !== e.alternate.memoizedState || (fk = B2()));
          d & 4 && ak(a);
          break;
        case 22:
          m = null !== c && null !== c.memoizedState;
          a.mode & 1 ? (U = (l = U) || m, ck(b, a), U = l) : ck(b, a);
          ek(a);
          if (d & 8192) {
            l = null !== a.memoizedState;
            if ((a.stateNode.isHidden = l) && !m && 0 !== (a.mode & 1)) for (V = a, m = a.child; null !== m; ) {
              for (q = V = m; null !== V; ) {
                r2 = V;
                y = r2.child;
                switch (r2.tag) {
                  case 0:
                  case 11:
                  case 14:
                  case 15:
                    Pj(4, r2, r2.return);
                    break;
                  case 1:
                    Lj(r2, r2.return);
                    var n = r2.stateNode;
                    if ("function" === typeof n.componentWillUnmount) {
                      d = r2;
                      c = r2.return;
                      try {
                        b = d, n.props = b.memoizedProps, n.state = b.memoizedState, n.componentWillUnmount();
                      } catch (t) {
                        W(d, c, t);
                      }
                    }
                    break;
                  case 5:
                    Lj(r2, r2.return);
                    break;
                  case 22:
                    if (null !== r2.memoizedState) {
                      gk(q);
                      continue;
                    }
                }
                null !== y ? (y.return = r2, V = y) : gk(q);
              }
              m = m.sibling;
            }
            a: for (m = null, q = a; ; ) {
              if (5 === q.tag) {
                if (null === m) {
                  m = q;
                  try {
                    e = q.stateNode, l ? (f = e.style, "function" === typeof f.setProperty ? f.setProperty("display", "none", "important") : f.display = "none") : (h = q.stateNode, k = q.memoizedProps.style, g = void 0 !== k && null !== k && k.hasOwnProperty("display") ? k.display : null, h.style.display = rb("display", g));
                  } catch (t) {
                    W(a, a.return, t);
                  }
                }
              } else if (6 === q.tag) {
                if (null === m) try {
                  q.stateNode.nodeValue = l ? "" : q.memoizedProps;
                } catch (t) {
                  W(a, a.return, t);
                }
              } else if ((22 !== q.tag && 23 !== q.tag || null === q.memoizedState || q === a) && null !== q.child) {
                q.child.return = q;
                q = q.child;
                continue;
              }
              if (q === a) break a;
              for (; null === q.sibling; ) {
                if (null === q.return || q.return === a) break a;
                m === q && (m = null);
                q = q.return;
              }
              m === q && (m = null);
              q.sibling.return = q.return;
              q = q.sibling;
            }
          }
          break;
        case 19:
          ck(b, a);
          ek(a);
          d & 4 && ak(a);
          break;
        case 21:
          break;
        default:
          ck(
            b,
            a
          ), ek(a);
      }
    }
    function ek(a) {
      var b = a.flags;
      if (b & 2) {
        try {
          a: {
            for (var c = a.return; null !== c; ) {
              if (Tj(c)) {
                var d = c;
                break a;
              }
              c = c.return;
            }
            throw Error(p(160));
          }
          switch (d.tag) {
            case 5:
              var e = d.stateNode;
              d.flags & 32 && (ob(e, ""), d.flags &= -33);
              var f = Uj(a);
              Wj(a, f, e);
              break;
            case 3:
            case 4:
              var g = d.stateNode.containerInfo, h = Uj(a);
              Vj(a, h, g);
              break;
            default:
              throw Error(p(161));
          }
        } catch (k) {
          W(a, a.return, k);
        }
        a.flags &= -3;
      }
      b & 4096 && (a.flags &= -4097);
    }
    function hk(a, b, c) {
      V = a;
      ik(a, b, c);
    }
    function ik(a, b, c) {
      for (var d = 0 !== (a.mode & 1); null !== V; ) {
        var e = V, f = e.child;
        if (22 === e.tag && d) {
          var g = null !== e.memoizedState || Jj;
          if (!g) {
            var h = e.alternate, k = null !== h && null !== h.memoizedState || U;
            h = Jj;
            var l = U;
            Jj = g;
            if ((U = k) && !l) for (V = e; null !== V; ) g = V, k = g.child, 22 === g.tag && null !== g.memoizedState ? jk(e) : null !== k ? (k.return = g, V = k) : jk(e);
            for (; null !== f; ) V = f, ik(f, b, c), f = f.sibling;
            V = e;
            Jj = h;
            U = l;
          }
          kk(a, b, c);
        } else 0 !== (e.subtreeFlags & 8772) && null !== f ? (f.return = e, V = f) : kk(a, b, c);
      }
    }
    function kk(a) {
      for (; null !== V; ) {
        var b = V;
        if (0 !== (b.flags & 8772)) {
          var c = b.alternate;
          try {
            if (0 !== (b.flags & 8772)) switch (b.tag) {
              case 0:
              case 11:
              case 15:
                U || Qj(5, b);
                break;
              case 1:
                var d = b.stateNode;
                if (b.flags & 4 && !U) if (null === c) d.componentDidMount();
                else {
                  var e = b.elementType === b.type ? c.memoizedProps : Ci(b.type, c.memoizedProps);
                  d.componentDidUpdate(e, c.memoizedState, d.__reactInternalSnapshotBeforeUpdate);
                }
                var f = b.updateQueue;
                null !== f && sh(b, f, d);
                break;
              case 3:
                var g = b.updateQueue;
                if (null !== g) {
                  c = null;
                  if (null !== b.child) switch (b.child.tag) {
                    case 5:
                      c = b.child.stateNode;
                      break;
                    case 1:
                      c = b.child.stateNode;
                  }
                  sh(b, g, c);
                }
                break;
              case 5:
                var h = b.stateNode;
                if (null === c && b.flags & 4) {
                  c = h;
                  var k = b.memoizedProps;
                  switch (b.type) {
                    case "button":
                    case "input":
                    case "select":
                    case "textarea":
                      k.autoFocus && c.focus();
                      break;
                    case "img":
                      k.src && (c.src = k.src);
                  }
                }
                break;
              case 6:
                break;
              case 4:
                break;
              case 12:
                break;
              case 13:
                if (null === b.memoizedState) {
                  var l = b.alternate;
                  if (null !== l) {
                    var m = l.memoizedState;
                    if (null !== m) {
                      var q = m.dehydrated;
                      null !== q && bd(q);
                    }
                  }
                }
                break;
              case 19:
              case 17:
              case 21:
              case 22:
              case 23:
              case 25:
                break;
              default:
                throw Error(p(163));
            }
            U || b.flags & 512 && Rj(b);
          } catch (r2) {
            W(b, b.return, r2);
          }
        }
        if (b === a) {
          V = null;
          break;
        }
        c = b.sibling;
        if (null !== c) {
          c.return = b.return;
          V = c;
          break;
        }
        V = b.return;
      }
    }
    function gk(a) {
      for (; null !== V; ) {
        var b = V;
        if (b === a) {
          V = null;
          break;
        }
        var c = b.sibling;
        if (null !== c) {
          c.return = b.return;
          V = c;
          break;
        }
        V = b.return;
      }
    }
    function jk(a) {
      for (; null !== V; ) {
        var b = V;
        try {
          switch (b.tag) {
            case 0:
            case 11:
            case 15:
              var c = b.return;
              try {
                Qj(4, b);
              } catch (k) {
                W(b, c, k);
              }
              break;
            case 1:
              var d = b.stateNode;
              if ("function" === typeof d.componentDidMount) {
                var e = b.return;
                try {
                  d.componentDidMount();
                } catch (k) {
                  W(b, e, k);
                }
              }
              var f = b.return;
              try {
                Rj(b);
              } catch (k) {
                W(b, f, k);
              }
              break;
            case 5:
              var g = b.return;
              try {
                Rj(b);
              } catch (k) {
                W(b, g, k);
              }
          }
        } catch (k) {
          W(b, b.return, k);
        }
        if (b === a) {
          V = null;
          break;
        }
        var h = b.sibling;
        if (null !== h) {
          h.return = b.return;
          V = h;
          break;
        }
        V = b.return;
      }
    }
    var lk = Math.ceil;
    var mk = ua.ReactCurrentDispatcher;
    var nk = ua.ReactCurrentOwner;
    var ok = ua.ReactCurrentBatchConfig;
    var K = 0;
    var Q = null;
    var Y = null;
    var Z = 0;
    var fj = 0;
    var ej = Uf(0);
    var T = 0;
    var pk = null;
    var rh = 0;
    var qk = 0;
    var rk = 0;
    var sk = null;
    var tk = null;
    var fk = 0;
    var Gj = Infinity;
    var uk = null;
    var Oi = false;
    var Pi = null;
    var Ri = null;
    var vk = false;
    var wk = null;
    var xk = 0;
    var yk = 0;
    var zk = null;
    var Ak = -1;
    var Bk = 0;
    function R2() {
      return 0 !== (K & 6) ? B2() : -1 !== Ak ? Ak : Ak = B2();
    }
    function yi(a) {
      if (0 === (a.mode & 1)) return 1;
      if (0 !== (K & 2) && 0 !== Z) return Z & -Z;
      if (null !== Kg.transition) return 0 === Bk && (Bk = yc()), Bk;
      a = C2;
      if (0 !== a) return a;
      a = window.event;
      a = void 0 === a ? 16 : jd(a.type);
      return a;
    }
    function gi(a, b, c, d) {
      if (50 < yk) throw yk = 0, zk = null, Error(p(185));
      Ac(a, c, d);
      if (0 === (K & 2) || a !== Q) a === Q && (0 === (K & 2) && (qk |= c), 4 === T && Ck(a, Z)), Dk(a, d), 1 === c && 0 === K && 0 === (b.mode & 1) && (Gj = B2() + 500, fg && jg());
    }
    function Dk(a, b) {
      var c = a.callbackNode;
      wc(a, b);
      var d = uc(a, a === Q ? Z : 0);
      if (0 === d) null !== c && bc(c), a.callbackNode = null, a.callbackPriority = 0;
      else if (b = d & -d, a.callbackPriority !== b) {
        null != c && bc(c);
        if (1 === b) 0 === a.tag ? ig(Ek.bind(null, a)) : hg(Ek.bind(null, a)), Jf(function() {
          0 === (K & 6) && jg();
        }), c = null;
        else {
          switch (Dc(d)) {
            case 1:
              c = fc;
              break;
            case 4:
              c = gc;
              break;
            case 16:
              c = hc;
              break;
            case 536870912:
              c = jc;
              break;
            default:
              c = hc;
          }
          c = Fk(c, Gk.bind(null, a));
        }
        a.callbackPriority = b;
        a.callbackNode = c;
      }
    }
    function Gk(a, b) {
      Ak = -1;
      Bk = 0;
      if (0 !== (K & 6)) throw Error(p(327));
      var c = a.callbackNode;
      if (Hk() && a.callbackNode !== c) return null;
      var d = uc(a, a === Q ? Z : 0);
      if (0 === d) return null;
      if (0 !== (d & 30) || 0 !== (d & a.expiredLanes) || b) b = Ik(a, d);
      else {
        b = d;
        var e = K;
        K |= 2;
        var f = Jk();
        if (Q !== a || Z !== b) uk = null, Gj = B2() + 500, Kk(a, b);
        do
          try {
            Lk();
            break;
          } catch (h) {
            Mk(a, h);
          }
        while (1);
        $g();
        mk.current = f;
        K = e;
        null !== Y ? b = 0 : (Q = null, Z = 0, b = T);
      }
      if (0 !== b) {
        2 === b && (e = xc(a), 0 !== e && (d = e, b = Nk(a, e)));
        if (1 === b) throw c = pk, Kk(a, 0), Ck(a, d), Dk(a, B2()), c;
        if (6 === b) Ck(a, d);
        else {
          e = a.current.alternate;
          if (0 === (d & 30) && !Ok(e) && (b = Ik(a, d), 2 === b && (f = xc(a), 0 !== f && (d = f, b = Nk(a, f))), 1 === b)) throw c = pk, Kk(a, 0), Ck(a, d), Dk(a, B2()), c;
          a.finishedWork = e;
          a.finishedLanes = d;
          switch (b) {
            case 0:
            case 1:
              throw Error(p(345));
            case 2:
              Pk(a, tk, uk);
              break;
            case 3:
              Ck(a, d);
              if ((d & 130023424) === d && (b = fk + 500 - B2(), 10 < b)) {
                if (0 !== uc(a, 0)) break;
                e = a.suspendedLanes;
                if ((e & d) !== d) {
                  R2();
                  a.pingedLanes |= a.suspendedLanes & e;
                  break;
                }
                a.timeoutHandle = Ff(Pk.bind(null, a, tk, uk), b);
                break;
              }
              Pk(a, tk, uk);
              break;
            case 4:
              Ck(a, d);
              if ((d & 4194240) === d) break;
              b = a.eventTimes;
              for (e = -1; 0 < d; ) {
                var g = 31 - oc(d);
                f = 1 << g;
                g = b[g];
                g > e && (e = g);
                d &= ~f;
              }
              d = e;
              d = B2() - d;
              d = (120 > d ? 120 : 480 > d ? 480 : 1080 > d ? 1080 : 1920 > d ? 1920 : 3e3 > d ? 3e3 : 4320 > d ? 4320 : 1960 * lk(d / 1960)) - d;
              if (10 < d) {
                a.timeoutHandle = Ff(Pk.bind(null, a, tk, uk), d);
                break;
              }
              Pk(a, tk, uk);
              break;
            case 5:
              Pk(a, tk, uk);
              break;
            default:
              throw Error(p(329));
          }
        }
      }
      Dk(a, B2());
      return a.callbackNode === c ? Gk.bind(null, a) : null;
    }
    function Nk(a, b) {
      var c = sk;
      a.current.memoizedState.isDehydrated && (Kk(a, b).flags |= 256);
      a = Ik(a, b);
      2 !== a && (b = tk, tk = c, null !== b && Fj(b));
      return a;
    }
    function Fj(a) {
      null === tk ? tk = a : tk.push.apply(tk, a);
    }
    function Ok(a) {
      for (var b = a; ; ) {
        if (b.flags & 16384) {
          var c = b.updateQueue;
          if (null !== c && (c = c.stores, null !== c)) for (var d = 0; d < c.length; d++) {
            var e = c[d], f = e.getSnapshot;
            e = e.value;
            try {
              if (!He(f(), e)) return false;
            } catch (g) {
              return false;
            }
          }
        }
        c = b.child;
        if (b.subtreeFlags & 16384 && null !== c) c.return = b, b = c;
        else {
          if (b === a) break;
          for (; null === b.sibling; ) {
            if (null === b.return || b.return === a) return true;
            b = b.return;
          }
          b.sibling.return = b.return;
          b = b.sibling;
        }
      }
      return true;
    }
    function Ck(a, b) {
      b &= ~rk;
      b &= ~qk;
      a.suspendedLanes |= b;
      a.pingedLanes &= ~b;
      for (a = a.expirationTimes; 0 < b; ) {
        var c = 31 - oc(b), d = 1 << c;
        a[c] = -1;
        b &= ~d;
      }
    }
    function Ek(a) {
      if (0 !== (K & 6)) throw Error(p(327));
      Hk();
      var b = uc(a, 0);
      if (0 === (b & 1)) return Dk(a, B2()), null;
      var c = Ik(a, b);
      if (0 !== a.tag && 2 === c) {
        var d = xc(a);
        0 !== d && (b = d, c = Nk(a, d));
      }
      if (1 === c) throw c = pk, Kk(a, 0), Ck(a, b), Dk(a, B2()), c;
      if (6 === c) throw Error(p(345));
      a.finishedWork = a.current.alternate;
      a.finishedLanes = b;
      Pk(a, tk, uk);
      Dk(a, B2());
      return null;
    }
    function Qk(a, b) {
      var c = K;
      K |= 1;
      try {
        return a(b);
      } finally {
        K = c, 0 === K && (Gj = B2() + 500, fg && jg());
      }
    }
    function Rk(a) {
      null !== wk && 0 === wk.tag && 0 === (K & 6) && Hk();
      var b = K;
      K |= 1;
      var c = ok.transition, d = C2;
      try {
        if (ok.transition = null, C2 = 1, a) return a();
      } finally {
        C2 = d, ok.transition = c, K = b, 0 === (K & 6) && jg();
      }
    }
    function Hj() {
      fj = ej.current;
      E(ej);
    }
    function Kk(a, b) {
      a.finishedWork = null;
      a.finishedLanes = 0;
      var c = a.timeoutHandle;
      -1 !== c && (a.timeoutHandle = -1, Gf(c));
      if (null !== Y) for (c = Y.return; null !== c; ) {
        var d = c;
        wg(d);
        switch (d.tag) {
          case 1:
            d = d.type.childContextTypes;
            null !== d && void 0 !== d && $f();
            break;
          case 3:
            zh();
            E(Wf);
            E(H);
            Eh();
            break;
          case 5:
            Bh(d);
            break;
          case 4:
            zh();
            break;
          case 13:
            E(L);
            break;
          case 19:
            E(L);
            break;
          case 10:
            ah(d.type._context);
            break;
          case 22:
          case 23:
            Hj();
        }
        c = c.return;
      }
      Q = a;
      Y = a = Pg(a.current, null);
      Z = fj = b;
      T = 0;
      pk = null;
      rk = qk = rh = 0;
      tk = sk = null;
      if (null !== fh) {
        for (b = 0; b < fh.length; b++) if (c = fh[b], d = c.interleaved, null !== d) {
          c.interleaved = null;
          var e = d.next, f = c.pending;
          if (null !== f) {
            var g = f.next;
            f.next = e;
            d.next = g;
          }
          c.pending = d;
        }
        fh = null;
      }
      return a;
    }
    function Mk(a, b) {
      do {
        var c = Y;
        try {
          $g();
          Fh.current = Rh;
          if (Ih) {
            for (var d = M.memoizedState; null !== d; ) {
              var e = d.queue;
              null !== e && (e.pending = null);
              d = d.next;
            }
            Ih = false;
          }
          Hh = 0;
          O = N = M = null;
          Jh = false;
          Kh = 0;
          nk.current = null;
          if (null === c || null === c.return) {
            T = 1;
            pk = b;
            Y = null;
            break;
          }
          a: {
            var f = a, g = c.return, h = c, k = b;
            b = Z;
            h.flags |= 32768;
            if (null !== k && "object" === typeof k && "function" === typeof k.then) {
              var l = k, m = h, q = m.tag;
              if (0 === (m.mode & 1) && (0 === q || 11 === q || 15 === q)) {
                var r2 = m.alternate;
                r2 ? (m.updateQueue = r2.updateQueue, m.memoizedState = r2.memoizedState, m.lanes = r2.lanes) : (m.updateQueue = null, m.memoizedState = null);
              }
              var y = Ui(g);
              if (null !== y) {
                y.flags &= -257;
                Vi(y, g, h, f, b);
                y.mode & 1 && Si(f, l, b);
                b = y;
                k = l;
                var n = b.updateQueue;
                if (null === n) {
                  var t = /* @__PURE__ */ new Set();
                  t.add(k);
                  b.updateQueue = t;
                } else n.add(k);
                break a;
              } else {
                if (0 === (b & 1)) {
                  Si(f, l, b);
                  tj();
                  break a;
                }
                k = Error(p(426));
              }
            } else if (I && h.mode & 1) {
              var J = Ui(g);
              if (null !== J) {
                0 === (J.flags & 65536) && (J.flags |= 256);
                Vi(J, g, h, f, b);
                Jg(Ji(k, h));
                break a;
              }
            }
            f = k = Ji(k, h);
            4 !== T && (T = 2);
            null === sk ? sk = [f] : sk.push(f);
            f = g;
            do {
              switch (f.tag) {
                case 3:
                  f.flags |= 65536;
                  b &= -b;
                  f.lanes |= b;
                  var x = Ni(f, k, b);
                  ph(f, x);
                  break a;
                case 1:
                  h = k;
                  var w = f.type, u = f.stateNode;
                  if (0 === (f.flags & 128) && ("function" === typeof w.getDerivedStateFromError || null !== u && "function" === typeof u.componentDidCatch && (null === Ri || !Ri.has(u)))) {
                    f.flags |= 65536;
                    b &= -b;
                    f.lanes |= b;
                    var F = Qi(f, h, b);
                    ph(f, F);
                    break a;
                  }
              }
              f = f.return;
            } while (null !== f);
          }
          Sk(c);
        } catch (na) {
          b = na;
          Y === c && null !== c && (Y = c = c.return);
          continue;
        }
        break;
      } while (1);
    }
    function Jk() {
      var a = mk.current;
      mk.current = Rh;
      return null === a ? Rh : a;
    }
    function tj() {
      if (0 === T || 3 === T || 2 === T) T = 4;
      null === Q || 0 === (rh & 268435455) && 0 === (qk & 268435455) || Ck(Q, Z);
    }
    function Ik(a, b) {
      var c = K;
      K |= 2;
      var d = Jk();
      if (Q !== a || Z !== b) uk = null, Kk(a, b);
      do
        try {
          Tk();
          break;
        } catch (e) {
          Mk(a, e);
        }
      while (1);
      $g();
      K = c;
      mk.current = d;
      if (null !== Y) throw Error(p(261));
      Q = null;
      Z = 0;
      return T;
    }
    function Tk() {
      for (; null !== Y; ) Uk(Y);
    }
    function Lk() {
      for (; null !== Y && !cc(); ) Uk(Y);
    }
    function Uk(a) {
      var b = Vk(a.alternate, a, fj);
      a.memoizedProps = a.pendingProps;
      null === b ? Sk(a) : Y = b;
      nk.current = null;
    }
    function Sk(a) {
      var b = a;
      do {
        var c = b.alternate;
        a = b.return;
        if (0 === (b.flags & 32768)) {
          if (c = Ej(c, b, fj), null !== c) {
            Y = c;
            return;
          }
        } else {
          c = Ij(c, b);
          if (null !== c) {
            c.flags &= 32767;
            Y = c;
            return;
          }
          if (null !== a) a.flags |= 32768, a.subtreeFlags = 0, a.deletions = null;
          else {
            T = 6;
            Y = null;
            return;
          }
        }
        b = b.sibling;
        if (null !== b) {
          Y = b;
          return;
        }
        Y = b = a;
      } while (null !== b);
      0 === T && (T = 5);
    }
    function Pk(a, b, c) {
      var d = C2, e = ok.transition;
      try {
        ok.transition = null, C2 = 1, Wk(a, b, c, d);
      } finally {
        ok.transition = e, C2 = d;
      }
      return null;
    }
    function Wk(a, b, c, d) {
      do
        Hk();
      while (null !== wk);
      if (0 !== (K & 6)) throw Error(p(327));
      c = a.finishedWork;
      var e = a.finishedLanes;
      if (null === c) return null;
      a.finishedWork = null;
      a.finishedLanes = 0;
      if (c === a.current) throw Error(p(177));
      a.callbackNode = null;
      a.callbackPriority = 0;
      var f = c.lanes | c.childLanes;
      Bc(a, f);
      a === Q && (Y = Q = null, Z = 0);
      0 === (c.subtreeFlags & 2064) && 0 === (c.flags & 2064) || vk || (vk = true, Fk(hc, function() {
        Hk();
        return null;
      }));
      f = 0 !== (c.flags & 15990);
      if (0 !== (c.subtreeFlags & 15990) || f) {
        f = ok.transition;
        ok.transition = null;
        var g = C2;
        C2 = 1;
        var h = K;
        K |= 4;
        nk.current = null;
        Oj(a, c);
        dk(c, a);
        Oe(Df);
        dd = !!Cf;
        Df = Cf = null;
        a.current = c;
        hk(c, a, e);
        dc();
        K = h;
        C2 = g;
        ok.transition = f;
      } else a.current = c;
      vk && (vk = false, wk = a, xk = e);
      f = a.pendingLanes;
      0 === f && (Ri = null);
      mc(c.stateNode, d);
      Dk(a, B2());
      if (null !== b) for (d = a.onRecoverableError, c = 0; c < b.length; c++) e = b[c], d(e.value, { componentStack: e.stack, digest: e.digest });
      if (Oi) throw Oi = false, a = Pi, Pi = null, a;
      0 !== (xk & 1) && 0 !== a.tag && Hk();
      f = a.pendingLanes;
      0 !== (f & 1) ? a === zk ? yk++ : (yk = 0, zk = a) : yk = 0;
      jg();
      return null;
    }
    function Hk() {
      if (null !== wk) {
        var a = Dc(xk), b = ok.transition, c = C2;
        try {
          ok.transition = null;
          C2 = 16 > a ? 16 : a;
          if (null === wk) var d = false;
          else {
            a = wk;
            wk = null;
            xk = 0;
            if (0 !== (K & 6)) throw Error(p(331));
            var e = K;
            K |= 4;
            for (V = a.current; null !== V; ) {
              var f = V, g = f.child;
              if (0 !== (V.flags & 16)) {
                var h = f.deletions;
                if (null !== h) {
                  for (var k = 0; k < h.length; k++) {
                    var l = h[k];
                    for (V = l; null !== V; ) {
                      var m = V;
                      switch (m.tag) {
                        case 0:
                        case 11:
                        case 15:
                          Pj(8, m, f);
                      }
                      var q = m.child;
                      if (null !== q) q.return = m, V = q;
                      else for (; null !== V; ) {
                        m = V;
                        var r2 = m.sibling, y = m.return;
                        Sj(m);
                        if (m === l) {
                          V = null;
                          break;
                        }
                        if (null !== r2) {
                          r2.return = y;
                          V = r2;
                          break;
                        }
                        V = y;
                      }
                    }
                  }
                  var n = f.alternate;
                  if (null !== n) {
                    var t = n.child;
                    if (null !== t) {
                      n.child = null;
                      do {
                        var J = t.sibling;
                        t.sibling = null;
                        t = J;
                      } while (null !== t);
                    }
                  }
                  V = f;
                }
              }
              if (0 !== (f.subtreeFlags & 2064) && null !== g) g.return = f, V = g;
              else b: for (; null !== V; ) {
                f = V;
                if (0 !== (f.flags & 2048)) switch (f.tag) {
                  case 0:
                  case 11:
                  case 15:
                    Pj(9, f, f.return);
                }
                var x = f.sibling;
                if (null !== x) {
                  x.return = f.return;
                  V = x;
                  break b;
                }
                V = f.return;
              }
            }
            var w = a.current;
            for (V = w; null !== V; ) {
              g = V;
              var u = g.child;
              if (0 !== (g.subtreeFlags & 2064) && null !== u) u.return = g, V = u;
              else b: for (g = w; null !== V; ) {
                h = V;
                if (0 !== (h.flags & 2048)) try {
                  switch (h.tag) {
                    case 0:
                    case 11:
                    case 15:
                      Qj(9, h);
                  }
                } catch (na) {
                  W(h, h.return, na);
                }
                if (h === g) {
                  V = null;
                  break b;
                }
                var F = h.sibling;
                if (null !== F) {
                  F.return = h.return;
                  V = F;
                  break b;
                }
                V = h.return;
              }
            }
            K = e;
            jg();
            if (lc && "function" === typeof lc.onPostCommitFiberRoot) try {
              lc.onPostCommitFiberRoot(kc, a);
            } catch (na) {
            }
            d = true;
          }
          return d;
        } finally {
          C2 = c, ok.transition = b;
        }
      }
      return false;
    }
    function Xk(a, b, c) {
      b = Ji(c, b);
      b = Ni(a, b, 1);
      a = nh(a, b, 1);
      b = R2();
      null !== a && (Ac(a, 1, b), Dk(a, b));
    }
    function W(a, b, c) {
      if (3 === a.tag) Xk(a, a, c);
      else for (; null !== b; ) {
        if (3 === b.tag) {
          Xk(b, a, c);
          break;
        } else if (1 === b.tag) {
          var d = b.stateNode;
          if ("function" === typeof b.type.getDerivedStateFromError || "function" === typeof d.componentDidCatch && (null === Ri || !Ri.has(d))) {
            a = Ji(c, a);
            a = Qi(b, a, 1);
            b = nh(b, a, 1);
            a = R2();
            null !== b && (Ac(b, 1, a), Dk(b, a));
            break;
          }
        }
        b = b.return;
      }
    }
    function Ti(a, b, c) {
      var d = a.pingCache;
      null !== d && d.delete(b);
      b = R2();
      a.pingedLanes |= a.suspendedLanes & c;
      Q === a && (Z & c) === c && (4 === T || 3 === T && (Z & 130023424) === Z && 500 > B2() - fk ? Kk(a, 0) : rk |= c);
      Dk(a, b);
    }
    function Yk(a, b) {
      0 === b && (0 === (a.mode & 1) ? b = 1 : (b = sc, sc <<= 1, 0 === (sc & 130023424) && (sc = 4194304)));
      var c = R2();
      a = ih(a, b);
      null !== a && (Ac(a, b, c), Dk(a, c));
    }
    function uj(a) {
      var b = a.memoizedState, c = 0;
      null !== b && (c = b.retryLane);
      Yk(a, c);
    }
    function bk(a, b) {
      var c = 0;
      switch (a.tag) {
        case 13:
          var d = a.stateNode;
          var e = a.memoizedState;
          null !== e && (c = e.retryLane);
          break;
        case 19:
          d = a.stateNode;
          break;
        default:
          throw Error(p(314));
      }
      null !== d && d.delete(b);
      Yk(a, c);
    }
    var Vk;
    Vk = function(a, b, c) {
      if (null !== a) if (a.memoizedProps !== b.pendingProps || Wf.current) dh = true;
      else {
        if (0 === (a.lanes & c) && 0 === (b.flags & 128)) return dh = false, yj(a, b, c);
        dh = 0 !== (a.flags & 131072) ? true : false;
      }
      else dh = false, I && 0 !== (b.flags & 1048576) && ug(b, ng, b.index);
      b.lanes = 0;
      switch (b.tag) {
        case 2:
          var d = b.type;
          ij(a, b);
          a = b.pendingProps;
          var e = Yf(b, H.current);
          ch(b, c);
          e = Nh(null, b, d, a, e, c);
          var f = Sh();
          b.flags |= 1;
          "object" === typeof e && null !== e && "function" === typeof e.render && void 0 === e.$$typeof ? (b.tag = 1, b.memoizedState = null, b.updateQueue = null, Zf(d) ? (f = true, cg(b)) : f = false, b.memoizedState = null !== e.state && void 0 !== e.state ? e.state : null, kh(b), e.updater = Ei, b.stateNode = e, e._reactInternals = b, Ii(b, d, a, c), b = jj(null, b, d, true, f, c)) : (b.tag = 0, I && f && vg(b), Xi(null, b, e, c), b = b.child);
          return b;
        case 16:
          d = b.elementType;
          a: {
            ij(a, b);
            a = b.pendingProps;
            e = d._init;
            d = e(d._payload);
            b.type = d;
            e = b.tag = Zk(d);
            a = Ci(d, a);
            switch (e) {
              case 0:
                b = cj(null, b, d, a, c);
                break a;
              case 1:
                b = hj(null, b, d, a, c);
                break a;
              case 11:
                b = Yi(null, b, d, a, c);
                break a;
              case 14:
                b = $i(null, b, d, Ci(d.type, a), c);
                break a;
            }
            throw Error(p(
              306,
              d,
              ""
            ));
          }
          return b;
        case 0:
          return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : Ci(d, e), cj(a, b, d, e, c);
        case 1:
          return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : Ci(d, e), hj(a, b, d, e, c);
        case 3:
          a: {
            kj(b);
            if (null === a) throw Error(p(387));
            d = b.pendingProps;
            f = b.memoizedState;
            e = f.element;
            lh(a, b);
            qh(b, d, null, c);
            var g = b.memoizedState;
            d = g.element;
            if (f.isDehydrated) if (f = { element: d, isDehydrated: false, cache: g.cache, pendingSuspenseBoundaries: g.pendingSuspenseBoundaries, transitions: g.transitions }, b.updateQueue.baseState = f, b.memoizedState = f, b.flags & 256) {
              e = Ji(Error(p(423)), b);
              b = lj(a, b, d, c, e);
              break a;
            } else if (d !== e) {
              e = Ji(Error(p(424)), b);
              b = lj(a, b, d, c, e);
              break a;
            } else for (yg = Lf(b.stateNode.containerInfo.firstChild), xg = b, I = true, zg = null, c = Vg(b, null, d, c), b.child = c; c; ) c.flags = c.flags & -3 | 4096, c = c.sibling;
            else {
              Ig();
              if (d === e) {
                b = Zi(a, b, c);
                break a;
              }
              Xi(a, b, d, c);
            }
            b = b.child;
          }
          return b;
        case 5:
          return Ah(b), null === a && Eg(b), d = b.type, e = b.pendingProps, f = null !== a ? a.memoizedProps : null, g = e.children, Ef(d, e) ? g = null : null !== f && Ef(d, f) && (b.flags |= 32), gj(a, b), Xi(a, b, g, c), b.child;
        case 6:
          return null === a && Eg(b), null;
        case 13:
          return oj(a, b, c);
        case 4:
          return yh(b, b.stateNode.containerInfo), d = b.pendingProps, null === a ? b.child = Ug(b, null, d, c) : Xi(a, b, d, c), b.child;
        case 11:
          return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : Ci(d, e), Yi(a, b, d, e, c);
        case 7:
          return Xi(a, b, b.pendingProps, c), b.child;
        case 8:
          return Xi(a, b, b.pendingProps.children, c), b.child;
        case 12:
          return Xi(a, b, b.pendingProps.children, c), b.child;
        case 10:
          a: {
            d = b.type._context;
            e = b.pendingProps;
            f = b.memoizedProps;
            g = e.value;
            G(Wg, d._currentValue);
            d._currentValue = g;
            if (null !== f) if (He(f.value, g)) {
              if (f.children === e.children && !Wf.current) {
                b = Zi(a, b, c);
                break a;
              }
            } else for (f = b.child, null !== f && (f.return = b); null !== f; ) {
              var h = f.dependencies;
              if (null !== h) {
                g = f.child;
                for (var k = h.firstContext; null !== k; ) {
                  if (k.context === d) {
                    if (1 === f.tag) {
                      k = mh(-1, c & -c);
                      k.tag = 2;
                      var l = f.updateQueue;
                      if (null !== l) {
                        l = l.shared;
                        var m = l.pending;
                        null === m ? k.next = k : (k.next = m.next, m.next = k);
                        l.pending = k;
                      }
                    }
                    f.lanes |= c;
                    k = f.alternate;
                    null !== k && (k.lanes |= c);
                    bh(
                      f.return,
                      c,
                      b
                    );
                    h.lanes |= c;
                    break;
                  }
                  k = k.next;
                }
              } else if (10 === f.tag) g = f.type === b.type ? null : f.child;
              else if (18 === f.tag) {
                g = f.return;
                if (null === g) throw Error(p(341));
                g.lanes |= c;
                h = g.alternate;
                null !== h && (h.lanes |= c);
                bh(g, c, b);
                g = f.sibling;
              } else g = f.child;
              if (null !== g) g.return = f;
              else for (g = f; null !== g; ) {
                if (g === b) {
                  g = null;
                  break;
                }
                f = g.sibling;
                if (null !== f) {
                  f.return = g.return;
                  g = f;
                  break;
                }
                g = g.return;
              }
              f = g;
            }
            Xi(a, b, e.children, c);
            b = b.child;
          }
          return b;
        case 9:
          return e = b.type, d = b.pendingProps.children, ch(b, c), e = eh(e), d = d(e), b.flags |= 1, Xi(a, b, d, c), b.child;
        case 14:
          return d = b.type, e = Ci(d, b.pendingProps), e = Ci(d.type, e), $i(a, b, d, e, c);
        case 15:
          return bj(a, b, b.type, b.pendingProps, c);
        case 17:
          return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : Ci(d, e), ij(a, b), b.tag = 1, Zf(d) ? (a = true, cg(b)) : a = false, ch(b, c), Gi(b, d, e), Ii(b, d, e, c), jj(null, b, d, true, a, c);
        case 19:
          return xj(a, b, c);
        case 22:
          return dj(a, b, c);
      }
      throw Error(p(156, b.tag));
    };
    function Fk(a, b) {
      return ac(a, b);
    }
    function $k(a, b, c, d) {
      this.tag = a;
      this.key = c;
      this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null;
      this.index = 0;
      this.ref = null;
      this.pendingProps = b;
      this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null;
      this.mode = d;
      this.subtreeFlags = this.flags = 0;
      this.deletions = null;
      this.childLanes = this.lanes = 0;
      this.alternate = null;
    }
    function Bg(a, b, c, d) {
      return new $k(a, b, c, d);
    }
    function aj(a) {
      a = a.prototype;
      return !(!a || !a.isReactComponent);
    }
    function Zk(a) {
      if ("function" === typeof a) return aj(a) ? 1 : 0;
      if (void 0 !== a && null !== a) {
        a = a.$$typeof;
        if (a === Da) return 11;
        if (a === Ga) return 14;
      }
      return 2;
    }
    function Pg(a, b) {
      var c = a.alternate;
      null === c ? (c = Bg(a.tag, b, a.key, a.mode), c.elementType = a.elementType, c.type = a.type, c.stateNode = a.stateNode, c.alternate = a, a.alternate = c) : (c.pendingProps = b, c.type = a.type, c.flags = 0, c.subtreeFlags = 0, c.deletions = null);
      c.flags = a.flags & 14680064;
      c.childLanes = a.childLanes;
      c.lanes = a.lanes;
      c.child = a.child;
      c.memoizedProps = a.memoizedProps;
      c.memoizedState = a.memoizedState;
      c.updateQueue = a.updateQueue;
      b = a.dependencies;
      c.dependencies = null === b ? null : { lanes: b.lanes, firstContext: b.firstContext };
      c.sibling = a.sibling;
      c.index = a.index;
      c.ref = a.ref;
      return c;
    }
    function Rg(a, b, c, d, e, f) {
      var g = 2;
      d = a;
      if ("function" === typeof a) aj(a) && (g = 1);
      else if ("string" === typeof a) g = 5;
      else a: switch (a) {
        case ya:
          return Tg(c.children, e, f, b);
        case za:
          g = 8;
          e |= 8;
          break;
        case Aa:
          return a = Bg(12, c, b, e | 2), a.elementType = Aa, a.lanes = f, a;
        case Ea:
          return a = Bg(13, c, b, e), a.elementType = Ea, a.lanes = f, a;
        case Fa:
          return a = Bg(19, c, b, e), a.elementType = Fa, a.lanes = f, a;
        case Ia:
          return pj(c, e, f, b);
        default:
          if ("object" === typeof a && null !== a) switch (a.$$typeof) {
            case Ba:
              g = 10;
              break a;
            case Ca:
              g = 9;
              break a;
            case Da:
              g = 11;
              break a;
            case Ga:
              g = 14;
              break a;
            case Ha:
              g = 16;
              d = null;
              break a;
          }
          throw Error(p(130, null == a ? a : typeof a, ""));
      }
      b = Bg(g, c, b, e);
      b.elementType = a;
      b.type = d;
      b.lanes = f;
      return b;
    }
    function Tg(a, b, c, d) {
      a = Bg(7, a, d, b);
      a.lanes = c;
      return a;
    }
    function pj(a, b, c, d) {
      a = Bg(22, a, d, b);
      a.elementType = Ia;
      a.lanes = c;
      a.stateNode = { isHidden: false };
      return a;
    }
    function Qg(a, b, c) {
      a = Bg(6, a, null, b);
      a.lanes = c;
      return a;
    }
    function Sg(a, b, c) {
      b = Bg(4, null !== a.children ? a.children : [], a.key, b);
      b.lanes = c;
      b.stateNode = { containerInfo: a.containerInfo, pendingChildren: null, implementation: a.implementation };
      return b;
    }
    function al(a, b, c, d, e) {
      this.tag = b;
      this.containerInfo = a;
      this.finishedWork = this.pingCache = this.current = this.pendingChildren = null;
      this.timeoutHandle = -1;
      this.callbackNode = this.pendingContext = this.context = null;
      this.callbackPriority = 0;
      this.eventTimes = zc(0);
      this.expirationTimes = zc(-1);
      this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0;
      this.entanglements = zc(0);
      this.identifierPrefix = d;
      this.onRecoverableError = e;
      this.mutableSourceEagerHydrationData = null;
    }
    function bl(a, b, c, d, e, f, g, h, k) {
      a = new al(a, b, c, h, k);
      1 === b ? (b = 1, true === f && (b |= 8)) : b = 0;
      f = Bg(3, null, null, b);
      a.current = f;
      f.stateNode = a;
      f.memoizedState = { element: d, isDehydrated: c, cache: null, transitions: null, pendingSuspenseBoundaries: null };
      kh(f);
      return a;
    }
    function cl(a, b, c) {
      var d = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : null;
      return { $$typeof: wa, key: null == d ? null : "" + d, children: a, containerInfo: b, implementation: c };
    }
    function dl(a) {
      if (!a) return Vf;
      a = a._reactInternals;
      a: {
        if (Vb(a) !== a || 1 !== a.tag) throw Error(p(170));
        var b = a;
        do {
          switch (b.tag) {
            case 3:
              b = b.stateNode.context;
              break a;
            case 1:
              if (Zf(b.type)) {
                b = b.stateNode.__reactInternalMemoizedMergedChildContext;
                break a;
              }
          }
          b = b.return;
        } while (null !== b);
        throw Error(p(171));
      }
      if (1 === a.tag) {
        var c = a.type;
        if (Zf(c)) return bg(a, c, b);
      }
      return b;
    }
    function el(a, b, c, d, e, f, g, h, k) {
      a = bl(c, d, true, a, e, f, g, h, k);
      a.context = dl(null);
      c = a.current;
      d = R2();
      e = yi(c);
      f = mh(d, e);
      f.callback = void 0 !== b && null !== b ? b : null;
      nh(c, f, e);
      a.current.lanes = e;
      Ac(a, e, d);
      Dk(a, d);
      return a;
    }
    function fl(a, b, c, d) {
      var e = b.current, f = R2(), g = yi(e);
      c = dl(c);
      null === b.context ? b.context = c : b.pendingContext = c;
      b = mh(f, g);
      b.payload = { element: a };
      d = void 0 === d ? null : d;
      null !== d && (b.callback = d);
      a = nh(e, b, g);
      null !== a && (gi(a, e, g, f), oh(a, e, g));
      return g;
    }
    function gl(a) {
      a = a.current;
      if (!a.child) return null;
      switch (a.child.tag) {
        case 5:
          return a.child.stateNode;
        default:
          return a.child.stateNode;
      }
    }
    function hl(a, b) {
      a = a.memoizedState;
      if (null !== a && null !== a.dehydrated) {
        var c = a.retryLane;
        a.retryLane = 0 !== c && c < b ? c : b;
      }
    }
    function il(a, b) {
      hl(a, b);
      (a = a.alternate) && hl(a, b);
    }
    function jl() {
      return null;
    }
    var kl = "function" === typeof reportError ? reportError : function(a) {
      console.error(a);
    };
    function ll(a) {
      this._internalRoot = a;
    }
    ml.prototype.render = ll.prototype.render = function(a) {
      var b = this._internalRoot;
      if (null === b) throw Error(p(409));
      fl(a, b, null, null);
    };
    ml.prototype.unmount = ll.prototype.unmount = function() {
      var a = this._internalRoot;
      if (null !== a) {
        this._internalRoot = null;
        var b = a.containerInfo;
        Rk(function() {
          fl(null, a, null, null);
        });
        b[uf] = null;
      }
    };
    function ml(a) {
      this._internalRoot = a;
    }
    ml.prototype.unstable_scheduleHydration = function(a) {
      if (a) {
        var b = Hc();
        a = { blockedOn: null, target: a, priority: b };
        for (var c = 0; c < Qc.length && 0 !== b && b < Qc[c].priority; c++) ;
        Qc.splice(c, 0, a);
        0 === c && Vc(a);
      }
    };
    function nl(a) {
      return !(!a || 1 !== a.nodeType && 9 !== a.nodeType && 11 !== a.nodeType);
    }
    function ol(a) {
      return !(!a || 1 !== a.nodeType && 9 !== a.nodeType && 11 !== a.nodeType && (8 !== a.nodeType || " react-mount-point-unstable " !== a.nodeValue));
    }
    function pl() {
    }
    function ql(a, b, c, d, e) {
      if (e) {
        if ("function" === typeof d) {
          var f = d;
          d = function() {
            var a2 = gl(g);
            f.call(a2);
          };
        }
        var g = el(b, d, a, 0, null, false, false, "", pl);
        a._reactRootContainer = g;
        a[uf] = g.current;
        sf(8 === a.nodeType ? a.parentNode : a);
        Rk();
        return g;
      }
      for (; e = a.lastChild; ) a.removeChild(e);
      if ("function" === typeof d) {
        var h = d;
        d = function() {
          var a2 = gl(k);
          h.call(a2);
        };
      }
      var k = bl(a, 0, false, null, null, false, false, "", pl);
      a._reactRootContainer = k;
      a[uf] = k.current;
      sf(8 === a.nodeType ? a.parentNode : a);
      Rk(function() {
        fl(b, k, c, d);
      });
      return k;
    }
    function rl(a, b, c, d, e) {
      var f = c._reactRootContainer;
      if (f) {
        var g = f;
        if ("function" === typeof e) {
          var h = e;
          e = function() {
            var a2 = gl(g);
            h.call(a2);
          };
        }
        fl(b, g, a, e);
      } else g = ql(c, b, a, e, d);
      return gl(g);
    }
    Ec = function(a) {
      switch (a.tag) {
        case 3:
          var b = a.stateNode;
          if (b.current.memoizedState.isDehydrated) {
            var c = tc(b.pendingLanes);
            0 !== c && (Cc(b, c | 1), Dk(b, B2()), 0 === (K & 6) && (Gj = B2() + 500, jg()));
          }
          break;
        case 13:
          Rk(function() {
            var b2 = ih(a, 1);
            if (null !== b2) {
              var c2 = R2();
              gi(b2, a, 1, c2);
            }
          }), il(a, 1);
      }
    };
    Fc = function(a) {
      if (13 === a.tag) {
        var b = ih(a, 134217728);
        if (null !== b) {
          var c = R2();
          gi(b, a, 134217728, c);
        }
        il(a, 134217728);
      }
    };
    Gc = function(a) {
      if (13 === a.tag) {
        var b = yi(a), c = ih(a, b);
        if (null !== c) {
          var d = R2();
          gi(c, a, b, d);
        }
        il(a, b);
      }
    };
    Hc = function() {
      return C2;
    };
    Ic = function(a, b) {
      var c = C2;
      try {
        return C2 = a, b();
      } finally {
        C2 = c;
      }
    };
    yb = function(a, b, c) {
      switch (b) {
        case "input":
          bb(a, c);
          b = c.name;
          if ("radio" === c.type && null != b) {
            for (c = a; c.parentNode; ) c = c.parentNode;
            c = c.querySelectorAll("input[name=" + JSON.stringify("" + b) + '][type="radio"]');
            for (b = 0; b < c.length; b++) {
              var d = c[b];
              if (d !== a && d.form === a.form) {
                var e = Db(d);
                if (!e) throw Error(p(90));
                Wa(d);
                bb(d, e);
              }
            }
          }
          break;
        case "textarea":
          ib(a, c);
          break;
        case "select":
          b = c.value, null != b && fb(a, !!c.multiple, b, false);
      }
    };
    Gb = Qk;
    Hb = Rk;
    var sl = { usingClientEntryPoint: false, Events: [Cb, ue, Db, Eb, Fb, Qk] };
    var tl = { findFiberByHostInstance: Wc, bundleType: 0, version: "18.3.1", rendererPackageName: "react-dom" };
    var ul = { bundleType: tl.bundleType, version: tl.version, rendererPackageName: tl.rendererPackageName, rendererConfig: tl.rendererConfig, overrideHookState: null, overrideHookStateDeletePath: null, overrideHookStateRenamePath: null, overrideProps: null, overridePropsDeletePath: null, overridePropsRenamePath: null, setErrorHandler: null, setSuspenseHandler: null, scheduleUpdate: null, currentDispatcherRef: ua.ReactCurrentDispatcher, findHostInstanceByFiber: function(a) {
      a = Zb(a);
      return null === a ? null : a.stateNode;
    }, findFiberByHostInstance: tl.findFiberByHostInstance || jl, findHostInstancesForRefresh: null, scheduleRefresh: null, scheduleRoot: null, setRefreshHandler: null, getCurrentFiber: null, reconcilerVersion: "18.3.1-next-f1338f8080-20240426" };
    if ("undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__) {
      vl = __REACT_DEVTOOLS_GLOBAL_HOOK__;
      if (!vl.isDisabled && vl.supportsFiber) try {
        kc = vl.inject(ul), lc = vl;
      } catch (a) {
      }
    }
    var vl;
    exports.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = sl;
    exports.createPortal = function(a, b) {
      var c = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null;
      if (!nl(b)) throw Error(p(200));
      return cl(a, b, null, c);
    };
    exports.createRoot = function(a, b) {
      if (!nl(a)) throw Error(p(299));
      var c = false, d = "", e = kl;
      null !== b && void 0 !== b && (true === b.unstable_strictMode && (c = true), void 0 !== b.identifierPrefix && (d = b.identifierPrefix), void 0 !== b.onRecoverableError && (e = b.onRecoverableError));
      b = bl(a, 1, false, null, null, c, false, d, e);
      a[uf] = b.current;
      sf(8 === a.nodeType ? a.parentNode : a);
      return new ll(b);
    };
    exports.findDOMNode = function(a) {
      if (null == a) return null;
      if (1 === a.nodeType) return a;
      var b = a._reactInternals;
      if (void 0 === b) {
        if ("function" === typeof a.render) throw Error(p(188));
        a = Object.keys(a).join(",");
        throw Error(p(268, a));
      }
      a = Zb(b);
      a = null === a ? null : a.stateNode;
      return a;
    };
    exports.flushSync = function(a) {
      return Rk(a);
    };
    exports.hydrate = function(a, b, c) {
      if (!ol(b)) throw Error(p(200));
      return rl(null, a, b, true, c);
    };
    exports.hydrateRoot = function(a, b, c) {
      if (!nl(a)) throw Error(p(405));
      var d = null != c && c.hydratedSources || null, e = false, f = "", g = kl;
      null !== c && void 0 !== c && (true === c.unstable_strictMode && (e = true), void 0 !== c.identifierPrefix && (f = c.identifierPrefix), void 0 !== c.onRecoverableError && (g = c.onRecoverableError));
      b = el(b, null, a, 1, null != c ? c : null, e, false, f, g);
      a[uf] = b.current;
      sf(a);
      if (d) for (a = 0; a < d.length; a++) c = d[a], e = c._getVersion, e = e(c._source), null == b.mutableSourceEagerHydrationData ? b.mutableSourceEagerHydrationData = [c, e] : b.mutableSourceEagerHydrationData.push(
        c,
        e
      );
      return new ml(b);
    };
    exports.render = function(a, b, c) {
      if (!ol(b)) throw Error(p(200));
      return rl(null, a, b, false, c);
    };
    exports.unmountComponentAtNode = function(a) {
      if (!ol(a)) throw Error(p(40));
      return a._reactRootContainer ? (Rk(function() {
        rl(null, null, a, false, function() {
          a._reactRootContainer = null;
          a[uf] = null;
        });
      }), true) : false;
    };
    exports.unstable_batchedUpdates = Qk;
    exports.unstable_renderSubtreeIntoContainer = function(a, b, c, d) {
      if (!ol(c)) throw Error(p(200));
      if (null == a || void 0 === a._reactInternals) throw Error(p(38));
      return rl(a, b, c, false, d);
    };
    exports.version = "18.3.1-next-f1338f8080-20240426";
  }
});

// node_modules/react-dom/index.js
var require_react_dom = __commonJS({
  "node_modules/react-dom/index.js"(exports, module) {
    "use strict";
    function checkDCE() {
      if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ === "undefined" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE !== "function") {
        return;
      }
      if (false) {
        throw new Error("^_^");
      }
      try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(checkDCE);
      } catch (err) {
        console.error(err);
      }
    }
    if (true) {
      checkDCE();
      module.exports = require_react_dom_production_min();
    } else {
      module.exports = null;
    }
  }
});

// node_modules/react-dom/client.js
var require_client = __commonJS({
  "node_modules/react-dom/client.js"(exports) {
    "use strict";
    var m = require_react_dom();
    if (true) {
      exports.createRoot = m.createRoot;
      exports.hydrateRoot = m.hydrateRoot;
    } else {
      i = m.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;
      exports.createRoot = function(c, o) {
        i.usingClientEntryPoint = true;
        try {
          return m.createRoot(c, o);
        } finally {
          i.usingClientEntryPoint = false;
        }
      };
      exports.hydrateRoot = function(c, h, o) {
        i.usingClientEntryPoint = true;
        try {
          return m.hydrateRoot(c, h, o);
        } finally {
          i.usingClientEntryPoint = false;
        }
      };
    }
    var i;
  }
});

// src/lib/keyedRng.ts
function keyedRng(key) {
  let h = 2166136261;
  for (let i = 0; i < key.length; i += 1) {
    h ^= key.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  let a = h >>> 0;
  return () => {
    a = a + 1831565813 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
var init_keyedRng = __esm({
  "src/lib/keyedRng.ts"() {
  }
});

// src/lib/careerIdentity.ts
var init_careerIdentity = __esm({
  "src/lib/careerIdentity.ts"() {
  }
});

// src/lib/soccerCareerLife.ts
var init_soccerCareerLife = __esm({
  "src/lib/soccerCareerLife.ts"() {
    init_careerIdentity();
  }
});

// src/lib/careerEras.ts
function adjustClubsForYear(clubs, year) {
  return clubs.filter((c) => {
    const founded = CLUB_FOUNDED_AFTER[c.name];
    return founded === void 0 || year >= founded;
  }).map((c) => {
    for (const rule of ERA_TIER_RULES) {
      if (rule.name !== c.name) continue;
      if (rule.from !== void 0 && year < rule.from) continue;
      if (rule.until !== void 0 && year > rule.until) continue;
      if (c.tier === rule.tier) return c;
      return { ...c, tier: rule.tier };
    }
    return c;
  });
}
var S, ERA_DEFS, CLUB_FOUNDED_AFTER, ERA_TIER_RULES;
var init_careerEras = __esm({
  "src/lib/careerEras.ts"() {
    init_soccerCareerLife();
    S = (name, nationality, position, club, g0, g1, power) => ({ name, nationality, position, club, baseGoals: [g0, g1], power });
    ERA_DEFS = [
      {
        from: 1990,
        to: 1994,
        stars: [
          S("Marco van Basten", "Netherlands", "ST", "AC Milan", 19, 32, 10),
          S("Ruud Gullit", "Netherlands", "CAM", "AC Milan", 10, 20, 8),
          S("Frank Rijkaard", "Netherlands", "CDM", "AC Milan", 4, 10, 7),
          S("Lothar Matth\xE4us", "Germany", "CM", "Bayern Munich", 8, 16, 9),
          S("Roberto Baggio", "Italy", "CAM", "Juventus", 15, 25, 10),
          S("Hristo Stoichkov", "Bulgaria", "ST", "Barcelona", 16, 28, 9),
          S("Rom\xE1rio", "Brazil", "ST", "PSV", 22, 34, 9),
          S("Gabriel Batistuta", "Argentina", "ST", "Fiorentina", 18, 28, 7),
          S("J\xFCrgen Klinsmann", "Germany", "ST", "Monaco", 15, 25, 7),
          S("Dennis Bergkamp", "Netherlands", "ST", "Ajax", 12, 22, 7),
          S("George Weah", "Liberia", "ST", "PSG", 14, 24, 8),
          S("Paolo Maldini", "Italy", "CB", "AC Milan", 1, 4, 8),
          S("Franco Baresi", "Italy", "CB", "AC Milan", 0, 3, 7),
          S("Eric Cantona", "France", "ST", "Man United", 14, 22, 8),
          S("Ryan Giggs", "Wales", "LW", "Man United", 8, 15, 6),
          S("Gheorghe Hagi", "Romania", "CAM", "Brescia", 8, 15, 7),
          S("Peter Schmeichel", "Denmark", "GK", "Man United", 0, 0, 7),
          S("Alan Shearer", "England", "ST", "Blackburn Rovers", 22, 34, 7),
          S("Matthias Sammer", "Germany", "CB", "Dortmund", 4, 8, 7),
          S("Ra\xED", "Brazil", "CAM", "Sao Paulo", 8, 16, 5)
        ],
        topClubs: ["AC Milan", "Barcelona", "Juventus", "Man United", "Real Madrid", "Inter Milan", "Ajax", "Marseille", "Bayern Munich", "Benfica"],
        uclExtras: ["Porto", "PSG", "Parma", "Sampdoria", "Red Star Belgrade", "Steaua Bucharest"],
        leagues: {
          "Premier League": ["Man United", "Arsenal", "Blackburn Rovers", "Newcastle", "Leeds United", "Liverpool"],
          "La Liga": ["Barcelona", "Real Madrid", "Atletico Madrid", "Deportivo", "Valencia"],
          "Bundesliga": ["Bayern Munich", "Dortmund", "Werder Bremen", "Kaiserslautern", "Stuttgart"],
          "Serie A": ["AC Milan", "Juventus", "Inter Milan", "Napoli", "Sampdoria", "Lazio"],
          "Ligue 1": ["Marseille", "PSG", "Monaco", "Nantes", "Bordeaux"],
          /* Round 302: the leagues the owner named join the title race feed, each
             window listing the clubs that actually contested that half decade
             (champions first, verified against season records). MLS is absent
             before 1995 because the league first kicked off in 1996, and K League
             joins from 2010 when its club identities settled into the names the
             game uses; simCareerEras pins both exemptions. */
          "Primeira Liga": ["Porto", "Benfica", "Sporting CP"],
          "Eredivisie": ["Ajax", "PSV", "Feyenoord"],
          "Scottish Premiership": ["Rangers", "Celtic", "Aberdeen"],
          "Brasileirao": ["Sao Paulo", "Palmeiras", "Flamengo", "Corinthians"],
          "Saudi Pro League": ["Al Shabab", "Al Nassr", "Al Hilal"]
        },
        rivalFirsts: ["Stefan", "Dario", "Gianluca", "Patrik", "Emile", "Dejan", "Tomas", "Brian", "Oliver", "Marcelo", "Iv\xE1n", "Predrag", "Davor", "Nwankwo", "Marcel", "Youri", "Ariel", "Christophe", "Darko", "Kenneth"]
      },
      {
        from: 1995,
        to: 1999,
        stars: [
          S("Ronaldo", "Brazil", "ST", "Inter Milan", 25, 40, 10),
          S("Zinedine Zidane", "France", "CAM", "Juventus", 8, 16, 10),
          S("George Weah", "Liberia", "ST", "AC Milan", 16, 26, 9),
          S("Matthias Sammer", "Germany", "CB", "Dortmund", 4, 9, 8),
          S("Alessandro Del Piero", "Italy", "ST", "Juventus", 15, 25, 8),
          S("Rivaldo", "Brazil", "LW", "Barcelona", 18, 28, 9),
          S("Davor \u0160uker", "Croatia", "ST", "Real Madrid", 16, 26, 7),
          S("Michael Owen", "England", "ST", "Liverpool", 15, 24, 8),
          S("David Beckham", "England", "RW", "Man United", 6, 12, 8),
          S("Lu\xEDs Figo", "Portugal", "RW", "Barcelona", 8, 14, 8),
          S("Dennis Bergkamp", "Netherlands", "CAM", "Arsenal", 12, 20, 8),
          S("Gabriel Batistuta", "Argentina", "ST", "Fiorentina", 18, 28, 7),
          S("Roberto Carlos", "Brazil", "LB", "Real Madrid", 4, 8, 7),
          S("Ra\xFAl", "Spain", "ST", "Real Madrid", 16, 25, 7),
          S("Andriy Shevchenko", "Ukraine", "ST", "Dynamo Kyiv", 18, 28, 7),
          S("Eric Cantona", "France", "ST", "Man United", 12, 18, 6),
          S("Paolo Maldini", "Italy", "CB", "AC Milan", 1, 3, 7),
          S("Oliver Kahn", "Germany", "GK", "Bayern Munich", 0, 0, 7),
          S("Christian Vieri", "Italy", "ST", "Inter Milan", 16, 26, 6),
          S("Jaap Stam", "Netherlands", "CB", "PSV", 1, 3, 6)
        ],
        topClubs: ["Juventus", "AC Milan", "Real Madrid", "Man United", "Bayern Munich", "Barcelona", "Dortmund", "Ajax", "Inter Milan", "Arsenal"],
        uclExtras: ["Parma", "Lazio", "PSG", "Porto", "Newcastle", "Valencia"],
        leagues: {
          "Premier League": ["Man United", "Arsenal", "Newcastle", "Liverpool", "Chelsea", "Leeds United"],
          "La Liga": ["Real Madrid", "Barcelona", "Atletico Madrid", "Valencia", "Deportivo"],
          "Bundesliga": ["Bayern Munich", "Dortmund", "Kaiserslautern", "Leverkusen"],
          "Serie A": ["Juventus", "AC Milan", "Inter Milan", "Lazio", "Parma", "Fiorentina"],
          "Ligue 1": ["PSG", "Monaco", "Marseille", "Lyon", "Bordeaux"],
          "Primeira Liga": ["Porto", "Benfica", "Sporting CP"],
          "Eredivisie": ["Ajax", "PSV", "Feyenoord"],
          "Scottish Premiership": ["Rangers", "Celtic", "Hearts"],
          "Brasileirao": ["Corinthians", "Vasco da Gama", "Gremio", "Botafogo"],
          "Saudi Pro League": ["Al Hilal", "Al Ittihad", "Al Nassr"],
          "MLS": ["DC United", "Chicago Fire", "LA Galaxy"]
        },
        rivalFirsts: ["Stefan", "Dario", "Gianluca", "Patrik", "Emile", "Dejan", "Tomas", "Brian", "Oliver", "Marcelo", "Iv\xE1n", "Predrag", "Davor", "Nwankwo", "Marcel", "Youri", "Ariel", "Christophe", "Darko", "Kenneth"]
      },
      {
        from: 2e3,
        to: 2004,
        stars: [
          S("Zinedine Zidane", "France", "CAM", "Real Madrid", 8, 15, 10),
          S("Lu\xEDs Figo", "Portugal", "RW", "Real Madrid", 8, 14, 9),
          S("Michael Owen", "England", "ST", "Liverpool", 16, 26, 8),
          S("Ronaldo", "Brazil", "ST", "Real Madrid", 20, 30, 9),
          S("Pavel Nedv\u011Bd", "Czech Republic", "CAM", "Juventus", 10, 18, 8),
          S("Andriy Shevchenko", "Ukraine", "ST", "AC Milan", 20, 30, 9),
          S("Ronaldinho", "Brazil", "CAM", "Barcelona", 15, 25, 9),
          S("Thierry Henry", "France", "ST", "Arsenal", 24, 34, 9),
          S("Oliver Kahn", "Germany", "GK", "Bayern Munich", 0, 0, 8),
          S("Ra\xFAl", "Spain", "ST", "Real Madrid", 16, 26, 8),
          S("Rivaldo", "Brazil", "CAM", "Barcelona", 14, 24, 7),
          S("David Beckham", "England", "RW", "Man United", 5, 10, 7),
          S("Roberto Carlos", "Brazil", "LB", "Real Madrid", 4, 8, 7),
          S("Ruud van Nistelrooy", "Netherlands", "ST", "Man United", 22, 32, 8),
          S("Francesco Totti", "Italy", "CAM", "Roma", 14, 22, 7),
          S("Paolo Maldini", "Italy", "CB", "AC Milan", 1, 3, 6),
          S("Deco", "Portugal", "CM", "Porto", 8, 14, 7),
          S("Steven Gerrard", "England", "CM", "Liverpool", 8, 14, 7),
          S("Frank Lampard", "England", "CM", "Chelsea", 10, 18, 7),
          S("Samuel Eto'o", "Cameroon", "ST", "Mallorca", 16, 26, 6),
          S("Alessandro Nesta", "Italy", "CB", "AC Milan", 0, 3, 6)
        ],
        topClubs: ["Real Madrid", "Bayern Munich", "AC Milan", "Porto", "Barcelona", "Man United", "Juventus", "Arsenal", "Liverpool", "Inter Milan"],
        uclExtras: ["Valencia", "Deportivo", "Leeds United", "Lazio", "PSV", "Monaco"],
        leagues: {
          "Premier League": ["Man United", "Arsenal", "Chelsea", "Liverpool", "Newcastle", "Leeds United"],
          "La Liga": ["Real Madrid", "Barcelona", "Valencia", "Deportivo", "Atletico Madrid"],
          "Bundesliga": ["Bayern Munich", "Dortmund", "Leverkusen", "Werder Bremen", "Stuttgart"],
          "Serie A": ["Juventus", "AC Milan", "Inter Milan", "Roma", "Lazio"],
          "Ligue 1": ["Lyon", "Monaco", "PSG", "Marseille", "Bordeaux"],
          "Primeira Liga": ["Porto", "Sporting CP", "Boavista", "Benfica"],
          "Eredivisie": ["PSV", "Ajax", "Feyenoord"],
          "Scottish Premiership": ["Celtic", "Rangers", "Hearts"],
          "Brasileirao": ["Santos", "Cruzeiro", "Vasco da Gama", "Sao Paulo"],
          "Saudi Pro League": ["Al Ittihad", "Al Hilal", "Al Shabab"],
          "MLS": ["LA Galaxy", "San Jose Earthquakes", "DC United"]
        },
        rivalFirsts: ["Fernando", "Diego", "Andr\xE9s", "Wesley", "Robin", "Arjen", "Franck", "Ricardo", "Milan", "Dimitar", "Emmanuel", "Obafemi", "Landon", "Gonzalo", "Sergio", "Karim", "Cesc", "Theo", "Mikel", "Klaas"]
      },
      {
        from: 2005,
        to: 2009,
        stars: [
          S("Ronaldinho", "Brazil", "CAM", "Barcelona", 18, 26, 10),
          S("Fabio Cannavaro", "Italy", "CB", "Real Madrid", 0, 3, 8),
          S("Kak\xE1", "Brazil", "CAM", "AC Milan", 15, 25, 9),
          S("Cristiano Ronaldo", "Portugal", "RW", "Man United", 24, 42, 10),
          S("Lionel Messi", "Argentina", "RW", "Barcelona", 23, 38, 10),
          S("Thierry Henry", "France", "ST", "Barcelona", 18, 28, 8),
          S("Samuel Eto'o", "Cameroon", "ST", "Barcelona", 20, 30, 8),
          S("Fernando Torres", "Spain", "ST", "Liverpool", 18, 28, 8),
          S("Steven Gerrard", "England", "CM", "Liverpool", 10, 18, 8),
          S("Frank Lampard", "England", "CM", "Chelsea", 12, 20, 8),
          S("Xavi", "Spain", "CM", "Barcelona", 4, 10, 8),
          S("Andr\xE9s Iniesta", "Spain", "CM", "Barcelona", 4, 9, 8),
          S("Wayne Rooney", "England", "ST", "Man United", 14, 26, 8),
          S("Zlatan Ibrahimovi\u0107", "Sweden", "ST", "Inter Milan", 16, 26, 8),
          S("Gianluigi Buffon", "Italy", "GK", "Juventus", 0, 0, 8),
          S("Didier Drogba", "Ivory Coast", "ST", "Chelsea", 15, 28, 8),
          S("Franck Rib\xE9ry", "France", "LW", "Bayern Munich", 10, 18, 7),
          S("David Villa", "Spain", "ST", "Valencia", 18, 28, 7),
          S("Andrea Pirlo", "Italy", "CM", "AC Milan", 4, 9, 7),
          S("John Terry", "England", "CB", "Chelsea", 1, 4, 6)
        ],
        topClubs: ["Barcelona", "AC Milan", "Liverpool", "Man United", "Chelsea", "Real Madrid", "Inter Milan", "Bayern Munich", "Arsenal", "Juventus"],
        uclExtras: ["Lyon", "Porto", "Sevilla", "Valencia", "Roma", "PSV"],
        leagues: {
          "Premier League": ["Man United", "Chelsea", "Arsenal", "Liverpool", "Tottenham", "Everton"],
          "La Liga": ["Barcelona", "Real Madrid", "Valencia", "Sevilla", "Villarreal"],
          "Bundesliga": ["Bayern Munich", "Werder Bremen", "Stuttgart", "Wolfsburg", "Dortmund"],
          "Serie A": ["Inter Milan", "AC Milan", "Juventus", "Roma", "Fiorentina"],
          "Ligue 1": ["Lyon", "Marseille", "Bordeaux", "PSG", "Monaco"],
          "Primeira Liga": ["Porto", "Benfica", "Sporting CP"],
          "Eredivisie": ["PSV", "Ajax", "AZ Alkmaar", "Feyenoord"],
          "Scottish Premiership": ["Celtic", "Rangers", "Aberdeen"],
          "Brasileirao": ["Sao Paulo", "Corinthians", "Flamengo", "Internacional"],
          "Saudi Pro League": ["Al Hilal", "Al Ittihad", "Al Shabab"],
          "MLS": ["LA Galaxy", "Houston Dynamo", "Columbus Crew"]
        },
        rivalFirsts: ["Fernando", "Diego", "Andr\xE9s", "Wesley", "Robin", "Arjen", "Franck", "Ricardo", "Milan", "Dimitar", "Emmanuel", "Obafemi", "Landon", "Gonzalo", "Sergio", "Karim", "Cesc", "Theo", "Mikel", "Klaas"]
      },
      {
        from: 2010,
        to: 2014,
        stars: [
          S("Lionel Messi", "Argentina", "RW", "Barcelona", 35, 55, 10),
          S("Cristiano Ronaldo", "Portugal", "ST", "Real Madrid", 35, 55, 10),
          S("Xavi", "Spain", "CM", "Barcelona", 4, 10, 8),
          S("Andr\xE9s Iniesta", "Spain", "CM", "Barcelona", 4, 9, 9),
          S("Neymar", "Brazil", "LW", "Santos", 15, 28, 8),
          S("Zlatan Ibrahimovi\u0107", "Sweden", "ST", "PSG", 20, 32, 8),
          S("Wayne Rooney", "England", "ST", "Man United", 15, 27, 7),
          S("Franck Rib\xE9ry", "France", "LW", "Bayern Munich", 10, 18, 9),
          S("Arjen Robben", "Netherlands", "RW", "Bayern Munich", 12, 20, 8),
          S("Radamel Falcao", "Colombia", "ST", "Atletico Madrid", 22, 32, 7),
          S("Gareth Bale", "Wales", "RW", "Tottenham", 14, 22, 8),
          S("Luis Su\xE1rez", "Uruguay", "ST", "Liverpool", 22, 32, 8),
          S("Robert Lewandowski", "Poland", "ST", "Dortmund", 20, 30, 8),
          S("Sergio Ag\xFCero", "Argentina", "ST", "Man City", 20, 30, 8),
          S("Manuel Neuer", "Germany", "GK", "Bayern Munich", 0, 0, 9),
          S("Thomas M\xFCller", "Germany", "CAM", "Bayern Munich", 12, 22, 8),
          S("Sergio Ramos", "Spain", "CB", "Real Madrid", 3, 6, 7),
          S("Yaya Tour\xE9", "Ivory Coast", "CM", "Man City", 12, 20, 7),
          S("Eden Hazard", "Belgium", "LW", "Chelsea", 12, 18, 7),
          S("Andrea Pirlo", "Italy", "CM", "Juventus", 3, 7, 7),
          S("James Rodr\xEDguez", "Colombia", "CAM", "Porto", 10, 16, 6)
        ],
        topClubs: ["Barcelona", "Real Madrid", "Bayern Munich", "Chelsea", "Inter Milan", "Man United", "Dortmund", "Atletico Madrid", "Man City", "Juventus"],
        uclExtras: ["PSG", "Liverpool", "Porto", "Napoli", "Sevilla", "AC Milan"],
        leagues: {
          "Premier League": ["Man United", "Man City", "Chelsea", "Arsenal", "Liverpool", "Tottenham"],
          "La Liga": ["Barcelona", "Real Madrid", "Atletico Madrid", "Valencia", "Sevilla"],
          "Bundesliga": ["Bayern Munich", "Dortmund", "Leverkusen", "Schalke"],
          "Serie A": ["Juventus", "AC Milan", "Inter Milan", "Napoli", "Roma"],
          "Ligue 1": ["PSG", "Marseille", "Lyon", "Monaco", "Lille"],
          "Primeira Liga": ["Porto", "Benfica", "Braga", "Sporting CP"],
          "Eredivisie": ["Ajax", "Twente", "PSV", "Feyenoord"],
          "Scottish Premiership": ["Celtic", "Rangers", "Aberdeen"],
          "Brasileirao": ["Fluminense", "Corinthians", "Cruzeiro", "Sao Paulo"],
          "Saudi Pro League": ["Al Hilal", "Al Nassr", "Al Shabab"],
          "MLS": ["LA Galaxy", "Sporting Kansas City", "Real Salt Lake"],
          "K League 1": ["FC Seoul", "Jeonbuk Motors", "Pohang Steelers", "Ulsan HD"]
        },
        rivalFirsts: ["Eden", "Isco", "Paulo", "Romelu", "Memphis", "Alexis", "\xC1ngel", "Edinson", "Mario", "Marco", "Antoine", "Ousmane", "Leroy", "Kingsley", "Dele", "Raheem", "Thiago", "Ciro", "James", "Granit"]
      },
      {
        from: 2015,
        to: 2019,
        stars: [
          S("Lionel Messi", "Argentina", "RW", "Barcelona", 30, 50, 10),
          S("Cristiano Ronaldo", "Portugal", "ST", "Real Madrid", 28, 48, 10),
          S("Neymar", "Brazil", "LW", "PSG", 18, 30, 8),
          S("Luis Su\xE1rez", "Uruguay", "ST", "Barcelona", 24, 40, 8),
          S("Antoine Griezmann", "France", "ST", "Atletico Madrid", 16, 26, 8),
          S("Kylian Mbapp\xE9", "France", "ST", "PSG", 18, 33, 9),
          S("Mohamed Salah", "Egypt", "RW", "Liverpool", 20, 32, 9),
          S("Kevin De Bruyne", "Belgium", "CAM", "Man City", 8, 16, 9),
          S("Eden Hazard", "Belgium", "LW", "Chelsea", 12, 21, 8),
          S("Luka Modri\u0107", "Croatia", "CM", "Real Madrid", 3, 8, 9),
          S("Robert Lewandowski", "Poland", "ST", "Bayern Munich", 25, 40, 9),
          S("Sergio Ag\xFCero", "Argentina", "ST", "Man City", 18, 28, 7),
          S("Harry Kane", "England", "ST", "Tottenham", 22, 32, 8),
          S("Sadio Man\xE9", "Senegal", "LW", "Liverpool", 16, 26, 8),
          S("Virgil van Dijk", "Netherlands", "CB", "Liverpool", 2, 6, 9),
          S("Gareth Bale", "Wales", "RW", "Real Madrid", 10, 18, 7),
          S("Paulo Dybala", "Argentina", "CAM", "Juventus", 12, 22, 7),
          S("N'Golo Kant\xE9", "France", "CDM", "Chelsea", 2, 5, 8),
          S("Raheem Sterling", "England", "LW", "Man City", 15, 25, 7),
          S("Alisson Becker", "Brazil", "GK", "Liverpool", 0, 0, 7)
        ],
        topClubs: ["Real Madrid", "Barcelona", "Bayern Munich", "Liverpool", "Atletico Madrid", "Juventus", "Man City", "PSG", "Tottenham", "Ajax"],
        uclExtras: ["Roma", "Monaco", "Napoli", "Dortmund", "Sevilla", "Porto"],
        leagues: {
          "Premier League": ["Man City", "Liverpool", "Chelsea", "Tottenham", "Arsenal", "Man United"],
          "La Liga": ["Barcelona", "Real Madrid", "Atletico Madrid", "Sevilla", "Valencia"],
          "Bundesliga": ["Bayern Munich", "Dortmund", "Leipzig", "Leverkusen"],
          "Serie A": ["Juventus", "Napoli", "Roma", "Inter Milan", "AC Milan"],
          "Ligue 1": ["PSG", "Monaco", "Lyon", "Marseille", "Lille"],
          "Primeira Liga": ["Benfica", "Porto", "Sporting CP"],
          "Eredivisie": ["PSV", "Ajax", "Feyenoord"],
          "Scottish Premiership": ["Celtic", "Rangers", "Aberdeen"],
          "Brasileirao": ["Palmeiras", "Corinthians", "Flamengo", "Santos"],
          "Saudi Pro League": ["Al Hilal", "Al Nassr", "Al Ahli"],
          "MLS": ["Seattle Sounders", "Toronto FC", "Atlanta United", "Portland Timbers"],
          "K League 1": ["Jeonbuk Motors", "FC Seoul", "Ulsan HD"]
        },
        rivalFirsts: ["Eden", "Isco", "Paulo", "Romelu", "Memphis", "Alexis", "\xC1ngel", "Edinson", "Mario", "Marco", "Antoine", "Ousmane", "Leroy", "Kingsley", "Dele", "Raheem", "Thiago", "Ciro", "James", "Granit"]
      },
      {
        from: 2020,
        to: 2024,
        stars: [
          S("Lionel Messi", "Argentina", "RW", "PSG", 16, 30, 10),
          S("Robert Lewandowski", "Poland", "ST", "Barcelona", 30, 48, 10),
          S("Karim Benzema", "France", "ST", "Real Madrid", 22, 40, 10),
          S("Kylian Mbapp\xE9", "France", "ST", "PSG", 25, 42, 9),
          S("Erling Haaland", "Norway", "ST", "Man City", 28, 48, 9),
          S("Kevin De Bruyne", "Belgium", "CAM", "Man City", 7, 15, 8),
          S("Mohamed Salah", "Egypt", "RW", "Liverpool", 18, 30, 8),
          S("Vin\xEDcius Jr", "Brazil", "LW", "Real Madrid", 15, 26, 9),
          S("Jude Bellingham", "England", "CAM", "Dortmund", 12, 23, 8),
          S("Rodri", "Spain", "CDM", "Man City", 4, 10, 9),
          S("Luka Modri\u0107", "Croatia", "CM", "Real Madrid", 2, 6, 7),
          S("Harry Kane", "England", "ST", "Tottenham", 25, 40, 8),
          S("Neymar", "Brazil", "LW", "PSG", 12, 22, 7),
          S("Lautaro Mart\xEDnez", "Argentina", "ST", "Inter Milan", 18, 28, 7),
          S("Bukayo Saka", "England", "RW", "Arsenal", 12, 22, 7),
          S("Phil Foden", "England", "CAM", "Man City", 12, 20, 7),
          S("Federico Valverde", "Uruguay", "CM", "Real Madrid", 5, 12, 7),
          S("Antoine Griezmann", "France", "CAM", "Atletico Madrid", 12, 20, 7),
          S("Virgil van Dijk", "Netherlands", "CB", "Liverpool", 2, 5, 7),
          S("Thibaut Courtois", "Belgium", "GK", "Real Madrid", 0, 0, 7)
        ],
        topClubs: ["Real Madrid", "Man City", "Bayern Munich", "Chelsea", "Liverpool", "PSG", "Inter Milan", "Barcelona", "Arsenal", "Dortmund"],
        uclExtras: ["Atletico Madrid", "Napoli", "Benfica", "Porto", "AC Milan", "Ajax"],
        leagues: {
          "Premier League": ["Man City", "Liverpool", "Arsenal", "Chelsea", "Man United", "Tottenham"],
          "La Liga": ["Real Madrid", "Barcelona", "Atletico Madrid", "Sevilla", "Real Sociedad"],
          "Bundesliga": ["Bayern Munich", "Dortmund", "Leipzig", "Leverkusen"],
          "Serie A": ["Inter Milan", "AC Milan", "Napoli", "Juventus", "Atalanta"],
          "Ligue 1": ["PSG", "Marseille", "Monaco", "Lille", "Lyon"],
          "Primeira Liga": ["Porto", "Sporting CP", "Benfica", "Braga"],
          "Eredivisie": ["Ajax", "PSV", "Feyenoord"],
          "Scottish Premiership": ["Celtic", "Rangers", "Hearts"],
          "Brasileirao": ["Palmeiras", "Flamengo", "Atletico Mineiro", "Botafogo"],
          "Saudi Pro League": ["Al Hilal", "Al Ittihad", "Al Nassr"],
          "MLS": ["LAFC", "Columbus Crew", "LA Galaxy", "Inter Miami"],
          "K League 1": ["Ulsan HD", "Jeonbuk Motors", "Pohang Steelers"]
        },
        rivalFirsts: ["Kylian", "Erling", "Jude", "Bukayo", "Lamine", "Jamal", "Florian", "Pablo", "Jules", "Aur\xE9lien", "Eduardo", "Rasmus", "Cole", "Alejandro", "Xavi", "Kenan", "Arda", "Endrick", "Mathys", "Kobbie"]
      },
      {
        from: 2025,
        to: 2029,
        stars: [
          S("Kylian Mbapp\xE9", "France", "ST", "Real Madrid", 28, 45, 10),
          S("Erling Haaland", "Norway", "ST", "Man City", 28, 46, 9),
          S("Jude Bellingham", "England", "CAM", "Real Madrid", 12, 24, 9),
          S("Vin\xEDcius Jr", "Brazil", "LW", "Real Madrid", 16, 28, 9),
          S("Lamine Yamal", "Spain", "RW", "Barcelona", 14, 28, 10),
          S("Florian Wirtz", "Germany", "CAM", "Liverpool", 10, 22, 8),
          S("Jamal Musiala", "Germany", "CAM", "Bayern Munich", 10, 20, 8),
          S("Bukayo Saka", "England", "RW", "Arsenal", 12, 24, 8),
          S("Pedri", "Spain", "CM", "Barcelona", 4, 12, 8),
          S("Rodri", "Spain", "CDM", "Barcelona", 3, 9, 8),
          S("Federico Valverde", "Uruguay", "CM", "Real Madrid", 6, 12, 7),
          S("Harry Kane", "England", "ST", "Bayern Munich", 24, 38, 8),
          S("Mohamed Salah", "Egypt", "RW", "Trabzonspor", 16, 28, 7),
          S("Phil Foden", "England", "CAM", "Man City", 10, 20, 7),
          S("Declan Rice", "England", "CDM", "Arsenal", 4, 10, 7),
          S("Raphinha", "Brazil", "RW", "Barcelona", 14, 26, 8),
          S("Endrick", "Brazil", "ST", "Real Madrid", 12, 24, 7),
          S("Nico Williams", "Spain", "LW", "Athletic Bilbao", 10, 20, 7),
          S("D\xE9sir\xE9 Dou\xE9", "France", "LW", "PSG", 8, 18, 7),
          S("Kobbie Mainoo", "England", "CM", "Man United", 3, 10, 6),
          S("Gianluigi Donnarumma", "Italy", "GK", "Man City", 0, 0, 7),
          S("Ousmane Demb\xE9l\xE9", "France", "LW", "PSG", 14, 28, 9)
        ],
        topClubs: ["Real Madrid", "Man City", "Barcelona", "Bayern Munich", "Arsenal", "Liverpool", "PSG", "Inter Milan", "Leverkusen", "Chelsea"],
        uclExtras: ["Newcastle", "Atletico Madrid", "Napoli", "Benfica", "Dortmund", "Juventus"],
        leagues: {
          "Premier League": ["Man City", "Arsenal", "Liverpool", "Chelsea", "Man United", "Newcastle"],
          "La Liga": ["Real Madrid", "Barcelona", "Atletico Madrid", "Athletic Bilbao", "Girona"],
          "Bundesliga": ["Bayern Munich", "Leverkusen", "Dortmund", "Leipzig"],
          "Serie A": ["Inter Milan", "Napoli", "AC Milan", "Juventus", "Atalanta"],
          "Ligue 1": ["PSG", "Monaco", "Marseille", "Lille", "Lyon"],
          "Primeira Liga": ["Sporting CP", "Benfica", "Porto"],
          "Eredivisie": ["PSV", "Ajax", "Feyenoord"],
          "Scottish Premiership": ["Celtic", "Rangers", "Aberdeen"],
          "Brasileirao": ["Flamengo", "Palmeiras", "Botafogo", "Cruzeiro"],
          "Saudi Pro League": ["Al Ittihad", "Al Hilal", "Al Nassr"],
          "MLS": ["Inter Miami", "LAFC", "Columbus Crew", "Seattle Sounders"],
          "K League 1": ["Jeonbuk Motors", "Ulsan HD", "Pohang Steelers"]
        },
        rivalFirsts: ["Kylian", "Erling", "Jude", "Bukayo", "Lamine", "Jamal", "Florian", "Pablo", "Jules", "Aur\xE9lien", "Eduardo", "Rasmus", "Cole", "Alejandro", "Xavi", "Kenan", "Arda", "Endrick", "Mathys", "Kobbie"]
      }
    ];
    CLUB_FOUNDED_AFTER = {
      "Leipzig": 2010,
      "RB Leipzig": 2010,
      "Inter Miami": 2020,
      "LAFC": 2018,
      "Los Angeles FC": 2018,
      "New York City FC": 2015,
      "Austin FC": 2021,
      "Charlotte FC": 2022,
      // Round 54 club expansion: keep the new-world clubs out of eras where they
      // did not exist yet (or were not professional outfits yet).
      "Toronto FC": 2006,
      "Vancouver Whitecaps": 2011,
      "Melbourne Victory": 2004,
      "Wellington Phoenix": 2007,
      "Auckland FC": 2024,
      "Mumbai City": 2014,
      "Buriram United": 2012,
      "Hanoi FC": 2006,
      "Al Duhail": 2009,
      "Shanghai Port": 2005,
      "Sheriff Tiraspol": 1997,
      "Beijing Guoan": 1992,
      /* Round 302 league depth pass. MLS kicked off in 1996, so its two founding
         era clubs date from there (a gap this table had all along for LA Galaxy),
         and the newer franchises from their own first seasons. */
      "LA Galaxy": 1996,
      "Columbus Crew": 1996,
      "Seattle Sounders": 2007,
      "Atlanta United": 2017,
      /* Round 1013: the club played as Bragantino until Red Bull's rebrand for
         the 2020 season (Planet Football's Red Bull in Brazil piece, and Lance!'s
         2020 badge and kit launch, read 2026-10-05). Same rule as RB Leipzig: the
         name did not exist before then. */
      "Red Bull Bragantino": 2020
    };
    ERA_TIER_RULES = [
      { name: "Man City", until: 2008, tier: 4 },
      { name: "Man City", until: 2010, tier: 2 },
      { name: "Chelsea", until: 1996, tier: 3 },
      { name: "Chelsea", until: 2003, tier: 2 },
      { name: "PSG", until: 2011, tier: 2 },
      { name: "Arsenal", until: 1996, tier: 2 },
      { name: "Liverpool", until: 2e3, tier: 2 },
      { name: "AC Milan", until: 2011, tier: 1 },
      { name: "Napoli", until: 1992, tier: 2 },
      { name: "Napoli", until: 2010, tier: 4 },
      { name: "Newcastle", from: 2007, until: 2021, tier: 3 },
      { name: "Tottenham", until: 2009, tier: 3 },
      { name: "Atletico Madrid", until: 2010, tier: 3 },
      { name: "Dortmund", until: 1993, tier: 3 },
      { name: "Dortmund", until: 2002, tier: 1 },
      { name: "Monaco", until: 2004, tier: 2 },
      { name: "Marseille", until: 1993, tier: 1 },
      { name: "Al Hilal", until: 2022, tier: 4 },
      { name: "Al Nassr", until: 2022, tier: 4 },
      { name: "Leipzig", until: 2015, tier: 4 },
      // Round 54: era-honest tiers for the expansion clubs
      { name: "Girona", until: 2022, tier: 4 },
      { name: "Al Ittihad", until: 2022, tier: 4 },
      { name: "Brighton", until: 2016, tier: 4 },
      { name: "Brighton", until: 2021, tier: 3 },
      { name: "Wolves", until: 2017, tier: 4 },
      { name: "Zenit", until: 2006, tier: 4 },
      { name: "Shakhtar Donetsk", until: 1999, tier: 4 },
      /* Round 1013: Forest were relegated in 1999 and came back up through the
         2022 Championship play-off final, so 1999-00 to 2021-22 were spent
         outside the top flight (ESPN's 29 May 2022 match report and Sports
         Illustrated the same day, "the first time since 1999"). Their tier 2 is
         Club Manager's 2026 XI and would otherwise apply in every era. The two
         earlier second tier seasons, 1993-94 (Division One runners up) and
         1997-98 (Division One champions), get one season rules of their own
         (rsssf's Football League tables for both seasons and Wikipedia's list
         of the club's seasons, read 2026-10-05). */
      { name: "Nottingham Forest", from: 1993, until: 1993, tier: 4 },
      { name: "Nottingham Forest", from: 1997, until: 1997, tier: 4 },
      { name: "Nottingham Forest", from: 1999, until: 2021, tier: 4 }
    ];
  }
});

// src/data/clubRivalries.ts
var SC_CLUB_CANON;
var init_clubRivalries = __esm({
  "src/data/clubRivalries.ts"() {
    SC_CLUB_CANON = {
      "Man City": "Manchester City",
      "Man United": "Manchester United",
      "Athletic Bilbao": "Athletic Club",
      "Atletico Madrid": "Atl\xE9tico Madrid",
      "Dortmund": "Borussia Dortmund",
      "Frankfurt": "Eintracht Frankfurt",
      "Leipzig": "RB Leipzig",
      "Leverkusen": "Bayer Leverkusen",
      "Hertha Berlin": "Hertha BSC",
      "Vitoria Guimaraes": "Vit\xF3ria Guimar\xE3es",
      "Sao Paulo": "S\xE3o Paulo",
      "Gremio": "Gr\xEAmio",
      "Chivas": "Guadalajara",
      "Club America": "Am\xE9rica",
      "Pumas": "Pumas UNAM",
      "Al Hilal": "Al-Hilal",
      "Al Nassr": "Al-Nassr",
      "Al Ittihad": "Al-Ittihad",
      "Al Ahli": "Al-Ahli",
      "Al Shabab": "Al-Shabab",
      "Fenerbahce": "Fenerbah\xE7e",
      "Besiktas": "Be\u015Fikta\u015F",
      /* Round 1013's clubs that the shared table names under another spelling
         (scripts/lib/careerClubPool.mjs NAME_ALIASES has the same two, the other
         way round; simCareerDerbies section 1 holds the two maps together). */
      "Deportivo": "Deportivo La Coru\xF1a",
      "Atletico Mineiro": "Atl\xE9tico Mineiro"
    };
  }
});

// src/data/careerLeagueSeasons.ts
var CAREER_LEAGUE_SEASONS;
var init_careerLeagueSeasons = __esm({
  "src/data/careerLeagueSeasons.ts"() {
    CAREER_LEAGUE_SEASONS = {
      "Premier League": {
        1990: { name: "First Division", size: 20, clubs: ["Arsenal", "Liverpool", "Crystal Palace", "Leeds United", "Man City", "Man United", "Nottingham Forest", "Everton", "Tottenham", "Chelsea", "QPR", "Sheffield United", "Southampton", "Norwich City", "Coventry City", "Aston Villa", "Sunderland", "Derby County"], others: ["wimbledon", "luton town"] },
        1991: { name: "First Division", size: 22, clubs: ["Leeds United", "Man United", "Arsenal", "Man City", "Liverpool", "Aston Villa", "Nottingham Forest", "Sheffield United", "Crystal Palace", "QPR", "Everton", "Chelsea", "Tottenham", "Southampton", "Norwich City", "Coventry City", "West Ham"], others: ["sheffield wednesday", "wimbledon", "oldham athletic", "luton town", "notts county"] },
        1992: { name: "Premier League", size: 22, clubs: ["Man United", "Aston Villa", "Norwich City", "Blackburn Rovers", "QPR", "Liverpool", "Tottenham", "Man City", "Arsenal", "Chelsea", "Everton", "Sheffield United", "Coventry City", "Ipswich Town", "Leeds United", "Southampton", "Crystal Palace", "Middlesbrough", "Nottingham Forest"], others: ["sheffield wednesday", "wimbledon", "oldham athletic"] },
        1993: { name: "Premier League", size: 22, clubs: ["Man United", "Blackburn Rovers", "Newcastle", "Arsenal", "Leeds United", "Liverpool", "QPR", "Aston Villa", "Coventry City", "Norwich City", "West Ham", "Chelsea", "Tottenham", "Man City", "Everton", "Southampton", "Ipswich Town", "Sheffield United"], others: ["wimbledon", "sheffield wednesday", "oldham athletic", "swindon town"] },
        1994: { name: "Premier League", size: 22, clubs: ["Blackburn Rovers", "Man United", "Nottingham Forest", "Liverpool", "Leeds United", "Newcastle", "Tottenham", "QPR", "Southampton", "Chelsea", "Arsenal", "West Ham", "Everton", "Coventry City", "Man City", "Aston Villa", "Crystal Palace", "Norwich City", "Ipswich Town"], others: ["wimbledon", "sheffield wednesday", "leicester city"] },
        1995: { name: "Premier League", size: 20, clubs: ["Man United", "Newcastle", "Liverpool", "Aston Villa", "Arsenal", "Everton", "Blackburn Rovers", "Tottenham", "Nottingham Forest", "West Ham", "Chelsea", "Middlesbrough", "Leeds United", "Coventry City", "Southampton", "Man City", "QPR", "Bolton Wanderers"], others: ["wimbledon", "sheffield wednesday"] },
        1996: { name: "Premier League", size: 20, clubs: ["Man United", "Newcastle", "Arsenal", "Liverpool", "Aston Villa", "Chelsea", "Tottenham", "Leeds United", "Derby County", "Blackburn Rovers", "West Ham", "Everton", "Southampton", "Coventry City", "Sunderland", "Middlesbrough", "Nottingham Forest"], others: ["sheffield wednesday", "wimbledon", "leicester city"] },
        1997: { name: "Premier League", size: 20, clubs: ["Arsenal", "Man United", "Liverpool", "Chelsea", "Leeds United", "Blackburn Rovers", "Aston Villa", "West Ham", "Derby County", "Coventry City", "Southampton", "Newcastle", "Tottenham", "Everton", "Bolton Wanderers", "Crystal Palace"], others: ["leicester city", "wimbledon", "sheffield wednesday", "barnsley"] },
        1998: { name: "Premier League", size: 20, clubs: ["Man United", "Arsenal", "Chelsea", "Leeds United", "West Ham", "Aston Villa", "Liverpool", "Derby County", "Middlesbrough", "Tottenham", "Newcastle", "Everton", "Coventry City", "Southampton", "Charlton Athletic", "Blackburn Rovers", "Nottingham Forest"], others: ["leicester city", "sheffield wednesday", "wimbledon"] },
        1999: { name: "Premier League", size: 20, clubs: ["Man United", "Arsenal", "Leeds United", "Liverpool", "Chelsea", "Aston Villa", "Sunderland", "West Ham", "Tottenham", "Newcastle", "Middlesbrough", "Everton", "Coventry City", "Southampton", "Derby County", "Watford"], others: ["leicester city", "bradford city", "wimbledon", "sheffield wednesday"] },
        2e3: { name: "Premier League", size: 20, clubs: ["Man United", "Arsenal", "Liverpool", "Leeds United", "Ipswich Town", "Chelsea", "Sunderland", "Aston Villa", "Charlton Athletic", "Southampton", "Newcastle", "Tottenham", "Middlesbrough", "West Ham", "Everton", "Derby County", "Man City", "Coventry City"], others: ["leicester city", "bradford city"] },
        2001: { name: "Premier League", size: 20, clubs: ["Arsenal", "Liverpool", "Man United", "Newcastle", "Leeds United", "Chelsea", "West Ham", "Aston Villa", "Tottenham", "Blackburn Rovers", "Southampton", "Middlesbrough", "Fulham", "Charlton Athletic", "Everton", "Bolton Wanderers", "Sunderland", "Ipswich Town", "Derby County"], others: ["leicester city"] },
        2002: { name: "Premier League", size: 20, clubs: ["Man United", "Arsenal", "Newcastle", "Chelsea", "Liverpool", "Blackburn Rovers", "Everton", "Southampton", "Man City", "Tottenham", "Middlesbrough", "Charlton Athletic", "Birmingham City", "Fulham", "Leeds United", "Aston Villa", "Bolton Wanderers", "West Ham", "West Brom", "Sunderland"], others: [] },
        2003: { name: "Premier League", size: 20, clubs: ["Arsenal", "Chelsea", "Man United", "Liverpool", "Newcastle", "Aston Villa", "Charlton Athletic", "Bolton Wanderers", "Fulham", "Birmingham City", "Middlesbrough", "Southampton", "Portsmouth", "Tottenham", "Blackburn Rovers", "Man City", "Everton", "Leeds United", "Wolves"], others: ["leicester city"] },
        2004: { name: "Premier League", size: 20, clubs: ["Chelsea", "Arsenal", "Man United", "Everton", "Liverpool", "Bolton Wanderers", "Middlesbrough", "Man City", "Tottenham", "Aston Villa", "Charlton Athletic", "Birmingham City", "Fulham", "Newcastle", "Blackburn Rovers", "Portsmouth", "West Brom", "Crystal Palace", "Norwich City", "Southampton"], others: [] },
        2005: { name: "Premier League", size: 20, clubs: ["Chelsea", "Man United", "Liverpool", "Arsenal", "Tottenham", "Blackburn Rovers", "Newcastle", "Bolton Wanderers", "West Ham", "Everton", "Fulham", "Charlton Athletic", "Middlesbrough", "Man City", "Aston Villa", "Portsmouth", "Birmingham City", "West Brom", "Sunderland"], others: ["wigan athleitc|wigan athletic"] },
        2006: { name: "Premier League", size: 20, clubs: ["Man United", "Chelsea", "Liverpool", "Arsenal", "Tottenham", "Everton", "Bolton Wanderers", "Portsmouth", "Blackburn Rovers", "Aston Villa", "Middlesbrough", "Newcastle", "Man City", "West Ham", "Fulham", "Sheffield United", "Charlton Athletic", "Watford"], others: ["reading", "wigan athletic"] },
        2007: { name: "Premier League", size: 20, clubs: ["Man United", "Chelsea", "Arsenal", "Liverpool", "Everton", "Aston Villa", "Blackburn Rovers", "Portsmouth", "Man City", "West Ham", "Tottenham", "Newcastle", "Middlesbrough", "Sunderland", "Bolton Wanderers", "Fulham", "Birmingham City", "Derby County"], others: ["wigan athletic", "reading"] },
        2008: { name: "Premier League", size: 20, clubs: ["Man United", "Liverpool", "Chelsea", "Arsenal", "Everton", "Aston Villa", "Fulham", "Tottenham", "West Ham", "Man City", "Stoke City", "Bolton Wanderers", "Portsmouth", "Blackburn Rovers", "Sunderland", "Hull City", "Newcastle", "Middlesbrough", "West Brom"], others: ["wigan athletic"] },
        2009: { name: "Premier League", size: 20, clubs: ["Chelsea", "Man United", "Arsenal", "Tottenham", "Man City", "Aston Villa", "Liverpool", "Everton", "Birmingham City", "Blackburn Rovers", "Stoke City", "Fulham", "Sunderland", "Bolton Wanderers", "Wolves", "West Ham", "Burnley", "Hull City", "Portsmouth"], others: ["wigan athletic"] },
        2010: { name: "Premier League", size: 20, clubs: ["Man United", "Chelsea", "Man City", "Arsenal", "Tottenham", "Liverpool", "Everton", "Fulham", "Aston Villa", "Sunderland", "West Brom", "Newcastle", "Stoke City", "Bolton Wanderers", "Blackburn Rovers", "Wolves", "Birmingham City", "West Ham"], others: ["wigan athletic", "blackpool"] },
        2011: { name: "Premier League", size: 20, clubs: ["Man City", "Man United", "Arsenal", "Tottenham", "Newcastle", "Chelsea", "Everton", "Liverpool", "Fulham", "West Brom", "Swansea City", "Norwich City", "Sunderland", "Stoke City", "Aston Villa", "QPR", "Bolton Wanderers", "Blackburn Rovers", "Wolves"], others: ["wigan athletic"] },
        2012: { name: "Premier League", size: 20, clubs: ["Man United", "Man City", "Chelsea", "Arsenal", "Tottenham", "Everton", "Liverpool", "West Brom", "Swansea City", "West Ham", "Norwich City", "Fulham", "Stoke City", "Southampton", "Aston Villa", "Newcastle", "Sunderland", "QPR"], others: ["wigan athletic", "reading"] },
        2013: { name: "Premier League", size: 20, clubs: ["Man City", "Liverpool", "Chelsea", "Arsenal", "Everton", "Tottenham", "Man United", "Southampton", "Stoke City", "Newcastle", "Crystal Palace", "Swansea City", "West Ham", "Sunderland", "Aston Villa", "Hull City", "West Brom", "Norwich City", "Fulham", "Cardiff City"], others: [] },
        2014: { name: "Premier League", size: 20, clubs: ["Chelsea", "Man City", "Arsenal", "Man United", "Tottenham", "Liverpool", "Southampton", "Swansea City", "Stoke City", "Crystal Palace", "Everton", "West Ham", "West Brom", "Newcastle", "Sunderland", "Aston Villa", "Hull City", "Burnley", "QPR"], others: ["leicester city"] },
        2015: { name: "Premier League", size: 20, clubs: ["Arsenal", "Tottenham", "Man City", "Man United", "Southampton", "West Ham", "Liverpool", "Stoke City", "Chelsea", "Everton", "Swansea City", "Watford", "West Brom", "Crystal Palace", "Bournemouth", "Sunderland", "Newcastle", "Norwich City", "Aston Villa"], others: ["leicester city"] },
        2016: { name: "Premier League", size: 20, clubs: ["Chelsea", "Tottenham", "Man City", "Liverpool", "Arsenal", "Man United", "Everton", "Southampton", "Bournemouth", "West Brom", "West Ham", "Stoke City", "Crystal Palace", "Swansea City", "Burnley", "Watford", "Hull City", "Middlesbrough", "Sunderland"], others: ["leicester city"] },
        2017: { name: "Premier League", size: 20, clubs: ["Man City", "Man United", "Tottenham", "Liverpool", "Chelsea", "Arsenal", "Burnley", "Everton", "Newcastle", "Crystal Palace", "Bournemouth", "West Ham", "Watford", "Brighton", "Southampton", "Swansea City", "Stoke City", "West Brom"], others: ["leicester city", "huddersfield town"] },
        2018: { name: "Premier League", size: 20, clubs: ["Man City", "Liverpool", "Chelsea", "Tottenham", "Arsenal", "Man United", "Wolves", "Everton", "West Ham", "Watford", "Crystal Palace", "Newcastle", "Bournemouth", "Burnley", "Southampton", "Brighton", "Cardiff City", "Fulham"], others: ["leicester city", "huddersfield town"] },
        2019: { name: "Premier League", size: 20, clubs: ["Liverpool", "Man City", "Man United", "Chelsea", "Tottenham", "Wolves", "Arsenal", "Sheffield United", "Burnley", "Southampton", "Everton", "Newcastle", "Crystal Palace", "Brighton", "West Ham", "Aston Villa", "Bournemouth", "Watford", "Norwich City"], others: ["leicester city"] },
        2020: { name: "Premier League", size: 20, clubs: ["Man City", "Man United", "Liverpool", "Chelsea", "West Ham", "Tottenham", "Arsenal", "Leeds United", "Everton", "Aston Villa", "Newcastle", "Wolves", "Crystal Palace", "Southampton", "Brighton", "Burnley", "Fulham", "West Brom", "Sheffield United"], others: ["leicester city"] },
        2021: { name: "Premier League", size: 20, clubs: ["Man City", "Liverpool", "Chelsea", "Tottenham", "Arsenal", "Man United", "West Ham", "Brighton", "Wolves", "Newcastle", "Crystal Palace", "Brentford", "Aston Villa", "Southampton", "Everton", "Leeds United", "Burnley", "Watford", "Norwich City"], others: ["leicester city"] },
        2022: { name: "Premier League", size: 20, clubs: ["Man City", "Arsenal", "Man United", "Newcastle", "Liverpool", "Brighton", "Aston Villa", "Tottenham", "Brentford", "Fulham", "Crystal Palace", "Chelsea", "Wolves", "West Ham", "Bournemouth", "Nottingham Forest", "Everton", "Leeds United", "Southampton"], others: ["leicester city"] },
        2023: { name: "Premier League", size: 20, clubs: ["Man City", "Arsenal", "Liverpool", "Aston Villa", "Tottenham", "Chelsea", "Newcastle", "Man United", "West Ham", "Crystal Palace", "Brighton", "Bournemouth", "Fulham", "Wolves", "Everton", "Brentford", "Nottingham Forest", "Burnley", "Sheffield United"], others: ["luton town"] },
        2024: { name: "Premier League", size: 20, clubs: ["Liverpool", "Arsenal", "Man City", "Chelsea", "Newcastle", "Aston Villa", "Nottingham Forest", "Brighton", "Bournemouth", "Brentford", "Fulham", "Crystal Palace", "Everton", "West Ham", "Man United", "Wolves", "Tottenham", "Ipswich Town", "Southampton"], others: ["leicester city"] },
        2025: { name: "Premier League", size: 20, clubs: ["Arsenal", "Man City", "Man United", "Aston Villa", "Liverpool", "Bournemouth", "Sunderland", "Brighton", "Brentford", "Chelsea", "Fulham", "Newcastle", "Everton", "Leeds United", "Crystal Palace", "Nottingham Forest", "Tottenham", "West Ham", "Burnley", "Wolves"], others: [] }
      },
      "Championship": {
        1990: { name: "Second Division", size: 24, clubs: ["West Ham", "Millwall", "Brighton", "Middlesbrough", "Bristol City", "Newcastle", "Wolves", "Ipswich Town", "Charlton Athletic", "Portsmouth", "Blackburn Rovers", "Watford", "West Brom", "Hull City"], others: ["oldham athletic", "sheffield wednesday", "notts county", "barnsley", "oxford united", "bristol rovers", "port vale", "plymouth argyle", "swindon town", "leicester city"] },
        1991: { name: "Second Division", size: 24, clubs: ["Ipswich Town", "Middlesbrough", "Derby County", "Blackburn Rovers", "Charlton Athletic", "Portsmouth", "Watford", "Wolves", "Millwall", "Bristol City", "Sunderland", "Newcastle", "Brighton"], others: ["leicester city", "cambridge united", "swindon town", "southend united", "bristol rovers", "tranmere rovers", "barnsley", "grimsby town", "oxford united", "plymouth argyle", "port vale"] },
        1992: { name: "First Division", size: 24, clubs: ["Newcastle", "West Ham", "Portsmouth", "Millwall", "Derby County", "Wolves", "Charlton Athletic", "Bristol City", "Watford", "Birmingham City", "Sunderland", "Brentford"], others: ["tranmere rovers", "swindon town", "leicester city", "grimsby town", "peterborough united", "barnsley", "oxford united", "notts county", "southend united", "luton town", "cambridge united", "bristol rovers"] },
        1993: { name: "First Division", size: 24, clubs: ["Crystal Palace", "Nottingham Forest", "Millwall", "Derby County", "Wolves", "Middlesbrough", "Stoke City", "Charlton Athletic", "Sunderland", "Bristol City", "Bolton Wanderers", "Portsmouth", "Watford", "West Brom", "Birmingham City"], others: ["leicester city", "tranmere rovers", "notts county", "southend united", "grimsby town", "barnsley", "luton town", "oxford united", "peterborough united"] },
        1994: { name: "First Division", size: 24, clubs: ["Middlesbrough", "Bolton Wanderers", "Wolves", "Watford", "Sheffield United", "Derby County", "Stoke City", "Millwall", "Charlton Athletic", "Portsmouth", "West Brom", "Sunderland", "Burnley", "Bristol City"], others: ["reading", "tranmere rovers", "barnsley", "grimsby town", "southend united", "oldham athletic", "luton town", "port vale", "swindon town", "notts county"] },
        1995: { name: "First Division", size: 24, clubs: ["Sunderland", "Derby County", "Crystal Palace", "Stoke City", "Charlton Athletic", "Ipswich Town", "Sheffield United", "West Brom", "Birmingham City", "Norwich City", "Wolves", "Portsmouth", "Millwall", "Watford"], others: ["leicester city", "huddersfield town", "barnsley", "port vale", "tranmere rovers", "southend united", "grimsby town", "oldham athletic", "reading", "luton town"] },
        1996: { name: "First Division", size: 24, clubs: ["Bolton Wanderers", "Wolves", "Ipswich Town", "Sheffield United", "Crystal Palace", "Portsmouth", "QPR", "Birmingham City", "Stoke City", "Norwich City", "Man City", "Charlton Athletic", "West Brom"], others: ["barnsley", "port vale", "tranmere rovers", "oxford united", "reading", "swindon town", "huddersfield town", "bradford city", "grimsby town", "oldham athletic", "southend united"] },
        1997: { name: "First Division", size: 24, clubs: ["Nottingham Forest", "Middlesbrough", "Sunderland", "Charlton Athletic", "Ipswich Town", "Sheffield United", "Birmingham City", "Wolves", "West Brom", "Norwich City", "Portsmouth", "QPR", "Man City", "Stoke City"], others: ["stockport county", "crewe alexandra", "oxford united", "bradford city", "tranmere rovers", "huddersfield town", "bury", "swindon town", "port vale", "reading"] },
        1998: { name: "First Division", size: 24, clubs: ["Sunderland", "Ipswich Town", "Birmingham City", "Watford", "Bolton Wanderers", "Wolves", "Sheffield United", "Norwich City", "West Brom", "Crystal Palace", "Portsmouth", "QPR", "Bristol City"], others: ["bradford city", "huddersfield town", "grimsby town", "barnsley", "tranmere rovers", "stockport county", "swindon town", "crewe alexandra", "port vale", "bury", "oxford united"] },
        1999: { name: "First Division", size: 24, clubs: ["Charlton Athletic", "Man City", "Ipswich Town", "Birmingham City", "Bolton Wanderers", "Wolves", "Fulham", "QPR", "Blackburn Rovers", "Norwich City", "Nottingham Forest", "Crystal Palace", "Sheffield United", "Portsmouth", "West Brom"], others: ["barnsley", "huddersfield town", "tranmere rovers", "stockport county", "crewe alexandra", "grimsby town", "walsall", "port vale", "swindon town"] },
        2e3: { name: "First Division", size: 24, clubs: ["Fulham", "Blackburn Rovers", "Bolton Wanderers", "Preston North End", "Birmingham City", "West Brom", "Burnley", "Watford", "Sheffield United", "Nottingham Forest", "Wolves", "Norwich City", "Portsmouth", "Crystal Palace", "QPR"], others: ["wimbledon", "gillingham", "crewe alexandra", "barnsley", "sheffield wednesday", "grimsby town", "stockport county", "huddersfield town", "tranmere rovers"] },
        2001: { name: "First Division", size: 24, clubs: ["Man City", "West Brom", "Wolves", "Millwall", "Birmingham City", "Norwich City", "Burnley", "Preston North End", "Crystal Palace", "Coventry City", "Sheffield United", "Watford", "Nottingham Forest", "Portsmouth"], others: ["wimbledon", "gillingham", "bradford city", "walsall", "grimsby town", "sheffield wednesday", "rotherham united", "crewe alexandra", "barnsley", "stockport county"] },
        2002: { name: "First Division", size: 24, clubs: ["Portsmouth", "Sheffield United", "Wolves", "Nottingham Forest", "Ipswich Town", "Norwich City", "Millwall", "Preston North End", "Watford", "Crystal Palace", "Burnley", "Derby County", "Coventry City", "Stoke City", "Brighton"], others: ["leicester city", "reading", "wimbledon|milton keynes dons", "gillingham", "rotherham united", "walsall", "bradford city", "sheffield wedsnesday|sheffield wednesday", "grimsby town"] },
        2003: { name: "First Division", size: 24, clubs: ["Norwich City", "West Brom", "Sunderland", "West Ham", "Ipswich Town", "Crystal Palace", "Sheffield United", "Millwall", "Stoke City", "Coventry City", "Cardiff City", "Nottingham Forest", "Preston North End", "Watford", "Burnley", "Derby County"], others: ["wigan athletic", "reading", "rotherham united", "crewe alexandra", "gillingham", "walsall", "bradford city", "wimbledon|milton keynes dons"] },
        2004: { name: "Championship", size: 24, clubs: ["Sunderland", "Ipswich Town", "Derby County", "Preston North End", "West Ham", "Sheffield United", "Wolves", "Millwall", "QPR", "Stoke City", "Burnley", "Leeds United", "Cardiff City", "Watford", "Coventry City", "Brighton", "Nottingham Forest"], others: ["wigan athletic", "reading", "leicester city", "plymouth argyle", "crewe alexandra", "gillingham", "rotherham united"] },
        2005: { name: "Championship", size: 24, clubs: ["Sheffield United", "Watford", "Preston North End", "Leeds United", "Crystal Palace", "Wolves", "Coventry City", "Norwich City", "Cardiff City", "Southampton", "Stoke City", "Ipswich Town", "Burnley", "Hull City", "Derby County", "QPR", "Millwall", "Brighton"], others: ["reading", "luton town", "plymouth argyle", "leicester city", "sheffield wednesday", "crewe alexandra"] },
        2006: { name: "Championship", size: 24, clubs: ["Sunderland", "Birmingham City", "Derby County", "West Brom", "Wolves", "Southampton", "Preston North End", "Stoke City", "Crystal Palace", "Cardiff City", "Ipswich Town", "Burnley", "Norwich City", "Coventry City", "QPR", "Hull City", "Leeds United"], others: ["sheffield wednesday", "colchester united", "plymouth argyle", "leicester city", "barnsley", "southend united", "luton town"] },
        2007: { name: "Championship", size: 24, clubs: ["West Brom", "Stoke City", "Hull City", "Bristol City", "Crystal Palace", "Watford", "Wolves", "Ipswich Town", "Sheffield United", "Charlton Athletic", "Cardiff City", "Burnley", "QPR", "Preston North End", "Norwich City", "Southampton", "Coventry City"], others: ["plymouth argyle", "sheffield wednesday", "barnsley", "blackpool", "leicester city", "scunthorpe united", "colchester united"] },
        2008: { name: "Championship", size: 24, clubs: ["Wolves", "Birmingham City", "Sheffield United", "Burnley", "Preston North End", "Cardiff City", "Swansea City", "Ipswich Town", "Bristol City", "QPR", "Watford", "Crystal Palace", "Coventry City", "Derby County", "Nottingham Forest", "Norwich City", "Southampton", "Charlton Athletic"], others: ["reading", "sheffield wednesday", "doncaster rovers", "blackpool", "barnsley", "plymouth argyle"] },
        2009: { name: "Championship", size: 24, clubs: ["Newcastle", "West Brom", "Nottingham Forest", "Cardiff City", "Swansea City", "Sheffield United", "Bristol City", "Middlesbrough", "QPR", "Derby County", "Ipswich Town", "Watford", "Preston North End", "Coventry City", "Crystal Palace"], others: ["leicester city", "blackpool", "reading", "doncaster rovers", "barnsley", "scunthorpe united", "sheffield wednesday", "plymouth argyle", "peterborough united"] },
        2010: { name: "Championship", size: 24, clubs: ["QPR", "Norwich City", "Swansea City", "Cardiff City", "Nottingham Forest", "Leeds United", "Burnley", "Millwall", "Hull City", "Middlesbrough", "Ipswich Town", "Watford", "Bristol City", "Portsmouth", "Coventry City", "Derby County", "Crystal Palace", "Preston North End", "Sheffield United"], others: ["reading", "leicester city", "barnsley", "doncaster rovers", "scunthorpe united"] },
        2011: { name: "Championship", size: 24, clubs: ["Southampton", "West Ham", "Birmingham City", "Cardiff City", "Middlesbrough", "Hull City", "Brighton", "Watford", "Derby County", "Burnley", "Leeds United", "Ipswich Town", "Millwall", "Crystal Palace", "Nottingham Forest", "Bristol City", "Portsmouth", "Coventry City"], others: ["reading", "blackpool", "leicester city", "peterborough united", "barnsley", "doncaster rovers"] },
        2012: { name: "Championship", size: 24, clubs: ["Cardiff City", "Hull City", "Watford", "Brighton", "Crystal Palace", "Bolton Wanderers", "Nottingham Forest", "Charlton Athletic", "Derby County", "Burnley", "Birmingham City", "Leeds United", "Ipswich Town", "Middlesbrough", "Blackburn Rovers", "Millwall", "Wolves", "Bristol City"], others: ["leicester city", "blackpool", "sheffield wednesday", "huddersfield town", "barnsley", "peterborough united"] },
        2013: { name: "Championship", size: 24, clubs: ["Burnley", "Derby County", "QPR", "Brighton", "Blackburn Rovers", "Ipswich Town", "Bournemouth", "Nottingham Forest", "Middlesbrough", "Watford", "Bolton Wanderers", "Leeds United", "Charlton Athletic", "Millwall", "Birmingham City"], others: ["leicester city", "wigan athletic", "reading", "sheffield wednesday", "huddersfield town", "blackpool", "doncaster rovers", "barnsley", "yeovil town"] },
        2014: { name: "Championship", size: 24, clubs: ["Bournemouth", "Watford", "Norwich City", "Middlesbrough", "Brentford", "Ipswich Town", "Wolves", "Derby County", "Blackburn Rovers", "Birmingham City", "Cardiff City", "Charlton Athletic", "Nottingham Forest", "Leeds United", "Fulham", "Bolton Wanderers", "Brighton", "Millwall"], others: ["sheffield wednesday", "huddersfield town", "reading", "rotherham united", "wigan athletic", "blackpool"] },
        2015: { name: "Championship", size: 24, clubs: ["Burnley", "Middlesbrough", "Brighton", "Hull City", "Derby County", "Ipswich Town", "Cardiff City", "Brentford", "Birmingham City", "Preston North End", "QPR", "Leeds United", "Wolves", "Blackburn Rovers", "Nottingham Forest", "Bristol City", "Fulham", "Charlton Athletic", "Bolton Wanderers"], others: ["sheffield wednesday", "reading", "huddersfield town", "rotherham united", "milton keynes dons"] },
        2016: { name: "Championship", size: 24, clubs: ["Newcastle", "Brighton", "Fulham", "Leeds United", "Norwich City", "Derby County", "Brentford", "Preston North End", "Cardiff City", "Aston Villa", "Wolves", "Ipswich Town", "Bristol City", "QPR", "Birmingham City", "Nottingham Forest", "Blackburn Rovers"], others: ["reading", "sheffield wednesday", "huddersfield town", "barnsley", "burton albion", "wigan athletic", "rotherham united"] },
        2017: { name: "Championship", size: 24, clubs: ["Wolves", "Cardiff City", "Fulham", "Aston Villa", "Middlesbrough", "Derby County", "Preston North End", "Millwall", "Brentford", "Sheffield United", "Bristol City", "Ipswich Town", "Leeds United", "Norwich City", "QPR", "Nottingham Forest", "Hull City", "Birmingham City", "Bolton Wanderers", "Sunderland"], others: ["sheffield wednesday", "reading", "barnsley", "burton albion"] },
        2018: { name: "Championship", size: 24, clubs: ["Norwich City", "Sheffield United", "Leeds United", "West Brom", "Aston Villa", "Derby County", "Middlesbrough", "Bristol City", "Nottingham Forest", "Swansea City", "Brentford", "Hull City", "Preston North End", "Blackburn Rovers", "Stoke City", "Birmingham City", "QPR", "Millwall", "Bolton Wanderers", "Ipswich Town"], others: ["sheffield wednesday", "wigan athletic", "reading", "rotherham united"] },
        2019: { name: "Championship", size: 24, clubs: ["Leeds United", "West Brom", "Brentford", "Fulham", "Cardiff City", "Swansea City", "Nottingham Forest", "Millwall", "Preston North End", "Derby County", "Blackburn Rovers", "Bristol City", "QPR", "Stoke City", "Middlesbrough", "Birmingham City", "Charlton Athletic", "Hull City"], others: ["reading", "sheffield wednesday", "huddersfield town", "luton town", "barnsley", "wigan athletic"] },
        2020: { name: "Championship", size: 24, clubs: ["Norwich City", "Watford", "Brentford", "Swansea City", "Bournemouth", "Cardiff City", "QPR", "Middlesbrough", "Millwall", "Preston North End", "Stoke City", "Blackburn Rovers", "Coventry City", "Nottingham Forest", "Birmingham City", "Bristol City", "Derby County"], others: ["barnsley", "reading", "luton town", "huddersfield town", "wycombe wanderers", "rotherham united", "sheffield wednesday"] },
        2021: { name: "Championship", size: 24, clubs: ["Fulham", "Bournemouth", "Nottingham Forest", "Sheffield United", "Middlesbrough", "Blackburn Rovers", "Millwall", "West Brom", "QPR", "Coventry City", "Preston North End", "Stoke City", "Swansea City", "Bristol City", "Cardiff City", "Hull City", "Birmingham City", "Derby County"], others: ["huddersfield town", "luton town", "blackpool", "reading", "peterborough united", "barnsley"] },
        2022: { name: "Championship", size: 24, clubs: ["Burnley", "Sheffield United", "Middlesbrough", "Coventry City", "Sunderland", "Blackburn Rovers", "Millwall", "West Brom", "Swansea City", "Watford", "Preston North End", "Norwich City", "Bristol City", "Hull City", "Stoke City", "Birmingham City", "QPR", "Cardiff City"], others: ["luton town", "huddersfield town", "rotherham united", "reading", "blackpool", "wigan athletic"] },
        2023: { name: "Championship", size: 24, clubs: ["Ipswich Town", "Leeds United", "Southampton", "West Brom", "Norwich City", "Hull City", "Middlesbrough", "Coventry City", "Preston North End", "Bristol City", "Cardiff City", "Millwall", "Swansea City", "Watford", "Sunderland", "Stoke City", "QPR", "Blackburn Rovers", "Birmingham City"], others: ["leicester city", "sheffield wednesday", "plymouth argyle", "huddersfield town", "rotherham united"] },
        2024: { name: "Championship", size: 24, clubs: ["Leeds United", "Burnley", "Sheffield United", "Sunderland", "Coventry City", "Bristol City", "Blackburn Rovers", "Millwall", "West Brom", "Middlesbrough", "Swansea City", "Norwich City", "Watford", "QPR", "Portsmouth", "Stoke City", "Derby County", "Preston North End", "Hull City", "Cardiff City"], others: ["sheffield wednesday", "oxford united", "luton town", "plymouth argyle"] },
        2025: { name: "Championship", size: 24, clubs: ["Coventry City", "Ipswich Town", "Millwall", "Southampton", "Middlesbrough", "Hull City", "Wrexham", "Derby County", "Norwich City", "Birmingham City", "Swansea City", "Bristol City", "Sheffield United", "Preston North End", "QPR", "Watford", "Stoke City", "Portsmouth", "Charlton Athletic", "Blackburn Rovers", "West Brom"], others: ["oxford united", "leicester city", "sheffield wednesday"] }
      },
      "La Liga": {
        1990: { name: "La Liga", size: 20, clubs: ["Barcelona", "Atletico Madrid", "Real Madrid", "Osasuna", "Valencia", "Sevilla", "Athletic Bilbao", "Real Sociedad", "Espanyol", "Real Betis"], others: ["sporting de gijon|sporting gijon", "real oviedo", "real valladolid", "logrones", "real burgos|burgos", "tenerife", "mallorca", "real zaragoza", "cadiz", "castellon"] },
        1991: { name: "La Liga", size: 20, clubs: ["Barcelona", "Real Madrid", "Atletico Madrid", "Valencia", "Real Sociedad", "Sevilla", "Athletic Bilbao", "Osasuna", "Espanyol", "Deportivo"], others: ["real zaragoza", "albacete", "sporting de gijon|sporting gijon", "real burgos|burgos", "logrones", "real oviedo", "tenerife", "cadiz", "real valladolid", "mallorca"] },
        1992: { name: "La Liga", size: 20, clubs: ["Barcelona", "Real Madrid", "Deportivo", "Valencia", "Atletico Madrid", "Sevilla", "Athletic Bilbao", "Osasuna", "Celta Vigo", "Real Sociedad", "Rayo Vallecano", "Espanyol"], others: ["tenerife", "real zaragoza", "sporting de gijon|sporting gijon", "logrones", "real oviedo", "albacete", "cadiz", "real burgos|burgos"] },
        1993: { name: "La Liga", size: 20, clubs: ["Barcelona", "Deportivo", "Real Madrid", "Athletic Bilbao", "Sevilla", "Valencia", "Racing Santander", "Real Sociedad", "Atletico Madrid", "Celta Vigo", "Rayo Vallecano", "Osasuna"], others: ["real zaragoza", "real oviedo", "tenerife", "albacete", "sporting de gijon|sporting gijon", "logrones", "real valladolid", "ue lleida|lleida"] },
        1994: { name: "La Liga", size: 20, clubs: ["Real Madrid", "Deportivo", "Real Betis", "Barcelona", "Sevilla", "Espanyol", "Athletic Bilbao", "Valencia", "Real Sociedad", "Racing Santander", "Celta Vigo", "Atletico Madrid"], others: ["real zaragoza", "real oviedo", "tenerife", "compostela", "albacete", "sporting de gijon|sporting gijon", "real valladolid", "logrones"] },
        1995: { name: "La Liga", size: 22, clubs: ["Atletico Madrid", "Valencia", "Barcelona", "Espanyol", "Real Madrid", "Real Sociedad", "Real Betis", "Deportivo", "Celta Vigo", "Sevilla", "Athletic Bilbao", "Racing Santander", "Rayo Vallecano"], others: ["tenerife", "compostela", "real zaragoza", "real oviedo", "real valladolid", "sporting de gijon|sporting gijon", "albacete", "merida cp|merida ad", "salamanca"] },
        1996: { name: "La Liga", size: 22, clubs: ["Real Madrid", "Barcelona", "Deportivo", "Real Betis", "Atletico Madrid", "Athletic Bilbao", "Real Sociedad", "Valencia", "Espanyol", "Racing Santander", "Celta Vigo", "Rayo Vallecano", "Sevilla"], others: ["real valladolid", "tenerife", "compostela", "real zaragoza", "sporting de gijon|sporting gijon", "real oviedo", "extremadura", "hercules", "logrones"] },
        1997: { name: "La Liga", size: 20, clubs: ["Barcelona", "Athletic Bilbao", "Real Sociedad", "Real Madrid", "Celta Vigo", "Atletico Madrid", "Real Betis", "Valencia", "Espanyol", "Deportivo", "Racing Santander"], others: ["mallorca", "real valladolid", "real zaragoza", "salamanca", "tenerife", "compostela", "real oviedo", "merida cp|merida ad", "sporting de gijon|sporting gijon"] },
        1998: { name: "La Liga", size: 20, clubs: ["Barcelona", "Real Madrid", "Valencia", "Celta Vigo", "Deportivo", "Espanyol", "Athletic Bilbao", "Real Sociedad", "Real Betis", "Atletico Madrid", "Racing Santander", "Alaves", "Villarreal"], others: ["mallorca", "real zaragoza", "real valladolid", "real oviedo", "extremadura", "tenerife", "salamanca"] },
        1999: { name: "La Liga", size: 20, clubs: ["Deportivo", "Barcelona", "Valencia", "Real Madrid", "Alaves", "Celta Vigo", "Rayo Vallecano", "Athletic Bilbao", "Malaga", "Real Sociedad", "Espanyol", "Racing Santander", "Real Betis", "Atletico Madrid", "Sevilla"], others: ["real zaragoza", "real valladolid", "mallorca", "real oviedo", "numancia"] },
        2e3: { name: "La Liga", size: 20, clubs: ["Real Madrid", "Deportivo", "Barcelona", "Valencia", "Celta Vigo", "Villarreal", "Malaga", "Espanyol", "Alaves", "Athletic Bilbao", "Real Sociedad", "Rayo Vallecano", "Osasuna", "Racing Santander"], others: ["mallorca", "las palmas", "real valladolid", "real zaragoza", "real oviedo", "numancia soria|numancia"] },
        2001: { name: "La Liga", size: 20, clubs: ["Valencia", "Deportivo", "Real Madrid", "Barcelona", "Celta Vigo", "Real Betis", "Alaves", "Athletic Bilbao", "Sevilla", "Malaga", "Rayo Vallecano", "Real Sociedad", "Espanyol", "Villarreal", "Osasuna"], others: ["real valladolid", "mallorca palma de m|mallorca", "las palmas", "tenerife santa cruz|tenerife", "real zaragoza"] },
        2002: { name: "La Liga", size: 20, clubs: ["Real Madrid", "Real Sociedad", "Deportivo", "Celta Vigo", "Valencia", "Barcelona", "Athletic Bilbao", "Real Betis", "Sevilla", "Atletico Madrid", "Osasuna", "Malaga", "Villarreal", "Racing Santander", "Espanyol", "Alaves", "Rayo Vallecano"], others: ["mallorca palma de m|mallorca", "real valladolid", "recreativo huelva"] },
        2003: { name: "La Liga", size: 20, clubs: ["Valencia", "Barcelona", "Deportivo", "Real Madrid", "Athletic Bilbao", "Sevilla", "Atletico Madrid", "Villarreal", "Real Betis", "Malaga", "Osasuna", "Real Sociedad", "Espanyol", "Racing Santander", "Celta Vigo"], others: ["mallorca palma de m|mallorca", "real zaragoza", "albacete balompie|albacete", "real valladolid", "real murcia"] },
        2004: { name: "La Liga", size: 20, clubs: ["Barcelona", "Real Madrid", "Villarreal", "Real Betis", "Espanyol", "Sevilla", "Valencia", "Deportivo", "Athletic Bilbao", "Malaga", "Atletico Madrid", "Getafe", "Real Sociedad", "Osasuna", "Racing Santander", "Levante"], others: ["real zaragoza", "mallorca palma de m|mallorca", "numancia soria|numancia", "albacete balompie|albacete"] },
        2005: { name: "La Liga", size: 20, clubs: ["Barcelona", "Real Madrid", "Valencia", "Osasuna", "Sevilla", "Celta Vigo", "Villarreal", "Deportivo", "Getafe", "Atletico Madrid", "Athletic Bilbao", "Real Betis", "Espanyol", "Real Sociedad", "Racing Santander", "Alaves", "Malaga"], others: ["real zaragoza", "mallorca palma de m|mallorca", "cadiz"] },
        2006: { name: "La Liga", size: 20, clubs: ["Real Madrid", "Barcelona", "Sevilla", "Valencia", "Villarreal", "Atletico Madrid", "Getafe", "Racing Santander", "Espanyol", "Deportivo", "Osasuna", "Levante", "Real Betis", "Athletic Bilbao", "Celta Vigo", "Real Sociedad"], others: ["real zaragoza", "recreativo de huelva|recreativo huelva", "mallorca palma de m|mallorca", "club gimnastic de tarragona|gimnastic de tarragona"] },
        2007: { name: "La Liga", size: 20, clubs: ["Real Madrid", "Villarreal", "Barcelona", "Atletico Madrid", "Sevilla", "Racing Santander", "Deportivo", "Valencia", "Athletic Bilbao", "Espanyol", "Real Betis", "Getafe", "Osasuna", "Levante"], others: ["mallorca palma de m|mallorca", "almeria", "real valladolid", "recreativo de huelva|recreativo huelva", "real zaragoza", "real murcia"] },
        2008: { name: "La Liga", size: 20, clubs: ["Barcelona", "Real Madrid", "Sevilla", "Atletico Madrid", "Villarreal", "Valencia", "Deportivo", "Malaga", "Espanyol", "Racing Santander", "Athletic Bilbao", "Osasuna", "Getafe", "Real Betis"], others: ["mallorca palma de m|mallorca", "almeria", "sporting de gijon|sporting gijon", "real valladolid", "numancia soria|numancia", "recreativo de huelva|recreativo huelva"] },
        2009: { name: "La Liga", size: 20, clubs: ["Barcelona", "Real Madrid", "Valencia", "Sevilla", "Getafe", "Villarreal", "Athletic Bilbao", "Atletico Madrid", "Deportivo", "Espanyol", "Osasuna", "Racing Santander", "Malaga"], others: ["mallorca palma de m|mallorca", "almeria", "real zaragoza", "sporting de gijon|sporting gijon", "real valladolid", "tenerife", "xerez"] },
        2010: { name: "La Liga", size: 20, clubs: ["Barcelona", "Real Madrid", "Valencia", "Villarreal", "Sevilla", "Athletic Bilbao", "Atletico Madrid", "Espanyol", "Osasuna", "Malaga", "Racing Santander", "Real Sociedad", "Levante", "Getafe", "Deportivo"], others: ["sporting de gijon|sporting gijon", "real zaragoza", "mallorca palma de m|mallorca", "hercules alicante|hercules", "almeria"] },
        2011: { name: "La Liga", size: 20, clubs: ["Real Madrid", "Barcelona", "Valencia", "Malaga", "Atletico Madrid", "Levante", "Osasuna", "Sevilla", "Athletic Bilbao", "Getafe", "Real Sociedad", "Real Betis", "Espanyol", "Rayo Vallecano", "Villarreal", "Racing Santander"], others: ["mallorca palma de m|mallorca", "real zaragoza", "granada", "sporting de gijon|sporting gijon"] },
        2012: { name: "La Liga", size: 20, clubs: ["Barcelona", "Real Madrid", "Atletico Madrid", "Real Sociedad", "Valencia", "Malaga", "Real Betis", "Rayo Vallecano", "Sevilla", "Getafe", "Levante", "Athletic Bilbao", "Espanyol", "Osasuna", "Celta Vigo", "Deportivo"], others: ["real valladolid", "granada", "mallorca palma de m|mallorca", "real zaragoza"] },
        2013: { name: "La Liga", size: 20, clubs: ["Atletico Madrid", "Barcelona", "Real Madrid", "Athletic Bilbao", "Sevilla", "Villarreal", "Real Sociedad", "Valencia", "Celta Vigo", "Levante", "Malaga", "Rayo Vallecano", "Getafe", "Espanyol", "Elche", "Osasuna", "Real Betis"], others: ["granada", "almeria", "real valladolid"] },
        2014: { name: "La Liga", size: 20, clubs: ["Barcelona", "Real Madrid", "Atletico Madrid", "Valencia", "Sevilla", "Villarreal", "Athletic Bilbao", "Celta Vigo", "Malaga", "Espanyol", "Rayo Vallecano", "Real Sociedad", "Elche", "Levante", "Getafe", "Deportivo"], others: ["granada", "eibar", "almeria", "cordoba"] },
        2015: { name: "La Liga", size: 20, clubs: ["Barcelona", "Real Madrid", "Atletico Madrid", "Villarreal", "Athletic Bilbao", "Celta Vigo", "Sevilla", "Malaga", "Real Sociedad", "Real Betis", "Valencia", "Espanyol", "Deportivo", "Rayo Vallecano", "Getafe", "Levante"], others: ["las palmas", "eibar", "granada", "sporting de gijon|sporting gijon"] },
        2016: { name: "La Liga", size: 20, clubs: ["Real Madrid", "Barcelona", "Atletico Madrid", "Sevilla", "Villarreal", "Real Sociedad", "Athletic Bilbao", "Espanyol", "Alaves", "Malaga", "Valencia", "Celta Vigo", "Real Betis", "Deportivo", "Osasuna"], others: ["eibar", "las palmas", "leganes", "sporting de gijon|sporting gijon", "granada"] },
        2017: { name: "La Liga", size: 20, clubs: ["Barcelona", "Atletico Madrid", "Real Madrid", "Valencia", "Villarreal", "Real Betis", "Sevilla", "Getafe", "Girona", "Espanyol", "Real Sociedad", "Celta Vigo", "Alaves", "Levante", "Athletic Bilbao", "Deportivo", "Malaga"], others: ["eibar", "leganes", "las palmas"] },
        2018: { name: "La Liga", size: 20, clubs: ["Barcelona", "Atletico Madrid", "Real Madrid", "Valencia", "Getafe", "Sevilla", "Espanyol", "Athletic Bilbao", "Real Sociedad", "Real Betis", "Alaves", "Villarreal", "Levante", "Celta Vigo", "Girona", "Rayo Vallecano"], others: ["eibar", "leganes", "real valladolid", "huesca"] },
        2019: { name: "La Liga", size: 20, clubs: ["Real Madrid", "Barcelona", "Atletico Madrid", "Sevilla", "Villarreal", "Real Sociedad", "Getafe", "Valencia", "Osasuna", "Athletic Bilbao", "Levante", "Real Betis", "Alaves", "Celta Vigo", "Espanyol"], others: ["granada", "real valladolid", "eibar", "leganes", "mallorca palma de m|mallorca"] },
        2020: { name: "La Liga", size: 20, clubs: ["Atletico Madrid", "Real Madrid", "Barcelona", "Sevilla", "Real Sociedad", "Real Betis", "Villarreal", "Celta Vigo", "Athletic Bilbao", "Osasuna", "Valencia", "Levante", "Getafe", "Alaves", "Elche"], others: ["granada", "cadiz", "huesca", "real valladolid", "eibar"] },
        2021: { name: "La Liga", size: 20, clubs: ["Real Madrid", "Barcelona", "Atletico Madrid", "Sevilla", "Real Betis", "Real Sociedad", "Villarreal", "Athletic Bilbao", "Valencia", "Osasuna", "Celta Vigo", "Rayo Vallecano", "Elche", "Espanyol", "Getafe", "Levante", "Alaves"], others: ["mallorca palma de m|mallorca", "cadiz", "granada"] },
        2022: { name: "La Liga", size: 20, clubs: ["Barcelona", "Real Madrid", "Atletico Madrid", "Real Sociedad", "Villarreal", "Real Betis", "Osasuna", "Athletic Bilbao", "Girona", "Rayo Vallecano", "Sevilla", "Celta Vigo", "Getafe", "Valencia", "Espanyol", "Elche"], others: ["mallorca palma de m|mallorca", "cadiz", "almeria", "real valladolid"] },
        2023: { name: "La Liga", size: 20, clubs: ["Real Madrid", "Barcelona", "Girona", "Atletico Madrid", "Athletic Bilbao", "Real Sociedad", "Real Betis", "Villarreal", "Valencia", "Alaves", "Osasuna", "Getafe", "Celta Vigo", "Sevilla", "Rayo Vallecano"], others: ["mallorca palma de m|mallorca", "las palmas", "cadiz", "almeria", "granada"] },
        2024: { name: "La Liga", size: 20, clubs: ["Barcelona", "Real Madrid", "Atletico Madrid", "Athletic Bilbao", "Villarreal", "Real Betis", "Celta Vigo", "Rayo Vallecano", "Osasuna", "Real Sociedad", "Valencia", "Getafe", "Espanyol", "Alaves", "Girona", "Sevilla"], others: ["mallorca palma de m|mallorca", "leganes", "las palmas", "real valladolid"] },
        2025: { name: "La Liga", size: 20, clubs: ["Barcelona", "Real Madrid", "Villarreal", "Atletico Madrid", "Real Betis", "Celta Vigo", "Getafe", "Rayo Vallecano", "Valencia", "Real Sociedad", "Espanyol", "Athletic Bilbao", "Sevilla", "Alaves", "Elche", "Levante", "Osasuna", "Girona"], others: ["mallorca palma de m|mallorca", "real oviedo"] }
      },
      "Serie A": {
        1990: { name: "Serie A", size: 18, clubs: ["AC Milan", "Inter Milan", "Torino", "Juventus", "Napoli", "Roma", "Atalanta", "Fiorentina", "Bologna"], others: ["sampdoria", "genoa", "parma", "lazio|lazio roma", "bari", "cagliari", "lecce", "pisa", "cesena"] },
        1991: { name: "Serie A", size: 18, clubs: ["AC Milan", "Juventus", "Torino", "Napoli", "Roma", "Inter Milan", "Atalanta", "Fiorentina"], others: ["sampdoria", "parma", "foggia", "lazio|lazio roma", "cagliari", "genoa", "bari", "verona|hellas verona", "cremonese", "ascoli"] },
        1992: { name: "Serie A", size: 18, clubs: ["AC Milan", "Inter Milan", "Juventus", "Atalanta", "Torino", "Roma", "Napoli", "Fiorentina"], others: ["parma", "lazio|lazio roma", "cagliari", "sampdoria", "foggia", "genoa", "udinese", "brescia", "ancona", "pescara"] },
        1993: { name: "Serie A", size: 18, clubs: ["AC Milan", "Juventus", "Napoli", "Roma", "Torino", "Inter Milan", "Atalanta"], others: ["sampdoria", "lazio|lazio roma", "parma", "foggia", "cremonese", "genoa", "cagliari", "reggiana", "piacenza", "udinese", "lecce"] },
        1994: { name: "Serie A", size: 18, clubs: ["Juventus", "AC Milan", "Roma", "Inter Milan", "Napoli", "Fiorentina", "Torino"], others: ["lazio|lazio roma", "parma", "sampdoria", "cagliari", "bari", "cremonese", "genoa", "padova", "foggia", "reggiana", "brescia"] },
        1995: { name: "Serie A", size: 18, clubs: ["AC Milan", "Juventus", "Fiorentina", "Roma", "Inter Milan", "Napoli", "Atalanta", "Torino"], others: ["lazio|lazio roma", "parma", "sampdoria", "vicenza", "cagliari", "udinese", "piacenza", "bari", "cremonese", "padova"] },
        1996: { name: "Serie A", size: 18, clubs: ["Juventus", "Inter Milan", "Bologna", "Fiorentina", "Atalanta", "AC Milan", "Roma", "Napoli"], others: ["parma", "lazio|lazio roma", "udinese", "sampdoria", "vicenza", "piacenza", "cagliari", "perugia", "verona|hellas verona", "reggiana"] },
        1997: { name: "Serie A", size: 18, clubs: ["Juventus", "Inter Milan", "Roma", "Fiorentina", "Bologna", "AC Milan", "Atalanta", "Napoli"], others: ["udinese", "parma", "lazio|lazio roma", "sampdoria", "bari", "empoli", "piacenza", "vicenza", "brescia", "lecce"] },
        1998: { name: "Serie A", size: 18, clubs: ["AC Milan", "Fiorentina", "Roma", "Juventus", "Inter Milan", "Bologna"], others: ["lazio|lazio roma", "parma", "udinese", "bari", "venezia", "cagliari", "piacenza", "perugia", "salernitana sport", "sampdoria", "vicenza", "empoli"] },
        1999: { name: "Serie A", size: 18, clubs: ["Juventus", "AC Milan", "Inter Milan", "Roma", "Fiorentina", "Bologna", "Torino"], others: ["lazio|lazio roma", "parma", "udinese", "hellas verona", "perugia", "reggina", "lecce", "bari", "venezia", "cagliari", "piacenza"] },
        2e3: { name: "Serie A", size: 18, clubs: ["Roma", "Juventus", "Inter Milan", "AC Milan", "Atalanta", "Fiorentina", "Bologna", "Napoli"], others: ["lazio|lazio roma", "parma", "brescia", "perugia", "udinese", "lecce", "reggina", "hellas verona", "vicenza", "bari"] },
        2001: { name: "Serie A", size: 18, clubs: ["Juventus", "Roma", "Inter Milan", "AC Milan", "Bologna", "Atalanta", "Torino", "Fiorentina"], others: ["chievo verona", "lazio|lazio roma", "perugia", "parma", "piacenza", "brescia", "udinese", "hellas verona", "lecce", "venezia"] },
        2002: { name: "Serie A", size: 18, clubs: ["Juventus", "Inter Milan", "AC Milan", "Roma", "Bologna", "Atalanta", "Torino"], others: ["lazio|lazio roma", "parma", "udinese", "chievo verona", "brescia", "perugia", "modena", "empoli", "reggina", "piacenza", "como"] },
        2003: { name: "Serie A", size: 18, clubs: ["AC Milan", "Roma", "Juventus", "Inter Milan", "Bologna"], others: ["parma", "lazio|lazio roma", "udinese", "uc sampdoria|sampdoria", "chievo verona", "lecce", "brescia", "siena", "reggina", "perugia", "modena", "empoli", "ancona"] },
        2004: { name: "Serie A", size: 20, clubs: ["Juventus", "AC Milan", "Inter Milan", "Roma", "Fiorentina", "Bologna", "Atalanta"], others: ["udinese", "uc sampdoria|sampdoria", "citta di palermo|palermo", "messina pfc|messina", "livorno", "lazio|lazio roma", "lecce", "cagliari", "reggina", "siena", "chievo verona", "parma", "brescia"] },
        2005: { name: "Serie A", size: 20, clubs: ["Inter Milan", "Roma", "AC Milan", "Fiorentina", "Juventus"], others: ["chievo verona", "citta di palermo|palermo", "livorno", "empoli", "parma", "ascoli", "udinese", "uc sampdoria|sampdoria", "reggina", "cagliari", "siena", "lazio|lazio roma", "messina pfc|messina", "lecce", "treviso|treviso fbc"] },
        2006: { name: "Serie A", size: 20, clubs: ["Inter Milan", "Roma", "AC Milan", "Fiorentina", "Atalanta", "Torino"], others: ["lazio|lazio roma", "citta di palermo|palermo", "empoli", "uc sampdoria|sampdoria", "udinese", "livorno", "parma", "catania", "reggina", "siena", "cagliari", "chievo verona", "ascoli", "messina pfc|messina"] },
        2007: { name: "Serie A", size: 20, clubs: ["Inter Milan", "Roma", "Juventus", "Fiorentina", "AC Milan", "Napoli", "Atalanta", "Torino"], others: ["uc sampdoria|sampdoria", "udinese", "genoa", "citta di palermo|palermo", "lazio|lazio roma", "siena", "cagliari", "reggina", "catania", "empoli", "parma", "livorno"] },
        2008: { name: "Serie A", size: 20, clubs: ["Inter Milan", "Juventus", "AC Milan", "Fiorentina", "Roma", "Atalanta", "Napoli", "Bologna", "Torino"], others: ["genoa", "udinese", "citta di palermo|palermo", "cagliari", "lazio|lazio roma", "uc sampdoria|sampdoria", "siena", "catania", "chievo verona", "reggina", "lecce"] },
        2009: { name: "Serie A", size: 20, clubs: ["Inter Milan", "Roma", "AC Milan", "Napoli", "Juventus", "Fiorentina", "Bologna", "Atalanta"], others: ["uc sampdoria|sampdoria", "citta di palermo|palermo", "parma", "genoa", "bari", "lazio|lazio roma", "catania", "cagliari", "udinese", "chievo verona", "siena", "livorno"] },
        2010: { name: "Serie A", size: 20, clubs: ["AC Milan", "Inter Milan", "Napoli", "Roma", "Juventus", "Fiorentina", "Bologna"], others: ["udinese", "lazio|lazio roma", "citta di palermo|palermo", "genoa", "chievo verona", "parma", "catania", "cagliari", "cesena", "lecce", "uc sampdoria|sampdoria", "brescia", "bari"] },
        2011: { name: "Serie A", size: 20, clubs: ["Juventus", "AC Milan", "Napoli", "Inter Milan", "Roma", "Bologna", "Atalanta", "Fiorentina"], others: ["udinese", "lazio|lazio roma", "parma", "chievo verona", "catania", "siena", "cagliari", "citta di palermo|palermo", "genoa", "lecce", "novara", "cesena"] },
        2012: { name: "Serie A", size: 20, clubs: ["Juventus", "Napoli", "AC Milan", "Fiorentina", "Roma", "Inter Milan", "Bologna", "Atalanta", "Torino"], others: ["udinese", "lazio|lazio roma", "catania", "parma", "cagliari", "chievo verona", "uc sampdoria|sampdoria", "genoa", "citta di palermo|palermo", "siena", "delfino pescara|pescara"] },
        2013: { name: "Serie A", size: 20, clubs: ["Juventus", "Roma", "Napoli", "Fiorentina", "Inter Milan", "Torino", "AC Milan", "Atalanta", "Bologna"], others: ["parma", "lazio|lazio roma", "hellas verona", "uc sampdoria|sampdoria", "udinese", "genoa", "cagliari", "chievo verona", "sassuolo", "catania", "livorno"] },
        2014: { name: "Serie A", size: 20, clubs: ["Juventus", "Roma", "Fiorentina", "Napoli", "Inter Milan", "Torino", "AC Milan", "Atalanta"], others: ["lazio|lazio roma", "genoa", "uc sampdoria|sampdoria", "citta di palermo|palermo", "sassuolo", "hellas verona", "chievo verona", "empoli", "udinese", "cagliari", "cesena", "parma"] },
        2015: { name: "Serie A", size: 20, clubs: ["Juventus", "Napoli", "Roma", "Inter Milan", "Fiorentina", "AC Milan", "Torino", "Atalanta", "Bologna"], others: ["sassuolo", "lazio|lazio roma", "chievo verona", "empoli", "genoa", "uc sampdoria|sampdoria", "citta di palermo|palermo", "udinese", "carpi", "frosinone", "hellas verona"] },
        2016: { name: "Serie A", size: 20, clubs: ["Juventus", "Roma", "Napoli", "Atalanta", "AC Milan", "Inter Milan", "Fiorentina", "Torino", "Bologna"], others: ["lazio|lazio roma", "uc sampdoria|sampdoria", "cagliari", "sassuolo", "udinese", "chievo verona", "genoa", "crotone", "empoli", "citta di palermo|palermo", "delfino pescara|pescara"] },
        2017: { name: "Serie A", size: 20, clubs: ["Juventus", "Napoli", "Roma", "Inter Milan", "AC Milan", "Atalanta", "Fiorentina", "Torino", "Bologna"], others: ["lazio|lazio roma", "uc sampdoria|sampdoria", "sassuolo", "genoa", "chievo verona", "udinese", "cagliari", "spal ferrara", "crotone", "hellas verona", "benevento"] },
        2018: { name: "Serie A", size: 20, clubs: ["Juventus", "Napoli", "Atalanta", "Inter Milan", "AC Milan", "Roma", "Torino", "Bologna", "Fiorentina"], others: ["lazio|lazio roma", "uc sampdoria|sampdoria", "sassuolo", "udinese", "spal ferrara", "parma", "cagliari", "genoa", "empoli", "frosinone", "chievo verona"] },
        2019: { name: "Serie A", size: 20, clubs: ["Juventus", "Inter Milan", "Atalanta", "Roma", "AC Milan", "Napoli", "Fiorentina", "Bologna", "Torino"], others: ["lazio|lazio roma", "sassuolo", "hellas verona", "parma", "udinese", "cagliari", "uc sampdoria|sampdoria", "genoa", "lecce", "brescia", "spal ferrara"] },
        2020: { name: "Serie A", size: 20, clubs: ["Inter Milan", "AC Milan", "Atalanta", "Juventus", "Napoli", "Roma", "Bologna", "Fiorentina", "Torino"], others: ["lazio|lazio roma", "sassuolo", "uc sampdoria|sampdoria", "hellas verona", "genoa", "udinese", "spezia", "cagliari", "benevento", "crotone", "parma"] },
        2021: { name: "Serie A", size: 20, clubs: ["AC Milan", "Inter Milan", "Napoli", "Juventus", "Roma", "Fiorentina", "Atalanta", "Torino", "Bologna"], others: ["lazio|lazio roma", "hellas verona", "sassuolo", "udinese", "empoli", "uc sampdoria|sampdoria", "spezia", "salernitana", "cagliari", "genoa", "venezia"] },
        2022: { name: "Serie A", size: 20, clubs: ["Napoli", "Inter Milan", "AC Milan", "Atalanta", "Roma", "Juventus", "Fiorentina", "Bologna", "Torino"], others: ["lazio|lazio roma", "monza", "udinese", "sassuolo", "empoli", "salernitana", "lecce", "spezia", "hellas verona", "cremonese", "uc sampdoria|sampdoria"] },
        2023: { name: "Serie A", size: 20, clubs: ["Inter Milan", "AC Milan", "Juventus", "Atalanta", "Bologna", "Roma", "Fiorentina", "Torino", "Napoli"], others: ["lazio|lazio roma", "genoa", "monza", "hellas verona", "lecce", "udinese", "cagliari", "empoli", "frosinone", "sassuolo", "salernitana"] },
        2024: { name: "Serie A", size: 20, clubs: ["Napoli", "Inter Milan", "Atalanta", "Juventus", "Roma", "Fiorentina", "AC Milan", "Bologna", "Torino"], others: ["lazio", "como", "udinese", "genoa", "hellas verona", "cagliari", "parma", "lecce", "empoli", "venezia", "monza"] },
        2025: { name: "Serie A", size: 20, clubs: ["Inter Milan", "Napoli", "Roma", "AC Milan", "Juventus", "Atalanta", "Bologna", "Torino", "Fiorentina"], others: ["como", "lazio", "udinese", "sassuolo", "parma", "cagliari", "genoa", "lecce", "cremonese", "hellas verona", "pisa"] }
      },
      "Bundesliga": {
        1990: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Werder Bremen", "Frankfurt", "Stuttgart", "Leverkusen", "Dortmund", "Hertha Berlin"], others: ["kaiserslautern", "hamburger", "koln", "borussia monchengladbach|borussia m gladbach", "wattenscheid|sg wattenscheid", "fortuna dusseldorf", "karlsruher", "bochum", "nurnberg", "st pauli", "bayer uerdingen"] },
        1991: { name: "Bundesliga", size: 20, clubs: ["Stuttgart", "Dortmund", "Frankfurt", "Leverkusen", "Werder Bremen", "Bayern Munich"], others: ["koln", "kaiserslautern", "nurnberg", "karlsruher", "schalke", "hamburger", "borussia monchengladbach|borussia m gladbach", "dynamo dresden", "bochum", "wattenscheid|sg wattenscheid", "stuttgarter kickers", "hansa rostock", "msv duisburg", "fortuna dusseldorf"] },
        1992: { name: "Bundesliga", size: 18, clubs: ["Werder Bremen", "Bayern Munich", "Frankfurt", "Dortmund", "Leverkusen", "Stuttgart"], others: ["karlsruher", "kaiserslautern", "borussia monchengladbach|borussia m gladbach", "schalke", "hamburger", "koln", "wattenscheid|sg wattenscheid", "nurnberg", "dynamo dresden", "bochum", "bayer uerdingen", "saarbrucken"] },
        1993: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Dortmund", "Leverkusen", "Frankfurt", "Stuttgart", "Werder Bremen"], others: ["kaiserslautern", "karlsruher", "msv duisburg", "borussia monchengladbach|borussia m gladbach", "koln", "dynamo dresden", "hamburger", "schalke", "freiburg", "nurnberg", "wattenscheid|sg wattenscheid", "leipzig"] },
        1994: { name: "Bundesliga", size: 18, clubs: ["Dortmund", "Werder Bremen", "Bayern Munich", "Leverkusen", "Frankfurt", "Stuttgart"], others: ["freiburg", "kaiserslautern", "borussia monchengladbach|borussia m gladbach", "karlsruher", "koln", "schalke", "hamburger", "tsv munchen", "bayer uerdingen", "bochum", "msv duisburg", "dynamo dresden"] },
        1995: { name: "Bundesliga", size: 18, clubs: ["Dortmund", "Bayern Munich", "Werder Bremen", "Stuttgart", "Leverkusen", "Frankfurt"], others: ["schalke", "borussia monchengladbach|borussia m gladbach", "hamburger", "hansa rostock", "karlsruher", "tsv munchen", "freiburg", "koln", "fortuna dusseldorf", "st pauli", "kaiserslautern", "kfc uerdingen"] },
        1996: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Leverkusen", "Dortmund", "Stuttgart", "Werder Bremen"], others: ["bochum", "karlsruher", "tsv munchen", "msv duisburg", "koln", "borussia monchengladbach|borussia m gladbach", "schalke", "hamburger", "hansa rostock", "arminia bielefeld|dsc arminia bielefeld", "fortuna dusseldorf", "freiburg", "st pauli"] },
        1997: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Leverkusen", "Stuttgart", "Werder Bremen", "Dortmund", "Hertha Berlin"], others: ["kaiserslautern", "schalke", "hansa rostock", "msv duisburg", "hamburger", "bochum", "tsv munchen", "wolfsburg", "borussia monchengladbach|borussia m gladbach", "karlsruher", "koln", "arminia bielefeld|dsc arminia bielefeld"] },
        1998: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Leverkusen", "Hertha Berlin", "Dortmund", "Stuttgart", "Werder Bremen", "Frankfurt"], others: ["kaiserslautern", "wolfsburg", "hamburger", "msv duisburg", "schalke", "tsv munchen", "freiburg", "hansa rostock", "nurnberg", "bochum", "borussia monchengladbach|borussia m gladbach"] },
        1999: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Leverkusen", "Hertha Berlin", "Stuttgart", "Werder Bremen", "Dortmund", "Frankfurt"], others: ["hamburger", "tsv munchen", "kaiserslautern", "wolfsburg", "unterhaching", "freiburg", "schalke", "hansa rostock", "ssv ulm", "dsc arminia bielefeld", "msv duisburg"] },
        2e3: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Dortmund", "Leverkusen", "Hertha Berlin", "Werder Bremen", "Stuttgart", "Frankfurt"], others: ["schalke", "freiburg", "kaiserslautern", "wolfsburg", "koln", "tsv munchen", "hansa rostock", "hamburger", "energie cottbus", "unterhaching", "bochum"] },
        2001: { name: "Bundesliga", size: 18, clubs: ["Dortmund", "Leverkusen", "Bayern Munich", "Hertha Berlin", "Werder Bremen", "Stuttgart"], others: ["schalke", "kaiserslautern", "tsv munchen", "wolfsburg", "hamburger", "borussia monchengladbach|borussia m gladbach", "energie cottbus", "hansa rostock", "nurnberg", "freiburg", "koln", "sankt pauli|st pauli"] },
        2002: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Stuttgart", "Dortmund", "Hertha Berlin", "Werder Bremen", "Leverkusen"], others: ["hamburger", "schalke", "wolfsburg", "bochum", "tsv munchen", "hannover", "borussia monchengladbach|borussia m gladbach", "hansa rostock", "kaiserslautern", "dsc arminia bielefeld", "nurnberg", "energie cottbus"] },
        2003: { name: "Bundesliga", size: 18, clubs: ["Werder Bremen", "Bayern Munich", "Leverkusen", "Stuttgart", "Dortmund", "Hertha Berlin", "Frankfurt"], others: ["bochum", "schalke gelsenkirchen|schalke", "hamburger", "hansa rostock", "wolfsburg", "borussia monchengladbach|borussia m gladbach", "freiburg", "hannover", "kaiserslautern", "tsv munchen", "koln"] },
        2004: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Werder Bremen", "Hertha Berlin", "Stuttgart", "Leverkusen", "Dortmund"], others: ["schalke gelsenkirchen|schalke", "hamburger", "wolfsburg", "hannover", "mainz", "kaiserslautern", "dsc arminia bielefeld", "nurnberg", "borussia monchengladbach|borussia m gladbach", "bochum", "hansa rostock", "freiburg"] },
        2005: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Werder Bremen", "Leverkusen", "Hertha Berlin", "Dortmund", "Stuttgart", "Frankfurt"], others: ["hamburger", "schalke gelsenkirchen|schalke", "nurnberg", "borussia monchengladbach|borussia m gladbach", "mainz", "hannover", "dsc arminia bielefeld", "wolfsburg", "kaiserslautern", "koln", "msv duisburg"] },
        2006: { name: "Bundesliga", size: 18, clubs: ["Stuttgart", "Werder Bremen", "Bayern Munich", "Leverkusen", "Dortmund", "Hertha Berlin", "Frankfurt"], others: ["schalke gelsenkirchen|schalke", "nurnberg", "hamburger", "bochum", "hannover", "dsc arminia bielefeld", "energie cottbus", "wolfsburg", "mainz", "tsv alemannia aachen|alemannia aachen", "borussia monchengladbach|borussia m gladbach"] },
        2007: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Werder Bremen", "Stuttgart", "Leverkusen", "Frankfurt", "Hertha Berlin", "Dortmund"], others: ["schalke gelsenkirchen|schalke", "hamburger", "wolfsburg", "hannover", "karlsruher", "bochum", "energie cottbus", "dsc arminia bielefeld", "nurnberg", "hansa rostock", "msv duisburg"] },
        2008: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Stuttgart", "Hertha Berlin", "Dortmund", "Leverkusen", "Werder Bremen", "Frankfurt"], others: ["wolfsburg", "hamburger", "hoffenheim", "schalke gelsenkirchen|schalke", "hannover", "koln", "bochum", "borussia monchengladbach|borussia m gladbach", "energie cottbus", "karlsruher", "dsc arminia bielefeld"] },
        2009: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Werder Bremen", "Leverkusen", "Dortmund", "Stuttgart", "Frankfurt", "Hertha Berlin"], others: ["schalke gelsenkirchen|schalke", "hamburger", "wolfsburg", "mainz", "hoffenheim", "borussia monchengladbach|borussia m gladbach", "koln", "freiburg", "hannover", "nurnberg", "bochum"] },
        2010: { name: "Bundesliga", size: 18, clubs: ["Dortmund", "Leverkusen", "Bayern Munich", "Stuttgart", "Werder Bremen", "Frankfurt"], others: ["hannover", "mainz", "nurnberg", "kaiserslautern", "hamburger", "freiburg", "koln", "hoffenheim", "schalke", "wolfsburg", "borussia m gladbach", "st pauli"] },
        2011: { name: "Bundesliga", size: 18, clubs: ["Dortmund", "Bayern Munich", "Leverkusen", "Stuttgart", "Werder Bremen", "Hertha Berlin"], others: ["schalke gelsenkirchen|schalke", "borussia monchengladbach|borussia m gladbach", "hannover", "wolfsburg", "nurnberg", "hoffenheim", "freiburg", "mainz", "augsburg", "hamburger", "koln", "kaiserslautern"] },
        2012: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Dortmund", "Leverkusen", "Frankfurt", "Stuttgart", "Werder Bremen"], others: ["schalke gelsenkirchen|schalke", "freiburg", "hamburger", "borussia monchengladbach|borussia m gladbach", "hannover", "nurnberg", "wolfsburg", "mainz", "augsburg", "hoffenheim", "fortuna dusseldorf", "greuther furth"] },
        2013: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Dortmund", "Leverkusen", "Hertha Berlin", "Werder Bremen", "Frankfurt", "Stuttgart"], others: ["schalke gelsenkirchen|schalke", "wolfsburg", "borussia monchengladbach|borussia m gladbach", "mainz", "augsburg", "hoffenheim", "hannover", "freiburg", "hamburger", "nurnberg", "eintracht braunschweig"] },
        2014: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Leverkusen", "Dortmund", "Frankfurt", "Werder Bremen", "Stuttgart", "Hertha Berlin"], others: ["wolfsburg", "borussia monchengladbach|borussia m gladbach", "augsburg", "schalke gelsenkirchen|schalke", "hoffenheim", "mainz", "koln", "hannover", "hamburger", "freiburg", "paderborn"] },
        2015: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Dortmund", "Leverkusen", "Hertha Berlin", "Werder Bremen", "Frankfurt", "Stuttgart"], others: ["borussia monchengladbach|borussia m gladbach", "schalke gelsenkirchen|schalke", "mainz", "wolfsburg", "koln", "hamburger", "ingolstadt", "augsburg", "darmstadt", "hoffenheim", "hannover"] },
        2016: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Leipzig", "Dortmund", "Hertha Berlin", "Werder Bremen", "Frankfurt", "Leverkusen"], others: ["hoffenheim", "koln", "freiburg", "borussia monchengladbach|borussia m gladbach", "schalke gelsenkirchen|schalke", "augsburg", "hamburger", "mainz", "wolfsburg", "ingolstadt", "darmstadt"] },
        2017: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Dortmund", "Leverkusen", "Leipzig", "Stuttgart", "Frankfurt", "Hertha Berlin", "Werder Bremen"], others: ["schalke gelsenkirchen|schalke", "hoffenheim", "borussia monchengladbach|borussia m gladbach", "augsburg", "hannover", "mainz", "freiburg", "wolfsburg", "hamburger", "koln"] },
        2018: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Dortmund", "Leipzig", "Leverkusen", "Frankfurt", "Werder Bremen", "Hertha Berlin", "Stuttgart"], others: ["borussia monchengladbach|borussia m gladbach", "wolfsburg", "hoffenheim", "fortuna dusseldorf", "mainz", "freiburg", "schalke gelsenkirchen|schalke", "augsburg", "hannover", "nurnberg"] },
        2019: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Dortmund", "Leipzig", "Leverkusen", "Frankfurt", "Hertha Berlin", "Werder Bremen"], others: ["borussia monchengladbach|borussia m gladbach", "hoffenheim", "wolfsburg", "freiburg", "union berlin", "schalke gelsenkirchen|schalke", "mainz", "koln", "augsburg", "fortuna dusseldorf", "paderborn"] },
        2020: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Leipzig", "Dortmund", "Frankfurt", "Leverkusen", "Stuttgart", "Hertha Berlin", "Werder Bremen"], others: ["wolfsburg", "union berlin", "borussia monchengladbach|borussia m gladbach", "freiburg", "hoffenheim", "mainz", "augsburg", "dsc arminia bielefeld", "koln", "schalke gelsenkirchen|schalke"] },
        2021: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Dortmund", "Leverkusen", "Leipzig", "Frankfurt", "Stuttgart", "Hertha Berlin"], others: ["union berlin", "freiburg", "koln", "mainz", "hoffenheim", "borussia monchengladbach|borussia m gladbach", "wolfsburg", "bochum", "augsburg", "dsc arminia bielefeld", "greuther furth"] },
        2022: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Dortmund", "Leipzig", "Leverkusen", "Frankfurt", "Werder Bremen", "Stuttgart", "Hertha Berlin"], others: ["union berlin", "freiburg", "wolfsburg", "mainz", "borussia monchengladbach", "koln|cologne", "hoffenheim", "bochum", "augsburg", "schalke gelsenkirchen|schalke"] },
        2023: { name: "Bundesliga", size: 18, clubs: ["Leverkusen", "Stuttgart", "Bayern Munich", "Leipzig", "Dortmund", "Frankfurt", "Werder Bremen"], others: ["hoffenheim", "heidenheim", "freiburg", "augsburg", "wolfsburg", "mainz", "borussia monchengladbach", "union berlin", "bochum", "koln|cologne", "darmstadt"] },
        2024: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Leverkusen", "Frankfurt", "Dortmund", "Leipzig", "Werder Bremen", "Stuttgart"], others: ["freiburg", "mainz", "borussia monchengladbach", "wolfsburg", "augsburg", "union berlin", "sankt pauli|st pauli", "hoffenheim", "heidenheim", "holstein kiel", "bochum"] },
        2025: { name: "Bundesliga", size: 18, clubs: ["Bayern Munich", "Dortmund", "Leipzig", "Stuttgart", "Leverkusen", "Frankfurt", "Werder Bremen"], others: ["hoffenheim", "freiburg", "augsburg", "mainz", "union berlin", "borussia monchengladbach", "hamburger|hamburg", "koln|cologne", "wolfsburg", "heidenheim", "sankt pauli|st pauli"] }
      },
      "Ligue 1": {
        1990: { name: "Division 1", size: 20, clubs: ["Marseille", "Monaco", "Lyon", "Lille", "PSG", "Nice", "Nantes"], others: ["auxerre", "cannes", "montpellier", "caen", "bordeaux", "brest", "metz", "st etienne|saint etienne", "toulon", "nancy", "sochaux", "toulouse", "rennes"] },
        1991: { name: "Division 1", size: 20, clubs: ["Marseille", "Monaco", "PSG", "Nantes", "Lille", "Lyon"], others: ["auxerre", "caen", "montpellier", "le havre", "lens", "st etienne|saint etienne", "toulouse", "metz", "toulon", "nimes", "sochaux", "rennes", "cannes", "nancy"] },
        1992: { name: "Division 1", size: 20, clubs: ["Marseille", "PSG", "Monaco", "Nantes", "Strasbourg", "Lyon", "Lille"], others: ["bordeaux", "auxerre", "st etienne|saint etienne", "lens", "montpellier", "caen", "metz", "toulouse", "le havre", "sochaux", "valenciennes", "toulon", "nimes"] },
        1993: { name: "Division 1", size: 20, clubs: ["PSG", "Marseille", "Nantes", "Lyon", "Monaco", "Strasbourg", "Lille"], others: ["auxerre", "bordeaux|girondins de bordeaux", "cannes|a s cannes", "montpellier|montpellier herault", "lens", "st etienne|saint etienne", "metz", "sochaux|sochaux montbeliard", "caen|stade malherbe caen", "le havre|havre", "martigues|f c martigues", "toulouse", "angers"] },
        1994: { name: "Division 1", size: 20, clubs: ["Nantes", "Lyon", "PSG", "Monaco", "Strasbourg", "Lille", "Nice"], others: ["auxerre", "lens", "bordeaux|girondins de bordeaux", "metz", "cannes|a s cannes", "martigues|f c martigues", "le havre|havre", "rennes|stade rennais", "bastia|s c bastiais", "montpellier|montpellier herault", "st etienne|saint etienne", "caen|stade malherbe caen", "sochaux|sochaux montbeliard"] },
        1995: { name: "Division 1", size: 20, clubs: ["PSG", "Monaco", "Nantes", "Strasbourg", "Lyon", "Nice", "Lille"], others: ["auxerre", "metz", "lens", "montpellier|montpellier herault", "rennes|stade rennais", "guingamp|en avant guingamp", "le havre|havre", "cannes|a s cannes", "bastia|s c bastiais", "bordeaux|girondins de bordeaux", "gueugnon|f c gueugnon", "st etienne|saint etienne", "martigues|f c martigues"] },
        1996: { name: "Division 1", size: 20, clubs: ["Monaco", "PSG", "Nantes", "Lyon", "Strasbourg", "Marseille", "Lille", "Nice"], others: ["bordeaux|girondins de bordeaux", "metz", "auxerre", "bastia|s c bastiais", "montpellier|montpellier herault", "guingamp|en avant guingamp", "lens", "le havre|havre", "cannes|a s cannes", "rennes|stade rennais", "caen|stade malherbe caen", "nancy|nancy lorraine"] },
        1997: { name: "Division 1", size: 18, clubs: ["Monaco", "Marseille", "Lyon", "PSG", "Nantes", "Strasbourg"], others: ["lens", "metz", "girondins de bordeaux", "auxerre", "bastia|s c bastiais", "le havre|havre", "montpellier hsc|montpellier herault", "stade rennais", "toulouse", "en avant guingamp", "berrichonne chateauroux|chateauroux", "cannes|a s cannes"] },
        1998: { name: "Division 1", size: 18, clubs: ["Marseille", "Lyon", "Monaco", "Nantes", "PSG", "Strasbourg"], others: ["girondins de bordeaux", "stade rennais", "lens", "montpellier hsc|montpellier herault", "metz", "nancy lorraine", "bastia|s c bastiais", "auxerre", "havre", "lorient", "sochaux montbeliard", "toulouse"] },
        1999: { name: "Division 1", size: 18, clubs: ["Monaco", "PSG", "Lyon", "Strasbourg", "Nantes", "Marseille"], others: ["girondins de bordeaux", "lens", "saint etienne", "cs sedan ardennes|c s sedan ardennes", "auxerre", "bastia|s c bastiais", "metz", "stade rennais", "atac troyes|estac troyes", "nancy lorraine", "havre", "montpellier hsc|montpellier herault"] },
        2e3: { name: "Division 1", size: 18, clubs: ["Nantes", "Lyon", "Lille", "PSG", "Monaco", "Marseille", "Strasbourg"], others: ["girondins de bordeaux", "cs sedan ardennes|c s sedan ardennes", "stade rennais", "es troyes|estac troyes", "bastia|s c bastiais", "en avant guingamp", "metz", "auxerre", "lens", "toulouse", "saint etienne"] },
        2001: { name: "Division 1", size: 18, clubs: ["Lyon", "PSG", "Lille", "Marseille", "Nantes", "Monaco"], others: ["lens", "auxerre", "girondins de bordeaux", "es troyes|estac troyes", "sochaux montbeliard", "bastia|s c bastiais", "stade rennais", "montpellier hsc|montpellier herault", "cs sedan ardennes|c s sedan ardennes", "en avant guingamp", "metz", "lorient"] },
        2002: { name: "Ligue 1", size: 20, clubs: ["Lyon", "Monaco", "Marseille", "Nantes", "Nice", "PSG", "Strasbourg", "Lille"], others: ["girondins bordeaux|girondins de bordeaux|bordeaux", "sochaux montbeliard|sochaux", "auxerre", "en avant guingamp|guingamp", "lens", "bastia|s c bastiais", "stade rennais", "montpellier hsc|montpellier herault|montpellier", "ajaccio", "le havre|havre", "cs sedan ardennes|c s sedan ardennes|sedan", "es troyes|estac troyes|troyes"] },
        2003: { name: "Ligue 1", size: 20, clubs: ["Lyon", "PSG", "Monaco", "Nantes", "Marseille", "Lille", "Nice", "Strasbourg"], others: ["auxerre", "sochaux montbeliard|sochaux", "lens", "stade rennais", "girondins bordeaux|girondins de bordeaux|bordeaux", "metz", "ajaccio", "toulouse", "bastia|s c bastiais", "en avant guingamp|guingamp", "le mans uc72|le mans", "montpellier hsc|montpellier herault|montpellier"] },
        2004: { name: "Ligue 1", size: 20, clubs: ["Lyon", "Lille", "Monaco", "Marseille", "PSG", "Strasbourg", "Nice", "Nantes"], others: ["stade rennais", "saint etienne", "lens", "auxerre", "sochaux montbeliard|sochaux", "toulouse", "ajaccio", "girondins bordeaux|girondins de bordeaux|bordeaux", "metz", "stade malherbe caen|caen", "bastia|s c bastiais", "istres|f c istres ouest provence"] },
        2005: { name: "Ligue 1", size: 20, clubs: ["Lyon", "Lille", "Marseille", "Nice", "PSG", "Monaco", "Nantes", "Strasbourg"], others: ["girondins bordeaux|girondins de bordeaux|bordeaux", "lens", "auxerre", "stade rennais", "le mans uc|le mans", "nancy lorraine", "saint etienne", "sochaux montbeliard|sochaux", "toulouse", "es troyes|estac troyes|troyes", "ajaccio", "metz"] },
        2006: { name: "Ligue 1", size: 20, clubs: ["Lyon", "Marseille", "Monaco", "Lille", "PSG", "Nice", "Nantes"], others: ["toulouse", "stade rennais", "lens", "girondins bordeaux|girondins de bordeaux|bordeaux", "sochaux montbeliard|sochaux", "auxerre", "saint etienne", "le mans uc|le mans", "nancy lorraine", "lorient", "valenciennes", "es troyes|estac troyes|troyes", "cs sedan ardennes|c s sedan ardennes|sedan"] },
        2007: { name: "Ligue 1", size: 20, clubs: ["Lyon", "Marseille", "Lille", "Nice", "Monaco", "PSG", "Strasbourg"], others: ["girondins bordeaux|girondins de bordeaux|bordeaux", "nancy lorraine", "saint etienne", "stade rennais", "le mans uc|le mans", "lorient", "sm caen|stade malherbe caen|caen", "valenciennes", "sochaux montbeliard|sochaux", "auxerre", "toulouse", "lens", "metz"] },
        2008: { name: "Ligue 1", size: 20, clubs: ["Marseille", "Lyon", "Lille", "PSG", "Nice", "Monaco", "Nantes"], others: ["girondins bordeaux|girondins de bordeaux|bordeaux", "toulouse", "stade rennais", "auxerre", "lorient", "valenciennes", "grenoble foot|grenoble", "sochaux montbeliard|sochaux", "nancy lorraine", "le mans uc|le mans", "saint etienne", "sm caen|stade malherbe caen|caen", "le havre|havre"] },
        2009: { name: "Ligue 1", size: 20, clubs: ["Marseille", "Lyon", "Lille", "Monaco", "PSG", "Nice"], others: ["auxerre", "montpellier herault|montpellier", "girondins bordeaux|girondins de bordeaux|bordeaux", "lorient", "stade rennais", "valenciennes", "lens", "nancy lorraine", "toulouse", "sochaux montbeliard|sochaux", "saint etienne", "le mans uc|le mans", "boulogne sur mer co|u s boulogne cote d opale|boulogne", "grenoble foot|grenoble"] },
        2010: { name: "Ligue 1", size: 20, clubs: ["Lille", "Marseille", "Lyon", "PSG", "Nice", "Monaco"], others: ["sochaux montbeliard|sochaux", "stade rennais", "girondins bordeaux|girondins de bordeaux|bordeaux", "toulouse", "auxerre", "saint etienne", "lorient", "valenciennes", "nancy lorraine", "montpellier herault|montpellier", "sm caen|stade malherbe caen|caen", "stade brestois|brest", "lens", "arles avignon|a c arles avignon|arles"] },
        2011: { name: "Ligue 1", size: 20, clubs: ["PSG", "Lille", "Lyon", "Marseille", "Nice"], others: ["montpellier herault|montpellier", "girondins bordeaux|girondins de bordeaux|bordeaux", "stade rennais", "saint etienne", "toulouse", "evian thonon gaillard|evian thonon gaillard f c", "nancy lorraine", "valenciennes", "sochaux montbeliard|sochaux", "stade brestois|brest", "ajaccio", "lorient", "sm caen|stade malherbe caen|caen", "dijon fco", "auxerre"] },
        2012: { name: "Ligue 1", size: 20, clubs: ["PSG", "Marseille", "Lyon", "Nice", "Lille"], others: ["saint etienne", "girondins bordeaux|girondins de bordeaux|bordeaux", "lorient", "montpellier herault|montpellier", "toulouse", "valenciennes", "bastia|s c bastiais", "stade rennais", "stade de reims", "sochaux montbeliard|sochaux", "evian thonon gaillard|evian thonon gaillard f c", "ajaccio", "nancy lorraine", "es troyes|estac troyes|troyes", "stade brestois|brest"] },
        2013: { name: "Ligue 1", size: 20, clubs: ["PSG", "Monaco", "Lille", "Lyon", "Marseille", "Nantes", "Nice"], others: ["saint etienne", "girondins bordeaux|girondins de bordeaux|bordeaux", "lorient", "toulouse", "bastia|s c bastiais", "stade de reims", "stade rennais", "evian thonon gaillard|evian thonon gaillard f c", "montpellier herault|montpellier", "en avant guingamp|guingamp", "sochaux montbeliard|sochaux", "valenciennes", "ajaccio"] },
        2014: { name: "Ligue 1", size: 20, clubs: ["PSG", "Lyon", "Monaco", "Marseille", "Lille", "Nice", "Nantes"], others: ["saint etienne", "girondins bordeaux|girondins de bordeaux|bordeaux", "montpellier herault|montpellier", "stade rennais", "en avant guingamp|guingamp", "bastia|s c bastiais", "sm caen|stade malherbe caen|caen", "stade de reims", "lorient", "toulouse", "evian thonon gaillard|evian thonon gaillard f c", "metz", "lens"] },
        2015: { name: "Ligue 1", size: 20, clubs: ["PSG", "Lyon", "Monaco", "Nice", "Lille", "Marseille", "Nantes"], others: ["saint etienne", "sm caen|stade malherbe caen|caen", "stade rennais", "angers", "bastia|s c bastiais", "girondins bordeaux|girondins de bordeaux|bordeaux", "montpellier herault|montpellier", "lorient", "en avant guingamp|guingamp", "toulouse", "stade de reims", "gazelec ajaccio fco|gazelec ajaccio|gfc ajaccio", "es troyes|estac troyes|troyes"] },
        2016: { name: "Ligue 1", size: 20, clubs: ["Monaco", "PSG", "Nice", "Lyon", "Marseille", "Nantes", "Lille"], others: ["girondins bordeaux|girondins de bordeaux|bordeaux", "saint etienne", "stade rennais", "en avant guingamp|guingamp", "angers", "toulouse", "metz", "montpellier herault|montpellier", "dijon fco", "sm caen|stade malherbe caen|caen", "lorient", "nancy lorraine", "bastia|s c bastiais"] },
        2017: { name: "Ligue 1", size: 20, clubs: ["PSG", "Monaco", "Lyon", "Marseille", "Nice", "Nantes", "Strasbourg", "Lille"], others: ["stade rennais", "girondins bordeaux|girondins de bordeaux|bordeaux", "saint etienne", "montpellier herault|montpellier", "dijon fco", "en avant guingamp|guingamp", "amiens", "angers", "sm caen|stade malherbe caen|caen", "toulouse", "es troyes|estac troyes|troyes", "metz"] },
        2018: { name: "Ligue 1", size: 20, clubs: ["PSG", "Lille", "Lyon", "Marseille", "Nice", "Strasbourg", "Nantes", "Monaco"], others: ["saint etienne", "montpellier herault|montpellier", "stade de reims", "nimes olympique|nimes", "stade rennais", "angers", "girondins bordeaux|girondins de bordeaux|bordeaux", "amiens", "toulouse", "dijon fco", "sm caen|stade malherbe caen|caen", "en avant guingamp|guingamp"] },
        2019: { name: "Ligue 1", size: 20, clubs: ["PSG", "Marseille", "Lille", "Nice", "Lyon", "Monaco", "Strasbourg", "Nantes"], others: ["stade rennais", "stade de reims", "montpellier herault|montpellier", "angers", "girondins bordeaux|girondins de bordeaux|bordeaux", "stade brestois|brest", "metz", "dijon fco", "saint etienne", "nimes olympique|nimes", "amiens", "toulouse"] },
        2020: { name: "Ligue 1", size: 20, clubs: ["Lille", "PSG", "Monaco", "Lyon", "Marseille", "Nice", "Strasbourg", "Nantes"], others: ["stade rennais|rennes", "lens", "montpellier herault|montpellier", "metz", "saint etienne|st etienne", "girondins bordeaux|bordeaux", "angers", "stade de reims|reims", "lorient", "stade brestois|brest", "nimes olympique|nimes", "dijon fco|dijon"] },
        2021: { name: "Ligue 1", size: 20, clubs: ["PSG", "Marseille", "Monaco", "Nice", "Strasbourg", "Lyon", "Nantes", "Lille"], others: ["stade rennais", "lens", "stade brestois|brest", "stade de reims", "montpellier herault|montpellier", "angers", "es troyes|estac troyes|troyes", "lorient", "clermont foot auvergne|clermont foot", "saint etienne", "metz", "girondins bordeaux|girondins de bordeaux|bordeaux"] },
        2022: { name: "Ligue 1", size: 20, clubs: ["PSG", "Marseille", "Lille", "Monaco", "Lyon", "Nice", "Strasbourg", "Nantes"], others: ["lens", "stade rennais", "clermont foot auvergne|clermont foot", "lorient", "stade de reims", "montpellier herault|montpellier", "toulouse", "stade brestois|brest", "auxerre", "ajaccio", "es troyes|estac troyes|troyes", "angers"] },
        2023: { name: "Ligue 1", size: 18, clubs: ["PSG", "Monaco", "Lille", "Nice", "Lyon", "Marseille", "Strasbourg", "Nantes"], others: ["stade brestois|brest", "lens", "stade de reims", "stade rennais", "toulouse", "montpellier herault|montpellier", "le havre|havre athletic club", "metz", "lorient", "clermont foot auvergne|clermont foot"] },
        2024: { name: "Ligue 1", size: 18, clubs: ["PSG", "Marseille", "Monaco", "Nice", "Lille", "Lyon", "Strasbourg", "Nantes"], others: ["lens", "stade brestois|brest", "toulouse", "auxerre", "stade rennais", "angers", "le havre|havre athletic club", "stade de reims", "saint etienne", "montpellier herault|montpellier"] },
        2025: { name: "Ligue 1", size: 18, clubs: ["PSG", "Lille", "Lyon", "Marseille", "Monaco", "Strasbourg", "Nice", "Nantes"], others: ["lens", "stade rennais", "toulouse", "lorient", "paris", "stade brestois|brest", "angers", "le havre|havre athletic club", "auxerre", "metz"] }
      }
    };
  }
});

// src/lib/soccerCareerLeague.ts
function leagueSizeFor(league, year, dugout = false) {
  const ledger = year < LIST_SEASON ? CAREER_LEAGUE_SEASONS[league]?.[year] : void 0;
  if (ledger) return ledger.size;
  const windows = LEAGUE_SIZES[league] ?? (dugout ? DUGOUT_SIZES[league] : void 0);
  if (!windows) return null;
  for (const w of windows) {
    if (year >= w.from && (w.to === void 0 || year <= w.to)) return w.size;
  }
  return null;
}
function hashKey(key) {
  let h = 2166136261;
  for (let i = 0; i < key.length; i++) {
    h ^= key.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
function forkRng(key) {
  let a = hashKey(key) || 1;
  return () => {
    a = a + 1831565813 >>> 0;
    let t = a;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
function readLeagueFinish(r2) {
  const f = r2.leagueFinish;
  if (typeof f !== "number" || !Number.isInteger(f) || f < 1 || f > 40) return null;
  if (f === 1 !== (r2.leagueTitle === true)) return null;
  const z = r2.leagueSize;
  const size = typeof z === "number" && Number.isInteger(z) && z >= 2 && z <= 40 ? z : null;
  if (size !== null && f > size) return null;
  return { finish: f, size };
}
function leagueWithArticle(name) {
  return /^(la |serie |ligue |eredivisie|primeira|liga |division \d|mls$)/i.test(name) ? name : `the ${name}`;
}
function ordinal(n) {
  const tens = n % 100;
  if (tens >= 11 && tens <= 13) return `${n}th`;
  const unit = n % 10;
  return `${n}${unit === 1 ? "st" : unit === 2 ? "nd" : unit === 3 ? "rd" : "th"}`;
}
function listLeague(clubs, label) {
  const f = foldName(label);
  const want = LEAGUE_ALIASES[f];
  const hit = clubs.find((c) => want ? c.league === want : foldName(c.league) === f);
  return hit ? hit.league : null;
}
function identityKey(name) {
  return name.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/ß/g, "ss").replace(/&/g, " and ").split(/[^a-z0-9]+/).filter((w) => w && !IDENTITY_STOP.has(w) && !/^\d+$/.test(w)).join(" ");
}
function ledgerByYear() {
  if (ledgerIndex) return ledgerIndex;
  const index = /* @__PURE__ */ new Map();
  for (const [key, years] of Object.entries(CAREER_LEAGUE_SEASONS)) {
    for (const [y, season] of Object.entries(years)) {
      const year = Number(y);
      const byClub = index.get(year) ?? /* @__PURE__ */ new Map();
      for (const name of season.clubs) {
        byClub.set(clubKey(name), { key, canon: name });
        byClub.set(`#${identityKey(name)}`, { key, canon: name });
      }
      for (const ids of season.others) for (const id of ids.split("|")) byClub.set(`#${id}`, { key, canon: null });
      index.set(year, byClub);
    }
  }
  ledgerIndex = index;
  return index;
}
function ledgerMember(club, year) {
  const byClub = ledgerByYear().get(year);
  if (!byClub) return null;
  return byClub.get(clubKey(club)) ?? byClub.get(`#${identityKey(SC_CLUB_CANON[club] ?? MARKET_SPELLINGS[club] ?? club)}`) ?? null;
}
function ledgerLeague(key, year) {
  if (year >= LIST_SEASON) return null;
  const s = CAREER_LEAGUE_SEASONS[key]?.[year];
  return s ? { key, name: s.name, size: s.size, clubs: s.clubs, others: s.others } : null;
}
function clubLedgerSeason(club, year) {
  if (year >= LIST_SEASON) return null;
  const m = ledgerMember(club, year);
  const s = m ? ledgerLeague(m.key, year) : null;
  return s && m ? { ...s, canon: m.canon } : null;
}
function leagueInYear(club, year) {
  if (year >= LIST_SEASON) return club.league || null;
  return clubLedgerSeason(club.name, year)?.name ?? null;
}
function leagueKeyInYear(club, year) {
  if (year >= LIST_SEASON) return club.league || null;
  return clubLedgerSeason(club.name, year)?.key ?? null;
}
function namedInLeague(club, key, year) {
  return year >= LIST_SEASON || clubLedgerSeason(club, year)?.key === key;
}
function finishLeague(club, year, savedSize) {
  const key = leagueKeyInYear(club, year);
  const name = leagueInYear(club, year);
  if (key === null || name === null) return null;
  if (savedSize !== null && savedSize !== leagueSizeFor(key, year)) return null;
  return { key, name };
}
function managerLeagueField(input, rng) {
  const world = adjustClubsForYear([...input.clubs], input.year);
  const mine = clubKey(input.club);
  let league = input.league ? listLeague(input.clubs, input.league) ?? input.league : input.clubs.find((c) => clubKey(c.name) === mine)?.league ?? null;
  if (input.placed === false && input.year < LIST_SEASON) {
    const real = clubLedgerSeason(input.club, input.year);
    if (real) league = real.key;
    else if (league !== null && ledgerLeague(league, input.year)) {
      return { league: null, size: MANAGER_FIELD, sizeVerified: false, named: [], lineupUnknown: true };
    }
  }
  const ledger = league !== null ? ledgerLeague(league, input.year) : null;
  if (ledger) return ledgerField(input, ledger);
  const inLeague = league !== null && world.some((c) => c.league === league && clubKey(c.name) === mine);
  const myWords = nameWords(input.club);
  const rivals = league === null ? [] : world.filter((c) => c.league === league && clubKey(c.name) !== mine && (inLeague || !nameWords(c.name).some((w) => myWords.includes(w))));
  const names = [];
  const seen = /* @__PURE__ */ new Set();
  for (const c of rivals) {
    const k = clubKey(c.name);
    if (!seen.has(k)) {
      seen.add(k);
      names.push(c.name);
    }
  }
  const verified = league ? leagueSizeFor(league, input.year, true) : null;
  const size = verified ?? Math.max(MANAGER_FIELD, names.length + 1);
  if (names.length > size - 1) {
    for (let i = names.length - 1; i > 0; i -= 1) {
      const j = Math.floor(rng() * (i + 1));
      [names[i], names[j]] = [names[j], names[i]];
    }
  }
  const lineupUnknown = input.year < LIST_SEASON && league !== null;
  return { league, size, sizeVerified: verified !== null, named: lineupUnknown ? [] : names.slice(0, size - 1), lineupUnknown };
}
function ledgerField(input, s) {
  const me = clubLedgerSeason(input.club, input.year);
  const member = me !== null && me.key === s.key;
  let named = s.clubs.filter((n) => !(member && me.canon === n));
  if (!member) {
    const prev = ledgerByYear().get(input.year - 1);
    const seats = [
      ...s.clubs.map((n) => ({ name: n, ids: [clubKey(n), `#${identityKey(n)}`] })),
      ...s.others.map((o) => ({ name: null, ids: o.split("|").map((id) => `#${id}`) }))
    ];
    const cameFrom = (ids, key) => ids.some((id) => prev?.get(id)?.key === key);
    const moved = input.from && input.from !== s.key ? seats.filter((seat2) => !cameFrom(seat2.ids, s.key) && cameFrom(seat2.ids, input.from)) : [];
    const pool = moved.length ? moved : seats;
    const seat = pool[Math.floor(forkRng(`${input.club}|${input.year}|${s.key}|seat`)() * pool.length)];
    if (seat.name !== null) named = named.filter((n) => n !== seat.name);
    const myWords = nameWords(input.club);
    named = named.filter((n) => !nameWords(n).some((w) => myWords.includes(w)));
  }
  return { league: s.key, leagueName: s.name, size: s.size, sizeVerified: true, named, lineupUnknown: false };
}
var LEAGUE_SIZES, DUGOUT_SIZES, MANAGER_FIELD, LIST_SEASON, foldName, clubKey, PLAIN_WORDS, nameWords, LEAGUE_ALIASES, IDENTITY_STOP, MARKET_SPELLINGS, ledgerIndex;
var init_soccerCareerLeague = __esm({
  "src/lib/soccerCareerLeague.ts"() {
    init_careerEras();
    init_clubRivalries();
    init_careerLeagueSeasons();
    LEAGUE_SIZES = {
      "Premier League": [{ from: 1992, to: 1994, size: 22 }, { from: 1995, size: 20 }],
      "La Liga": [{ from: 1990, to: 1994, size: 20 }, { from: 1995, to: 1996, size: 22 }, { from: 1997, size: 20 }],
      "Bundesliga": [{ from: 1990, to: 1990, size: 18 }, { from: 1991, to: 1991, size: 20 }, { from: 1992, size: 18 }],
      "Serie A": [{ from: 1990, to: 2003, size: 18 }, { from: 2004, size: 20 }],
      "Ligue 1": [{ from: 1990, to: 1996, size: 20 }, { from: 1997, to: 2001, size: 18 }, { from: 2002, to: 2022, size: 20 }, { from: 2023, size: 18 }]
    };
    DUGOUT_SIZES = {
      "Championship": [{ from: 2004, size: 24 }],
      /* Round 1040: Club Manager's Serie B is a manager's job now, so a Soccer
         Career dugout can be offered one. Only the 2026-27 season is read (20
         clubs: espn.com/soccer/standings/_/league/ita.2 and Sky Sport Italia's
         "Serie B 2026-27, le squadre del prossimo campionato", 2026-06-07, read
         2026-10-06), so no size is claimed before it. */
      "Serie B": [{ from: 2026, size: 20 }],
      /* The same for Ligue 2: 18 clubs in 2026-27 (espn.com/soccer/standings/
         _/league/fra.2 and Saint-Étienne's own Ligue 2 BKT table, asse.fr, both
         read 2026-10-06). */
      "Ligue 2": [{ from: 2026, size: 18 }],
      /* And the Segunda División: 22 clubs in 2026-27 (espn.com/soccer/standings/
         _/league/esp.2 and laliga.com's LALIGA HYPERMOTION table, both read
         2026-10-06). Club Manager plays 20 of them, but the dugout's table is
         the real league's size, the clubs it does not know unnamed. */
      "Segunda Divisi\xF3n": [{ from: 2026, size: 22 }]
    };
    MANAGER_FIELD = 20;
    LIST_SEASON = 2026;
    foldName = (s) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
    clubKey = (name) => foldName(SC_CLUB_CANON[name] ?? name);
    PLAIN_WORDS = /* @__PURE__ */ new Set(["city", "united", "club", "real", "sporting", "athletic", "atletico", "town", "county", "rovers", "football"]);
    nameWords = (name) => foldName(name).split(/[^a-z0-9]+/).filter((w) => w.length >= 4 && !PLAIN_WORDS.has(w));
    LEAGUE_ALIASES = {
      "efl championship": "Championship",
      "brasileirao serie a": "Brasileirao",
      "supersport hnl": "HNL",
      "mls eastern conference": "MLS",
      "mls western conference": "MLS"
    };
    IDENTITY_STOP = /* @__PURE__ */ new Set(["fc", "sc", "ac", "as", "ss", "us", "sv", "afc", "cf", "cfc", "vfl", "vfb", "tsg", "fsv", "spvgg", "calcio", "sco", "rc", "ogc", "aj", "sd", "ud", "cd", "rcd", "ca", "bsc"]);
    MARKET_SPELLINGS = {
      "Gladbach": "Borussia Monchengladbach",
      "Karlsruhe": "Karlsruher SC",
      "Braunschweig": "Eintracht Braunschweig"
    };
    ledgerIndex = null;
  }
});

// src/lib/soccerCareerDerby.ts
function derbyMeetings(league, year) {
  const windows = DERBY_CADENCE[league];
  if (!windows) return null;
  for (const w of windows) {
    if (year >= w.from && (w.to === void 0 || year <= w.to)) return w.meetings;
  }
  return null;
}
function readMeeting(m) {
  if (!m || typeof m !== "object") return null;
  const o = m;
  if (typeof o.home !== "boolean" || typeof o.played !== "boolean") return null;
  if (!isCount(o.gf) || !isCount(o.ga) || !isCount(o.goals)) return null;
  if (o.won !== void 0 && o.won !== true) return null;
  const out = { home: o.home, gf: o.gf, ga: o.ga, played: o.played, goals: o.goals };
  if (o.won === true) out.won = true;
  return out;
}
function readSeasonDerbies(season) {
  if (!season || typeof season !== "object") return [];
  const raw2 = season.derbies;
  if (!Array.isArray(raw2)) return [];
  const read = [];
  for (const d of raw2) {
    if (!d || typeof d !== "object") return [];
    const o = d;
    if (typeof o.rival !== "string" || !o.rival || typeof o.name !== "string" || !o.name) return [];
    if (typeof o.kind !== "string" || !KINDS.includes(o.kind) || !Array.isArray(o.meetings) || o.meetings.length === 0) return [];
    const meetings = [];
    for (const m of o.meetings) {
      const ok = readMeeting(m);
      if (!ok) return [];
      meetings.push(ok);
    }
    read.push({ rival: o.rival, name: o.name, kind: o.kind, meetings });
  }
  return read;
}
function derbyRecord(derbies) {
  const r2 = { played: 0, w: 0, d: 0, l: 0, goals: 0, heroes: 0 };
  for (const x of derbies) {
    for (const m of x.meetings) {
      if (!m.played) continue;
      r2.played += 1;
      if (m.gf > m.ga) r2.w += 1;
      else if (m.gf < m.ga) r2.l += 1;
      else r2.d += 1;
      r2.goals += m.goals;
      if (m.won) r2.heroes += 1;
    }
  }
  return r2;
}
function careerDerbyRecord(seasons) {
  const all = [];
  for (const s of seasons) all.push(...readSeasonDerbies(s));
  return derbyRecord(all);
}
var DERBY_CADENCE, KINDS, isCount, DERBY_WIN_POP, DERBY_WIN_MORALE, DERBY_LOSS_POP, DERBY_HERO_POP, DERBY_HELP_RULES;
var init_soccerCareerDerby = __esm({
  "src/lib/soccerCareerDerby.ts"() {
    init_keyedRng();
    init_careerEras();
    init_soccerCareerLeague();
    init_clubRivalries();
    DERBY_CADENCE = {
      "Premier League": [{ from: 1990, meetings: 2 }],
      "La Liga": [{ from: 1990, meetings: 2 }],
      "Serie A": [{ from: 1990, meetings: 2 }],
      "Bundesliga": [{ from: 1990, meetings: 2 }],
      "Ligue 1": [{ from: 1990, to: 2018, meetings: 2 }, { from: 2020, meetings: 2 }],
      "Primeira Liga": [{ from: 1990, meetings: 2 }],
      "Brasileirao": [{ from: 2003, meetings: 2 }],
      "Liga MX": [{ from: 1996, to: 2018, meetings: 2 }, { from: 2020, meetings: 2 }]
    };
    KINDS = ["derby", "rivalry"];
    isCount = (v) => typeof v === "number" && Number.isInteger(v) && v >= 0 && v < 100;
    DERBY_WIN_POP = 2;
    DERBY_WIN_MORALE = 2;
    DERBY_LOSS_POP = -2;
    DERBY_HERO_POP = 2;
    DERBY_HELP_RULES = [
      "Derbies: if your club has a real rival in the same league, you meet them twice a season in the league. We only count a rivalry two separate sources back, in leagues and years where we checked how often the clubs meet, so some clubs have none yet.",
      `You play the derbies you are picked for, roughly in line with your league appearances. Each one you win adds ${DERBY_WIN_POP} popularity and ${DERBY_WIN_MORALE} morale, each one you lose takes ${-DERBY_LOSS_POP} off both, a draw changes nothing, the swing is capped every season and your rating is never touched.`,
      `Score the goal that puts you ahead for good in a derby win and the season counts as a Derby Hero season, worth ${DERBY_HERO_POP} more popularity. Example: at Arsenal you beat Tottenham 2-1 at home with the winner and draw 1-1 away, so that is +${DERBY_WIN_POP + DERBY_HERO_POP} popularity, +${DERBY_WIN_MORALE} morale and a Derby Hero.`
    ];
  }
});

// src/lib/arcade.ts
function lehmer(seed) {
  let s = Math.trunc(seed) % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => {
    s = s * 16807 % 2147483647;
    return (s - 1) / 2147483646;
  };
}
function daySeed(dateStr) {
  const digits = dateStr.replace(/-/g, "");
  return parseInt(digits, 10) % 2147483647 || 7;
}
function sprayFor(effort, over, cfg, rng) {
  const magnitude = effort * effort * cfg.power + over * cfg.distance;
  return { x: (rng() * 2 - 1) * magnitude, y: (rng() * 2 - 1) * magnitude * cfg.vertical };
}
function buildLadder(seed, rounds, make) {
  const rng = lehmer(seed);
  const out = [];
  for (let i = 0; i < rounds; i += 1) {
    out.push(make(rounds > 1 ? i / (rounds - 1) : 0, rng, i));
  }
  return out;
}
var ROUNDS_PER_RUN, clamp;
var init_arcade = __esm({
  "src/lib/arcade.ts"() {
    ROUNDS_PER_RUN = 10;
    clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  }
});

// src/lib/freeKick.ts
function flightPath(aim, setup, spray = { x: 0, y: 0 }) {
  const pts = [];
  const bend = aim.curve * (1.25 - aim.power * 0.6) * 0.55;
  const dip = (aim.power - 0.55) * 0.22;
  for (let i = 0; i <= 24; i += 1) {
    const t = i / 24;
    const x = aim.x + bend * t * t + spray.x * t * t;
    const y = aim.y * (1 - t * t * 0.12) - dip * t * t + Math.sin(t * Math.PI) * 0.08 * aim.power + spray.y * t * t;
    pts.push({ x, y });
  }
  return pts;
}
function keeperDive(aim, setup, rng) {
  const read = setup.keeperSkill;
  const guess = rng() * 2 - 1;
  const hurry = clamp(aim.power - 0.5, 0, 0.5) * 0.18;
  const x = aim.x * (read - hurry) + setup.keeperLean * (1 - read) * 0.6 + guess * (1 - read) * 0.5;
  const y = clamp(aim.y * (read + 0.15) + rng() * 0.2, 0, 1);
  return { x: clamp(x, -1.35, 1.35), y };
}
var init_freeKick = __esm({
  "src/lib/freeKick.ts"() {
    init_arcade();
  }
});

// src/lib/captaincy.ts
var init_captaincy = __esm({
  "src/lib/captaincy.ts"() {
  }
});

// src/lib/uclFormatHistory.ts
var init_uclFormatHistory = __esm({
  "src/lib/uclFormatHistory.ts"() {
  }
});

// src/lib/uclTieRule.ts
var init_uclTieRule = __esm({
  "src/lib/uclTieRule.ts"() {
  }
});

// src/lib/intlFormatHistory.ts
var init_intlFormatHistory = __esm({
  "src/lib/intlFormatHistory.ts"() {
  }
});

// src/lib/soccerInternational.ts
var NATION_CONFED, CONFED_POOL, FIFA_POINTS, RANK_ORDER;
var init_soccerInternational = __esm({
  "src/lib/soccerInternational.ts"() {
    init_intlFormatHistory();
    NATION_CONFED = {
      // UEFA
      Albania: "UEFA",
      Armenia: "UEFA",
      Austria: "UEFA",
      Azerbaijan: "UEFA",
      Belarus: "UEFA",
      Belgium: "UEFA",
      "Bosnia & Herzegovina": "UEFA",
      Bulgaria: "UEFA",
      Croatia: "UEFA",
      Cyprus: "UEFA",
      "Czech Republic": "UEFA",
      Denmark: "UEFA",
      England: "UEFA",
      Estonia: "UEFA",
      "Faroe Islands": "UEFA",
      Finland: "UEFA",
      France: "UEFA",
      Georgia: "UEFA",
      Germany: "UEFA",
      Greece: "UEFA",
      Hungary: "UEFA",
      Iceland: "UEFA",
      Ireland: "UEFA",
      Israel: "UEFA",
      Italy: "UEFA",
      Kazakhstan: "UEFA",
      Kosovo: "UEFA",
      Latvia: "UEFA",
      Liechtenstein: "UEFA",
      Lithuania: "UEFA",
      Luxembourg: "UEFA",
      Malta: "UEFA",
      Moldova: "UEFA",
      Montenegro: "UEFA",
      Netherlands: "UEFA",
      "North Macedonia": "UEFA",
      "Northern Ireland": "UEFA",
      Norway: "UEFA",
      Poland: "UEFA",
      Portugal: "UEFA",
      Romania: "UEFA",
      Russia: "UEFA",
      Scotland: "UEFA",
      Serbia: "UEFA",
      Slovakia: "UEFA",
      Slovenia: "UEFA",
      Spain: "UEFA",
      Sweden: "UEFA",
      Switzerland: "UEFA",
      Turkey: "UEFA",
      Ukraine: "UEFA",
      Wales: "UEFA",
      // CONMEBOL
      Argentina: "CONMEBOL",
      Bolivia: "CONMEBOL",
      Brazil: "CONMEBOL",
      Chile: "CONMEBOL",
      Colombia: "CONMEBOL",
      Ecuador: "CONMEBOL",
      Paraguay: "CONMEBOL",
      Peru: "CONMEBOL",
      Uruguay: "CONMEBOL",
      Venezuela: "CONMEBOL",
      // CAF
      Algeria: "CAF",
      Angola: "CAF",
      Benin: "CAF",
      "Burkina Faso": "CAF",
      Cameroon: "CAF",
      "Cape Verde": "CAF",
      Comoros: "CAF",
      Congo: "CAF",
      "DR Congo": "CAF",
      Egypt: "CAF",
      Ethiopia: "CAF",
      Gabon: "CAF",
      Ghana: "CAF",
      Guinea: "CAF",
      "Guinea-Bissau": "CAF",
      "Ivory Coast": "CAF",
      Kenya: "CAF",
      Liberia: "CAF",
      Libya: "CAF",
      Madagascar: "CAF",
      Mali: "CAF",
      Morocco: "CAF",
      Mozambique: "CAF",
      Nigeria: "CAF",
      Senegal: "CAF",
      "Sierra Leone": "CAF",
      "South Africa": "CAF",
      Tanzania: "CAF",
      "The Gambia": "CAF",
      Togo: "CAF",
      Tunisia: "CAF",
      Uganda: "CAF",
      Zambia: "CAF",
      Zimbabwe: "CAF",
      // AFC
      Australia: "AFC",
      Bahrain: "AFC",
      China: "AFC",
      India: "AFC",
      Indonesia: "AFC",
      Iran: "AFC",
      Iraq: "AFC",
      Japan: "AFC",
      Jordan: "AFC",
      Kuwait: "AFC",
      Lebanon: "AFC",
      "North Korea": "AFC",
      Oman: "AFC",
      Philippines: "AFC",
      Qatar: "AFC",
      "Saudi Arabia": "AFC",
      "South Korea": "AFC",
      Tajikistan: "AFC",
      Thailand: "AFC",
      "United Arab Emirates": "AFC",
      Uzbekistan: "AFC",
      Vietnam: "AFC",
      // Both play Asian Cup and AFC World Cup qualifying, both are inside the
      // published world top 100, so both are here as opponents.
      Syria: "AFC",
      Palestine: "AFC",
      // CONCACAF
      Canada: "CONCACAF",
      "Costa Rica": "CONCACAF",
      Cuba: "CONCACAF",
      "Cura\xE7ao": "CONCACAF",
      "Dominican Republic": "CONCACAF",
      "El Salvador": "CONCACAF",
      Guatemala: "CONCACAF",
      Haiti: "CONCACAF",
      Honduras: "CONCACAF",
      Jamaica: "CONCACAF",
      Mexico: "CONCACAF",
      Panama: "CONCACAF",
      Suriname: "CONCACAF",
      "Trinidad and Tobago": "CONCACAF",
      USA: "CONCACAF",
      /* OFC. New Zealand is the only Oceanian side the player picker offers, but
         a confederation of one cannot run a qualifying group, so the other ten
         full members are here as opponents. List and count from
         en.wikipedia.org/wiki/Oceania_Football_Confederation (11 full members),
         read August 2026. */
      "New Zealand": "OFC",
      "New Caledonia": "OFC",
      Tahiti: "OFC",
      Fiji: "OFC",
      "Solomon Islands": "OFC",
      "Papua New Guinea": "OFC",
      Vanuatu: "OFC",
      Samoa: "OFC",
      "American Samoa": "OFC",
      "Cook Islands": "OFC",
      Tonga: "OFC"
    };
    CONFED_POOL = {
      UEFA: [],
      CONMEBOL: [],
      CAF: [],
      AFC: [],
      CONCACAF: [],
      OFC: []
    };
    for (const [nation, conf] of Object.entries(NATION_CONFED)) CONFED_POOL[conf].push(nation);
    FIFA_POINTS = {
      Spain: 1995.88,
      Argentina: 1970.37,
      France: 1948.97,
      England: 1922.83,
      Brazil: 1804.92,
      Morocco: 1803.99,
      Portugal: 1787.85,
      Belgium: 1778.36,
      Netherlands: 1775.54,
      Mexico: 1754.3,
      Colombia: 1739.89,
      Germany: 1726.22,
      Croatia: 1723.05,
      Switzerland: 1710.88,
      Italy: 1704.73,
      USA: 1690.33,
      Japan: 1673.68,
      Senegal: 1653.43,
      Norway: 1651.29,
      Uruguay: 1634.7,
      Denmark: 1619.47,
      Iran: 1609.85,
      Austria: 1598.82,
      Egypt: 1597.04,
      Ecuador: 1592.59,
      Nigeria: 1585.02,
      Turkey: 1582.54,
      Australia: 1581.51,
      Algeria: 1576.8,
      Canada: 1571.34,
      "Ivory Coast": 1565.47,
      "South Korea": 1558.72,
      Ukraine: 1549.29,
      Paraguay: 1542.48,
      Russia: 1529.6,
      Poland: 1526.18,
      Sweden: 1525.58,
      Wales: 1516.95,
      Hungary: 1506.39,
      Serbia: 1502.13,
      "DR Congo": 1495.48,
      Scotland: 1491.22,
      Cameroon: 1481.24,
      Panama: 1478.41,
      Slovakia: 1473.66,
      Greece: 1473.19,
      Venezuela: 1469.18,
      "Czech Republic": 1467.26,
      Chile: 1458.2,
      Peru: 1457.69,
      "Costa Rica": 1456.03,
      Romania: 1455.89,
      Mali: 1455.59,
      "South Africa": 1451.24,
      Ireland: 1441.1,
      // listed as Republic of Ireland
      Slovenia: 1441.09,
      Tunisia: 1426.58,
      "Saudi Arabia": 1425.52,
      Qatar: 1411.06,
      Uzbekistan: 1409.73,
      "Bosnia & Herzegovina": 1408.93,
      "Burkina Faso": 1406.99,
      Iraq: 1404.17,
      "Cape Verde": 1402.97,
      // listed as Cabo Verde
      Ghana: 1387,
      Honduras: 1378.97,
      Albania: 1376.03,
      "United Arab Emirates": 1370.47,
      "North Macedonia": 1369.16,
      "Northern Ireland": 1365.3,
      Jamaica: 1357.84,
      Georgia: 1355.26,
      Jordan: 1350.41,
      Iceland: 1342.77,
      Finland: 1341.92,
      Israel: 1333.9,
      Bolivia: 1326,
      Kosovo: 1319.12,
      Oman: 1306.9,
      Montenegro: 1301.98,
      Guinea: 1295.6,
      "Cura\xE7ao": 1285.64,
      Syria: 1283.05,
      Gabon: 1272.51,
      Bulgaria: 1271.68,
      "New Zealand": 1269.8,
      Angola: 1265.58,
      Haiti: 1264.58,
      Uganda: 1264.09,
      Thailand: 1256.73,
      Zambia: 1255.82,
      China: 1254.81,
      // listed as China PR
      Bahrain: 1254.41,
      Benin: 1252.17,
      Palestine: 1243.71,
      Belarus: 1242.88,
      Guatemala: 1238.74,
      Luxembourg: 1232.82,
      Vietnam: 1230.67,
      "El Salvador": 1225.34
    };
    RANK_ORDER = Object.entries(FIFA_POINTS).sort((a, b) => b[1] - a[1]).map((e) => e[0]);
  }
});

// src/lib/clubManagerUclGroups.ts
var init_clubManagerUclGroups = __esm({
  "src/lib/clubManagerUclGroups.ts"() {
  }
});

// src/lib/soccerCareerContinental.ts
var ESPN_ELITE_SOURCE, ESPN_ELITE, GRID_FROM, GRID_STEP, GRID_POINTS, PASS_GRID;
var init_soccerCareerContinental = __esm({
  "src/lib/soccerCareerContinental.ts"() {
    init_soccerInternational();
    init_careerEras();
    init_uclFormatHistory();
    init_clubManagerUclGroups();
    ESPN_ELITE_SOURCE = { url: "https://www.espn.com/soccer/story/_/id/41270886/new-afc-champions-league-format-explained/" };
    ESPN_ELITE = 'ESPN, "The new AFC Champions League format explained", ' + ESPN_ELITE_SOURCE.url + ", 15 September 2024, read 2026-10-05: the AFC Champions League Elite from 2024-25, in place of the AFC Champions League, every tie from the quarter-finals one match";
    GRID_FROM = -1.5;
    GRID_STEP = 0.125;
    GRID_POINTS = 37;
    PASS_GRID = Array.from({ length: GRID_POINTS }, (_, i) => GRID_FROM + i * GRID_STEP);
  }
});

// src/data/soccerCareerClubPool.ts
var CAREER_CLUB_POOL;
var init_soccerCareerClubPool = __esm({
  "src/data/soccerCareerClubPool.ts"() {
    CAREER_CLUB_POOL = [
      { id: "cm-bournemouth", name: "Bournemouth", country: "England", tier: 4, color: "#da291c", league: "Premier League" },
      { id: "cm-coventry-city", name: "Coventry City", country: "England", tier: 4, color: "#66b2e8", league: "Premier League" },
      { id: "cm-hull-city", name: "Hull City", country: "England", tier: 4, color: "#f5a12d", league: "Premier League" },
      { id: "cm-ipswich-town", name: "Ipswich Town", country: "England", tier: 4, color: "#2450a3", league: "Premier League" },
      { id: "cm-leeds-united", name: "Leeds United", country: "England", tier: 4, color: "#ffcd00", league: "Premier League" },
      { id: "cm-nottingham-forest", name: "Nottingham Forest", country: "England", tier: 2, color: "#dd0000", league: "Premier League" },
      { id: "cm-sunderland", name: "Sunderland", country: "England", tier: 4, color: "#eb172b", league: "Premier League" },
      { id: "cm-birmingham-city", name: "Birmingham City", country: "England", tier: 4, color: "#2966b0", league: "Championship" },
      { id: "cm-blackburn-rovers", name: "Blackburn Rovers", country: "England", tier: 4, color: "#009ee0", league: "Championship" },
      { id: "cm-bolton-wanderers", name: "Bolton Wanderers", country: "England", tier: 4, color: "#263c7e", league: "Championship" },
      { id: "cm-bristol-city", name: "Bristol City", country: "England", tier: 4, color: "#e21a23", league: "Championship" },
      { id: "cm-burnley", name: "Burnley", country: "England", tier: 4, color: "#8b2a4a", league: "Championship" },
      { id: "cm-cardiff-city", name: "Cardiff City", country: "Wales", tier: 4, color: "#0070b5", league: "Championship" },
      { id: "cm-charlton-athletic", name: "Charlton Athletic", country: "England", tier: 4, color: "#d4021d", league: "Championship" },
      { id: "cm-derby-county", name: "Derby County", country: "England", tier: 4, color: "#d8d8d8", league: "Championship" },
      { id: "cm-lincoln-city", name: "Lincoln City", country: "England", tier: 4, color: "#e30613", league: "Championship" },
      { id: "cm-middlesbrough", name: "Middlesbrough", country: "England", tier: 4, color: "#e21a23", league: "Championship" },
      { id: "cm-millwall", name: "Millwall", country: "England", tier: 4, color: "#25457a", league: "Championship" },
      { id: "cm-portsmouth", name: "Portsmouth", country: "England", tier: 4, color: "#2450a3", league: "Championship" },
      { id: "cm-preston-north-end", name: "Preston North End", country: "England", tier: 4, color: "#b9c4d1", league: "Championship" },
      { id: "cm-qpr", name: "QPR", country: "England", tier: 4, color: "#1d5ba4", league: "Championship" },
      { id: "cm-sheffield-united", name: "Sheffield United", country: "England", tier: 4, color: "#ee2737", league: "Championship" },
      { id: "cm-southampton", name: "Southampton", country: "England", tier: 4, color: "#d71920", league: "Championship" },
      { id: "cm-stoke-city", name: "Stoke City", country: "England", tier: 4, color: "#e03a3e", league: "Championship" },
      { id: "cm-swansea-city", name: "Swansea City", country: "Wales", tier: 4, color: "#c8c8c8", league: "Championship" },
      { id: "cm-watford", name: "Watford", country: "England", tier: 4, color: "#fbee23", league: "Championship" },
      { id: "cm-west-brom", name: "West Brom", country: "England", tier: 4, color: "#3a5da8", league: "Championship" },
      { id: "cm-wrexham", name: "Wrexham", country: "Wales", tier: 4, color: "#ce1126", league: "Championship" },
      { id: "cm-alaves", name: "Alaves", country: "Spain", tier: 4, color: "#0761af", league: "La Liga" },
      { id: "cm-deportivo", name: "Deportivo", country: "Spain", tier: 4, color: "#0068b3", league: "La Liga" },
      { id: "cm-elche", name: "Elche", country: "Spain", tier: 4, color: "#1a9349", league: "La Liga" },
      { id: "cm-espanyol", name: "Espanyol", country: "Spain", tier: 4, color: "#007fc8", league: "La Liga" },
      { id: "cm-getafe", name: "Getafe", country: "Spain", tier: 4, color: "#1265b3", league: "La Liga" },
      { id: "cm-levante", name: "Levante", country: "Spain", tier: 4, color: "#9c2743", league: "La Liga" },
      { id: "cm-malaga", name: "Malaga", country: "Spain", tier: 4, color: "#29a5dd", league: "La Liga" },
      { id: "cm-osasuna", name: "Osasuna", country: "Spain", tier: 4, color: "#d91a21", league: "La Liga" },
      { id: "cm-racing-santander", name: "Racing Santander", country: "Spain", tier: 4, color: "#009e49", league: "La Liga" },
      { id: "cm-rayo-vallecano", name: "Rayo Vallecano", country: "Spain", tier: 4, color: "#e53027", league: "La Liga" },
      { id: "cm-valencia", name: "Valencia", country: "Spain", tier: 4, color: "#ee7f24", league: "La Liga" },
      { id: "cm-athletico-paranaense", name: "Athletico Paranaense", country: "Brazil", tier: 4, color: "#c8102e", league: "Brasileirao" },
      { id: "cm-fluminense", name: "Fluminense", country: "Brazil", tier: 4, color: "#7a1e3a", league: "Brasileirao" },
      { id: "cm-bahia", name: "Bahia", country: "Brazil", tier: 4, color: "#0057b8", league: "Brasileirao" },
      { id: "cm-atletico-mineiro", name: "Atletico Mineiro", country: "Brazil", tier: 4, color: "#2b2b2b", league: "Brasileirao" },
      { id: "cm-coritiba", name: "Coritiba", country: "Brazil", tier: 4, color: "#0a7040", league: "Brasileirao" },
      { id: "cm-red-bull-bragantino", name: "Red Bull Bragantino", country: "Brazil", tier: 4, color: "#d9d9d9", league: "Brasileirao" },
      { id: "cm-vitoria", name: "Vitoria", country: "Brazil", tier: 4, color: "#d02128", league: "Brasileirao" },
      { id: "cm-mirassol", name: "Mirassol", country: "Brazil", tier: 4, color: "#f5d800", league: "Brasileirao" },
      { id: "cm-vasco-da-gama", name: "Vasco da Gama", country: "Brazil", tier: 4, color: "#2b2b2b", league: "Brasileirao" },
      { id: "cm-internacional", name: "Internacional", country: "Brazil", tier: 4, color: "#d02128", league: "Brasileirao" },
      { id: "cm-remo", name: "Remo", country: "Brazil", tier: 4, color: "#12294a", league: "Brasileirao" },
      { id: "cm-chapecoense", name: "Chapecoense", country: "Brazil", tier: 4, color: "#0a7040", league: "Brasileirao" }
    ];
  }
});

// src/lib/soccerCareerCup.ts
var init_soccerCareerCup = __esm({
  "src/lib/soccerCareerCup.ts"() {
    init_careerEras();
    init_soccerCareerContinental();
    init_keyedRng();
  }
});

// src/lib/soccerPhone.ts
var CONTACTS, CONTACT_BY_ID, R, B, C, CONVOS, CONVO_BY_ID;
var init_soccerPhone = __esm({
  "src/lib/soccerPhone.ts"() {
    init_careerEras();
    init_soccerCareerLeague();
    init_soccerCareerCup();
    CONTACTS = [
      { id: "mum", name: "Mum", emoji: "\u2764\uFE0F", blurb: "Answers on the first ring" },
      { id: "dad", name: "Dad", emoji: "\u{1F9D4}", blurb: "Watched every minute you ever played" },
      { id: "grandad", name: "Grandad", emoji: "\u{1F9D3}", blurb: "Shouts at the telly on your behalf" },
      { id: "partner", name: "Your partner", emoji: "\u{1F49E}", blurb: "The one who sees the bad days" },
      { id: "bestmate", name: "Best mate", emoji: "\u{1F919}", blurb: "Knew you before any of this" },
      { id: "agent", name: "Your agent", emoji: "\u{1F4BC}", blurb: "Always half a deal ahead of you" },
      { id: "gaffer", name: "The gaffer", emoji: "\u{1F4CB}", blurb: "Picks the team, picks his words" },
      { id: "captain", name: "Club captain", emoji: "\u{1F981}", blurb: "Runs the dressing room" },
      { id: "roomie", name: "Away room mate", emoji: "\u{1F634}", blurb: "Snores, shares everything else" },
      { id: "physio", name: "Club physio", emoji: "\u{1FA79}", blurb: "Knows your body better than you" },
      { id: "fitness", name: "Fitness coach", emoji: "\u{1F3CB}\uFE0F", blurb: "Owns the sadistic clipboard" },
      { id: "youthcoach", name: "Old youth coach", emoji: "\u{1F474}", blurb: "Still calls you kid" },
      { id: "academy", name: "Academy kid", emoji: "\u{1F331}", blurb: "Looks at you the way you looked at someone" },
      { id: "kitman", name: "Kit man", emoji: "\u{1F9FA}", blurb: "Has seen forty years of you lot" },
      { id: "journo", name: "Journalist", emoji: "\u{1F4F0}", blurb: "Friendly until he is not" },
      { id: "natcoach", name: "Country manager", emoji: "\u{1F30D}", blurb: "Names the squad in March" },
      { id: "rival", name: "Rival", emoji: "\u{1FA9E}", blurb: "The name next to yours, forever" }
    ];
    CONTACT_BY_ID = Object.fromEntries(CONTACTS.map((c) => [c.id, c]));
    R = (label, say, back, warm = 6, extra = {}) => ({ label, say, back, warm, ...extra });
    B = (text, ...replies) => ({ text, replies });
    C = (id, contact, phase, beats, opts = {}) => ({ id, contact, phase, beats, starter: true, ...opts });
    CONVOS = [
      /* ── Mum ── */
      C("mum_checkin", "mum", "any", [
        B(
          "Just checking you are eating something other than chicken and rice. Are you?",
          R("Send her a photo of dinner", "Sending you a photo. There are vegetables on it. Two kinds", "TWO kinds. My son. Look at you", 8, { morale: 3 }),
          R("Be honest", "Chicken and rice. Every day. I have made peace with it", "You are a professional athlete not a prisoner. I am posting you a lasagne", 6, { morale: 2 }),
          R("Turn it round on her", "Are YOU eating properly is the question", "Do not do that. Answer the question", 4)
        ),
        B(
          "Right. Next thing. Are you sleeping? And do not say fine.",
          R("Tell her the truth", "Not brilliant. Head is loud after games", "Then ring me after games instead of lying in the dark. Any time. I mean it", 9, { morale: 5, perk: "calm" }),
          R("Say you are fine", "I am fine mum", "You said fine. I said do not say fine", 3),
          R("Make her laugh", "I sleep like a baby. Wake up every two hours crying", "Cheeky. Go to bed", 6, { morale: 2 })
        ),
        B(
          "One more thing and I will leave you alone. Sunday dinner. Yes or no.",
          R("Yes", "Yes. What time", "One o clock and do not be late like your father", 9, { morale: 5 }),
          R("Bring the whole squad", "Can I bring two of the lads? They live on their own", "Two? I will do a leg of lamb. Tell them to bring nothing", 10, { morale: 6, perk: "lift" }),
          R("Cannot", "Away game Sunday mum", "Then the Sunday after. I am writing it down", 4)
        )
      ]),
      C("mum_proud", "mum", "any", [
        B(
          "Your nan told the whole street about you again. She has a photo in her purse and everything.",
          R("Send something for nan", "Tell her I am sending a signed shirt for the purse photo wall", "She is going to cry. Then she is going to tell the street again", 9, { karma: 4, morale: 3 }),
          R("Be embarrassed", "Mum that is so embarrassing please stop her", "Absolutely not. Let the woman have this", 5),
          R("Leave it", "Ok", "Ok? That is all I get? Ok?", -2, { warm: -2 })
        ),
        B(
          "She asked if you are happy. Not doing well. Happy. I said I would ask properly.",
          R("Say yes and mean it", "Honestly? Yeah. Tired, but yeah", "Good. That is the only bit I actually worry about", 8, { morale: 4 }),
          R("Admit it is heavy", "Some weeks it is a lot mum", "Then come home for a weekend. The kettle works and nobody wants anything from you here", 9, { morale: 6, perk: "calm" }),
          R("Dodge it", "Ask me after Saturday", "That is not an answer and you know it", 2)
        ),
        B(
          "She wants to know if you will come to the street party when you next win something.",
          R("Say yes", "If we win anything I am coming home with it. Tell her to get the bunting", "The bunting has been in the loft for two years waiting", 10, { karma: 4, morale: 4 }),
          R("Say it is too much", "I would get mobbed mum", "You would get fed. Different thing", 5)
        )
      ]),
      C("mum_worry", "mum", "any", [
        B(
          "I saw what they were saying about you online. I know you say do not read it. I read it.",
          R("Tell her to stop reading", "Mum. Log off. Please. It is noise", "It is my son they are talking about. But fine. Logging off", 7, { morale: 2 }),
          R("Let her be angry", "Go on then. Say what you want to say", "I want to say they have never kicked a ball in their lives. There. Done", 8, { morale: 4 }),
          R("Laugh it off", "Half of them are twelve mum", "The other half are grown men which is worse", 6, { morale: 2 })
        ),
        B(
          "Promise me you are talking to someone about it. Not just me at midnight.",
          R("Promise properly", "I will talk to the club doc this week. Promise", "Good boy. Now go and win something", 9, { morale: 5, karma: 3, perk: "calm" }),
          R("Say you have got it", "I have got it. Really", "Hm. I am checking back in a month", 4)
        ),
        B(
          "And do me a favour. Do not read the comments before a game. Read them never actually.",
          R("Agree to delete the apps", "Deleting the apps til the end of the season", "That is my boy. Watch how much lighter you feel", 10, { morale: 6, perk: "calm" }),
          R("Half agree", "I will stop before games at least", "Half a promise. I will take it", 6, { morale: 2 })
        )
      ]),
      /* ── Dad ── */
      C("dad_analysis", "dad", "any", [
        B(
          "Watched it back three times. You were dropping too deep in the second half son. Coming to get the ball because you wanted a touch.",
          R("Take it on the chin", "You are right. I got frustrated and went looking for it", "That is all I wanted to hear. Stay high, they have to deal with you", 8, { perk: "sharp" }),
          R("Argue back", "There was nobody else showing for it. What was I meant to do", "Then let them lose it. Not your job to fix their bottle", 5),
          R("Tell him to relax", "Dad it is one game", "Three times I watched it. THREE", 3)
        ),
        B(
          "Anyway. Your mother says I am not allowed to send you notes at midnight anymore.",
          R("Tell him to keep sending", "Keep sending them. Nobody else tells me the truth", "Right. Notes continue. Do not tell her", 9, { morale: 4 }),
          R("Agree with mum", "She might have a point", "Traitor", 4)
        ),
        B(
          "Right. Last one. What are you actually working on this week. In training. Specifically.",
          R("Give him a real answer", "First touch away from pressure. Doing 200 a day on my own", "THAT is an answer. Two hundred a day. Good lad", 9, { perk: "sharp" }),
          R("Say you do not know", "Whatever the coaches put on honestly", "Then pick something yourself. Nobody built a career doing the group session", 7, { perk: "sharp" }),
          R("Tell him to leave it", "Dad. Enough for tonight", "Alright alright. Night son", 3)
        )
      ]),
      C("dad_firstboots", "dad", "any", [
        B(
          "Found your first pair of boots in the loft. Size 3. Held together with tape and hope.",
          R("Ask him to keep them", "Do not throw those out. Ever", "They are going in a box with your name on it. Already done", 9, { morale: 5 }),
          R("Ask for a photo", "Send me a photo of them", "Sent. Look at the state of the left one", 7, { morale: 3 }),
          R("Bin them", "Chuck them, I have got hundreds of pairs now", "You have got hundreds of pairs because of that pair", -1, { warm: -4 })
        ),
        B(
          "Your mother wants to know if you remember who paid for them.",
          R("Say thank you properly", "I know exactly who paid for them. And the petrol to every away game. Thank you", "Stop it. You will set me off", 10, { morale: 6, karma: 4 }),
          R("Joke about it", "The council?", "The COUNCIL. Right", 5)
        ),
        B(
          "She says put them in the cabinet with your medals. I said you have not got a cabinet.",
          R("Promise the cabinet", "Tell her I am building one. Boots go on the top shelf", "Top shelf. Above the medals. She will love that", 10, { morale: 5 }),
          R("Admit you have no medals yet", "I have not won anything yet dad", "Yet. That word is doing a lot of work and I like it", 8, { morale: 4, perk: "sharp" })
        )
      ]),
      C("dad_pressure", "dad", "pro", [
        B(
          "Lads at work keep asking me when you are going to a bigger club. I keep telling them to ask you.",
          R("Give him something to say", "Tell them my dad has no idea and neither do I. Which is true", "Perfect. That will shut them up for a week", 7),
          R("Be honest about it", "Honestly? I think about it every day dad", "Then think about it properly and stop letting other people think it for you", 8, { perk: "sharp" }),
          R("Get annoyed", "Tell them to mind their business", "They are just proud of you in a stupid way. That is all it is", 3)
        )
      ], { minAge: 20 }),
      /* ── Grandad ── */
      C("grandad_ticket", "grandad", "any", [
        B(
          "Still got my seat. Row H. Been in that row since 1974 and I am not moving for anybody.",
          R("Offer him the good seats", "I can get you in the family box. Heated. Cup of tea and everything", "Heated? Row H it is then. But tell your mother I considered it", 8, { morale: 4 }),
          R("Respect the row", "Row H forever. I would not dare move you", "Good lad. You understand", 9, { morale: 3 })
        ),
        B(
          "Here. When you score, do the thing. You know the thing.",
          R("Promise the celebration", "Next one is for you. Point at Row H", "I will have my hat off and everything", 10, { morale: 6, karma: 3 }),
          R("Play it down", "I do not really do celebrations grandad", "You will do this one", 5)
        ),
        B(
          "And bring your nan a scarf from the away end. She collects them. Do not ask me why.",
          R("Get her the scarf", "Away scarf, next trip. Consider it done", "She has 31 of them. You are keeping a woman happy here", 9, { morale: 4 }),
          R("Get her the whole lot", "I will get her one from every away ground this season", "Now you have started something. She will count them", 10, { morale: 6, karma: 3 })
        )
      ]),
      C("grandad_oldtimes", "grandad", "any", [
        B(
          "In my day the ball was heavier and the pitch was mud from November. You lot play on a carpet.",
          R("Wind him up", "And you walked to the ground uphill both ways", "Do not be clever. I have got photographs", 7, { morale: 3 }),
          R("Ask him about it", "What was the best player you ever saw live?", "Now that is a proper question. Get the kettle on, this takes a while", 9, { morale: 4 })
        )
      ]),
      /* ── Partner ── */
      C("partner_time", "partner", "any", [
        B(
          "You have been home four nights this month. I counted. I was not going to say anything but I counted.",
          R("Own it", "That is on me. Not the schedule, me. I will fix it", "Thank you for not arguing with the number", 9, { morale: 5, karma: 4 }),
          R("Explain the schedule", "Away trip, then internationals, then away again. It is the calendar not me", "I know what the calendar is. I asked about you", 3),
          R("Get defensive", "This is the job. You knew that", "I did. Does not make the house any less quiet", -3, { warm: -6, morale: -3 })
        ),
        B(
          "So what does fixing it actually look like. Be specific.",
          R("Make a real plan", "Two nights a week, phone in a drawer, no exceptions. Starting Tuesday", "Tuesday. I am holding you to it and I am putting it in the calendar", 10, { morale: 8, perk: "calm" }),
          R("Promise vaguely", "I will be around more, I promise", "That is not specific. But ok", 3)
        ),
        B(
          "Ok. And when you are home, actually be home. Not on the phone reading about yourself.",
          R("Agree", "Phone in the drawer. I mean it", "Then I will stop pretending I do not check it either", 10, { morale: 6, perk: "calm" }),
          R("Push back gently", "Some of that is work though", "Some of it. Not all of it. You know the difference", 5)
        )
      ], { needs: (s) => !!s.hasRelationship || !!s.family?.isMarried }),
      C("partner_afterloss", "partner", "pro", [
        B(
          "I watched it. Do you want me to say something nice or do you want me to leave it alone.",
          R("Ask to be left alone", "Leave it alone tonight. Tomorrow I will talk", "Ok. Food is in the oven. Not talking about it", 8, { morale: 4 }),
          R("Ask for something nice", "Say something nice. I am on the floor here", "You were the only one who kept running. I watched you the whole way", 9, { morale: 7 }),
          R("Snap at her", "Do not watch them if you are going to analyse them", "Right. Noted", -4, { warm: -8, morale: -4 })
        ),
        B(
          "For what it is worth, the version of you that comes home is the one I actually like.",
          R("Say it back", "That version only exists because of you. I know that", "Now you are just being nice because I made food", 10, { morale: 8 }),
          R("Deflect", "Give it a week and you will change your mind", "Stop it", 4)
        ),
        B(
          "Do you want me at the next one or would you rather I was not in the stand?",
          R("Want them there", "I look for you every time. Be there", "Then I am there. Front row, terrible singing", 10, { morale: 7 }),
          R("Ask them to skip it", "Skip this one. It is going to be horrible", "Ok. But I am watching it at home and shouting anyway", 6, { morale: 2 })
        )
      ], { needs: (s) => !!s.hasRelationship || !!s.family?.isMarried }),
      C("partner_move", "partner", "pro", [
        B(
          "If you moved clubs, would you actually ask me first. Genuine question.",
          R("Say yes and mean it", "You would be the first call. Before my agent. Before anyone", "Good. Because I would go anywhere with you, I just want to be asked", 10, { morale: 6, karma: 4 }),
          R("Be honest about the business", "Honestly these things move fast and sometimes there is no time", "Then make time. It is my life too", 4),
          R("Joke", "Depends where", "Wrong answer. Try again", 2)
        ),
        B(
          "Where would you actually go, if it was only up to you.",
          R("Somewhere you would win", "Somewhere I would win everything. That is the whole point", "Then go and win it. I will find a coffee shop I like", 9, { morale: 5, perk: "offer" }),
          R("Somewhere you would play", "Somewhere I would play every week. Sick of watching", "That is the most honest thing you have said all month", 9, { morale: 5, perk: "offer" }),
          R("Nowhere", "Nowhere. I like it here", "Then stay and stop scrolling transfer rumours at 1am", 7, { morale: 3 })
        )
      ], { minAge: 20, needs: (s) => !!s.hasRelationship || !!s.family?.isMarried }),
      /* ── Best mate from home ── */
      C("mate_fivea", "bestmate", "any", [
        B(
          "Five a side Thursday. Same cage. Lads still think they can mark you. Are you coming or are you too famous",
          R("Turn up", "I am coming and I am not going easy on anyone", "The cage is going to be RAMMED. Word will get out in an hour", 8, { morale: 5, popularity: 2 }),
          R("Send money for the pitch", "Cannot make it but I have paid for the pitch for the rest of the year", "Absolute scenes. You are a legend", 6, { karma: 4, cash: -0.01 }),
          R("Leave him hanging", "", "Right. Say no more", -4, { warm: -8, karma: -4 })
        ),
        B(
          "Serious question though. Are you alright? You have gone quiet with everyone.",
          R("Open up", "Bit lost if I am honest mate", "Then get in the cage Thursday. Nobody in there cares what you earn", 10, { morale: 7, perk: "calm" }),
          R("Keep it light", "I am fine. Busy", "Busy. Right. Thursday. I am not asking", 5)
        ),
        B(
          "Also everyone keeps asking me if you have changed. I keep saying no. Have you?",
          R("Ask him honestly", "You tell me. You would know before I would", "Bit. Not in a bad way. You are just tired all the time", 9, { morale: 4 }),
          R("Say no", "Not a chance. Same idiot", "Correct answer and mostly true", 8, { morale: 3 }),
          R("Get defensive", "Why, what have they been saying", "Nothing. Forget I said it", 2)
        )
      ]),
      C("mate_wedding", "bestmate", "pro", [
        B(
          "Getting married in June. You are best man. Not a question, an announcement.",
          R("Say yes immediately", "Obviously. Try and stop me", "Speech better be good. No football stories. Ok one football story", 10, { morale: 7, karma: 4 }),
          R("Check the fixtures", "Let me check the fixture list first mate", "Mate. June. YOU are the fixture list", 3),
          R("Say no", "I cannot commit to anything that far out", "Wow. Ok", -5, { warm: -10, karma: -6 })
        ),
        B(
          "One more thing. Do not turn up with security. It is a village hall.",
          R("Agree", "Just me and a suit. Promise", "Perfect. Uncle Ray will still ask you for a trial", 9, { morale: 4 }),
          R("Insist", "I have to bring one guy, that is the club rule", "Fine. Put him on the buffet, he will love it", 6)
        ),
        B(
          "Last thing. The speech. Are you actually going to do it or are you going to wing it.",
          R("Write it properly", "I have already started writing it. Two pages", "TWO PAGES. Mate. I am going to cry in front of my in laws", 10, { morale: 6, karma: 3 }),
          R("Wing it", "I will wing it. It will be fine", "Famous last words from a man who cannot do a post match interview", 5)
        )
      ], { minAge: 22 }),
      /* ── Agent ── */
      C("agent_interest", "agent", "pro", [
        B(
          "Two clubs have called this week. One is serious, one is fishing. Do you want the names or do you want me to handle it",
          R("Ask for the names", "Names. Now. I want to know who actually rates me", "Sending them. Do not screenshot this to anyone", 8, { perk: "offer" }),
          R("Let him handle it", "Handle it. Bring me something real or nothing at all", "That is how I like to work. Leave it with me", 7, { perk: "offer" }),
          R("Shut it down", "Not interested. I am happy here", "Noted. I will tell them the door is shut. For now", 5, { morale: 3 })
        ),
        B(
          "Before I go back to them. What actually matters to you. Money, minutes, or medals.",
          R("Minutes", "Minutes. I cannot develop watching", "Good. That narrows it and it is the right answer at your age", 9, { perk: "sharp" }),
          R("Medals", "Medals. I want to win things while I still can", "Then we are aiming higher and I am asking for less. Understood", 9, { perk: "offer" }),
          R("Money", "Money. I am not going to pretend otherwise", "Refreshing. I can absolutely work with that", 6, { karma: -3, cash: 0.4 })
        ),
        B(
          "Right. I am going to go and be annoying at somebody on your behalf. Anything you do NOT want?",
          R("No sideways moves", "Nothing sideways. If it is not a step up I am not moving", "Understood. That rules out two of them already", 9, { perk: "offer" }),
          R("Nowhere I would not play", "Nowhere that signs me to sit me on a bench", "Right. I will ask about minutes before I ask about money", 9, { perk: "offer" }),
          R("Leave it with him", "Surprise me", "Dangerous words to say to an agent", 5)
        )
      ], { minAge: 18 }),
      C("agent_contract", "agent", "pro", [
        B(
          "Your club want to open contract talks early. That is a good sign and also a trap. They want to lock you in cheap.",
          R("Play it patient", "Let them wait. I will let the season do the talking", "That is the play. Every goal from here is a pay rise", 8, { perk: "offer" }),
          R("Sign now for security", "I would rather have it done. Get me a fair deal now", "Safe. Boring. Honestly, not wrong either", 7, { morale: 4 }),
          R("Demand the world", "Tell them the number and watch their faces", "I will enjoy that meeting. It may not end well", 4, { karma: -3 })
        ),
        B(
          "One more thing and then I will leave you alone. Are you happy at this club, actually.",
          R("Yes", "Yeah. I would stay", "Then I negotiate like a man who does not want to leave. Costs us a bit. Worth it", 8, { morale: 5 }),
          R("No", "No. I have outgrown it", "Right. Then we are having a very different conversation in January", 7, { perk: "offer" })
        ),
        B(
          "One last thing, and I ask everybody this. What do you want people to say about you at 35.",
          R("That he was hard to play against", "That I was a nightmare to play against for fifteen years", "Then we build the career around that sentence. Good", 9, { perk: "sharp" }),
          R("That he won things", "That I won. Everything else is noise", "Then we go where the trophies are, even if the money is worse", 9, { perk: "offer" }),
          R("Never thought about it", "Genuinely no idea", "Think about it. It is the only question that decides the rest", 5)
        )
      ], { minAge: 19 }),
      C("agent_brand", "agent", "pro", [
        B(
          "Boot brand wants you. Small money now, big money if you kick on. Or we wait for a bigger name to notice.",
          R("Take the small deal", "Take it. Money now, and I want to be loyal to whoever backs me early", "Loyalty plays well and pays later. Signing it", 7, { cash: 0.3, popularity: 2 }),
          R("Wait it out", "Wait. I back myself", "So do I. Risky. I like it", 7, { perk: "spotlight" }),
          R("Ask what he would do", "What would you do if it was your career", "I would wait. But I would also stop pretending my agent knows your body better than you", 8, { morale: 3 })
        )
      ], { minAge: 19 }),
      /* ── The gaffer ── */
      C("gaffer_role", "gaffer", "pro", [
        B(
          "Come see me at the training ground tomorrow. Nothing bad. I want to tell you what I actually want from you.",
          R("Ask for more", "Before I come in. I want more minutes and I will earn them", "Good. I like being asked. Bring that attitude tomorrow", 8, { perk: "sharp" }),
          R("Just listen", "I will be there. I will listen", "That is the right answer more often than players think", 7, { perk: "sharp" }),
          R("Be wary", "Should I be worried", "If you were, I would not have texted. I would have let you find out", 5)
        ),
        B(
          "One thing I want you to think about tonight. When we lose the ball, what do you do first.",
          R("Win it back", "Win it back. Within five seconds. That is the answer you want", "It is the answer I want AND the right one. See you at nine", 9, { perk: "sharp" }),
          R("Get in shape", "Get back in shape and hold the line", "Boring. Correct. Also see you at nine", 8),
          R("Admit you switch off", "Honestly? Sometimes I stand there annoyed", "At least you know. We can fix knowing. We cannot fix pretending", 8, { morale: 3, perk: "sharp" })
        ),
        B(
          "Good. Bring one question with you tomorrow. Any question. I will answer it straight.",
          R("Ask about your role", "Am I in your best eleven or am I in the squad", "In it. Not nailed on. That is the honest answer and you can change it by Friday", 9, { morale: 4, perk: "sharp" }),
          R("Ask about the team", "What is the one thing holding this team back", "Nobody talks. Including you. Fix that and we go up the table", 9, { perk: "lift" }),
          R("No question", "I will just listen", "Then listen properly. Nine o clock", 5)
        )
      ]),
      C("gaffer_dropped", "gaffer", "pro", [
        B(
          "You are on the bench Saturday. I would rather you heard it from me tonight than from a team sheet.",
          R("Ask what to fix", "Tell me exactly what gets me back in", "Two things. Sprint back after you lose it, and stop taking the safe pass. Do that and you start next week", 9, { perk: "sharp", morale: 2 }),
          R("Take it quietly", "Understood. I will be ready if you need me", "That is the response of somebody who plays a lot of games for me", 8, { morale: 3 }),
          R("Kick off", "This is a joke and you know it", "It is my team. Cool down and come see me Monday", -3, { warm: -8, morale: -5 })
        ),
        B(
          "For what it is worth I was dropped at your age and I sulked for a month. Waste of a month.",
          R("Take the lesson", "Then I will skip the month", "Ha. Good. Nine o clock, extra finishing", 9, { perk: "sharp" }),
          R("Stay annoyed", "I am still not happy about it", "I would be worried if you were", 6)
        ),
        B(
          "Be honest with me. Do you still trust that I will play you when you deserve it?",
          R("Yes", "Yeah. You have never lied to me about it", "Then we are fine. Everything else is just Saturdays", 9, { morale: 5, perk: "lift" }),
          R("Not really", "Honestly, not at the minute", "Fair. I will earn it back the same way you will. See you at nine", 8, { morale: 3 })
        )
      ]),
      /* ── Captain ── */
      C("captain_standards", "captain", "pro", [
        B(
          "Quick word. Nothing heavy. Couple of the young lads are drifting and they watch you more than they watch me.",
          R("Set the tone", "I will be first in all week. Let them see it rather than hear it", "That is exactly why I asked you and not somebody louder", 9, { perk: "lift" }),
          R("Talk to them", "I will pull them both aside quietly", "Quietly is right. Nobody learns anything from being embarrassed", 8, { karma: 4 }),
          R("Not your job", "Not really my problem mate", "Fair enough. It becomes your problem in about three years", -2, { warm: -5 })
        ),
        B(
          "Team meal Thursday. Everyone. Phones in a box at the door.",
          R("In", "In. And I am paying", "Right lads, he is paying. This is now a big night", 9, { morale: 5, cash: -0.02, perk: "lift" }),
          R("In, but not paying", "I will be there. Not paying, I paid last time", "Correct and I respect the memory", 7, { morale: 3 }),
          R("Skip it", "Cannot do Thursday", "Every time mate", -3, { warm: -7 })
        ),
        B(
          "Good. One more. If I go down injured for a long one, who speaks up in there?",
          R("Say you will", "Me. I will do it", "That is the answer I was fishing for and you did not even flinch", 10, { morale: 6, perk: "lift" }),
          R("Name somebody else", "The keeper. Everyone listens to him", "He would hate it. He would also be brilliant at it", 7)
        )
      ]),
      C("captain_armband", "captain", "pro", [
        B(
          "I am moving on in the summer. Between us, I have told the gaffer you should have the armband.",
          R("Say you are ready", "I am ready. I have been ready", "That is what I told him. Do not make me look daft", 9, { morale: 7, perk: "lift" }),
          R("Be honest about doubts", "Honestly I do not know if the lads would follow me", "They already do. You just have not noticed", 9, { morale: 6 }),
          R("Turn it down", "Give it to someone who wants it. I just want to play", "Respect that. Rare, but I respect it", 6)
        ),
        B(
          "Whoever gets it, one bit of advice. The armband is not for the good days.",
          R("Ask what he means", "So what is it for", "The week after a hammering, when nobody wants to be first to speak. That is the job", 9, { morale: 4, perk: "lift" }),
          R("Say you know", "I know. I have watched you do it", "Then you already have it, plastic or not", 8, { morale: 4 })
        )
      ], { minAge: 24 }),
      /* ── Room mate ── */
      C("roomie_nerves", "roomie", "pro", [
        B(
          "You alright? You have been staring at the ceiling for an hour and it is 1am.",
          R("Admit the nerves", "Big one tomorrow. Head is going", "Same. Every time. Nobody says it out loud though so we all lie awake separately", 9, { morale: 5 }),
          R("Say it is nothing", "Nothing mate. Go to sleep", "You are a terrible liar. Night", 5),
          R("Put the light on", "Put the light on, we are talking", "Great. Now neither of us sleeps. Worth it though", 8, { morale: 4 })
        ),
        B(
          "Can I ask you something daft. Do you ever feel like you got lucky and they will find out?",
          R("Admit you feel it too", "Every week. Waiting to be found out", "Thank god. I thought it was just me", 10, { morale: 6, perk: "calm" }),
          R("Talk him out of it", "You are here because you are good. Full stop", "Coming from you that actually lands", 9, { morale: 4, perk: "lift" }),
          R("Laugh at him", "Yeah you did get lucky", "Wow. Lights off", -2, { warm: -6 })
        ),
        B(
          "Do you ever think about what we do after? Like actually after.",
          R("Talk about it", "All the time. Coaching maybe. Or nothing at all for a year", "See I want to open a cafe. Everyone laughs. You did not laugh", 9, { morale: 4, perk: "calm" }),
          R("Refuse to", "I do not let myself think about it", "Probably healthy. Probably not", 6)
        )
      ]),
      C("roomie_snacks", "roomie", "pro", [
        B(
          "Mate the hotel food is a war crime. I have found a chip shop 400 metres away. Are we doing this",
          R("Go", "Go. Nutritionist will never know", "He will absolutely know. Worth it", 7, { morale: 4, karma: -2 }),
          R("Refuse", "Not the night before a game. Bring me a banana", "A BANANA. You have changed", 6),
          R("Order in for the whole squad", "Do one better. I am ordering proper food for everyone", "You are going to be the most popular man in this hotel", 8, { morale: 5, cash: -0.01, perk: "lift" })
        )
      ]),
      /* ── Physio ── */
      C("physio_niggle", "physio", "pro", [
        B(
          "That hamstring. You have been guarding it for two weeks and you think I have not noticed.",
          R("Come clean", "It is tight. I did not want to say in case I got left out", "Thank you. Now I can actually help instead of guessing. In at eight", 10, { perk: "calm", morale: 3 }),
          R("Deny it", "It is fine. Honestly", "Then you will not mind me testing it in front of the gaffer tomorrow", -2, { warm: -6 }),
          R("Ask to manage it", "Can we manage it without me missing games", "Sometimes. If you are honest with me every single day. Deal?", 9, { perk: "calm" })
        ),
        B(
          "Last thing. How is the sleep and the stress. Both of those show up in soft tissue before they show up anywhere else.",
          R("Be honest", "Sleep is bad. Stress is worse", "Right. Then we treat that too. Half of my job is not legs", 10, { morale: 6, perk: "calm" }),
          R("Say it is fine", "All fine there", "Ok. But that box is ticked in pencil", 4)
        ),
        B(
          "One rule then and we are done. If something feels wrong on a Friday, you tell me on the Friday.",
          R("Agree to the rule", "Friday. Every time. Even if it is nothing", "That one rule will add years to your career. I am not exaggerating", 10, { perk: "calm", morale: 4 }),
          R("Push back", "I do not want to be the one always in the treatment room", "You will not be. You will be the one still playing at 34", 8, { perk: "calm" })
        )
      ]),
      /* ── Fitness coach ── */
      C("fitness_extra", "fitness", "any", [
        B(
          "Optional extras start Monday. 6am. Nobody has signed up yet which tells you everything.",
          R("Sign up", "Put my name down. First one in", "Good. Bring a bin. I am not joking", 8, { perk: "sharp", morale: -2 }),
          R("Ask what it does", "What does it actually give me", "Two more sprints in the last ten minutes. That is the difference between a goal and a photo of you jogging", 8, { perk: "sharp" }),
          R("Pass", "I need the rest more", "Fine. Rest is training too. But nobody ever got quicker resting", 3)
        ),
        B(
          "If you come, I want a target. Give me one number to chase.",
          R("Top speed", "Top speed. I want to be the quickest at this club", "Now we are talking. Twelve weeks", 9, { perk: "sharp" }),
          R("Games played", "I just want to finish a season without breaking down", "Best target anyone has given me all year", 9, { perk: "calm" })
        ),
        B(
          "Last thing. Bring somebody with you. Nobody sticks at 6am on their own.",
          R("Drag a teammate in", "I will drag one of the young lads in with me", "Two of you at 6am and by March half the squad is there. Watch", 10, { perk: "lift" }),
          R("Go alone", "I will be fine on my own", "You will last three weeks. Prove me wrong", 6)
        )
      ]),
      /* ── Old youth coach ── */
      C("youth_pride", "youthcoach", "any", [
        B(
          "Still got the team photo from your first season up on the wall. You are the small angry one at the front.",
          R("Ask about the others", "Who else from that photo is still playing?", "Two. One is at a non league club and loves it. One is a physio now. Everyone else has a proper job", 9, { morale: 4 }),
          R("Thank him", "You made me. I will say that for the rest of my life", "Get away with you. You made you. I just stopped you kicking people", 10, { morale: 6, karma: 4 }),
          R("Brush it off", "Long time ago that", "It is. And I still watch every week", 3)
        ),
        B(
          "Do me one favour. When a kid asks you for a photo, say yes. Even when you are tired.",
          R("Promise", "Always yes. Even when I am tired. Especially then", "Good lad. That is the whole lesson", 10, { karma: 6, popularity: 3 }),
          R("Be honest about it", "Some days I really do not want to", "Nobody does. Do it anyway. That is what the word professional means", 8, { karma: 3 })
        ),
        B(
          "And one day, when you are done, come and coach here. I am putting it in writing now.",
          R("Say yes", "When I am done I am coming straight back here", "I will hold this message up in about fifteen years", 10, { morale: 5, karma: 4 }),
          R("Cannot think that far", "I cannot even think about next season coach", "Then do not. I will keep the message anyway", 6)
        )
      ]),
      C("youth_return", "youthcoach", "pro", [
        B(
          "We have got a session Thursday for the under 12s. Twenty minutes of you would blow their minds. No cameras.",
          R("Do the whole session", "I will do the full session. And no cameras, agreed", "They are going to be unbearable for a month. Thank you", 10, { karma: 8, popularity: 3, morale: 4 }),
          R("Twenty minutes", "Twenty minutes is all I have got but I will be there", "Twenty minutes is twenty more than most", 8, { karma: 4, popularity: 2 }),
          R("Send kit instead", "Cannot do Thursday. Sending a full set of kit for them", "That will help. They would rather have you though", 5, { karma: 2, cash: -0.03 })
        )
      ], { minAge: 21 }),
      /* ── Academy kid ── */
      C("academy_firstteam", "academy", "any", [
        B(
          "Training with the first team tomorrow. I have been sick twice. Any advice",
          R("Give him the one rule", "First ball, first tackle, win it. Everything else follows", "First ball first tackle. Ok. Ok I can do that", 8, { karma: 4, perk: "lift" }),
          R("Offer to pick him up", "I will pick you up. We go in together", "Are you serious. I am not going to sleep now", 10, { karma: 8, morale: 4, perk: "lift" }),
          R("Tell him to relax", "You are there because you are good enough. Breathe", "Nobody has said that to me yet. Thank you", 8, { karma: 4 })
        ),
        B(
          "Last thing sorry. What if I am rubbish and they send me back",
          R("Tell him the truth", "You probably will be rubbish for a bit. Everybody is. Then you are not", "That is weirdly the most calming thing anyone has said", 9, { karma: 4, perk: "lift" }),
          R("Big him up", "You will not be rubbish. I have watched you", "You have WATCHED me? I need to sit down", 8, { morale: 3 })
        ),
        B(
          "If it goes ok tomorrow can I text you after? I have got nobody else to tell.",
          R("Yes, any time", "Text me after every session. I mean it", "You have no idea what that means. See you tomorrow", 10, { karma: 6, morale: 4, perk: "lift" }),
          R("Set a boundary", "Text me after big ones. I am not your dad", "Fair enough. Big ones only", 5)
        )
      ]),
      /* ── Kit man ── */
      C("kitman_shirt", "kitman", "pro", [
        B(
          "Lad in the laundry has been here 30 years and never asked a player for anything. He asked me to ask you for a shirt.",
          R("Sign one properly", "Get me the shirt from Saturday. I will write him something proper on it", "He is going to have that framed by Tuesday", 9, { karma: 6, morale: 3 }),
          R("Do one better", "Shirt, boots, and get him and his wife in the box for a game", "Right. Now you have made an old man cry in a laundry room", 10, { karma: 8, popularity: 3, cash: -0.01 }),
          R("Later", "Remind me after the international break", "Course. He has waited 30 years, he can wait a fortnight", -1, { warm: -3 })
        )
      ]),
      /* ── Journalist ── */
      C("journo_column", "journo", "pro", [
        B(
          "Doing a piece on players your age carrying clubs. Not a hit job. Ten minutes on the phone, you see quotes before print.",
          R("Do it properly", "Ten minutes, and I want to talk about the lads not just me", "That makes it a better piece anyway. Thursday?", 8, { popularity: 3, karma: 3 }),
          R("Decline politely", "Not for me at the minute. No hard feelings", "None at all. Door is open", 5),
          R("Use it", "I will do it if I can say what I actually think about the club", "Now THAT is a phone call. Thursday, and I am recording", 6, { popularity: 5, karma: -4 })
        ),
        B(
          "Off the record before we set it up. Are you happy there?",
          R("Nothing off the record", "There is no off the record with you lot. Ask me Thursday", "Fair. Genuinely fair. Thursday", 9, { karma: 5 }),
          R("Give him a hint", "Ask me again in January", "January. Noted. Loudly noted", 4, { karma: -3, popularity: 3 })
        ),
        B(
          "Fine. Then give me one line for the piece that is actually about football and not about you.",
          R("Praise a teammate", "Put in that our left back is the most underrated player in this league", "That is a lovely line and he will never forget it", 9, { karma: 5, perk: "lift" }),
          R("Praise the fans", "Say the away end has been the best thing about this season", "Cheap. True though. Using it", 8, { popularity: 4 }),
          R("Refuse", "I do not do lines. Watch the games", "Ha. Print that then", 4)
        )
      ], { minAge: 19 }),
      /* ── Country manager ── */
      C("nat_squad", "natcoach", "pro", [
        B(
          "Naming the squad Monday. Before I do I want to know where your head is, because your club season has been noisy.",
          R("Commit fully", "My head is fine. I will run through a wall for that shirt", "That is what I needed to hear. See you Monday", 9, { morale: 6, perk: "lift" }),
          R("Ask for honesty back", "Am I starting or am I making up the numbers", "You are in the squad. Starting is earned in the week, same as everyone", 8, { perk: "sharp" }),
          R("Ask to be left out", "I am running on empty. Leave me out this window", "Brave call. I would rather have you in March than broken in October", 7, { morale: 4, perk: "calm" })
        )
      ], { needs: (s) => !!s.internationalCareer }),
      C("nat_tournament", "natcoach", "pro", [
        B(
          "Long summer coming. I need players who will still be sprinting in the 85th minute of a semi final.",
          R("Volunteer for anything", "Put me anywhere. Left back if you need it", "I might hold you to that and you will regret typing it", 9, { morale: 5, perk: "lift" }),
          R("Be realistic", "I can give you 60 big minutes every game, not 90", "Honest. Useful. Most players lie to me about this", 9, { perk: "sharp" })
        )
      ], { needs: (s) => !!s.internationalCareer, minAge: 21 }),
      /* ── Rival ── */
      C("rival_respect", "rival", "pro", [
        B(
          "Good game. You were the best player on that pitch and I am only saying it once so screenshot it.",
          R("Give it back", "You were the reason it was close. Screenshot that", "Look at us. Two grown men being nice. Disgusting", 8, { morale: 4, popularity: 2 }),
          R("Stay cold", "Scoreboard said what it said", "Ha. There he is. See you in March", -2, { warm: -6, perk: "needle" }),
          R("Take the compliment", "Appreciated. Genuinely", "Do not get used to it", 6)
        ),
        B(
          "Serious for a second. Does it get to you, the comparison thing?",
          R("Admit it", "Every single week. You?", "Constantly. Nobody else understands it which is the annoying part", 9, { morale: 5 }),
          R("Deny it", "Not once. I do not think about you at all", "You replied in four seconds", 3, { perk: "needle" })
        ),
        B(
          "Alright. One promise. Whoever finishes with more, the other one turns up to the testimonial.",
          R("Shake on it", "Deal. And I will be the one clapping you off", "We will see. Good luck this season. Genuinely", 9, { morale: 4, popularity: 2 }),
          R("Refuse the deal", "I am not planning a testimonial. I am planning to keep going", "Terrifying. See you in March", 4, { perk: "needle" })
        )
      ], { needs: (s) => !!s.rival && !s.rival.retired }),
      C("rival_needle", "rival", "pro", [
        B(
          "Saw your interview. Bold from someone with fewer trophies than me.",
          R("Fire back", "Count them again in three years", "Oh it is ON. See you in the derby", 4, { popularity: 4, morale: 3, perk: "needle" }),
          R("Kill it with kindness", "You are right. Come and help me get some", "That is so annoying. I cannot even argue with that", 8, { karma: 4 }),
          R("Ignore the bait", "", "Silence. Interesting.", 1, { warm: 0 })
        ),
        B(
          "Between us though. Would you ever play in the same team as me.",
          R("Yes", "In a heartbeat. We would be unplayable", "We would be. Do not tell anyone I agreed", 8, { morale: 4 }),
          R("Never", "Never. I want to beat you, not carry you", "That is the correct answer and you know it", 3, { perk: "needle", popularity: 3 })
        )
      ], { needs: (s) => !!s.rival && !s.rival.retired }),
      /* ── second wave: more to say to the same people ── */
      C("mum_money", "mum", "pro", [
        B(
          "Somebody at the shop asked me what you earn. I told them to mind their own business.",
          R("Back her up", "Good. It is nobody's business but ours", "That is what I said. Then I told them anyway. Sorry", 8, { morale: 3 }),
          R("Offer to sort her out", "Mum, let me buy you something. Anything. Please", "I do not need anything. Ask me again next year and I might say a new sofa", 9, { morale: 5 }),
          R("Get annoyed", "People are so nosy", "They are proud. It comes out sideways", 5)
        ),
        B(
          "Do not let it change how you are with people. That is my only rule.",
          R("Promise", "Same me. Always. You would tell me if it was not", "I would tell you loudly and in front of everyone", 10, { karma: 5, morale: 4 }),
          R("Joke", "Too late, I am insufferable", "You are not. But keep checking", 6)
        ),
        B(
          "Right. Go and get some sleep. And ring your nan.",
          R("Ring nan now", "Ringing her now before I forget", "You are a good boy. Night love", 10, { morale: 5, karma: 3 }),
          R("Tomorrow", "I will ring her tomorrow", "Tomorrow. I am writing it down", 4)
        )
      ]),
      C("dad_debut", "dad", "pro", [
        B(
          "Do you remember your first proper game? I do. You were sick behind the dugout.",
          R("Own the memory", "I remember. And I still nearly am, every time", "Everybody is. The ones who say they are not are lying", 9, { morale: 4 }),
          R("Deny it", "That never happened", "I have a photograph of the bucket", 7, { morale: 3 })
        ),
        B(
          "Point is you did it anyway. That has always been the thing about you.",
          R("Take it in", "I needed to hear that this week actually", "Then I will say it more often instead of sending you diagrams", 10, { morale: 6, perk: "calm" }),
          R("Deflect", "Soft in your old age dad", "Very. Do not tell the lads at work", 6)
        )
      ], { minAge: 19 }),
      C("partner_home", "partner", "pro", [
        B(
          "I found a house. It is too big and it has a stupid bath and I love it.",
          R("Go and see it", "Send me the link. We are going Saturday", "SATURDAY. Right. I am ringing them now", 9, { morale: 6 }),
          R("Talk about the move risk", "What if we get moved in January though", "Then we rent it out and cry. Come and look at the bath", 7, { morale: 3 }),
          R("Shut it down", "Not while the contract situation is up in the air", "Ok. It will be gone but ok", 2, { warm: -3 })
        ),
        B(
          "Whatever we do, I do not want to live somewhere that only makes sense if you keep winning.",
          R("Agree completely", "Nothing we cannot keep if it all goes wrong. Agreed", "That is the most attractive thing you have ever said", 10, { morale: 6 }),
          R("Play it big", "I am going to keep winning", "Not what I asked. But ok", 4)
        )
      ], { minAge: 21, needs: (s) => !!s.hasRelationship || !!s.family?.isMarried }),
      C("captain_newsigning", "captain", "pro", [
        B(
          "New lad signed today. Speaks about nine words of the language and looks terrified. Sound familiar?",
          R("Take him under your wing", "I will sit with him at lunch. And drive him in", "That is why I texted you and not the group chat", 9, { karma: 5, perk: "lift" }),
          R("Do the basics", "I will make sure he knows where everything is", "Do that much and he sleeps tonight", 7, { karma: 3 }),
          R("Not interested", "He will figure it out like the rest of us did", "We did. It was horrible. That was the point", -2, { warm: -6 })
        ),
        B(
          "Get him in the five a side on Thursday. That is where anyone actually joins a team.",
          R("Sort it", "He is on my team Thursday. Sorted", "Good. He will be one of us by Friday", 9, { perk: "lift" }),
          R("Let somebody else", "Get one of the young lads to do it", "I asked you because they copy you", 5)
        )
      ]),
      C("roomie_contract", "roomie", "pro", [
        B(
          "They have not offered me a new deal. Six months left. I am pretending I am fine.",
          R("Be straight with him", "You are not fine and that is fair enough. What do you actually want?", "To stay. Obviously. But nobody has said a word to me", 9, { morale: 3 }),
          R("Offer to ask for him", "Want me to say something to the gaffer? Quietly", "Would you? I would never have asked", 10, { karma: 6, perk: "lift" }),
          R("Change the subject", "Early game tomorrow mate", "Yeah. Night", -3, { warm: -7 })
        ),
        B(
          "If it goes the other way, will you still answer my messages when I am at some other club?",
          R("Obviously", "You will not get rid of me. Wherever you end up", "Right. Now I am the one lying awake being soft", 10, { morale: 5 }),
          R("Be realistic", "We will see. People drift", "Brutal. Honest though", 4)
        )
      ]),
      C("physio_comeback", "physio", "pro", [
        B(
          "Four weeks in. I know you feel good. I know you want to play Saturday. Ask me anyway.",
          R("Ask properly", "Am I ready for Saturday, honestly", "No. Two more weeks and you get the rest of the season. Push it and you get neither", 10, { perk: "calm" }),
          R("Push for it", "I am playing Saturday whatever you say", "Then you are picking a fortnight over a season and I will write that down", -2, { warm: -6, morale: -3 }),
          R("Defer to him", "Whatever you say. I will not fight you on it", "Good. Nobody ever regrets that call", 9, { perk: "calm", morale: 3 })
        ),
        B(
          "While I have got you. Rehab is boring and you have got a whole week of it. Do you want a job?",
          R("Take the job", "Give me something to do or I will lose my mind", "Right. You are coaching the under 18s finishers this week", 9, { morale: 5, perk: "sharp" }),
          R("Just rest", "I am going to switch off completely for a week", "Also a real answer. Go and be a person", 8, { morale: 4 })
        )
      ], { minAge: 19 }),
      C("agent_loan", "agent", "pro", [
        B(
          "There is a loan on the table. Lower league, guaranteed starter, nobody watching. Old fashioned option.",
          R("Take the loan", "I will go. I need games more than I need the badge", "Best decision a young player can make and almost none of them make it", 9, { perk: "sharp" }),
          R("Ask what he thinks", "What does it actually do for me", "Thirty games. Men's football. Somebody kicking you every week. It makes you", 8, { perk: "sharp" }),
          R("Refuse", "I am not dropping down. I will fight for my place here", "Brave. Could go either way. I will tell them no", 6, { morale: 3 })
        ),
        B(
          "Whatever you pick, do not disappear on me for six months. I work better when you talk to me.",
          R("Agree", "I will ring you every month whether there is news or not", "You would be the first player who ever did. Deal", 10, { perk: "offer" }),
          R("Push back", "Ring me when there is something to say", "Fine. There will be less than you think", 3)
        )
      ], { minAge: 18, maxAge: 25 }),
      C("kitman_boots", "kitman", "pro", [
        B(
          "Your boots have been in the same bag since August and they smell like a crime. Want me to sort them?",
          R("Let him sort them", "Please. And whatever it costs I will double it", "It costs nothing. That is the job. But I will take the tea", 8, { morale: 3 }),
          R("Do it yourself", "I will do them tonight. My mess", "A player cleaning his own boots. I need a lie down", 9, { karma: 4 })
        ),
        B(
          "Forty years I have done this. You lot come and go. The polite ones I remember.",
          R("Ask about the old days", "Who was the best one you ever kitted out?", "Not telling you. But you are in the top ten and you are 22", 9, { morale: 4 }),
          R("Say thanks", "Thanks for everything you do. Genuinely", "Get out of my kit room before I get emotional", 9, { karma: 4, morale: 3 })
        )
      ]),
      C("nat_debut", "natcoach", "pro", [
        B(
          "First cap. I want you to enjoy it, and I want you to remember one thing when you walk out.",
          R("Ask what", "Go on. What is the one thing", "Everybody in that stadium already thinks you belong. Only you are arguing", 9, { morale: 7, perk: "calm" }),
          R("Say you are ready", "I have been ready since I was nine", "Then go and prove it and stop texting me", 8, { morale: 5 })
        ),
        B(
          "Your family are in the players' box. All of them. I checked.",
          R("Thank him", "That means more than the cap does. Thank you", "Now go and have the best night of your life", 10, { morale: 8 }),
          R("Get emotional", "You have properly got me now", "Good. Use it in the first twenty minutes", 9, { morale: 6 })
        )
      ], { needs: (s) => !!s.internationalCareer }),
      C("grandad_advice", "grandad", "any", [
        B(
          "Your father says you are worrying too much. He worries too much. Runs in the family.",
          R("Admit it", "I do worry. All the time", "Course you do. So did I. Then I got old and it stopped mattering", 9, { morale: 5, perk: "calm" }),
          R("Blame dad", "He is worse than me", "He is much worse than you. Do not tell him I said it", 8, { morale: 3 })
        ),
        B(
          "Here is my advice and then I am going for my nap. Play like you did in the garden.",
          R("Take it", "Like the garden. I will remember that on Saturday", "That is all it ever was. Everything else is people talking", 10, { morale: 6, perk: "sharp" }),
          R("Ask what he means", "What, terribly and with one boot on?", "Cheeky sod. Nap time", 7, { morale: 3 })
        )
      ]),
      C("mate_home", "bestmate", "any", [
        B(
          "Went past your old house today. New people have painted the door red. Thought you should know.",
          R("Ask for a photo", "Send me a picture. Red? Really?", "Bright red. Your mum would have something to say", 8, { morale: 4 }),
          R("Get nostalgic", "I can still see the wall we used as a goal", "It is still there. Still has the mark", 9, { morale: 5 })
        ),
        B(
          "Do you miss it? Genuinely. Or is that a stupid question when you live where you live.",
          R("Say you miss it", "Every day. It is not stupid at all", "Then come back for a weekend. Nobody will make a fuss", 10, { morale: 6, perk: "calm" }),
          R("Say no", "No. I wanted out and I got out", "Fair. You always did want more than this place", 6)
        )
      ]),
      C("fitness_recovery", "fitness", "pro", [
        B(
          "Your numbers dip badly in the last fifteen minutes. Not fitness. Recovery. What are you doing after games?",
          R("Admit nothing", "Honestly? Nothing. I go home and sit on my phone", "Right. Then we have found free minutes lying on the floor", 9, { perk: "sharp" }),
          R("Claim you do everything", "Ice bath, stretch, the lot", "Your numbers disagree and numbers do not lie to me", 4),
          R("Ask for a plan", "Write me a proper recovery week and I will follow it", "Sending it tonight. Follow it and you get twenty minutes back", 10, { perk: "sharp" })
        ),
        B(
          "Sleep is the whole thing by the way. Everything else is decoration.",
          R("Fix the sleep", "Phone out the bedroom starting tonight", "That one change is worth more than anything I can do to you in a gym", 10, { perk: "calm", morale: 4 }),
          R("Say you cannot", "I cannot sleep after night games. Never could", "Then we work on the after, not the sleep. Come see me", 8, { perk: "calm" })
        )
      ]),
      C("academy_advice", "academy", "pro", [
        B(
          "They released my mate today. He is 18. He has not stopped crying and I do not know what to say to him.",
          R("Tell him what to say", "Say nothing. Just sit with him. That is the whole job today", "That is what I did. I did not know if it was enough", 10, { karma: 6, morale: 3 }),
          R("Offer to help him", "Give me his name. I know people at three clubs who would look", "Are you serious? He will not believe this", 10, { karma: 8, perk: "lift" }),
          R("Be blunt", "It happens to nearly everyone. He will be fine", "Yeah. Suppose", 1, { warm: -4 })
        ),
        B(
          "Does it ever stop being scary? Like, at your level?",
          R("Tell the truth", "No. You just get better at carrying it", "Weirdly that helps", 9, { morale: 4 }),
          R("Lie kindly", "It gets easier. Promise", "Ok. I am holding you to that", 6)
        )
      ], { minAge: 21 }),
      C("journo_column2", "journo", "pro", [
        B(
          "Story doing the rounds that your dressing room has split. I am running something. Do you want a right of reply?",
          R("Kill it flat", "There is no split. Print that and I will stand behind it all season", "That is a strong denial and I will print it word for word", 8, { karma: 5, perk: "lift" }),
          R("Say nothing", "No comment", "No comment reads like yes to every reader alive. Your call", 4),
          R("Point him elsewhere", "Ask whoever fed you it what they want out of it", "Now THAT is a better story than the one I had", 6, { karma: -2, popularity: 3 })
        ),
        B(
          "Between us, who is actually briefing against you lot? You must know.",
          R("Refuse", "Even if I knew I would not tell you", "Correct answer. Annoying. Respect", 9, { karma: 6 }),
          R("Give him a name", "I have got an idea. Off the record", "Off the record does not exist but go on", 3, { karma: -6, popularity: 4 })
        )
      ], { minAge: 21 }),
      C("gaffer_captainask", "gaffer", "pro", [
        B(
          "Something I want your read on, not as a player. Who do the group actually listen to in there?",
          R("Name somebody honestly", "The keeper. Nobody argues with him", "That matches what I see. Thank you for not saying yourself", 9, { perk: "lift" }),
          R("Say yourself", "Me, when it matters", "Bold. Prove it Tuesday when I make you run the warm up", 7, { morale: 4 }),
          R("Dodge it", "Not sure I should be answering that", "Fair. Forget I asked", 4)
        ),
        B(
          "Second question and then I will let you eat. What do the players say about ME when I leave the room?",
          R("Tell him straight", "That you are honest and that you are hard work. Both", "That is the most useful sentence anyone has said to me this season", 10, { perk: "lift", morale: 4 }),
          R("Protect him", "Nothing bad", "Now I know it is bad", 3)
        )
      ], { minAge: 24 }),
      C("rival_national", "rival", "pro", [
        B(
          "Wild that we are in the same squad this week. Do we have to pretend to like each other in front of the press?",
          R("Play nice for the country", "For ten days, yes. Then back to normal", "Ten days. Then war. Deal", 8, { morale: 4, popularity: 2 }),
          R("Refuse", "I am not pretending anything", "Honestly? Same. See you at breakfast", 3, { perk: "needle" })
        ),
        B(
          "Room next to yours by the way. If you snore I am telling everyone.",
          R("Wind him up", "I will snore on purpose", "You are the worst. See you at training", 7, { morale: 3 }),
          R("Call a truce", "Truce for the tournament. Properly", "Truce. And if we win it nobody ever mentions this chat again", 9, { morale: 5, perk: "lift" })
        )
      ], { needs: (s) => !!s.rival && !s.rival.retired && !!s.internationalCareer })
    ];
    CONVO_BY_ID = Object.fromEntries(CONVOS.map((c) => [c.id, c]));
  }
});

// src/lib/careerMoney.ts
var ASSETS, ASSET_BY_ID;
var init_careerMoney = __esm({
  "src/lib/careerMoney.ts"() {
    ASSETS = [
      {
        id: "ladder",
        name: "Steady Ladder Fund",
        emoji: "\u{1F4D7}",
        kind: "fund",
        blurb: "A bit of everything. Boring on purpose.",
        drift: 0.055,
        vol: 0.05,
        pull: 0.55,
        risk: "steady"
      },
      {
        id: "bricks",
        name: "Old Town Bricks",
        emoji: "\u{1F9F1}",
        kind: "property",
        blurb: "Flats above the shops back home.",
        drift: 0.04,
        vol: 0.11,
        pull: 0.4,
        risk: "steady"
      },
      {
        id: "cleats",
        name: "Cleatworks",
        emoji: "\u{1F45F}",
        kind: "share",
        blurb: "They make boots. Half the league wears them.",
        drift: 0.032,
        vol: 0.17,
        pull: 0.35,
        risk: "bumpy"
      },
      {
        id: "screens",
        name: "Matchday Screens",
        emoji: "\u{1F4FA}",
        kind: "share",
        blurb: "Sells the rights, sells the ads, sells the highlights.",
        drift: 0.025,
        vol: 0.22,
        pull: 0.32,
        risk: "bumpy"
      },
      {
        id: "spark",
        name: "SparkCoin",
        emoji: "\u26A1",
        kind: "coin",
        blurb: "A coin your mate's cousin made. Halves as often as it doubles.",
        drift: 0.01,
        vol: 0.5,
        pull: 0.25,
        risk: "wild"
      }
    ];
    ASSET_BY_ID = Object.fromEntries(ASSETS.map((a) => [a.id, a]));
  }
});

// src/lib/soccerMoney.ts
var init_soccerMoney = __esm({
  "src/lib/soccerMoney.ts"() {
    init_careerMoney();
    init_careerMoney();
  }
});

// src/lib/careerInbox.ts
var init_careerInbox = __esm({
  "src/lib/careerInbox.ts"() {
    init_keyedRng();
  }
});

// src/lib/careerRivalryEvents.ts
var init_careerRivalryEvents = __esm({
  "src/lib/careerRivalryEvents.ts"() {
  }
});

// src/lib/careerRivalryChoices.ts
var init_careerRivalryChoices = __esm({
  "src/lib/careerRivalryChoices.ts"() {
    init_keyedRng();
  }
});

// src/lib/intlNames.ts
var init_intlNames = __esm({
  "src/lib/intlNames.ts"() {
  }
});

// src/lib/soccerCurrency.ts
var CURRENCIES, EUR;
var init_soccerCurrency = __esm({
  "src/lib/soccerCurrency.ts"() {
    CURRENCIES = [
      { code: "EUR", symbol: "\u20AC", name: "Euro", perEur: 1 },
      { code: "GBP", symbol: "\xA3", name: "British pound", perEur: 0.8567 },
      { code: "USD", symbol: "$", name: "US dollar", perEur: 1.1699 },
      { code: "BRL", symbol: "R$", name: "Brazilian real", perEur: 6.0518 },
      { code: "MXN", symbol: "MX$", name: "Mexican peso", perEur: 19.769 },
      { code: "JPY", symbol: "\xA5", name: "Japanese yen", perEur: 185.66 },
      { code: "INR", symbol: "\u20B9", name: "Indian rupee", perEur: 111.9595 },
      { code: "AUD", symbol: "A$", name: "Australian dollar", perEur: 1.6321 }
    ];
    EUR = CURRENCIES[0];
  }
});

// src/lib/managerOffers.ts
var init_managerOffers = __esm({
  "src/lib/managerOffers.ts"() {
  }
});

// src/lib/soccerCareerToManager.ts
var init_soccerCareerToManager = __esm({
  "src/lib/soccerCareerToManager.ts"() {
    init_managerOffers();
  }
});

// src/lib/careerSocial.ts
var init_careerSocial = __esm({
  "src/lib/careerSocial.ts"() {
  }
});

// src/lib/careerBrand.ts
var init_careerBrand = __esm({
  "src/lib/careerBrand.ts"() {
  }
});

// src/lib/soccerCareerBrand.ts
var log, followers, popularity, SOCCER_SAVE_IDS, SOCCER_TIERS, SPONSORSHIP_TIERS, SOCCER_COVER, SOCCER_BRAND;
var init_soccerCareerBrand = __esm({
  "src/lib/soccerCareerBrand.ts"() {
    init_soccerCareerLife();
    log = (s, line) => {
      s.events = [...s.events, line];
    };
    followers = {
      get: (s) => s.socialMediaFollowers,
      set: (s, v) => {
        s.socialMediaFollowers = v;
      }
    };
    popularity = {
      get: (s) => s.popularity,
      set: (s, v) => {
        s.popularity = v;
      }
    };
    SOCCER_SAVE_IDS = {
      local_deal: "local_brand",
      kit_deal: "nike_adidas",
      global_ambassador: "global_ambassador",
      own_line: "merchandise_line",
      game_cover: "cover_athlete"
    };
    SOCCER_TIERS = [
      { id: "local_deal", name: "Local Brand Deal", emoji: "\u{1F3EA}", minFollowers: 1e6, income: 0.5 },
      { id: "kit_deal", name: "Global Boot Deal", emoji: "\u{1F45F}", minFollowers: 5e6, income: 3 },
      { id: "global_ambassador", name: "Global Brand Ambassador", emoji: "\u{1F30D}", minFollowers: 15e6, income: 8 },
      { id: "own_line", name: "Own Merchandise Line", emoji: "\u{1F455}", minFollowers: 3e7, income: 15 },
      { id: "game_cover", name: "Game Cover Athlete", emoji: "\u{1F3AE}", minFollowers: 5e7, income: 25 }
    ];
    SPONSORSHIP_TIERS = SOCCER_TIERS.map((t) => ({ tier: SOCCER_SAVE_IDS[t.id], name: t.name, emoji: t.emoji, minFollowers: t.minFollowers, income: t.income }));
    SOCCER_COVER = {
      minFollowers: 5e7,
      minRating: 90,
      pay: 25,
      followers: 5,
      declineStanding: 5,
      award: { name: "Game Cover Athlete", emoji: "\u{1F3AE}" }
    };
    SOCCER_BRAND = {
      tiers: SOCCER_TIERS,
      saveIds: SOCCER_SAVE_IDS,
      followerUnit: 1e6,
      followers,
      standing: popularity,
      cash: {
        get: (s) => s.netWorth,
        set: (s, v) => {
          s.netWorth = v;
        }
      },
      rating: (s) => s.overall,
      tier: {
        get: (s) => s.activeSponsorship,
        set: (s, stored) => {
          s.activeSponsorship = stored;
        }
      },
      cover: {
        ...SOCCER_COVER,
        taken: {
          get: (s) => s.coverAthleteAccepted,
          set: (s, v) => {
            s.coverAthleteAccepted = v;
          }
        },
        waiting: {
          get: (s) => s.pendingCoverAthleteEvent,
          set: (s, v) => {
            s.pendingCoverAthleteEvent = v;
          }
        },
        record: (s, a) => {
          s.awards = [...s.awards, { year: s.seasons[s.seasons.length - 1]?.year || 2024, name: a.name, emoji: a.emoji }];
        }
      },
      fame: [[80, 2], [60, 1], [40, 0.3]],
      perFollower: 0.1,
      // €100k per 1M followers
      log,
      words: {
        signed: (t) => `${t.emoji} NEW SPONSORSHIP: ${t.name}, \u20AC${t.income}M/year!`,
        coverTaken: `\u{1F3AE} You are the cover athlete of the world's biggest football video game! \u20AC${SOCCER_COVER.pay}M + ${SOCCER_COVER.followers}M followers + Legacy +10`,
        coverDeclined: `\u{1F3AE} Declined the game cover: gained respect for being selective. Reputation +${SOCCER_COVER.declineStanding}`,
        money: (m) => `\u20AC${m}M`
      }
    };
  }
});

// src/lib/soccerCareerAttributes.ts
var OUTFIELD_TREE, GK_TREE, ALL_ATTR_IDS;
var init_soccerCareerAttributes = __esm({
  "src/lib/soccerCareerAttributes.ts"() {
    OUTFIELD_TREE = [
      {
        key: "pace",
        label: "Pace",
        children: [
          { id: "acceleration", label: "Acceleration", perCm: -0.2, perKg: -0.34, does: "The first three yards. Getting away from a defender who is already touching you" },
          { id: "sprint_speed", label: "Sprint Speed", perCm: 0.1, perKg: -0.18, does: "Top end over forty yards, once you are already moving" }
        ]
      },
      {
        key: "shooting",
        label: "Shooting",
        children: [
          { id: "finishing", label: "Finishing", does: "One touch inside the box, the chances that decide seasons" },
          { id: "shot_power", label: "Shot Power", perKg: 0.14, perCm: 0.06, does: "How hard you hit it, and whether a keeper can hold it" },
          { id: "long_shots", label: "Long Shots", does: "Anything from outside the area" },
          { id: "heading", label: "Heading", perCm: 0.36, perKg: 0.12, does: "Attacking headers from crosses and set pieces" },
          { id: "penalties", label: "Penalties", does: "From twelve yards, and in a shootout" }
        ]
      },
      {
        key: "passing",
        label: "Passing",
        children: [
          { id: "vision", label: "Vision", does: "Seeing the pass nobody else in the stadium saw" },
          { id: "short_pass", label: "Short Passing", does: "Keeping the ball under pressure in tight areas" },
          { id: "crossing", label: "Crossing", does: "Delivery from wide, both feet, both heights" },
          { id: "long_pass", label: "Long Passing", does: "Switching play, and the ball over the top" },
          { id: "free_kicks", label: "Free Kicks", does: "Dead ball delivery and the ones you shoot yourself" }
        ]
      },
      {
        key: "dribbling",
        label: "Dribbling",
        children: [
          { id: "ball_control", label: "Ball Control", perCm: -0.06, does: "First touch, and whether the ball sticks when it arrives fast" },
          { id: "agility", label: "Agility", perCm: -0.3, perKg: -0.22, does: "Turning, changing direction, getting out of a crowd" },
          { id: "balance", label: "Balance", perCm: -0.12, perKg: 0.16, does: "Staying on your feet when somebody leans on you" },
          { id: "flair", label: "Flair", does: "The trick nobody asked for that comes off anyway" }
        ]
      },
      {
        key: "defending",
        label: "Defending",
        children: [
          { id: "marking", label: "Marking", perCm: 0.1, does: "Staying with a man for ninety minutes" },
          { id: "tackling", label: "Tackling", perKg: 0.1, does: "Winning the ball cleanly, standing up and going to ground" },
          { id: "interceptions", label: "Interceptions", perCm: 0.08, does: "Reading the pass before it is played and stepping in front" },
          { id: "reading", label: "Reading The Game", does: "Where to be before anything happens" }
        ]
      },
      {
        key: "physical",
        label: "Physical",
        children: [
          { id: "strength", label: "Strength", perCm: 0.16, perKg: 0.46, does: "Holding the ball up and winning the shoulder to shoulder stuff" },
          { id: "stamina", label: "Stamina", perKg: -0.22, does: "Still running in the ninetieth minute, and playing every week" },
          { id: "aggression", label: "Aggression", perKg: 0.1, does: "How hard you go into a challenge you might not win" },
          { id: "jumping", label: "Jumping", perCm: 0.26, perKg: -0.1, does: "How high you get off the floor, which is not the same as being tall" }
        ]
      }
    ];
    GK_TREE = [
      {
        key: "reflexes",
        label: "Reflexes",
        children: [
          { id: "gk_reflex", label: "Shot Reflexes", perCm: -0.1, does: "The save nobody had time to think about" },
          { id: "gk_recovery", label: "Recovery Saves", perCm: -0.12, does: "Getting back up and stopping the rebound" }
        ]
      },
      {
        key: "shooting",
        label: "Shot Stopping",
        children: [
          { id: "gk_one_v_one", label: "One On Ones", perCm: 0.1, does: "A striker through on goal with only you to beat" },
          { id: "gk_long_range", label: "Long Range", does: "Everything struck from outside the box" }
        ]
      },
      {
        key: "defending",
        label: "Positioning",
        children: [
          { id: "gk_angles", label: "Angles", perCm: 0.16, does: "Making the goal look small before the shot is hit" },
          { id: "gk_reading", label: "Reading The Game", does: "Knowing where the ball is going before it goes there" }
        ]
      },
      {
        key: "physical",
        label: "Aerial Command",
        children: [
          { id: "gk_crosses", label: "Claiming Crosses", perCm: 0.3, perKg: 0.1, does: "Coming and taking it in a crowded six yard box" },
          { id: "gk_punching", label: "Punching", perKg: 0.2, does: "Clearing the danger when catching it is not on" }
        ]
      },
      {
        key: "passing",
        label: "Distribution",
        children: [
          { id: "gk_throwing", label: "Throwing", perKg: 0.16, does: "Starting a counter attack with your hands" },
          { id: "gk_kicking", label: "Kicking", does: "Playing out from the back and finding a man long" }
        ]
      },
      {
        key: "dribbling",
        label: "Penalty Saving",
        children: [
          { id: "gk_pen_read", label: "Reading The Penalty", does: "Picking the corner before he strikes it" },
          { id: "gk_nerve", label: "Shootout Nerve", does: "The fifth kick of a shootout, in front of their end" }
        ]
      },
      {
        key: "pace",
        label: "Sweeping Speed",
        children: [
          { id: "gk_rush", label: "Rushing Out", perKg: -0.24, does: "Beating a striker to a through ball outside your area" },
          { id: "gk_recovery_pace", label: "Recovery Pace", perCm: -0.12, perKg: -0.28, does: "Getting back when the ball goes over your head" }
        ]
      }
    ];
    ALL_ATTR_IDS = [
      ...OUTFIELD_TREE.flatMap((f) => f.children.map((c) => c.id)),
      ...GK_TREE.flatMap((f) => f.children.map((c) => c.id))
    ];
  }
});

// src/lib/soccerCareerCorruption.ts
var init_soccerCareerCorruption = __esm({
  "src/lib/soccerCareerCorruption.ts"() {
  }
});

// src/lib/soccerCareerRealismA.ts
var init_soccerCareerRealismA = __esm({
  "src/lib/soccerCareerRealismA.ts"() {
    init_soccerCareerLife();
  }
});

// src/lib/soccerCareerRealismB.ts
var init_soccerCareerRealismB = __esm({
  "src/lib/soccerCareerRealismB.ts"() {
    init_soccerInternational();
    init_soccerCareerLife();
  }
});

// src/lib/soccerCareerRealism.ts
var init_soccerCareerRealism = __esm({
  "src/lib/soccerCareerRealism.ts"() {
    init_soccerCareerRealismA();
    init_soccerCareerRealismB();
  }
});

// src/lib/careerCritic.ts
var init_careerCritic = __esm({
  "src/lib/careerCritic.ts"() {
  }
});

// src/lib/soccerCareerCritic.ts
var init_soccerCareerCritic = __esm({
  "src/lib/soccerCareerCritic.ts"() {
    init_careerCritic();
  }
});

// src/lib/soccerCareerBoot.ts
var init_soccerCareerBoot = __esm({
  "src/lib/soccerCareerBoot.ts"() {
  }
});

// src/lib/soccerCareerAcademy.ts
var ACADEMY_FOCUS_BONUS, ACADEMY_FOCUS_RULE;
var init_soccerCareerAcademy = __esm({
  "src/lib/soccerCareerAcademy.ts"() {
    init_soccerCareerAttributes();
    init_careerEras();
    ACADEMY_FOCUS_BONUS = 2;
    ACADEMY_FOCUS_RULE = `+${ACADEMY_FOCUS_BONUS} to that skill on top of the year's normal growth. If the year takes you close to your ceiling it adds +1, and nothing once you reach it.`;
  }
});

// src/lib/season/momentsSave.ts
function readSeasonMoments(raw2) {
  try {
    if (!raw2 || typeof raw2 !== "object" || Array.isArray(raw2)) return null;
    const r2 = raw2;
    if (r2.v !== 1) return null;
    if (typeof r2.key !== "string" || r2.key.length === 0 || r2.key.length > KEY_MAX) return null;
    if (!Array.isArray(r2.m) || r2.m.length > LEDGER_MAX) return null;
    const m = [];
    for (const e of r2.m) {
      if (!Array.isArray(e) || e.length < ENTRY_MIN || e.length > ENTRY_MAX) return null;
      if (!e.every((x) => typeof x === "number" && Number.isFinite(x))) return null;
      if (!isInt(e[0], 1, MD_MAX) || !isInt(e[1], 0, LEDGER_MAX - 1) || !isInt(e[2], -1, 3)) return null;
      if (m.some((x) => x[0] === e[0] && x[1] === e[1])) continue;
      m.push(e.slice());
    }
    const out = { v: 1, key: r2.key, m };
    if (r2.banked !== void 0) {
      if (r2.banked !== 1) return null;
      out.banked = 1;
    }
    if (r2.paid !== void 0) {
      const p = r2.paid;
      if (out.banked !== 1 || !Array.isArray(p) || p.length !== 2 || !isInt(p[0], 0, YEAR_MAX) || !isInt(p[1], 1, PAID_MAX)) return null;
      out.paid = [p[0], p[1]];
    }
    if (r2.tally !== void 0) {
      const t = r2.tally;
      if (!t || typeof t !== "object" || Array.isArray(t)) return null;
      if (!isInt(t.seasons, 0, TALLY_MAX.seasons) || !isInt(t.moments, 0, TALLY_MAX.moments) || !isInt(t.stars, 0, TALLY_MAX.stars)) return null;
      out.tally = { seasons: t.seasons, moments: t.moments, stars: t.stars };
    }
    return out;
  } catch {
    return null;
  }
}
function ledgerOf(save, key) {
  const s = readSeasonMoments(save);
  return s && s.key === key ? s.m : [];
}
function folded(s) {
  const t = s.tally ?? { seasons: 0, moments: 0, stars: 0 };
  const stars = s.m.reduce((n, e) => n + (e[2] > 0 ? e[2] : 0), 0);
  return {
    seasons: Math.min(TALLY_MAX.seasons, t.seasons + (s.m.length > 0 ? 1 : 0)),
    moments: Math.min(TALLY_MAX.moments, t.moments + s.m.length),
    stars: Math.min(TALLY_MAX.stars, t.stars + stars)
  };
}
function ledgerPut(save, key, md, moment, result, input) {
  const prev = readSeasonMoments(save);
  const entry = [md, moment, result, ...packed(input)];
  if (!prev || prev.key !== key) {
    const out = { v: 1, key, m: [entry] };
    if (prev) out.tally = folded(prev);
    return out;
  }
  const at = prev.m.findIndex((e) => e[0] === md && e[1] === moment);
  if (at >= 0) {
    if (prev.m[at][2] !== -1 || result < 0) return prev;
    return { ...prev, m: prev.m.map((e, i) => i === at ? entry : e) };
  }
  if (prev.m.length >= LEDGER_MAX) return prev;
  return { ...prev, m: [...prev.m, entry] };
}
function ledgerBanked(save, year = 0, paid = 0) {
  const out = { ...save, banked: 1 };
  if (isInt(year, 0, YEAR_MAX) && isInt(paid, 1, PAID_MAX)) out.paid = [year, paid];
  else delete out.paid;
  return out;
}
var LEDGER_MAX, ENTRY_MIN, ENTRY_MAX, KEY_MAX, MD_MAX, YEAR_MAX, PAID_MAX, TALLY_MAX, isInt, packed;
var init_momentsSave = __esm({
  "src/lib/season/momentsSave.ts"() {
    LEDGER_MAX = 12;
    ENTRY_MIN = 3;
    ENTRY_MAX = 8;
    KEY_MAX = 200;
    MD_MAX = 400;
    YEAR_MAX = 9999;
    PAID_MAX = 2;
    TALLY_MAX = { seasons: 200, moments: 2400, stars: 7200 };
    isInt = (v, lo, hi) => typeof v === "number" && Number.isInteger(v) && v >= lo && v <= hi;
    packed = (input) => input.slice(0, ENTRY_MAX - ENTRY_MIN).map((v) => Number.isFinite(v) ? Math.round(v * 1e4) / 1e4 : 0);
  }
});

// src/data/nationalPools.ts
var init_nationalPools = __esm({
  "src/data/nationalPools.ts"() {
  }
});

// src/lib/soccerInternationalSquads.ts
var init_soccerInternationalSquads = __esm({
  "src/lib/soccerInternationalSquads.ts"() {
    init_intlNames();
    init_nationalPools();
    init_soccerInternational();
  }
});

// src/lib/careerAwardsNight.ts
var init_careerAwardsNight = __esm({
  "src/lib/careerAwardsNight.ts"() {
  }
});

// src/lib/soccerCareerEngine.ts
function trainingStatFor(position, drill) {
  return (position === "GK" ? KEEPER_TRAINING : OUTFIELD_TRAINING)[drill];
}
function rivalChoiceDilemma(id) {
  const d = SOCCER_RIVALRY_CHOICES.find((c) => c.id === id);
  return {
    id: d.id,
    emoji: d.emoji,
    title: d.title,
    description: typeof d.description === "string" ? d.description : "",
    choices: d.choices.map((c) => c.risk === void 0 ? { label: c.label, emoji: c.emoji, consequence: c.consequence } : { label: c.label, emoji: c.emoji, consequence: c.consequence, risk: c.risk })
  };
}
function effectivePotential(s) {
  const base = Math.max(s.potential ?? Math.max(90, s.overall + 3), s.overall);
  const earned = Number(s.potentialEarned);
  return Math.min(99, base + (Number.isFinite(earned) ? Math.max(0, earned) : 0));
}
var OUTFIELD_TRAINING, KEEPER_TRAINING, SOCCER_RIVALRY_CHOICES, MORAL_DILEMMAS, clamp3, HAND_CLUBS, FALLBACK_CLUBS;
var init_soccerCareerEngine = __esm({
  "src/lib/soccerCareerEngine.ts"() {
    init_captaincy();
    init_uclFormatHistory();
    init_uclTieRule();
    init_soccerCareerContinental();
    init_soccerCareerClubPool();
    init_careerEras();
    init_soccerCareerLeague();
    init_soccerCareerDerby();
    init_soccerCareerCup();
    init_soccerPhone();
    init_soccerMoney();
    init_careerInbox();
    init_careerRivalryEvents();
    init_careerRivalryChoices();
    init_intlNames();
    init_soccerCurrency();
    init_soccerCareerToManager();
    init_managerOffers();
    init_soccerCareerLife();
    init_careerSocial();
    init_careerBrand();
    init_soccerCareerBrand();
    init_soccerCareerAttributes();
    init_soccerCareerCorruption();
    init_soccerCareerRealism();
    init_soccerCareerCritic();
    init_soccerCareerBoot();
    init_soccerCareerAcademy();
    init_momentsSave();
    init_soccerInternational();
    init_soccerInternationalSquads();
    init_soccerInternational();
    init_soccerCareerBrand();
    init_careerAwardsNight();
    OUTFIELD_TRAINING = {
      dribbling: { stat: "dribbling", label: "Dribbling" },
      pace: { stat: "pace", label: "Pace" },
      passing: { stat: "passing", label: "Passing" },
      shooting: { stat: "shooting", label: "Shooting" }
    };
    KEEPER_TRAINING = {
      dribbling: { stat: "defending", label: "Positioning" },
      pace: { stat: "pace", label: "Sweeping Speed" },
      passing: { stat: "passing", label: "Distribution" },
      shooting: { stat: "reflexes", label: "Reflexes" }
    };
    SOCCER_RIVALRY_CHOICES = [
      {
        id: "rival_club_offer",
        emoji: "\u{1F4DE}",
        title: "THE ENEMY CALLS",
        description: "Your great rival's club triggers your release clause. Their sporting director says one sentence: come win everything next to him instead of against him. Your fans are already burning shirts preemptively.",
        when: (s) => s.age >= 24,
        choices: [
          {
            label: "Join forces with your rival",
            emoji: "\u{1F91D}",
            consequence: "The most talked-about transfer of the decade. Signing bonus 10M, old fans furious",
            apply: (s, r2) => {
              s.netWorth = Math.round((s.netWorth + 10) * 100) / 100;
              s.popularity = clamp3(s.popularity - 10, 0, 100);
              s.morale = clamp3(s.morale + 5, 0, 100);
              s.rivalryIntensity = clamp3((s.rivalryIntensity ?? 0) - 30, 0, 100);
              return `\u{1F4DE} You answered the enemy's call. 10M signing bonus banked, and the football world lost its mind. Old fans are furious, ${r2?.name ?? "your rival"} posted a handshake emoji.`;
            }
          },
          {
            label: "Leak the offer and refuse",
            emoji: "\u{1F4F0}",
            consequence: "Your fans crown you a legend of loyalty. Popularity +12, integrity +5",
            apply: (s) => {
              s.popularity = clamp3(s.popularity + 12, 0, 100);
              s.integrityBonus += 5;
              s.rivalryIntensity = clamp3((s.rivalryIntensity ?? 0) + 10, 0, 100);
              return "\u{1F4F0} The leaked offer made the front page. Your fans crowned you a legend of loyalty. Popularity +12.";
            }
          },
          {
            label: "Refuse quietly",
            emoji: "\u{1F910}",
            consequence: "Nobody ever knows how close it came",
            apply: () => "\u{1F910} You refused quietly. Somewhere in a drawer sits the most explosive transfer that never happened."
          }
        ]
      },
      {
        id: "rival_bad_tackle",
        emoji: "\u{1F9B5}",
        title: "THE TACKLE",
        description: "Your rival went through your ankle in the derby, studs up, no ball. The referee gave a yellow. Your physio says you are fine. Your teammates want blood. The rematch is in May.",
        when: () => true,
        choices: [
          {
            label: "Plot revenge for the rematch",
            emoji: "\u{1F608}",
            consequence: "The feud goes nuclear",
            risk: "30% chance you see red doing it: popularity and morale -5",
            apply: (s, r2, rng) => {
              s.rivalryIntensity = clamp3((s.rivalryIntensity ?? 0) + 25, 0, 100);
              if (rng() < 0.3) {
                s.popularity = clamp3(s.popularity - 5, 0, 100);
                s.morale = clamp3(s.morale - 5, 0, 100);
                return `\u{1F7E5} Revenge tasted sweet for four seconds, then the red card came out. Popularity and morale -5, and ${r2?.name ?? "your rival"} smiled the whole time.`;
              }
              s.morale = clamp3(s.morale + 8, 0, 100);
              return `\u{1F608} You got him back, clean enough to escape a card. The derby now has its own documentary crew.`;
            }
          },
          {
            label: "Accept his apology publicly",
            emoji: "\u{1F54A}\uFE0F",
            consequence: "Integrity +8, popularity +5, the feud cools",
            apply: (s) => {
              s.integrityBonus += 8;
              s.popularity = clamp3(s.popularity + 5, 0, 100);
              s.rivalryIntensity = clamp3((s.rivalryIntensity ?? 0) - 15, 0, 100);
              return "\u{1F54A}\uFE0F You accepted the apology on camera. The adults in the room won today. Integrity +8.";
            }
          },
          {
            label: "Say nothing. Score twice in May.",
            emoji: "\u{1F976}",
            consequence: "+1 Shooting next season, ice in the veins",
            apply: (s) => {
              s.statBoostNextSeason = { ...s.statBoostNextSeason, shooting: (s.statBoostNextSeason.shooting || 0) + 1 };
              s.rivalryIntensity = clamp3((s.rivalryIntensity ?? 0) + 10, 0, 100);
              return "\u{1F976} You said nothing. May is circled on your calendar in red ink. +1 Shooting next season.";
            }
          }
        ]
      },
      {
        id: "goat_debate_show",
        emoji: "\u{1F3A4}",
        title: "THE DEBATE SHOW",
        description: "A global sports network offers 2M for one live hour: you versus a panel of pundits arguing that your rival is better. No script, no edits, one microphone.",
        when: (s) => s.overall >= 85,
        choices: [
          {
            label: "Go on and cook them",
            emoji: "\u{1F525}",
            consequence: "2M fee",
            risk: "35% chance a clip goes viral badly: popularity -8",
            apply: (s, _r, rng) => {
              s.netWorth = Math.round((s.netWorth + 2) * 100) / 100;
              if (rng() < 0.35) {
                s.popularity = clamp3(s.popularity - 8, 0, 100);
                return "\u{1F3A4} You went on the debate show and one heated clip went viral for the wrong reasons. 2M banked, popularity -8.";
              }
              s.popularity = clamp3(s.popularity + 6, 0, 100);
              return "\u{1F525} You cooked the whole panel live on air. 2M banked and the clip is a permanent argument-ender. Popularity +6.";
            }
          },
          {
            label: "Send a highlight reel instead",
            emoji: "\u{1F4FC}",
            consequence: "The reel does the talking. Popularity +8",
            apply: (s) => {
              s.popularity = clamp3(s.popularity + 8, 0, 100);
              return "\u{1F4FC} You sent a four-minute highlight reel with no caption. It out-rated the show. Popularity +8.";
            }
          },
          {
            label: "Decline. Legends do not debate.",
            emoji: "\u{1F60E}",
            consequence: "Integrity +5, the mystique grows",
            apply: (s) => {
              s.integrityBonus += 5;
              return "\u{1F60E} You declined. Legends do not debate. The mystique compounds like interest.";
            }
          }
        ]
      },
      {
        id: "rival_charity_match",
        emoji: "\u{1F49B}",
        title: "TRUCE FOR ONE NIGHT",
        description: "Your rival's foundation asks you to co-headline a charity match for children's hospitals. Same pitch, same team, one night only. The photo of you two in the same shirt would break the internet.",
        when: () => true,
        choices: [
          {
            label: "Play, and split the donation",
            emoji: "\u{1F91D}",
            consequence: "1M donated, popularity +10, integrity +8, the feud softens",
            apply: (s, r2) => {
              s.netWorth = Math.round((s.netWorth - 1) * 100) / 100;
              s.popularity = clamp3(s.popularity + 10, 0, 100);
              s.integrityBonus += 8;
              s.rivalryIntensity = clamp3((s.rivalryIntensity ?? 0) - 20, 0, 100);
              return `\u{1F49B} One night, one shirt, one cause. You and ${r2?.name ?? "your rival"} raised millions for children's hospitals. The feud took the night off.`;
            }
          },
          {
            label: "Play, but start a playful nutmeg war",
            emoji: "\u{1F609}",
            consequence: "The clips are legendary. Popularity +12",
            apply: (s, r2) => {
              s.popularity = clamp3(s.popularity + 12, 0, 100);
              return `\u{1F609} The charity match turned into a nutmeg war with ${r2?.name ?? "your rival"}. The kids loved it, the internet melted. Popularity +12.`;
            }
          },
          {
            label: "Send a check, skip the match",
            emoji: "\u{1F4B8}",
            consequence: "1M donated quietly, integrity +3",
            apply: (s) => {
              s.netWorth = Math.round((s.netWorth - 1) * 100) / 100;
              s.integrityBonus += 3;
              return "\u{1F4B8} You sent the donation and skipped the cameras. The quiet kind of good. Integrity +3.";
            }
          }
        ]
      }
    ];
    MORAL_DILEMMAS = [
      {
        id: "match_fixing",
        emoji: "\u{1F3B0}",
        title: "MATCH FIXING",
        description: "A mysterious figure approaches you before a big match. He offers \u20AC5M to intentionally perform poorly. The money would be untraceable. No one would ever know... probably.",
        choices: [
          { label: "Accept the money", emoji: "\u{1F4B0}", consequence: "\u20AC5M added to your accounts", risk: "30% chance you are caught: banned for a season and the 5M taken back" },
          { label: "Refuse and report it", emoji: "\u{1F6E1}\uFE0F", consequence: "Reputation +20, Legacy +10, Fair Play Award" },
          { label: "Refuse silently", emoji: "\u{1F910}", consequence: "Walk away. Nothing happens." }
        ]
      },
      {
        id: "ped_offer",
        emoji: "\u{1F489}",
        title: "PERFORMANCE ENHANCING DRUGS",
        description: `A private trainer you met over the summer, nobody from your club, gets you alone after a session. He offers you an 'undetectable' substance that will boost all your stats by +5 for 3 seasons. "Nobody ever has to know," he whispers.`,
        choices: [
          { label: "Take the substance", emoji: "\u{1F48A}", consequence: "All stats +5 for 3 seasons", risk: "20% chance of a failed test each season: banned for a season" },
          { label: "Refuse", emoji: "\u270B", consequence: "Morale -5, but integrity +10 legacy bonus at retirement" }
        ]
      },
      {
        id: "diving_reputation",
        emoji: "\u{1F93F}",
        title: "DIVING REPUTATION",
        description: "You've developed a reputation for simulation. Journalists are running front-page stories about your theatrical falls in the box. Pundits are calling you 'the greatest actor in football.'",
        choices: [
          { label: "Embrace the dark arts", emoji: "\u{1F3AD}", consequence: "+2 goals per season from penalties, but reputation -15" },
          { label: "Clean up your game", emoji: "\u{1F91D}", consequence: "Reputation +10, integrity +5" },
          { label: "Ignore the noise", emoji: "\u{1F507}", consequence: "No change, let them talk" }
        ]
      },
      {
        id: "agent_corruption",
        emoji: "\u{1F574}\uFE0F",
        title: "AGENT CORRUPTION",
        description: "Your accountant finds your agent has been skimming double the agreed commission for the last 3 years. That is real money stolen from you, and your agent is sitting in your living room, sweating.",
        choices: [
          { label: "Fire your agent and sue", emoji: "\u2696\uFE0F", consequence: "Legal costs \u20AC500k, the stolen money back (up to \u20AC3M), and you negotiate your own deals from now on" },
          { label: "Keep your agent: the results are real", emoji: "\u{1F91D}", consequence: "Swallow the loss, morale -5" },
          { label: "Make them pay some of it back", emoji: "\u{1F4DD}", consequence: "Your agent stays, about a third of the money comes back" }
        ]
      },
      {
        id: "pitch_invader",
        emoji: "\u{1F3C3}",
        title: "PITCH INVADER",
        description: "Mid-match, a fan hops the barrier and sprints straight at you, phone out, screaming your name. Stewards are way behind. He's five yards away and closing.",
        choices: [
          { label: "Pose for the selfie", emoji: "\u{1F933}", consequence: "Popularity +10, but you concede possession and the crowd loves it" },
          { label: "Juke him like a defender", emoji: "\u{1F57A}", consequence: "Viral clip! Popularity +15, morale +5" },
          { label: "Push him away hard", emoji: "\u270B", consequence: "Crowd boos, popularity -10, but stewards praise your composure" }
        ]
      },
      {
        id: "match_fixer_approach",
        emoji: "\u{1F3AD}",
        title: "THE HOTEL BAR",
        description: 'A smooth operator finds you at a hotel bar the night before a meaningless end-of-season game. "Nobody cares about this one. Just miss a penalty if you get one. \u20AC2M, cash, tonight."',
        choices: [
          { label: "Take the deal", emoji: "\u{1F4B5}", consequence: "\u20AC2M added instantly", risk: "25% chance a recording leaks: banned for a season and the 2M taken back" },
          { label: "Film him and expose it", emoji: "\u{1F3A5}", consequence: "Hero status! Popularity +25, Fair Play recognition" },
          { label: "Politely decline, tell no one", emoji: "\u{1F6AA}", consequence: "Walk away clean. Nothing happens." }
        ]
      },
      {
        id: "captain_armband_feud",
        emoji: "\xA9\uFE0F",
        title: "THE ARMBAND WAR",
        description: "The manager is stripping the captaincy from a veteran teammate and offering it to you. The dressing room is split. The veteran hasn't spoken to you in three days.",
        choices: [
          { label: "Accept the armband", emoji: "\u{1F396}\uFE0F", consequence: "Popularity +10 with fans, morale -8 with a chunk of the squad" },
          { label: "Refuse out of respect", emoji: "\u{1F64F}", consequence: "Dressing room loyalty +, missed leadership bonus" },
          { label: "Broker peace between camps", emoji: "\u{1F54A}\uFE0F", consequence: "Morale +10 long term, no armband this season" }
        ]
      },
      {
        id: "tunnel_brawl",
        emoji: "\u{1F94A}",
        title: "TUNNEL INCIDENT",
        description: "After a brutal loss, an opposition player shoves you in the tunnel and says something about your family. Cameras are everywhere. Your teammates are already grabbing your shirt to hold you back.",
        choices: [
          { label: "Swing back", emoji: "\u{1F44A}", consequence: "Fined two weeks' wages, popularity -10 (your ultras loved it, nobody else did)" },
          { label: "Walk away, report it", emoji: "\u{1F6B6}", consequence: "Federation fines the other player, your reputation +15" },
          { label: "Trash talk, no contact", emoji: "\u{1F5E3}\uFE0F", consequence: "Fined a week's wages, the clip goes viral either way" }
        ]
      },
      {
        id: "sponsor_scandal",
        emoji: "\u{1F4F8}",
        title: "SPONSOR MELTDOWN",
        description: "Your energy drink sponsor just got exposed in a tax fraud scandal. Journalists are calling your phone nonstop asking if you'll cut ties with a \u20AC3M-a-year deal.",
        choices: [
          { label: "Cut ties publicly", emoji: "\u2702\uFE0F", consequence: "Lose \u20AC3M/year income, popularity +15" },
          { label: "Stay quiet, keep the money", emoji: "\u{1F910}", consequence: "Keep the deal, popularity -10 as backlash builds" },
          { label: "Donate the year's fee to charity", emoji: "\u2764\uFE0F", consequence: "Keep the deal, popularity +20, net worth unchanged this year" }
        ]
      },
      {
        id: "betting_ring_teammate",
        emoji: "\u{1F3B2}",
        title: "AN OLD FRIEND IN TROUBLE",
        description: "Your best mate from the academy, now playing a division below, confesses he owes a betting syndicate a huge sum and they've started asking him about your injury news. He's begging you not to tell anyone.",
        choices: [
          { label: "Report it to the federation", emoji: "\u{1F4E2}", consequence: "He gets suspended, integrity +15, morale -5 (you lost a friend)" },
          { label: "Lend him the money quietly", emoji: "\u{1F4B6}", consequence: "Net worth -1.5M, loyalty earned, risk buried" },
          { label: "Tell him to fix it himself", emoji: "\u{1F937}", consequence: "Nothing happens. You hope it stays that way" }
        ]
      },
      {
        id: "wonderkid_jealousy",
        emoji: "\u{1F31F}",
        title: "THE NEW WONDERKID",
        description: "The club just paid a fortune for a hyped 18-year-old who plays your exact position. The manager is clearly grooming him to replace you. He's also incredibly likeable, which makes it worse.",
        choices: [
          { label: "Mentor him openly", emoji: "\u{1F91D}", consequence: "Popularity +15, and the kid never forgets it" },
          { label: "Freeze him out", emoji: "\u{1F9CA}", consequence: "Morale -10, the dressing room turns cold on you" },
          { label: "Focus on yourself, ignore it", emoji: "\u{1F3AF}", consequence: "No change, business as usual" }
        ]
      },
      {
        id: "night_out_photo",
        emoji: "\u{1F37E}",
        title: "THE NIGHT OUT PHOTO",
        description: "A photo leaks of you out until 4am, three days before a huge cup final. It is blowing up online. Training is in six hours and the manager wants to see you immediately.",
        choices: [
          { label: "Own it, apologize publicly", emoji: "\u{1F647}", consequence: "Popularity +5 for honesty, morale -5, fined one week's wages" },
          { label: "Deny everything", emoji: "\u{1F645}", consequence: "Story drags on", risk: "35% chance it resurfaces: popularity -15" },
          { label: "Let your agent spin it", emoji: "\u{1F399}\uFE0F", consequence: "Story dies down fast, small net worth cost for the PR team" }
        ]
      },
      // 2026-08-05 storyline expansion (owner request: mafia arc, magazine offer, pitch chaos, more)
      {
        id: "magazine_shoot",
        emoji: "\u{1F4F8}",
        title: "THE MAGAZINE CALL",
        description: "A famous magazine wants you on the cover. The tasteful version pays well. The bold version, shirt off with a football under your arm, pays absurdly. Your agent is already laughing.",
        choices: [
          { label: "Tasteful calendar shoot", emoji: "\u{1F60E}", consequence: "2M fee, popularity +10" },
          { label: "The full artistic cover", emoji: "\u{1F648}", consequence: "6M fee, popularity +18", risk: "25% chance a sponsor drops you for 2M" },
          { label: "Decline politely", emoji: "\u{1F6AA}", consequence: "Nothing happens. Your grandmother approves." }
        ]
      },
      {
        id: "mafia_cup_ask",
        emoji: "\u{1F574}\uFE0F",
        title: "AN OFFER FROM SERIOUS PEOPLE",
        description: "Two men in beautiful suits find you at a family restaurant. They know your order. They want next month's cup tie thrown. 8M, offshore, untouchable. A small favor between friends, they say.",
        choices: [
          { label: "Take the money", emoji: "\u{1F4B0}", consequence: "8M offshore, morale -5. They now consider you a friend.", risk: "They ALWAYS come back" },
          { label: "Refuse and go to the police", emoji: "\u{1F694}", consequence: "Federation protection, popularity +20, integrity +15" },
          { label: "Refuse, say nothing", emoji: "\u{1F910}", consequence: "They nod and leave. You sleep badly for a week." }
        ]
      },
      {
        id: "mafia_second_ask",
        emoji: "\u{1F3A9}",
        title: "THE FRIENDS RETURN",
        description: "Same restaurant. Same suits. This time it is the title decider they want, and the number is 15M. The smile is thinner now. Friends help friends twice, they say.",
        choices: [
          { label: "Do it one last time", emoji: "\u{1F4B6}", consequence: "15M offshore", risk: "50% chance the investigation lands: banned for two seasons, legacy shattered" },
          { label: "Refuse them", emoji: "\u270B", consequence: "Morale -10, and they mention the first favor on the way out", risk: "40% chance the first fix leaks: banned for a season" },
          { label: "Go to the police, full confession", emoji: "\u{1F694}", consequence: "Immunity for testimony, popularity +25, integrity +10, the arc ends" }
        ]
      },
      {
        id: "streaker_proposal",
        emoji: "\u{1F48D}",
        title: "PITCH SIDE PROPOSAL",
        description: "A fan in a full wedding dress clears the hoardings, drops to one knee in the center circle, and holds up a ring the size of a grape. The stadium is HOWLING. The referee has given up.",
        choices: [
          { label: "Say yes as a joke", emoji: "\u{1F48D}", consequence: "The clip breaks the internet. Popularity +15" },
          { label: "Sign her sign, keep it moving", emoji: "\u{1F58A}\uFE0F", consequence: "Wholesome moment, popularity +8" },
          { label: "Play on, total professional", emoji: "\u26BD", consequence: "Pundits praise the focus, morale +3" }
        ]
      },
      {
        id: "deepfake_scandal",
        emoji: "\u{1F916}",
        title: "THE DEEPFAKE",
        description: "An AI video of you insulting your own fans is everywhere. It is fake, it is convincing, and your mentions are a war zone. The club wants a response within the hour.",
        choices: [
          { label: "Sue everyone involved", emoji: "\u2696\uFE0F", consequence: "1M legal costs, vindicated in court, popularity +15" },
          { label: "Post a parody of the parody", emoji: "\u{1F3AD}", consequence: "Popularity +20 if it lands", risk: "20% chance it reads wrong and costs 10 popularity" },
          { label: "Ignore it entirely", emoji: "\u{1F9D8}", consequence: "It burns out in a week. Small morale dip." }
        ]
      },
      {
        id: "hometown_statue",
        emoji: "\u{1F5FF}",
        title: "THE STATUE PROBLEM",
        description: "Your hometown commissioned a statue of you. The unveiling photos leak early. It looks like a melted action figure of someone else entirely. The sculptor is very proud.",
        choices: [
          { label: "Quietly fund a redo", emoji: "\u{1F4B6}", consequence: "2M cost, the new one is beautiful, popularity +12" },
          { label: "Embrace the meme statue", emoji: "\u{1F5FF}", consequence: "It becomes a pilgrimage site. Popularity +18" },
          { label: "Ask them to take it down", emoji: "\u{1F645}", consequence: "The town is hurt. Popularity -5" }
        ]
      },
      {
        id: "haunted_hotel",
        emoji: "\u{1F47B}",
        title: "THE HAUNTED HOTEL",
        description: "Night before the biggest match of the season, half the squad swears the team hotel is haunted. Two defenders are refusing to sleep alone. The manager is furious. Somebody has to lead here.",
        choices: [
          { label: "Lead a squad seance", emoji: "\u{1F56F}\uFE0F", consequence: "Team bonding of the strangest kind. Morale +8" },
          { label: "Demand a hotel change", emoji: "\u{1F3E8}", consequence: "Awkward with the club, but everyone sleeps. Morale +3" },
          { label: "Sleep in the team bus", emoji: "\u{1F68C}", consequence: "The photo goes viral. Popularity +10" }
        ]
      },
      {
        id: "valet_crash",
        emoji: "\u{1F511}",
        title: "THE VALET INCIDENT",
        description: "A hotel valet just reversed your hypercar into a fountain at 40 km/h. He is 19, shaking, and pretty sure his life is over. Forty phones are already filming.",
        choices: [
          { label: "Hug him, forgive publicly", emoji: "\u{1F917}", consequence: "The clip melts hearts. Popularity +12, the car costs 1.5M" },
          { label: "Insurance war", emoji: "\u{1F4CB}", consequence: "Insurance covers the 1.5M, popularity -8, he loses his job" },
          { label: "Gift him a bus pass and a smile", emoji: "\u{1F68C}", consequence: "Perfect comedy. Popularity +15, the car still costs 1.5M" }
        ]
      },
      {
        id: "wag_reality_show",
        emoji: "\u{1F4FA}",
        title: "THE REALITY SHOW",
        description: "A production company offers serious money to film a reality series inside your house. Your partner is excited. Your center back already texted: do NOT do this.",
        choices: [
          { label: "Full season, full access", emoji: "\u{1F3AC}", consequence: "3M fee, popularity +8", risk: "25% chance a dressing-room secret airs: morale -10" },
          { label: "One tasteful episode", emoji: "\u{1F39E}\uFE0F", consequence: "1M fee, everyone survives" },
          { label: "Hard no", emoji: "\u{1F6AA}", consequence: "Partner sulks for a week, morale +4 long term" }
        ]
      },
      {
        id: "ultras_tattoo",
        emoji: "\u{1F409}",
        title: "THE ULTRAS' DEMAND",
        description: "After your late winner, the ultras unfurl a banner: TATTOO THE CREST OR YOU NEVER LOVED US. They are outside training with a tattoo artist. He seems extremely available.",
        choices: [
          { label: "Get the crest tattooed", emoji: "\u{1F409}", consequence: "Popularity +15 here forever. Awkward if you ever transfer" },
          { label: "Henna prank first", emoji: "\u{1F58C}\uFE0F", consequence: "Popularity +8 for the joke", risk: "30% chance they find out it washed off: -10" },
          { label: "Respectfully decline", emoji: "\u{1F64F}", consequence: "Popularity -5, your skin remains yours" }
        ]
      },
      {
        id: "bdor_snub",
        emoji: "\u{1F948}",
        title: "THE SNUB",
        description: "Everyone in your camp thought this was your Ballon d'Or. It went to someone else. The cameras cut to your face at the exact wrong moment and the whole world saw it.",
        choices: [
          { label: "Fuel. Pure fuel.", emoji: "\u{1F525}", consequence: "+3 to every stat next season, morale -5. Revenge tour begins" },
          { label: "Congratulate the winner beautifully", emoji: "\u{1F91D}", consequence: "Popularity +10, integrity +5, the high road" },
          { label: "Skip the afterparty, train at midnight", emoji: "\u{1F319}", consequence: "The gym photo goes viral. +2 stats next season, popularity +5" }
        ]
      },
      {
        id: "biscuit_gate",
        emoji: "\u{1F36A}",
        title: "BISCUIT GATE",
        description: "You were photographed enjoying a rival brand's biscuit while your cereal sponsor pays you millions. The internet has named it Biscuit Gate. The sponsor's lawyers have named it a breach.",
        choices: [
          { label: "Apologize with a taste test video", emoji: "\u{1F3A5}", consequence: "Sponsor placated, the video hits huge, popularity +10" },
          { label: "Declare biscuit independence", emoji: "\u{1F36A}", consequence: "Lose 1M sponsor fee, popularity +15, folk hero status" },
          { label: "Blame a lookalike", emoji: "\u{1F978}", consequence: "Nobody believes you, popularity -5, it becomes a meme" }
        ]
      },
      // 2026-08-05 rivalry expansion: the feud gets interactive. Round 796: the
      // four live in SOCCER_RIVALRY_CHOICES above and are drawn from there, in
      // the same four places in this list.
      rivalChoiceDilemma("rival_club_offer"),
      rivalChoiceDilemma("rival_bad_tackle"),
      rivalChoiceDilemma("goat_debate_show"),
      rivalChoiceDilemma("rival_charity_match")
    ];
    clamp3 = (v, min, max) => Math.max(min, Math.min(max, v));
    HAND_CLUBS = [
      // Tier 1, elite
      { id: "fb-1", name: "Real Madrid", country: "Spain", tier: 1, color: "#FEBE10", league: "La Liga" },
      { id: "fb-2", name: "Barcelona", country: "Spain", tier: 1, color: "#A50044", league: "La Liga" },
      { id: "fb-3", name: "Man City", country: "England", tier: 1, color: "#6CABDD", league: "Premier League" },
      { id: "fb-4", name: "Liverpool", country: "England", tier: 1, color: "#C8102E", league: "Premier League" },
      { id: "fb-5", name: "Bayern Munich", country: "Germany", tier: 1, color: "#DC052D", league: "Bundesliga" },
      { id: "fb-6", name: "PSG", country: "France", tier: 1, color: "#004170", league: "Ligue 1" },
      { id: "fb-7", name: "Juventus", country: "Italy", tier: 1, color: "#000000", league: "Serie A" },
      { id: "fb-8", name: "Inter Milan", country: "Italy", tier: 1, color: "#0068A8", league: "Serie A" },
      { id: "fb-9", name: "Man United", country: "England", tier: 1, color: "#DA291C", league: "Premier League" },
      { id: "fb-10", name: "Arsenal", country: "England", tier: 1, color: "#EF0107", league: "Premier League" },
      { id: "fb-11", name: "Chelsea", country: "England", tier: 1, color: "#034694", league: "Premier League" },
      { id: "fb-12", name: "Ajax", country: "Netherlands", tier: 1, color: "#D2122E", league: "Eredivisie" },
      { id: "fb-13", name: "Benfica", country: "Portugal", tier: 1, color: "#E30613", league: "Primeira Liga" },
      { id: "fb-14", name: "Porto", country: "Portugal", tier: 1, color: "#003399", league: "Primeira Liga" },
      { id: "fb-15", name: "Boca Juniors", country: "Argentina", tier: 1, color: "#003DA5", league: "Liga Profesional" },
      { id: "fb-16", name: "River Plate", country: "Argentina", tier: 1, color: "#E9040F", league: "Liga Profesional" },
      { id: "fb-17", name: "Flamengo", country: "Brazil", tier: 1, color: "#C8102E", league: "Brasileirao" },
      { id: "fb-18", name: "Sao Paulo", country: "Brazil", tier: 1, color: "#B40404", league: "Brasileirao" },
      // Tier 2, strong mid-table
      { id: "fb-19", name: "Atletico Madrid", country: "Spain", tier: 2, color: "#CB3524", league: "La Liga" },
      { id: "fb-20", name: "Sevilla", country: "Spain", tier: 2, color: "#D0021B", league: "La Liga" },
      { id: "fb-21", name: "Tottenham", country: "England", tier: 2, color: "#132257", league: "Premier League" },
      { id: "fb-22", name: "Newcastle", country: "England", tier: 2, color: "#241F20", league: "Premier League" },
      { id: "fb-23", name: "Dortmund", country: "Germany", tier: 2, color: "#FDE100", league: "Bundesliga" },
      { id: "fb-24", name: "Leipzig", country: "Germany", tier: 2, color: "#DD0741", league: "Bundesliga" },
      { id: "fb-25", name: "AC Milan", country: "Italy", tier: 2, color: "#FB090B", league: "Serie A" },
      { id: "fb-26", name: "Napoli", country: "Italy", tier: 2, color: "#12A0D7", league: "Serie A" },
      { id: "fb-27", name: "Roma", country: "Italy", tier: 2, color: "#8E1F2F", league: "Serie A" },
      { id: "fb-28", name: "Marseille", country: "France", tier: 2, color: "#2FA0DA", league: "Ligue 1" },
      { id: "fb-29", name: "Lyon", country: "France", tier: 2, color: "#1C2C5B", league: "Ligue 1" },
      { id: "fb-30", name: "Feyenoord", country: "Netherlands", tier: 2, color: "#00A03C", league: "Eredivisie" },
      { id: "fb-31", name: "PSV", country: "Netherlands", tier: 2, color: "#ED1C24", league: "Eredivisie" },
      { id: "fb-32", name: "Sporting CP", country: "Portugal", tier: 2, color: "#008148", league: "Primeira Liga" },
      { id: "fb-33", name: "Fenerbahce", country: "Turkey", tier: 2, color: "#0A2C59", league: "Super Lig" },
      { id: "fb-34", name: "Galatasaray", country: "Turkey", tier: 2, color: "#A90432", league: "Super Lig" },
      { id: "fb-35", name: "Al Hilal", country: "Saudi Arabia", tier: 2, color: "#003DA5", league: "Saudi Pro League" },
      { id: "fb-36", name: "Celtic", country: "Scotland", tier: 2, color: "#018749", league: "Scottish Premiership" },
      { id: "fb-37", name: "Rangers", country: "Scotland", tier: 2, color: "#1E3A8A", league: "Scottish Premiership" },
      { id: "fb-38", name: "Palmeiras", country: "Brazil", tier: 2, color: "#006437", league: "Brasileirao" },
      { id: "fb-39", name: "LA Galaxy", country: "USA", tier: 2, color: "#00245D", league: "MLS" },
      { id: "fb-40", name: "Inter Miami", country: "USA", tier: 2, color: "#F7B5CD", league: "MLS" },
      // Tier 3, solid domestic clubs
      { id: "fb-41", name: "Real Sociedad", country: "Spain", tier: 3, color: "#0067B1", league: "La Liga" },
      { id: "fb-42", name: "Villarreal", country: "Spain", tier: 3, color: "#FFE667", league: "La Liga" },
      { id: "fb-43", name: "West Ham", country: "England", tier: 3, color: "#7A263A", league: "Championship" },
      { id: "fb-44", name: "Aston Villa", country: "England", tier: 3, color: "#670E36", league: "Premier League" },
      { id: "fb-45", name: "Everton", country: "England", tier: 3, color: "#003399", league: "Premier League" },
      { id: "fb-46", name: "Leverkusen", country: "Germany", tier: 3, color: "#E32221", league: "Bundesliga" },
      { id: "fb-47", name: "Frankfurt", country: "Germany", tier: 3, color: "#E1000F", league: "Bundesliga" },
      { id: "fb-48", name: "Atalanta", country: "Italy", tier: 3, color: "#1E71B8", league: "Serie A" },
      { id: "fb-49", name: "Fiorentina", country: "Italy", tier: 3, color: "#5B2A86", league: "Serie A" },
      { id: "fb-50", name: "Lille", country: "France", tier: 3, color: "#C60C30", league: "Ligue 1" },
      { id: "fb-51", name: "Monaco", country: "Monaco", tier: 3, color: "#E2231A", league: "Ligue 1" },
      { id: "fb-52", name: "Genk", country: "Belgium", tier: 3, color: "#0055A4", league: "Belgian Pro League" },
      { id: "fb-53", name: "Anderlecht", country: "Belgium", tier: 3, color: "#5E2C81", league: "Belgian Pro League" },
      { id: "fb-54", name: "FC Copenhagen", country: "Denmark", tier: 3, color: "#FFFFFF", league: "Danish Superliga" },
      { id: "fb-55", name: "Malmo FF", country: "Sweden", tier: 3, color: "#5CB8E4", league: "Allsvenskan" },
      { id: "fb-56", name: "Red Bull Salzburg", country: "Austria", tier: 3, color: "#DB021D", league: "Austrian Bundesliga" },
      { id: "fb-57", name: "Basel", country: "Switzerland", tier: 3, color: "#DB021D", league: "Swiss Super League" },
      { id: "fb-58", name: "Al Nassr", country: "Saudi Arabia", tier: 3, color: "#FFF200", league: "Saudi Pro League" },
      { id: "fb-59", name: "Cruz Azul", country: "Mexico", tier: 3, color: "#00539F", league: "Liga MX" },
      { id: "fb-60", name: "Club America", country: "Mexico", tier: 3, color: "#FFC72C", league: "Liga MX" },
      // Tier 4, smaller / lower league
      { id: "fb-61", name: "Real Betis", country: "Spain", tier: 4, color: "#00954C", league: "La Liga" },
      { id: "fb-62", name: "Celta Vigo", country: "Spain", tier: 4, color: "#8AC3EE", league: "La Liga" },
      { id: "fb-63", name: "Crystal Palace", country: "England", tier: 4, color: "#1B458F", league: "Premier League" },
      { id: "fb-64", name: "Brentford", country: "England", tier: 4, color: "#D20000", league: "Premier League" },
      { id: "fb-65", name: "Norwich City", country: "England", tier: 4, color: "#FFF200", league: "Championship" },
      { id: "fb-66", name: "Hertha Berlin", country: "Germany", tier: 4, color: "#004C9E", league: "2. Bundesliga" },
      { id: "fb-67", name: "Werder Bremen", country: "Germany", tier: 4, color: "#1D9053", league: "Bundesliga" },
      { id: "fb-68", name: "Torino", country: "Italy", tier: 4, color: "#881B1E", league: "Serie A" },
      { id: "fb-69", name: "Bologna", country: "Italy", tier: 4, color: "#A61C2E", league: "Serie A" },
      { id: "fb-70", name: "Nantes", country: "France", tier: 4, color: "#FCE300", league: "Ligue 2" },
      { id: "fb-71", name: "Strasbourg", country: "France", tier: 4, color: "#0072BB", league: "Ligue 1" },
      { id: "fb-72", name: "Utrecht", country: "Netherlands", tier: 4, color: "#D2122E", league: "Eredivisie" },
      { id: "fb-73", name: "Braga", country: "Portugal", tier: 4, color: "#DA020E", league: "Primeira Liga" },
      { id: "fb-74", name: "Aberdeen", country: "Scotland", tier: 4, color: "#D71920", league: "Scottish Premiership" },
      { id: "fb-75", name: "Santos", country: "Brazil", tier: 4, color: "#FFFFFF", league: "Brasileirao" },
      { id: "fb-76", name: "Colo-Colo", country: "Chile", tier: 4, color: "#FFFFFF", league: "Primera Division" },
      { id: "fb-77", name: "Al Ahly", country: "Egypt", tier: 4, color: "#C8102E", league: "Egyptian Premier League" },
      { id: "fb-78", name: "Kaizer Chiefs", country: "South Africa", tier: 4, color: "#FFD100", league: "PSL" },
      { id: "fb-79", name: "Yokohama F. Marinos", country: "Japan", tier: 4, color: "#00559A", league: "J1 League" },
      { id: "fb-80", name: "Urawa Red Diamonds", country: "Japan", tier: 4, color: "#D2001C", league: "J1 League" },
      { id: "fb-81", name: "Seattle Sounders", country: "USA", tier: 4, color: "#5D9741", league: "MLS" },
      // ── Round 54 expansion: 60+ new clubs so careers can wind through nearly
      // every football country on earth (owner: "more teams and more flags and
      // more of everything"). Tier 2, big names outside the usual five leagues.
      { id: "fb-82", name: "Al Ittihad", country: "Saudi Arabia", tier: 2, color: "#F9C623", league: "Saudi Pro League" },
      { id: "fb-83", name: "Club Brugge", country: "Belgium", tier: 2, color: "#0B4494", league: "Belgian Pro League" },
      { id: "fb-84", name: "Olympiacos", country: "Greece", tier: 2, color: "#D6202B", league: "Super League Greece" },
      { id: "fb-85", name: "Shakhtar Donetsk", country: "Ukraine", tier: 2, color: "#F26522", league: "Ukrainian Premier League" },
      { id: "fb-86", name: "Corinthians", country: "Brazil", tier: 2, color: "#141414", league: "Brasileirao" },
      { id: "fb-87", name: "Monterrey", country: "Mexico", tier: 2, color: "#0A2240", league: "Liga MX" },
      { id: "fb-88", name: "Tigres UANL", country: "Mexico", tier: 2, color: "#FDB913", league: "Liga MX" },
      { id: "fb-89", name: "Athletic Bilbao", country: "Spain", tier: 2, color: "#EE2523", league: "La Liga" },
      { id: "fb-90", name: "Brighton", country: "England", tier: 2, color: "#0057B8", league: "Premier League" },
      { id: "fb-91", name: "Stuttgart", country: "Germany", tier: 2, color: "#E32219", league: "Bundesliga" },
      { id: "fb-92", name: "LAFC", country: "USA", tier: 2, color: "#C39E6D", league: "MLS" },
      { id: "fb-93", name: "River Plate Asuncion", country: "Paraguay", tier: 4, color: "#CE1126", league: "Primera B Paraguay" },
      { id: "fb-94", name: "Racing Club", country: "Argentina", tier: 2, color: "#75AADB", league: "Liga Profesional" },
      { id: "fb-95", name: "Zenit", country: "Russia", tier: 2, color: "#009FDF", league: "Russian Premier League" },
      { id: "fb-96", name: "Girona", country: "Spain", tier: 2, color: "#CD2534", league: "Segunda Division" },
      // Tier 3, strong clubs across Europe, Asia, Africa and the Americas.
      { id: "fb-97", name: "PAOK", country: "Greece", tier: 3, color: "#2B2B2B", league: "Super League Greece" },
      { id: "fb-98", name: "Panathinaikos", country: "Greece", tier: 3, color: "#00743F", league: "Super League Greece" },
      { id: "fb-99", name: "Dinamo Zagreb", country: "Croatia", tier: 3, color: "#1F4C9C", league: "HNL" },
      { id: "fb-100", name: "Red Star Belgrade", country: "Serbia", tier: 3, color: "#D6202B", league: "Serbian SuperLiga" },
      { id: "fb-101", name: "Legia Warsaw", country: "Poland", tier: 3, color: "#0F5B2F", league: "Ekstraklasa" },
      { id: "fb-102", name: "Slavia Prague", country: "Czech Republic", tier: 3, color: "#D6202B", league: "Czech First League" },
      { id: "fb-103", name: "Besiktas", country: "Turkey", tier: 3, color: "#2B2B2B", league: "Super Lig" },
      { id: "fb-104", name: "Trabzonspor", country: "Turkey", tier: 3, color: "#5C1F33", league: "Super Lig" },
      { id: "fb-105", name: "Nice", country: "France", tier: 3, color: "#CC0000", league: "Ligue 1" },
      { id: "fb-106", name: "Wolves", country: "England", tier: 3, color: "#FDB913", league: "Championship" },
      { id: "fb-107", name: "Fulham", country: "England", tier: 3, color: "#111111", league: "Premier League" },
      { id: "fb-108", name: "Gremio", country: "Brazil", tier: 3, color: "#0D80BF", league: "Brasileirao" },
      { id: "fb-109", name: "Atletico Nacional", country: "Colombia", tier: 3, color: "#00A650", league: "Liga BetPlay" },
      { id: "fb-110", name: "Penarol", country: "Uruguay", tier: 3, color: "#FFD100", league: "Primera Division Uruguay" },
      { id: "fb-111", name: "Kawasaki Frontale", country: "Japan", tier: 3, color: "#009FE8", league: "J1 League" },
      { id: "fb-112", name: "Jeonbuk Motors", country: "South Korea", tier: 3, color: "#0C6B3E", league: "K League 1" },
      { id: "fb-113", name: "Al Sadd", country: "Qatar", tier: 3, color: "#2B2B2B", league: "Qatar Stars League" },
      { id: "fb-114", name: "Persepolis", country: "Iran", tier: 3, color: "#D6202B", league: "Persian Gulf Pro League" },
      { id: "fb-115", name: "Shanghai Port", country: "China", tier: 3, color: "#D6202B", league: "Chinese Super League" },
      { id: "fb-116", name: "Zamalek", country: "Egypt", tier: 3, color: "#FFFFFF", league: "Egyptian Premier League" },
      { id: "fb-117", name: "Wydad Casablanca", country: "Morocco", tier: 3, color: "#D6202B", league: "Botola Pro" },
      { id: "fb-118", name: "Esperance", country: "Tunisia", tier: 3, color: "#BC0C12", league: "Ligue 1 Tunisia" },
      { id: "fb-119", name: "Mamelodi Sundowns", country: "South Africa", tier: 3, color: "#FBC403", league: "PSL" },
      { id: "fb-120", name: "Toronto FC", country: "Canada", tier: 3, color: "#B81137", league: "MLS" },
      // Tier 4, the wide world where most careers actually start.
      { id: "fb-121", name: "Sparta Prague", country: "Czech Republic", tier: 4, color: "#7B0C11", league: "Czech First League" },
      { id: "fb-122", name: "Partizan", country: "Serbia", tier: 4, color: "#2B2B2B", league: "Serbian SuperLiga" },
      { id: "fb-123", name: "Ferencvaros", country: "Hungary", tier: 4, color: "#0E5C2F", league: "NB I" },
      { id: "fb-124", name: "Hajduk Split", country: "Croatia", tier: 4, color: "#0C4076", league: "HNL" },
      { id: "fb-125", name: "HJK Helsinki", country: "Finland", tier: 4, color: "#0056A3", league: "Veikkausliiga" },
      { id: "fb-126", name: "Breidablik", country: "Iceland", tier: 4, color: "#00954C", league: "Besta deild" },
      { id: "fb-127", name: "Slovan Bratislava", country: "Slovakia", tier: 4, color: "#57A8E2", league: "Slovak First League" },
      { id: "fb-128", name: "Ludogorets", country: "Bulgaria", tier: 4, color: "#00954C", league: "First League Bulgaria" },
      { id: "fb-129", name: "Sheriff Tiraspol", country: "Moldova", tier: 4, color: "#FBC403", league: "Super Liga Moldova" },
      { id: "fb-130", name: "Dinamo Tbilisi", country: "Georgia", tier: 4, color: "#0C4076", league: "Erovnuli Liga" },
      { id: "fb-131", name: "Pyunik", country: "Armenia", tier: 4, color: "#D6202B", league: "Armenian Premier League" },
      { id: "fb-132", name: "Qarabag", country: "Azerbaijan", tier: 4, color: "#2B2B2B", league: "Azerbaijan Premier League" },
      { id: "fb-133", name: "Kairat Almaty", country: "Kazakhstan", tier: 4, color: "#FBC403", league: "Kazakhstan Premier League" },
      { id: "fb-134", name: "Pakhtakor", country: "Uzbekistan", tier: 4, color: "#0056A3", league: "Uzbekistan Super League" },
      { id: "fb-135", name: "Mumbai City", country: "India", tier: 4, color: "#57A8E2", league: "Indian Super League" },
      { id: "fb-136", name: "Buriram United", country: "Thailand", tier: 4, color: "#0C2E5C", league: "Thai League 1" },
      { id: "fb-137", name: "Persija Jakarta", country: "Indonesia", tier: 4, color: "#D6202B", league: "Super League Indonesia" },
      { id: "fb-138", name: "Hanoi FC", country: "Vietnam", tier: 4, color: "#5C2D91", league: "V.League 1" },
      { id: "fb-139", name: "Johor Darul Tazim", country: "Malaysia", tier: 4, color: "#0C2E5C", league: "Malaysia Super League" },
      { id: "fb-140", name: "Melbourne Victory", country: "Australia", tier: 4, color: "#0C2E5C", league: "A-League" },
      { id: "fb-141", name: "Auckland FC", country: "New Zealand", tier: 4, color: "#2B2B2B", league: "A-League" },
      { id: "fb-142", name: "Wellington Phoenix", country: "New Zealand", tier: 4, color: "#FBC403", league: "A-League" },
      { id: "fb-143", name: "Raja Casablanca", country: "Morocco", tier: 4, color: "#00954C", league: "Botola Pro" },
      { id: "fb-144", name: "TP Mazembe", country: "DR Congo", tier: 4, color: "#2B2B2B", league: "Linafoot" },
      { id: "fb-145", name: "Enyimba", country: "Nigeria", tier: 4, color: "#0056A3", league: "NPFL" },
      { id: "fb-146", name: "Asante Kotoko", country: "Ghana", tier: 4, color: "#D6202B", league: "Ghana Premier League" },
      { id: "fb-147", name: "Gor Mahia", country: "Kenya", tier: 4, color: "#00954C", league: "Kenyan Premier League" },
      { id: "fb-148", name: "Orlando Pirates", country: "South Africa", tier: 4, color: "#2B2B2B", league: "PSL" },
      { id: "fb-149", name: "Saint George", country: "Ethiopia", tier: 4, color: "#FBC403", league: "Ethiopian Premier League" },
      { id: "fb-150", name: "Young Africans", country: "Tanzania", tier: 4, color: "#00954C", league: "NBC Premier League" },
      { id: "fb-151", name: "Atletico Petroleos", country: "Angola", tier: 4, color: "#FBC403", league: "Girabola" },
      { id: "fb-152", name: "Nacional", country: "Uruguay", tier: 4, color: "#FFFFFF", league: "Primera Division Uruguay" },
      { id: "fb-153", name: "Universidad de Chile", country: "Chile", tier: 4, color: "#0C2E5C", league: "Primera Division" },
      { id: "fb-154", name: "Millonarios", country: "Colombia", tier: 4, color: "#0056A3", league: "Liga BetPlay" },
      { id: "fb-155", name: "LDU Quito", country: "Ecuador", tier: 4, color: "#FFFFFF", league: "LigaPro" },
      { id: "fb-156", name: "Alianza Lima", country: "Peru", tier: 4, color: "#0C2E5C", league: "Liga 1 Peru" },
      { id: "fb-157", name: "Olimpia", country: "Paraguay", tier: 4, color: "#2B2B2B", league: "Primera Division Paraguay" },
      { id: "fb-158", name: "Caracas FC", country: "Venezuela", tier: 4, color: "#7B0C11", league: "Liga FUTVE" },
      { id: "fb-159", name: "Bolivar", country: "Bolivia", tier: 4, color: "#57A8E2", league: "Division Profesional" },
      { id: "fb-160", name: "Saprissa", country: "Costa Rica", tier: 4, color: "#5C2D91", league: "Liga FPD" },
      { id: "fb-161", name: "Olimpia Tegucigalpa", country: "Honduras", tier: 4, color: "#FFFFFF", league: "Liga Nacional Honduras" },
      { id: "fb-162", name: "Alianza FC", country: "El Salvador", tier: 4, color: "#FFFFFF", league: "Primera Division El Salvador" },
      { id: "fb-163", name: "Comunicaciones", country: "Guatemala", tier: 4, color: "#FFFFFF", league: "Liga Nacional Guatemala" },
      { id: "fb-164", name: "Violette AC", country: "Haiti", tier: 4, color: "#5C2D91", league: "Ligue Haitienne" },
      { id: "fb-165", name: "Waterhouse FC", country: "Jamaica", tier: 4, color: "#D6202B", league: "Jamaica Premier League" },
      { id: "fb-166", name: "Defence Force FC", country: "Trinidad and Tobago", tier: 4, color: "#7B0C11", league: "TT Premier League" },
      { id: "fb-167", name: "Vancouver Whitecaps", country: "Canada", tier: 4, color: "#0C2E5C", league: "MLS" },
      { id: "fb-168", name: "Chivas", country: "Mexico", tier: 4, color: "#D6202B", league: "Liga MX" },
      { id: "fb-169", name: "Pumas", country: "Mexico", tier: 4, color: "#0C2E5C", league: "Liga MX" },
      { id: "fb-170", name: "Al Duhail", country: "Qatar", tier: 4, color: "#D6202B", league: "Qatar Stars League" },
      { id: "fb-171", name: "Al Ain", country: "UAE", tier: 4, color: "#5C2D91", league: "UAE Pro League" },
      { id: "fb-172", name: "Beijing Guoan", country: "China", tier: 4, color: "#00954C", league: "Chinese Super League" },
      { id: "fb-173", name: "Maccabi Tel Aviv", country: "Israel", tier: 4, color: "#FBC403", league: "Israeli Premier League" },
      { id: "fb-174", name: "APOEL", country: "Cyprus", tier: 4, color: "#F26522", league: "Cypriot First Division" },
      { id: "fb-175", name: "Flora Tallinn", country: "Estonia", tier: 4, color: "#00954C", league: "Meistriliiga" },
      { id: "fb-176", name: "Zalgiris Vilnius", country: "Lithuania", tier: 4, color: "#00954C", league: "A Lyga" },
      /* Round 302, off the owner's tweaks document: the leagues he named by name
         (Liga Portugal here as Primeira Liga, Eredivisie, Scottish, MLS, Saudi,
         K League) get real depth instead of two or three clubs each. League
         labels are byte identical to the strings already in this array, because
         league is free text and a near miss silently creates a new league. */
      { id: "fb-177", name: "AZ Alkmaar", country: "Netherlands", tier: 3, color: "#DD0000", league: "Eredivisie" },
      { id: "fb-178", name: "Twente", country: "Netherlands", tier: 4, color: "#E70011", league: "Eredivisie" },
      { id: "fb-179", name: "Vitoria Guimaraes", country: "Portugal", tier: 4, color: "#F5F5F5", league: "Primeira Liga" },
      { id: "fb-180", name: "Hearts", country: "Scotland", tier: 4, color: "#800910", league: "Scottish Premiership" },
      { id: "fb-181", name: "Hibernian", country: "Scotland", tier: 4, color: "#006A4E", league: "Scottish Premiership" },
      { id: "fb-182", name: "Columbus Crew", country: "USA", tier: 3, color: "#FEDD00", league: "MLS" },
      { id: "fb-183", name: "Atlanta United", country: "USA", tier: 4, color: "#80000A", league: "MLS" },
      { id: "fb-184", name: "Al Ahli", country: "Saudi Arabia", tier: 3, color: "#006B3F", league: "Saudi Pro League" },
      { id: "fb-185", name: "Al Shabab", country: "Saudi Arabia", tier: 4, color: "#F2F2F2", league: "Saudi Pro League" },
      { id: "fb-186", name: "Ulsan HD", country: "South Korea", tier: 3, color: "#0053A0", league: "K League 1" },
      { id: "fb-187", name: "FC Seoul", country: "South Korea", tier: 4, color: "#AC1A2F", league: "K League 1" },
      { id: "fb-188", name: "Pohang Steelers", country: "South Korea", tier: 4, color: "#C8102E", league: "K League 1" },
      { id: "fb-189", name: "Botafogo", country: "Brazil", tier: 3, color: "#1A1A1A", league: "Brasileirao" },
      { id: "fb-190", name: "Cruzeiro", country: "Brazil", tier: 4, color: "#0033A0", league: "Brasileirao" }
    ];
    FALLBACK_CLUBS = [...HAND_CLUBS, ...CAREER_CLUB_POOL];
  }
});

// src/lib/careerDrills.ts
function drillStatFor(kind, position) {
  if (kind === "firsttouch") return trainingStatFor(position, "dribbling");
  if (kind === "throughball") return trainingStatFor(position, "passing");
  return { stat: DRILL_META[kind].stat, label: DRILL_META[kind].statLabel };
}
function drillForPosition(position) {
  if (position === "GK") return "gloves";
  if (position === "CB" || position === "LB" || position === "RB" || position === "CDM") return "tackle";
  if (position === "CM" || position === "CAM") return "throughball";
  return "wallshot";
}
function drillSeed(kind, dateStr) {
  return (daySeed(dateStr) * 7919 + KIND_SALT[kind]) % 2147483646 + 1;
}
function wallOpenAt(setup, t) {
  return Math.max(0, Math.sin(2 * Math.PI * (t / setup.period + setup.phase)));
}
function wallGapAt(setup, t) {
  return setup.gapMax * wallOpenAt(setup, t);
}
function wallTravel(power) {
  return 0.58 - 0.28 * clamp(power, 0, 1);
}
function wallNextPeak(setup, from) {
  const cycles = Math.ceil(from / setup.period + setup.phase - 0.25 - 1e-9);
  return (cycles + 0.25 - setup.phase) * setup.period;
}
function buildWallShotRun(seed) {
  return buildLadder(seed, ROUNDS_PER_RUN, (t, rng) => {
    const distance = Math.round((16 + t * 8) * 10) / 10;
    const gapCentre = Math.round((rng() * 2 - 1) * 80) / 100;
    const gapMax = Math.round((0.3 - t * 0.17) * 100) / 100;
    const period = Math.round((2.4 - t * 1.1) * 100) / 100;
    const phase = Math.round(rng() * 100) / 100;
    const keeperSkill = clamp(0.3 + t * 0.45 + (rng() - 0.5) * 0.12, 0.2, 0.82);
    const keeperLean = Math.round(clamp(gapCentre * 0.8 + (rng() - 0.5) * 0.6, -1, 1) * 100) / 100;
    const gap = gapMax >= 0.24 ? "a wide gap" : gapMax >= 0.17 ? "a gap" : "a slit";
    return { distance, gapCentre, gapMax, period, phase, keeperSkill, keeperLean, label: `${distance} m, ${gap} in the wall` };
  });
}
function takeWallShot(input, setup, rng) {
  const aim = { x: input.x, y: input.y, power: clamp(input.power, 0, 1), curve: 0 };
  const kick = { distance: setup.distance, wallSize: 5, keeperSkill: setup.keeperSkill * WALL_UNSIGHTED, keeperLean: setup.keeperLean, label: setup.label };
  const spray = sprayFor(aim.power, setup.distance - 16, WALL_SPRAY, rng);
  const path = flightPath(aim, kick, spray);
  const end = path[path.length - 1];
  const keeper = keeperDive(aim, kick, rng);
  const arrive = Math.max(0, input.press) + wallTravel(aim.power);
  const open = wallOpenAt(setup, arrive);
  const atWall = path[Math.round(path.length * 0.45)];
  const hitWall = Math.abs(atWall.x - setup.gapCentre) >= setup.gapMax * open;
  const insideX = Math.abs(end.x) < 1;
  const insideY = end.y > 0 && end.y < 1;
  const hitPost = !hitWall && Math.abs(Math.abs(end.x) - 1) < 0.035 && insideY;
  const tooWeak = aim.power < 0.36 + (setup.distance - 16) * 0.014;
  const onTarget = !hitWall && !hitPost && insideX && insideY && !tooWeak;
  const reach = 0.34 + kick.keeperSkill * 0.2;
  const saved = onTarget && Math.abs(end.x - keeper.x) < reach && Math.abs(end.y - keeper.y) < reach * 0.5 + 0.08;
  const won = onTarget && !saved;
  let points = 0;
  if (won) {
    const corner = Math.max(Math.abs(end.x), end.y > 0.5 ? end.y : 0);
    points = Math.round(100 + (setup.distance - 16) * 8 + corner * 120 + setup.keeperSkill * 60 + (0.3 - setup.gapMax) * 200);
  }
  const verdict = hitWall ? open <= 0.02 ? "Into the wall. It was shut." : "Into the wall. Off the gap." : hitPost ? "Through the gap, off the post." : tooWeak ? "Never had the legs." : !insideX || !insideY ? "Through the gap and wide of everything." : saved ? "Through the gap. Keeper got there." : "Through the wall and in.";
  return { x: end.x, y: end.y, open, hitWall, hitPost, onTarget, saved, won, points, keeperX: keeper.x, keeperY: keeper.y, path, verdict };
}
function maxWallShotScore(run) {
  return run.reduce((n, s) => n + Math.round(100 + (s.distance - 16) * 8 + 120 + s.keeperSkill * 60 + (0.3 - s.gapMax) * 200), 0);
}
function tackleFeetAt(setup, t) {
  const run = setup.speed * Math.max(0, t);
  return { x: setup.dir > 0 ? -TACKLE_EDGE + run : 1 + TACKLE_EDGE - run, y: setup.lane };
}
function tackleTouchAt(setup, t) {
  const u = ((t / setup.touchPeriod + setup.touchPhase) % 1 + 1) % 1;
  return Math.sin(Math.PI * u);
}
function tackleBallAt(setup, t) {
  const feet = tackleFeetAt(setup, t);
  const loose = tackleTouchAt(setup, t);
  return { x: feet.x + setup.dir * setup.touchLen * loose, y: feet.y + 0.03 * Math.sin(2 * Math.PI * t / setup.touchPeriod) };
}
function tackleDeadline(setup) {
  return (1 + 2 * TACKLE_EDGE) / setup.speed;
}
function buildTackleRun(seed) {
  return buildLadder(seed, ROUNDS_PER_RUN, (t, rng) => {
    const speed = Math.round((0.45 + t * 0.55) * 100) / 100;
    const dir = rng() > 0.5 ? 1 : -1;
    const lane = Math.round((0.35 + rng() * 0.3) * 100) / 100;
    const touchLen = Math.round((0.2 - t * 0.1) * 100) / 100;
    const touchPeriod = Math.round((0.9 - t * 0.45) * 100) / 100;
    const touchPhase = Math.round(rng() * 100) / 100;
    const reach = Math.round((0.08 - t * 0.038) * 1e3) / 1e3;
    const who = speed >= 0.8 ? "a flyer" : speed >= 0.62 ? "a quick one" : "a plodder";
    const touch = touchLen <= 0.13 ? "close control" : touchLen <= 0.17 ? "tidy feet" : "heavy touches";
    return { speed, dir, lane, touchLen, touchPeriod, touchPhase, reach, label: `${who}, ${touch}` };
  });
}
function makeTackle(input, setup) {
  const t = input.press;
  const feet = tackleFeetAt(setup, t);
  const ball = tackleBallAt(setup, t);
  const loose = tackleTouchAt(setup, t);
  const base = { ballX: ball.x, ballY: ball.y, feetX: feet.x, feetY: feet.y, loose };
  if (t < 0 || t >= tackleDeadline(setup)) {
    return { ...base, won: false, foul: false, late: true, points: 0, verdict: "He is gone. Never got near him." };
  }
  const dBall = tackleDist(input.x, input.y, ball.x, ball.y);
  const dFeet = tackleDist(input.x, input.y, feet.x, feet.y);
  if (dFeet < TACKLE_FEET && dFeet <= dBall) {
    return { ...base, won: false, foul: true, late: false, points: 0, verdict: "You took the man. Free kick, and a word from the ref." };
  }
  if (dBall < setup.reach) {
    if (loose < TACKLE_LOOSE) {
      return { ...base, won: false, foul: true, late: false, points: 0, verdict: "Ball was at his feet. Straight through him, foul." };
    }
    const clean = 1 - dBall / setup.reach;
    const points = Math.round(80 + setup.speed * 100 + (0.22 - setup.touchLen) * 300 + loose * 40 + clean * 40);
    return { ...base, won: true, foul: false, late: false, points, verdict: loose > 0.85 ? "Ball won. He pushed it too far and you read it." : "Ball won. Clean." };
  }
  return { ...base, won: false, foul: false, late: false, points: 0, verdict: dBall < setup.reach * 2 ? "Swiped at it. He is past you." : "Nowhere near it. He is past you." };
}
function maxTackleScore(run) {
  return run.reduce((n, s) => n + Math.round(80 + s.speed * 100 + (0.22 - s.touchLen) * 300 + 40 + 40), 0);
}
function diveTime(reach) {
  return 0.16 + 0.62 * clamp(reach, 0, 1);
}
function diveVector(input) {
  const len = Math.hypot(input.dx, input.dy);
  if (len <= GLOVE_MAX_REACH) return { dx: input.dx, dy: input.dy, reach: len / GLOVE_MAX_REACH };
  const k = GLOVE_MAX_REACH / len;
  return { dx: input.dx * k, dy: input.dy * k, reach: 1 };
}
function gloveAt(input, t) {
  const v = diveVector(input);
  if (t <= input.release) return { ...GLOVE_ORIGIN };
  const p = clamp((t - input.release) / diveTime(v.reach), 0, 1);
  const e = p * (2 - p);
  return { x: GLOVE_ORIGIN.x + v.dx * e, y: GLOVE_ORIGIN.y + v.dy * e };
}
function gloveBallProgress(setup, t) {
  if (t < setup.shotAt) return -1;
  return clamp((t - setup.shotAt) / setup.flight, 0, 1);
}
function gloveDeadline(setup) {
  return setup.shotAt + setup.flight;
}
function buildGloveRun(seed) {
  return buildLadder(seed, ROUNDS_PER_RUN, (t, rng) => {
    const pace = clamp(0.2 + t * 0.8 + (rng() - 0.5) * 0.1, 0.1, 1);
    const flight = Math.round((0.85 - pace * 0.4) * 100) / 100;
    const lead = Math.round((0.5 - t * 0.25) * 100) / 100;
    const shotAt = Math.round((0.9 + rng() * 0.8) * 100) / 100;
    const side = rng() > 0.5 ? 1 : -1;
    const dist = clamp(1.2 + t * 1.5 + (rng() - 0.5) * 0.4, 1, GLOVE_MAX_REACH);
    const angle = (-20 + rng() * 80) * Math.PI / 180;
    const target = {
      x: Math.round(clamp(GLOVE_ORIGIN.x + side * dist * Math.cos(angle), -3.4, 3.4) * 100) / 100,
      y: Math.round(clamp(GLOVE_ORIGIN.y + dist * Math.sin(angle), 0.15, 2.3) * 100) / 100
    };
    const hit = pace >= 0.75 ? "leathered" : pace >= 0.45 ? "hit well" : "placed";
    const where = Math.abs(target.x) >= 2.4 ? "into the corner" : Math.abs(target.x) >= 1.4 ? "wide of you" : "close to you";
    return { shotAt, tellAt: Math.round((shotAt - lead) * 100) / 100, target, flight, pace: Math.round(pace * 100) / 100, label: `${hit}, ${where}` };
  });
}
function makeSave(input, setup) {
  const arrival = gloveDeadline(setup);
  const v = diveVector(input);
  const glove = gloveAt(input, arrival);
  const radius = Math.round((0.55 - setup.pace * 0.2) * 100) / 100;
  const late = input.release > arrival;
  const d = Math.hypot(glove.x - setup.target.x, glove.y - setup.target.y);
  const saved = !late && d < radius;
  const targetDist = Math.hypot(setup.target.x - GLOVE_ORIGIN.x, setup.target.y - GLOVE_ORIGIN.y);
  const points = saved ? Math.round(90 + targetDist / GLOVE_MAX_REACH * 130 + setup.pace * 80) : 0;
  const wrongWay = Math.sign(v.dx) !== 0 && Math.sign(v.dx) !== Math.sign(setup.target.x - GLOVE_ORIGIN.x) && Math.abs(setup.target.x) > 0.5;
  const verdict = late ? "Never moved. It was past you before you went." : saved ? v.reach > 0.75 ? "Full stretch. Kept it out." : v.reach > 0.3 ? "Got down to it. Saved." : "Straight at you. Gathered." : wrongWay ? "Wrong way. Nothing you could do once you went." : d < radius * 1.6 ? "Fingertips. Not enough on it." : "Nowhere near. In the net.";
  return { saved, late, reach: v.reach, points, gloveX: glove.x, gloveY: glove.y, radius, verdict };
}
function maxGloveScore(run) {
  return run.reduce((n, s) => {
    const targetDist = Math.hypot(s.target.x - GLOVE_ORIGIN.x, s.target.y - GLOVE_ORIGIN.y);
    return n + Math.round(90 + targetDist / GLOVE_MAX_REACH * 130 + s.pace * 80);
  }, 0);
}
function sessionScore(count3) {
  return clamp(Math.round(count3), 0, ROUNDS_PER_RUN) * 10;
}
function drillHeadroom(s) {
  return Math.max(0, effectivePotential(s) - s.overall);
}
function drillBoost(score, headroom) {
  const raw2 = score >= 80 ? 2 : score >= 50 ? 1 : 0;
  return Math.max(0, Math.min(raw2, Math.floor(headroom)));
}
var DRILL_META, KIND_SALT, WALL_SPRAY, WALL_UNSIGHTED, TACKLE_EDGE, TACKLE_ASPECT, tackleDist, TACKLE_LOOSE, TACKLE_FEET, GLOVE_MAX_REACH, GLOVE_ORIGIN, GLOVE_HALF_WIDTH, GLOVE_HEIGHT;
var init_careerDrills = __esm({
  "src/lib/careerDrills.ts"() {
    init_arcade();
    init_freeKick();
    init_soccerCareerEngine();
    init_momentsSave();
    DRILL_META = {
      wallshot: { name: "Wall Shot", stat: "shooting", statLabel: "Shooting", emoji: "\u{1F9F1}", verb: "scored", slug: "career-drill-wallshot" },
      tackle: { name: "Tackle", stat: "defending", statLabel: "Defending", emoji: "\u{1F9B5}", verb: "won", slug: "career-drill-tackle" },
      gloves: { name: "Glove Save", stat: "reflexes", statLabel: "Reflexes", emoji: "\u{1F9E4}", verb: "saved", slug: "career-drill-gloves" },
      firsttouch: { name: "First Touch", stat: "dribbling", statLabel: "Dribbling", emoji: "\u{1F45F}", verb: "controlled", slug: "career-drill-firsttouch" },
      throughball: { name: "Through Ball", stat: "passing", statLabel: "Passing", emoji: "\u{1F3AF}", verb: "completed", slug: "career-drill-throughball" }
    };
    KIND_SALT = { wallshot: 1719, tackle: 4583, gloves: 8317, firsttouch: 12011, throughball: 15887 };
    WALL_SPRAY = { power: 0.34, distance: 0.011, vertical: 0.7 };
    WALL_UNSIGHTED = 0.45;
    TACKLE_EDGE = 0.15;
    TACKLE_ASPECT = 7 / 12;
    tackleDist = (ax, ay, bx, by) => Math.hypot(ax - bx, (ay - by) * TACKLE_ASPECT);
    TACKLE_LOOSE = 0.35;
    TACKLE_FEET = 0.06;
    GLOVE_MAX_REACH = 2.8;
    GLOVE_ORIGIN = { x: 0, y: 1 };
    GLOVE_HALF_WIDTH = 3.66;
    GLOVE_HEIGHT = 2.44;
  }
});

// src/lib/firstTouchDrill.ts
function validateFirstTouchRecord(fields) {
  const { rounds, count: count3, score, banked } = fields;
  if (!Number.isInteger(rounds) || !Number.isInteger(count3) || !Number.isInteger(score) || typeof banked !== "boolean") return null;
  const record = { rounds, count: count3, score, banked };
  if (record.rounds < 0 || record.rounds > ROUNDS_PER_RUN || record.count < 0 || record.count > record.rounds || record.score !== record.count * 10 || record.banked && record.rounds !== ROUNDS_PER_RUN) return null;
  return record;
}
var init_firstTouchDrill = __esm({
  "src/lib/firstTouchDrill.ts"() {
    init_arcade();
  }
});

// src/lib/throughBallDrill.ts
function runTime(setup) {
  return (setup.start.y - KEEPER_Y) / -setup.vel.y;
}
function runnerAt(setup, seconds) {
  const s = clamp(seconds - setup.hold, 0, runTime(setup));
  return { x: setup.start.x + setup.vel.x * s, y: setup.start.y + setup.vel.y * s };
}
function crossTime(setup) {
  return setup.hold + (setup.start.y - setup.line) / -setup.vel.y;
}
function throughBallDeadline(setup) {
  return crossTime(setup) + 0.4;
}
function passTarget(angle, weight) {
  const a = clamp(angle, -MAX_ANGLE, MAX_ANGLE) * RAD;
  const dist = clamp(weight, 0, 1) * MAX_PASS;
  return { x: PASSER.x + Math.sin(a) * dist, y: PASSER.y - Math.cos(a) * dist };
}
function aimFor(point) {
  const dx = point.x - PASSER.x;
  const dy = PASSER.y - point.y;
  return {
    angle: clamp(Math.atan2(dx, dy) / RAD, -MAX_ANGLE, MAX_ANGLE),
    weight: clamp(Math.hypot(dx, dy) / MAX_PASS, 0, 1)
  };
}
function lineCrossX(target, line) {
  if (target.y >= line) return null;
  return PASSER.x + (target.x - PASSER.x) * (PASSER.y - line) / (PASSER.y - target.y);
}
function collectWindow(setup, spot, from) {
  const dx = setup.start.x - spot.x;
  const dy = setup.start.y - spot.y;
  const vv = setup.vel.x * setup.vel.x + setup.vel.y * setup.vel.y;
  const dv = dx * setup.vel.x + dy * setup.vel.y;
  const disc = dv * dv - vv * (dx * dx + dy * dy - setup.reach * setup.reach);
  if (disc < 0 || vv === 0) return null;
  const root = Math.sqrt(disc);
  const lo = Math.max(from, setup.hold + Math.max(0, (-dv - root) / vv));
  const hi = setup.hold + Math.min(runTime(setup), (-dv + root) / vv);
  return lo <= hi ? [lo, hi] : null;
}
function takeThroughBall(input, setup) {
  const press = Number.isFinite(input.press) ? Math.max(0, input.press) : Infinity;
  const target = passTarget(input.angle, input.weight);
  const arrival = press + Math.hypot(target.x - PASSER.x, target.y - PASSER.y) / BALL_SPEED;
  const crossX = lineCrossX(target, setup.line);
  const settle = (outcome, taken = null) => ({
    won: outcome === "through",
    points: outcome === "through" ? 10 : 0,
    outcome,
    verdict: outcome === "offside" && press >= throughBallDeadline(setup) ? HELD_VERDICT : VERDICTS[outcome],
    target,
    line: setup.line,
    crossX,
    press,
    arrival,
    taken
  });
  if (!(press <= crossTime(setup))) return settle("offside");
  if (crossX !== null && onPitch(crossX) && setup.defenders.some((x) => Math.abs(x - crossX) < BLOCK)) return settle("cutout");
  if (!onPitch(target.x)) return settle("out");
  if (crossX === null) return settle("short");
  if (target.y <= KEEPER_Y) return settle("keeper");
  const window2 = collectWindow(setup, target, press);
  if (!window2) return settle("wide");
  if (window2[1] < arrival - LATE_SLACK) return settle("behind");
  if (window2[0] > arrival + setup.wait) return settle("early");
  return settle("through", clamp(arrival, window2[0], window2[1]));
}
function meetingPoint(setup, press, lead = LEAD_IDEAL) {
  const gap = (t) => {
    const at = runnerAt(setup, t);
    return t - lead - press - Math.hypot(at.x - PASSER.x, at.y - PASSER.y) / BALL_SPEED;
  };
  let lo = press;
  let hi = press + 8;
  for (let i = 0; i < 60; i += 1) {
    const mid = (lo + hi) / 2;
    if (gap(mid) < 0) lo = mid;
    else hi = mid;
  }
  return runnerAt(setup, (lo + hi) / 2);
}
function buildThroughBallRun(seed) {
  return buildLadder(seed, ROUNDS_PER_RUN, (t, rng) => {
    const line = rounded(104 + rng() * 32);
    const side = rng() < 0.5 ? 1 : -1;
    const start = { x: rounded(side === 1 ? 50 + rng() * 70 : 240 + rng() * 70), y: rounded(line + 52 + rng() * 14) };
    const endX = clamp(start.x + side * (70 + 60 * t) * (0.7 + 0.3 * rng()), 50, 310);
    const speed = 40 + 22 * t + rng() * 6;
    const len = Math.hypot(endX - start.x, 60 - start.y);
    const vel = { x: rounded(speed * (endX - start.x) / len), y: rounded(speed * (60 - start.y) / len) };
    const hold = rounded(0.5 + rng() * 0.7);
    const partial = { line, start, vel, hold, defenders: [], wait: rounded(0.3 - 0.15 * t), reach: rounded(12 - 4 * t), cue: 0 };
    partial.cue = rounded(crossTime(partial) - 0.2);
    const ideal = lineCrossX(meetingPoint(partial, partial.cue), line) ?? PASSER.x;
    const half = 30 - 14 * t + rng() * 4;
    const left = half * (0.6 + rng() * 0.8);
    const right = 2 * half - left;
    const inner = [ideal - left - BLOCK, ideal + right + BLOCK];
    const outer = [inner[0] - (64 + rng() * 20), inner[1] + (64 + rng() * 20)];
    const defenders = [outer[0], inner[0], inner[1], outer[1]].filter((x) => x >= PITCH_LEFT + 6 && x <= PITCH_RIGHT - 6).map(rounded);
    return { ...partial, defenders };
  });
}
function ballAt(result, seconds) {
  const end = result.outcome === "cutout" && result.crossX !== null ? { x: result.crossX, y: result.line } : result.target;
  const whole = Math.hypot(result.target.x - PASSER.x, result.target.y - PASSER.y);
  const part = Math.hypot(end.x - PASSER.x, end.y - PASSER.y);
  const span = Math.max(1e-3, (result.arrival - result.press) * (whole > 0 ? part / whole : 0));
  const p = Number.isFinite(result.press) ? clamp((seconds - result.press) / span, 0, 1) : 1;
  return { x: PASSER.x + (end.x - PASSER.x) * p, y: PASSER.y + (end.y - PASSER.y) * p };
}
function replayEnd(result) {
  return Number.isFinite(result.press) ? Math.max(result.arrival, result.taken ?? result.arrival) : 0;
}
var PASSER, KEEPER_Y, PITCH_LEFT, PITCH_RIGHT, MAX_PASS, BALL_SPEED, BLOCK, LATE_SLACK, LEAD_IDEAL, MAX_ANGLE, validateThroughBallRecord, rounded, RAD, VERDICTS, HELD_VERDICT, onPitch;
var init_throughBallDrill = __esm({
  "src/lib/throughBallDrill.ts"() {
    init_arcade();
    init_firstTouchDrill();
    PASSER = { x: 180, y: 222 };
    KEEPER_Y = 36;
    PITCH_LEFT = 18;
    PITCH_RIGHT = 342;
    MAX_PASS = 240;
    BALL_SPEED = 190;
    BLOCK = 11;
    LATE_SLACK = 0.08;
    LEAD_IDEAL = 0.15;
    MAX_ANGLE = 75;
    validateThroughBallRecord = validateFirstTouchRecord;
    rounded = (value) => Math.round(value * 1e3) / 1e3;
    RAD = Math.PI / 180;
    VERDICTS = {
      through: "Through. He is in on goal.",
      offside: "Offside. He was past the line when you played it.",
      short: "Underhit. It never got past the line.",
      cutout: "Cut out. Straight at a defender.",
      out: "Out of play. It ran off the side of the pitch.",
      keeper: "Overhit. It ran through to the keeper.",
      wide: "Wide of his run. He could not reach it.",
      behind: "Behind him. He was already past that spot.",
      early: "Too early. A defender got back to it first."
    };
    HELD_VERDICT = "Offside. You held it too long and he ran past the line.";
    onPitch = (x) => x >= PITCH_LEFT && x <= PITCH_RIGHT;
  }
});

// node_modules/react/cjs/react-jsx-runtime.production.min.js
var require_react_jsx_runtime_production_min = __commonJS({
  "node_modules/react/cjs/react-jsx-runtime.production.min.js"(exports) {
    "use strict";
    var f = require_react();
    var k = Symbol.for("react.element");
    var l = Symbol.for("react.fragment");
    var m = Object.prototype.hasOwnProperty;
    var n = f.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner;
    var p = { key: true, ref: true, __self: true, __source: true };
    function q(c, a, g) {
      var b, d = {}, e = null, h = null;
      void 0 !== g && (e = "" + g);
      void 0 !== a.key && (e = "" + a.key);
      void 0 !== a.ref && (h = a.ref);
      for (b in a) m.call(a, b) && !p.hasOwnProperty(b) && (d[b] = a[b]);
      if (c && c.defaultProps) for (b in a = c.defaultProps, a) void 0 === d[b] && (d[b] = a[b]);
      return { $$typeof: k, type: c, key: e, ref: h, props: d, _owner: n.current };
    }
    exports.Fragment = l;
    exports.jsx = q;
    exports.jsxs = q;
  }
});

// node_modules/react/jsx-runtime.js
var require_jsx_runtime = __commonJS({
  "node_modules/react/jsx-runtime.js"(exports, module) {
    "use strict";
    if (true) {
      module.exports = require_react_jsx_runtime_production_min();
    } else {
      module.exports = null;
    }
  }
});

// node_modules/@radix-ui/react-compose-refs/dist/index.mjs
function setRef(ref, value) {
  if (typeof ref === "function") {
    return ref(value);
  } else if (ref !== null && ref !== void 0) {
    ref.current = value;
  }
}
function composeRefs(...refs) {
  return (node) => {
    let hasCleanup = false;
    const cleanups = refs.map((ref) => {
      const cleanup = setRef(ref, node);
      if (!hasCleanup && typeof cleanup == "function") {
        hasCleanup = true;
      }
      return cleanup;
    });
    if (hasCleanup) {
      return () => {
        for (let i = 0; i < cleanups.length; i++) {
          const cleanup = cleanups[i];
          if (typeof cleanup == "function") {
            cleanup();
          } else {
            setRef(refs[i], null);
          }
        }
      };
    }
  };
}
function useComposedRefs(...refs) {
  return React.useCallback(composeRefs(...refs), refs);
}
var React;
var init_dist = __esm({
  "node_modules/@radix-ui/react-compose-refs/dist/index.mjs"() {
    React = __toESM(require_react(), 1);
  }
});

// node_modules/@radix-ui/react-slot/dist/index.mjs
// @__NO_SIDE_EFFECTS__
function createSlot(ownerName) {
  const SlotClone = /* @__PURE__ */ createSlotClone(ownerName);
  const Slot22 = React2.forwardRef((props, forwardedRef) => {
    const { children, ...slotProps } = props;
    const childrenArray = React2.Children.toArray(children);
    const slottable = childrenArray.find(isSlottable);
    if (slottable) {
      const newElement = slottable.props.children;
      const newChildren = childrenArray.map((child) => {
        if (child === slottable) {
          if (React2.Children.count(newElement) > 1) return React2.Children.only(null);
          return React2.isValidElement(newElement) ? newElement.props.children : null;
        } else {
          return child;
        }
      });
      return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlotClone, { ...slotProps, ref: forwardedRef, children: React2.isValidElement(newElement) ? React2.cloneElement(newElement, void 0, newChildren) : null });
    }
    return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlotClone, { ...slotProps, ref: forwardedRef, children });
  });
  Slot22.displayName = `${ownerName}.Slot`;
  return Slot22;
}
// @__NO_SIDE_EFFECTS__
function createSlotClone(ownerName) {
  const SlotClone = React2.forwardRef((props, forwardedRef) => {
    const { children, ...slotProps } = props;
    if (React2.isValidElement(children)) {
      const childrenRef = getElementRef(children);
      const props2 = mergeProps(slotProps, children.props);
      if (children.type !== React2.Fragment) {
        props2.ref = forwardedRef ? composeRefs(forwardedRef, childrenRef) : childrenRef;
      }
      return React2.cloneElement(children, props2);
    }
    return React2.Children.count(children) > 1 ? React2.Children.only(null) : null;
  });
  SlotClone.displayName = `${ownerName}.SlotClone`;
  return SlotClone;
}
function isSlottable(child) {
  return React2.isValidElement(child) && typeof child.type === "function" && "__radixId" in child.type && child.type.__radixId === SLOTTABLE_IDENTIFIER;
}
function mergeProps(slotProps, childProps) {
  const overrideProps = { ...childProps };
  for (const propName in childProps) {
    const slotPropValue = slotProps[propName];
    const childPropValue = childProps[propName];
    const isHandler = /^on[A-Z]/.test(propName);
    if (isHandler) {
      if (slotPropValue && childPropValue) {
        overrideProps[propName] = (...args) => {
          const result = childPropValue(...args);
          slotPropValue(...args);
          return result;
        };
      } else if (slotPropValue) {
        overrideProps[propName] = slotPropValue;
      }
    } else if (propName === "style") {
      overrideProps[propName] = { ...slotPropValue, ...childPropValue };
    } else if (propName === "className") {
      overrideProps[propName] = [slotPropValue, childPropValue].filter(Boolean).join(" ");
    }
  }
  return { ...slotProps, ...overrideProps };
}
function getElementRef(element) {
  let getter = Object.getOwnPropertyDescriptor(element.props, "ref")?.get;
  let mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
  if (mayWarn) {
    return element.ref;
  }
  getter = Object.getOwnPropertyDescriptor(element, "ref")?.get;
  mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
  if (mayWarn) {
    return element.props.ref;
  }
  return element.props.ref || element.ref;
}
var React2, import_jsx_runtime, Slot, SLOTTABLE_IDENTIFIER;
var init_dist2 = __esm({
  "node_modules/@radix-ui/react-slot/dist/index.mjs"() {
    React2 = __toESM(require_react(), 1);
    init_dist();
    import_jsx_runtime = __toESM(require_jsx_runtime(), 1);
    Slot = /* @__PURE__ */ createSlot("Slot");
    SLOTTABLE_IDENTIFIER = Symbol("radix.slottable");
  }
});

// node_modules/clsx/dist/clsx.mjs
function r(e) {
  var t, f, n = "";
  if ("string" == typeof e || "number" == typeof e) n += e;
  else if ("object" == typeof e) if (Array.isArray(e)) {
    var o = e.length;
    for (t = 0; t < o; t++) e[t] && (f = r(e[t])) && (n && (n += " "), n += f);
  } else for (f in e) e[f] && (n && (n += " "), n += f);
  return n;
}
function clsx() {
  for (var e, t, f = 0, n = "", o = arguments.length; f < o; f++) (e = arguments[f]) && (t = r(e)) && (n && (n += " "), n += t);
  return n;
}
var init_clsx = __esm({
  "node_modules/clsx/dist/clsx.mjs"() {
  }
});

// node_modules/class-variance-authority/dist/index.mjs
var falsyToString, cx, cva;
var init_dist3 = __esm({
  "node_modules/class-variance-authority/dist/index.mjs"() {
    init_clsx();
    falsyToString = (value) => typeof value === "boolean" ? `${value}` : value === 0 ? "0" : value;
    cx = clsx;
    cva = (base, config) => (props) => {
      var _config_compoundVariants;
      if ((config === null || config === void 0 ? void 0 : config.variants) == null) return cx(base, props === null || props === void 0 ? void 0 : props.class, props === null || props === void 0 ? void 0 : props.className);
      const { variants, defaultVariants } = config;
      const getVariantClassNames = Object.keys(variants).map((variant) => {
        const variantProp = props === null || props === void 0 ? void 0 : props[variant];
        const defaultVariantProp = defaultVariants === null || defaultVariants === void 0 ? void 0 : defaultVariants[variant];
        if (variantProp === null) return null;
        const variantKey = falsyToString(variantProp) || falsyToString(defaultVariantProp);
        return variants[variant][variantKey];
      });
      const propsWithoutUndefined = props && Object.entries(props).reduce((acc, param) => {
        let [key, value] = param;
        if (value === void 0) {
          return acc;
        }
        acc[key] = value;
        return acc;
      }, {});
      const getCompoundVariantClassNames = config === null || config === void 0 ? void 0 : (_config_compoundVariants = config.compoundVariants) === null || _config_compoundVariants === void 0 ? void 0 : _config_compoundVariants.reduce((acc, param) => {
        let { class: cvClass, className: cvClassName, ...compoundVariantOptions } = param;
        return Object.entries(compoundVariantOptions).every((param2) => {
          let [key, value] = param2;
          return Array.isArray(value) ? value.includes({
            ...defaultVariants,
            ...propsWithoutUndefined
          }[key]) : {
            ...defaultVariants,
            ...propsWithoutUndefined
          }[key] === value;
        }) ? [
          ...acc,
          cvClass,
          cvClassName
        ] : acc;
      }, []);
      return cx(base, getVariantClassNames, getCompoundVariantClassNames, props === null || props === void 0 ? void 0 : props.class, props === null || props === void 0 ? void 0 : props.className);
    };
  }
});

// node_modules/tailwind-merge/dist/bundle-mjs.mjs
function twJoin() {
  let index = 0;
  let argument;
  let resolvedValue;
  let string = "";
  while (index < arguments.length) {
    if (argument = arguments[index++]) {
      if (resolvedValue = toValue(argument)) {
        string && (string += " ");
        string += resolvedValue;
      }
    }
  }
  return string;
}
function createTailwindMerge(createConfigFirst, ...createConfigRest) {
  let configUtils;
  let cacheGet;
  let cacheSet;
  let functionToCall = initTailwindMerge;
  function initTailwindMerge(classList) {
    const config = createConfigRest.reduce((previousConfig, createConfigCurrent) => createConfigCurrent(previousConfig), createConfigFirst());
    configUtils = createConfigUtils(config);
    cacheGet = configUtils.cache.get;
    cacheSet = configUtils.cache.set;
    functionToCall = tailwindMerge;
    return tailwindMerge(classList);
  }
  function tailwindMerge(classList) {
    const cachedResult = cacheGet(classList);
    if (cachedResult) {
      return cachedResult;
    }
    const result = mergeClassList(classList, configUtils);
    cacheSet(classList, result);
    return result;
  }
  return function callTailwindMerge() {
    return functionToCall(twJoin.apply(null, arguments));
  };
}
var CLASS_PART_SEPARATOR, createClassGroupUtils, getGroupRecursive, arbitraryPropertyRegex, getGroupIdForArbitraryProperty, createClassMap, processClassesRecursively, getPart, isThemeGetter, getPrefixedClassGroupEntries, createLruCache, IMPORTANT_MODIFIER, createParseClassName, sortModifiers, createConfigUtils, SPLIT_CLASSES_REGEX, mergeClassList, toValue, fromTheme, arbitraryValueRegex, fractionRegex, stringLengths, tshirtUnitRegex, lengthUnitRegex, colorFunctionRegex, shadowRegex, imageRegex, isLength, isArbitraryLength, isNumber, isArbitraryNumber, isInteger, isPercent, isArbitraryValue, isTshirtSize, sizeLabels, isArbitrarySize, isArbitraryPosition, imageLabels, isArbitraryImage, isArbitraryShadow, isAny, getIsArbitraryValue, isLengthOnly, isNever, isShadow, isImage, getDefaultConfig, twMerge;
var init_bundle_mjs = __esm({
  "node_modules/tailwind-merge/dist/bundle-mjs.mjs"() {
    CLASS_PART_SEPARATOR = "-";
    createClassGroupUtils = (config) => {
      const classMap = createClassMap(config);
      const {
        conflictingClassGroups,
        conflictingClassGroupModifiers
      } = config;
      const getClassGroupId = (className) => {
        const classParts = className.split(CLASS_PART_SEPARATOR);
        if (classParts[0] === "" && classParts.length !== 1) {
          classParts.shift();
        }
        return getGroupRecursive(classParts, classMap) || getGroupIdForArbitraryProperty(className);
      };
      const getConflictingClassGroupIds = (classGroupId, hasPostfixModifier) => {
        const conflicts = conflictingClassGroups[classGroupId] || [];
        if (hasPostfixModifier && conflictingClassGroupModifiers[classGroupId]) {
          return [...conflicts, ...conflictingClassGroupModifiers[classGroupId]];
        }
        return conflicts;
      };
      return {
        getClassGroupId,
        getConflictingClassGroupIds
      };
    };
    getGroupRecursive = (classParts, classPartObject) => {
      if (classParts.length === 0) {
        return classPartObject.classGroupId;
      }
      const currentClassPart = classParts[0];
      const nextClassPartObject = classPartObject.nextPart.get(currentClassPart);
      const classGroupFromNextClassPart = nextClassPartObject ? getGroupRecursive(classParts.slice(1), nextClassPartObject) : void 0;
      if (classGroupFromNextClassPart) {
        return classGroupFromNextClassPart;
      }
      if (classPartObject.validators.length === 0) {
        return void 0;
      }
      const classRest = classParts.join(CLASS_PART_SEPARATOR);
      return classPartObject.validators.find(({
        validator
      }) => validator(classRest))?.classGroupId;
    };
    arbitraryPropertyRegex = /^\[(.+)\]$/;
    getGroupIdForArbitraryProperty = (className) => {
      if (arbitraryPropertyRegex.test(className)) {
        const arbitraryPropertyClassName = arbitraryPropertyRegex.exec(className)[1];
        const property = arbitraryPropertyClassName?.substring(0, arbitraryPropertyClassName.indexOf(":"));
        if (property) {
          return "arbitrary.." + property;
        }
      }
    };
    createClassMap = (config) => {
      const {
        theme,
        prefix
      } = config;
      const classMap = {
        nextPart: /* @__PURE__ */ new Map(),
        validators: []
      };
      const prefixedClassGroupEntries = getPrefixedClassGroupEntries(Object.entries(config.classGroups), prefix);
      prefixedClassGroupEntries.forEach(([classGroupId, classGroup]) => {
        processClassesRecursively(classGroup, classMap, classGroupId, theme);
      });
      return classMap;
    };
    processClassesRecursively = (classGroup, classPartObject, classGroupId, theme) => {
      classGroup.forEach((classDefinition) => {
        if (typeof classDefinition === "string") {
          const classPartObjectToEdit = classDefinition === "" ? classPartObject : getPart(classPartObject, classDefinition);
          classPartObjectToEdit.classGroupId = classGroupId;
          return;
        }
        if (typeof classDefinition === "function") {
          if (isThemeGetter(classDefinition)) {
            processClassesRecursively(classDefinition(theme), classPartObject, classGroupId, theme);
            return;
          }
          classPartObject.validators.push({
            validator: classDefinition,
            classGroupId
          });
          return;
        }
        Object.entries(classDefinition).forEach(([key, classGroup2]) => {
          processClassesRecursively(classGroup2, getPart(classPartObject, key), classGroupId, theme);
        });
      });
    };
    getPart = (classPartObject, path) => {
      let currentClassPartObject = classPartObject;
      path.split(CLASS_PART_SEPARATOR).forEach((pathPart) => {
        if (!currentClassPartObject.nextPart.has(pathPart)) {
          currentClassPartObject.nextPart.set(pathPart, {
            nextPart: /* @__PURE__ */ new Map(),
            validators: []
          });
        }
        currentClassPartObject = currentClassPartObject.nextPart.get(pathPart);
      });
      return currentClassPartObject;
    };
    isThemeGetter = (func) => func.isThemeGetter;
    getPrefixedClassGroupEntries = (classGroupEntries, prefix) => {
      if (!prefix) {
        return classGroupEntries;
      }
      return classGroupEntries.map(([classGroupId, classGroup]) => {
        const prefixedClassGroup = classGroup.map((classDefinition) => {
          if (typeof classDefinition === "string") {
            return prefix + classDefinition;
          }
          if (typeof classDefinition === "object") {
            return Object.fromEntries(Object.entries(classDefinition).map(([key, value]) => [prefix + key, value]));
          }
          return classDefinition;
        });
        return [classGroupId, prefixedClassGroup];
      });
    };
    createLruCache = (maxCacheSize) => {
      if (maxCacheSize < 1) {
        return {
          get: () => void 0,
          set: () => {
          }
        };
      }
      let cacheSize = 0;
      let cache = /* @__PURE__ */ new Map();
      let previousCache = /* @__PURE__ */ new Map();
      const update = (key, value) => {
        cache.set(key, value);
        cacheSize++;
        if (cacheSize > maxCacheSize) {
          cacheSize = 0;
          previousCache = cache;
          cache = /* @__PURE__ */ new Map();
        }
      };
      return {
        get(key) {
          let value = cache.get(key);
          if (value !== void 0) {
            return value;
          }
          if ((value = previousCache.get(key)) !== void 0) {
            update(key, value);
            return value;
          }
        },
        set(key, value) {
          if (cache.has(key)) {
            cache.set(key, value);
          } else {
            update(key, value);
          }
        }
      };
    };
    IMPORTANT_MODIFIER = "!";
    createParseClassName = (config) => {
      const {
        separator,
        experimentalParseClassName
      } = config;
      const isSeparatorSingleCharacter = separator.length === 1;
      const firstSeparatorCharacter = separator[0];
      const separatorLength = separator.length;
      const parseClassName = (className) => {
        const modifiers = [];
        let bracketDepth = 0;
        let modifierStart = 0;
        let postfixModifierPosition;
        for (let index = 0; index < className.length; index++) {
          let currentCharacter = className[index];
          if (bracketDepth === 0) {
            if (currentCharacter === firstSeparatorCharacter && (isSeparatorSingleCharacter || className.slice(index, index + separatorLength) === separator)) {
              modifiers.push(className.slice(modifierStart, index));
              modifierStart = index + separatorLength;
              continue;
            }
            if (currentCharacter === "/") {
              postfixModifierPosition = index;
              continue;
            }
          }
          if (currentCharacter === "[") {
            bracketDepth++;
          } else if (currentCharacter === "]") {
            bracketDepth--;
          }
        }
        const baseClassNameWithImportantModifier = modifiers.length === 0 ? className : className.substring(modifierStart);
        const hasImportantModifier = baseClassNameWithImportantModifier.startsWith(IMPORTANT_MODIFIER);
        const baseClassName = hasImportantModifier ? baseClassNameWithImportantModifier.substring(1) : baseClassNameWithImportantModifier;
        const maybePostfixModifierPosition = postfixModifierPosition && postfixModifierPosition > modifierStart ? postfixModifierPosition - modifierStart : void 0;
        return {
          modifiers,
          hasImportantModifier,
          baseClassName,
          maybePostfixModifierPosition
        };
      };
      if (experimentalParseClassName) {
        return (className) => experimentalParseClassName({
          className,
          parseClassName
        });
      }
      return parseClassName;
    };
    sortModifiers = (modifiers) => {
      if (modifiers.length <= 1) {
        return modifiers;
      }
      const sortedModifiers = [];
      let unsortedModifiers = [];
      modifiers.forEach((modifier) => {
        const isArbitraryVariant = modifier[0] === "[";
        if (isArbitraryVariant) {
          sortedModifiers.push(...unsortedModifiers.sort(), modifier);
          unsortedModifiers = [];
        } else {
          unsortedModifiers.push(modifier);
        }
      });
      sortedModifiers.push(...unsortedModifiers.sort());
      return sortedModifiers;
    };
    createConfigUtils = (config) => ({
      cache: createLruCache(config.cacheSize),
      parseClassName: createParseClassName(config),
      ...createClassGroupUtils(config)
    });
    SPLIT_CLASSES_REGEX = /\s+/;
    mergeClassList = (classList, configUtils) => {
      const {
        parseClassName,
        getClassGroupId,
        getConflictingClassGroupIds
      } = configUtils;
      const classGroupsInConflict = [];
      const classNames = classList.trim().split(SPLIT_CLASSES_REGEX);
      let result = "";
      for (let index = classNames.length - 1; index >= 0; index -= 1) {
        const originalClassName = classNames[index];
        const {
          modifiers,
          hasImportantModifier,
          baseClassName,
          maybePostfixModifierPosition
        } = parseClassName(originalClassName);
        let hasPostfixModifier = Boolean(maybePostfixModifierPosition);
        let classGroupId = getClassGroupId(hasPostfixModifier ? baseClassName.substring(0, maybePostfixModifierPosition) : baseClassName);
        if (!classGroupId) {
          if (!hasPostfixModifier) {
            result = originalClassName + (result.length > 0 ? " " + result : result);
            continue;
          }
          classGroupId = getClassGroupId(baseClassName);
          if (!classGroupId) {
            result = originalClassName + (result.length > 0 ? " " + result : result);
            continue;
          }
          hasPostfixModifier = false;
        }
        const variantModifier = sortModifiers(modifiers).join(":");
        const modifierId = hasImportantModifier ? variantModifier + IMPORTANT_MODIFIER : variantModifier;
        const classId = modifierId + classGroupId;
        if (classGroupsInConflict.includes(classId)) {
          continue;
        }
        classGroupsInConflict.push(classId);
        const conflictGroups = getConflictingClassGroupIds(classGroupId, hasPostfixModifier);
        for (let i = 0; i < conflictGroups.length; ++i) {
          const group = conflictGroups[i];
          classGroupsInConflict.push(modifierId + group);
        }
        result = originalClassName + (result.length > 0 ? " " + result : result);
      }
      return result;
    };
    toValue = (mix) => {
      if (typeof mix === "string") {
        return mix;
      }
      let resolvedValue;
      let string = "";
      for (let k = 0; k < mix.length; k++) {
        if (mix[k]) {
          if (resolvedValue = toValue(mix[k])) {
            string && (string += " ");
            string += resolvedValue;
          }
        }
      }
      return string;
    };
    fromTheme = (key) => {
      const themeGetter = (theme) => theme[key] || [];
      themeGetter.isThemeGetter = true;
      return themeGetter;
    };
    arbitraryValueRegex = /^\[(?:([a-z-]+):)?(.+)\]$/i;
    fractionRegex = /^\d+\/\d+$/;
    stringLengths = /* @__PURE__ */ new Set(["px", "full", "screen"]);
    tshirtUnitRegex = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/;
    lengthUnitRegex = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/;
    colorFunctionRegex = /^(rgba?|hsla?|hwb|(ok)?(lab|lch))\(.+\)$/;
    shadowRegex = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/;
    imageRegex = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/;
    isLength = (value) => isNumber(value) || stringLengths.has(value) || fractionRegex.test(value);
    isArbitraryLength = (value) => getIsArbitraryValue(value, "length", isLengthOnly);
    isNumber = (value) => Boolean(value) && !Number.isNaN(Number(value));
    isArbitraryNumber = (value) => getIsArbitraryValue(value, "number", isNumber);
    isInteger = (value) => Boolean(value) && Number.isInteger(Number(value));
    isPercent = (value) => value.endsWith("%") && isNumber(value.slice(0, -1));
    isArbitraryValue = (value) => arbitraryValueRegex.test(value);
    isTshirtSize = (value) => tshirtUnitRegex.test(value);
    sizeLabels = /* @__PURE__ */ new Set(["length", "size", "percentage"]);
    isArbitrarySize = (value) => getIsArbitraryValue(value, sizeLabels, isNever);
    isArbitraryPosition = (value) => getIsArbitraryValue(value, "position", isNever);
    imageLabels = /* @__PURE__ */ new Set(["image", "url"]);
    isArbitraryImage = (value) => getIsArbitraryValue(value, imageLabels, isImage);
    isArbitraryShadow = (value) => getIsArbitraryValue(value, "", isShadow);
    isAny = () => true;
    getIsArbitraryValue = (value, label, testValue) => {
      const result = arbitraryValueRegex.exec(value);
      if (result) {
        if (result[1]) {
          return typeof label === "string" ? result[1] === label : label.has(result[1]);
        }
        return testValue(result[2]);
      }
      return false;
    };
    isLengthOnly = (value) => (
      // `colorFunctionRegex` check is necessary because color functions can have percentages in them which which would be incorrectly classified as lengths.
      // For example, `hsl(0 0% 0%)` would be classified as a length without this check.
      // I could also use lookbehind assertion in `lengthUnitRegex` but that isn't supported widely enough.
      lengthUnitRegex.test(value) && !colorFunctionRegex.test(value)
    );
    isNever = () => false;
    isShadow = (value) => shadowRegex.test(value);
    isImage = (value) => imageRegex.test(value);
    getDefaultConfig = () => {
      const colors = fromTheme("colors");
      const spacing = fromTheme("spacing");
      const blur = fromTheme("blur");
      const brightness = fromTheme("brightness");
      const borderColor = fromTheme("borderColor");
      const borderRadius = fromTheme("borderRadius");
      const borderSpacing = fromTheme("borderSpacing");
      const borderWidth = fromTheme("borderWidth");
      const contrast = fromTheme("contrast");
      const grayscale = fromTheme("grayscale");
      const hueRotate = fromTheme("hueRotate");
      const invert = fromTheme("invert");
      const gap = fromTheme("gap");
      const gradientColorStops = fromTheme("gradientColorStops");
      const gradientColorStopPositions = fromTheme("gradientColorStopPositions");
      const inset = fromTheme("inset");
      const margin = fromTheme("margin");
      const opacity = fromTheme("opacity");
      const padding = fromTheme("padding");
      const saturate = fromTheme("saturate");
      const scale = fromTheme("scale");
      const sepia = fromTheme("sepia");
      const skew = fromTheme("skew");
      const space = fromTheme("space");
      const translate = fromTheme("translate");
      const getOverscroll = () => ["auto", "contain", "none"];
      const getOverflow = () => ["auto", "hidden", "clip", "visible", "scroll"];
      const getSpacingWithAutoAndArbitrary = () => ["auto", isArbitraryValue, spacing];
      const getSpacingWithArbitrary = () => [isArbitraryValue, spacing];
      const getLengthWithEmptyAndArbitrary = () => ["", isLength, isArbitraryLength];
      const getNumberWithAutoAndArbitrary = () => ["auto", isNumber, isArbitraryValue];
      const getPositions = () => ["bottom", "center", "left", "left-bottom", "left-top", "right", "right-bottom", "right-top", "top"];
      const getLineStyles = () => ["solid", "dashed", "dotted", "double", "none"];
      const getBlendModes = () => ["normal", "multiply", "screen", "overlay", "darken", "lighten", "color-dodge", "color-burn", "hard-light", "soft-light", "difference", "exclusion", "hue", "saturation", "color", "luminosity"];
      const getAlign = () => ["start", "end", "center", "between", "around", "evenly", "stretch"];
      const getZeroAndEmpty = () => ["", "0", isArbitraryValue];
      const getBreaks = () => ["auto", "avoid", "all", "avoid-page", "page", "left", "right", "column"];
      const getNumberAndArbitrary = () => [isNumber, isArbitraryValue];
      return {
        cacheSize: 500,
        separator: ":",
        theme: {
          colors: [isAny],
          spacing: [isLength, isArbitraryLength],
          blur: ["none", "", isTshirtSize, isArbitraryValue],
          brightness: getNumberAndArbitrary(),
          borderColor: [colors],
          borderRadius: ["none", "", "full", isTshirtSize, isArbitraryValue],
          borderSpacing: getSpacingWithArbitrary(),
          borderWidth: getLengthWithEmptyAndArbitrary(),
          contrast: getNumberAndArbitrary(),
          grayscale: getZeroAndEmpty(),
          hueRotate: getNumberAndArbitrary(),
          invert: getZeroAndEmpty(),
          gap: getSpacingWithArbitrary(),
          gradientColorStops: [colors],
          gradientColorStopPositions: [isPercent, isArbitraryLength],
          inset: getSpacingWithAutoAndArbitrary(),
          margin: getSpacingWithAutoAndArbitrary(),
          opacity: getNumberAndArbitrary(),
          padding: getSpacingWithArbitrary(),
          saturate: getNumberAndArbitrary(),
          scale: getNumberAndArbitrary(),
          sepia: getZeroAndEmpty(),
          skew: getNumberAndArbitrary(),
          space: getSpacingWithArbitrary(),
          translate: getSpacingWithArbitrary()
        },
        classGroups: {
          // Layout
          /**
           * Aspect Ratio
           * @see https://tailwindcss.com/docs/aspect-ratio
           */
          aspect: [{
            aspect: ["auto", "square", "video", isArbitraryValue]
          }],
          /**
           * Container
           * @see https://tailwindcss.com/docs/container
           */
          container: ["container"],
          /**
           * Columns
           * @see https://tailwindcss.com/docs/columns
           */
          columns: [{
            columns: [isTshirtSize]
          }],
          /**
           * Break After
           * @see https://tailwindcss.com/docs/break-after
           */
          "break-after": [{
            "break-after": getBreaks()
          }],
          /**
           * Break Before
           * @see https://tailwindcss.com/docs/break-before
           */
          "break-before": [{
            "break-before": getBreaks()
          }],
          /**
           * Break Inside
           * @see https://tailwindcss.com/docs/break-inside
           */
          "break-inside": [{
            "break-inside": ["auto", "avoid", "avoid-page", "avoid-column"]
          }],
          /**
           * Box Decoration Break
           * @see https://tailwindcss.com/docs/box-decoration-break
           */
          "box-decoration": [{
            "box-decoration": ["slice", "clone"]
          }],
          /**
           * Box Sizing
           * @see https://tailwindcss.com/docs/box-sizing
           */
          box: [{
            box: ["border", "content"]
          }],
          /**
           * Display
           * @see https://tailwindcss.com/docs/display
           */
          display: ["block", "inline-block", "inline", "flex", "inline-flex", "table", "inline-table", "table-caption", "table-cell", "table-column", "table-column-group", "table-footer-group", "table-header-group", "table-row-group", "table-row", "flow-root", "grid", "inline-grid", "contents", "list-item", "hidden"],
          /**
           * Floats
           * @see https://tailwindcss.com/docs/float
           */
          float: [{
            float: ["right", "left", "none", "start", "end"]
          }],
          /**
           * Clear
           * @see https://tailwindcss.com/docs/clear
           */
          clear: [{
            clear: ["left", "right", "both", "none", "start", "end"]
          }],
          /**
           * Isolation
           * @see https://tailwindcss.com/docs/isolation
           */
          isolation: ["isolate", "isolation-auto"],
          /**
           * Object Fit
           * @see https://tailwindcss.com/docs/object-fit
           */
          "object-fit": [{
            object: ["contain", "cover", "fill", "none", "scale-down"]
          }],
          /**
           * Object Position
           * @see https://tailwindcss.com/docs/object-position
           */
          "object-position": [{
            object: [...getPositions(), isArbitraryValue]
          }],
          /**
           * Overflow
           * @see https://tailwindcss.com/docs/overflow
           */
          overflow: [{
            overflow: getOverflow()
          }],
          /**
           * Overflow X
           * @see https://tailwindcss.com/docs/overflow
           */
          "overflow-x": [{
            "overflow-x": getOverflow()
          }],
          /**
           * Overflow Y
           * @see https://tailwindcss.com/docs/overflow
           */
          "overflow-y": [{
            "overflow-y": getOverflow()
          }],
          /**
           * Overscroll Behavior
           * @see https://tailwindcss.com/docs/overscroll-behavior
           */
          overscroll: [{
            overscroll: getOverscroll()
          }],
          /**
           * Overscroll Behavior X
           * @see https://tailwindcss.com/docs/overscroll-behavior
           */
          "overscroll-x": [{
            "overscroll-x": getOverscroll()
          }],
          /**
           * Overscroll Behavior Y
           * @see https://tailwindcss.com/docs/overscroll-behavior
           */
          "overscroll-y": [{
            "overscroll-y": getOverscroll()
          }],
          /**
           * Position
           * @see https://tailwindcss.com/docs/position
           */
          position: ["static", "fixed", "absolute", "relative", "sticky"],
          /**
           * Top / Right / Bottom / Left
           * @see https://tailwindcss.com/docs/top-right-bottom-left
           */
          inset: [{
            inset: [inset]
          }],
          /**
           * Right / Left
           * @see https://tailwindcss.com/docs/top-right-bottom-left
           */
          "inset-x": [{
            "inset-x": [inset]
          }],
          /**
           * Top / Bottom
           * @see https://tailwindcss.com/docs/top-right-bottom-left
           */
          "inset-y": [{
            "inset-y": [inset]
          }],
          /**
           * Start
           * @see https://tailwindcss.com/docs/top-right-bottom-left
           */
          start: [{
            start: [inset]
          }],
          /**
           * End
           * @see https://tailwindcss.com/docs/top-right-bottom-left
           */
          end: [{
            end: [inset]
          }],
          /**
           * Top
           * @see https://tailwindcss.com/docs/top-right-bottom-left
           */
          top: [{
            top: [inset]
          }],
          /**
           * Right
           * @see https://tailwindcss.com/docs/top-right-bottom-left
           */
          right: [{
            right: [inset]
          }],
          /**
           * Bottom
           * @see https://tailwindcss.com/docs/top-right-bottom-left
           */
          bottom: [{
            bottom: [inset]
          }],
          /**
           * Left
           * @see https://tailwindcss.com/docs/top-right-bottom-left
           */
          left: [{
            left: [inset]
          }],
          /**
           * Visibility
           * @see https://tailwindcss.com/docs/visibility
           */
          visibility: ["visible", "invisible", "collapse"],
          /**
           * Z-Index
           * @see https://tailwindcss.com/docs/z-index
           */
          z: [{
            z: ["auto", isInteger, isArbitraryValue]
          }],
          // Flexbox and Grid
          /**
           * Flex Basis
           * @see https://tailwindcss.com/docs/flex-basis
           */
          basis: [{
            basis: getSpacingWithAutoAndArbitrary()
          }],
          /**
           * Flex Direction
           * @see https://tailwindcss.com/docs/flex-direction
           */
          "flex-direction": [{
            flex: ["row", "row-reverse", "col", "col-reverse"]
          }],
          /**
           * Flex Wrap
           * @see https://tailwindcss.com/docs/flex-wrap
           */
          "flex-wrap": [{
            flex: ["wrap", "wrap-reverse", "nowrap"]
          }],
          /**
           * Flex
           * @see https://tailwindcss.com/docs/flex
           */
          flex: [{
            flex: ["1", "auto", "initial", "none", isArbitraryValue]
          }],
          /**
           * Flex Grow
           * @see https://tailwindcss.com/docs/flex-grow
           */
          grow: [{
            grow: getZeroAndEmpty()
          }],
          /**
           * Flex Shrink
           * @see https://tailwindcss.com/docs/flex-shrink
           */
          shrink: [{
            shrink: getZeroAndEmpty()
          }],
          /**
           * Order
           * @see https://tailwindcss.com/docs/order
           */
          order: [{
            order: ["first", "last", "none", isInteger, isArbitraryValue]
          }],
          /**
           * Grid Template Columns
           * @see https://tailwindcss.com/docs/grid-template-columns
           */
          "grid-cols": [{
            "grid-cols": [isAny]
          }],
          /**
           * Grid Column Start / End
           * @see https://tailwindcss.com/docs/grid-column
           */
          "col-start-end": [{
            col: ["auto", {
              span: ["full", isInteger, isArbitraryValue]
            }, isArbitraryValue]
          }],
          /**
           * Grid Column Start
           * @see https://tailwindcss.com/docs/grid-column
           */
          "col-start": [{
            "col-start": getNumberWithAutoAndArbitrary()
          }],
          /**
           * Grid Column End
           * @see https://tailwindcss.com/docs/grid-column
           */
          "col-end": [{
            "col-end": getNumberWithAutoAndArbitrary()
          }],
          /**
           * Grid Template Rows
           * @see https://tailwindcss.com/docs/grid-template-rows
           */
          "grid-rows": [{
            "grid-rows": [isAny]
          }],
          /**
           * Grid Row Start / End
           * @see https://tailwindcss.com/docs/grid-row
           */
          "row-start-end": [{
            row: ["auto", {
              span: [isInteger, isArbitraryValue]
            }, isArbitraryValue]
          }],
          /**
           * Grid Row Start
           * @see https://tailwindcss.com/docs/grid-row
           */
          "row-start": [{
            "row-start": getNumberWithAutoAndArbitrary()
          }],
          /**
           * Grid Row End
           * @see https://tailwindcss.com/docs/grid-row
           */
          "row-end": [{
            "row-end": getNumberWithAutoAndArbitrary()
          }],
          /**
           * Grid Auto Flow
           * @see https://tailwindcss.com/docs/grid-auto-flow
           */
          "grid-flow": [{
            "grid-flow": ["row", "col", "dense", "row-dense", "col-dense"]
          }],
          /**
           * Grid Auto Columns
           * @see https://tailwindcss.com/docs/grid-auto-columns
           */
          "auto-cols": [{
            "auto-cols": ["auto", "min", "max", "fr", isArbitraryValue]
          }],
          /**
           * Grid Auto Rows
           * @see https://tailwindcss.com/docs/grid-auto-rows
           */
          "auto-rows": [{
            "auto-rows": ["auto", "min", "max", "fr", isArbitraryValue]
          }],
          /**
           * Gap
           * @see https://tailwindcss.com/docs/gap
           */
          gap: [{
            gap: [gap]
          }],
          /**
           * Gap X
           * @see https://tailwindcss.com/docs/gap
           */
          "gap-x": [{
            "gap-x": [gap]
          }],
          /**
           * Gap Y
           * @see https://tailwindcss.com/docs/gap
           */
          "gap-y": [{
            "gap-y": [gap]
          }],
          /**
           * Justify Content
           * @see https://tailwindcss.com/docs/justify-content
           */
          "justify-content": [{
            justify: ["normal", ...getAlign()]
          }],
          /**
           * Justify Items
           * @see https://tailwindcss.com/docs/justify-items
           */
          "justify-items": [{
            "justify-items": ["start", "end", "center", "stretch"]
          }],
          /**
           * Justify Self
           * @see https://tailwindcss.com/docs/justify-self
           */
          "justify-self": [{
            "justify-self": ["auto", "start", "end", "center", "stretch"]
          }],
          /**
           * Align Content
           * @see https://tailwindcss.com/docs/align-content
           */
          "align-content": [{
            content: ["normal", ...getAlign(), "baseline"]
          }],
          /**
           * Align Items
           * @see https://tailwindcss.com/docs/align-items
           */
          "align-items": [{
            items: ["start", "end", "center", "baseline", "stretch"]
          }],
          /**
           * Align Self
           * @see https://tailwindcss.com/docs/align-self
           */
          "align-self": [{
            self: ["auto", "start", "end", "center", "stretch", "baseline"]
          }],
          /**
           * Place Content
           * @see https://tailwindcss.com/docs/place-content
           */
          "place-content": [{
            "place-content": [...getAlign(), "baseline"]
          }],
          /**
           * Place Items
           * @see https://tailwindcss.com/docs/place-items
           */
          "place-items": [{
            "place-items": ["start", "end", "center", "baseline", "stretch"]
          }],
          /**
           * Place Self
           * @see https://tailwindcss.com/docs/place-self
           */
          "place-self": [{
            "place-self": ["auto", "start", "end", "center", "stretch"]
          }],
          // Spacing
          /**
           * Padding
           * @see https://tailwindcss.com/docs/padding
           */
          p: [{
            p: [padding]
          }],
          /**
           * Padding X
           * @see https://tailwindcss.com/docs/padding
           */
          px: [{
            px: [padding]
          }],
          /**
           * Padding Y
           * @see https://tailwindcss.com/docs/padding
           */
          py: [{
            py: [padding]
          }],
          /**
           * Padding Start
           * @see https://tailwindcss.com/docs/padding
           */
          ps: [{
            ps: [padding]
          }],
          /**
           * Padding End
           * @see https://tailwindcss.com/docs/padding
           */
          pe: [{
            pe: [padding]
          }],
          /**
           * Padding Top
           * @see https://tailwindcss.com/docs/padding
           */
          pt: [{
            pt: [padding]
          }],
          /**
           * Padding Right
           * @see https://tailwindcss.com/docs/padding
           */
          pr: [{
            pr: [padding]
          }],
          /**
           * Padding Bottom
           * @see https://tailwindcss.com/docs/padding
           */
          pb: [{
            pb: [padding]
          }],
          /**
           * Padding Left
           * @see https://tailwindcss.com/docs/padding
           */
          pl: [{
            pl: [padding]
          }],
          /**
           * Margin
           * @see https://tailwindcss.com/docs/margin
           */
          m: [{
            m: [margin]
          }],
          /**
           * Margin X
           * @see https://tailwindcss.com/docs/margin
           */
          mx: [{
            mx: [margin]
          }],
          /**
           * Margin Y
           * @see https://tailwindcss.com/docs/margin
           */
          my: [{
            my: [margin]
          }],
          /**
           * Margin Start
           * @see https://tailwindcss.com/docs/margin
           */
          ms: [{
            ms: [margin]
          }],
          /**
           * Margin End
           * @see https://tailwindcss.com/docs/margin
           */
          me: [{
            me: [margin]
          }],
          /**
           * Margin Top
           * @see https://tailwindcss.com/docs/margin
           */
          mt: [{
            mt: [margin]
          }],
          /**
           * Margin Right
           * @see https://tailwindcss.com/docs/margin
           */
          mr: [{
            mr: [margin]
          }],
          /**
           * Margin Bottom
           * @see https://tailwindcss.com/docs/margin
           */
          mb: [{
            mb: [margin]
          }],
          /**
           * Margin Left
           * @see https://tailwindcss.com/docs/margin
           */
          ml: [{
            ml: [margin]
          }],
          /**
           * Space Between X
           * @see https://tailwindcss.com/docs/space
           */
          "space-x": [{
            "space-x": [space]
          }],
          /**
           * Space Between X Reverse
           * @see https://tailwindcss.com/docs/space
           */
          "space-x-reverse": ["space-x-reverse"],
          /**
           * Space Between Y
           * @see https://tailwindcss.com/docs/space
           */
          "space-y": [{
            "space-y": [space]
          }],
          /**
           * Space Between Y Reverse
           * @see https://tailwindcss.com/docs/space
           */
          "space-y-reverse": ["space-y-reverse"],
          // Sizing
          /**
           * Width
           * @see https://tailwindcss.com/docs/width
           */
          w: [{
            w: ["auto", "min", "max", "fit", "svw", "lvw", "dvw", isArbitraryValue, spacing]
          }],
          /**
           * Min-Width
           * @see https://tailwindcss.com/docs/min-width
           */
          "min-w": [{
            "min-w": [isArbitraryValue, spacing, "min", "max", "fit"]
          }],
          /**
           * Max-Width
           * @see https://tailwindcss.com/docs/max-width
           */
          "max-w": [{
            "max-w": [isArbitraryValue, spacing, "none", "full", "min", "max", "fit", "prose", {
              screen: [isTshirtSize]
            }, isTshirtSize]
          }],
          /**
           * Height
           * @see https://tailwindcss.com/docs/height
           */
          h: [{
            h: [isArbitraryValue, spacing, "auto", "min", "max", "fit", "svh", "lvh", "dvh"]
          }],
          /**
           * Min-Height
           * @see https://tailwindcss.com/docs/min-height
           */
          "min-h": [{
            "min-h": [isArbitraryValue, spacing, "min", "max", "fit", "svh", "lvh", "dvh"]
          }],
          /**
           * Max-Height
           * @see https://tailwindcss.com/docs/max-height
           */
          "max-h": [{
            "max-h": [isArbitraryValue, spacing, "min", "max", "fit", "svh", "lvh", "dvh"]
          }],
          /**
           * Size
           * @see https://tailwindcss.com/docs/size
           */
          size: [{
            size: [isArbitraryValue, spacing, "auto", "min", "max", "fit"]
          }],
          // Typography
          /**
           * Font Size
           * @see https://tailwindcss.com/docs/font-size
           */
          "font-size": [{
            text: ["base", isTshirtSize, isArbitraryLength]
          }],
          /**
           * Font Smoothing
           * @see https://tailwindcss.com/docs/font-smoothing
           */
          "font-smoothing": ["antialiased", "subpixel-antialiased"],
          /**
           * Font Style
           * @see https://tailwindcss.com/docs/font-style
           */
          "font-style": ["italic", "not-italic"],
          /**
           * Font Weight
           * @see https://tailwindcss.com/docs/font-weight
           */
          "font-weight": [{
            font: ["thin", "extralight", "light", "normal", "medium", "semibold", "bold", "extrabold", "black", isArbitraryNumber]
          }],
          /**
           * Font Family
           * @see https://tailwindcss.com/docs/font-family
           */
          "font-family": [{
            font: [isAny]
          }],
          /**
           * Font Variant Numeric
           * @see https://tailwindcss.com/docs/font-variant-numeric
           */
          "fvn-normal": ["normal-nums"],
          /**
           * Font Variant Numeric
           * @see https://tailwindcss.com/docs/font-variant-numeric
           */
          "fvn-ordinal": ["ordinal"],
          /**
           * Font Variant Numeric
           * @see https://tailwindcss.com/docs/font-variant-numeric
           */
          "fvn-slashed-zero": ["slashed-zero"],
          /**
           * Font Variant Numeric
           * @see https://tailwindcss.com/docs/font-variant-numeric
           */
          "fvn-figure": ["lining-nums", "oldstyle-nums"],
          /**
           * Font Variant Numeric
           * @see https://tailwindcss.com/docs/font-variant-numeric
           */
          "fvn-spacing": ["proportional-nums", "tabular-nums"],
          /**
           * Font Variant Numeric
           * @see https://tailwindcss.com/docs/font-variant-numeric
           */
          "fvn-fraction": ["diagonal-fractions", "stacked-fractions"],
          /**
           * Letter Spacing
           * @see https://tailwindcss.com/docs/letter-spacing
           */
          tracking: [{
            tracking: ["tighter", "tight", "normal", "wide", "wider", "widest", isArbitraryValue]
          }],
          /**
           * Line Clamp
           * @see https://tailwindcss.com/docs/line-clamp
           */
          "line-clamp": [{
            "line-clamp": ["none", isNumber, isArbitraryNumber]
          }],
          /**
           * Line Height
           * @see https://tailwindcss.com/docs/line-height
           */
          leading: [{
            leading: ["none", "tight", "snug", "normal", "relaxed", "loose", isLength, isArbitraryValue]
          }],
          /**
           * List Style Image
           * @see https://tailwindcss.com/docs/list-style-image
           */
          "list-image": [{
            "list-image": ["none", isArbitraryValue]
          }],
          /**
           * List Style Type
           * @see https://tailwindcss.com/docs/list-style-type
           */
          "list-style-type": [{
            list: ["none", "disc", "decimal", isArbitraryValue]
          }],
          /**
           * List Style Position
           * @see https://tailwindcss.com/docs/list-style-position
           */
          "list-style-position": [{
            list: ["inside", "outside"]
          }],
          /**
           * Placeholder Color
           * @deprecated since Tailwind CSS v3.0.0
           * @see https://tailwindcss.com/docs/placeholder-color
           */
          "placeholder-color": [{
            placeholder: [colors]
          }],
          /**
           * Placeholder Opacity
           * @see https://tailwindcss.com/docs/placeholder-opacity
           */
          "placeholder-opacity": [{
            "placeholder-opacity": [opacity]
          }],
          /**
           * Text Alignment
           * @see https://tailwindcss.com/docs/text-align
           */
          "text-alignment": [{
            text: ["left", "center", "right", "justify", "start", "end"]
          }],
          /**
           * Text Color
           * @see https://tailwindcss.com/docs/text-color
           */
          "text-color": [{
            text: [colors]
          }],
          /**
           * Text Opacity
           * @see https://tailwindcss.com/docs/text-opacity
           */
          "text-opacity": [{
            "text-opacity": [opacity]
          }],
          /**
           * Text Decoration
           * @see https://tailwindcss.com/docs/text-decoration
           */
          "text-decoration": ["underline", "overline", "line-through", "no-underline"],
          /**
           * Text Decoration Style
           * @see https://tailwindcss.com/docs/text-decoration-style
           */
          "text-decoration-style": [{
            decoration: [...getLineStyles(), "wavy"]
          }],
          /**
           * Text Decoration Thickness
           * @see https://tailwindcss.com/docs/text-decoration-thickness
           */
          "text-decoration-thickness": [{
            decoration: ["auto", "from-font", isLength, isArbitraryLength]
          }],
          /**
           * Text Underline Offset
           * @see https://tailwindcss.com/docs/text-underline-offset
           */
          "underline-offset": [{
            "underline-offset": ["auto", isLength, isArbitraryValue]
          }],
          /**
           * Text Decoration Color
           * @see https://tailwindcss.com/docs/text-decoration-color
           */
          "text-decoration-color": [{
            decoration: [colors]
          }],
          /**
           * Text Transform
           * @see https://tailwindcss.com/docs/text-transform
           */
          "text-transform": ["uppercase", "lowercase", "capitalize", "normal-case"],
          /**
           * Text Overflow
           * @see https://tailwindcss.com/docs/text-overflow
           */
          "text-overflow": ["truncate", "text-ellipsis", "text-clip"],
          /**
           * Text Wrap
           * @see https://tailwindcss.com/docs/text-wrap
           */
          "text-wrap": [{
            text: ["wrap", "nowrap", "balance", "pretty"]
          }],
          /**
           * Text Indent
           * @see https://tailwindcss.com/docs/text-indent
           */
          indent: [{
            indent: getSpacingWithArbitrary()
          }],
          /**
           * Vertical Alignment
           * @see https://tailwindcss.com/docs/vertical-align
           */
          "vertical-align": [{
            align: ["baseline", "top", "middle", "bottom", "text-top", "text-bottom", "sub", "super", isArbitraryValue]
          }],
          /**
           * Whitespace
           * @see https://tailwindcss.com/docs/whitespace
           */
          whitespace: [{
            whitespace: ["normal", "nowrap", "pre", "pre-line", "pre-wrap", "break-spaces"]
          }],
          /**
           * Word Break
           * @see https://tailwindcss.com/docs/word-break
           */
          break: [{
            break: ["normal", "words", "all", "keep"]
          }],
          /**
           * Hyphens
           * @see https://tailwindcss.com/docs/hyphens
           */
          hyphens: [{
            hyphens: ["none", "manual", "auto"]
          }],
          /**
           * Content
           * @see https://tailwindcss.com/docs/content
           */
          content: [{
            content: ["none", isArbitraryValue]
          }],
          // Backgrounds
          /**
           * Background Attachment
           * @see https://tailwindcss.com/docs/background-attachment
           */
          "bg-attachment": [{
            bg: ["fixed", "local", "scroll"]
          }],
          /**
           * Background Clip
           * @see https://tailwindcss.com/docs/background-clip
           */
          "bg-clip": [{
            "bg-clip": ["border", "padding", "content", "text"]
          }],
          /**
           * Background Opacity
           * @deprecated since Tailwind CSS v3.0.0
           * @see https://tailwindcss.com/docs/background-opacity
           */
          "bg-opacity": [{
            "bg-opacity": [opacity]
          }],
          /**
           * Background Origin
           * @see https://tailwindcss.com/docs/background-origin
           */
          "bg-origin": [{
            "bg-origin": ["border", "padding", "content"]
          }],
          /**
           * Background Position
           * @see https://tailwindcss.com/docs/background-position
           */
          "bg-position": [{
            bg: [...getPositions(), isArbitraryPosition]
          }],
          /**
           * Background Repeat
           * @see https://tailwindcss.com/docs/background-repeat
           */
          "bg-repeat": [{
            bg: ["no-repeat", {
              repeat: ["", "x", "y", "round", "space"]
            }]
          }],
          /**
           * Background Size
           * @see https://tailwindcss.com/docs/background-size
           */
          "bg-size": [{
            bg: ["auto", "cover", "contain", isArbitrarySize]
          }],
          /**
           * Background Image
           * @see https://tailwindcss.com/docs/background-image
           */
          "bg-image": [{
            bg: ["none", {
              "gradient-to": ["t", "tr", "r", "br", "b", "bl", "l", "tl"]
            }, isArbitraryImage]
          }],
          /**
           * Background Color
           * @see https://tailwindcss.com/docs/background-color
           */
          "bg-color": [{
            bg: [colors]
          }],
          /**
           * Gradient Color Stops From Position
           * @see https://tailwindcss.com/docs/gradient-color-stops
           */
          "gradient-from-pos": [{
            from: [gradientColorStopPositions]
          }],
          /**
           * Gradient Color Stops Via Position
           * @see https://tailwindcss.com/docs/gradient-color-stops
           */
          "gradient-via-pos": [{
            via: [gradientColorStopPositions]
          }],
          /**
           * Gradient Color Stops To Position
           * @see https://tailwindcss.com/docs/gradient-color-stops
           */
          "gradient-to-pos": [{
            to: [gradientColorStopPositions]
          }],
          /**
           * Gradient Color Stops From
           * @see https://tailwindcss.com/docs/gradient-color-stops
           */
          "gradient-from": [{
            from: [gradientColorStops]
          }],
          /**
           * Gradient Color Stops Via
           * @see https://tailwindcss.com/docs/gradient-color-stops
           */
          "gradient-via": [{
            via: [gradientColorStops]
          }],
          /**
           * Gradient Color Stops To
           * @see https://tailwindcss.com/docs/gradient-color-stops
           */
          "gradient-to": [{
            to: [gradientColorStops]
          }],
          // Borders
          /**
           * Border Radius
           * @see https://tailwindcss.com/docs/border-radius
           */
          rounded: [{
            rounded: [borderRadius]
          }],
          /**
           * Border Radius Start
           * @see https://tailwindcss.com/docs/border-radius
           */
          "rounded-s": [{
            "rounded-s": [borderRadius]
          }],
          /**
           * Border Radius End
           * @see https://tailwindcss.com/docs/border-radius
           */
          "rounded-e": [{
            "rounded-e": [borderRadius]
          }],
          /**
           * Border Radius Top
           * @see https://tailwindcss.com/docs/border-radius
           */
          "rounded-t": [{
            "rounded-t": [borderRadius]
          }],
          /**
           * Border Radius Right
           * @see https://tailwindcss.com/docs/border-radius
           */
          "rounded-r": [{
            "rounded-r": [borderRadius]
          }],
          /**
           * Border Radius Bottom
           * @see https://tailwindcss.com/docs/border-radius
           */
          "rounded-b": [{
            "rounded-b": [borderRadius]
          }],
          /**
           * Border Radius Left
           * @see https://tailwindcss.com/docs/border-radius
           */
          "rounded-l": [{
            "rounded-l": [borderRadius]
          }],
          /**
           * Border Radius Start Start
           * @see https://tailwindcss.com/docs/border-radius
           */
          "rounded-ss": [{
            "rounded-ss": [borderRadius]
          }],
          /**
           * Border Radius Start End
           * @see https://tailwindcss.com/docs/border-radius
           */
          "rounded-se": [{
            "rounded-se": [borderRadius]
          }],
          /**
           * Border Radius End End
           * @see https://tailwindcss.com/docs/border-radius
           */
          "rounded-ee": [{
            "rounded-ee": [borderRadius]
          }],
          /**
           * Border Radius End Start
           * @see https://tailwindcss.com/docs/border-radius
           */
          "rounded-es": [{
            "rounded-es": [borderRadius]
          }],
          /**
           * Border Radius Top Left
           * @see https://tailwindcss.com/docs/border-radius
           */
          "rounded-tl": [{
            "rounded-tl": [borderRadius]
          }],
          /**
           * Border Radius Top Right
           * @see https://tailwindcss.com/docs/border-radius
           */
          "rounded-tr": [{
            "rounded-tr": [borderRadius]
          }],
          /**
           * Border Radius Bottom Right
           * @see https://tailwindcss.com/docs/border-radius
           */
          "rounded-br": [{
            "rounded-br": [borderRadius]
          }],
          /**
           * Border Radius Bottom Left
           * @see https://tailwindcss.com/docs/border-radius
           */
          "rounded-bl": [{
            "rounded-bl": [borderRadius]
          }],
          /**
           * Border Width
           * @see https://tailwindcss.com/docs/border-width
           */
          "border-w": [{
            border: [borderWidth]
          }],
          /**
           * Border Width X
           * @see https://tailwindcss.com/docs/border-width
           */
          "border-w-x": [{
            "border-x": [borderWidth]
          }],
          /**
           * Border Width Y
           * @see https://tailwindcss.com/docs/border-width
           */
          "border-w-y": [{
            "border-y": [borderWidth]
          }],
          /**
           * Border Width Start
           * @see https://tailwindcss.com/docs/border-width
           */
          "border-w-s": [{
            "border-s": [borderWidth]
          }],
          /**
           * Border Width End
           * @see https://tailwindcss.com/docs/border-width
           */
          "border-w-e": [{
            "border-e": [borderWidth]
          }],
          /**
           * Border Width Top
           * @see https://tailwindcss.com/docs/border-width
           */
          "border-w-t": [{
            "border-t": [borderWidth]
          }],
          /**
           * Border Width Right
           * @see https://tailwindcss.com/docs/border-width
           */
          "border-w-r": [{
            "border-r": [borderWidth]
          }],
          /**
           * Border Width Bottom
           * @see https://tailwindcss.com/docs/border-width
           */
          "border-w-b": [{
            "border-b": [borderWidth]
          }],
          /**
           * Border Width Left
           * @see https://tailwindcss.com/docs/border-width
           */
          "border-w-l": [{
            "border-l": [borderWidth]
          }],
          /**
           * Border Opacity
           * @see https://tailwindcss.com/docs/border-opacity
           */
          "border-opacity": [{
            "border-opacity": [opacity]
          }],
          /**
           * Border Style
           * @see https://tailwindcss.com/docs/border-style
           */
          "border-style": [{
            border: [...getLineStyles(), "hidden"]
          }],
          /**
           * Divide Width X
           * @see https://tailwindcss.com/docs/divide-width
           */
          "divide-x": [{
            "divide-x": [borderWidth]
          }],
          /**
           * Divide Width X Reverse
           * @see https://tailwindcss.com/docs/divide-width
           */
          "divide-x-reverse": ["divide-x-reverse"],
          /**
           * Divide Width Y
           * @see https://tailwindcss.com/docs/divide-width
           */
          "divide-y": [{
            "divide-y": [borderWidth]
          }],
          /**
           * Divide Width Y Reverse
           * @see https://tailwindcss.com/docs/divide-width
           */
          "divide-y-reverse": ["divide-y-reverse"],
          /**
           * Divide Opacity
           * @see https://tailwindcss.com/docs/divide-opacity
           */
          "divide-opacity": [{
            "divide-opacity": [opacity]
          }],
          /**
           * Divide Style
           * @see https://tailwindcss.com/docs/divide-style
           */
          "divide-style": [{
            divide: getLineStyles()
          }],
          /**
           * Border Color
           * @see https://tailwindcss.com/docs/border-color
           */
          "border-color": [{
            border: [borderColor]
          }],
          /**
           * Border Color X
           * @see https://tailwindcss.com/docs/border-color
           */
          "border-color-x": [{
            "border-x": [borderColor]
          }],
          /**
           * Border Color Y
           * @see https://tailwindcss.com/docs/border-color
           */
          "border-color-y": [{
            "border-y": [borderColor]
          }],
          /**
           * Border Color S
           * @see https://tailwindcss.com/docs/border-color
           */
          "border-color-s": [{
            "border-s": [borderColor]
          }],
          /**
           * Border Color E
           * @see https://tailwindcss.com/docs/border-color
           */
          "border-color-e": [{
            "border-e": [borderColor]
          }],
          /**
           * Border Color Top
           * @see https://tailwindcss.com/docs/border-color
           */
          "border-color-t": [{
            "border-t": [borderColor]
          }],
          /**
           * Border Color Right
           * @see https://tailwindcss.com/docs/border-color
           */
          "border-color-r": [{
            "border-r": [borderColor]
          }],
          /**
           * Border Color Bottom
           * @see https://tailwindcss.com/docs/border-color
           */
          "border-color-b": [{
            "border-b": [borderColor]
          }],
          /**
           * Border Color Left
           * @see https://tailwindcss.com/docs/border-color
           */
          "border-color-l": [{
            "border-l": [borderColor]
          }],
          /**
           * Divide Color
           * @see https://tailwindcss.com/docs/divide-color
           */
          "divide-color": [{
            divide: [borderColor]
          }],
          /**
           * Outline Style
           * @see https://tailwindcss.com/docs/outline-style
           */
          "outline-style": [{
            outline: ["", ...getLineStyles()]
          }],
          /**
           * Outline Offset
           * @see https://tailwindcss.com/docs/outline-offset
           */
          "outline-offset": [{
            "outline-offset": [isLength, isArbitraryValue]
          }],
          /**
           * Outline Width
           * @see https://tailwindcss.com/docs/outline-width
           */
          "outline-w": [{
            outline: [isLength, isArbitraryLength]
          }],
          /**
           * Outline Color
           * @see https://tailwindcss.com/docs/outline-color
           */
          "outline-color": [{
            outline: [colors]
          }],
          /**
           * Ring Width
           * @see https://tailwindcss.com/docs/ring-width
           */
          "ring-w": [{
            ring: getLengthWithEmptyAndArbitrary()
          }],
          /**
           * Ring Width Inset
           * @see https://tailwindcss.com/docs/ring-width
           */
          "ring-w-inset": ["ring-inset"],
          /**
           * Ring Color
           * @see https://tailwindcss.com/docs/ring-color
           */
          "ring-color": [{
            ring: [colors]
          }],
          /**
           * Ring Opacity
           * @see https://tailwindcss.com/docs/ring-opacity
           */
          "ring-opacity": [{
            "ring-opacity": [opacity]
          }],
          /**
           * Ring Offset Width
           * @see https://tailwindcss.com/docs/ring-offset-width
           */
          "ring-offset-w": [{
            "ring-offset": [isLength, isArbitraryLength]
          }],
          /**
           * Ring Offset Color
           * @see https://tailwindcss.com/docs/ring-offset-color
           */
          "ring-offset-color": [{
            "ring-offset": [colors]
          }],
          // Effects
          /**
           * Box Shadow
           * @see https://tailwindcss.com/docs/box-shadow
           */
          shadow: [{
            shadow: ["", "inner", "none", isTshirtSize, isArbitraryShadow]
          }],
          /**
           * Box Shadow Color
           * @see https://tailwindcss.com/docs/box-shadow-color
           */
          "shadow-color": [{
            shadow: [isAny]
          }],
          /**
           * Opacity
           * @see https://tailwindcss.com/docs/opacity
           */
          opacity: [{
            opacity: [opacity]
          }],
          /**
           * Mix Blend Mode
           * @see https://tailwindcss.com/docs/mix-blend-mode
           */
          "mix-blend": [{
            "mix-blend": [...getBlendModes(), "plus-lighter", "plus-darker"]
          }],
          /**
           * Background Blend Mode
           * @see https://tailwindcss.com/docs/background-blend-mode
           */
          "bg-blend": [{
            "bg-blend": getBlendModes()
          }],
          // Filters
          /**
           * Filter
           * @deprecated since Tailwind CSS v3.0.0
           * @see https://tailwindcss.com/docs/filter
           */
          filter: [{
            filter: ["", "none"]
          }],
          /**
           * Blur
           * @see https://tailwindcss.com/docs/blur
           */
          blur: [{
            blur: [blur]
          }],
          /**
           * Brightness
           * @see https://tailwindcss.com/docs/brightness
           */
          brightness: [{
            brightness: [brightness]
          }],
          /**
           * Contrast
           * @see https://tailwindcss.com/docs/contrast
           */
          contrast: [{
            contrast: [contrast]
          }],
          /**
           * Drop Shadow
           * @see https://tailwindcss.com/docs/drop-shadow
           */
          "drop-shadow": [{
            "drop-shadow": ["", "none", isTshirtSize, isArbitraryValue]
          }],
          /**
           * Grayscale
           * @see https://tailwindcss.com/docs/grayscale
           */
          grayscale: [{
            grayscale: [grayscale]
          }],
          /**
           * Hue Rotate
           * @see https://tailwindcss.com/docs/hue-rotate
           */
          "hue-rotate": [{
            "hue-rotate": [hueRotate]
          }],
          /**
           * Invert
           * @see https://tailwindcss.com/docs/invert
           */
          invert: [{
            invert: [invert]
          }],
          /**
           * Saturate
           * @see https://tailwindcss.com/docs/saturate
           */
          saturate: [{
            saturate: [saturate]
          }],
          /**
           * Sepia
           * @see https://tailwindcss.com/docs/sepia
           */
          sepia: [{
            sepia: [sepia]
          }],
          /**
           * Backdrop Filter
           * @deprecated since Tailwind CSS v3.0.0
           * @see https://tailwindcss.com/docs/backdrop-filter
           */
          "backdrop-filter": [{
            "backdrop-filter": ["", "none"]
          }],
          /**
           * Backdrop Blur
           * @see https://tailwindcss.com/docs/backdrop-blur
           */
          "backdrop-blur": [{
            "backdrop-blur": [blur]
          }],
          /**
           * Backdrop Brightness
           * @see https://tailwindcss.com/docs/backdrop-brightness
           */
          "backdrop-brightness": [{
            "backdrop-brightness": [brightness]
          }],
          /**
           * Backdrop Contrast
           * @see https://tailwindcss.com/docs/backdrop-contrast
           */
          "backdrop-contrast": [{
            "backdrop-contrast": [contrast]
          }],
          /**
           * Backdrop Grayscale
           * @see https://tailwindcss.com/docs/backdrop-grayscale
           */
          "backdrop-grayscale": [{
            "backdrop-grayscale": [grayscale]
          }],
          /**
           * Backdrop Hue Rotate
           * @see https://tailwindcss.com/docs/backdrop-hue-rotate
           */
          "backdrop-hue-rotate": [{
            "backdrop-hue-rotate": [hueRotate]
          }],
          /**
           * Backdrop Invert
           * @see https://tailwindcss.com/docs/backdrop-invert
           */
          "backdrop-invert": [{
            "backdrop-invert": [invert]
          }],
          /**
           * Backdrop Opacity
           * @see https://tailwindcss.com/docs/backdrop-opacity
           */
          "backdrop-opacity": [{
            "backdrop-opacity": [opacity]
          }],
          /**
           * Backdrop Saturate
           * @see https://tailwindcss.com/docs/backdrop-saturate
           */
          "backdrop-saturate": [{
            "backdrop-saturate": [saturate]
          }],
          /**
           * Backdrop Sepia
           * @see https://tailwindcss.com/docs/backdrop-sepia
           */
          "backdrop-sepia": [{
            "backdrop-sepia": [sepia]
          }],
          // Tables
          /**
           * Border Collapse
           * @see https://tailwindcss.com/docs/border-collapse
           */
          "border-collapse": [{
            border: ["collapse", "separate"]
          }],
          /**
           * Border Spacing
           * @see https://tailwindcss.com/docs/border-spacing
           */
          "border-spacing": [{
            "border-spacing": [borderSpacing]
          }],
          /**
           * Border Spacing X
           * @see https://tailwindcss.com/docs/border-spacing
           */
          "border-spacing-x": [{
            "border-spacing-x": [borderSpacing]
          }],
          /**
           * Border Spacing Y
           * @see https://tailwindcss.com/docs/border-spacing
           */
          "border-spacing-y": [{
            "border-spacing-y": [borderSpacing]
          }],
          /**
           * Table Layout
           * @see https://tailwindcss.com/docs/table-layout
           */
          "table-layout": [{
            table: ["auto", "fixed"]
          }],
          /**
           * Caption Side
           * @see https://tailwindcss.com/docs/caption-side
           */
          caption: [{
            caption: ["top", "bottom"]
          }],
          // Transitions and Animation
          /**
           * Tranisition Property
           * @see https://tailwindcss.com/docs/transition-property
           */
          transition: [{
            transition: ["none", "all", "", "colors", "opacity", "shadow", "transform", isArbitraryValue]
          }],
          /**
           * Transition Duration
           * @see https://tailwindcss.com/docs/transition-duration
           */
          duration: [{
            duration: getNumberAndArbitrary()
          }],
          /**
           * Transition Timing Function
           * @see https://tailwindcss.com/docs/transition-timing-function
           */
          ease: [{
            ease: ["linear", "in", "out", "in-out", isArbitraryValue]
          }],
          /**
           * Transition Delay
           * @see https://tailwindcss.com/docs/transition-delay
           */
          delay: [{
            delay: getNumberAndArbitrary()
          }],
          /**
           * Animation
           * @see https://tailwindcss.com/docs/animation
           */
          animate: [{
            animate: ["none", "spin", "ping", "pulse", "bounce", isArbitraryValue]
          }],
          // Transforms
          /**
           * Transform
           * @see https://tailwindcss.com/docs/transform
           */
          transform: [{
            transform: ["", "gpu", "none"]
          }],
          /**
           * Scale
           * @see https://tailwindcss.com/docs/scale
           */
          scale: [{
            scale: [scale]
          }],
          /**
           * Scale X
           * @see https://tailwindcss.com/docs/scale
           */
          "scale-x": [{
            "scale-x": [scale]
          }],
          /**
           * Scale Y
           * @see https://tailwindcss.com/docs/scale
           */
          "scale-y": [{
            "scale-y": [scale]
          }],
          /**
           * Rotate
           * @see https://tailwindcss.com/docs/rotate
           */
          rotate: [{
            rotate: [isInteger, isArbitraryValue]
          }],
          /**
           * Translate X
           * @see https://tailwindcss.com/docs/translate
           */
          "translate-x": [{
            "translate-x": [translate]
          }],
          /**
           * Translate Y
           * @see https://tailwindcss.com/docs/translate
           */
          "translate-y": [{
            "translate-y": [translate]
          }],
          /**
           * Skew X
           * @see https://tailwindcss.com/docs/skew
           */
          "skew-x": [{
            "skew-x": [skew]
          }],
          /**
           * Skew Y
           * @see https://tailwindcss.com/docs/skew
           */
          "skew-y": [{
            "skew-y": [skew]
          }],
          /**
           * Transform Origin
           * @see https://tailwindcss.com/docs/transform-origin
           */
          "transform-origin": [{
            origin: ["center", "top", "top-right", "right", "bottom-right", "bottom", "bottom-left", "left", "top-left", isArbitraryValue]
          }],
          // Interactivity
          /**
           * Accent Color
           * @see https://tailwindcss.com/docs/accent-color
           */
          accent: [{
            accent: ["auto", colors]
          }],
          /**
           * Appearance
           * @see https://tailwindcss.com/docs/appearance
           */
          appearance: [{
            appearance: ["none", "auto"]
          }],
          /**
           * Cursor
           * @see https://tailwindcss.com/docs/cursor
           */
          cursor: [{
            cursor: ["auto", "default", "pointer", "wait", "text", "move", "help", "not-allowed", "none", "context-menu", "progress", "cell", "crosshair", "vertical-text", "alias", "copy", "no-drop", "grab", "grabbing", "all-scroll", "col-resize", "row-resize", "n-resize", "e-resize", "s-resize", "w-resize", "ne-resize", "nw-resize", "se-resize", "sw-resize", "ew-resize", "ns-resize", "nesw-resize", "nwse-resize", "zoom-in", "zoom-out", isArbitraryValue]
          }],
          /**
           * Caret Color
           * @see https://tailwindcss.com/docs/just-in-time-mode#caret-color-utilities
           */
          "caret-color": [{
            caret: [colors]
          }],
          /**
           * Pointer Events
           * @see https://tailwindcss.com/docs/pointer-events
           */
          "pointer-events": [{
            "pointer-events": ["none", "auto"]
          }],
          /**
           * Resize
           * @see https://tailwindcss.com/docs/resize
           */
          resize: [{
            resize: ["none", "y", "x", ""]
          }],
          /**
           * Scroll Behavior
           * @see https://tailwindcss.com/docs/scroll-behavior
           */
          "scroll-behavior": [{
            scroll: ["auto", "smooth"]
          }],
          /**
           * Scroll Margin
           * @see https://tailwindcss.com/docs/scroll-margin
           */
          "scroll-m": [{
            "scroll-m": getSpacingWithArbitrary()
          }],
          /**
           * Scroll Margin X
           * @see https://tailwindcss.com/docs/scroll-margin
           */
          "scroll-mx": [{
            "scroll-mx": getSpacingWithArbitrary()
          }],
          /**
           * Scroll Margin Y
           * @see https://tailwindcss.com/docs/scroll-margin
           */
          "scroll-my": [{
            "scroll-my": getSpacingWithArbitrary()
          }],
          /**
           * Scroll Margin Start
           * @see https://tailwindcss.com/docs/scroll-margin
           */
          "scroll-ms": [{
            "scroll-ms": getSpacingWithArbitrary()
          }],
          /**
           * Scroll Margin End
           * @see https://tailwindcss.com/docs/scroll-margin
           */
          "scroll-me": [{
            "scroll-me": getSpacingWithArbitrary()
          }],
          /**
           * Scroll Margin Top
           * @see https://tailwindcss.com/docs/scroll-margin
           */
          "scroll-mt": [{
            "scroll-mt": getSpacingWithArbitrary()
          }],
          /**
           * Scroll Margin Right
           * @see https://tailwindcss.com/docs/scroll-margin
           */
          "scroll-mr": [{
            "scroll-mr": getSpacingWithArbitrary()
          }],
          /**
           * Scroll Margin Bottom
           * @see https://tailwindcss.com/docs/scroll-margin
           */
          "scroll-mb": [{
            "scroll-mb": getSpacingWithArbitrary()
          }],
          /**
           * Scroll Margin Left
           * @see https://tailwindcss.com/docs/scroll-margin
           */
          "scroll-ml": [{
            "scroll-ml": getSpacingWithArbitrary()
          }],
          /**
           * Scroll Padding
           * @see https://tailwindcss.com/docs/scroll-padding
           */
          "scroll-p": [{
            "scroll-p": getSpacingWithArbitrary()
          }],
          /**
           * Scroll Padding X
           * @see https://tailwindcss.com/docs/scroll-padding
           */
          "scroll-px": [{
            "scroll-px": getSpacingWithArbitrary()
          }],
          /**
           * Scroll Padding Y
           * @see https://tailwindcss.com/docs/scroll-padding
           */
          "scroll-py": [{
            "scroll-py": getSpacingWithArbitrary()
          }],
          /**
           * Scroll Padding Start
           * @see https://tailwindcss.com/docs/scroll-padding
           */
          "scroll-ps": [{
            "scroll-ps": getSpacingWithArbitrary()
          }],
          /**
           * Scroll Padding End
           * @see https://tailwindcss.com/docs/scroll-padding
           */
          "scroll-pe": [{
            "scroll-pe": getSpacingWithArbitrary()
          }],
          /**
           * Scroll Padding Top
           * @see https://tailwindcss.com/docs/scroll-padding
           */
          "scroll-pt": [{
            "scroll-pt": getSpacingWithArbitrary()
          }],
          /**
           * Scroll Padding Right
           * @see https://tailwindcss.com/docs/scroll-padding
           */
          "scroll-pr": [{
            "scroll-pr": getSpacingWithArbitrary()
          }],
          /**
           * Scroll Padding Bottom
           * @see https://tailwindcss.com/docs/scroll-padding
           */
          "scroll-pb": [{
            "scroll-pb": getSpacingWithArbitrary()
          }],
          /**
           * Scroll Padding Left
           * @see https://tailwindcss.com/docs/scroll-padding
           */
          "scroll-pl": [{
            "scroll-pl": getSpacingWithArbitrary()
          }],
          /**
           * Scroll Snap Align
           * @see https://tailwindcss.com/docs/scroll-snap-align
           */
          "snap-align": [{
            snap: ["start", "end", "center", "align-none"]
          }],
          /**
           * Scroll Snap Stop
           * @see https://tailwindcss.com/docs/scroll-snap-stop
           */
          "snap-stop": [{
            snap: ["normal", "always"]
          }],
          /**
           * Scroll Snap Type
           * @see https://tailwindcss.com/docs/scroll-snap-type
           */
          "snap-type": [{
            snap: ["none", "x", "y", "both"]
          }],
          /**
           * Scroll Snap Type Strictness
           * @see https://tailwindcss.com/docs/scroll-snap-type
           */
          "snap-strictness": [{
            snap: ["mandatory", "proximity"]
          }],
          /**
           * Touch Action
           * @see https://tailwindcss.com/docs/touch-action
           */
          touch: [{
            touch: ["auto", "none", "manipulation"]
          }],
          /**
           * Touch Action X
           * @see https://tailwindcss.com/docs/touch-action
           */
          "touch-x": [{
            "touch-pan": ["x", "left", "right"]
          }],
          /**
           * Touch Action Y
           * @see https://tailwindcss.com/docs/touch-action
           */
          "touch-y": [{
            "touch-pan": ["y", "up", "down"]
          }],
          /**
           * Touch Action Pinch Zoom
           * @see https://tailwindcss.com/docs/touch-action
           */
          "touch-pz": ["touch-pinch-zoom"],
          /**
           * User Select
           * @see https://tailwindcss.com/docs/user-select
           */
          select: [{
            select: ["none", "text", "all", "auto"]
          }],
          /**
           * Will Change
           * @see https://tailwindcss.com/docs/will-change
           */
          "will-change": [{
            "will-change": ["auto", "scroll", "contents", "transform", isArbitraryValue]
          }],
          // SVG
          /**
           * Fill
           * @see https://tailwindcss.com/docs/fill
           */
          fill: [{
            fill: [colors, "none"]
          }],
          /**
           * Stroke Width
           * @see https://tailwindcss.com/docs/stroke-width
           */
          "stroke-w": [{
            stroke: [isLength, isArbitraryLength, isArbitraryNumber]
          }],
          /**
           * Stroke
           * @see https://tailwindcss.com/docs/stroke
           */
          stroke: [{
            stroke: [colors, "none"]
          }],
          // Accessibility
          /**
           * Screen Readers
           * @see https://tailwindcss.com/docs/screen-readers
           */
          sr: ["sr-only", "not-sr-only"],
          /**
           * Forced Color Adjust
           * @see https://tailwindcss.com/docs/forced-color-adjust
           */
          "forced-color-adjust": [{
            "forced-color-adjust": ["auto", "none"]
          }]
        },
        conflictingClassGroups: {
          overflow: ["overflow-x", "overflow-y"],
          overscroll: ["overscroll-x", "overscroll-y"],
          inset: ["inset-x", "inset-y", "start", "end", "top", "right", "bottom", "left"],
          "inset-x": ["right", "left"],
          "inset-y": ["top", "bottom"],
          flex: ["basis", "grow", "shrink"],
          gap: ["gap-x", "gap-y"],
          p: ["px", "py", "ps", "pe", "pt", "pr", "pb", "pl"],
          px: ["pr", "pl"],
          py: ["pt", "pb"],
          m: ["mx", "my", "ms", "me", "mt", "mr", "mb", "ml"],
          mx: ["mr", "ml"],
          my: ["mt", "mb"],
          size: ["w", "h"],
          "font-size": ["leading"],
          "fvn-normal": ["fvn-ordinal", "fvn-slashed-zero", "fvn-figure", "fvn-spacing", "fvn-fraction"],
          "fvn-ordinal": ["fvn-normal"],
          "fvn-slashed-zero": ["fvn-normal"],
          "fvn-figure": ["fvn-normal"],
          "fvn-spacing": ["fvn-normal"],
          "fvn-fraction": ["fvn-normal"],
          "line-clamp": ["display", "overflow"],
          rounded: ["rounded-s", "rounded-e", "rounded-t", "rounded-r", "rounded-b", "rounded-l", "rounded-ss", "rounded-se", "rounded-ee", "rounded-es", "rounded-tl", "rounded-tr", "rounded-br", "rounded-bl"],
          "rounded-s": ["rounded-ss", "rounded-es"],
          "rounded-e": ["rounded-se", "rounded-ee"],
          "rounded-t": ["rounded-tl", "rounded-tr"],
          "rounded-r": ["rounded-tr", "rounded-br"],
          "rounded-b": ["rounded-br", "rounded-bl"],
          "rounded-l": ["rounded-tl", "rounded-bl"],
          "border-spacing": ["border-spacing-x", "border-spacing-y"],
          "border-w": ["border-w-s", "border-w-e", "border-w-t", "border-w-r", "border-w-b", "border-w-l"],
          "border-w-x": ["border-w-r", "border-w-l"],
          "border-w-y": ["border-w-t", "border-w-b"],
          "border-color": ["border-color-s", "border-color-e", "border-color-t", "border-color-r", "border-color-b", "border-color-l"],
          "border-color-x": ["border-color-r", "border-color-l"],
          "border-color-y": ["border-color-t", "border-color-b"],
          "scroll-m": ["scroll-mx", "scroll-my", "scroll-ms", "scroll-me", "scroll-mt", "scroll-mr", "scroll-mb", "scroll-ml"],
          "scroll-mx": ["scroll-mr", "scroll-ml"],
          "scroll-my": ["scroll-mt", "scroll-mb"],
          "scroll-p": ["scroll-px", "scroll-py", "scroll-ps", "scroll-pe", "scroll-pt", "scroll-pr", "scroll-pb", "scroll-pl"],
          "scroll-px": ["scroll-pr", "scroll-pl"],
          "scroll-py": ["scroll-pt", "scroll-pb"],
          touch: ["touch-x", "touch-y", "touch-pz"],
          "touch-x": ["touch"],
          "touch-y": ["touch"],
          "touch-pz": ["touch"]
        },
        conflictingClassGroupModifiers: {
          "font-size": ["leading"]
        }
      };
    };
    twMerge = /* @__PURE__ */ createTailwindMerge(getDefaultConfig);
  }
});

// src/lib/utils.ts
function cn(...inputs) {
  return twMerge(clsx(inputs));
}
var init_utils = __esm({
  "src/lib/utils.ts"() {
    init_clsx();
    init_bundle_mjs();
  }
});

// src/components/ui/button.tsx
var React3, import_jsx_runtime2, buttonVariants, Button;
var init_button = __esm({
  "src/components/ui/button.tsx"() {
    React3 = __toESM(require_react(), 1);
    init_dist2();
    init_dist3();
    init_utils();
    import_jsx_runtime2 = __toESM(require_jsx_runtime(), 1);
    buttonVariants = cva(
      "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
      {
        variants: {
          variant: {
            default: "bg-primary text-primary-foreground hover:bg-primary/90",
            destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
            outline: "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
            secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
            ghost: "hover:bg-accent hover:text-accent-foreground",
            link: "text-primary underline-offset-4 hover:underline"
          },
          size: {
            default: "h-10 px-4 py-2",
            sm: "h-9 rounded-md px-3",
            lg: "h-11 rounded-md px-8",
            icon: "h-10 w-10"
          }
        },
        defaultVariants: {
          variant: "default",
          size: "default"
        }
      }
    );
    Button = React3.forwardRef(
      ({ className, variant, size, asChild = false, ...props }, ref) => {
        const Comp = asChild ? Slot : "button";
        return /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(Comp, { className: cn(buttonVariants({ variant, size, className })), ref, ...props });
      }
    );
    Button.displayName = "Button";
  }
});

// node_modules/lucide-react/dist/esm/shared/src/utils.js
var toKebabCase, mergeClasses;
var init_utils2 = __esm({
  "node_modules/lucide-react/dist/esm/shared/src/utils.js"() {
    toKebabCase = (string) => string.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
    mergeClasses = (...classes) => classes.filter((className, index, array) => {
      return Boolean(className) && className.trim() !== "" && array.indexOf(className) === index;
    }).join(" ").trim();
  }
});

// node_modules/lucide-react/dist/esm/defaultAttributes.js
var defaultAttributes;
var init_defaultAttributes = __esm({
  "node_modules/lucide-react/dist/esm/defaultAttributes.js"() {
    defaultAttributes = {
      xmlns: "http://www.w3.org/2000/svg",
      width: 24,
      height: 24,
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: 2,
      strokeLinecap: "round",
      strokeLinejoin: "round"
    };
  }
});

// node_modules/lucide-react/dist/esm/Icon.js
var import_react, Icon;
var init_Icon = __esm({
  "node_modules/lucide-react/dist/esm/Icon.js"() {
    import_react = __toESM(require_react());
    init_defaultAttributes();
    init_utils2();
    Icon = (0, import_react.forwardRef)(
      ({
        color = "currentColor",
        size = 24,
        strokeWidth = 2,
        absoluteStrokeWidth,
        className = "",
        children,
        iconNode,
        ...rest
      }, ref) => {
        return (0, import_react.createElement)(
          "svg",
          {
            ref,
            ...defaultAttributes,
            width: size,
            height: size,
            stroke: color,
            strokeWidth: absoluteStrokeWidth ? Number(strokeWidth) * 24 / Number(size) : strokeWidth,
            className: mergeClasses("lucide", className),
            ...rest
          },
          [
            ...iconNode.map(([tag, attrs]) => (0, import_react.createElement)(tag, attrs)),
            ...Array.isArray(children) ? children : [children]
          ]
        );
      }
    );
  }
});

// node_modules/lucide-react/dist/esm/createLucideIcon.js
var import_react2, createLucideIcon;
var init_createLucideIcon = __esm({
  "node_modules/lucide-react/dist/esm/createLucideIcon.js"() {
    import_react2 = __toESM(require_react());
    init_utils2();
    init_Icon();
    createLucideIcon = (iconName, iconNode) => {
      const Component2 = (0, import_react2.forwardRef)(
        ({ className, ...props }, ref) => (0, import_react2.createElement)(Icon, {
          ref,
          iconNode,
          className: mergeClasses(`lucide-${toKebabCase(iconName)}`, className),
          ...props
        })
      );
      Component2.displayName = `${iconName}`;
      return Component2;
    };
  }
});

// node_modules/lucide-react/dist/esm/icons/calendar-days.js
var CalendarDays;
var init_calendar_days = __esm({
  "node_modules/lucide-react/dist/esm/icons/calendar-days.js"() {
    init_createLucideIcon();
    CalendarDays = createLucideIcon("CalendarDays", [
      ["path", { d: "M8 2v4", key: "1cmpym" }],
      ["path", { d: "M16 2v4", key: "4m81vk" }],
      ["rect", { width: "18", height: "18", x: "3", y: "4", rx: "2", key: "1hopcy" }],
      ["path", { d: "M3 10h18", key: "8toen8" }],
      ["path", { d: "M8 14h.01", key: "6423bh" }],
      ["path", { d: "M12 14h.01", key: "1etili" }],
      ["path", { d: "M16 14h.01", key: "1gbofw" }],
      ["path", { d: "M8 18h.01", key: "lrp35t" }],
      ["path", { d: "M12 18h.01", key: "mhygvu" }],
      ["path", { d: "M16 18h.01", key: "kzsmim" }]
    ]);
  }
});

// node_modules/lucide-react/dist/esm/icons/infinity.js
var Infinity2;
var init_infinity = __esm({
  "node_modules/lucide-react/dist/esm/icons/infinity.js"() {
    init_createLucideIcon();
    Infinity2 = createLucideIcon("Infinity", [
      [
        "path",
        {
          d: "M12 12c-2-2.67-4-4-6-4a4 4 0 1 0 0 8c2 0 4-1.33 6-4Zm0 0c2 2.67 4 4 6 4a4 4 0 0 0 0-8c-2 0-4 1.33-6 4Z",
          key: "1z0uae"
        }
      ]
    ]);
  }
});

// node_modules/lucide-react/dist/esm/icons/rotate-ccw.js
var RotateCcw;
var init_rotate_ccw = __esm({
  "node_modules/lucide-react/dist/esm/icons/rotate-ccw.js"() {
    init_createLucideIcon();
    RotateCcw = createLucideIcon("RotateCcw", [
      ["path", { d: "M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8", key: "1357e3" }],
      ["path", { d: "M3 3v5h5", key: "1xhq8a" }]
    ]);
  }
});

// node_modules/lucide-react/dist/esm/icons/x.js
var X;
var init_x = __esm({
  "node_modules/lucide-react/dist/esm/icons/x.js"() {
    init_createLucideIcon();
    X = createLucideIcon("X", [
      ["path", { d: "M18 6 6 18", key: "1bl5f8" }],
      ["path", { d: "m6 6 12 12", key: "d8bk6v" }]
    ]);
  }
});

// node_modules/lucide-react/dist/esm/lucide-react.js
var init_lucide_react = __esm({
  "node_modules/lucide-react/dist/esm/lucide-react.js"() {
    init_calendar_days();
    init_infinity();
    init_rotate_ccw();
    init_x();
  }
});

// src/hooks/useArcadeFlight.ts
function useArcadeFlight(durationMs) {
  const [progress, setProgress] = (0, import_react3.useState)(0);
  const [paused, setPaused] = (0, import_react3.useState)(false);
  const pausedRef = (0, import_react3.useRef)(false);
  const flightRef = (0, import_react3.useRef)(null);
  const rafRef = (0, import_react3.useRef)(null);
  const timerRef = (0, import_react3.useRef)(null);
  const stop = (0, import_react3.useCallback)(() => {
    if (rafRef.current !== null) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
    if (timerRef.current !== null) {
      window.clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  }, []);
  (0, import_react3.useEffect)(() => () => {
    stop();
    flightRef.current = null;
  }, [stop]);
  const fly = (0, import_react3.useCallback)((flight) => {
    const segment = ++flight.segment;
    flight.startedAt = performance.now();
    const isCurrent = () => flightRef.current === flight && flight.segment === segment && !pausedRef.current;
    const settle = () => {
      if (!isCurrent()) return;
      stop();
      flightRef.current = null;
      setProgress(1);
      flight.onSettle();
    };
    if (flight.elapsed >= durationMs) {
      settle();
      return;
    }
    const tick = (now) => {
      if (!isCurrent()) return;
      const elapsed = Math.min(durationMs, flight.elapsed + now - flight.startedAt);
      setProgress(elapsed / durationMs);
      if (elapsed < durationMs) {
        rafRef.current = requestAnimationFrame(tick);
        return;
      }
      settle();
    };
    rafRef.current = requestAnimationFrame(tick);
    timerRef.current = window.setTimeout(settle, durationMs - flight.elapsed + 60);
  }, [durationMs, stop]);
  const reset = (0, import_react3.useCallback)(() => {
    stop();
    flightRef.current = null;
    pausedRef.current = false;
    setPaused(false);
    setProgress(0);
  }, [stop]);
  const pause = (0, import_react3.useCallback)(() => {
    if (pausedRef.current) return;
    pausedRef.current = true;
    const flight = flightRef.current;
    if (flight) {
      flight.elapsed = Math.min(durationMs, flight.elapsed + performance.now() - flight.startedAt);
      flight.segment++;
      setProgress(flight.elapsed / durationMs);
    }
    stop();
    setPaused(true);
  }, [durationMs, stop]);
  const resume = (0, import_react3.useCallback)(() => {
    if (!pausedRef.current) return;
    pausedRef.current = false;
    setPaused(false);
    if (flightRef.current) fly(flightRef.current);
  }, [fly]);
  const launch = (0, import_react3.useCallback)((onSettle) => {
    if (pausedRef.current) return;
    stop();
    setProgress(0);
    flightRef.current = null;
    if (prefersReducedMotion()) {
      setProgress(1);
      onSettle();
      return;
    }
    const flight = { elapsed: 0, startedAt: 0, segment: 0, onSettle };
    flightRef.current = flight;
    fly(flight);
  }, [fly, stop]);
  return { progress, paused, launch, reset, pause, resume };
}
var import_react3, prefersReducedMotion;
var init_useArcadeFlight = __esm({
  "src/hooks/useArcadeFlight.ts"() {
    import_react3 = __toESM(require_react(), 1);
    prefersReducedMotion = () => typeof window !== "undefined" && typeof window.matchMedia === "function" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  }
});

// src/hooks/useRevealScroll.ts
function topInset() {
  const vh = window.innerHeight || document.documentElement.clientHeight;
  const vw = window.innerWidth || document.documentElement.clientWidth;
  let inset = 0;
  for (const x of [vw * 0.5, 6, vw - 6]) {
    for (const el of document.elementsFromPoint(x, 1)) {
      const pos = getComputedStyle(el).position;
      if (pos !== "fixed" && pos !== "sticky") continue;
      const r2 = el.getBoundingClientRect();
      if (r2.height === 0 || r2.height > vh * MAX_BAR) continue;
      if (r2.top > 2 || r2.bottom <= 0) continue;
      if (r2.bottom > inset) inset = r2.bottom;
    }
  }
  return inset;
}
function bottomInset() {
  const vh = window.innerHeight || document.documentElement.clientHeight;
  const vw = window.innerWidth || document.documentElement.clientWidth;
  let inset = 0;
  for (const x of [vw * 0.5, 6, vw - 6]) {
    for (const el of document.elementsFromPoint(x, vh - 2)) {
      const pos = getComputedStyle(el).position;
      if (pos !== "fixed" && pos !== "sticky") continue;
      const r2 = el.getBoundingClientRect();
      if (r2.height === 0 || r2.height > vh * MAX_BAR) continue;
      if (r2.bottom < vh - 2 || r2.top >= vh) continue;
      if (vh - r2.top > inset) inset = vh - r2.top;
    }
  }
  return inset;
}
function useRevealScroll(key, options) {
  const ref = (0, import_react4.useRef)(null);
  const firstRun = (0, import_react4.useRef)(true);
  const enabled = options?.enabled ?? true;
  const block = options?.block;
  const skipFirst = options?.skipFirst ?? true;
  (0, import_react4.useEffect)(() => {
    if (!enabled) return;
    if (firstRun.current) {
      firstRun.current = false;
      if (skipFirst) return;
    }
    const el = ref.current;
    if (!el || typeof window === "undefined") return;
    let raf2 = 0;
    const raf1 = requestAnimationFrame(() => {
      raf2 = requestAnimationFrame(() => {
        const node = ref.current;
        if (!node) return;
        const rect = node.getBoundingClientRect();
        if (rect.height === 0) return;
        const vh = window.innerHeight || document.documentElement.clientHeight;
        const top = topInset();
        const bottom = bottomInset();
        const readTop = top;
        const readBottom = vh - bottom;
        const visible = Math.max(0, Math.min(rect.bottom, readBottom) - Math.max(rect.top, readTop));
        const needed = Math.min(rect.height, MIN_LEAD);
        if (rect.top >= readTop - 2 && visible >= needed) return;
        const behavior = prefersReducedMotion2() ? "auto" : "smooth";
        const fits = rect.height <= readBottom - readTop - GAP;
        if (block && block !== "start" && fits) {
          node.scrollIntoView({ behavior, block, inline: "nearest" });
          return;
        }
        node.style.scrollMarginTop = `${readTop + GAP}px`;
        node.scrollIntoView({ behavior, block: "start", inline: "nearest" });
      });
    });
    return () => {
      cancelAnimationFrame(raf1);
      if (raf2) cancelAnimationFrame(raf2);
    };
  }, [key, enabled, block, skipFirst]);
  return ref;
}
var import_react4, prefersReducedMotion2, GAP, MIN_LEAD, MAX_BAR;
var init_useRevealScroll = __esm({
  "src/hooks/useRevealScroll.ts"() {
    import_react4 = __toESM(require_react(), 1);
    prefersReducedMotion2 = () => typeof window !== "undefined" && typeof window.matchMedia === "function" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    GAP = 12;
    MIN_LEAD = 160;
    MAX_BAR = 0.4;
  }
});

// src/lib/dateUtils.ts
function getTodayET() {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/New_York"
  }).format(/* @__PURE__ */ new Date());
}
var init_dateUtils = __esm({
  "src/lib/dateUtils.ts"() {
  }
});

// src/lib/dailyRecord.ts
function dailyRecordKey(slug, date) {
  return `${slug}-daily-${date}`;
}
function readDailyRecord(slug, today, validate) {
  try {
    const raw2 = localStorage.getItem(dailyRecordKey(slug, today));
    if (!raw2) return null;
    const parsed = JSON.parse(raw2);
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return null;
    const fields = parsed;
    if (fields.v !== 1 || fields.date !== today) return null;
    return validate(fields);
  } catch {
    return null;
  }
}
function writeDailyRecord(slug, today, fields) {
  try {
    localStorage.setItem(dailyRecordKey(slug, today), JSON.stringify({ ...fields, v: 1, date: today }));
    const mine = `${slug}-daily-`;
    const stale = [];
    for (let i = 0; i < localStorage.length; i += 1) {
      const k = localStorage.key(i);
      if (k && k.startsWith(mine) && k !== dailyRecordKey(slug, today)) stale.push(k);
    }
    for (const k of stale) localStorage.removeItem(k);
  } catch {
  }
}
var init_dailyRecord = __esm({
  "src/lib/dailyRecord.ts"() {
  }
});

// src/components/soccer-career/DrillPlayers.tsx
function DrillFigure({ x, y, tint, scale = 1, lean = 0, stride = 0, strike = 0, reach, wallHalfWidth }) {
  const { shirt, shorts } = COLORS[tint];
  const left = { x: -4 - stride * 4, y: -Math.max(0, stride) * 3 };
  const right = reach ?? { x: 4 + stride * 4 + strike * 13, y: -Math.max(0, -stride) * 3 - strike * 12 };
  return /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("g", { "data-drill-player": tint, "data-strike": strike.toFixed(3), transform: `translate(${x} ${y}) scale(${scale})`, pointerEvents: "none", children: [
    /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("ellipse", { cx: 0, cy: 2, rx: 10, ry: 2.5, fill: "#102f28", opacity: 0.3 }),
    /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("path", { d: `M -2 -10 Q ${-4 - stride * 2} -4 ${left.x} ${left.y}`, fill: "none", stroke: shorts, strokeWidth: 4.5, strokeLinecap: "round" }),
    /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("path", { "data-drill-reaching-leg": true, d: `M 3 -10 Q ${right.x * 0.45 + 3} ${right.y * 0.3 - 5} ${right.x} ${right.y}`, fill: "none", stroke: shorts, strokeWidth: 4.5, strokeLinecap: "round" }),
    /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("path", { d: `M ${left.x - 2} ${left.y} h 5`, stroke: BOOT, strokeWidth: 3, strokeLinecap: "round" }),
    /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("path", { "data-drill-boot": true, d: `M ${right.x - 1} ${right.y} h 5`, stroke: BOOT, strokeWidth: 3, strokeLinecap: "round" }),
    /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("g", { transform: `rotate(${lean} 0 -11)`, children: [
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("path", { d: "M -5 -24 Q 0 -27 5 -24 L 5 -10 Q 0 -8 -5 -10 Z", fill: shirt }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("path", { d: "M -4 -11 H 4", stroke: shorts, strokeWidth: 4, strokeLinecap: "round" }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("path", { d: wallHalfWidth ? `M ${-wallHalfWidth} -20 H ${wallHalfWidth}` : `M -5 -22 Q ${-9 - strike * 5} -19 ${-9 - strike * 5} -14 M 5 -22 Q ${9 + strike * 4} -20 ${10 + strike * 4} -17`, fill: "none", stroke: shirt, strokeWidth: 4.5, strokeLinecap: "round" }),
      !wallHalfWidth && /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("path", { d: `M ${-9 - strike * 5} -14 v 1 M ${10 + strike * 4} -17 v 1`, stroke: SKIN, strokeWidth: 3, strokeLinecap: "round" }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("path", { d: "M 0 -27 V -25", stroke: SKIN, strokeWidth: 4 }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("circle", { cy: -30.5, r: 4.7, fill: SKIN }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("path", { d: "M -4.4 -32 Q -1 -38 4.4 -32", fill: "#302c27" }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("path", { d: "M -3 -23 L -2 -13", stroke: "white", strokeOpacity: 0.22, strokeWidth: 1.5 })
    ] })
  ] });
}
function DrillKeeper({ origin, glove, contact, catching = false }) {
  const dx = glove.x - origin.x;
  const dy = glove.y - origin.y;
  const distance = Math.hypot(dx, dy);
  const direction = distance > 0.01 ? { x: dx / distance, y: dy / distance } : { x: 0, y: -1 };
  const extension = Math.min(1, distance / 45);
  const reach = 14 + extension * 8;
  const chest = { x: glove.x - direction.x * reach, y: glove.y - direction.y * reach };
  const angle = Math.atan2(direction.y, direction.x) * 180 / Math.PI + 90;
  const hands = contact ?? glove;
  const across = { x: -direction.y, y: direction.x };
  return /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("g", { "data-drill-keeper": true, "data-catching": catching, "data-glove-x": glove.x.toFixed(3), "data-glove-y": glove.y.toFixed(3), pointerEvents: "none", children: [
    /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("g", { "data-drill-keeper-body": true, transform: `translate(${chest.x} ${chest.y}) rotate(${angle})`, children: [
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("path", { d: `M -3 9 Q ${-5 - extension * 6} ${18 + extension * 3} ${-4 - extension * 9} 25 M 3 9 Q ${7 + extension * 7} 15 ${6 + extension * 6} ${22 - extension * 5}`, fill: "none", stroke: COLORS.keeper.shorts, strokeWidth: 4.5, strokeLinecap: "round" }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("path", { d: `M ${-6 - extension * 9} 25 h 5 M ${4 + extension * 6} ${22 - extension * 5} h 5`, stroke: BOOT, strokeWidth: 3, strokeLinecap: "round" }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("path", { d: "M -6 -5 Q 0 -8 6 -5 L 5 11 H -5 Z", fill: COLORS.keeper.shirt }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("path", { d: "M -4 10 H 4", stroke: COLORS.keeper.shorts, strokeWidth: 4, strokeLinecap: "round" }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("circle", { cy: -12, r: 5, fill: SKIN }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("path", { d: "M -4.7 -14 Q 0 -20 4.7 -14", fill: "#302c27" })
    ] }),
    [-1, 1].map((side) => {
      const shoulder = { x: chest.x + across.x * side * 5, y: chest.y + across.y * side * 5 };
      const hand = { x: hands.x + across.x * side * (catching ? 2 : 4), y: hands.y + across.y * side * (catching ? 2 : 4) };
      return /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("g", { children: [
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("path", { d: `M ${shoulder.x} ${shoulder.y} Q ${(shoulder.x + hand.x) / 2 + across.x * side * 4} ${(shoulder.y + hand.y) / 2 + across.y * side * 4} ${hand.x} ${hand.y}`, fill: "none", stroke: COLORS.keeper.shirt, strokeWidth: 4.5, strokeLinecap: "round" }),
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("ellipse", { cx: hand.x, cy: hand.y, rx: 3.4, ry: 4.2, fill: "#f4f1df", stroke: "#b9c9bf", strokeWidth: 0.8 })
      ] }, side);
    })
  ] });
}
var import_jsx_runtime3, COLORS, SKIN, BOOT;
var init_DrillPlayers = __esm({
  "src/components/soccer-career/DrillPlayers.tsx"() {
    import_jsx_runtime3 = __toESM(require_jsx_runtime(), 1);
    COLORS = {
      wall: { shirt: "#6aafe5", shorts: "#294b70" },
      keeper: { shirt: "#f5c64b", shorts: "#594725" },
      attacker: { shirt: "#e86a70", shorts: "#6a303b" },
      you: { shirt: "#51c79a", shorts: "#215d4b" }
    };
    SKIN = "#dbab87";
    BOOT = "#122c29";
  }
});

// src/components/soccer-career/DrillBoard.tsx
var DrillBoard_exports = {};
__export(DrillBoard_exports, {
  default: () => DrillBoard
});
function matchInput(kind, inp) {
  if (kind === "wallshot") {
    const w = inp;
    const o2 = { x: r4(w.x), y: r4(w.y), power: r4(w.power), press: r4(w.press) };
    return { inp: o2, packed: [o2.x, o2.y, o2.power, o2.press] };
  }
  if (kind === "tackle") {
    const t = inp;
    const o2 = { x: r4(t.x), y: r4(t.y), press: r4(t.press) };
    return { inp: o2, packed: [o2.x, o2.y, o2.press] };
  }
  const g = inp;
  const o = { dx: r4(g.dx), dy: r4(g.dy), release: r4(g.release) };
  return { inp: o, packed: [o.dx, o.dy, o.release] };
}
function readRecord(slug, today) {
  return readDailyRecord(slug, today, (f) => {
    if (typeof f.score !== "number" || !Number.isFinite(f.score)) return null;
    if (typeof f.count !== "number" || !Number.isFinite(f.count) || f.count < 0 || f.count > ROUNDS_PER_RUN) return null;
    if (typeof f.banked !== "boolean") return null;
    const rounds = f.rounds === void 0 ? ROUNDS_PER_RUN : f.rounds;
    if (typeof rounds !== "number" || !Number.isInteger(rounds) || rounds < 0 || rounds > ROUNDS_PER_RUN) return null;
    if (rounds < ROUNDS_PER_RUN && f.banked === true) return null;
    return { score: f.score, count: f.count, banked: f.banked, rounds };
  });
}
function buildRun(kind, seed) {
  if (kind === "wallshot") return buildWallShotRun(seed);
  if (kind === "tackle") return buildTackleRun(seed);
  return buildGloveRun(seed);
}
function maxRun(kind, setups) {
  if (kind === "wallshot") return maxWallShotScore(setups);
  if (kind === "tackle") return maxTackleScore(setups);
  return maxGloveScore(setups);
}
function wallShotBall(result, progress) {
  const p = Math.max(0, Math.min(1, progress));
  const wallAt = 0.45;
  const atWall = result.path[Math.round(result.path.length * wallAt)];
  const wallY = (height) => GOAL_BOT + 3 - Math.max(0, Math.min(1, height)) * 2;
  const contact = { x: toViewX(atWall.x), y: wallY(atWall.y) };
  const short = !result.hitWall && !result.hitPost && !result.onTarget && Math.abs(result.x) < 1 && result.y > 0 && result.y < 1;
  const depth = result.hitWall ? Math.min(p, wallAt) : short ? Math.min(p, 0.74) : p;
  const sample = result.path[Math.min(result.path.length - 1, Math.round(depth * (result.path.length - 1)))];
  if (p <= wallAt) {
    const approach = p / wallAt;
    return { x: VIEW_W / 2 + (toViewX(sample.x) - VIEW_W / 2) * approach, y: VIEW_H - 12 + (wallY(sample.y) - (VIEW_H - 12)) * approach };
  }
  const afterWall = (p - wallAt) / (1 - wallAt);
  if (result.hitWall) {
    const rebound = afterWall * (2 - afterWall);
    return { x: contact.x + (VIEW_W / 2 - contact.x) * rebound * 0.07, y: contact.y + rebound * 17 };
  }
  if (short) return { x: toViewX(sample.x), y: contact.y + (GOAL_BOT + 10 - contact.y) * afterWall };
  return { x: toViewX(sample.x), y: contact.y + (toViewY(sample.y) - contact.y) * afterWall };
}
function DrillBoard({ career, canBank, onBank, onBack, match }) {
  const todayStr = (0, import_react5.useRef)(getTodayET()).current;
  const kind = match ? match.kind : drillForPosition(career.position);
  const meta = DRILL_META[kind];
  const [record, setRecord] = (0, import_react5.useState)(() => match ? null : readRecord(meta.slug, todayStr));
  const [mode, setMode] = (0, import_react5.useState)(match ? "match" : "daily");
  const [phase, setPhase] = (0, import_react5.useState)(match ? "ready" : "intro");
  const [setups, setSetups] = (0, import_react5.useState)(() => match ? buildRun(match.kind, match.seed) : []);
  const [idx, setIdx] = (0, import_react5.useState)(match ? match.round : 0);
  const toldRef = (0, import_react5.useRef)(false);
  const [score, setScore] = (0, import_react5.useState)(0);
  const [count3, setCount] = (0, import_react5.useState)(0);
  const [fouls, setFouls] = (0, import_react5.useState)(0);
  const [result, setResult] = (0, import_react5.useState)(null);
  const [input, setInput] = (0, import_react5.useState)(null);
  const { progress: flight, launch, reset: resetFlight } = useArcadeFlight(FLIGHT_MS);
  const [reducedMotion2, setReducedMotion] = (0, import_react5.useState)(prefersReducedMotion3);
  (0, import_react5.useEffect)(() => {
    const query = window.matchMedia?.("(prefers-reduced-motion: reduce)");
    if (!query) return;
    const change = () => setReducedMotion(query.matches);
    query.addEventListener("change", change);
    return () => query.removeEventListener("change", change);
  }, []);
  const rngRef = (0, import_react5.useRef)(lehmer(1));
  const savedRef = (0, import_react5.useRef)(false);
  const startRef = (0, import_react5.useRef)(0);
  const [now, setNow] = (0, import_react5.useState)(0);
  const elapsed = () => (performance.now() - startRef.current) / 1e3;
  const [aimX, setAimX] = (0, import_react5.useState)(0);
  const [aimY, setAimY] = (0, import_react5.useState)(0.8);
  const [power, setPower] = (0, import_react5.useState)(0.65);
  const [cursor, setCursor] = (0, import_react5.useState)({ x: 0.5, y: 0.5 });
  const [drag, setDrag] = (0, import_react5.useState)({ dx: 0, dy: 0 });
  const [dragging, setDragging] = (0, import_react5.useState)(false);
  const dragStart = (0, import_react5.useRef)(null);
  const boardRef = (0, import_react5.useRef)(null);
  const setup = setups[idx] ?? null;
  const isDone = phase === "done";
  const best = setups.length ? maxRun(kind, setups) : 0;
  const revealRef = useRevealScroll(`${phase}-${idx}`);
  (0, import_react5.useEffect)(() => {
    if (phase !== "playing") return;
    let raf = 0;
    let timer = 0;
    const tick = () => {
      setNow(elapsed());
      raf = requestAnimationFrame(tick);
    };
    if (prefersReducedMotion3()) timer = window.setInterval(() => setNow(elapsed()), 125);
    else raf = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(raf);
      window.clearInterval(timer);
    };
  }, [phase]);
  const resetControls = (0, import_react5.useCallback)(() => {
    setAimX(0);
    setAimY(0.8);
    setPower(0.65);
    setCursor({ x: 0.5, y: 0.5 });
    setDrag({ dx: 0, dy: 0 });
    setDragging(false);
    dragStart.current = null;
  }, []);
  const start = (0, import_react5.useCallback)((m) => {
    if (m === "daily" && record) {
      const done = record.rounds >= ROUNDS_PER_RUN;
      savedRef.current = done;
      setMode("daily");
      const seed2 = drillSeed(kind, todayStr);
      rngRef.current = lehmer(seed2 ^ 1592594996);
      setSetups(buildRun(kind, seed2));
      setIdx(done ? ROUNDS_PER_RUN - 1 : record.rounds);
      setScore(record.score);
      setCount(record.count);
      setFouls(0);
      setResult(null);
      setInput(null);
      resetFlight();
      resetControls();
      setPhase(done ? "done" : "ready");
      return;
    }
    const seed = m === "daily" ? drillSeed(kind, todayStr) : Math.floor(Math.random() * 2147483645) + 1;
    rngRef.current = lehmer(seed ^ 1592594996);
    resetFlight();
    setMode(m);
    setSetups(buildRun(kind, seed));
    setIdx(0);
    setScore(0);
    setCount(0);
    setFouls(0);
    setResult(null);
    setInput(null);
    resetControls();
    savedRef.current = false;
    setPhase("ready");
  }, [record, kind, todayStr, resetFlight, resetControls]);
  const beginRound = (0, import_react5.useCallback)(() => {
    if (phase !== "ready") return;
    startRef.current = performance.now();
    setNow(0);
    setPhase("playing");
  }, [phase]);
  const resolve2 = (0, import_react5.useCallback)((raw2) => {
    if (phase !== "playing" || !setup) return;
    const held = match ? matchInput(kind, raw2) : null;
    const inp = held ? held.inp : raw2;
    const rng = match ? match.rng() : rngRef.current;
    let r2;
    let won;
    let foul = false;
    if (kind === "wallshot") {
      const w = takeWallShot(inp, setup, rng);
      r2 = w;
      won = w.won;
    } else if (kind === "tackle") {
      const tk = makeTackle(inp, setup);
      r2 = tk;
      won = tk.won;
      foul = tk.foul;
    } else {
      const g = makeSave(inp, setup);
      r2 = g;
      won = g.saved;
    }
    setInput(inp);
    setResult(r2);
    setDragging(false);
    setPhase("flying");
    launch(() => {
      setScore((s) => s + r2.points);
      if (won) setCount((c) => c + 1);
      if (foul) setFouls((f) => f + 1);
      setPhase("roundEnd");
      if (match && held && !toldRef.current) {
        toldRef.current = true;
        match.onResult({ won, points: r2.points, verdict: r2.verdict, input: held.packed });
      }
    });
  }, [phase, setup, kind, launch, match]);
  (0, import_react5.useEffect)(() => {
    if (phase !== "playing" || !setup) return;
    if (kind === "tackle" && now >= tackleDeadline(setup)) resolve2({ x: -1, y: -1, press: tackleDeadline(setup) });
    else if (kind === "gloves" && now >= gloveDeadline(setup)) resolve2({ dx: drag.dx, dy: drag.dy, release: gloveDeadline(setup) + 0.01 });
  }, [now, phase, setup, kind, resolve2, drag]);
  const next = (0, import_react5.useCallback)(() => {
    resetFlight();
    if (idx + 1 >= ROUNDS_PER_RUN) {
      setPhase("done");
      return;
    }
    setIdx((i) => i + 1);
    setResult(null);
    setInput(null);
    resetControls();
    setPhase("ready");
  }, [idx, resetFlight, resetControls]);
  (0, import_react5.useEffect)(() => {
    if (mode !== "daily" || savedRef.current) return;
    if (phase !== "roundEnd" && phase !== "done") return;
    const rounds = phase === "done" ? ROUNDS_PER_RUN : Math.min(ROUNDS_PER_RUN, idx + 1);
    if (phase === "done") savedRef.current = true;
    const rec = { score, count: count3, banked: false, rounds };
    writeDailyRecord(meta.slug, todayStr, rec);
    setRecord(rec);
  }, [phase, mode, score, count3, idx, meta.slug, todayStr]);
  const bank = (0, import_react5.useCallback)(() => {
    if (!record || record.banked || record.rounds < ROUNDS_PER_RUN || !canBank) return;
    onBank(kind, record.count);
    const rec = { ...record, banked: true };
    writeDailyRecord(meta.slug, todayStr, rec);
    setRecord(rec);
  }, [record, canBank, onBank, kind, meta.slug, todayStr]);
  const strike = (0, import_react5.useCallback)(() => resolve2({ x: aimX, y: aimY, power, press: elapsed() }), [resolve2, aimX, aimY, power]);
  const tackleAt = (0, import_react5.useCallback)((x, y) => resolve2({ x, y, press: elapsed() }), [resolve2]);
  const dive = (0, import_react5.useCallback)(() => resolve2({ dx: drag.dx, dy: drag.dy, release: elapsed() }), [resolve2, drag]);
  (0, import_react5.useEffect)(() => {
    if (phase !== "playing" && phase !== "ready") return;
    const down = (e) => {
      if (phase === "ready") {
        if (e.key === " " || e.key === "Enter") {
          beginRound();
          e.preventDefault();
        }
        return;
      }
      if (kind === "wallshot") {
        if (e.key === "ArrowLeft") {
          setAimX((x) => Math.max(-1.15, x - 0.06));
          e.preventDefault();
        } else if (e.key === "ArrowRight") {
          setAimX((x) => Math.min(1.15, x + 0.06));
          e.preventDefault();
        } else if (e.key === "ArrowUp") {
          setAimY((y) => Math.min(1.1, y + 0.05));
          e.preventDefault();
        } else if (e.key === "ArrowDown") {
          setAimY((y) => Math.max(0, y - 0.05));
          e.preventDefault();
        } else if (e.key === "w" || e.key === "W") setPower((p) => Math.min(1, p + 0.05));
        else if (e.key === "s" || e.key === "S") setPower((p) => Math.max(0.3, p - 0.05));
        else if (e.key === " " && !e.repeat) {
          strike();
          e.preventDefault();
        }
      } else if (kind === "tackle") {
        if (e.key === "ArrowLeft") {
          setCursor((c) => ({ ...c, x: Math.max(0, c.x - 0.04) }));
          e.preventDefault();
        } else if (e.key === "ArrowRight") {
          setCursor((c) => ({ ...c, x: Math.min(1, c.x + 0.04) }));
          e.preventDefault();
        } else if (e.key === "ArrowUp") {
          setCursor((c) => ({ ...c, y: Math.max(0, c.y - 0.04) }));
          e.preventDefault();
        } else if (e.key === "ArrowDown") {
          setCursor((c) => ({ ...c, y: Math.min(1, c.y + 0.04) }));
          e.preventDefault();
        } else if (e.key === " " && !e.repeat) {
          tackleAt(cursor.x, cursor.y);
          e.preventDefault();
        }
      } else {
        const step = 0.35;
        if (e.key === "ArrowLeft") {
          setDrag((d) => ({ ...d, dx: Math.max(-GLOVE_MAX_REACH, d.dx - step) }));
          e.preventDefault();
        } else if (e.key === "ArrowRight") {
          setDrag((d) => ({ ...d, dx: Math.min(GLOVE_MAX_REACH, d.dx + step) }));
          e.preventDefault();
        } else if (e.key === "ArrowUp") {
          setDrag((d) => ({ ...d, dy: Math.min(GLOVE_MAX_REACH, d.dy + step) }));
          e.preventDefault();
        } else if (e.key === "ArrowDown") {
          setDrag((d) => ({ ...d, dy: Math.max(-1, d.dy - step) }));
          e.preventDefault();
        } else if (e.key === " " && !e.repeat) {
          dive();
          e.preventDefault();
        }
      }
    };
    window.addEventListener("keydown", down);
    return () => window.removeEventListener("keydown", down);
  }, [phase, kind, beginRound, strike, tackleAt, dive, cursor]);
  const viewPoint = (clientX, clientY) => {
    const el = boardRef.current;
    if (!el) return null;
    const box = el.getBoundingClientRect();
    return { vx: (clientX - box.left) / box.width * VIEW_W, vy: (clientY - box.top) / box.height * VIEW_H, scale: box.width / VIEW_W };
  };
  const onDown = (e) => {
    if (phase !== "playing") return;
    const p = viewPoint(e.clientX, e.clientY);
    if (!p) return;
    if (kind === "wallshot") {
      setAimX(Math.max(-1.15, Math.min(1.15, (p.vx - GOAL_L) / (GOAL_R - GOAL_L) * 2 - 1)));
      setAimY(Math.max(0, Math.min(1.1, (GOAL_BOT - p.vy) / (GOAL_BOT - GOAL_TOP))));
      setDragging(true);
    } else if (kind === "tackle") {
      const x = p.vx / VIEW_W;
      const y = p.vy / VIEW_H;
      setCursor({ x, y });
      tackleAt(x, y);
    } else {
      dragStart.current = { x: e.clientX, y: e.clientY };
      setDrag({ dx: 0, dy: 0 });
      setDragging(true);
    }
  };
  const onMove = (e) => {
    if (phase !== "playing" || !dragging) return;
    const p = viewPoint(e.clientX, e.clientY);
    if (!p) return;
    if (kind === "wallshot") {
      setAimX(Math.max(-1.15, Math.min(1.15, (p.vx - GOAL_L) / (GOAL_R - GOAL_L) * 2 - 1)));
      setAimY(Math.max(0, Math.min(1.1, (GOAL_BOT - p.vy) / (GOAL_BOT - GOAL_TOP))));
    } else if (kind === "gloves" && dragStart.current) {
      const dxM = (e.clientX - dragStart.current.x) / p.scale / VX_PER_M;
      const dyM = -((e.clientY - dragStart.current.y) / p.scale) / VY_PER_M;
      setDrag({ dx: Math.max(-GLOVE_MAX_REACH, Math.min(GLOVE_MAX_REACH, dxM)), dy: Math.max(-1, Math.min(GLOVE_MAX_REACH, dyM)) });
    }
  };
  const onUp = () => {
    if (phase !== "playing" || !dragging) return;
    setDragging(false);
    if (kind === "wallshot") strike();
    else if (kind === "gloves") dive();
  };
  const drawFlight = reducedMotion2 && result ? 1 : flight;
  let tDraw = phase === "playing" ? now : 0;
  if ((phase === "flying" || phase === "roundEnd") && input && setup) {
    if (kind === "wallshot") {
      const w = input;
      tDraw = w.press + drawFlight * (wallTravel(w.power) / 0.45);
    } else if (kind === "tackle") {
      const tk = input;
      tDraw = tk.press + drawFlight * 0.45;
    } else {
      const g = input;
      const arrival = gloveDeadline(setup);
      const from = Math.min(g.release, arrival);
      tDraw = from + drawFlight * (arrival - from);
    }
  }
  const headroom = drillHeadroom(career);
  const boost = drillBoost(sessionScore(count3), headroom);
  if (phase === "intro") {
    return /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "p-4 space-y-3", children: [
      /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "flex items-center justify-between text-xs font-bold", children: [
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("button", { onClick: onBack, className: "text-muted-foreground hover:text-foreground", children: "\u2039 Drills" }),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("span", { className: "text-muted-foreground", children: [
          career.position,
          " drill"
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "rounded-2xl border border-border bg-muted/10 p-4 text-center", children: [
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("div", { className: "text-4xl", children: meta.emoji }),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("p", { className: "mt-1 text-lg font-black", children: meta.name }),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("p", { className: "mx-auto mt-2 max-w-sm text-[12px] text-muted-foreground", children: [
          kind === "wallshot" && "A wall with a gap that opens and closes. Drag the goal to aim across and up, set your power, and let go as the gap opens. Pace gets there sooner and sprays wider. Ten shots.",
          kind === "tackle" && "He runs across you and every touch pushes the ball off his feet for a moment. Tap the ball, not the man, while it is loose. Tap him, or go through the ball while it sits at his feet, and it is a foul. Ten runs.",
          kind === "gloves" && "Hold and drag to set your dive: the direction is where you drag, the reach is how far. Let go to dive. A full stretch takes longer to get there than a hop, so the corner has to be left for early. Ten shots."
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("p", { className: "mt-2 text-[11px] text-muted-foreground", children: [
          "Trains ",
          meta.statLabel,
          ". Today's ten count once, ",
          ROUNDS_PER_RUN / 2,
          " wins pay +1 and 8 pay +2 with next season's growth, never past your ceiling. Practice is free and banks nothing."
        ] }),
        record && /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("p", { className: "mt-2 text-[11px] font-bold text-sky-300", children: record.rounds < ROUNDS_PER_RUN ? `Today: ${record.rounds} of ${ROUNDS_PER_RUN} rounds played, ${record.count} ${meta.verb}, ${record.score} points so far.` : `Today: ${record.count} of ${ROUNDS_PER_RUN} ${meta.verb}, ${record.score} points${record.banked ? ", banked" : ""}.` })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "flex flex-col gap-2 sm:flex-row", children: [
        /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(Button, { onClick: () => start("daily"), className: "flex-1 gap-2", children: [
          /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(CalendarDays, { className: "h-4 w-4" }),
          " ",
          !record ? "Today's ten" : record.rounds < ROUNDS_PER_RUN ? "Finish today's ten" : "Today's result"
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(Button, { variant: "secondary", onClick: () => start("unlimited"), className: "flex-1 gap-2", children: [
          /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(Infinity2, { className: "h-4 w-4" }),
          " Practice"
        ] })
      ] })
    ] });
  }
  return /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "p-4 space-y-3", children: [
    match ? /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "text-center text-xs font-bold", "data-drill-match": kind, children: [
      meta.emoji,
      " ",
      meta.name,
      ": one go"
    ] }) : /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "flex items-center justify-between text-xs font-bold", children: [
      /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("button", { onClick: () => {
        resetFlight();
        setPhase("intro");
      }, className: "text-muted-foreground hover:text-foreground", children: [
        "\u2039 ",
        meta.name
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("span", { children: [
        "Round ",
        Math.min(idx + 1, ROUNDS_PER_RUN),
        "/",
        ROUNDS_PER_RUN
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("span", { className: "text-emerald-400", children: [
        count3,
        " ",
        meta.verb
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("span", { className: "text-amber-300 tabular-nums", children: [
        score,
        " pts"
      ] })
    ] }),
    setup && /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("p", { className: "text-center text-[11px] text-muted-foreground", children: setup.label }),
    /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(
      "svg",
      {
        "data-drill-board": kind,
        "data-drill-phase": phase,
        "data-drill-motion": reducedMotion2 ? "reduced" : "full",
        "data-drill-time": tDraw,
        ref: boardRef,
        viewBox: `0 0 ${VIEW_W} ${VIEW_H}`,
        className: cn("w-full touch-none select-none rounded-2xl border border-border", kind === "tackle" ? "bg-[hsl(140_35%_20%)]" : "bg-[hsl(140_35%_18%)]"),
        role: "img",
        "aria-label": setup ? `${meta.name}: ${setup.label}` : meta.name,
        onPointerDown: onDown,
        onPointerMove: onMove,
        onPointerUp: onUp,
        onPointerCancel: onUp,
        children: [
          [0, 1, 2, 3, 4, 5].map((i) => /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("rect", { x: 0, y: VIEW_H / 6 * i, width: VIEW_W, height: VIEW_H / 6, fill: i % 2 ? "hsl(140 35% 20%)" : "hsl(140 35% 17%)" }, i)),
          kind !== "tackle" && /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(import_jsx_runtime4.Fragment, { children: [
            /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("rect", { x: GOAL_L - 26, y: GOAL_TOP - 6, width: GOAL_R - GOAL_L + 52, height: GOAL_BOT - GOAL_TOP + 6, fill: "none", stroke: "hsl(140 20% 40%)", strokeWidth: 1 }),
            /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("g", { opacity: 0.5, children: [
              Array.from({ length: 13 }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("line", { x1: GOAL_L + i * (GOAL_R - GOAL_L) / 12, y1: GOAL_TOP, x2: GOAL_L + i * (GOAL_R - GOAL_L) / 12, y2: GOAL_BOT, stroke: "hsl(0 0% 85%)", strokeWidth: 0.4 }, `v${i}`)),
              Array.from({ length: 7 }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("line", { x1: GOAL_L, y1: GOAL_TOP + i * (GOAL_BOT - GOAL_TOP) / 6, x2: GOAL_R, y2: GOAL_TOP + i * (GOAL_BOT - GOAL_TOP) / 6, stroke: "hsl(0 0% 85%)", strokeWidth: 0.4 }, `h${i}`))
            ] }),
            /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("line", { x1: GOAL_L, y1: GOAL_TOP, x2: GOAL_L, y2: GOAL_BOT, stroke: "white", strokeWidth: 3.5, strokeLinecap: "round" }),
            /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("line", { x1: GOAL_R, y1: GOAL_TOP, x2: GOAL_R, y2: GOAL_BOT, stroke: "white", strokeWidth: 3.5, strokeLinecap: "round" }),
            /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("line", { x1: GOAL_L, y1: GOAL_TOP, x2: GOAL_R, y2: GOAL_TOP, stroke: "white", strokeWidth: 3.5, strokeLinecap: "round" })
          ] }),
          kind === "wallshot" && setup && (() => {
            const w = setup;
            const r2 = result;
            const gap = wallGapAt(w, tDraw);
            const men = [];
            for (let k = 0; k < 14; k += 1) {
              const left = w.gapCentre - gap - WALL_MAN_HALF_STEP - WALL_MAN_STEP * k;
              const right = w.gapCentre + gap + WALL_MAN_HALF_STEP + WALL_MAN_STEP * k;
              if (left > -1.5) men.push(left);
              if (right < 1.5) men.push(right);
            }
            const restX = toViewX(w.keeperLean * 0.18);
            const kx = r2 ? toViewX(r2.keeperX) : restX;
            const ky = r2 ? toViewY(r2.keeperY) : GOAL_BOT - 20;
            const dive2 = r2 && phase !== "playing" ? drawFlight : 0;
            const ball = r2 && phase !== "playing" ? wallShotBall(r2, drawFlight) : null;
            const glove = { x: restX + (kx - restX) * dive2, y: GOAL_BOT - 20 + (ky - (GOAL_BOT - 20)) * dive2 };
            const catchProgress = r2?.saved ? Math.max(0, (drawFlight - 0.8) / 0.2) : 0;
            const jump = r2 && !reducedMotion2 ? Math.sin(Math.PI * Math.min(1, drawFlight / 0.65)) * 5 : 0;
            const swing = r2 ? Math.sin(drawFlight * Math.PI) : 0;
            return /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(import_jsx_runtime4.Fragment, { children: [
              /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
                DrillKeeper,
                {
                  origin: { x: restX, y: GOAL_BOT - 20 },
                  glove,
                  catching: !!r2?.saved && drawFlight >= 0.8,
                  contact: r2?.saved ? { x: glove.x + (toViewX(r2.x) - glove.x) * catchProgress, y: glove.y + (toViewY(r2.y) - glove.y) * catchProgress } : void 0
                }
              ),
              men.map((m, i) => /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(DrillFigure, { x: toViewX(m), y: GOAL_BOT + 26 - jump, tint: "wall", scale: 1.15, wallHalfWidth: WALL_MAN_HALF_STEP * ((GOAL_R - GOAL_L) / 2) / 1.15 + 0.4 }, i)),
              /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
                DrillFigure,
                {
                  x: 164,
                  y: 201,
                  tint: "you",
                  scale: 1.1,
                  lean: r2 ? 7 + swing * 6 : -5,
                  strike: r2 ? 0.5 + swing * 0.5 : 0,
                  reach: r2 ? { x: 14 + swing * 6, y: -3 - swing * 14 } : void 0
                }
              ),
              phase === "playing" && /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(import_jsx_runtime4.Fragment, { children: [
                /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("path", { d: `M ${VIEW_W / 2} ${VIEW_H - 12} L ${toViewX(aimX)} ${toViewY(aimY)}`, fill: "none", stroke: "hsl(var(--primary))", strokeWidth: 1.4, strokeDasharray: "4 4", opacity: 0.75 }),
                /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("circle", { cx: toViewX(aimX), cy: toViewY(aimY), r: 7, fill: "none", stroke: "hsl(var(--primary))", strokeWidth: 2 }),
                /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("circle", { cx: toViewX(aimX), cy: toViewY(aimY), r: 1.6, fill: "hsl(var(--primary))" })
              ] }),
              /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("circle", { "data-drill-ball": true, cx: ball ? ball.x : VIEW_W / 2, cy: ball ? ball.y : VIEW_H - 12, r: ball ? 4 + drawFlight * 1.6 : 4.5, fill: "white", stroke: "hsl(0 0% 55%)", strokeWidth: 0.7 })
            ] });
          })(),
          kind === "tackle" && setup && (() => {
            const tk = setup;
            const r2 = result;
            const inp = input;
            const live = phase === "playing" || phase === "flying" || phase === "roundEnd";
            const feet = tackleFeetAt(tk, live ? tDraw : 0);
            const ball = tackleBallAt(tk, r2?.won && inp ? inp.press : live ? tDraw : 0);
            const pressed = inp && inp.x >= 0 ? { x: inp.x * VIEW_W, y: inp.y * VIEW_H } : null;
            const stride = live && !reducedMotion2 ? Math.sin(tDraw * 15) * 0.85 : 0;
            const recovery = Math.max(0, (drawFlight - 0.72) / 0.28);
            const body = pressed ? { x: pressed.x + tk.dir * 26, y: Math.min(VIEW_H + 22, pressed.y + 28) + (1 - drawFlight) * 45 - recovery * 6 } : null;
            const contact = pressed ? { x: r2?.won ? ball.x * VIEW_W : pressed.x, y: r2?.won ? ball.y * VIEW_H : pressed.y } : null;
            const reach = body && contact ? { x: (contact.x - body.x) / 1.25 * drawFlight, y: (contact.y - body.y) / 1.25 * drawFlight } : void 0;
            return /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(import_jsx_runtime4.Fragment, { children: [
              /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("line", { x1: 0, y1: VIEW_H * 0.5, x2: VIEW_W, y2: VIEW_H * 0.5, stroke: "hsl(0 0% 85%)", strokeWidth: 0.6, opacity: 0.35 }),
              /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("circle", { cx: VIEW_W / 2, cy: VIEW_H * 0.5, r: 30, fill: "none", stroke: "hsl(0 0% 85%)", strokeWidth: 0.6, opacity: 0.35 }),
              /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(DrillFigure, { x: feet.x * VIEW_W, y: feet.y * VIEW_H, tint: "attacker", lean: tk.dir * 8, stride, scale: 1.3 }),
              /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("circle", { "data-drill-ball": true, cx: ball.x * VIEW_W, cy: ball.y * VIEW_H, r: 4.5, fill: "white", stroke: "hsl(0 0% 55%)", strokeWidth: 0.7 }),
              phase === "playing" && /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("circle", { cx: cursor.x * VIEW_W, cy: cursor.y * VIEW_H, r: 9, fill: "none", stroke: "hsl(var(--primary))", strokeWidth: 1.4, strokeDasharray: "3 3", opacity: 0.8 }),
              pressed && body && /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(import_jsx_runtime4.Fragment, { children: [
                /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(DrillFigure, { x: body.x, y: body.y, tint: "you", lean: -tk.dir * (24 * drawFlight - recovery * 14), reach, scale: 1.25 }),
                /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("circle", { cx: pressed.x, cy: pressed.y, r: 10, fill: "none", stroke: r2?.won ? "hsl(150 70% 60%)" : r2?.foul ? "hsl(0 80% 60%)" : "hsl(45 90% 62%)", strokeWidth: 2 })
              ] })
            ] });
          })(),
          kind === "gloves" && setup && (() => {
            const g = setup;
            const inp = input;
            const r2 = result;
            const live = phase === "playing" || phase === "flying" || phase === "roundEnd";
            const t = live ? tDraw : 0;
            const glove = inp ? gloveAt(inp, t) : { ...GLOVE_ORIGIN };
            const p = gloveBallProgress(g, t);
            const side = g.target.x >= GLOVE_ORIGIN.x ? 1 : -1;
            const tell = live && t >= g.tellAt;
            const strikerX = VIEW_W / 2;
            const strikerY = VIEW_H - 14;
            const tx = mX(g.target.x);
            const ty = mY(g.target.y);
            const ballX = p < 0 ? strikerX : strikerX + (tx - strikerX) * p;
            const ballY = p < 0 ? strikerY - 4 : strikerY - 4 + (ty - (strikerY - 4)) * p - Math.sin(p * Math.PI) * 10;
            const gx = mX(glove.x);
            const gy = mY(glove.y);
            const vecX = mX(GLOVE_ORIGIN.x + drag.dx);
            const vecY = mY(GLOVE_ORIGIN.y + drag.dy);
            const strikeProgress = Math.max(0, Math.min(1, (t - g.shotAt) / g.flight));
            const catchProgress = r2?.saved ? Math.max(0, (p - 0.8) / 0.2) : 0;
            return /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(import_jsx_runtime4.Fragment, { children: [
              /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("circle", { "data-drill-glove": true, cx: gx, cy: gy, r: r2 ? r2.radius * VX_PER_M : 6, fill: "hsl(45 90% 70%)", fillOpacity: 0.12, stroke: "hsl(45 60% 55%)", strokeWidth: 1, opacity: r2 ? 0.75 : 0.95 }),
              /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
                DrillKeeper,
                {
                  origin: { x: mX(GLOVE_ORIGIN.x), y: mY(GLOVE_ORIGIN.y) },
                  glove: { x: gx, y: gy },
                  catching: !!r2?.saved && p >= 0.8,
                  contact: r2?.saved ? { x: gx + (tx - gx) * catchProgress, y: gy + (ty - gy) * catchProgress } : void 0
                }
              ),
              phase === "playing" && (drag.dx !== 0 || drag.dy !== 0) && /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(import_jsx_runtime4.Fragment, { children: [
                /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("line", { x1: mX(GLOVE_ORIGIN.x), y1: mY(GLOVE_ORIGIN.y), x2: vecX, y2: vecY, stroke: "hsl(var(--primary))", strokeWidth: 1.6, strokeDasharray: "4 4" }),
                /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("circle", { cx: vecX, cy: vecY, r: 6, fill: "none", stroke: "hsl(var(--primary))", strokeWidth: 2 })
              ] }),
              /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
                DrillFigure,
                {
                  x: strikerX - 13 + (tell ? side * 6 : 0),
                  y: strikerY + 5,
                  tint: "attacker",
                  lean: tell ? side * 16 : 0,
                  scale: 1.35,
                  strike: p >= 0 ? reducedMotion2 ? 0.5 : 0.5 + Math.sin(strikeProgress * Math.PI) * 0.5 : 0
                }
              ),
              (phase === "roundEnd" || phase === "done") && r2 && !r2.saved && /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("circle", { cx: tx, cy: ty, r: 5, fill: "none", stroke: "hsl(0 80% 60%)", strokeWidth: 1.5 }),
              /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("circle", { "data-drill-ball": true, cx: ballX, cy: ballY, r: p < 0 ? 3.2 : 3.2 + p * 2.6, fill: "white", stroke: "hsl(0 0% 55%)", strokeWidth: 0.7 })
            ] });
          })()
        ]
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { ref: revealRef, className: "min-h-[132px]", children: [
      phase === "ready" && /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "rounded-2xl border border-border bg-card p-3 text-center", children: [
        /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("p", { className: "text-[12px] text-muted-foreground", children: [
          kind === "wallshot" && "Drag the goal to aim, let go to shoot as the gap opens. Arrow keys aim, W and S set power, space shoots.",
          kind === "tackle" && "Tap the ball while it is off his feet. Arrow keys move the marker, space goes in.",
          kind === "gloves" && "Hold and drag to set the dive, let go to go. Arrow keys set it, space dives."
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(Button, { className: "mt-2", onClick: beginRound, children: idx === 0 || match ? "Start" : "Next one" })
      ] }),
      phase === "playing" && kind === "wallshot" && /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "space-y-2 rounded-2xl border border-border bg-card p-3", children: [
        /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "flex items-center gap-2 text-xs text-muted-foreground", children: [
          /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "w-14 shrink-0", children: "Power" }),
          /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
            "input",
            {
              type: "range",
              min: 0.3,
              max: 1,
              step: 0.05,
              value: power,
              onChange: (e) => setPower(Number(e.target.value)),
              className: "flex-1 accent-[hsl(var(--primary))]",
              "aria-label": "How hard to hit it"
            }
          ),
          /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: cn("w-10 shrink-0 text-right tabular-nums", power > 0.85 ? "text-destructive" : power > 0.65 ? "text-amber-300" : ""), children: Math.round(power * 100) })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(Button, { size: "sm", className: "w-full", onClick: strike, children: "Shoot now" })
      ] }),
      phase === "playing" && kind === "tackle" && /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("div", { className: "rounded-2xl border border-border bg-card p-3 text-center", children: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(Button, { size: "sm", className: "w-full", onClick: () => tackleAt(cursor.x, cursor.y), children: "Go in at the marker" }) }),
      phase === "playing" && kind === "gloves" && /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "rounded-2xl border border-border bg-card p-3 text-center", children: [
        /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("p", { className: "text-[11px] text-muted-foreground", children: [
          "Reach ",
          Math.round(Math.min(1, Math.hypot(drag.dx, drag.dy) / GLOVE_MAX_REACH) * 100),
          "%",
          dragging ? ", holding" : ""
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(Button, { size: "sm", className: "mt-1 w-full", onClick: dive, children: "Dive now" })
      ] }),
      phase === "roundEnd" && result && /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "rounded-2xl border border-border bg-card p-4 text-center", children: [
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("p", { className: cn("font-display text-lg font-black", result.points > 0 ? "text-primary" : "text-muted-foreground"), children: result.verdict }),
        !match && result.points > 0 && /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("p", { className: "mt-1 text-sm text-muted-foreground", children: [
          result.points,
          " points."
        ] }),
        !match && /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(Button, { className: "mt-3", onClick: next, children: idx + 1 >= ROUNDS_PER_RUN ? "See the session" : "Next" })
      ] }),
      isDone && /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "rounded-2xl border border-amber-400/50 bg-card p-4 text-center", children: [
        /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("p", { className: "font-display text-2xl font-black", children: [
          count3,
          " of ",
          ROUNDS_PER_RUN,
          " ",
          meta.verb
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("p", { className: "mt-1 text-sm text-muted-foreground", children: [
          score,
          " points",
          best ? ` of a possible ${best}` : "",
          kind === "tackle" && fouls > 0 ? `, ${fouls} foul${fouls === 1 ? "" : "s"}` : "",
          ". Session score ",
          sessionScore(count3),
          "."
        ] }),
        mode === "daily" ? record?.banked ? /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("p", { className: "mt-2 text-sm font-bold text-emerald-400", children: "Banked. Come back tomorrow for ten new ones." }) : !canBank ? /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("p", { className: "mt-2 text-[12px] text-muted-foreground", children: "Already trained this season, so there is nothing to bank. Practice stays open." }) : boost > 0 ? /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(Button, { className: "mt-3 w-full bg-emerald-600 text-black hover:bg-emerald-500", onClick: bank, children: [
          "Bank the session: +",
          boost,
          " ",
          meta.statLabel
        ] }) : sessionScore(count3) >= 50 ? /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("p", { className: "mt-2 text-[12px] text-muted-foreground", children: "Good session, but you are at your ceiling and there is nothing left to add." }) : /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("p", { className: "mt-2 text-[12px] text-muted-foreground", children: [
          "Under 50, so nothing to bank. ",
          ROUNDS_PER_RUN / 2,
          " wins pays +1. Practice, then try again tomorrow."
        ] }) : /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("p", { className: "mt-2 text-[12px] text-muted-foreground", children: "Practice banks nothing. Today's ten are the ones that count." }),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "mt-3 flex flex-col gap-2 sm:flex-row", children: [
          /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(Button, { variant: "secondary", className: "flex-1 gap-2", onClick: () => start("unlimited"), children: [
            /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(RotateCcw, { className: "h-4 w-4" }),
            " Practice again"
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(Button, { variant: "outline", className: "flex-1", onClick: onBack, children: "Back to the drills" })
        ] })
      ] })
    ] })
  ] });
}
var import_react5, import_jsx_runtime4, r4, FLIGHT_MS, VIEW_W, VIEW_H, GOAL_L, GOAL_R, GOAL_TOP, GOAL_BOT, WALL_MAN_STEP, WALL_MAN_HALF_STEP, toViewX, toViewY, VX_PER_M, VY_PER_M, mX, mY, prefersReducedMotion3;
var init_DrillBoard = __esm({
  "src/components/soccer-career/DrillBoard.tsx"() {
    import_react5 = __toESM(require_react(), 1);
    init_button();
    init_lucide_react();
    init_utils();
    init_useArcadeFlight();
    init_useRevealScroll();
    init_dateUtils();
    init_dailyRecord();
    init_DrillPlayers();
    init_careerDrills();
    import_jsx_runtime4 = __toESM(require_jsx_runtime(), 1);
    r4 = (v) => Math.round(v * 1e4) / 1e4;
    FLIGHT_MS = 700;
    VIEW_W = 360;
    VIEW_H = 210;
    GOAL_L = 60;
    GOAL_R = 300;
    GOAL_TOP = 34;
    GOAL_BOT = 150;
    WALL_MAN_STEP = 0.22;
    WALL_MAN_HALF_STEP = WALL_MAN_STEP / 2;
    toViewX = (x) => GOAL_L + (x + 1) / 2 * (GOAL_R - GOAL_L);
    toViewY = (y) => GOAL_BOT - y * (GOAL_BOT - GOAL_TOP);
    VX_PER_M = (GOAL_R - GOAL_L) / (2 * GLOVE_HALF_WIDTH);
    VY_PER_M = (GOAL_BOT - GOAL_TOP) / GLOVE_HEIGHT;
    mX = (m) => toViewX(m / GLOVE_HALF_WIDTH);
    mY = (m) => toViewY(m / GLOVE_HEIGHT);
    prefersReducedMotion3 = () => typeof window !== "undefined" && typeof window.matchMedia === "function" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  }
});

// node_modules/@radix-ui/primitive/dist/index.mjs
function composeEventHandlers(originalEventHandler, ourEventHandler, { checkForDefaultPrevented = true } = {}) {
  return function handleEvent(event) {
    originalEventHandler?.(event);
    if (checkForDefaultPrevented === false || !event.defaultPrevented) {
      return ourEventHandler?.(event);
    }
  };
}
var init_dist4 = __esm({
  "node_modules/@radix-ui/primitive/dist/index.mjs"() {
  }
});

// node_modules/@radix-ui/react-context/dist/index.mjs
function createContext2(rootComponentName, defaultContext) {
  const Context = React4.createContext(defaultContext);
  const Provider = (props) => {
    const { children, ...context } = props;
    const value = React4.useMemo(() => context, Object.values(context));
    return /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(Context.Provider, { value, children });
  };
  Provider.displayName = rootComponentName + "Provider";
  function useContext22(consumerName) {
    const context = React4.useContext(Context);
    if (context) return context;
    if (defaultContext !== void 0) return defaultContext;
    throw new Error(`\`${consumerName}\` must be used within \`${rootComponentName}\``);
  }
  return [Provider, useContext22];
}
function createContextScope(scopeName, createContextScopeDeps = []) {
  let defaultContexts = [];
  function createContext32(rootComponentName, defaultContext) {
    const BaseContext = React4.createContext(defaultContext);
    const index = defaultContexts.length;
    defaultContexts = [...defaultContexts, defaultContext];
    const Provider = (props) => {
      const { scope, children, ...context } = props;
      const Context = scope?.[scopeName]?.[index] || BaseContext;
      const value = React4.useMemo(() => context, Object.values(context));
      return /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(Context.Provider, { value, children });
    };
    Provider.displayName = rootComponentName + "Provider";
    function useContext22(consumerName, scope) {
      const Context = scope?.[scopeName]?.[index] || BaseContext;
      const context = React4.useContext(Context);
      if (context) return context;
      if (defaultContext !== void 0) return defaultContext;
      throw new Error(`\`${consumerName}\` must be used within \`${rootComponentName}\``);
    }
    return [Provider, useContext22];
  }
  const createScope = () => {
    const scopeContexts = defaultContexts.map((defaultContext) => {
      return React4.createContext(defaultContext);
    });
    return function useScope(scope) {
      const contexts = scope?.[scopeName] || scopeContexts;
      return React4.useMemo(
        () => ({ [`__scope${scopeName}`]: { ...scope, [scopeName]: contexts } }),
        [scope, contexts]
      );
    };
  };
  createScope.scopeName = scopeName;
  return [createContext32, composeContextScopes(createScope, ...createContextScopeDeps)];
}
function composeContextScopes(...scopes) {
  const baseScope = scopes[0];
  if (scopes.length === 1) return baseScope;
  const createScope = () => {
    const scopeHooks = scopes.map((createScope2) => ({
      useScope: createScope2(),
      scopeName: createScope2.scopeName
    }));
    return function useComposedScopes(overrideScopes) {
      const nextScopes = scopeHooks.reduce((nextScopes2, { useScope, scopeName }) => {
        const scopeProps = useScope(overrideScopes);
        const currentScope = scopeProps[`__scope${scopeName}`];
        return { ...nextScopes2, ...currentScope };
      }, {});
      return React4.useMemo(() => ({ [`__scope${baseScope.scopeName}`]: nextScopes }), [nextScopes]);
    };
  };
  createScope.scopeName = baseScope.scopeName;
  return createScope;
}
var React4, import_jsx_runtime5;
var init_dist5 = __esm({
  "node_modules/@radix-ui/react-context/dist/index.mjs"() {
    React4 = __toESM(require_react(), 1);
    import_jsx_runtime5 = __toESM(require_jsx_runtime(), 1);
  }
});

// node_modules/@radix-ui/react-use-layout-effect/dist/index.mjs
var React5, useLayoutEffect2;
var init_dist6 = __esm({
  "node_modules/@radix-ui/react-use-layout-effect/dist/index.mjs"() {
    React5 = __toESM(require_react(), 1);
    useLayoutEffect2 = globalThis?.document ? React5.useLayoutEffect : () => {
    };
  }
});

// node_modules/@radix-ui/react-id/dist/index.mjs
function useId(deterministicId) {
  const [id, setId] = React6.useState(useReactId());
  useLayoutEffect2(() => {
    if (!deterministicId) setId((reactId) => reactId ?? String(count++));
  }, [deterministicId]);
  return deterministicId || (id ? `radix-${id}` : "");
}
var React6, useReactId, count;
var init_dist7 = __esm({
  "node_modules/@radix-ui/react-id/dist/index.mjs"() {
    React6 = __toESM(require_react(), 1);
    init_dist6();
    useReactId = React6[" useId ".trim().toString()] || (() => void 0);
    count = 0;
  }
});

// node_modules/@radix-ui/react-use-controllable-state/dist/index.mjs
function useControllableState({
  prop,
  defaultProp,
  onChange = () => {
  },
  caller
}) {
  const [uncontrolledProp, setUncontrolledProp, onChangeRef] = useUncontrolledState({
    defaultProp,
    onChange
  });
  const isControlled = prop !== void 0;
  const value = isControlled ? prop : uncontrolledProp;
  if (true) {
    const isControlledRef = React7.useRef(prop !== void 0);
    React7.useEffect(() => {
      const wasControlled = isControlledRef.current;
      if (wasControlled !== isControlled) {
        const from = wasControlled ? "controlled" : "uncontrolled";
        const to = isControlled ? "controlled" : "uncontrolled";
        console.warn(
          `${caller} is changing from ${from} to ${to}. Components should not switch from controlled to uncontrolled (or vice versa). Decide between using a controlled or uncontrolled value for the lifetime of the component.`
        );
      }
      isControlledRef.current = isControlled;
    }, [isControlled, caller]);
  }
  const setValue = React7.useCallback(
    (nextValue) => {
      if (isControlled) {
        const value2 = isFunction(nextValue) ? nextValue(prop) : nextValue;
        if (value2 !== prop) {
          onChangeRef.current?.(value2);
        }
      } else {
        setUncontrolledProp(nextValue);
      }
    },
    [isControlled, prop, setUncontrolledProp, onChangeRef]
  );
  return [value, setValue];
}
function useUncontrolledState({
  defaultProp,
  onChange
}) {
  const [value, setValue] = React7.useState(defaultProp);
  const prevValueRef = React7.useRef(value);
  const onChangeRef = React7.useRef(onChange);
  useInsertionEffect(() => {
    onChangeRef.current = onChange;
  }, [onChange]);
  React7.useEffect(() => {
    if (prevValueRef.current !== value) {
      onChangeRef.current?.(value);
      prevValueRef.current = value;
    }
  }, [value, prevValueRef]);
  return [value, setValue, onChangeRef];
}
function isFunction(value) {
  return typeof value === "function";
}
var React7, React22, useInsertionEffect, SYNC_STATE;
var init_dist8 = __esm({
  "node_modules/@radix-ui/react-use-controllable-state/dist/index.mjs"() {
    React7 = __toESM(require_react(), 1);
    init_dist6();
    React22 = __toESM(require_react(), 1);
    useInsertionEffect = React7[" useInsertionEffect ".trim().toString()] || useLayoutEffect2;
    SYNC_STATE = Symbol("RADIX:SYNC_STATE");
  }
});

// node_modules/@radix-ui/react-primitive/dist/index.mjs
function dispatchDiscreteCustomEvent(target, event) {
  if (target) ReactDOM.flushSync(() => target.dispatchEvent(event));
}
var React8, ReactDOM, import_jsx_runtime6, NODES, Primitive;
var init_dist9 = __esm({
  "node_modules/@radix-ui/react-primitive/dist/index.mjs"() {
    React8 = __toESM(require_react(), 1);
    ReactDOM = __toESM(require_react_dom(), 1);
    init_dist2();
    import_jsx_runtime6 = __toESM(require_jsx_runtime(), 1);
    NODES = [
      "a",
      "button",
      "div",
      "form",
      "h2",
      "h3",
      "img",
      "input",
      "label",
      "li",
      "nav",
      "ol",
      "p",
      "select",
      "span",
      "svg",
      "ul"
    ];
    Primitive = NODES.reduce((primitive, node) => {
      const Slot3 = createSlot(`Primitive.${node}`);
      const Node2 = React8.forwardRef((props, forwardedRef) => {
        const { asChild, ...primitiveProps } = props;
        const Comp = asChild ? Slot3 : node;
        if (typeof window !== "undefined") {
          window[Symbol.for("radix-ui")] = true;
        }
        return /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(Comp, { ...primitiveProps, ref: forwardedRef });
      });
      Node2.displayName = `Primitive.${node}`;
      return { ...primitive, [node]: Node2 };
    }, {});
  }
});

// node_modules/@radix-ui/react-use-callback-ref/dist/index.mjs
function useCallbackRef(callback) {
  const callbackRef = React9.useRef(callback);
  React9.useEffect(() => {
    callbackRef.current = callback;
  });
  return React9.useMemo(() => (...args) => callbackRef.current?.(...args), []);
}
var React9;
var init_dist10 = __esm({
  "node_modules/@radix-ui/react-use-callback-ref/dist/index.mjs"() {
    React9 = __toESM(require_react(), 1);
  }
});

// node_modules/@radix-ui/react-use-escape-keydown/dist/index.mjs
function useEscapeKeydown(onEscapeKeyDownProp, ownerDocument = globalThis?.document) {
  const onEscapeKeyDown = useCallbackRef(onEscapeKeyDownProp);
  React10.useEffect(() => {
    const handleKeyDown = (event) => {
      if (event.key === "Escape") {
        onEscapeKeyDown(event);
      }
    };
    ownerDocument.addEventListener("keydown", handleKeyDown, { capture: true });
    return () => ownerDocument.removeEventListener("keydown", handleKeyDown, { capture: true });
  }, [onEscapeKeyDown, ownerDocument]);
}
var React10;
var init_dist11 = __esm({
  "node_modules/@radix-ui/react-use-escape-keydown/dist/index.mjs"() {
    React10 = __toESM(require_react(), 1);
    init_dist10();
  }
});

// node_modules/@radix-ui/react-dismissable-layer/dist/index.mjs
function usePointerDownOutside(onPointerDownOutside, ownerDocument = globalThis?.document) {
  const handlePointerDownOutside = useCallbackRef(onPointerDownOutside);
  const isPointerInsideReactTreeRef = React11.useRef(false);
  const handleClickRef = React11.useRef(() => {
  });
  React11.useEffect(() => {
    const handlePointerDown = (event) => {
      if (event.target && !isPointerInsideReactTreeRef.current) {
        let handleAndDispatchPointerDownOutsideEvent2 = function() {
          handleAndDispatchCustomEvent(
            POINTER_DOWN_OUTSIDE,
            handlePointerDownOutside,
            eventDetail,
            { discrete: true }
          );
        };
        var handleAndDispatchPointerDownOutsideEvent = handleAndDispatchPointerDownOutsideEvent2;
        const eventDetail = { originalEvent: event };
        if (event.pointerType === "touch") {
          ownerDocument.removeEventListener("click", handleClickRef.current);
          handleClickRef.current = handleAndDispatchPointerDownOutsideEvent2;
          ownerDocument.addEventListener("click", handleClickRef.current, { once: true });
        } else {
          handleAndDispatchPointerDownOutsideEvent2();
        }
      } else {
        ownerDocument.removeEventListener("click", handleClickRef.current);
      }
      isPointerInsideReactTreeRef.current = false;
    };
    const timerId = window.setTimeout(() => {
      ownerDocument.addEventListener("pointerdown", handlePointerDown);
    }, 0);
    return () => {
      window.clearTimeout(timerId);
      ownerDocument.removeEventListener("pointerdown", handlePointerDown);
      ownerDocument.removeEventListener("click", handleClickRef.current);
    };
  }, [ownerDocument, handlePointerDownOutside]);
  return {
    // ensures we check React component tree (not just DOM tree)
    onPointerDownCapture: () => isPointerInsideReactTreeRef.current = true
  };
}
function useFocusOutside(onFocusOutside, ownerDocument = globalThis?.document) {
  const handleFocusOutside = useCallbackRef(onFocusOutside);
  const isFocusInsideReactTreeRef = React11.useRef(false);
  React11.useEffect(() => {
    const handleFocus = (event) => {
      if (event.target && !isFocusInsideReactTreeRef.current) {
        const eventDetail = { originalEvent: event };
        handleAndDispatchCustomEvent(FOCUS_OUTSIDE, handleFocusOutside, eventDetail, {
          discrete: false
        });
      }
    };
    ownerDocument.addEventListener("focusin", handleFocus);
    return () => ownerDocument.removeEventListener("focusin", handleFocus);
  }, [ownerDocument, handleFocusOutside]);
  return {
    onFocusCapture: () => isFocusInsideReactTreeRef.current = true,
    onBlurCapture: () => isFocusInsideReactTreeRef.current = false
  };
}
function dispatchUpdate() {
  const event = new CustomEvent(CONTEXT_UPDATE);
  document.dispatchEvent(event);
}
function handleAndDispatchCustomEvent(name, handler, detail, { discrete }) {
  const target = detail.originalEvent.target;
  const event = new CustomEvent(name, { bubbles: false, cancelable: true, detail });
  if (handler) target.addEventListener(name, handler, { once: true });
  if (discrete) {
    dispatchDiscreteCustomEvent(target, event);
  } else {
    target.dispatchEvent(event);
  }
}
var React11, import_jsx_runtime7, DISMISSABLE_LAYER_NAME, CONTEXT_UPDATE, POINTER_DOWN_OUTSIDE, FOCUS_OUTSIDE, originalBodyPointerEvents, DismissableLayerContext, DismissableLayer, BRANCH_NAME, DismissableLayerBranch;
var init_dist12 = __esm({
  "node_modules/@radix-ui/react-dismissable-layer/dist/index.mjs"() {
    "use client";
    React11 = __toESM(require_react(), 1);
    init_dist4();
    init_dist9();
    init_dist();
    init_dist10();
    init_dist11();
    import_jsx_runtime7 = __toESM(require_jsx_runtime(), 1);
    DISMISSABLE_LAYER_NAME = "DismissableLayer";
    CONTEXT_UPDATE = "dismissableLayer.update";
    POINTER_DOWN_OUTSIDE = "dismissableLayer.pointerDownOutside";
    FOCUS_OUTSIDE = "dismissableLayer.focusOutside";
    DismissableLayerContext = React11.createContext({
      layers: /* @__PURE__ */ new Set(),
      layersWithOutsidePointerEventsDisabled: /* @__PURE__ */ new Set(),
      branches: /* @__PURE__ */ new Set()
    });
    DismissableLayer = React11.forwardRef(
      (props, forwardedRef) => {
        const {
          disableOutsidePointerEvents = false,
          onEscapeKeyDown,
          onPointerDownOutside,
          onFocusOutside,
          onInteractOutside,
          onDismiss,
          ...layerProps
        } = props;
        const context = React11.useContext(DismissableLayerContext);
        const [node, setNode] = React11.useState(null);
        const ownerDocument = node?.ownerDocument ?? globalThis?.document;
        const [, force] = React11.useState({});
        const composedRefs = useComposedRefs(forwardedRef, (node2) => setNode(node2));
        const layers = Array.from(context.layers);
        const [highestLayerWithOutsidePointerEventsDisabled] = [...context.layersWithOutsidePointerEventsDisabled].slice(-1);
        const highestLayerWithOutsidePointerEventsDisabledIndex = layers.indexOf(highestLayerWithOutsidePointerEventsDisabled);
        const index = node ? layers.indexOf(node) : -1;
        const isBodyPointerEventsDisabled = context.layersWithOutsidePointerEventsDisabled.size > 0;
        const isPointerEventsEnabled = index >= highestLayerWithOutsidePointerEventsDisabledIndex;
        const pointerDownOutside = usePointerDownOutside((event) => {
          const target = event.target;
          const isPointerDownOnBranch = [...context.branches].some((branch) => branch.contains(target));
          if (!isPointerEventsEnabled || isPointerDownOnBranch) return;
          onPointerDownOutside?.(event);
          onInteractOutside?.(event);
          if (!event.defaultPrevented) onDismiss?.();
        }, ownerDocument);
        const focusOutside = useFocusOutside((event) => {
          const target = event.target;
          const isFocusInBranch = [...context.branches].some((branch) => branch.contains(target));
          if (isFocusInBranch) return;
          onFocusOutside?.(event);
          onInteractOutside?.(event);
          if (!event.defaultPrevented) onDismiss?.();
        }, ownerDocument);
        useEscapeKeydown((event) => {
          const isHighestLayer = index === context.layers.size - 1;
          if (!isHighestLayer) return;
          onEscapeKeyDown?.(event);
          if (!event.defaultPrevented && onDismiss) {
            event.preventDefault();
            onDismiss();
          }
        }, ownerDocument);
        React11.useEffect(() => {
          if (!node) return;
          if (disableOutsidePointerEvents) {
            if (context.layersWithOutsidePointerEventsDisabled.size === 0) {
              originalBodyPointerEvents = ownerDocument.body.style.pointerEvents;
              ownerDocument.body.style.pointerEvents = "none";
            }
            context.layersWithOutsidePointerEventsDisabled.add(node);
          }
          context.layers.add(node);
          dispatchUpdate();
          return () => {
            if (disableOutsidePointerEvents && context.layersWithOutsidePointerEventsDisabled.size === 1) {
              ownerDocument.body.style.pointerEvents = originalBodyPointerEvents;
            }
          };
        }, [node, ownerDocument, disableOutsidePointerEvents, context]);
        React11.useEffect(() => {
          return () => {
            if (!node) return;
            context.layers.delete(node);
            context.layersWithOutsidePointerEventsDisabled.delete(node);
            dispatchUpdate();
          };
        }, [node, context]);
        React11.useEffect(() => {
          const handleUpdate = () => force({});
          document.addEventListener(CONTEXT_UPDATE, handleUpdate);
          return () => document.removeEventListener(CONTEXT_UPDATE, handleUpdate);
        }, []);
        return /* @__PURE__ */ (0, import_jsx_runtime7.jsx)(
          Primitive.div,
          {
            ...layerProps,
            ref: composedRefs,
            style: {
              pointerEvents: isBodyPointerEventsDisabled ? isPointerEventsEnabled ? "auto" : "none" : void 0,
              ...props.style
            },
            onFocusCapture: composeEventHandlers(props.onFocusCapture, focusOutside.onFocusCapture),
            onBlurCapture: composeEventHandlers(props.onBlurCapture, focusOutside.onBlurCapture),
            onPointerDownCapture: composeEventHandlers(
              props.onPointerDownCapture,
              pointerDownOutside.onPointerDownCapture
            )
          }
        );
      }
    );
    DismissableLayer.displayName = DISMISSABLE_LAYER_NAME;
    BRANCH_NAME = "DismissableLayerBranch";
    DismissableLayerBranch = React11.forwardRef((props, forwardedRef) => {
      const context = React11.useContext(DismissableLayerContext);
      const ref = React11.useRef(null);
      const composedRefs = useComposedRefs(forwardedRef, ref);
      React11.useEffect(() => {
        const node = ref.current;
        if (node) {
          context.branches.add(node);
          return () => {
            context.branches.delete(node);
          };
        }
      }, [context.branches]);
      return /* @__PURE__ */ (0, import_jsx_runtime7.jsx)(Primitive.div, { ...props, ref: composedRefs });
    });
    DismissableLayerBranch.displayName = BRANCH_NAME;
  }
});

// node_modules/@radix-ui/react-focus-scope/dist/index.mjs
function focusFirst(candidates, { select = false } = {}) {
  const previouslyFocusedElement = document.activeElement;
  for (const candidate of candidates) {
    focus(candidate, { select });
    if (document.activeElement !== previouslyFocusedElement) return;
  }
}
function getTabbableEdges(container) {
  const candidates = getTabbableCandidates(container);
  const first = findVisible(candidates, container);
  const last = findVisible(candidates.reverse(), container);
  return [first, last];
}
function getTabbableCandidates(container) {
  const nodes = [];
  const walker = document.createTreeWalker(container, NodeFilter.SHOW_ELEMENT, {
    acceptNode: (node) => {
      const isHiddenInput = node.tagName === "INPUT" && node.type === "hidden";
      if (node.disabled || node.hidden || isHiddenInput) return NodeFilter.FILTER_SKIP;
      return node.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
    }
  });
  while (walker.nextNode()) nodes.push(walker.currentNode);
  return nodes;
}
function findVisible(elements, container) {
  for (const element of elements) {
    if (!isHidden(element, { upTo: container })) return element;
  }
}
function isHidden(node, { upTo }) {
  if (getComputedStyle(node).visibility === "hidden") return true;
  while (node) {
    if (upTo !== void 0 && node === upTo) return false;
    if (getComputedStyle(node).display === "none") return true;
    node = node.parentElement;
  }
  return false;
}
function isSelectableInput(element) {
  return element instanceof HTMLInputElement && "select" in element;
}
function focus(element, { select = false } = {}) {
  if (element && element.focus) {
    const previouslyFocusedElement = document.activeElement;
    element.focus({ preventScroll: true });
    if (element !== previouslyFocusedElement && isSelectableInput(element) && select)
      element.select();
  }
}
function createFocusScopesStack() {
  let stack = [];
  return {
    add(focusScope) {
      const activeFocusScope = stack[0];
      if (focusScope !== activeFocusScope) {
        activeFocusScope?.pause();
      }
      stack = arrayRemove(stack, focusScope);
      stack.unshift(focusScope);
    },
    remove(focusScope) {
      stack = arrayRemove(stack, focusScope);
      stack[0]?.resume();
    }
  };
}
function arrayRemove(array, item) {
  const updatedArray = [...array];
  const index = updatedArray.indexOf(item);
  if (index !== -1) {
    updatedArray.splice(index, 1);
  }
  return updatedArray;
}
function removeLinks(items) {
  return items.filter((item) => item.tagName !== "A");
}
var React12, import_jsx_runtime8, AUTOFOCUS_ON_MOUNT, AUTOFOCUS_ON_UNMOUNT, EVENT_OPTIONS, FOCUS_SCOPE_NAME, FocusScope, focusScopesStack;
var init_dist13 = __esm({
  "node_modules/@radix-ui/react-focus-scope/dist/index.mjs"() {
    "use client";
    React12 = __toESM(require_react(), 1);
    init_dist();
    init_dist9();
    init_dist10();
    import_jsx_runtime8 = __toESM(require_jsx_runtime(), 1);
    AUTOFOCUS_ON_MOUNT = "focusScope.autoFocusOnMount";
    AUTOFOCUS_ON_UNMOUNT = "focusScope.autoFocusOnUnmount";
    EVENT_OPTIONS = { bubbles: false, cancelable: true };
    FOCUS_SCOPE_NAME = "FocusScope";
    FocusScope = React12.forwardRef((props, forwardedRef) => {
      const {
        loop = false,
        trapped = false,
        onMountAutoFocus: onMountAutoFocusProp,
        onUnmountAutoFocus: onUnmountAutoFocusProp,
        ...scopeProps
      } = props;
      const [container, setContainer] = React12.useState(null);
      const onMountAutoFocus = useCallbackRef(onMountAutoFocusProp);
      const onUnmountAutoFocus = useCallbackRef(onUnmountAutoFocusProp);
      const lastFocusedElementRef = React12.useRef(null);
      const composedRefs = useComposedRefs(forwardedRef, (node) => setContainer(node));
      const focusScope = React12.useRef({
        paused: false,
        pause() {
          this.paused = true;
        },
        resume() {
          this.paused = false;
        }
      }).current;
      React12.useEffect(() => {
        if (trapped) {
          let handleFocusIn2 = function(event) {
            if (focusScope.paused || !container) return;
            const target = event.target;
            if (container.contains(target)) {
              lastFocusedElementRef.current = target;
            } else {
              focus(lastFocusedElementRef.current, { select: true });
            }
          }, handleFocusOut2 = function(event) {
            if (focusScope.paused || !container) return;
            const relatedTarget = event.relatedTarget;
            if (relatedTarget === null) return;
            if (!container.contains(relatedTarget)) {
              focus(lastFocusedElementRef.current, { select: true });
            }
          }, handleMutations2 = function(mutations) {
            const focusedElement = document.activeElement;
            if (focusedElement !== document.body) return;
            for (const mutation of mutations) {
              if (mutation.removedNodes.length > 0) focus(container);
            }
          };
          var handleFocusIn = handleFocusIn2, handleFocusOut = handleFocusOut2, handleMutations = handleMutations2;
          document.addEventListener("focusin", handleFocusIn2);
          document.addEventListener("focusout", handleFocusOut2);
          const mutationObserver = new MutationObserver(handleMutations2);
          if (container) mutationObserver.observe(container, { childList: true, subtree: true });
          return () => {
            document.removeEventListener("focusin", handleFocusIn2);
            document.removeEventListener("focusout", handleFocusOut2);
            mutationObserver.disconnect();
          };
        }
      }, [trapped, container, focusScope.paused]);
      React12.useEffect(() => {
        if (container) {
          focusScopesStack.add(focusScope);
          const previouslyFocusedElement = document.activeElement;
          const hasFocusedCandidate = container.contains(previouslyFocusedElement);
          if (!hasFocusedCandidate) {
            const mountEvent = new CustomEvent(AUTOFOCUS_ON_MOUNT, EVENT_OPTIONS);
            container.addEventListener(AUTOFOCUS_ON_MOUNT, onMountAutoFocus);
            container.dispatchEvent(mountEvent);
            if (!mountEvent.defaultPrevented) {
              focusFirst(removeLinks(getTabbableCandidates(container)), { select: true });
              if (document.activeElement === previouslyFocusedElement) {
                focus(container);
              }
            }
          }
          return () => {
            container.removeEventListener(AUTOFOCUS_ON_MOUNT, onMountAutoFocus);
            setTimeout(() => {
              const unmountEvent = new CustomEvent(AUTOFOCUS_ON_UNMOUNT, EVENT_OPTIONS);
              container.addEventListener(AUTOFOCUS_ON_UNMOUNT, onUnmountAutoFocus);
              container.dispatchEvent(unmountEvent);
              if (!unmountEvent.defaultPrevented) {
                focus(previouslyFocusedElement ?? document.body, { select: true });
              }
              container.removeEventListener(AUTOFOCUS_ON_UNMOUNT, onUnmountAutoFocus);
              focusScopesStack.remove(focusScope);
            }, 0);
          };
        }
      }, [container, onMountAutoFocus, onUnmountAutoFocus, focusScope]);
      const handleKeyDown = React12.useCallback(
        (event) => {
          if (!loop && !trapped) return;
          if (focusScope.paused) return;
          const isTabKey = event.key === "Tab" && !event.altKey && !event.ctrlKey && !event.metaKey;
          const focusedElement = document.activeElement;
          if (isTabKey && focusedElement) {
            const container2 = event.currentTarget;
            const [first, last] = getTabbableEdges(container2);
            const hasTabbableElementsInside = first && last;
            if (!hasTabbableElementsInside) {
              if (focusedElement === container2) event.preventDefault();
            } else {
              if (!event.shiftKey && focusedElement === last) {
                event.preventDefault();
                if (loop) focus(first, { select: true });
              } else if (event.shiftKey && focusedElement === first) {
                event.preventDefault();
                if (loop) focus(last, { select: true });
              }
            }
          }
        },
        [loop, trapped, focusScope.paused]
      );
      return /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(Primitive.div, { tabIndex: -1, ...scopeProps, ref: composedRefs, onKeyDown: handleKeyDown });
    });
    FocusScope.displayName = FOCUS_SCOPE_NAME;
    focusScopesStack = createFocusScopesStack();
  }
});

// node_modules/@radix-ui/react-portal/dist/index.mjs
var React13, import_react_dom, import_jsx_runtime9, PORTAL_NAME, Portal;
var init_dist14 = __esm({
  "node_modules/@radix-ui/react-portal/dist/index.mjs"() {
    "use client";
    React13 = __toESM(require_react(), 1);
    import_react_dom = __toESM(require_react_dom(), 1);
    init_dist9();
    init_dist6();
    import_jsx_runtime9 = __toESM(require_jsx_runtime(), 1);
    PORTAL_NAME = "Portal";
    Portal = React13.forwardRef((props, forwardedRef) => {
      const { container: containerProp, ...portalProps } = props;
      const [mounted, setMounted] = React13.useState(false);
      useLayoutEffect2(() => setMounted(true), []);
      const container = containerProp || mounted && globalThis?.document?.body;
      return container ? import_react_dom.default.createPortal(/* @__PURE__ */ (0, import_jsx_runtime9.jsx)(Primitive.div, { ...portalProps, ref: forwardedRef }), container) : null;
    });
    Portal.displayName = PORTAL_NAME;
  }
});

// node_modules/@radix-ui/react-presence/dist/index.mjs
function useStateMachine(initialState, machine) {
  return React14.useReducer((state, event) => {
    const nextState = machine[state][event];
    return nextState ?? state;
  }, initialState);
}
function usePresence(present) {
  const [node, setNode] = React23.useState();
  const stylesRef = React23.useRef(null);
  const prevPresentRef = React23.useRef(present);
  const prevAnimationNameRef = React23.useRef("none");
  const initialState = present ? "mounted" : "unmounted";
  const [state, send] = useStateMachine(initialState, {
    mounted: {
      UNMOUNT: "unmounted",
      ANIMATION_OUT: "unmountSuspended"
    },
    unmountSuspended: {
      MOUNT: "mounted",
      ANIMATION_END: "unmounted"
    },
    unmounted: {
      MOUNT: "mounted"
    }
  });
  React23.useEffect(() => {
    const currentAnimationName = getAnimationName(stylesRef.current);
    prevAnimationNameRef.current = state === "mounted" ? currentAnimationName : "none";
  }, [state]);
  useLayoutEffect2(() => {
    const styles = stylesRef.current;
    const wasPresent = prevPresentRef.current;
    const hasPresentChanged = wasPresent !== present;
    if (hasPresentChanged) {
      const prevAnimationName = prevAnimationNameRef.current;
      const currentAnimationName = getAnimationName(styles);
      if (present) {
        send("MOUNT");
      } else if (currentAnimationName === "none" || styles?.display === "none") {
        send("UNMOUNT");
      } else {
        const isAnimating = prevAnimationName !== currentAnimationName;
        if (wasPresent && isAnimating) {
          send("ANIMATION_OUT");
        } else {
          send("UNMOUNT");
        }
      }
      prevPresentRef.current = present;
    }
  }, [present, send]);
  useLayoutEffect2(() => {
    if (node) {
      let timeoutId;
      const ownerWindow = node.ownerDocument.defaultView ?? window;
      const handleAnimationEnd = (event) => {
        const currentAnimationName = getAnimationName(stylesRef.current);
        const isCurrentAnimation = currentAnimationName.includes(event.animationName);
        if (event.target === node && isCurrentAnimation) {
          send("ANIMATION_END");
          if (!prevPresentRef.current) {
            const currentFillMode = node.style.animationFillMode;
            node.style.animationFillMode = "forwards";
            timeoutId = ownerWindow.setTimeout(() => {
              if (node.style.animationFillMode === "forwards") {
                node.style.animationFillMode = currentFillMode;
              }
            });
          }
        }
      };
      const handleAnimationStart = (event) => {
        if (event.target === node) {
          prevAnimationNameRef.current = getAnimationName(stylesRef.current);
        }
      };
      node.addEventListener("animationstart", handleAnimationStart);
      node.addEventListener("animationcancel", handleAnimationEnd);
      node.addEventListener("animationend", handleAnimationEnd);
      return () => {
        ownerWindow.clearTimeout(timeoutId);
        node.removeEventListener("animationstart", handleAnimationStart);
        node.removeEventListener("animationcancel", handleAnimationEnd);
        node.removeEventListener("animationend", handleAnimationEnd);
      };
    } else {
      send("ANIMATION_END");
    }
  }, [node, send]);
  return {
    isPresent: ["mounted", "unmountSuspended"].includes(state),
    ref: React23.useCallback((node2) => {
      stylesRef.current = node2 ? getComputedStyle(node2) : null;
      setNode(node2);
    }, [])
  };
}
function getAnimationName(styles) {
  return styles?.animationName || "none";
}
function getElementRef2(element) {
  let getter = Object.getOwnPropertyDescriptor(element.props, "ref")?.get;
  let mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
  if (mayWarn) {
    return element.ref;
  }
  getter = Object.getOwnPropertyDescriptor(element, "ref")?.get;
  mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
  if (mayWarn) {
    return element.props.ref;
  }
  return element.props.ref || element.ref;
}
var React23, React14, Presence;
var init_dist15 = __esm({
  "node_modules/@radix-ui/react-presence/dist/index.mjs"() {
    "use client";
    React23 = __toESM(require_react(), 1);
    init_dist();
    init_dist6();
    React14 = __toESM(require_react(), 1);
    Presence = (props) => {
      const { present, children } = props;
      const presence = usePresence(present);
      const child = typeof children === "function" ? children({ present: presence.isPresent }) : React23.Children.only(children);
      const ref = useComposedRefs(presence.ref, getElementRef2(child));
      const forceMount = typeof children === "function";
      return forceMount || presence.isPresent ? React23.cloneElement(child, { ref }) : null;
    };
    Presence.displayName = "Presence";
  }
});

// node_modules/@radix-ui/react-focus-guards/dist/index.mjs
function useFocusGuards() {
  React15.useEffect(() => {
    const edgeGuards = document.querySelectorAll("[data-radix-focus-guard]");
    document.body.insertAdjacentElement("afterbegin", edgeGuards[0] ?? createFocusGuard());
    document.body.insertAdjacentElement("beforeend", edgeGuards[1] ?? createFocusGuard());
    count2++;
    return () => {
      if (count2 === 1) {
        document.querySelectorAll("[data-radix-focus-guard]").forEach((node) => node.remove());
      }
      count2--;
    };
  }, []);
}
function createFocusGuard() {
  const element = document.createElement("span");
  element.setAttribute("data-radix-focus-guard", "");
  element.tabIndex = 0;
  element.style.outline = "none";
  element.style.opacity = "0";
  element.style.position = "fixed";
  element.style.pointerEvents = "none";
  return element;
}
var React15, count2;
var init_dist16 = __esm({
  "node_modules/@radix-ui/react-focus-guards/dist/index.mjs"() {
    "use client";
    React15 = __toESM(require_react(), 1);
    count2 = 0;
  }
});

// node_modules/tslib/tslib.es6.mjs
function __rest(s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
    t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function")
    for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
      if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
        t[p[i]] = s[p[i]];
    }
  return t;
}
function __spreadArray(to, from, pack) {
  if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
    if (ar || !(i in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i);
      ar[i] = from[i];
    }
  }
  return to.concat(ar || Array.prototype.slice.call(from));
}
var __assign;
var init_tslib_es6 = __esm({
  "node_modules/tslib/tslib.es6.mjs"() {
    __assign = function() {
      __assign = Object.assign || function __assign2(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
      return __assign.apply(this, arguments);
    };
  }
});

// node_modules/react-remove-scroll-bar/dist/es2015/constants.js
var zeroRightClassName, fullWidthClassName, noScrollbarsClassName, removedBarSizeVariable;
var init_constants = __esm({
  "node_modules/react-remove-scroll-bar/dist/es2015/constants.js"() {
    zeroRightClassName = "right-scroll-bar-position";
    fullWidthClassName = "width-before-scroll-bar";
    noScrollbarsClassName = "with-scroll-bars-hidden";
    removedBarSizeVariable = "--removed-body-scroll-bar-size";
  }
});

// node_modules/use-callback-ref/dist/es2015/assignRef.js
function assignRef(ref, value) {
  if (typeof ref === "function") {
    ref(value);
  } else if (ref) {
    ref.current = value;
  }
  return ref;
}
var init_assignRef = __esm({
  "node_modules/use-callback-ref/dist/es2015/assignRef.js"() {
  }
});

// node_modules/use-callback-ref/dist/es2015/useRef.js
function useCallbackRef2(initialValue, callback) {
  var ref = (0, import_react6.useState)(function() {
    return {
      // value
      value: initialValue,
      // last callback
      callback,
      // "memoized" public interface
      facade: {
        get current() {
          return ref.value;
        },
        set current(value) {
          var last = ref.value;
          if (last !== value) {
            ref.value = value;
            ref.callback(value, last);
          }
        }
      }
    };
  })[0];
  ref.callback = callback;
  return ref.facade;
}
var import_react6;
var init_useRef = __esm({
  "node_modules/use-callback-ref/dist/es2015/useRef.js"() {
    import_react6 = __toESM(require_react());
  }
});

// node_modules/use-callback-ref/dist/es2015/useMergeRef.js
function useMergeRefs(refs, defaultValue) {
  var callbackRef = useCallbackRef2(defaultValue || null, function(newValue) {
    return refs.forEach(function(ref) {
      return assignRef(ref, newValue);
    });
  });
  useIsomorphicLayoutEffect(function() {
    var oldValue = currentValues.get(callbackRef);
    if (oldValue) {
      var prevRefs_1 = new Set(oldValue);
      var nextRefs_1 = new Set(refs);
      var current_1 = callbackRef.current;
      prevRefs_1.forEach(function(ref) {
        if (!nextRefs_1.has(ref)) {
          assignRef(ref, null);
        }
      });
      nextRefs_1.forEach(function(ref) {
        if (!prevRefs_1.has(ref)) {
          assignRef(ref, current_1);
        }
      });
    }
    currentValues.set(callbackRef, refs);
  }, [refs]);
  return callbackRef;
}
var React16, useIsomorphicLayoutEffect, currentValues;
var init_useMergeRef = __esm({
  "node_modules/use-callback-ref/dist/es2015/useMergeRef.js"() {
    React16 = __toESM(require_react());
    init_assignRef();
    init_useRef();
    useIsomorphicLayoutEffect = typeof window !== "undefined" ? React16.useLayoutEffect : React16.useEffect;
    currentValues = /* @__PURE__ */ new WeakMap();
  }
});

// node_modules/use-callback-ref/dist/es2015/index.js
var init_es2015 = __esm({
  "node_modules/use-callback-ref/dist/es2015/index.js"() {
    init_useMergeRef();
  }
});

// node_modules/use-sidecar/dist/es2015/medium.js
function ItoI(a) {
  return a;
}
function innerCreateMedium(defaults, middleware) {
  if (middleware === void 0) {
    middleware = ItoI;
  }
  var buffer = [];
  var assigned = false;
  var medium = {
    read: function() {
      if (assigned) {
        throw new Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");
      }
      if (buffer.length) {
        return buffer[buffer.length - 1];
      }
      return defaults;
    },
    useMedium: function(data) {
      var item = middleware(data, assigned);
      buffer.push(item);
      return function() {
        buffer = buffer.filter(function(x) {
          return x !== item;
        });
      };
    },
    assignSyncMedium: function(cb) {
      assigned = true;
      while (buffer.length) {
        var cbs = buffer;
        buffer = [];
        cbs.forEach(cb);
      }
      buffer = {
        push: function(x) {
          return cb(x);
        },
        filter: function() {
          return buffer;
        }
      };
    },
    assignMedium: function(cb) {
      assigned = true;
      var pendingQueue = [];
      if (buffer.length) {
        var cbs = buffer;
        buffer = [];
        cbs.forEach(cb);
        pendingQueue = buffer;
      }
      var executeQueue = function() {
        var cbs2 = pendingQueue;
        pendingQueue = [];
        cbs2.forEach(cb);
      };
      var cycle = function() {
        return Promise.resolve().then(executeQueue);
      };
      cycle();
      buffer = {
        push: function(x) {
          pendingQueue.push(x);
          cycle();
        },
        filter: function(filter) {
          pendingQueue = pendingQueue.filter(filter);
          return buffer;
        }
      };
    }
  };
  return medium;
}
function createSidecarMedium(options) {
  if (options === void 0) {
    options = {};
  }
  var medium = innerCreateMedium(null);
  medium.options = __assign({ async: true, ssr: false }, options);
  return medium;
}
var init_medium = __esm({
  "node_modules/use-sidecar/dist/es2015/medium.js"() {
    init_tslib_es6();
  }
});

// node_modules/use-sidecar/dist/es2015/exports.js
function exportSidecar(medium, exported) {
  medium.useMedium(exported);
  return SideCar;
}
var React17, SideCar;
var init_exports = __esm({
  "node_modules/use-sidecar/dist/es2015/exports.js"() {
    init_tslib_es6();
    React17 = __toESM(require_react());
    SideCar = function(_a) {
      var sideCar = _a.sideCar, rest = __rest(_a, ["sideCar"]);
      if (!sideCar) {
        throw new Error("Sidecar: please provide `sideCar` property to import the right car");
      }
      var Target = sideCar.read();
      if (!Target) {
        throw new Error("Sidecar medium not found");
      }
      return React17.createElement(Target, __assign({}, rest));
    };
    SideCar.isSideCarExport = true;
  }
});

// node_modules/use-sidecar/dist/es2015/index.js
var init_es20152 = __esm({
  "node_modules/use-sidecar/dist/es2015/index.js"() {
    init_medium();
    init_exports();
  }
});

// node_modules/react-remove-scroll/dist/es2015/medium.js
var effectCar;
var init_medium2 = __esm({
  "node_modules/react-remove-scroll/dist/es2015/medium.js"() {
    init_es20152();
    effectCar = createSidecarMedium();
  }
});

// node_modules/react-remove-scroll/dist/es2015/UI.js
var React18, nothing, RemoveScroll;
var init_UI = __esm({
  "node_modules/react-remove-scroll/dist/es2015/UI.js"() {
    init_tslib_es6();
    React18 = __toESM(require_react());
    init_constants();
    init_es2015();
    init_medium2();
    nothing = function() {
      return;
    };
    RemoveScroll = React18.forwardRef(function(props, parentRef) {
      var ref = React18.useRef(null);
      var _a = React18.useState({
        onScrollCapture: nothing,
        onWheelCapture: nothing,
        onTouchMoveCapture: nothing
      }), callbacks = _a[0], setCallbacks = _a[1];
      var forwardProps = props.forwardProps, children = props.children, className = props.className, removeScrollBar = props.removeScrollBar, enabled = props.enabled, shards = props.shards, sideCar = props.sideCar, noRelative = props.noRelative, noIsolation = props.noIsolation, inert = props.inert, allowPinchZoom = props.allowPinchZoom, _b = props.as, Container = _b === void 0 ? "div" : _b, gapMode = props.gapMode, rest = __rest(props, ["forwardProps", "children", "className", "removeScrollBar", "enabled", "shards", "sideCar", "noRelative", "noIsolation", "inert", "allowPinchZoom", "as", "gapMode"]);
      var SideCar2 = sideCar;
      var containerRef = useMergeRefs([ref, parentRef]);
      var containerProps = __assign(__assign({}, rest), callbacks);
      return React18.createElement(
        React18.Fragment,
        null,
        enabled && React18.createElement(SideCar2, { sideCar: effectCar, removeScrollBar, shards, noRelative, noIsolation, inert, setCallbacks, allowPinchZoom: !!allowPinchZoom, lockRef: ref, gapMode }),
        forwardProps ? React18.cloneElement(React18.Children.only(children), __assign(__assign({}, containerProps), { ref: containerRef })) : React18.createElement(Container, __assign({}, containerProps, { className, ref: containerRef }), children)
      );
    });
    RemoveScroll.defaultProps = {
      enabled: true,
      removeScrollBar: true,
      inert: false
    };
    RemoveScroll.classNames = {
      fullWidth: fullWidthClassName,
      zeroRight: zeroRightClassName
    };
  }
});

// node_modules/get-nonce/dist/es2015/index.js
var currentNonce, getNonce;
var init_es20153 = __esm({
  "node_modules/get-nonce/dist/es2015/index.js"() {
    getNonce = function() {
      if (currentNonce) {
        return currentNonce;
      }
      if (typeof __webpack_nonce__ !== "undefined") {
        return __webpack_nonce__;
      }
      return void 0;
    };
  }
});

// node_modules/react-style-singleton/dist/es2015/singleton.js
function makeStyleTag() {
  if (!document)
    return null;
  var tag = document.createElement("style");
  tag.type = "text/css";
  var nonce = getNonce();
  if (nonce) {
    tag.setAttribute("nonce", nonce);
  }
  return tag;
}
function injectStyles(tag, css) {
  if (tag.styleSheet) {
    tag.styleSheet.cssText = css;
  } else {
    tag.appendChild(document.createTextNode(css));
  }
}
function insertStyleTag(tag) {
  var head = document.head || document.getElementsByTagName("head")[0];
  head.appendChild(tag);
}
var stylesheetSingleton;
var init_singleton = __esm({
  "node_modules/react-style-singleton/dist/es2015/singleton.js"() {
    init_es20153();
    stylesheetSingleton = function() {
      var counter = 0;
      var stylesheet = null;
      return {
        add: function(style) {
          if (counter == 0) {
            if (stylesheet = makeStyleTag()) {
              injectStyles(stylesheet, style);
              insertStyleTag(stylesheet);
            }
          }
          counter++;
        },
        remove: function() {
          counter--;
          if (!counter && stylesheet) {
            stylesheet.parentNode && stylesheet.parentNode.removeChild(stylesheet);
            stylesheet = null;
          }
        }
      };
    };
  }
});

// node_modules/react-style-singleton/dist/es2015/hook.js
var React19, styleHookSingleton;
var init_hook = __esm({
  "node_modules/react-style-singleton/dist/es2015/hook.js"() {
    React19 = __toESM(require_react());
    init_singleton();
    styleHookSingleton = function() {
      var sheet = stylesheetSingleton();
      return function(styles, isDynamic) {
        React19.useEffect(function() {
          sheet.add(styles);
          return function() {
            sheet.remove();
          };
        }, [styles && isDynamic]);
      };
    };
  }
});

// node_modules/react-style-singleton/dist/es2015/component.js
var styleSingleton;
var init_component = __esm({
  "node_modules/react-style-singleton/dist/es2015/component.js"() {
    init_hook();
    styleSingleton = function() {
      var useStyle = styleHookSingleton();
      var Sheet = function(_a) {
        var styles = _a.styles, dynamic = _a.dynamic;
        useStyle(styles, dynamic);
        return null;
      };
      return Sheet;
    };
  }
});

// node_modules/react-style-singleton/dist/es2015/index.js
var init_es20154 = __esm({
  "node_modules/react-style-singleton/dist/es2015/index.js"() {
    init_component();
    init_singleton();
    init_hook();
  }
});

// node_modules/react-remove-scroll-bar/dist/es2015/utils.js
var zeroGap, parse, getOffset, getGapWidth;
var init_utils3 = __esm({
  "node_modules/react-remove-scroll-bar/dist/es2015/utils.js"() {
    zeroGap = {
      left: 0,
      top: 0,
      right: 0,
      gap: 0
    };
    parse = function(x) {
      return parseInt(x || "", 10) || 0;
    };
    getOffset = function(gapMode) {
      var cs = window.getComputedStyle(document.body);
      var left = cs[gapMode === "padding" ? "paddingLeft" : "marginLeft"];
      var top = cs[gapMode === "padding" ? "paddingTop" : "marginTop"];
      var right = cs[gapMode === "padding" ? "paddingRight" : "marginRight"];
      return [parse(left), parse(top), parse(right)];
    };
    getGapWidth = function(gapMode) {
      if (gapMode === void 0) {
        gapMode = "margin";
      }
      if (typeof window === "undefined") {
        return zeroGap;
      }
      var offsets = getOffset(gapMode);
      var documentWidth = document.documentElement.clientWidth;
      var windowWidth = window.innerWidth;
      return {
        left: offsets[0],
        top: offsets[1],
        right: offsets[2],
        gap: Math.max(0, windowWidth - documentWidth + offsets[2] - offsets[0])
      };
    };
  }
});

// node_modules/react-remove-scroll-bar/dist/es2015/component.js
var React20, Style, lockAttribute, getStyles, getCurrentUseCounter, useLockAttribute, RemoveScrollBar;
var init_component2 = __esm({
  "node_modules/react-remove-scroll-bar/dist/es2015/component.js"() {
    React20 = __toESM(require_react());
    init_es20154();
    init_constants();
    init_utils3();
    Style = styleSingleton();
    lockAttribute = "data-scroll-locked";
    getStyles = function(_a, allowRelative, gapMode, important) {
      var left = _a.left, top = _a.top, right = _a.right, gap = _a.gap;
      if (gapMode === void 0) {
        gapMode = "margin";
      }
      return "\n  .".concat(noScrollbarsClassName, " {\n   overflow: hidden ").concat(important, ";\n   padding-right: ").concat(gap, "px ").concat(important, ";\n  }\n  body[").concat(lockAttribute, "] {\n    overflow: hidden ").concat(important, ";\n    overscroll-behavior: contain;\n    ").concat([
        allowRelative && "position: relative ".concat(important, ";"),
        gapMode === "margin" && "\n    padding-left: ".concat(left, "px;\n    padding-top: ").concat(top, "px;\n    padding-right: ").concat(right, "px;\n    margin-left:0;\n    margin-top:0;\n    margin-right: ").concat(gap, "px ").concat(important, ";\n    "),
        gapMode === "padding" && "padding-right: ".concat(gap, "px ").concat(important, ";")
      ].filter(Boolean).join(""), "\n  }\n  \n  .").concat(zeroRightClassName, " {\n    right: ").concat(gap, "px ").concat(important, ";\n  }\n  \n  .").concat(fullWidthClassName, " {\n    margin-right: ").concat(gap, "px ").concat(important, ";\n  }\n  \n  .").concat(zeroRightClassName, " .").concat(zeroRightClassName, " {\n    right: 0 ").concat(important, ";\n  }\n  \n  .").concat(fullWidthClassName, " .").concat(fullWidthClassName, " {\n    margin-right: 0 ").concat(important, ";\n  }\n  \n  body[").concat(lockAttribute, "] {\n    ").concat(removedBarSizeVariable, ": ").concat(gap, "px;\n  }\n");
    };
    getCurrentUseCounter = function() {
      var counter = parseInt(document.body.getAttribute(lockAttribute) || "0", 10);
      return isFinite(counter) ? counter : 0;
    };
    useLockAttribute = function() {
      React20.useEffect(function() {
        document.body.setAttribute(lockAttribute, (getCurrentUseCounter() + 1).toString());
        return function() {
          var newCounter = getCurrentUseCounter() - 1;
          if (newCounter <= 0) {
            document.body.removeAttribute(lockAttribute);
          } else {
            document.body.setAttribute(lockAttribute, newCounter.toString());
          }
        };
      }, []);
    };
    RemoveScrollBar = function(_a) {
      var noRelative = _a.noRelative, noImportant = _a.noImportant, _b = _a.gapMode, gapMode = _b === void 0 ? "margin" : _b;
      useLockAttribute();
      var gap = React20.useMemo(function() {
        return getGapWidth(gapMode);
      }, [gapMode]);
      return React20.createElement(Style, { styles: getStyles(gap, !noRelative, gapMode, !noImportant ? "!important" : "") });
    };
  }
});

// node_modules/react-remove-scroll-bar/dist/es2015/index.js
var init_es20155 = __esm({
  "node_modules/react-remove-scroll-bar/dist/es2015/index.js"() {
    init_component2();
    init_constants();
    init_utils3();
  }
});

// node_modules/react-remove-scroll/dist/es2015/aggresiveCapture.js
var passiveSupported, options, nonPassive;
var init_aggresiveCapture = __esm({
  "node_modules/react-remove-scroll/dist/es2015/aggresiveCapture.js"() {
    passiveSupported = false;
    if (typeof window !== "undefined") {
      try {
        options = Object.defineProperty({}, "passive", {
          get: function() {
            passiveSupported = true;
            return true;
          }
        });
        window.addEventListener("test", options, options);
        window.removeEventListener("test", options, options);
      } catch (err) {
        passiveSupported = false;
      }
    }
    nonPassive = passiveSupported ? { passive: false } : false;
  }
});

// node_modules/react-remove-scroll/dist/es2015/handleScroll.js
var alwaysContainsScroll, elementCanBeScrolled, elementCouldBeVScrolled, elementCouldBeHScrolled, locationCouldBeScrolled, getVScrollVariables, getHScrollVariables, elementCouldBeScrolled, getScrollVariables, getDirectionFactor, handleScroll;
var init_handleScroll = __esm({
  "node_modules/react-remove-scroll/dist/es2015/handleScroll.js"() {
    alwaysContainsScroll = function(node) {
      return node.tagName === "TEXTAREA";
    };
    elementCanBeScrolled = function(node, overflow) {
      if (!(node instanceof Element)) {
        return false;
      }
      var styles = window.getComputedStyle(node);
      return (
        // not-not-scrollable
        styles[overflow] !== "hidden" && // contains scroll inside self
        !(styles.overflowY === styles.overflowX && !alwaysContainsScroll(node) && styles[overflow] === "visible")
      );
    };
    elementCouldBeVScrolled = function(node) {
      return elementCanBeScrolled(node, "overflowY");
    };
    elementCouldBeHScrolled = function(node) {
      return elementCanBeScrolled(node, "overflowX");
    };
    locationCouldBeScrolled = function(axis, node) {
      var ownerDocument = node.ownerDocument;
      var current = node;
      do {
        if (typeof ShadowRoot !== "undefined" && current instanceof ShadowRoot) {
          current = current.host;
        }
        var isScrollable = elementCouldBeScrolled(axis, current);
        if (isScrollable) {
          var _a = getScrollVariables(axis, current), scrollHeight = _a[1], clientHeight = _a[2];
          if (scrollHeight > clientHeight) {
            return true;
          }
        }
        current = current.parentNode;
      } while (current && current !== ownerDocument.body);
      return false;
    };
    getVScrollVariables = function(_a) {
      var scrollTop = _a.scrollTop, scrollHeight = _a.scrollHeight, clientHeight = _a.clientHeight;
      return [
        scrollTop,
        scrollHeight,
        clientHeight
      ];
    };
    getHScrollVariables = function(_a) {
      var scrollLeft = _a.scrollLeft, scrollWidth = _a.scrollWidth, clientWidth = _a.clientWidth;
      return [
        scrollLeft,
        scrollWidth,
        clientWidth
      ];
    };
    elementCouldBeScrolled = function(axis, node) {
      return axis === "v" ? elementCouldBeVScrolled(node) : elementCouldBeHScrolled(node);
    };
    getScrollVariables = function(axis, node) {
      return axis === "v" ? getVScrollVariables(node) : getHScrollVariables(node);
    };
    getDirectionFactor = function(axis, direction) {
      return axis === "h" && direction === "rtl" ? -1 : 1;
    };
    handleScroll = function(axis, endTarget, event, sourceDelta, noOverscroll) {
      var directionFactor = getDirectionFactor(axis, window.getComputedStyle(endTarget).direction);
      var delta = directionFactor * sourceDelta;
      var target = event.target;
      var targetInLock = endTarget.contains(target);
      var shouldCancelScroll = false;
      var isDeltaPositive = delta > 0;
      var availableScroll = 0;
      var availableScrollTop = 0;
      do {
        if (!target) {
          break;
        }
        var _a = getScrollVariables(axis, target), position = _a[0], scroll_1 = _a[1], capacity = _a[2];
        var elementScroll = scroll_1 - capacity - directionFactor * position;
        if (position || elementScroll) {
          if (elementCouldBeScrolled(axis, target)) {
            availableScroll += elementScroll;
            availableScrollTop += position;
          }
        }
        var parent_1 = target.parentNode;
        target = parent_1 && parent_1.nodeType === Node.DOCUMENT_FRAGMENT_NODE ? parent_1.host : parent_1;
      } while (
        // portaled content
        !targetInLock && target !== document.body || // self content
        targetInLock && (endTarget.contains(target) || endTarget === target)
      );
      if (isDeltaPositive && (noOverscroll && Math.abs(availableScroll) < 1 || !noOverscroll && delta > availableScroll)) {
        shouldCancelScroll = true;
      } else if (!isDeltaPositive && (noOverscroll && Math.abs(availableScrollTop) < 1 || !noOverscroll && -delta > availableScrollTop)) {
        shouldCancelScroll = true;
      }
      return shouldCancelScroll;
    };
  }
});

// node_modules/react-remove-scroll/dist/es2015/SideEffect.js
function RemoveScrollSideCar(props) {
  var shouldPreventQueue = React21.useRef([]);
  var touchStartRef = React21.useRef([0, 0]);
  var activeAxis = React21.useRef();
  var id = React21.useState(idCounter++)[0];
  var Style2 = React21.useState(styleSingleton)[0];
  var lastProps = React21.useRef(props);
  React21.useEffect(function() {
    lastProps.current = props;
  }, [props]);
  React21.useEffect(function() {
    if (props.inert) {
      document.body.classList.add("block-interactivity-".concat(id));
      var allow_1 = __spreadArray([props.lockRef.current], (props.shards || []).map(extractRef), true).filter(Boolean);
      allow_1.forEach(function(el) {
        return el.classList.add("allow-interactivity-".concat(id));
      });
      return function() {
        document.body.classList.remove("block-interactivity-".concat(id));
        allow_1.forEach(function(el) {
          return el.classList.remove("allow-interactivity-".concat(id));
        });
      };
    }
    return;
  }, [props.inert, props.lockRef.current, props.shards]);
  var shouldCancelEvent = React21.useCallback(function(event, parent) {
    if ("touches" in event && event.touches.length === 2 || event.type === "wheel" && event.ctrlKey) {
      return !lastProps.current.allowPinchZoom;
    }
    var touch = getTouchXY(event);
    var touchStart = touchStartRef.current;
    var deltaX = "deltaX" in event ? event.deltaX : touchStart[0] - touch[0];
    var deltaY = "deltaY" in event ? event.deltaY : touchStart[1] - touch[1];
    var currentAxis;
    var target = event.target;
    var moveDirection = Math.abs(deltaX) > Math.abs(deltaY) ? "h" : "v";
    if ("touches" in event && moveDirection === "h" && target.type === "range") {
      return false;
    }
    var canBeScrolledInMainDirection = locationCouldBeScrolled(moveDirection, target);
    if (!canBeScrolledInMainDirection) {
      return true;
    }
    if (canBeScrolledInMainDirection) {
      currentAxis = moveDirection;
    } else {
      currentAxis = moveDirection === "v" ? "h" : "v";
      canBeScrolledInMainDirection = locationCouldBeScrolled(moveDirection, target);
    }
    if (!canBeScrolledInMainDirection) {
      return false;
    }
    if (!activeAxis.current && "changedTouches" in event && (deltaX || deltaY)) {
      activeAxis.current = currentAxis;
    }
    if (!currentAxis) {
      return true;
    }
    var cancelingAxis = activeAxis.current || currentAxis;
    return handleScroll(cancelingAxis, parent, event, cancelingAxis === "h" ? deltaX : deltaY, true);
  }, []);
  var shouldPrevent = React21.useCallback(function(_event) {
    var event = _event;
    if (!lockStack.length || lockStack[lockStack.length - 1] !== Style2) {
      return;
    }
    var delta = "deltaY" in event ? getDeltaXY(event) : getTouchXY(event);
    var sourceEvent = shouldPreventQueue.current.filter(function(e) {
      return e.name === event.type && (e.target === event.target || event.target === e.shadowParent) && deltaCompare(e.delta, delta);
    })[0];
    if (sourceEvent && sourceEvent.should) {
      if (event.cancelable) {
        event.preventDefault();
      }
      return;
    }
    if (!sourceEvent) {
      var shardNodes = (lastProps.current.shards || []).map(extractRef).filter(Boolean).filter(function(node) {
        return node.contains(event.target);
      });
      var shouldStop = shardNodes.length > 0 ? shouldCancelEvent(event, shardNodes[0]) : !lastProps.current.noIsolation;
      if (shouldStop) {
        if (event.cancelable) {
          event.preventDefault();
        }
      }
    }
  }, []);
  var shouldCancel = React21.useCallback(function(name, delta, target, should) {
    var event = { name, delta, target, should, shadowParent: getOutermostShadowParent(target) };
    shouldPreventQueue.current.push(event);
    setTimeout(function() {
      shouldPreventQueue.current = shouldPreventQueue.current.filter(function(e) {
        return e !== event;
      });
    }, 1);
  }, []);
  var scrollTouchStart = React21.useCallback(function(event) {
    touchStartRef.current = getTouchXY(event);
    activeAxis.current = void 0;
  }, []);
  var scrollWheel = React21.useCallback(function(event) {
    shouldCancel(event.type, getDeltaXY(event), event.target, shouldCancelEvent(event, props.lockRef.current));
  }, []);
  var scrollTouchMove = React21.useCallback(function(event) {
    shouldCancel(event.type, getTouchXY(event), event.target, shouldCancelEvent(event, props.lockRef.current));
  }, []);
  React21.useEffect(function() {
    lockStack.push(Style2);
    props.setCallbacks({
      onScrollCapture: scrollWheel,
      onWheelCapture: scrollWheel,
      onTouchMoveCapture: scrollTouchMove
    });
    document.addEventListener("wheel", shouldPrevent, nonPassive);
    document.addEventListener("touchmove", shouldPrevent, nonPassive);
    document.addEventListener("touchstart", scrollTouchStart, nonPassive);
    return function() {
      lockStack = lockStack.filter(function(inst) {
        return inst !== Style2;
      });
      document.removeEventListener("wheel", shouldPrevent, nonPassive);
      document.removeEventListener("touchmove", shouldPrevent, nonPassive);
      document.removeEventListener("touchstart", scrollTouchStart, nonPassive);
    };
  }, []);
  var removeScrollBar = props.removeScrollBar, inert = props.inert;
  return React21.createElement(
    React21.Fragment,
    null,
    inert ? React21.createElement(Style2, { styles: generateStyle(id) }) : null,
    removeScrollBar ? React21.createElement(RemoveScrollBar, { noRelative: props.noRelative, gapMode: props.gapMode }) : null
  );
}
function getOutermostShadowParent(node) {
  var shadowParent = null;
  while (node !== null) {
    if (node instanceof ShadowRoot) {
      shadowParent = node.host;
      node = node.host;
    }
    node = node.parentNode;
  }
  return shadowParent;
}
var React21, getTouchXY, getDeltaXY, extractRef, deltaCompare, generateStyle, idCounter, lockStack;
var init_SideEffect = __esm({
  "node_modules/react-remove-scroll/dist/es2015/SideEffect.js"() {
    init_tslib_es6();
    React21 = __toESM(require_react());
    init_es20155();
    init_es20154();
    init_aggresiveCapture();
    init_handleScroll();
    getTouchXY = function(event) {
      return "changedTouches" in event ? [event.changedTouches[0].clientX, event.changedTouches[0].clientY] : [0, 0];
    };
    getDeltaXY = function(event) {
      return [event.deltaX, event.deltaY];
    };
    extractRef = function(ref) {
      return ref && "current" in ref ? ref.current : ref;
    };
    deltaCompare = function(x, y) {
      return x[0] === y[0] && x[1] === y[1];
    };
    generateStyle = function(id) {
      return "\n  .block-interactivity-".concat(id, " {pointer-events: none;}\n  .allow-interactivity-").concat(id, " {pointer-events: all;}\n");
    };
    idCounter = 0;
    lockStack = [];
  }
});

// node_modules/react-remove-scroll/dist/es2015/sidecar.js
var sidecar_default;
var init_sidecar = __esm({
  "node_modules/react-remove-scroll/dist/es2015/sidecar.js"() {
    init_es20152();
    init_SideEffect();
    init_medium2();
    sidecar_default = exportSidecar(effectCar, RemoveScrollSideCar);
  }
});

// node_modules/react-remove-scroll/dist/es2015/Combination.js
var React24, ReactRemoveScroll, Combination_default;
var init_Combination = __esm({
  "node_modules/react-remove-scroll/dist/es2015/Combination.js"() {
    init_tslib_es6();
    React24 = __toESM(require_react());
    init_UI();
    init_sidecar();
    ReactRemoveScroll = React24.forwardRef(function(props, ref) {
      return React24.createElement(RemoveScroll, __assign({}, props, { ref, sideCar: sidecar_default }));
    });
    ReactRemoveScroll.classNames = RemoveScroll.classNames;
    Combination_default = ReactRemoveScroll;
  }
});

// node_modules/react-remove-scroll/dist/es2015/index.js
var init_es20156 = __esm({
  "node_modules/react-remove-scroll/dist/es2015/index.js"() {
    init_Combination();
  }
});

// node_modules/aria-hidden/dist/es2015/index.js
var getDefaultParent, counterMap, uncontrolledNodes, markerMap, lockCount, unwrapHost, correctTargets, applyAttributeToOthers, hideOthers;
var init_es20157 = __esm({
  "node_modules/aria-hidden/dist/es2015/index.js"() {
    getDefaultParent = function(originalTarget) {
      if (typeof document === "undefined") {
        return null;
      }
      var sampleTarget = Array.isArray(originalTarget) ? originalTarget[0] : originalTarget;
      return sampleTarget.ownerDocument.body;
    };
    counterMap = /* @__PURE__ */ new WeakMap();
    uncontrolledNodes = /* @__PURE__ */ new WeakMap();
    markerMap = {};
    lockCount = 0;
    unwrapHost = function(node) {
      return node && (node.host || unwrapHost(node.parentNode));
    };
    correctTargets = function(parent, targets) {
      return targets.map(function(target) {
        if (parent.contains(target)) {
          return target;
        }
        var correctedTarget = unwrapHost(target);
        if (correctedTarget && parent.contains(correctedTarget)) {
          return correctedTarget;
        }
        console.error("aria-hidden", target, "in not contained inside", parent, ". Doing nothing");
        return null;
      }).filter(function(x) {
        return Boolean(x);
      });
    };
    applyAttributeToOthers = function(originalTarget, parentNode, markerName, controlAttribute) {
      var targets = correctTargets(parentNode, Array.isArray(originalTarget) ? originalTarget : [originalTarget]);
      if (!markerMap[markerName]) {
        markerMap[markerName] = /* @__PURE__ */ new WeakMap();
      }
      var markerCounter = markerMap[markerName];
      var hiddenNodes = [];
      var elementsToKeep = /* @__PURE__ */ new Set();
      var elementsToStop = new Set(targets);
      var keep = function(el) {
        if (!el || elementsToKeep.has(el)) {
          return;
        }
        elementsToKeep.add(el);
        keep(el.parentNode);
      };
      targets.forEach(keep);
      var deep = function(parent) {
        if (!parent || elementsToStop.has(parent)) {
          return;
        }
        Array.prototype.forEach.call(parent.children, function(node) {
          if (elementsToKeep.has(node)) {
            deep(node);
          } else {
            try {
              var attr = node.getAttribute(controlAttribute);
              var alreadyHidden = attr !== null && attr !== "false";
              var counterValue = (counterMap.get(node) || 0) + 1;
              var markerValue = (markerCounter.get(node) || 0) + 1;
              counterMap.set(node, counterValue);
              markerCounter.set(node, markerValue);
              hiddenNodes.push(node);
              if (counterValue === 1 && alreadyHidden) {
                uncontrolledNodes.set(node, true);
              }
              if (markerValue === 1) {
                node.setAttribute(markerName, "true");
              }
              if (!alreadyHidden) {
                node.setAttribute(controlAttribute, "true");
              }
            } catch (e) {
              console.error("aria-hidden: cannot operate on ", node, e);
            }
          }
        });
      };
      deep(parentNode);
      elementsToKeep.clear();
      lockCount++;
      return function() {
        hiddenNodes.forEach(function(node) {
          var counterValue = counterMap.get(node) - 1;
          var markerValue = markerCounter.get(node) - 1;
          counterMap.set(node, counterValue);
          markerCounter.set(node, markerValue);
          if (!counterValue) {
            if (!uncontrolledNodes.has(node)) {
              node.removeAttribute(controlAttribute);
            }
            uncontrolledNodes.delete(node);
          }
          if (!markerValue) {
            node.removeAttribute(markerName);
          }
        });
        lockCount--;
        if (!lockCount) {
          counterMap = /* @__PURE__ */ new WeakMap();
          counterMap = /* @__PURE__ */ new WeakMap();
          uncontrolledNodes = /* @__PURE__ */ new WeakMap();
          markerMap = {};
        }
      };
    };
    hideOthers = function(originalTarget, parentNode, markerName) {
      if (markerName === void 0) {
        markerName = "data-aria-hidden";
      }
      var targets = Array.from(Array.isArray(originalTarget) ? originalTarget : [originalTarget]);
      var activeParentNode = parentNode || getDefaultParent(originalTarget);
      if (!activeParentNode) {
        return function() {
          return null;
        };
      }
      targets.push.apply(targets, Array.from(activeParentNode.querySelectorAll("[aria-live]")));
      return applyAttributeToOthers(targets, activeParentNode, markerName, "aria-hidden");
    };
  }
});

// node_modules/@radix-ui/react-dialog/dist/index.mjs
function getState(open) {
  return open ? "open" : "closed";
}
var React25, import_jsx_runtime10, DIALOG_NAME, createDialogContext, createDialogScope, DialogProvider, useDialogContext, Dialog, TRIGGER_NAME, DialogTrigger, PORTAL_NAME2, PortalProvider, usePortalContext, DialogPortal, OVERLAY_NAME, DialogOverlay, Slot2, DialogOverlayImpl, CONTENT_NAME, DialogContent, DialogContentModal, DialogContentNonModal, DialogContentImpl, TITLE_NAME, DialogTitle, DESCRIPTION_NAME, DialogDescription, CLOSE_NAME, DialogClose, TITLE_WARNING_NAME, WarningProvider, useWarningContext, TitleWarning, DESCRIPTION_WARNING_NAME, DescriptionWarning, Root, Trigger, Portal2, Overlay, Content, Title, Description, Close;
var init_dist17 = __esm({
  "node_modules/@radix-ui/react-dialog/dist/index.mjs"() {
    "use client";
    React25 = __toESM(require_react(), 1);
    init_dist4();
    init_dist();
    init_dist5();
    init_dist7();
    init_dist8();
    init_dist12();
    init_dist13();
    init_dist14();
    init_dist15();
    init_dist9();
    init_dist16();
    init_es20156();
    init_es20157();
    init_dist2();
    import_jsx_runtime10 = __toESM(require_jsx_runtime(), 1);
    DIALOG_NAME = "Dialog";
    [createDialogContext, createDialogScope] = createContextScope(DIALOG_NAME);
    [DialogProvider, useDialogContext] = createDialogContext(DIALOG_NAME);
    Dialog = (props) => {
      const {
        __scopeDialog,
        children,
        open: openProp,
        defaultOpen,
        onOpenChange,
        modal = true
      } = props;
      const triggerRef = React25.useRef(null);
      const contentRef = React25.useRef(null);
      const [open, setOpen] = useControllableState({
        prop: openProp,
        defaultProp: defaultOpen ?? false,
        onChange: onOpenChange,
        caller: DIALOG_NAME
      });
      return /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
        DialogProvider,
        {
          scope: __scopeDialog,
          triggerRef,
          contentRef,
          contentId: useId(),
          titleId: useId(),
          descriptionId: useId(),
          open,
          onOpenChange: setOpen,
          onOpenToggle: React25.useCallback(() => setOpen((prevOpen) => !prevOpen), [setOpen]),
          modal,
          children
        }
      );
    };
    Dialog.displayName = DIALOG_NAME;
    TRIGGER_NAME = "DialogTrigger";
    DialogTrigger = React25.forwardRef(
      (props, forwardedRef) => {
        const { __scopeDialog, ...triggerProps } = props;
        const context = useDialogContext(TRIGGER_NAME, __scopeDialog);
        const composedTriggerRef = useComposedRefs(forwardedRef, context.triggerRef);
        return /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
          Primitive.button,
          {
            type: "button",
            "aria-haspopup": "dialog",
            "aria-expanded": context.open,
            "aria-controls": context.contentId,
            "data-state": getState(context.open),
            ...triggerProps,
            ref: composedTriggerRef,
            onClick: composeEventHandlers(props.onClick, context.onOpenToggle)
          }
        );
      }
    );
    DialogTrigger.displayName = TRIGGER_NAME;
    PORTAL_NAME2 = "DialogPortal";
    [PortalProvider, usePortalContext] = createDialogContext(PORTAL_NAME2, {
      forceMount: void 0
    });
    DialogPortal = (props) => {
      const { __scopeDialog, forceMount, children, container } = props;
      const context = useDialogContext(PORTAL_NAME2, __scopeDialog);
      return /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(PortalProvider, { scope: __scopeDialog, forceMount, children: React25.Children.map(children, (child) => /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(Presence, { present: forceMount || context.open, children: /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(Portal, { asChild: true, container, children: child }) })) });
    };
    DialogPortal.displayName = PORTAL_NAME2;
    OVERLAY_NAME = "DialogOverlay";
    DialogOverlay = React25.forwardRef(
      (props, forwardedRef) => {
        const portalContext = usePortalContext(OVERLAY_NAME, props.__scopeDialog);
        const { forceMount = portalContext.forceMount, ...overlayProps } = props;
        const context = useDialogContext(OVERLAY_NAME, props.__scopeDialog);
        return context.modal ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(Presence, { present: forceMount || context.open, children: /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(DialogOverlayImpl, { ...overlayProps, ref: forwardedRef }) }) : null;
      }
    );
    DialogOverlay.displayName = OVERLAY_NAME;
    Slot2 = createSlot("DialogOverlay.RemoveScroll");
    DialogOverlayImpl = React25.forwardRef(
      (props, forwardedRef) => {
        const { __scopeDialog, ...overlayProps } = props;
        const context = useDialogContext(OVERLAY_NAME, __scopeDialog);
        return (
          // Make sure `Content` is scrollable even when it doesn't live inside `RemoveScroll`
          // ie. when `Overlay` and `Content` are siblings
          /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(Combination_default, { as: Slot2, allowPinchZoom: true, shards: [context.contentRef], children: /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
            Primitive.div,
            {
              "data-state": getState(context.open),
              ...overlayProps,
              ref: forwardedRef,
              style: { pointerEvents: "auto", ...overlayProps.style }
            }
          ) })
        );
      }
    );
    CONTENT_NAME = "DialogContent";
    DialogContent = React25.forwardRef(
      (props, forwardedRef) => {
        const portalContext = usePortalContext(CONTENT_NAME, props.__scopeDialog);
        const { forceMount = portalContext.forceMount, ...contentProps } = props;
        const context = useDialogContext(CONTENT_NAME, props.__scopeDialog);
        return /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(Presence, { present: forceMount || context.open, children: context.modal ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(DialogContentModal, { ...contentProps, ref: forwardedRef }) : /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(DialogContentNonModal, { ...contentProps, ref: forwardedRef }) });
      }
    );
    DialogContent.displayName = CONTENT_NAME;
    DialogContentModal = React25.forwardRef(
      (props, forwardedRef) => {
        const context = useDialogContext(CONTENT_NAME, props.__scopeDialog);
        const contentRef = React25.useRef(null);
        const composedRefs = useComposedRefs(forwardedRef, context.contentRef, contentRef);
        React25.useEffect(() => {
          const content = contentRef.current;
          if (content) return hideOthers(content);
        }, []);
        return /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
          DialogContentImpl,
          {
            ...props,
            ref: composedRefs,
            trapFocus: context.open,
            disableOutsidePointerEvents: true,
            onCloseAutoFocus: composeEventHandlers(props.onCloseAutoFocus, (event) => {
              event.preventDefault();
              context.triggerRef.current?.focus();
            }),
            onPointerDownOutside: composeEventHandlers(props.onPointerDownOutside, (event) => {
              const originalEvent = event.detail.originalEvent;
              const ctrlLeftClick = originalEvent.button === 0 && originalEvent.ctrlKey === true;
              const isRightClick = originalEvent.button === 2 || ctrlLeftClick;
              if (isRightClick) event.preventDefault();
            }),
            onFocusOutside: composeEventHandlers(
              props.onFocusOutside,
              (event) => event.preventDefault()
            )
          }
        );
      }
    );
    DialogContentNonModal = React25.forwardRef(
      (props, forwardedRef) => {
        const context = useDialogContext(CONTENT_NAME, props.__scopeDialog);
        const hasInteractedOutsideRef = React25.useRef(false);
        const hasPointerDownOutsideRef = React25.useRef(false);
        return /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
          DialogContentImpl,
          {
            ...props,
            ref: forwardedRef,
            trapFocus: false,
            disableOutsidePointerEvents: false,
            onCloseAutoFocus: (event) => {
              props.onCloseAutoFocus?.(event);
              if (!event.defaultPrevented) {
                if (!hasInteractedOutsideRef.current) context.triggerRef.current?.focus();
                event.preventDefault();
              }
              hasInteractedOutsideRef.current = false;
              hasPointerDownOutsideRef.current = false;
            },
            onInteractOutside: (event) => {
              props.onInteractOutside?.(event);
              if (!event.defaultPrevented) {
                hasInteractedOutsideRef.current = true;
                if (event.detail.originalEvent.type === "pointerdown") {
                  hasPointerDownOutsideRef.current = true;
                }
              }
              const target = event.target;
              const targetIsTrigger = context.triggerRef.current?.contains(target);
              if (targetIsTrigger) event.preventDefault();
              if (event.detail.originalEvent.type === "focusin" && hasPointerDownOutsideRef.current) {
                event.preventDefault();
              }
            }
          }
        );
      }
    );
    DialogContentImpl = React25.forwardRef(
      (props, forwardedRef) => {
        const { __scopeDialog, trapFocus, onOpenAutoFocus, onCloseAutoFocus, ...contentProps } = props;
        const context = useDialogContext(CONTENT_NAME, __scopeDialog);
        const contentRef = React25.useRef(null);
        const composedRefs = useComposedRefs(forwardedRef, contentRef);
        useFocusGuards();
        return /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)(import_jsx_runtime10.Fragment, { children: [
          /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
            FocusScope,
            {
              asChild: true,
              loop: true,
              trapped: trapFocus,
              onMountAutoFocus: onOpenAutoFocus,
              onUnmountAutoFocus: onCloseAutoFocus,
              children: /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
                DismissableLayer,
                {
                  role: "dialog",
                  id: context.contentId,
                  "aria-describedby": context.descriptionId,
                  "aria-labelledby": context.titleId,
                  "data-state": getState(context.open),
                  ...contentProps,
                  ref: composedRefs,
                  onDismiss: () => context.onOpenChange(false)
                }
              )
            }
          ),
          /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)(import_jsx_runtime10.Fragment, { children: [
            /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(TitleWarning, { titleId: context.titleId }),
            /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(DescriptionWarning, { contentRef, descriptionId: context.descriptionId })
          ] })
        ] });
      }
    );
    TITLE_NAME = "DialogTitle";
    DialogTitle = React25.forwardRef(
      (props, forwardedRef) => {
        const { __scopeDialog, ...titleProps } = props;
        const context = useDialogContext(TITLE_NAME, __scopeDialog);
        return /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(Primitive.h2, { id: context.titleId, ...titleProps, ref: forwardedRef });
      }
    );
    DialogTitle.displayName = TITLE_NAME;
    DESCRIPTION_NAME = "DialogDescription";
    DialogDescription = React25.forwardRef(
      (props, forwardedRef) => {
        const { __scopeDialog, ...descriptionProps } = props;
        const context = useDialogContext(DESCRIPTION_NAME, __scopeDialog);
        return /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(Primitive.p, { id: context.descriptionId, ...descriptionProps, ref: forwardedRef });
      }
    );
    DialogDescription.displayName = DESCRIPTION_NAME;
    CLOSE_NAME = "DialogClose";
    DialogClose = React25.forwardRef(
      (props, forwardedRef) => {
        const { __scopeDialog, ...closeProps } = props;
        const context = useDialogContext(CLOSE_NAME, __scopeDialog);
        return /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
          Primitive.button,
          {
            type: "button",
            ...closeProps,
            ref: forwardedRef,
            onClick: composeEventHandlers(props.onClick, () => context.onOpenChange(false))
          }
        );
      }
    );
    DialogClose.displayName = CLOSE_NAME;
    TITLE_WARNING_NAME = "DialogTitleWarning";
    [WarningProvider, useWarningContext] = createContext2(TITLE_WARNING_NAME, {
      contentName: CONTENT_NAME,
      titleName: TITLE_NAME,
      docsSlug: "dialog"
    });
    TitleWarning = ({ titleId }) => {
      const titleWarningContext = useWarningContext(TITLE_WARNING_NAME);
      const MESSAGE = `\`${titleWarningContext.contentName}\` requires a \`${titleWarningContext.titleName}\` for the component to be accessible for screen reader users.

If you want to hide the \`${titleWarningContext.titleName}\`, you can wrap it with our VisuallyHidden component.

For more information, see https://radix-ui.com/primitives/docs/components/${titleWarningContext.docsSlug}`;
      React25.useEffect(() => {
        if (titleId) {
          const hasTitle = document.getElementById(titleId);
          if (!hasTitle) console.error(MESSAGE);
        }
      }, [MESSAGE, titleId]);
      return null;
    };
    DESCRIPTION_WARNING_NAME = "DialogDescriptionWarning";
    DescriptionWarning = ({ contentRef, descriptionId }) => {
      const descriptionWarningContext = useWarningContext(DESCRIPTION_WARNING_NAME);
      const MESSAGE = `Warning: Missing \`Description\` or \`aria-describedby={undefined}\` for {${descriptionWarningContext.contentName}}.`;
      React25.useEffect(() => {
        const describedById = contentRef.current?.getAttribute("aria-describedby");
        if (descriptionId && describedById) {
          const hasDescription = document.getElementById(descriptionId);
          if (!hasDescription) console.warn(MESSAGE);
        }
      }, [MESSAGE, contentRef, descriptionId]);
      return null;
    };
    Root = Dialog;
    Trigger = DialogTrigger;
    Portal2 = DialogPortal;
    Overlay = DialogOverlay;
    Content = DialogContent;
    Title = DialogTitle;
    Description = DialogDescription;
    Close = DialogClose;
  }
});

// src/components/ui/dialog.tsx
var React26, import_jsx_runtime11, Dialog2, DialogTrigger2, DialogPortal2, DialogOverlay2, DialogContent2, DialogHeader, DialogFooter, DialogTitle2, DialogDescription2;
var init_dialog = __esm({
  "src/components/ui/dialog.tsx"() {
    React26 = __toESM(require_react(), 1);
    init_dist17();
    init_lucide_react();
    init_utils();
    import_jsx_runtime11 = __toESM(require_jsx_runtime(), 1);
    Dialog2 = Root;
    DialogTrigger2 = Trigger;
    DialogPortal2 = Portal2;
    DialogOverlay2 = React26.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(
      Overlay,
      {
        ref,
        className: cn(
          "fixed inset-0 z-50 bg-black/80 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
          className
        ),
        ...props
      }
    ));
    DialogOverlay2.displayName = Overlay.displayName;
    DialogContent2 = React26.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime11.jsxs)(DialogPortal2, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(DialogOverlay2, {}),
      /* @__PURE__ */ (0, import_jsx_runtime11.jsxs)(
        Content,
        {
          ref,
          className: cn(
            "fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] sm:rounded-lg",
            className
          ),
          ...props,
          children: [
            children,
            /* @__PURE__ */ (0, import_jsx_runtime11.jsxs)(Close, { className: "absolute right-2 top-2 p-2 rounded-sm opacity-70 ring-offset-background transition-opacity data-[state=open]:bg-accent data-[state=open]:text-muted-foreground hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none", children: [
              /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(X, { className: "h-4 w-4" }),
              /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("span", { className: "sr-only", children: "Close" })
            ] })
          ]
        }
      )
    ] }));
    DialogContent2.displayName = Content.displayName;
    DialogHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("div", { className: cn("flex flex-col space-y-1.5 text-center sm:text-left", className), ...props });
    DialogHeader.displayName = "DialogHeader";
    DialogFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("div", { className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className), ...props });
    DialogFooter.displayName = "DialogFooter";
    DialogTitle2 = React26.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(
      Title,
      {
        ref,
        className: cn("text-lg font-semibold leading-none tracking-tight", className),
        ...props
      }
    ));
    DialogTitle2.displayName = Title.displayName;
    DialogDescription2 = React26.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(Description, { ref, className: cn("text-sm text-muted-foreground", className), ...props }));
    DialogDescription2.displayName = Description.displayName;
  }
});

// src/components/soccer-career/ThroughBallBoard.module.css
var ThroughBallBoard_default;
var init_ThroughBallBoard = __esm({
  "src/components/soccer-career/ThroughBallBoard.module.css"() {
    ThroughBallBoard_default = {
      board: "ThroughBallBoard_board",
      field: "ThroughBallBoard_field",
      reply: "ThroughBallBoard_reply",
      settled: "ThroughBallBoard_settled",
      rules: "ThroughBallBoard_rules"
    };
  }
});

// src/components/soccer-career/ThroughBallBoard.tsx
var ThroughBallBoard_exports = {};
__export(ThroughBallBoard_exports, {
  default: () => ThroughBallBoard
});
function Rules({ trains, match }) {
  if (match) return /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)("div", { className: "space-y-2 text-xs text-muted-foreground", children: [
    /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("p", { children: "One ball. Your runner starts onside, waits a moment, then cuts in across the defensive line. Drag on the pitch to the spot you want the ball to stop: where you drag is the direction, how far is the weight. Let go to play it." }),
    /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("p", { children: "It comes off when it goes through a gap in the line, stops short of the keeper and lands on his run in time. Play it after he crosses the line and he is offside. Too soft and it dies before the line or behind him; too hard and it runs to the keeper or away from him." }),
    /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("p", { children: "Or focus the pitch: Left and Right turn the aim, Up and Down set the weight, Space starts the run and plays the pass. Pause freezes the clock." })
  ] });
  return /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)("div", { className: "space-y-2 text-xs text-muted-foreground", children: [
    /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("p", { children: "Ten runs. Your runner starts onside, waits a moment, then cuts in across the defensive line. Drag on the pitch to the spot you want the ball to stop: where you drag is the direction, how far is the weight. Let go to play it." }),
    /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("p", { children: "A pass scores 10 when it goes through a gap in the line, stops short of the keeper and lands on his run in time. Play it after he crosses the line and he is offside. Too soft and it dies before the line or behind him; too hard and it runs to the keeper or away from him. Off the side of the pitch is out of play. Later runs are quicker and the gaps get tighter. The clock and his timings stay on screen the whole run, including with reduced motion." }),
    /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("p", { children: "Drag and let go with a mouse or a finger. Or focus the pitch: Left and Right turn the aim, Up and Down set the weight, Space starts the run and plays the pass. The buttons under the pitch do the same. Pause freezes the clock, and coming back from another tab needs Resume." }),
    /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)("p", { children: [
      "Today's ten save after every ball and can bank once. Practice is unlimited and never banks. One career session per season: 50 earns +1 ",
      trains,
      ", 80 earns +2, capped by your ceiling, with next season's growth."
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)("p", { children: [
      /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("strong", { className: "text-foreground", children: "Example:" }),
      " he goes at 1.00s and crosses the line at 2.40s. Play it at about 2.20s into the space a step ahead of his run, through the gap, and he takes it in stride for 10. The same pass at 2.50s is offside."
    ] })
  ] });
}
function ThroughBallBoard({ career, canBank, onBank, onBack, match }) {
  const SLUG = DRILL_META.throughball.slug;
  const trains = drillStatFor("throughball", career.position).label;
  const today = (0, import_react7.useRef)(getTodayET()).current;
  const [daily, setDaily] = (0, import_react7.useState)(() => match ? null : readDailyRecord(SLUG, today, validateThroughBallRecord));
  const [mode, setMode] = (0, import_react7.useState)(match ? "match" : "daily");
  const [run, setRun] = (0, import_react7.useState)(() => buildThroughBallRun(match ? match.seed : drillSeed("throughball", today)));
  const [phase, setPhase] = (0, import_react7.useState)(match ? "ready" : "intro");
  const phaseRef = (0, import_react7.useRef)(match ? "ready" : "intro");
  const told = (0, import_react7.useRef)(false);
  const [record, setRecord] = (0, import_react7.useState)(EMPTY);
  const recordRef = (0, import_react7.useRef)(EMPTY);
  const bankedRef = (0, import_react7.useRef)(false);
  const [index, setIndex] = (0, import_react7.useState)(match ? match.round : 0);
  const [aim, setAimState] = (0, import_react7.useState)(START_AIM);
  const aimRef = (0, import_react7.useRef)(START_AIM);
  const dragging = (0, import_react7.useRef)(false);
  const [seconds, setSeconds] = (0, import_react7.useState)(0);
  const [result, setResult] = (0, import_react7.useState)(null);
  const [paused, setPaused] = (0, import_react7.useState)(false);
  const pausedRef = (0, import_react7.useRef)(false);
  const [help, setHelp] = (0, import_react7.useState)(false);
  const helpRef = (0, import_react7.useRef)(false);
  const [reduced, setReduced] = (0, import_react7.useState)(reducedMotion);
  const flight = useArcadeFlight(700);
  const elapsed = (0, import_react7.useRef)(0);
  const startedAt = (0, import_react7.useRef)(0);
  const running = (0, import_react7.useRef)(false);
  const epoch = (0, import_react7.useRef)(0);
  const reveal = (0, import_react7.useRef)(0);
  const mounted = (0, import_react7.useRef)(true);
  const frame = (0, import_react7.useRef)(null);
  const deadline = (0, import_react7.useRef)(null);
  const resolveRef = (0, import_react7.useRef)(() => {
  });
  const setup = run[index];
  const move = (next) => {
    phaseRef.current = next;
    setPhase(next);
  };
  const setAim = (next) => {
    const held = clampAim(next);
    aimRef.current = held;
    setAimState(held);
  };
  const activeSeconds = (0, import_react7.useCallback)(() => elapsed.current + (running.current ? (performance.now() - startedAt.current) / 1e3 : 0), []);
  const stopClock = (0, import_react7.useCallback)(() => {
    elapsed.current = activeSeconds();
    running.current = false;
    epoch.current++;
    if (frame.current !== null) cancelAnimationFrame(frame.current);
    if (deadline.current !== null) window.clearTimeout(deadline.current);
    frame.current = null;
    deadline.current = null;
  }, [activeSeconds]);
  const startClock = () => {
    if (document.hidden || helpRef.current || pausedRef.current) return;
    running.current = true;
    startedAt.current = performance.now();
    const token = ++epoch.current;
    const current = () => mounted.current && epoch.current === token && phaseRef.current === "playing" && !pausedRef.current;
    const tick = () => {
      if (!current()) return;
      setSeconds(activeSeconds());
      frame.current = requestAnimationFrame(tick);
    };
    frame.current = requestAnimationFrame(tick);
    deadline.current = window.setTimeout(() => {
      if (current()) resolveRef.current(Math.max(activeSeconds(), throughBallDeadline(setup) + 1e-3));
    }, Math.max(0, (throughBallDeadline(setup) - elapsed.current) * 1e3) + 1);
  };
  const pause = (0, import_react7.useCallback)(() => {
    if (pausedRef.current || phaseRef.current !== "playing" && phaseRef.current !== "resolve") return;
    pausedRef.current = true;
    setPaused(true);
    dragging.current = false;
    stopClock();
    if (phaseRef.current === "resolve") flight.pause();
  }, [stopClock, flight.pause]);
  (0, import_react7.useEffect)(() => {
    mounted.current = true;
    const visibility = () => {
      if (document.hidden) pause();
    };
    document.addEventListener("visibilitychange", visibility);
    const media = typeof window.matchMedia === "function" ? window.matchMedia("(prefers-reduced-motion: reduce)") : null;
    const change = () => setReduced(Boolean(media?.matches));
    media?.addEventListener?.("change", change);
    return () => {
      mounted.current = false;
      reveal.current++;
      stopClock();
      document.removeEventListener("visibilitychange", visibility);
      media?.removeEventListener?.("change", change);
    };
  }, [pause, stopClock]);
  const save = (next) => {
    if (mode === "daily") {
      const newer = readDailyRecord(SLUG, today, validateThroughBallRecord);
      if (newer && (newer.rounds > next.rounds || newer.banked)) next = newer;
    }
    recordRef.current = next;
    setRecord(next);
    if (mode === "daily") {
      writeDailyRecord(SLUG, today, { ...next });
      setDaily(next);
    }
  };
  resolveRef.current = (press) => {
    if (!mounted.current || phaseRef.current !== "playing" || pausedRef.current || helpRef.current) return;
    if (mode === "daily" && restoreNewerDaily()) return;
    dragging.current = false;
    move("resolve");
    stopClock();
    setSeconds(press);
    const played = match ? { angle: r42(aimRef.current.angle), weight: r42(aimRef.current.weight), press: r42(press) } : { ...aimRef.current, press };
    const settled2 = takeThroughBall(played, setup);
    setResult(settled2);
    const previous = recordRef.current;
    const count3 = previous.count + Number(settled2.won);
    save({ rounds: previous.rounds + 1, count: count3, score: count3 * 10, banked: false });
    const token = ++reveal.current;
    flight.launch(() => {
      if (mounted.current && reveal.current === token && phaseRef.current === "resolve") move(recordRef.current.rounds === 10 ? "done" : "roundEnd");
      if (match && !told.current) {
        told.current = true;
        match.onResult({ won: settled2.won, points: settled2.points, verdict: settled2.verdict, input: [played.angle, played.weight, played.press] });
      }
    });
  };
  const clearRound = () => {
    reveal.current++;
    stopClock();
    flight.reset();
    elapsed.current = 0;
    setSeconds(0);
    setResult(null);
    pausedRef.current = false;
    setPaused(false);
    dragging.current = false;
  };
  const restoreNewerDaily = () => {
    const newer = readDailyRecord(SLUG, today, validateThroughBallRecord);
    if (!newer || newer.rounds <= recordRef.current.rounds && !newer.banked) return false;
    clearRound();
    recordRef.current = newer;
    setRecord(newer);
    setDaily(newer);
    bankedRef.current = newer.banked;
    setIndex(Math.min(newer.rounds, 9));
    move(newer.rounds === 10 ? "done" : "ready");
    return true;
  };
  const startRun = (nextMode) => {
    clearRound();
    setMode(nextMode);
    const restored = nextMode === "daily" ? readDailyRecord(SLUG, today, validateThroughBallRecord) : null;
    const next = restored ?? { ...EMPTY };
    if (nextMode === "daily") setDaily(restored);
    recordRef.current = next;
    setRecord(next);
    bankedRef.current = next.banked;
    setRun(buildThroughBallRun(nextMode === "daily" ? drillSeed("throughball", today) : Math.floor(Math.random() * 2147483645) + 1));
    setIndex(Math.min(next.rounds, 9));
    setAim(START_AIM);
    move(next.rounds === 10 ? "done" : "ready");
  };
  const advance = () => {
    clearRound();
    if (recordRef.current.rounds === 10) {
      move("done");
      return;
    }
    setIndex(recordRef.current.rounds);
    move("ready");
  };
  const action = () => {
    if (pausedRef.current || helpRef.current) return;
    if (phaseRef.current === "ready") {
      if (document.hidden) return;
      elapsed.current = 0;
      setSeconds(0);
      move("playing");
      startClock();
    } else if (phaseRef.current === "playing") resolveRef.current(activeSeconds());
    else if (match) return;
    else if (phaseRef.current === "resolve" || phaseRef.current === "roundEnd") advance();
  };
  const resume = () => {
    if (!pausedRef.current || document.hidden || helpRef.current) return;
    pausedRef.current = false;
    setPaused(false);
    if (phaseRef.current === "playing") startClock();
    else if (phaseRef.current === "resolve") flight.resume();
  };
  const bank = () => {
    if (mode !== "daily" || phaseRef.current !== "done" || recordRef.current.rounds !== 10 || !canBank || bankedRef.current || recordRef.current.banked) return;
    const stored = readDailyRecord(SLUG, today, validateThroughBallRecord);
    if (stored?.banked) {
      bankedRef.current = true;
      save(stored);
      return;
    }
    bankedRef.current = true;
    save({ ...recordRef.current, banked: true });
    onBank("throughball", recordRef.current.count);
  };
  const leave = () => {
    clearRound();
    move("intro");
    onBack();
  };
  const changeMode = () => {
    clearRound();
    move("intro");
  };
  const aiming = () => !pausedRef.current && !helpRef.current && (phaseRef.current === "ready" || phaseRef.current === "playing");
  const nudge2 = (angle, weight) => {
    if (aiming()) setAim({ angle: aimRef.current.angle + angle, weight: aimRef.current.weight + weight });
  };
  const aimAtPointer = (event) => {
    const box = event.currentTarget.getBoundingClientRect();
    if (!box.width || !box.height) return;
    setAim(aimFor({ x: (event.clientX - box.left) / box.width * 360, y: (event.clientY - box.top) / box.height * 240 }));
  };
  const pointerDown = (event) => {
    if (!aiming()) return;
    dragging.current = true;
    event.currentTarget.setPointerCapture?.(event.pointerId);
    aimAtPointer(event);
  };
  const pointerMove = (event) => {
    if (dragging.current && aiming()) aimAtPointer(event);
  };
  const pointerUp = (event) => {
    if (!dragging.current) return;
    dragging.current = false;
    if (!aiming()) return;
    aimAtPointer(event);
    if (phaseRef.current === "playing") resolveRef.current(activeSeconds());
  };
  const replay = result ? result.press + (reduced ? 1 : flight.progress) * (replayEnd(result) - result.press) : 0;
  const runner = result ? runnerAt(setup, replay) : reduced && phase === "playing" ? setup.start : runnerAt(setup, seconds);
  const ball = result ? ballAt(result, replay) : PASSER;
  const spot = passTarget(aim.angle, aim.weight);
  const runEnd = runnerAt(setup, setup.hold + runTime(setup));
  const crossAt = crossTime(setup);
  const crossing = runnerAt(setup, crossAt);
  const boost = drillBoost(record.score, drillHeadroom(career));
  const active = phase === "playing" || phase === "resolve";
  const canAim = !paused && (phase === "ready" || phase === "playing");
  const actionText = phase === "ready" ? "Start run" : phase === "playing" ? "Play it" : phase === "done" ? "Session complete" : record.rounds === 10 ? "See session" : "Next ball";
  const aimText = `${Math.abs(aim.angle).toFixed(0)}\xB0 ${aim.angle < 0 ? "left" : aim.angle > 0 ? "right" : "straight"} \xB7 weight ${Math.round(aim.weight * 100)}%`;
  return /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)("div", { className: `p-3 space-y-2 ${ThroughBallBoard_default.board}`, "data-through-ball-board": true, "data-mode": mode, "data-phase": phase, children: [
    /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)("div", { className: "flex items-center justify-between gap-2", children: [
      match ? /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("span", { className: "w-11" }) : /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("button", { onClick: leave, className: "px-2 text-xs font-bold text-muted-foreground", children: "\u2039 Drills" }),
      /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("h3", { className: "text-sm font-black", children: "\u{1F3AF} Through Ball" }),
      /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)(Dialog2, { open: help, onOpenChange: (open) => {
        if (open) pause();
        helpRef.current = open;
        setHelp(open);
      }, children: [
        /* @__PURE__ */ (0, import_jsx_runtime12.jsx)(DialogTrigger2, { asChild: true, children: /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("button", { "aria-label": "Through Ball rules", className: "w-11 rounded-lg bg-muted/40 font-black", children: "?" }) }),
        /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)(DialogContent2, { className: `w-[calc(100%-24px)] max-w-sm max-h-[85vh] overflow-y-auto p-5 ${ThroughBallBoard_default.rules}`, onKeyDown: (event) => {
          if (event.key === "Escape") event.stopPropagation();
        }, children: [
          /* @__PURE__ */ (0, import_jsx_runtime12.jsx)(DialogTitle2, { children: "Through Ball rules" }),
          /* @__PURE__ */ (0, import_jsx_runtime12.jsx)(DialogDescription2, { children: "Read his run, then weight it into his path." }),
          /* @__PURE__ */ (0, import_jsx_runtime12.jsx)(Rules, { trains, match: !!match })
        ] })
      ] })
    ] }),
    phase === "intro" ? /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)("div", { className: "space-y-3", children: [
      /* @__PURE__ */ (0, import_jsx_runtime12.jsx)(Rules, { trains }),
      daily && /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)("p", { className: "text-xs font-bold", children: [
        "Today: ",
        daily.count,
        " through, ",
        daily.rounds,
        "/10 played",
        daily.banked ? ", banked" : "",
        "."
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("button", { onClick: () => startRun("daily"), className: "w-full rounded-lg bg-emerald-600 px-3 font-black text-black text-sm", children: daily?.rounds === 10 ? "View today\u2019s result" : daily?.rounds ? "Resume today\u2019s ten" : "Play today\u2019s ten" }),
      /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("button", { onClick: () => startRun("practice"), className: "w-full rounded-lg bg-muted/40 px-3 text-sm font-bold", children: "Practice, no banking" })
    ] }) : /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)(import_jsx_runtime12.Fragment, { children: [
      match ? /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("div", { className: "text-center text-xs font-bold", "data-through-match": true, children: "One ball. Read his run, then weight it into his path." }) : /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)("div", { className: "flex justify-between gap-2 text-xs font-bold tabular-nums", children: [
        /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)("span", { children: [
          mode === "daily" ? "Today" : "Practice",
          " \xB7 Ball ",
          Math.min(index + 1, 10),
          "/10"
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)("span", { "data-through-score": true, children: [
          record.score,
          "/100 \xB7 ",
          record.count,
          " through"
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("div", { className: ThroughBallBoard_default.field, tabIndex: 0, role: "group", "aria-label": "Through Ball pitch, Left and Right aim, Up and Down set the weight, Space starts the run or plays the pass", onKeyDown: (event) => {
        if (event.target !== event.currentTarget || event.repeat || pausedRef.current || helpRef.current) return;
        const turns = { ArrowLeft: [-ANGLE_STEP, 0], ArrowRight: [ANGLE_STEP, 0], ArrowUp: [0, WEIGHT_STEP], ArrowDown: [0, -WEIGHT_STEP] };
        if (turns[event.key]) {
          event.preventDefault();
          nudge2(...turns[event.key]);
        } else if (event.code === "Space" || event.key === " ") {
          event.preventDefault();
          action();
        }
      }, children: /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)(
        "svg",
        {
          viewBox: "0 0 360 240",
          className: "w-full rounded-xl border border-border",
          role: "img",
          "aria-label": `Runner goes at ${setup.hold.toFixed(2)} seconds and crosses the line at ${crossAt.toFixed(2)} seconds`,
          style: { background: "linear-gradient(#166534, #14532d)" },
          onPointerDown: pointerDown,
          onPointerMove: pointerMove,
          onPointerUp: pointerUp,
          onPointerCancel: () => {
            dragging.current = false;
          },
          children: [
            /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("path", { d: `M${PITCH_LEFT} 225V18H${PITCH_RIGHT}V225`, fill: "none", stroke: "white", strokeOpacity: ".2" }),
            /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("rect", { x: "150", y: "10", width: "60", height: "8", fill: "none", stroke: "white", strokeOpacity: ".6" }),
            /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("path", { d: `M110 18V${KEEPER_Y}H250V18`, fill: "none", stroke: "white", strokeOpacity: ".3" }),
            /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("circle", { cx: "180", cy: "27", r: "6", fill: "#a855f7" }),
            /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("path", { d: `M${PITCH_LEFT} ${setup.line}H${PITCH_RIGHT}`, stroke: "#fca5a5", strokeOpacity: ".55", strokeDasharray: "6 5", "data-defensive-line": true }),
            setup.defenders.map((x, i) => /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("circle", { "data-defender": true, cx: x, cy: setup.line, r: "7", fill: "#ef4444", stroke: "#7f1d1d", strokeWidth: "2" }, i)),
            /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("path", { d: `M${setup.start.x} ${setup.start.y}L${runEnd.x} ${runEnd.y}`, fill: "none", stroke: "#fde68a", strokeOpacity: ".45", strokeDasharray: "4 5", "data-runner-path": true }),
            /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("circle", { cx: crossing.x, cy: crossing.y, r: "3", fill: "#fde68a", fillOpacity: ".7", "data-runner-crossing": true }),
            canAim && /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("path", { d: `M${PASSER.x} ${PASSER.y}L${spot.x} ${spot.y}`, stroke: "white", strokeOpacity: ".5", strokeDasharray: "2 4" }),
            (canAim || result) && /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("circle", { "data-aim-target": true, cx: result ? result.target.x : spot.x, cy: result ? result.target.y : spot.y, r: "9", fill: "none", stroke: "#fbbf24", strokeWidth: "2" }),
            /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("circle", { cx: PASSER.x, cy: PASSER.y, r: "8", fill: "#38bdf8" }),
            /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("circle", { "data-runner": true, cx: runner.x, cy: runner.y, r: "7", fill: "#fbbf24", stroke: "#78350f", strokeWidth: "2" }),
            /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("circle", { "data-through-ball": true, cx: ball.x, cy: ball.y, r: "5", fill: "white", stroke: "#172554", strokeWidth: "2" })
          ]
        }
      ) }),
      /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)("div", { className: "text-center text-xs tabular-nums h-9", "data-through-clock": true, children: [
        /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("div", { className: "font-black", children: paused ? "Paused, press Resume" : `${seconds.toFixed(2)}s \xB7 ${aimText}` }),
        /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)("div", { className: "text-muted-foreground", children: [
          "He goes at ",
          setup.hold.toFixed(2),
          "s, crosses the line at ",
          crossAt.toFixed(2),
          "s",
          reduced ? " \xB7 static pitch" : ""
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)("div", { className: "grid grid-cols-4 gap-2", children: [
        /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("button", { onClick: () => nudge2(-ANGLE_STEP, 0), disabled: !canAim, className: "rounded-lg border border-border bg-muted/20 text-xs font-bold disabled:opacity-50", children: "Aim left" }),
        /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("button", { onClick: () => nudge2(ANGLE_STEP, 0), disabled: !canAim, className: "rounded-lg border border-border bg-muted/20 text-xs font-bold disabled:opacity-50", children: "Aim right" }),
        /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("button", { onClick: () => nudge2(0, -WEIGHT_STEP), disabled: !canAim, className: "rounded-lg border border-border bg-muted/20 text-xs font-bold disabled:opacity-50", children: "Softer" }),
        /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("button", { onClick: () => nudge2(0, WEIGHT_STEP), disabled: !canAim, className: "rounded-lg border border-border bg-muted/20 text-xs font-bold disabled:opacity-50", children: "Harder" })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("button", { onClick: action, onKeyDown: (event) => {
          if (event.repeat && (event.key === " " || event.key === "Enter")) event.preventDefault();
        }, disabled: paused || phase === "done" || !!match && (phase === "resolve" || phase === "roundEnd"), "data-through-action": true, className: "flex-1 rounded-lg bg-emerald-600 text-black text-sm font-black disabled:opacity-50", children: match && (phase === "resolve" || phase === "roundEnd") ? "Played" : actionText }),
        /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("button", { onClick: paused ? resume : pause, disabled: !active, className: "w-20 rounded-lg bg-muted/40 text-xs font-bold disabled:opacity-50", children: paused ? "Resume" : "Pause" })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("div", { className: "min-h-10 text-center text-xs font-bold", "aria-live": "polite", children: result && /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("p", { "data-through-verdict": result.outcome, className: `${ThroughBallBoard_default.reply} ${result.won ? "text-emerald-400" : "text-amber-300"}`, children: result.verdict }) }),
      /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("div", { className: "min-h-20 space-y-2 text-center text-xs", children: phase === "done" && /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)(import_jsx_runtime12.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("p", { className: "font-bold", children: mode === "practice" ? "Practice complete. No career reward." : record.banked ? "Session banked." : !canBank ? "Already trained this season. Today\u2019s result is saved." : boost > 0 ? `+${boost} ${trains} with next season\u2019s growth.` : record.score >= 50 ? `At your ceiling. No extra ${trains} to add.` : "Below 50. No stat gain this time." }),
        mode === "daily" && (canBank || record.banked) && /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("button", { "data-through-bank": true, onClick: record.banked ? leave : bank, className: "w-full rounded-lg bg-emerald-600 text-black text-sm font-black", children: record.banked ? "Back to drills" : "Bank the session" }),
        mode === "practice" && /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("button", { onClick: () => startRun("practice"), className: "w-full rounded-lg bg-muted/40 text-sm font-bold", children: "Another practice" })
      ] }) }),
      !match && /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("button", { onClick: changeMode, className: "w-full rounded-lg bg-muted/20 text-xs font-bold", children: "Daily / practice menu" })
    ] })
  ] });
}
var import_react7, import_jsx_runtime12, r42, EMPTY, START_AIM, ANGLE_STEP, WEIGHT_STEP, reducedMotion, clampAim;
var init_ThroughBallBoard2 = __esm({
  "src/components/soccer-career/ThroughBallBoard.tsx"() {
    import_react7 = __toESM(require_react(), 1);
    init_dialog();
    init_useArcadeFlight();
    init_dateUtils();
    init_dailyRecord();
    init_careerDrills();
    init_throughBallDrill();
    init_ThroughBallBoard();
    import_jsx_runtime12 = __toESM(require_jsx_runtime(), 1);
    r42 = (v) => Math.round(v * 1e4) / 1e4;
    EMPTY = { rounds: 0, count: 0, score: 0, banked: false };
    START_AIM = { angle: 0, weight: 0.55 };
    ANGLE_STEP = 2;
    WEIGHT_STEP = 0.02;
    reducedMotion = () => typeof window.matchMedia === "function" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    clampAim = (aim) => ({
      angle: Math.round(Math.max(-MAX_ANGLE, Math.min(MAX_ANGLE, aim.angle)) * 100) / 100,
      weight: Math.round(Math.max(0, Math.min(1, aim.weight)) * 1e3) / 1e3
    });
  }
});

// src/lib/clubManagerClock.ts
function minuteLabel(e) {
  return e.plus ? `${e.minute}+${e.plus}'` : `${e.minute}'`;
}
var init_clubManagerClock = __esm({
  "src/lib/clubManagerClock.ts"() {
  }
});

// src/lib/safeStorage.ts
var PROBE_KEY = "__dukb_storage_probe__";
function createMemoryStorage(under = null, onRefused) {
  const kept = /* @__PURE__ */ new Map();
  const gone = /* @__PURE__ */ new Set();
  let below = under;
  const keys = () => {
    const out = [];
    if (below) {
      try {
        for (let i = 0; i < below.length; i += 1) {
          const k = below.key(i);
          if (k !== null && !gone.has(k) && !kept.has(k)) out.push(k);
        }
      } catch {
      }
    }
    return [...out, ...kept.keys()];
  };
  const store = {
    get length() {
      return keys().length;
    },
    key(index) {
      return keys()[index] ?? null;
    },
    getItem(key) {
      const k = String(key);
      if (kept.has(k)) return kept.get(k);
      if (!below || gone.has(k)) return null;
      try {
        return below.getItem(k);
      } catch {
        return null;
      }
    },
    setItem(key, value) {
      const k = String(key);
      const v = String(value);
      gone.delete(k);
      if (below) {
        try {
          below.setItem(k, v);
          kept.delete(k);
          return;
        } catch {
          onRefused?.();
        }
      }
      kept.set(k, v);
    },
    removeItem(key) {
      const k = String(key);
      kept.delete(k);
      if (!below) return;
      try {
        below.removeItem(k);
      } catch {
        gone.add(k);
      }
    },
    clear() {
      kept.clear();
      gone.clear();
      if (!below) return;
      try {
        below.clear();
      } catch {
        below = null;
      }
    }
  };
  return store;
}
function resolve(name, onRefused) {
  let real = null;
  try {
    real = window[name] ?? null;
  } catch {
    real = null;
  }
  if (real) {
    try {
      real.getItem(PROBE_KEY);
      return { storage: createMemoryStorage(real, onRefused), real, blocked: false };
    } catch {
    }
  }
  const memory = createMemoryStorage();
  try {
    Object.defineProperty(window, name, { configurable: true, enumerable: true, get: () => memory });
  } catch {
  }
  return { storage: memory, real: null, blocked: true };
}
function standInForLocks() {
  try {
    const locks = window.navigator?.locks;
    if (!locks || typeof locks.request !== "function") return;
    const native = locks.request.bind(locks);
    const request = (...args) => {
      const callback = args[args.length - 1];
      if (typeof callback !== "function") return native(...args);
      let entered = false;
      const watched = (lock) => {
        entered = true;
        return callback(lock);
      };
      let asked;
      try {
        asked = Promise.resolve(native(...args.slice(0, -1), watched));
      } catch (error) {
        asked = Promise.reject(error);
      }
      return asked.catch((error) => {
        const refused = !entered && !!error && error.name === "SecurityError";
        if (!refused) throw error;
        return callback({ name: String(args[0]), mode: "exclusive" });
      });
    };
    Object.defineProperty(locks, "request", { configurable: true, writable: true, value: request });
  } catch {
  }
}
function rawRequested() {
  try {
    return window.__DUKB_RAW_STORAGE__ === true;
  } catch {
    return false;
  }
}
var raw = rawRequested();
var refusedWrite = false;
var noteRefusedWrite = () => {
  refusedWrite = true;
};
var local = raw ? { storage: window.localStorage, real: null, blocked: false } : resolve("localStorage", noteRefusedWrite);
var session = raw ? { storage: window.sessionStorage, real: null, blocked: false } : resolve("sessionStorage", () => {
});
if (local.blocked) standInForLocks();
var safeLocalStorage = local.storage;
var safeSessionStorage = session.storage;
var sessionStorageIsMemory = session.blocked;

// ../../_temp/own-goals-1167.sj5mbQ/viewer-candidate/entry.tsx
var import_client = __toESM(require_client());

// src/components/soccer-career/SoccerSeasonCentre.tsx
var import_react17 = __toESM(require_react(), 1);

// src/lib/leagueCore.ts
function roundRobinCalendar(n) {
  const teams = Array.from({ length: n }, (_, i) => i);
  if (n % 2 === 1) teams.push(-1);
  const half = teams.length / 2;
  const firstLeg = [];
  for (let round = 0; round < teams.length - 1; round++) {
    for (let k = 0; k < half; k++) {
      const a = teams[k];
      const b = teams[teams.length - 1 - k];
      if (a === -1 || b === -1) continue;
      firstLeg.push(round % 2 === 0 ? [a, b] : [b, a]);
    }
    teams.splice(1, 0, teams.pop());
  }
  return [...firstLeg, ...firstLeg.map(([h, a]) => [a, h])];
}

// src/lib/season/core.ts
init_keyedRng();
var clampN = (v, lo, hi) => v < lo ? lo : v > hi ? hi : v;
function shuffled(xs, rng) {
  const a = xs.slice();
  for (let i = a.length - 1; i > 0; i -= 1) {
    const j = Math.floor(rng() * (i + 1));
    const t = a[i];
    a[i] = a[j];
    a[j] = t;
  }
  return a;
}
function standingsOf(rounds, teams, rule, md) {
  const rows = Array.from({ length: teams }, (_, slot) => ({ slot, p: 0, w: 0, d: 0, l: 0, gf: 0, ga: 0, pts: 0 }));
  for (let r2 = 0; r2 < md && r2 < rounds.length; r2 += 1) {
    for (const [h, a, hg, ag] of rounds[r2]) {
      const H = rows[h];
      const A = rows[a];
      H.p += 1;
      A.p += 1;
      H.gf += hg;
      H.ga += ag;
      A.gf += ag;
      A.ga += hg;
      if (hg > ag) {
        H.w += 1;
        A.l += 1;
        H.pts += rule.win;
        A.pts += rule.loss;
      } else if (hg < ag) {
        A.w += 1;
        H.l += 1;
        A.pts += rule.win;
        H.pts += rule.loss;
      } else {
        H.d += 1;
        A.d += 1;
        H.pts += rule.draw;
        A.pts += rule.draw;
      }
    }
  }
  return rows.sort((x, y) => y.pts - x.pts || y.gf - y.ga - (x.gf - x.ga) || y.gf - x.gf || x.slot - y.slot);
}
function tableAt(s, md) {
  if (s.mode !== "table" || !s.rule) return [];
  return standingsOf(s.rounds, s.teams, s.rule, md);
}
function soFar(s, md) {
  const out = { apps: 0 };
  for (const g of s.games) {
    if (g.md > md || !g.played) continue;
    out.apps += 1;
    for (const [k, v] of Object.entries(g.line)) out[k] = (out[k] ?? 0) + v;
  }
  return out;
}
function roundRobinRounds(teams) {
  const flat = roundRobinCalendar(teams);
  const per = Math.floor(teams / 2);
  const out = [];
  for (let i = 0; i < flat.length; i += per) out.push(flat.slice(i, i + per));
  return out;
}
function ownRowRounds(teams) {
  return roundRobinRounds(teams).map((r2) => r2.filter(([h, a]) => h === 0 || a === 0)).filter((r2) => r2.length > 0);
}
function placeFixed(rounds, fixed, rng) {
  const mine = [];
  rounds.forEach((pairs, r2) => {
    for (const [h, a] of pairs) if (h === 0 || a === 0) mine.push({ r: r2, opp: h === 0 ? a : h, home: h === 0 });
  });
  const fixedAt = mine.map(() => null);
  const slotOf = /* @__PURE__ */ new Map();
  const keys = [];
  for (const f of fixed) if (!keys.includes(f.key)) keys.push(f.key);
  const taken = /* @__PURE__ */ new Set();
  for (const key of keys) {
    const meetings = fixed.filter((f) => f.key === key);
    const slots = [...new Set(mine.map((m) => m.opp))].filter((s2) => !taken.has(s2)).sort((x, y) => x - y);
    const fits = slots.filter((s2) => {
      const legs = mine.filter((m) => m.opp === s2);
      return legs.length === meetings.length && legs.every((m, i2) => m.home === meetings[i2].home);
    });
    if (fits.length === 0) return null;
    const s = fits[Math.floor(rng() * fits.length)];
    taken.add(s);
    slotOf.set(key, s);
    let i = 0;
    mine.forEach((m, idx) => {
      if (m.opp === s) {
        fixedAt[idx] = meetings[i];
        i += 1;
      }
    });
  }
  return { mine, fixedAt, slotOf };
}
function chooseAvailability(p, a, rng) {
  const M = p.mine.length;
  const fixedPlayed = p.fixedAt.map((f) => !!f && f.played);
  const nFixedPlayed = fixedPlayed.filter(Boolean).length;
  const need = a.played - nFixedPlayed;
  if (need < 0 || a.played > M) return null;
  const played = fixedPlayed.slice();
  const why = p.mine.map(() => void 0);
  const free = (i) => !p.fixedAt[i];
  if (a.severe) {
    let lastFixed = -1;
    fixedPlayed.forEach((x, i) => {
      if (x) lastFixed = i;
    });
    let W = lastFixed + 1;
    let avail = 0;
    for (let i = 0; i < W; i += 1) if (free(i)) avail += 1;
    while (avail < need && W < M) {
      if (free(W)) avail += 1;
      W += 1;
    }
    if (avail < need) return null;
    const pool2 = [];
    for (let i = 0; i < W; i += 1) if (free(i)) pool2.push(i);
    const lastFree = pool2.length ? pool2[pool2.length - 1] : -1;
    const mustLast = need > 0 && lastFree === W - 1 && lastFixed < W - 1;
    const rest = shuffled(pool2.filter((i) => !(mustLast && i === lastFree)), rng).slice(0, need - (mustLast ? 1 : 0));
    if (mustLast) played[lastFree] = true;
    for (const i of rest) played[i] = true;
    let last = -1;
    played.forEach((x, i) => {
      if (x) last = i;
    });
    for (let i = last + 1; i < M; i += 1) why[i] = i <= last + a.block ? "injured" : "rested";
    for (let i = 0; i <= last; i += 1) if (!played[i]) why[i] = "rested";
    return { played, why };
  }
  if (a.block > 0) {
    const starts = [];
    for (let s2 = 0; s2 + a.block <= M; s2 += 1) {
      let ok = true;
      for (let i = s2; i < s2 + a.block; i += 1) if (fixedPlayed[i]) {
        ok = false;
        break;
      }
      if (!ok) continue;
      let room = 0;
      for (let i = 0; i < M; i += 1) if (free(i) && (i < s2 || i >= s2 + a.block)) room += 1;
      if (room >= need) starts.push(s2);
    }
    if (starts.length === 0) return null;
    const s = starts[Math.floor(rng() * starts.length)];
    for (let i = s; i < s + a.block; i += 1) why[i] = "injured";
  }
  const pool = p.mine.map((_, i) => i).filter((i) => free(i) && why[i] !== "injured");
  if (pool.length < need) return null;
  for (const i of shuffled(pool, rng).slice(0, need)) played[i] = true;
  for (let i = 0; i < M; i += 1) if (!played[i] && !why[i]) why[i] = "rested";
  return { played, why };
}
function pickWeighted(weights, rng) {
  let sum = 0;
  for (const w of weights) sum += w > 0 ? w : 0;
  if (sum <= 0) return -1;
  let x = rng() * sum;
  for (let i = 0; i < weights.length; i += 1) {
    if (weights[i] <= 0) continue;
    x -= weights[i];
    if (x < 0) return i;
  }
  for (let i = weights.length - 1; i >= 0; i -= 1) if (weights[i] > 0) return i;
  return -1;
}
function teamFloor(totals, line) {
  let s = 0;
  for (const t of totals) if (t.kind === "sum" && t.teamFor) s += (line[t.key] ?? 0) * (t.teamPoints ?? 1);
  return s;
}
function allocate(p, av, totals, bucketApps, rng) {
  const M = p.mine.length;
  const lines = p.fixedAt.map((f) => f ? { ...f.line } : {});
  const bucket = {};
  const marks = p.mine.map(() => void 0);
  const phase = rng() * Math.PI * 2;
  const form = p.mine.map((_, i) => (1 + 0.45 * Math.sin(phase + i / Math.max(1, M) * Math.PI * 2)) * (0.6 + rng() * 0.8));
  const teamSum = (i) => teamFloor(totals, lines[i]);
  const cardTaken = (i, group) => totals.some((t) => t.kind === "sum" && t.distinct === group && (lines[i][t.key] ?? 0) > 0);
  const bucketCards = (group) => totals.reduce((s, t) => s + (t.kind === "sum" && t.distinct === group ? bucket[t.key] ?? 0 : 0), 0);
  const order = [...totals.filter((t) => t.kind === "sum" && !t.distinct), ...totals.filter((t) => t.kind === "sum" && t.distinct && t.suspends), ...totals.filter((t) => t.kind === "sum" && t.distinct && !t.suspends), ...totals.filter((t) => t.kind === "count-of")];
  let lastPlayed = -1;
  av.played.forEach((x, i) => {
    if (x) lastPlayed = i;
  });
  for (const t of order) {
    if (t.kind === "sum" && !t.distinct) {
      let rem = t.total;
      const owns = (i) => !!p.fixedAt[i] && p.fixedAt[i].line[t.key] !== void 0;
      for (let i = 0; i < M; i += 1) if (owns(i)) rem -= p.fixedAt[i].line[t.key];
      if (rem < 0) return null;
      bucket[t.key] = 0;
      for (let i = 0; i < M; i += 1) if (!owns(i)) lines[i][t.key] = 0;
      for (let u = 0; u < rem; u += 1) {
        const w = p.mine.map((_, i) => {
          if (!av.played[i] || owns(i) || lines[i][t.key] >= t.perGameCap) return 0;
          const f = p.fixedAt[i];
          if (t.teamFor && f && teamSum(i) + (t.teamPoints ?? 1) > f.us) return 0;
          return form[i];
        });
        const bucketRoom = !t.noBucket && bucket[t.key] < t.perGameCap * bucketApps;
        w.push(bucketRoom ? bucketApps * 0.9 : 0);
        const at = pickWeighted(w, rng);
        if (at < 0) return null;
        if (at === M) bucket[t.key] += 1;
        else lines[at][t.key] += 1;
      }
    } else if (t.kind === "sum" && t.distinct) {
      bucket[t.key] = 0;
      for (let i = 0; i < M; i += 1) lines[i][t.key] = 0;
      for (let u = 0; u < t.total; u += 1) {
        const ok = p.mine.map((_, i) => {
          if (!av.played[i] || cardTaken(i, t.distinct)) return 0;
          if (!t.suspends) return 1;
          if (i === lastPlayed) return 1;
          return i + 1 < M && !av.played[i + 1] && av.why[i + 1] === "rested" ? 1 : 0;
        });
        ok.push(bucketCards(t.distinct) < bucketApps ? Math.max(0.5, bucketApps * 0.3) : 0);
        const at = pickWeighted(ok, rng);
        if (at < 0) return null;
        if (at === M) {
          bucket[t.key] += 1;
          continue;
        }
        lines[at][t.key] = 1;
        if (t.suspends && at !== lastPlayed) av.why[at + 1] = "suspended";
      }
    } else if (t.kind === "count-of") {
      let rem = t.total;
      const free = [];
      for (let i = 0; i < M; i += 1) {
        if (!av.played[i]) continue;
        const f = p.fixedAt[i];
        if (f) {
          const cs = f.them === 0 ? 1 : 0;
          lines[i][t.key] = cs;
          rem -= cs;
        } else free.push(i);
      }
      if (rem < 0) return null;
      const n = free.length;
      const lo = Math.max(0, rem - bucketApps);
      const hi = Math.min(rem, n);
      if (lo > hi) return null;
      const inLeague = n + bucketApps > 0 ? clampN(Math.round(rem * n / (n + bucketApps)), lo, hi) : 0;
      const pick = new Set(shuffled(free, rng).slice(0, inLeague));
      for (const i of free) {
        const s = pick.has(i);
        marks[i] = s ? "shutout" : "concede";
        lines[i][t.key] = s ? 1 : 0;
      }
      bucket[t.key] = rem - inLeague;
    }
  }
  const floors = p.mine.map((_, i) => av.played[i] ? teamSum(i) : 0);
  for (let i = 0; i < M; i += 1) {
    const f = p.fixedAt[i];
    if (f && f.us < floors[i]) return null;
  }
  for (let i = 0; i < M; i += 1) if (!av.played[i]) lines[i] = {};
  return { lines, bucket, marks, floors };
}
var GOAL_CAP = 7;
var cell = (r2, k) => `${r2}:${k}`;
function bounds(L, r2, k, homeSide) {
  const i = L.at.get(cell(r2, k));
  if (i === void 0) return [0, L.cap];
  if (L.p.fixedAt[i]) return null;
  const m = L.p.mine[i];
  const usSide = m.home === homeSide;
  if (usSide) return [L.al.floors[i], L.cap];
  const mark = L.al.marks[i];
  return mark === "shutout" ? [0, 0] : mark === "concede" ? [1, L.cap] : [0, L.cap];
}
function nudge(board, L, slot, dir, rng) {
  const opts = [];
  board.forEach((pairs, r3) => pairs.forEach((g, k2) => {
    if (g[0] !== slot && g[1] !== slot) return;
    const home = g[0] === slot;
    const si = home ? 2 : 3;
    const oi = home ? 3 : 2;
    const sb = bounds(L, r3, k2, home);
    const ob = bounds(L, r3, k2, !home);
    if (!sb || !ob) return;
    const s = g[si];
    const o = g[oi];
    if (L.wide) {
      if (dir === 1 && s <= o && o + 1 <= sb[1]) opts.push([r3, k2, si, o + 1 - s]);
      if (dir === -1 && s >= o && s + 1 <= ob[1]) opts.push([r3, k2, oi, s + 1 - o]);
      return;
    }
    if (dir === 1 && (s === o || s === o - 1)) {
      if (s + 1 <= sb[1]) opts.push([r3, k2, si, 1]);
      if (o - 1 >= ob[0]) opts.push([r3, k2, oi, -1]);
    }
    if (dir === -1 && (s === o || s === o + 1)) {
      if (o + 1 <= ob[1]) opts.push([r3, k2, oi, 1]);
      if (s - 1 >= sb[0]) opts.push([r3, k2, si, -1]);
    }
  }));
  if (opts.length === 0) return false;
  const [r2, k, idx, d] = opts[Math.floor(rng() * opts.length)];
  board[r2][k][idx] += d;
  return true;
}
function violation(board, frame, target, slotOf) {
  if (target.kind === "none") return null;
  if (target.kind === "record" || target.kind === "band") {
    let w = 0;
    let d = 0;
    let n = 0;
    for (const pairs of board) for (const [h, a, hg, ag] of pairs) {
      if (h !== 0 && a !== 0) continue;
      const us = h === 0 ? hg : ag;
      const them = h === 0 ? ag : hg;
      n += 1;
      if (us > them) w += 1;
      else if (us === them) d += 1;
    }
    if (target.kind === "record") return w < target.winsMin ? { slot: 0, dir: 1 } : w > target.winsMax ? { slot: 0, dir: -1 } : null;
    const rule = frame.rule ?? { win: 3, draw: 1, loss: 0 };
    const ppg = n ? (w * rule.win + d * rule.draw) / n : 0;
    return ppg < target.ppgMin ? { slot: 0, dir: 1 } : ppg > target.ppgMax ? { slot: 0, dir: -1 } : null;
  }
  const rows = standingsOf(board, frame.teams, frame.rule, board.length);
  const f = target.finish;
  const pos = rows.findIndex((x) => x.slot === 0) + 1;
  if (pos > f) return { slot: 0, dir: 1, alt: { slot: rows[pos - 2].slot, dir: -1 } };
  if (pos < f) return { slot: 0, dir: -1, alt: { slot: rows[pos].slot, dir: 1 } };
  if (f > 1 && rows[f - 2].pts === rows[f - 1].pts) return { slot: rows[f - 2].slot, dir: 1 };
  if (f < rows.length && rows[f].pts === rows[f - 1].pts) return { slot: rows[f].slot, dir: -1 };
  if (f === 1) return null;
  if (rows[0].pts === rows[1].pts) return { slot: rows[0].slot, dir: 1, alt: rows[1].slot !== 0 ? { slot: rows[1].slot, dir: -1 } : void 0 };
  const fixedSlots = new Set(slotOf.values());
  const ch = target.champion;
  if (typeof ch === "object") {
    const ks = slotOf.get(ch.key);
    if (ks === void 0) return { slot: rows[0].slot, dir: -1 };
    if (rows[0].slot !== ks) return { slot: ks, dir: 1, alt: { slot: rows[0].slot, dir: -1 } };
  } else if (ch === "other" && fixedSlots.has(rows[0].slot)) {
    return { slot: rows[0].slot, dir: -1 };
  }
  return null;
}
var ATTEMPTS = 30;
var REPAIRS = 40;
function playAttempt(sport, frame, rounds, L, str, key, t, target, slotOf) {
  const rng = keyedRng(`${key}|score|${t}`);
  const board = rounds.map((pairs, r2) => pairs.map(([h, a], k) => {
    const i = L.at.get(cell(r2, k));
    if (i === void 0) {
      const [hg, ag] = sport.score(str[h] - str[a], true, rng);
      return [h, a, hg, ag];
    }
    const f = L.p.fixedAt[i];
    const m = L.p.mine[i];
    let us;
    let them;
    if (f) {
      us = f.us;
      them = f.them;
    } else {
      [us, them] = sport.score(str[0] - str[m.opp], m.home, rng);
      us = Math.min(L.cap, Math.max(us, L.al.floors[i]));
      const mark = L.al.marks[i];
      if (mark === "shutout") them = 0;
      else if (mark === "concede") them = Math.max(1, them);
    }
    return m.home ? [h, a, us, them] : [h, a, them, us];
  }));
  for (let n = 0; n <= REPAIRS; n += 1) {
    const v = violation(board, frame, target, slotOf);
    if (!v) return { board, repairs: n };
    if (n === REPAIRS) break;
    const first = v.alt && rng() < 0.5 ? v.alt : v;
    const second = first === v ? v.alt : v;
    if (!nudge(board, L, first.slot, first.dir, rng) && !(second && nudge(board, L, second.slot, second.dir, rng))) break;
  }
  return null;
}
function clinchOf(rounds, teams, rule) {
  const total = new Array(teams).fill(0);
  for (const pairs of rounds) for (const [h, a] of pairs) {
    total[h] += 1;
    total[a] += 1;
  }
  for (let md = 1; md <= rounds.length; md += 1) {
    const rows = standingsOf(rounds, teams, rule, md);
    const me = rows.find((x) => x.slot === 0);
    if (rows.every((x) => x.slot === 0 || me.pts > x.pts + rule.win * (total[x.slot] - x.p))) return md;
  }
  return null;
}
function fitMean(games, t, base, rng) {
  const on = games.filter((g) => g.played);
  if (on.length === 0) return true;
  const step = t.perGame === "int" ? 1 : 0.1;
  const snap = (v) => Math.round(clampN(v, t.min, t.max) / step) * step;
  const vals = on.map((g) => snap(base(g) + (rng() - 0.5) * (t.perGame === "int" ? 2 : 1.2)));
  const scale = t.dp === 1 ? 10 : 1;
  const target = Math.round(t.mean * scale);
  const meanOk = () => Math.round(vals.reduce((s, v) => s + v, 0) / vals.length * scale + 1e-9) === target;
  for (let n = 0; n < 4e3 && !meanOk(); n += 1) {
    const up = vals.reduce((s, v) => s + v, 0) / vals.length < t.mean;
    const can = vals.map((v, i2) => (up ? v + step <= t.max + 1e-9 : v - step >= t.min - 1e-9) ? i2 : -1).filter((i2) => i2 >= 0);
    if (can.length === 0) return false;
    const i = can[Math.floor(rng() * can.length)];
    vals[i] = Math.round((vals[i] + (up ? step : -step)) / step) * step;
  }
  if (!meanOk()) return false;
  on.forEach((g, i) => {
    g.line[t.key] = Math.round(vals[i] * 10) / 10;
  });
  return true;
}
function deriveSeason(sport, row, ctx) {
  const s = deriveSeasonOrWhy(sport, row, ctx);
  return typeof s === "string" ? null : s;
}
function deriveSeasonOrWhy(sport, row, ctx) {
  const key = sport.seasonKey(row, ctx);
  if (key === null) return "nokey";
  const frame = sport.frame(row, ctx);
  const cal = keyedRng(`${key}|cal`);
  const rounds = sport.fixtures(frame, cal);
  const p = placeFixed(rounds, sport.fixed(row, ctx, frame), cal);
  if (!p) return "fixed";
  const av = chooseAvailability(p, sport.availability(row, ctx, frame), keyedRng(`${key}|avail`));
  if (!av) return "availability";
  const shown = av.played.filter(Boolean).length;
  const bucketApps = sport.apps(row) - shown;
  if (bucketApps < 0) return "apps";
  const totals = sport.totals(row, ctx);
  const al = allocate(p, av, totals, bucketApps, keyedRng(`${key}|alloc`));
  if (!al) return "allocation";
  const target = sport.target(row, ctx, frame);
  const at = /* @__PURE__ */ new Map();
  p.mine.forEach((m, i) => at.set(cell(m.r, rounds[m.r].findIndex(([h, a]) => h === 0 || a === 0)), i));
  const L = { at, p, al, cap: frame.cap ?? GOAL_CAP, wide: frame.mode === "record" };
  const str = sport.strengths(frame, target, p.slotOf, ctx, keyedRng(`${key}|str`));
  let won = null;
  let attempt = 0;
  for (; attempt < ATTEMPTS && !won; attempt += 1) won = playAttempt(sport, frame, rounds, L, str, key, attempt, target, p.slotOf);
  if (!won) return "attempts";
  const board = won.board;
  const minRng = keyedRng(`${key}|min`);
  const subChance = sport.subChance(shown, p.mine.length);
  const games = p.mine.map((m, i) => {
    const k = rounds[m.r].findIndex(([h, a]) => h === 0 || a === 0);
    const [, , hg, ag] = board[m.r][k];
    const f = p.fixedAt[i];
    const g = { md: m.r + 1, opp: m.opp, home: m.home, us: m.home ? hg : ag, them: m.home ? ag : hg, fixed: !!f, played: av.played[i], started: false, line: al.lines[i], events: [] };
    if (f) g.fixedKey = f.key;
    if (!av.played[i]) g.why = av.why[i];
    if (al.marks[i]) g.mark = al.marks[i];
    const injured = av.played[i] && i + 1 < p.mine.length && av.why[i + 1] === "injured";
    if (sport.events) sport.events(g, f, { injured, subChance }, minRng);
    else g.started = g.played;
    return g;
  });
  for (const t of totals) {
    if (t.kind === "mean" && !fitMean(games, t, (g) => sport.meanBase(t.key, g), minRng)) return "mean";
    if (t.kind === "max") {
      const on = games.filter((g) => g.played);
      if (on.length) {
        const top = Math.floor(minRng() * on.length);
        on.forEach((g, i) => {
          g.line[t.key] = i === top ? t.max : Math.floor(minRng() * (t.max + 1));
        });
      }
    }
  }
  if (sport.finish && !sport.finish(games, row, ctx, keyedRng(`${key}|fin`))) return "finish";
  const rows = frame.mode === "table" && frame.rule ? standingsOf(board, frame.teams, frame.rule, board.length) : [];
  const keyOfSlot = /* @__PURE__ */ new Map();
  p.slotOf.forEach((s2, k) => keyOfSlot.set(s2, k));
  const facts = Array.from({ length: frame.teams }, (_, slot) => {
    const pos = rows.findIndex((x) => x.slot === slot) + 1;
    return { slot, pos, fixedKey: keyOfSlot.get(slot) ?? null, champion: pos === 1 && slot !== 0 };
  });
  const labels = sport.labels(facts, ctx, keyedRng(`${key}|label`));
  const title = target.kind === "finish" && target.title;
  const md = title && frame.rule ? clinchOf(board, frame.teams, frame.rule) : null;
  const s = {
    key,
    mode: frame.mode,
    rule: frame.rule,
    teams: frame.teams,
    labels,
    games,
    rounds: board,
    bucket: { apps: bucketApps, line: al.bucket },
    clinch: md ? { md } : null,
    target,
    attempt: attempt - 1,
    repairs: won.repairs
  };
  const bad = disagreements(sport, row, ctx, s);
  return bad.length === 0 ? s : `self: ${bad[0]}`;
}
function disagreements(sport, row, ctx, s) {
  const out = [];
  const frame = sport.frame(row, ctx);
  const a = sport.availability(row, ctx, frame);
  const on = s.games.filter((g) => g.played);
  const bucket = s.bucket ?? { apps: 0, line: {} };
  if (on.length + bucket.apps !== sport.apps(row)) out.push(`apps ${on.length}+${bucket.apps} != ${sport.apps(row)}`);
  if (on.length !== a.played) out.push(`league played ${on.length} != ${a.played}`);
  if (s.games.length !== frame.games) out.push(`games ${s.games.length} != ${frame.games}`);
  for (const t of sport.totals(row, ctx)) {
    const vals = on.map((g) => g.line[t.key] ?? 0);
    if (t.kind === "sum") {
      const total = vals.reduce((x, v) => x + v, 0) + (bucket.line[t.key] ?? 0);
      if (total !== t.total) out.push(`${t.key} ${total} != ${t.total}`);
      if (vals.some((v) => v > t.perGameCap)) out.push(`${t.key} over its cap in a game`);
      if (t.noBucket && (bucket.line[t.key] ?? 0) > 0) out.push(`${t.key} in the bucket`);
      if ((bucket.line[t.key] ?? 0) > t.perGameCap * bucket.apps) out.push(`${t.key} bucket over its cap`);
    } else if (t.kind === "count-of") {
      const shown = on.filter((g) => g.them === 0).length;
      if (shown + (bucket.line[t.key] ?? 0) !== t.total) out.push(`${t.key} ${shown}+${bucket.line[t.key] ?? 0} != ${t.total}`);
      if (on.some((g) => (g.line[t.key] ?? 0) !== (g.them === 0 ? 1 : 0))) out.push(`${t.key} mark disagrees with a score`);
    } else if (t.kind === "mean" && on.length) {
      const scale = t.dp === 1 ? 10 : 1;
      const mean = vals.reduce((x, v) => x + v, 0) / vals.length;
      if (Math.round(mean * scale + 1e-9) !== Math.round(t.mean * scale)) out.push(`${t.key} mean ${mean.toFixed(3)} != ${t.mean}`);
      if (vals.some((v) => v < t.min - 1e-9 || v > t.max + 1e-9)) out.push(`${t.key} out of range`);
    } else if (t.kind === "max" && on.length && Math.max(...vals) !== t.max) out.push(`${t.key} max != ${t.max}`);
  }
  const totalsNow = sport.totals(row, ctx);
  for (const g of on) if (teamFloor(totalsNow, g.line) > g.us) out.push(`md ${g.md}: his line puts more on the board than his club scored`);
  for (const g of s.games) {
    if (!g.events.some((e) => e.pts)) continue;
    const us = g.events.reduce((x, e) => x + (e.side === "us" ? e.pts ?? 0 : 0), 0);
    const them = g.events.reduce((x, e) => x + (e.side === "them" ? e.pts ?? 0 : 0), 0);
    if (us !== g.us || them !== g.them) out.push(`md ${g.md}: the events' points do not make the score`);
  }
  const fixed = sport.fixed(row, ctx, frame);
  const keys = [...new Set(fixed.map((f) => f.key))];
  for (const k of keys) {
    const want = fixed.filter((f) => f.key === k);
    const got = s.games.filter((g) => g.fixedKey === k);
    if (got.length !== want.length) {
      out.push(`fixed ${k}: ${got.length} games for ${want.length}`);
      continue;
    }
    want.forEach((f, i) => {
      const g = got[i];
      if (g.home !== f.home || g.us !== f.us || g.them !== f.them || g.played !== f.played) out.push(`fixed ${k} #${i + 1} differs`);
      for (const [lk, lv] of Object.entries(f.line)) if (f.played && (g.line[lk] ?? 0) !== lv) out.push(`fixed ${k} #${i + 1} ${lk}`);
    });
  }
  const inj = s.games.map((g) => g.why === "injured");
  const first = inj.indexOf(true);
  const runEnd = first < 0 ? -1 : (() => {
    let e = first;
    while (e + 1 < inj.length && inj[e + 1]) e += 1;
    return e;
  })();
  const run = first < 0 ? 0 : runEnd - first + 1;
  if (inj.lastIndexOf(true) !== runEnd) out.push("injury is not one run");
  if (a.severe) {
    const last = s.games.map((g) => g.played).lastIndexOf(true);
    if (run !== Math.min(a.block, s.games.length - last - 1)) out.push(`severe injury run ${run}`);
    if (first >= 0 && first !== last + 1) out.push("severe injury does not follow his last game");
  } else if (run !== a.block) out.push(`injury run ${run} != ${a.block}`);
  const redKey = sport.totals(row, ctx).find((t) => t.kind === "sum" && t.suspends)?.key;
  for (const [i, g] of s.games.entries()) {
    const red = !!redKey && (g.line[redKey] ?? 0) > 0;
    if (red && s.games[i + 1]?.why !== "suspended" && s.games.slice(i + 1).some((x) => x.played)) out.push(`md ${g.md}: a red with no suspension`);
  }
  out.push(...targetDisagreements(s, frame, sport.target(row, ctx, frame)));
  if (sport.check) out.push(...sport.check(row, ctx, s));
  return out;
}
function targetDisagreements(s, frame, target) {
  const out = [];
  if (JSON.stringify(target) !== JSON.stringify(s.target)) out.push("the season carries another team target than its row");
  const slotOf = /* @__PURE__ */ new Map();
  for (const g of s.games) if (g.fixedKey) slotOf.set(g.fixedKey, g.opp);
  if (violation(s.rounds, frame, target, slotOf)) out.push(`team target not met (${target.kind})`);
  if (s.mode === "table" && s.rule) {
    const title = target.kind === "finish" && target.title;
    const md = title ? clinchOf(s.rounds, s.teams, s.rule) : null;
    if ((s.clinch?.md ?? null) !== md) out.push("clinch round");
    const rows = standingsOf(s.rounds, s.teams, s.rule, s.rounds.length);
    if (rows.some((r2) => r2.pts !== s.rule.win * r2.w + s.rule.draw * r2.d + s.rule.loss * r2.l)) out.push("points rule");
    if (rows.some((r2) => r2.p !== frame.games)) out.push("games played");
  }
  return out;
}
var turned = (d) => ({
  us: d.us === 0 ? 0 : -d.us,
  them: d.them === 0 ? 0 : -d.them,
  line: Object.fromEntries(Object.entries(d.line).map(([k, v]) => [k, v === 0 ? 0 : -v]))
});
var touchesLine = (d) => Object.values(d.line).some((v) => v !== 0);
var momentKey = (s, spot) => `${s.key}|moment|${spot.md}|${spot.minute}|${spot.kind}|${spot.planSuccess ? 1 : 0}`;
function withGames(s, changed) {
  const by = new Map(changed.map((g) => [g.md, g]));
  const games = s.games.map((g) => by.get(g.md) ?? g);
  const rounds = s.rounds.map((pairs, r2) => {
    const g = by.get(r2 + 1);
    if (!g) return pairs;
    return pairs.map((p) => p[0] === 0 || p[1] === 0 ? g.home ? [p[0], p[1], g.us, g.them] : [p[0], p[1], g.them, g.us] : p);
  });
  const title = s.target.kind === "finish" && s.target.title;
  const md = title && s.rule && s.mode === "table" ? clinchOf(rounds, s.teams, s.rule) : null;
  return { ...s, games, rounds, clinch: md ? { md } : null };
}
function ownRecord(s) {
  let w = 0, d = 0, l = 0, gf = 0, ga = 0;
  for (const g of s.games) {
    gf += g.us;
    ga += g.them;
    if (g.us > g.them) w += 1;
    else if (g.us < g.them) l += 1;
    else d += 1;
  }
  return `${w}|${d}|${l}|${gf}|${ga}`;
}
function finalLine(s) {
  return s.mode === "table" && s.rule ? JSON.stringify(standingsOf(s.rounds, s.teams, s.rule, s.rounds.length)) : ownRecord(s);
}
function otherOutcome(sport, row, ctx, s, spot) {
  const hook = sport.moments;
  if (!hook) return null;
  const g = s.games[spot.md - 1];
  if (!g || g.md !== spot.md || !g.played || g.fixed) return null;
  const meetings = s.games.filter((x) => x.opp === g.opp);
  if (meetings.length !== 2) return null;
  const back = meetings.find((x) => x.md !== g.md);
  if (back.md <= g.md || back.fixed) return null;
  if (touchesLine(spot.delta) && !back.played) return null;
  const key = momentKey(s, spot);
  const a = hook.apply(row, ctx, g, spot.delta, spot.minute, keyedRng(`${key}|a`));
  if (!a) return null;
  const b = hook.apply(row, ctx, back, turned(spot.delta), null, keyedRng(`${key}|b`));
  if (!b) return null;
  for (const t of sport.totals(row, ctx)) {
    if (t.kind !== "mean" || !back.played) continue;
    const step = t.perGame === "int" ? 1 : 0.1;
    const at = (v) => Math.round(v / step);
    const here = at(g.line[t.key] ?? 0);
    const there = at(back.line[t.key] ?? 0);
    const want = at(sport.meanBase(t.key, a)) - at(sport.meanBase(t.key, g));
    const up = Math.min(at(t.max) - here, there - at(t.min));
    const down = Math.min(here - at(t.min), at(t.max) - there);
    const n = clampN(want, -Math.max(0, down), Math.max(0, up));
    a.line = { ...a.line, [t.key]: Math.round((here + n) * step * 10) / 10 };
    b.line = { ...b.line, [t.key]: Math.round((there - n) * step * 10) / 10 };
  }
  const season = withGames(s, [a, b]);
  if (finalLine(season) !== finalLine(s)) return null;
  if (disagreements(sport, row, ctx, season).length > 0) return null;
  return { season, mirrorMd: back.md };
}
var CALL_BONUS = 1;
var MIX = ["call", "recreate", "call"];
function planMoments(sport, row, ctx, s) {
  const hook = sport.moments;
  if (!hook || hook.max <= 0) return [];
  const rng = keyedRng(`${s.key}|moment`);
  const cands = [];
  for (const g of s.games) {
    if (!g.played) continue;
    for (const spot of hook.spots(row, ctx, s, g, rng)) {
      const other = otherOutcome(sport, row, ctx, s, spot);
      if (other) cands.push({ ...spot, weight: spot.weight + CALL_BONUS, mode: "call", mirrorMd: other.mirrorMd });
      else if (spot.planSuccess && spot.onRecord) cands.push({ ...spot, mode: "recreate", mirrorMd: null });
    }
  }
  cands.sort((x, y) => y.weight - x.weight || x.md - y.md || x.minute - y.minute);
  const used = /* @__PURE__ */ new Set();
  const picked = [];
  const free = (c) => !used.has(c.md) && (c.mirrorMd === null || !used.has(c.mirrorMd));
  const take = (c) => {
    picked.push(c);
    used.add(c.md);
    if (c.mirrorMd !== null) used.add(c.mirrorMd);
  };
  for (const mode of MIX) {
    const best = cands.find((c) => c.mode === mode && free(c));
    if (best && picked.length < hook.max) take(best);
  }
  for (const c of cands) {
    if (picked.length >= hook.max) break;
    if (free(c)) take(c);
  }
  picked.sort((x, y) => x.md - y.md || x.minute - y.minute);
  return picked.map((c, id) => ({ ...c, id }));
}
function momentResult(m, entries) {
  const e = entries.find((x) => x[0] === m.md && x[1] === m.id);
  if (!e) return { taken: false, success: m.planSuccess, stars: 0, flipped: false };
  const made = e[2] >= 1;
  const success = m.mode === "call" ? made : m.planSuccess;
  return { taken: true, success, stars: Math.max(0, e[2]), flipped: m.mode === "call" && made !== m.planSuccess };
}
function applyDecisions(sport, row, ctx, plan, moments, entries) {
  let s = plan;
  let changed = false;
  for (const m of [...moments].sort((x, y) => x.md - y.md)) {
    if (!momentResult(m, entries).flipped) continue;
    const other = otherOutcome(sport, row, ctx, s, m);
    if (!other || other.mirrorMd !== m.mirrorMd) return plan;
    s = other.season;
    changed = true;
  }
  if (!changed) return plan;
  return finalLine(s) === finalLine(plan) && disagreements(sport, row, ctx, s).length === 0 ? s : plan;
}

// src/lib/season/law.ts
var LAW = {
  base: 1.25,
  perPoint: 0.055,
  min: 0.12,
  max: 4.2,
  cap: 7,
  home: 0.2,
  away: -0.08
};
function goalLambda(edge, venue) {
  const raw2 = LAW.base + edge * LAW.perPoint + venue;
  return raw2 < LAW.min ? LAW.min : raw2 > LAW.max ? LAW.max : raw2;
}
function poissonDraw(lambda, rng) {
  const L = Math.exp(-lambda);
  let k = 0;
  let p = 1;
  do {
    k += 1;
    p *= rng();
  } while (p > L);
  return Math.min(k - 1, LAW.cap);
}

// src/lib/season/soccer.ts
init_soccerCareerLeague();
init_soccerCareerDerby();
init_careerEras();
init_keyedRng();

// src/data/leagueFormat.ts
var LEAGUE_FORMAT = {
  "Premier League": [{ from: 1995 }],
  "La Liga": [{ from: 1995 }],
  "Serie A": [{ from: 1995 }],
  "Bundesliga": [{ from: 1995 }],
  "Ligue 1": [{ from: 1995, to: 2018 }, { from: 2020 }]
};
function leagueFormatFor(league, year) {
  const windows = LEAGUE_FORMAT[league];
  if (!windows) return null;
  for (const w of windows) {
    if (year >= w.from && (w.to === void 0 || year <= w.to)) return { win: 3, draw: 1, loss: 0 };
  }
  return null;
}

// src/lib/season/soccerEvents.ts
init_keyedRng();
var SOCCER_FULL_TIME = 90;
var RANK = { on: 0, goal: 1, assist: 2, yellow: 3, red: 4, injury: 4, off: 5 };
function soccerEvents(g, f, game, rng) {
  const mins = (n) => Array.from({ length: n }, () => 1 + Math.floor(rng() * SOCCER_FULL_TIME)).sort((x, y) => x - y);
  const ourMins = mins(g.us);
  const theirMins = mins(g.them);
  const his = g.line.goals ?? 0;
  const ast = g.line.assists ?? 0;
  let onAt = 1;
  if (g.played && rng() < game.subChance) onAt = 46 + Math.floor(rng() * 40);
  const order = Array.from({ length: g.us }, (_, i) => i);
  const must = f && f.decisive ? f.them : -1;
  const avoid = f && !f.decisive && f.us > f.them ? f.them : -1;
  const fits = (start) => order.filter((i) => ourMins[i] >= start && i !== avoid);
  const after = (start) => order.filter((i) => ourMins[i] >= start).length;
  if (fits(onAt).length < his || after(onAt) < his + ast || must >= 0 && ourMins[must] < onAt) onAt = 1;
  const pool = shuffled(fits(onAt).filter((i) => i !== must), rng);
  const mineIdx = new Set(must >= 0 && his > 0 ? [must, ...pool.slice(0, his - 1)] : pool.slice(0, his));
  const rest = shuffled(order.filter((i) => ourMins[i] >= onAt && !mineIdx.has(i)), rng);
  const astIdx = new Set(rest.slice(0, ast));
  const ev = [];
  ourMins.forEach((m, i) => {
    ev.push({ min: m, kind: "goal", side: "us", pts: 1, ...mineIdx.has(i) ? { mine: true } : {} });
    if (astIdx.has(i)) ev.push({ min: m, kind: "assist", side: "us", mine: true });
  });
  for (const m of theirMins) ev.push({ min: m, kind: "goal", side: "them", pts: 1 });
  if (g.played) {
    const lastMine = Math.max(onAt, ...ev.filter((e) => e.mine).map((e) => e.min));
    if (onAt > 1) {
      g.started = false;
      g.onAt = onAt;
      ev.push({ min: onAt, kind: "on", side: "us", mine: true });
    } else g.started = true;
    const red = (g.line.red ?? 0) > 0;
    let offAt = SOCCER_FULL_TIME + 1;
    if (red || game.injured) {
      offAt = Math.min(SOCCER_FULL_TIME, Math.max(lastMine + 1, 15 + Math.floor(rng() * 76)));
      g.offAt = offAt;
      ev.push({ min: offAt, kind: red ? "red" : "injury", side: "us", mine: true });
    }
    if ((g.line.yellow ?? 0) > 0) ev.push({ min: Math.min(SOCCER_FULL_TIME, lastMine + Math.floor(rng() * Math.max(1, offAt - lastMine))), kind: "yellow", side: "us", mine: true });
  }
  g.events = ev.sort((x, y) => x.min - y.min || (RANK[x.kind] ?? 5) - (RANK[y.kind] ?? 5));
}
function soccerOwnGoals(s, moments) {
  const minutes = new Set(moments.map((m) => `${m.md}|${m.minute}`));
  const mirrors = new Set(moments.flatMap((m) => m.mirrorMd === null ? [] : [m.mirrorMd]));
  return { ...s, games: s.games.map((g) => {
    const assists = new Set(g.events.filter((e) => e.kind === "assist" && e.mine).map((e) => e.min));
    const ordinals = /* @__PURE__ */ new Map();
    const win = pitchWindow(g);
    return { ...g, events: g.events.map((e) => {
      if (e.kind !== "goal") return e;
      const group = `${e.min}|${e.side}`;
      const ordinal2 = ordinals.get(group) ?? 0;
      ordinals.set(group, ordinal2 + 1);
      if (e.pts !== 1 || e.mine || mirrors.has(g.md) || minutes.has(`${g.md}|${e.min}`) || e.side === "us" && assists.has(e.min)) return e;
      const key = `${s.key}|og|${g.md}|${e.min}|${e.side}|${ordinal2}`;
      if (keyedRng(`${key}|tag`)() >= 1 / 64) return e;
      const role = Math.floor(keyedRng(`${key}|role`)() * 11);
      const ownGoalBy = e.side === "us" ? "opponent" : win && e.min >= win[0] && e.min <= win[1] && role === 0 ? "you" : "teammate";
      return { ...e, ownGoalBy };
    }) };
  }) };
}
function soccerEventDisagreements(s, fixed) {
  const out = [];
  for (const g of s.games) {
    const goals = g.events.filter((e) => e.kind === "goal");
    if (goals.filter((e) => e.side === "us").length !== g.us || goals.filter((e) => e.side === "them").length !== g.them) out.push(`md ${g.md}: events do not add up to the score`);
    if (!g.played) continue;
    if (goals.filter((e) => e.mine).length !== (g.line.goals ?? 0)) out.push(`md ${g.md}: his goal events`);
    if (g.events.filter((e) => e.kind === "assist").length !== (g.line.assists ?? 0)) out.push(`md ${g.md}: his assist events`);
    if (g.offAt && g.events.some((e) => e.mine && e.min > g.offAt)) out.push(`md ${g.md}: an event of his after he went off`);
  }
  const keys = [...new Set(fixed.map((f) => f.key))];
  for (const k of keys) {
    const want = fixed.filter((f) => f.key === k);
    const got = s.games.filter((g) => g.fixedKey === k);
    want.forEach((f, i) => {
      const g = got[i];
      if (!g || !f.played || f.us <= f.them) return;
      const ours = g.events.filter((e) => e.kind === "goal" && e.side === "us");
      if (!!ours[f.them]?.mine !== !!f.decisive) out.push(`fixed ${k} #${i + 1} decisive goal`);
    });
  }
  return out;
}
var SCORE_CAP = 7;
var HIS_GOALS_CAP = 4;
var HIS_ASSISTS_CAP = 3;
function pitchWindow(g) {
  if (!g.played) return null;
  const from = g.onAt ?? 1;
  const to = g.offAt ? g.offAt - 1 : SOCCER_FULL_TIME;
  return to >= from ? [from, to] : null;
}
function freeMinute(g, from, to, rng) {
  const taken = new Set(g.events.map((e) => e.min));
  for (let n = 0; n < 12; n += 1) {
    const m = from + Math.floor(rng() * (to - from + 1));
    if (!taken.has(m)) return m;
  }
  for (let m = to; m >= from; m -= 1) if (!taken.has(m)) return m;
  return null;
}
function soccerStakes(g, minute) {
  const close = Math.abs(g.us - g.them) <= 1 ? 0.4 : 0;
  const late = minute >= 75 ? 0.3 : minute >= 60 ? 0.15 : 0;
  return Math.min(1, close + late + (g.fixedKey ? 0.3 : 0));
}
function soccerMomentSpots(g, primary, keepsSheets, rng) {
  const win = pitchWindow(g);
  if (!win) return [];
  const [from, to] = win;
  const out = [];
  const add = (minute, kind, planSuccess, delta, onRecord = planSuccess) => {
    const noise = rng() * 0.5;
    if (out.some((s) => s.minute === minute && s.kind === kind && s.planSuccess === planSuccess)) return;
    const stakes = soccerStakes(g, minute);
    out.push({ md: g.md, minute, kind, planSuccess, onRecord, delta, stakes, weight: (planSuccess ? 2 : 1.2) + stakes * 3 + noise });
  };
  const keeper = primary === "save";
  if (!keeper) {
    for (const e of g.events) {
      if (e.kind === "goal" && e.mine) add(e.min, "finish", true, { us: -1, them: 0, line: { goals: -1 } });
      if (e.kind === "assist") add(e.min, "pass", true, { us: -1, them: 0, line: { assists: -1 } });
    }
  }
  if (primary === "finish" || primary === "pass") {
    const m = freeMinute(g, from, to, rng);
    const room = g.us < SCORE_CAP && (primary === "finish" ? (g.line.goals ?? 0) < HIS_GOALS_CAP : (g.line.assists ?? 0) < HIS_ASSISTS_CAP);
    if (m !== null && room) add(m, primary, false, { us: 1, them: 0, line: primary === "finish" ? { goals: 1 } : { assists: 1 } });
  } else {
    const m = freeMinute(g, from, to, rng);
    if (m !== null && g.them < SCORE_CAP) add(m, primary, true, { us: 0, them: 1, line: keepsSheets && g.them === 0 ? { cs: -1 } : {} }, g.them === 0);
    const against = g.events.filter((e) => e.kind === "goal" && e.side === "them" && e.min >= from && e.min <= to);
    if (against.length > 0) {
      const e = against[Math.floor(rng() * against.length)];
      add(e.min, primary, false, { us: 0, them: -1, line: keepsSheets && g.them === 1 ? { cs: 1 } : {} });
    }
  }
  return out;
}
var sortEvents = (ev) => ev.sort((x, y) => x.min - y.min || (RANK[x.kind] ?? 5) - (RANK[y.kind] ?? 5));
function soccerApplyDelta(g, delta, minute, keepsSheets, rng) {
  const us = g.us + delta.us;
  const them = g.them + delta.them;
  if (us < 0 || them < 0 || us > SCORE_CAP || them > SCORE_CAP) return null;
  const dGoals = delta.line.goals ?? 0;
  const dAst = delta.line.assists ?? 0;
  const dCs = delta.line.cs ?? 0;
  if (Object.entries(delta.line).some(([k, v]) => v !== 0 && k !== "goals" && k !== "assists" && k !== "cs")) return null;
  const win = pitchWindow(g);
  if ((dGoals !== 0 || dAst !== 0 || dCs !== 0) && !win) return null;
  const ev = g.events.slice();
  const line = { ...g.line };
  const pick = (xs) => xs.length ? xs[Math.floor(rng() * xs.length)] : null;
  const drop = (e) => {
    ev.splice(ev.indexOf(e), 1);
  };
  const fresh = () => {
    if (minute !== null) return minute;
    return win ? freeMinute(g, win[0], win[1], rng) : freeMinute(g, 1, SOCCER_FULL_TIME, rng);
  };
  const at = (e) => minute === null || e.min === minute;
  if (delta.them === 0 && delta.us === 1 && dGoals === 1 && dAst === 0) {
    if ((line.goals ?? 0) + 1 > HIS_GOALS_CAP) return null;
    const m = fresh();
    if (m === null) return null;
    ev.push({ min: m, kind: "goal", side: "us", pts: 1, mine: true });
    line.goals = (line.goals ?? 0) + 1;
  } else if (delta.them === 0 && delta.us === -1 && dGoals === -1 && dAst === 0) {
    const e = pick(ev.filter((x) => x.kind === "goal" && x.mine && at(x)));
    if (!e || (line.goals ?? 0) < 1) return null;
    drop(e);
    line.goals = (line.goals ?? 0) - 1;
  } else if (delta.them === 0 && delta.us === 1 && dAst === 1 && dGoals === 0) {
    if ((line.assists ?? 0) + 1 > HIS_ASSISTS_CAP) return null;
    const m = fresh();
    if (m === null) return null;
    ev.push({ min: m, kind: "goal", side: "us", pts: 1 }, { min: m, kind: "assist", side: "us", mine: true });
    line.assists = (line.assists ?? 0) + 1;
  } else if (delta.them === 0 && delta.us === -1 && dAst === -1 && dGoals === 0) {
    const a = pick(ev.filter((x) => x.kind === "assist" && at(x)));
    const goal = a ? ev.find((x) => x.kind === "goal" && x.side === "us" && !x.mine && x.min === a.min) : null;
    if (!a || !goal || (line.assists ?? 0) < 1) return null;
    drop(a);
    drop(goal);
    line.assists = (line.assists ?? 0) - 1;
  } else if (delta.us === 0 && delta.them === 1 && dGoals === 0 && dAst === 0) {
    const m = fresh();
    if (m === null) return null;
    ev.push({ min: m, kind: "goal", side: "them", pts: 1 });
  } else if (delta.us === 0 && delta.them === -1 && dGoals === 0 && dAst === 0) {
    const e = pick(ev.filter((x) => x.kind === "goal" && x.side === "them" && at(x) && (!win || x.min >= win[0] && x.min <= win[1])));
    if (!e) return null;
    drop(e);
  } else return null;
  if (keepsSheets && g.played) {
    const cs = them === 0 ? 1 : 0;
    if (cs - (g.line.cs ?? 0) !== dCs) return null;
    line.cs = cs;
  } else if (dCs !== 0) return null;
  if ((line.goals ?? 0) + (line.assists ?? 0) > us) return null;
  const out = { ...g, us, them, line, events: sortEvents(ev) };
  if (g.mark) out.mark = them === 0 ? "shutout" : "concede";
  return out;
}

// src/lib/season/soccer.ts
init_careerDrills();
var KEEPS_SHEETS = /* @__PURE__ */ new Set(["GK", "CB", "LB", "RB"]);
var CHAMPION_PPG = { min: 1.9, max: 2.65 };
var FINISH_PPG = [
  { min: 1.6, max: 2.5 },
  { min: 1.35, max: 2.1 },
  { min: 1.05, max: 1.85 },
  { min: 0.75, max: 1.55 },
  { min: 0.3, max: 1.2 }
];
function finishFifth(finish, size) {
  return Math.min(4, Math.floor((finish - 1) / Math.max(1, size - 1) * 5));
}
function worldFor(career, year) {
  const w = career.phone?.world;
  return w && w.year === year ? w : null;
}
function buildSoccerSeasonCtx(career, clubs, row) {
  const finish = readLeagueFinish(row);
  const today = clubs.find((c) => c.name === row.club)?.league ?? "";
  const league = finishLeague({ name: row.club, league: today }, row.year, finish?.size ?? null);
  const world = worldFor(career, row.year);
  const key = league?.key;
  const crowned = finish && finish.finish !== 1 && key && world ? world.leagues?.[key] && world.leagues[key] !== row.club ? world.leagues[key] : null : null;
  const champion = crowned && key && namedInLeague(crowned, key, row.year) ? crowned : null;
  const derbies = readSeasonDerbies(row);
  const rivals = derbies.map((d) => d.rival);
  let why = null;
  if (row.injurySevere) why = "severe";
  else if (!finish) why = "nofinish";
  else if (finish.size === null) why = "nosize";
  else if (!league) why = "league";
  else if (!leagueFormatFor(league.key, row.year)) why = "format";
  else if (derbyMeetings(league.key, row.year) !== 2) why = "cadence";
  else if (rivals.some((r2) => !namedInLeague(r2, league.key, row.year))) why = "rival";
  const mode = why === null ? "table" : "results";
  const sizeKey = league?.key ?? leagueKeyInYear({ name: row.club, league: today }, row.year);
  const size = mode === "table" ? finish.size : sizeKey ? leagueSizeFor(sizeKey, row.year) : null;
  const games = size ? 2 * (size - 1) : 38;
  let named = [];
  if (mode === "table" && league) {
    const field = managerLeagueField({ clubs, club: row.club, league: league.key, year: row.year }, keyedRng(`${row.club}|${row.year}|centre|field`));
    named = field.named.filter((n) => n !== row.club && !rivals.includes(n) && n !== champion);
  }
  const tiers = {};
  for (const c of adjustClubsForYear([...clubs], row.year)) if (tiers[c.name] === void 0) tiers[c.name] = c.tier;
  const at = career.seasons.indexOf(row);
  const earlier = at >= 0 ? career.seasons.slice(0, at) : career.seasons.filter((s) => s.year < row.year);
  const prev = [...earlier].reverse().find((s) => s.type === "playing");
  const prevFinish = prev ? readLeagueFinish(prev) : null;
  return {
    playerName: career.playerName,
    club: row.club,
    clubTier: row.clubTier,
    position: career.position,
    mode,
    why,
    league,
    finish,
    games,
    champion,
    rivals,
    named,
    tiers,
    goldenBoot: (career.awards ?? []).some((a) => a.year === row.year && a.name === "Golden Boot"),
    keepsSheets: KEEPS_SHEETS.has(career.position),
    derbyBefore: careerDerbyRecord(earlier),
    lastSeason: prev && prevFinish ? { finish: prevFinish.finish, club: prev.club } : null
  };
}
var RULE3 = { win: 3, draw: 1, loss: 0 };
function soccerSeasonKey(playerName, row) {
  return row.type === "playing" && row.apps > 0 ? `${playerName}|${row.club}|${row.year}|${row.apps}|${row.goals}|${row.assists}|${row.rating}|centre` : null;
}
var MOMENT_KIND = { wallshot: "finish", throughball: "pass", tackle: "tackle", gloves: "save" };
function momentKindFor(position) {
  return MOMENT_KIND[drillForPosition(position)];
}
var MOMENTS_PER_SEASON = 3;
var clamp4 = (v, lo, hi) => v < lo ? lo : v > hi ? hi : v;
function injuryBlock(row, games) {
  const w = row.injuryWeeks ?? 0;
  return w > 0 ? clamp4(Math.round(w * games / 46), 1, games) : 0;
}
function fixedOf(row, ctx) {
  const out = [];
  for (const d of readSeasonDerbies(row)) {
    for (const m of d.meetings) {
      const g = { key: d.rival, home: m.home, us: m.gf, them: m.ga, played: m.played, line: { goals: ctx.position === "GK" ? 0 : m.goals } };
      if (m.won) g.decisive = true;
      out.push(g);
    }
  }
  return out;
}
var SOCCER = {
  id: "soccer",
  seasonKey: (row, ctx) => soccerSeasonKey(ctx.playerName, row),
  frame: (_row, ctx) => ({
    mode: ctx.mode,
    teams: ctx.games / 2 + 1,
    games: ctx.games,
    rule: ctx.mode === "table" ? RULE3 : null
  }),
  fixtures: (f) => f.mode === "table" ? roundRobinRounds(f.teams) : ownRowRounds(f.teams),
  target: (row, ctx) => {
    if (ctx.mode === "table" && ctx.finish) {
      const title = ctx.finish.finish === 1;
      const champion = title ? "mine" : ctx.champion && ctx.rivals.includes(ctx.champion) ? { key: ctx.champion } : "other";
      return { kind: "finish", finish: ctx.finish.finish, title, champion };
    }
    if (row.leagueTitle && !row.injurySevere) return { kind: "band", ppgMin: CHAMPION_PPG.min, ppgMax: CHAMPION_PPG.max };
    if (ctx.finish && ctx.finish.size && !row.injurySevere) {
      const band = FINISH_PPG[finishFifth(ctx.finish.finish, ctx.finish.size)];
      return { kind: "band", ppgMin: band.min, ppgMax: band.max };
    }
    return { kind: "none" };
  },
  fixed: (row, ctx) => fixedOf(row, ctx),
  availability: (row, ctx) => {
    const M = ctx.games;
    const block = injuryBlock(row, M);
    const severe = !!row.injurySevere && block > 0;
    const fixedPlayed = fixedOf(row, ctx).filter((f) => f.played).length;
    const room = severe ? M : M - block;
    const want = Math.min(row.leagueApps ?? row.apps, room, row.apps);
    return { played: Math.min(Math.max(want, fixedPlayed), room, row.apps), block, severe };
  },
  totals: (row, ctx) => [
    { key: "goals", kind: "sum", total: row.goals, perGameCap: ctx.position === "GK" ? 0 : 4, teamFor: true, ...ctx.goldenBoot ? { noBucket: true } : {} },
    { key: "assists", kind: "sum", total: row.assists, perGameCap: 3, teamFor: true },
    { key: "rating", kind: "mean", mean: row.rating, dp: 1, perGame: 0.1, min: 3, max: 10 },
    ...ctx.keepsSheets ? [{ key: "cs", kind: "count-of", total: row.cleanSheets, when: "shutout" }] : [],
    { key: "yellow", kind: "sum", total: row.yellowCards, perGameCap: 1, distinct: "card" },
    { key: "red", kind: "sum", total: row.redCards, perGameCap: 1, distinct: "card", suspends: true }
  ],
  apps: (row) => row.apps,
  score: (edge, home, rng) => [
    poissonDraw(goalLambda(edge, home ? LAW.home : LAW.away), rng),
    poissonDraw(goalLambda(-edge, home ? LAW.away : LAW.home), rng)
  ],
  strengths: (frame, target, slotOf, ctx, rng) => {
    const n = frame.teams;
    const ladder = Array.from({ length: n }, (_, i) => 85 - 20 * i / Math.max(1, n - 1));
    const byTier = Math.ceil(n * (ctx.clubTier <= 1 ? 0.15 : ctx.clubTier === 2 ? 0.4 : ctx.clubTier === 3 ? 0.6 : 0.8));
    const f = ctx.finish;
    const fromFinish = f ? f.size ? 1 + Math.round((f.finish - 1) / Math.max(1, f.size - 1) * (n - 1)) : f.finish : null;
    const tier = fromFinish ?? (target.kind === "band" ? 1 : byTier);
    const mine = clamp4(target.kind === "finish" ? target.finish : tier, 1, n);
    const out = new Array(n).fill(0);
    out[0] = ladder[mine - 1];
    const rest = ladder.filter((_, i) => i !== mine - 1);
    const champ = target.kind === "finish" && typeof target.champion === "object" ? slotOf.get(target.champion.key) : void 0;
    if (champ !== void 0) out[champ] = rest.shift();
    const slots = Array.from({ length: n - 1 }, (_, i) => i + 1).filter((s) => s !== champ);
    for (let i = slots.length - 1; i > 0; i -= 1) {
      const j = Math.floor(rng() * (i + 1));
      [slots[i], slots[j]] = [slots[j], slots[i]];
    }
    slots.forEach((s, i) => {
      out[s] = rest[i] + (rng() - 0.5) * 2;
    });
    return out;
  },
  meanBase: (_key, g) => 6.55 + 0.8 * (g.line.goals ?? 0) + 0.4 * (g.line.assists ?? 0) + 0.35 * (g.line.cs ?? 0) + (g.us > g.them ? 0.25 : g.us < g.them ? -0.3 : 0) - (g.started ? 0 : 0.3),
  subChance: (played, games) => clamp4(1.15 - 1.3 * played / Math.max(1, games), 0.04, 0.55),
  labels: (slots, ctx, rng) => soccerLabels(slots, ctx, rng),
  events: soccerEvents,
  moments: {
    max: MOMENTS_PER_SEASON,
    spots: (_row, ctx, _s, g, rng) => soccerMomentSpots(g, momentKindFor(ctx.position), ctx.keepsSheets, rng),
    apply: (_row, ctx, g, delta, minute, rng) => soccerApplyDelta(g, delta, minute, ctx.keepsSheets, rng)
  },
  check: (row, ctx, s) => {
    const out = soccerEventDisagreements(s, fixedOf(row, ctx));
    const names = s.labels.filter((l) => l.named).map((l) => l.name);
    if (new Set(names).size !== names.length) out.push("a club named twice");
    if (s.labels[0]?.name !== row.club) out.push("his club is not slot 0");
    return out;
  },
  words: { round: "Matchday", title: "Season Centre", unnamed: "another club" }
};
function soccerLabels(slots, ctx, rng) {
  const unnamed = (slot) => ({ name: "another club", named: false, key: `u${slot}` });
  const out = slots.map((s) => unnamed(s.slot));
  out[0] = { name: ctx.club, named: true, key: ctx.club };
  const open = [];
  for (const s of slots) {
    if (s.slot === 0) continue;
    if (s.fixedKey) out[s.slot] = { name: s.fixedKey, named: true, key: s.fixedKey };
    else if (s.champion) out[s.slot] = ctx.champion ? { name: ctx.champion, named: true, key: ctx.champion } : unnamed(s.slot);
    else open.push(s);
  }
  if (ctx.mode !== "table") return out;
  open.sort((a, b) => a.pos - b.pos);
  const entries = ctx.named.map((name) => ({ name, at: (ctx.tiers[name] ?? 3) + rng() * 1.5 }));
  for (let i = entries.length; i < open.length; i += 1) entries.push({ name: null, at: 1 + rng() * 3.5 });
  entries.sort((a, b) => a.at - b.at);
  open.forEach((s, i) => {
    const e = entries[i];
    if (e && e.name) out[s.slot] = { name: e.name, named: true, key: e.name };
  });
  return out;
}

// src/components/soccer-career/SoccerSeasonCentre.tsx
init_momentsSave();

// src/components/soccer-career/useSoccerMoments.tsx
var import_react9 = __toESM(require_react(), 1);
init_momentsSave();

// src/lib/season/soccerMoments.ts
init_keyedRng();
init_careerDrills();
init_throughBallDrill();
init_momentsSave();
var MOMENT_BOARD = { finish: "wallshot", tackle: "tackle", save: "gloves", pass: "throughball" };
var MOMENT_STARS_MAX = 3;
var momentTag = (key, md, id) => `${key}|moment|${md}|${id}`;
function momentSeed(key, md, id) {
  return 1 + Math.floor(keyedRng(momentTag(key, md, id))() * 2147483645);
}
function momentRound(stakes) {
  const s = Number.isFinite(stakes) ? Math.min(1, Math.max(0, stakes)) : 0;
  return Math.min(ROUNDS_PER_RUN - 1, 2 + Math.round(s * 5));
}
function textbookStrike(setup) {
  const power = 0.6;
  let peak = wallNextPeak(setup, 0);
  if (peak - wallTravel(power) < 0) peak += setup.period;
  return packMomentInput([setup.gapCentre, 0.85, power, peak - wallTravel(power)]);
}
var SHOT_STREAMS = 8;
function momentShotRng(key, md, id, setup) {
  const tag = `${momentTag(key, md, id)}|shot`;
  if (setup) {
    const [x, y, power, press] = textbookStrike(setup);
    for (let n = 0; n < SHOT_STREAMS; n += 1) {
      if (takeWallShot({ x, y, power, press }, setup, keyedRng(`${tag}|${n}`)).won) return keyedRng(`${tag}|${n}`);
    }
  }
  return keyedRng(`${tag}|0`);
}
function momentSetup(board, seed, round) {
  if (board === "wallshot") return buildWallShotRun(seed)[round];
  if (board === "tackle") return buildTackleRun(seed)[round];
  if (board === "gloves") return buildGloveRun(seed)[round];
  return buildThroughBallRun(seed)[round];
}
function packMomentInput(input) {
  return input.map((v) => Number.isFinite(v) ? Math.round(v * 1e4) / 1e4 : 0);
}
var starsFor = (quality) => quality >= 2 / 3 ? 3 : quality >= 1 / 3 ? 2 : 1;
function settleMoment(board, setup, input, rng) {
  const i = packMomentInput(input);
  if (board === "wallshot") {
    const r3 = takeWallShot({ x: i[0] ?? 0, y: i[1] ?? 0, power: i[2] ?? 0, press: i[3] ?? 0 }, setup, rng);
    const quality2 = Math.min(1, Math.max(Math.abs(r3.x), r3.y > 0.5 ? r3.y : 0));
    return { won: r3.won, stars: r3.won ? starsFor(quality2) : 0, verdict: r3.verdict, quality: r3.won ? quality2 : 0 };
  }
  if (board === "tackle") {
    const s2 = setup;
    const r3 = makeTackle({ x: i[0] ?? -1, y: i[1] ?? -1, press: i[2] ?? 0 }, s2);
    const base = Math.round(80 + s2.speed * 100 + (0.22 - s2.touchLen) * 300);
    const quality2 = Math.min(1, Math.max(0, (r3.points - base) / 80));
    return { won: r3.won, stars: r3.won ? starsFor(quality2) : 0, verdict: r3.verdict, quality: r3.won ? quality2 : 0 };
  }
  if (board === "gloves") {
    const s2 = setup;
    const r3 = makeSave({ dx: i[0] ?? 0, dy: i[1] ?? 0, release: i[2] ?? 0 }, s2);
    const d = Math.hypot(r3.gloveX - s2.target.x, r3.gloveY - s2.target.y);
    const quality2 = r3.radius > 0 ? Math.min(1, Math.max(0, 1 - d / r3.radius)) : 0;
    return { won: r3.saved, stars: r3.saved ? starsFor(quality2) : 0, verdict: r3.verdict, quality: r3.saved ? quality2 : 0 };
  }
  const s = setup;
  const r2 = takeThroughBall({ angle: i[0] ?? 0, weight: i[1] ?? 0, press: i[2] ?? 0 }, s);
  const w = r2.won ? collectWindow(s, r2.target, r2.press) : null;
  const quality = w ? Math.min(1, Math.max(0, 1 - Math.abs(w[0] - r2.arrival - LEAD_IDEAL) / Math.max(0.25, s.wait))) : 0;
  return { won: r2.won, stars: r2.won ? starsFor(quality) : 0, verdict: r2.verdict, quality };
}
function momentsRoom(s) {
  let pending = 0;
  for (const v of Object.values(s.statBoostNextSeason ?? {})) if (typeof v === "number" && v > 0) pending += v;
  return Math.max(0, Math.floor(drillHeadroom(s)) - pending);
}
function momentsBoost(stars, offered, room) {
  const max = Math.max(0, offered) * MOMENT_STARS_MAX;
  const share = max > 0 ? stars / max : 0;
  const raw2 = share >= 0.85 ? 2 : share >= 0.6 ? 1 : 0;
  return Math.max(0, Math.min(raw2, Math.floor(room)));
}
function applySeasonMomentsBank(prev, offered) {
  const save = readSeasonMoments(prev.seasonMoments);
  if (!save || save.banked || save.m.length === 0) return prev;
  const row = prev.seasons[prev.seasons.length - 1];
  if (!row || save.key !== soccerSeasonKey(prev.playerName, row)) return prev;
  const n = Math.max(save.m.length, Math.min(12, Math.floor(offered) || 0));
  const stars = save.m.reduce((x, e) => x + (e[2] > 0 ? e[2] : 0), 0);
  const made = save.m.some((e) => e[2] >= 1);
  const s = { ...prev };
  const { stat, label } = drillStatFor(drillForPosition(s.position), s.position);
  const boost = momentsBoost(stars, n, momentsRoom(s));
  s.seasonMoments = ledgerBanked(save, row.year, boost);
  const head = `\u{1F3AF} Season Centre moments: ${stars} of ${n * MOMENT_STARS_MAX} stars.`;
  if (boost > 0) {
    s.statBoostNextSeason = { ...s.statBoostNextSeason, [stat]: (s.statBoostNextSeason[stat] || 0) + boost };
    s.events = [...s.events, `${head} +${boost} ${label} coming with next season's growth`];
  } else if (momentsBoost(stars, n, 2) > 0) {
    s.events = [...s.events, `${head} Good hands, but you are at your ceiling and there is nothing left to add`];
  } else {
    s.events = [...s.events, `${head} No gains this time`];
  }
  if (made) s.morale = Math.min(100, Math.max(0, s.morale + 2));
  return s;
}
var MOMENT_LINE = {
  finish: "The ball breaks to you on the edge of the box",
  /* a striker and a winger replay their own assists here too, so it names no position */
  pass: "You have the ball and a teammate is making the run",
  save: "Their striker is through and it is you or the net",
  tackle: "Their winger is running at your back line"
};
var MOMENT_HOW = {
  wallshot: "Wall Shot, one shot. A wall with a gap that opens and closes: drag the goal to aim across and up, set your power, and let go as the gap opens. Pace gets there sooner and sprays wider. Keys: arrows aim, W and S set power, space shoots.",
  tackle: "Tackle, one run. He runs across you and every touch pushes the ball off his feet for a moment: tap the ball, not the man, while it is loose. Tap him, or go in while it sits at his feet, and it is a foul. Keys: arrows move the marker, space goes in.",
  gloves: "Glove Save, one shot. Hold and drag to set your dive (where you drag is the direction, how far is the reach), then let go to dive. A full stretch takes longer to get there, so go early for the corner. Keys: arrows set it, space dives.",
  throughball: "Through Ball, one ball. Your runner waits a moment, then cuts across the back line: drag on the pitch to where the ball should stop and let go to play it, through a gap and onto his run before he is offside. The ? on the board has the full rules."
};
var RECREATE_LINE = {
  finish: "On the record you scored here. Do it again.",
  pass: "On the record you set this one up. Do it again.",
  save: "On the record you kept a clean sheet here. Keep this one out again.",
  tackle: "They never scored in this one. Win this ball again."
};
var CALL_LINE = "What you do here is what happened in this match.";
function momentAfter(mode, made, flipped, mirrorMd, round = "matchday") {
  if (mode === "recreate") return made ? "The record stands, and the stars are yours." : "The record stands: on the day you got this one right. No stars this time.";
  if (!flipped) return made ? "That is how the match went. The stars are yours." : "That is how the match went.";
  const back = mirrorMd === null ? "A later game" : `The return game on ${round} ${mirrorMd}`;
  return made ? `It counts, and the match changes from here. ${back} takes the other side of it, so your season totals stay as they are.` : `It did not go your way, so the match changes from here. ${back} takes the other side of it, so your season totals stay as they are.`;
}
function momentsKickoffLine(mds, round = "matchday") {
  if (mds.length === 0) return null;
  const list = mds.length === 1 ? `${mds[0]}` : `${mds.slice(0, -1).join(", ")} and ${mds[mds.length - 1]}`;
  return mds.length === 1 ? `1 moment is yours to play this season: ${round} ${list}.` : `${mds.length} moments are yours to play this season: ${round}s ${list}.`;
}

// src/components/soccer-career/SoccerMomentBoard.tsx
var import_react8 = __toESM(require_react(), 1);
var import_jsx_runtime13 = __toESM(require_jsx_runtime(), 1);
var DrillBoard2 = (0, import_react8.lazy)(() => Promise.resolve().then(() => (init_DrillBoard(), DrillBoard_exports)));
var ThroughBallBoard2 = (0, import_react8.lazy)(() => Promise.resolve().then(() => (init_ThroughBallBoard2(), ThroughBallBoard_exports)));
function preloadMomentBoard(board) {
  return board === "throughball" ? Promise.resolve().then(() => (init_ThroughBallBoard2(), ThroughBallBoard_exports)) : Promise.resolve().then(() => (init_DrillBoard(), DrillBoard_exports));
}
var nothing2 = () => {
};
function SoccerMomentBoard({ career, board, seed, round, rng, onInput }) {
  const drill = (0, import_react8.useMemo)(() => board === "throughball" ? null : { kind: board, seed, round, rng, onResult: (r2) => onInput(r2.input) }, []);
  const through = (0, import_react8.useMemo)(() => board === "throughball" ? { seed, round, onResult: (r2) => onInput(r2.input) } : null, []);
  return /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(import_react8.Suspense, { fallback: /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("div", { className: "p-6 text-center text-sm text-muted-foreground", "data-moment-loading": true, children: "Getting the pitch ready..." }), children: /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)("div", { className: "mx-auto w-full max-w-md", "data-soccer-moment-board": board, children: [
    through && /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(ThroughBallBoard2, { career, canBank: false, onBank: nothing2, onBack: nothing2, match: through }),
    drill && /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(DrillBoard2, { career, canBank: false, onBank: nothing2, onBack: nothing2, match: drill })
  ] }) });
}

// src/components/soccer-career/useSoccerMoments.tsx
var import_jsx_runtime14 = __toESM(require_jsx_runtime(), 1);
function roundOf(key, m) {
  const board = MOMENT_BOARD[m.kind];
  const seed = momentSeed(key, m.md, m.id);
  const round = momentRound(m.stakes);
  const setup = momentSetup(board, seed, round);
  const rng = () => momentShotRng(key, m.md, m.id, board === "wallshot" ? setup : void 0);
  return { board, seed, round, setup, rng };
}
function useSoccerMoments({ career, row, ctx, plan, key, offered, entriesKey, banked, onCareer }) {
  return (0, import_react9.useMemo)(() => {
    if (!onCareer || !plan || !key || offered.length === 0) return null;
    const entries = JSON.parse(entriesKey);
    const word = plan.mode === "table" ? "matchday" : "league game";
    const find = (m) => offered.find((x) => x.md === m.md && x.id === m.id) ?? null;
    const all = offered.map((m) => {
      const r2 = momentResult(m, entries);
      const kind = m.kind;
      return {
        md: m.md,
        id: m.id,
        minute: m.minute,
        mode: m.mode,
        line: MOMENT_LINE[kind],
        objective: m.mode === "recreate" ? RECREATE_LINE[kind] : CALL_LINE,
        how: MOMENT_HOW[MOMENT_BOARD[kind]],
        taken: r2.taken ? { stars: r2.stars, made: r2.stars >= 1 } : null
      };
    });
    const list = banked ? all.filter((m) => m.taken) : all;
    const taken = list.filter((m) => m.taken);
    const stars = taken.reduce((n, m) => n + (m.taken?.stars ?? 0), 0);
    const review = [];
    if (taken.length > 0) {
      review.push(`Your moments: ${stars} of ${offered.length * MOMENT_STARS_MAX} stars from ${taken.length} of ${offered.length} played.`);
      const paid = banked ? [...career.events].reverse().find((e) => e.startsWith("\u{1F3AF} Season Centre moments:")) : null;
      if (paid) review.push(paid.replace(/^🎯 Season Centre moments: \d+ of \d+ stars\.\s*/, ""));
    }
    return {
      list,
      feedback: "goal",
      kickoff: momentsKickoffLine(list.filter((m) => !m.taken).map((m) => m.md), word),
      review,
      preload: (m) => {
        const mm = find(m);
        return mm ? preloadMomentBoard(MOMENT_BOARD[mm.kind]) : Promise.reject(new Error("no such moment"));
      },
      use: (m) => onCareer((prev) => ({ ...prev, seasonMoments: ledgerPut(prev.seasonMoments, key, m.md, m.id, -1, []) })),
      board: (m, done) => {
        const mm = find(m);
        if (!mm) return null;
        const r2 = roundOf(key, mm);
        return /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(SoccerMomentBoard, { career, board: r2.board, seed: r2.seed, round: r2.round, rng: r2.rng, onInput: done }, `${m.md}|${m.id}`);
      },
      settle: (m, input) => {
        const mm = find(m);
        if (!mm) return { made: false, stars: 0, verdict: "", after: "", wonMatch: false };
        const r2 = roundOf(key, mm);
        const packed2 = packMomentInput(input);
        const play = settleMoment(r2.board, r2.setup, packed2, r2.rng());
        onCareer((prev) => ({ ...prev, seasonMoments: ledgerPut(prev.seasonMoments, key, mm.md, mm.id, play.stars, packed2) }));
        const flipped = mm.mode === "call" && play.won !== mm.planSuccess;
        let wonMatch = false;
        if (mm.mode === "call" && play.won) {
          const other = otherOutcome(SOCCER, row, ctx, plan, mm)?.season.games[mm.md - 1];
          const here = plan.games[mm.md - 1];
          const made = mm.planSuccess ? here : other;
          const missed = mm.planSuccess ? other : here;
          wonMatch = !!made && !!missed && made.us > made.them && !(missed.us > missed.them);
        }
        return { made: play.won, stars: play.stars, verdict: play.verdict, after: momentAfter(mm.mode, play.won, flipped, mm.mirrorMd, word), wonMatch };
      },
      bank: (final) => {
        if (final || all.every((m) => m.taken)) onCareer((prev) => applySeasonMomentsBank(prev, offered.length));
      }
    };
  }, [onCareer, plan, key, offered, entriesKey, banked, row, ctx, career.events, career.position]);
}

// src/components/soccer-career/SoccerSeasonCentre.tsx
init_soccerCareerDerby();
init_soccerCareerLeague();

// src/lib/dialogA11y.ts
function focusDialogOnMount(el) {
  if (el && !el.dataset.dukbFocused) {
    el.dataset.dukbFocused = "1";
    el.focus();
  }
}
function escapeCloses(onClose) {
  return (e) => {
    if (e.key === "Escape") onClose();
  };
}

// src/components/season-centre/SeasonCentre.tsx
var import_react16 = __toESM(require_react(), 1);

// src/components/club-manager/LeagueTableCard.tsx
init_utils();
var import_jsx_runtime15 = __toESM(require_jsx_runtime(), 1);
function LeagueTableCard({ rows, myClub, compact = false, title, preseason = false, onClubClick, footnote, zoneTop = 4, isUnnamed }) {
  const myIdx = rows.findIndex((r2) => r2.club === myClub);
  let visible = rows.map((r2, i) => ({ r: r2, pos: i + 1 }));
  if (compact) {
    const lo = Math.max(0, Math.min(myIdx - 2, rows.length - 5));
    visible = visible.slice(lo, lo + 5);
  }
  return /* @__PURE__ */ (0, import_jsx_runtime15.jsxs)("div", { className: "bg-card border border-border rounded-2xl p-3 md:p-4", children: [
    title && /* @__PURE__ */ (0, import_jsx_runtime15.jsx)("div", { className: "text-xs text-muted-foreground uppercase tracking-wider mb-2", children: title }),
    /* @__PURE__ */ (0, import_jsx_runtime15.jsxs)("div", { className: "grid grid-cols-[1rem_1fr_1rem_1rem_1rem_2.6rem_1.9rem_1.5rem] min-[375px]:grid-cols-[1.3rem_1fr_1.3rem_1.3rem_1.3rem_2.6rem_1.9rem_2rem] gap-x-0.5 min-[375px]:gap-x-1 text-[10px] text-muted-foreground uppercase tracking-wide pb-1 border-b border-border/60", children: [
      /* @__PURE__ */ (0, import_jsx_runtime15.jsx)("span", { children: "#" }),
      /* @__PURE__ */ (0, import_jsx_runtime15.jsx)("span", { children: "Club" }),
      /* @__PURE__ */ (0, import_jsx_runtime15.jsx)("span", { className: "text-center", children: "W" }),
      /* @__PURE__ */ (0, import_jsx_runtime15.jsx)("span", { className: "text-center", children: "D" }),
      /* @__PURE__ */ (0, import_jsx_runtime15.jsx)("span", { className: "text-center", children: "L" }),
      /* @__PURE__ */ (0, import_jsx_runtime15.jsx)("span", { className: "text-center", children: "GF-GA" }),
      /* @__PURE__ */ (0, import_jsx_runtime15.jsx)("span", { className: "text-center", children: "GD" }),
      /* @__PURE__ */ (0, import_jsx_runtime15.jsx)("span", { className: "text-right", children: "Pts" })
    ] }),
    onClubClick && /* @__PURE__ */ (0, import_jsx_runtime15.jsx)("p", { className: "text-[9px] text-muted-foreground pt-1", children: "Tap any club to scout their full squad." }),
    visible.map(({ r: r2, pos }) => {
      const mine = r2.club === myClub;
      const gd = r2.gf - r2.ga;
      return /* @__PURE__ */ (0, import_jsx_runtime15.jsxs)(
        "div",
        {
          onClick: onClubClick ? () => onClubClick(r2.club) : void 0,
          className: cn(
            "grid grid-cols-[1rem_1fr_1rem_1rem_1rem_2.6rem_1.9rem_1.5rem] min-[375px]:grid-cols-[1.3rem_1fr_1.3rem_1.3rem_1.3rem_2.6rem_1.9rem_2rem] gap-x-0.5 min-[375px]:gap-x-1 items-center text-xs py-1.5 border-b border-border/30 last:border-0",
            mine && "bg-primary/10 rounded-md -mx-1 px-1",
            onClubClick && "cursor-pointer hover:bg-secondary/40 rounded-md -mx-1 px-1 transition-colors"
          ),
          "data-club": r2.club,
          children: [
            /* @__PURE__ */ (0, import_jsx_runtime15.jsx)("span", { className: cn(
              "font-bold",
              preseason ? "text-muted-foreground" : pos === 1 ? "text-gold" : pos <= zoneTop ? "text-emerald-400" : "text-muted-foreground"
            ), children: preseason ? mine ? "\u2B50" : "\xB7" : pos }),
            /* @__PURE__ */ (0, import_jsx_runtime15.jsx)("span", { className: cn("min-w-0 break-words leading-tight", mine ? "text-primary font-bold" : "text-foreground"), children: isUnnamed?.(r2.club) ? /* @__PURE__ */ (0, import_jsx_runtime15.jsx)("i", { className: "text-muted-foreground", children: "another club" }) : r2.club }),
            /* @__PURE__ */ (0, import_jsx_runtime15.jsx)("span", { className: "text-center text-muted-foreground", children: r2.w }),
            /* @__PURE__ */ (0, import_jsx_runtime15.jsx)("span", { className: "text-center text-muted-foreground", children: r2.d }),
            /* @__PURE__ */ (0, import_jsx_runtime15.jsx)("span", { className: "text-center text-muted-foreground", children: r2.l }),
            /* @__PURE__ */ (0, import_jsx_runtime15.jsxs)("span", { className: "text-center text-muted-foreground text-[11px] tabular-nums", "data-goals": `${r2.gf}-${r2.ga}`, children: [
              r2.gf,
              "-",
              r2.ga
            ] }),
            /* @__PURE__ */ (0, import_jsx_runtime15.jsx)("span", { className: cn("text-center", gd > 0 ? "text-emerald-400" : gd < 0 ? "text-red-400" : "text-muted-foreground"), children: gd > 0 ? `+${gd}` : gd }),
            /* @__PURE__ */ (0, import_jsx_runtime15.jsx)("span", { className: "text-right font-bold text-foreground", children: r2.pts })
          ]
        },
        r2.club
      );
    }),
    footnote && /* @__PURE__ */ (0, import_jsx_runtime15.jsx)("p", { className: "text-[9px] text-muted-foreground pt-1.5", children: footnote })
  ] });
}

// src/components/club-manager/CelebrationStyles.tsx
var import_jsx_runtime16 = __toESM(require_jsx_runtime(), 1);
function CelebrationStyles() {
  return /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("style", { children: `
      @keyframes cmRise { 0% { opacity: 0; transform: translateY(7px); } 100% { opacity: 1; transform: translateY(0); } }
      .cm-rise { opacity: 0; animation: cmRise 0.45s ease-out forwards; }
      @keyframes cmSlam { 0% { opacity: 0; transform: scale(1.6); } 60% { opacity: 1; transform: scale(0.94); } 100% { opacity: 1; transform: scale(1); } }
      .cm-slam { opacity: 0; animation: cmSlam 0.4s cubic-bezier(0.2, 0.8, 0.3, 1.2) forwards; }
      @keyframes cmWinPulse { 0% { box-shadow: 0 0 0 0 rgba(34,197,94,0.45); } 100% { box-shadow: 0 0 0 26px rgba(34,197,94,0); } }
      .cm-win-pulse { animation: cmWinPulse 0.9s ease-out 1; }
      @keyframes cmLossShake { 0%, 100% { transform: translateX(0); } 25% { transform: translateX(-4px); } 55% { transform: translateX(3px); } 80% { transform: translateX(-2px); } }
      .cm-loss-shake { animation: cmLossShake 0.4s ease-in-out 1; }
      @keyframes cmGoldGlow { 0%, 100% { box-shadow: 0 0 8px rgba(234,179,8,0.35); } 50% { box-shadow: 0 0 22px rgba(234,179,8,0.75); } }
      .cm-gold-glow { animation: cmGoldGlow 1.5s ease-in-out infinite; }
      @keyframes cmTickIn { 0% { opacity: 0; transform: translateX(-6px); } 100% { opacity: 1; transform: translateX(0); } }
      .cm-tick-in { opacity: 0; animation: cmTickIn 0.35s ease-out forwards; }
      /* cm-rise for a control that must not be pressed before it shows: hidden
         (so unclickable) through its delay, visible from its first frame. */
      @keyframes cmRiseGated { 0% { opacity: 0; visibility: visible; transform: translateY(7px); } 100% { opacity: 1; visibility: visible; transform: translateY(0); } }
      .cm-rise-gated { opacity: 0; visibility: hidden; animation: cmRiseGated 0.45s ease-out forwards; }


      @media (prefers-reduced-motion: reduce) {
        .cm-rise, .cm-slam, .cm-tick-in, .cm-rise-gated { animation: none; opacity: 1; transform: none; visibility: visible; }
        .cm-win-pulse, .cm-loss-shake, .cm-gold-glow { animation: none; }
      }
    ` });
}

// src/components/club-manager/Celebration.tsx
var import_jsx_runtime17 = __toESM(require_jsx_runtime(), 1);
function det(i) {
  const x = Math.sin(i * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
}
var PIECE_COLORS = ["#22c55e", "#eab308", "#3b82f6", "#ef4444", "#a855f7", "#f97316", "#facc15"];
function revealDelay(i, start = 0.6, step = 0.22) {
  return `${Math.round((start + i * step) * 1e3) / 1e3}s`;
}
function confettiSeedOf(text) {
  let seed = 1;
  for (let i = 0; i < text.length; i++) seed = seed * 31 + text.charCodeAt(i) >>> 0;
  return seed % 997;
}
function ConfettiBurst({ seed = 1, count: count3 = 30 }) {
  return /* @__PURE__ */ (0, import_jsx_runtime17.jsxs)("div", { className: "absolute inset-0 overflow-hidden pointer-events-none", "aria-hidden": true, children: [
    Array.from({ length: count3 }, (_, i) => {
      const k = i + seed * 97;
      return /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(
        "span",
        {
          className: "absolute -top-2 w-1.5 h-2.5 cm-confetti",
          style: {
            left: `${4 + det(k) * 92}%`,
            backgroundColor: PIECE_COLORS[i % PIECE_COLORS.length],
            animationDuration: `${1.1 + det(k * 3) * 1.2}s`,
            animationDelay: `${det(k * 7) * 0.35}s`,
            transform: `rotate(${Math.floor(det(k * 13) * 360)}deg)`
          }
        },
        i
      );
    }),
    /* @__PURE__ */ (0, import_jsx_runtime17.jsx)("style", { children: `
        @keyframes cmConfettiFall {
          0% { opacity: 0; transform: translateY(-10px) rotate(0deg); }
          8% { opacity: 1; }
          100% { opacity: 0; transform: translateY(240px) rotate(560deg); }
        }
        .cm-confetti { animation-name: cmConfettiFall; animation-timing-function: ease-in; animation-fill-mode: forwards; }

        @media (prefers-reduced-motion: reduce) {
          .cm-confetti { display: none; }
        }
      ` })
  ] });
}

// src/components/soccer-career/CareerFx.tsx
var import_react10 = __toESM(require_react(), 1);
var import_jsx_runtime18 = __toESM(require_jsx_runtime(), 1);
var prefersReducedMotion4 = () => typeof window !== "undefined" && typeof window.matchMedia === "function" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
var CONFETTI_COLORS = ["#FBBF24", "#F59E0B", "#10B981", "#3B82F6", "#EC4899", "#A855F7", "#FFFFFF"];
var Confetti = ({ pieces = 40, gold = false }) => {
  const [on, setOn] = (0, import_react10.useState)(false);
  (0, import_react10.useEffect)(() => {
    if (prefersReducedMotion4()) return;
    setOn(true);
  }, []);
  if (!on) return null;
  const palette = gold ? ["#FBBF24", "#F59E0B", "#FDE68A", "#FFFFFF"] : CONFETTI_COLORS;
  return /* @__PURE__ */ (0, import_jsx_runtime18.jsx)("div", { className: "pointer-events-none absolute inset-0 overflow-hidden rounded-xl", "aria-hidden": "true", children: Array.from({ length: pieces }).map((_, i) => {
    const left = i * 37 % 100;
    const delay = i * 13 % 22 / 10;
    const duration = 2.4 + i * 7 % 14 / 10;
    const size = 5 + i * 5 % 6;
    const color = palette[i % palette.length];
    return /* @__PURE__ */ (0, import_jsx_runtime18.jsx)(
      "span",
      {
        className: "absolute top-0 animate-confetti-fall",
        style: {
          left: `${left}%`,
          width: `${size}px`,
          height: `${size * 1.6}px`,
          backgroundColor: color,
          borderRadius: i % 3 === 0 ? "50%" : "2px",
          animationDelay: `${delay}s`,
          animationDuration: `${duration}s`
        }
      },
      i
    );
  }) });
};

// src/components/game/VictoryMoment.tsx
var import_jsx_runtime19 = __toESM(require_jsx_runtime(), 1);
function VictoryMoment({ children, compact = false }) {
  return /* @__PURE__ */ (0, import_jsx_runtime19.jsxs)("div", { className: `victory-moment${compact ? " victory-compact" : ""}`, "data-victory-moment": true, children: [
    /* @__PURE__ */ (0, import_jsx_runtime19.jsxs)("svg", { className: "victory-art", viewBox: "0 0 72 72", "aria-hidden": "true", focusable: "false", children: [
      /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("g", { className: "victory-rays", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", children: /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("path", { d: "M36 7v5M12 17l4 4M60 17l-4 4M7 37h6M65 37h-6" }) }),
      /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("ellipse", { className: "victory-shadow", cx: "36", cy: "65", rx: "19", ry: "3", fill: "currentColor", opacity: ".15" }),
      /* @__PURE__ */ (0, import_jsx_runtime19.jsxs)("g", { className: "victory-cup", children: [
        /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("path", { d: "M24 25H14v6c0 9 5 13 13 13M48 25h10v6c0 9-5 13-13 13", fill: "none", stroke: "currentColor", strokeWidth: "4" }),
        /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("g", { className: "victory-ribbons", fill: "currentColor", opacity: ".55", children: /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("path", { d: "M16 29h5l-1 24-4-4-4 3zM51 29h5l4 23-4-3-4 4z" }) }),
        /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("path", { d: "M23 19h26v17c0 9-5 15-13 15s-13-6-13-15z", fill: "currentColor" }),
        /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("path", { d: "M28 24v11c0 5 2 8 5 10", fill: "none", stroke: "white", strokeOpacity: ".55", strokeWidth: "2", strokeLinecap: "round" }),
        /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("path", { d: "M33 49h6v9h7v5H26v-5h7z", fill: "currentColor" }),
        /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("path", { d: "m36 27 2 4 5 .6-3.5 3.3.9 4.7-4.4-2.3-4.4 2.3.9-4.7-3.5-3.3 5-.6z", fill: "black", fillOpacity: ".2" })
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("div", { className: "victory-copy", children }),
    /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("style", { children: `
        .victory-moment { position: relative; display: flex; align-items: center; justify-content: center; gap: 8px; isolation: isolate; overflow: hidden; border-radius: inherit; }
        .victory-moment::before { content: ''; position: absolute; inset: 0; z-index: -1; pointer-events: none; background: linear-gradient(110deg, transparent 25%, currentColor 50%, transparent 75%); opacity: 0; transform: translateX(-110%); animation: victory-light 1050ms ease-out 1 both; }
        .victory-art { flex: 0 0 64px; width: 64px; height: 64px; overflow: hidden; pointer-events: none; }
        .victory-compact .victory-art { flex-basis: 40px; width: 40px; height: 40px; }
        .victory-copy { min-width: 0; overflow-wrap: anywhere; }
        .victory-cup { transform-origin: 36px 56px; animation: victory-lift 900ms cubic-bezier(.2,.75,.3,1) 1 both; }
        .victory-ribbons { transform-origin: 36px 29px; animation: victory-ribbon 1050ms ease-out 1 both; }
        .victory-rays { transform-origin: 36px 37px; animation: victory-rays 1050ms ease-out 1 both; }
        .victory-shadow { transform-origin: 36px 65px; animation: victory-shadow 900ms ease-out 1 both; }
        @keyframes victory-lift { 0% { transform: translateY(16px) rotate(-12deg) scale(.82); } 55% { transform: translateY(-3px) rotate(4deg) scale(1.04); } 78% { transform: translateY(1px) rotate(-2deg); } 100% { transform: none; } }
        @keyframes victory-ribbon { 0%, 25% { transform: scaleY(.2); } 65% { transform: scaleY(1.12); } 100% { transform: none; } }
        @keyframes victory-rays { 0%, 35% { opacity: 0; transform: scale(.7); } 65% { opacity: .8; transform: scale(1.05); } 100% { opacity: .35; transform: none; } }
        @keyframes victory-shadow { 0% { transform: scaleX(.6); } 100% { transform: none; } }
        @keyframes victory-light { 0% { opacity: 0; transform: translateX(-110%); } 40% { opacity: .12; } 100% { opacity: 0; transform: translateX(110%); } }
        @media (prefers-reduced-motion: reduce) {
          .victory-cup, .victory-ribbons, .victory-rays, .victory-shadow { animation: none; transform: none; }
          .victory-rays { opacity: .35; }
          .victory-moment::before { animation: none; opacity: 0; transform: none; }
        }
      ` })
  ] });
}

// src/components/soccer-career/careerMoments.ts
var import_react11 = __toESM(require_react(), 1);
var settled = /* @__PURE__ */ new Set();
var IN_VIEW = { rootMargin: "0px 0px -15% 0px" };
function useCareerMoment(key) {
  const [fresh] = (0, import_react11.useState)(() => key !== null && !settled.has(key));
  const [el, setEl] = (0, import_react11.useState)(null);
  const [live, setLive] = (0, import_react11.useState)(false);
  (0, import_react11.useEffect)(() => {
    if (!fresh || live || !el) return;
    if (typeof IntersectionObserver === "undefined") {
      setLive(true);
      return;
    }
    const io = new IntersectionObserver((entries) => {
      if (entries.some((e) => e.isIntersecting)) setLive(true);
    }, IN_VIEW);
    io.observe(el);
    return () => io.disconnect();
  }, [fresh, live, el]);
  (0, import_react11.useEffect)(() => {
    if (key && live) settled.add(key);
  }, [key, live]);
  return { fresh, live, ref: setEl };
}

// src/components/season-centre/SeasonCentre.tsx
init_soccerCareerLeague();

// src/components/season-centre/MatchClock.tsx
var import_react12 = __toESM(require_react(), 1);
var import_jsx_runtime20 = __toESM(require_jsx_runtime(), 1);
var MATCH_SECONDS = { 1: 15, 3: 5 };
function scoreAt(events, minute) {
  let us = 0, them = 0;
  for (const e of events) if (e.pts && e.min <= minute) {
    if (e.side === "us") us += e.pts;
    else them += e.pts;
  }
  return [us, them];
}
function MatchClock({ game, clock, usName, themName, speed, paused, reduced, onFullTime, holdAt, onHold }) {
  const FULL_TIME = clock.length;
  const instant = reduced || speed === "results";
  const limit = holdAt != null ? Math.max(0, Math.min(FULL_TIME, holdAt - 1)) : FULL_TIME;
  const [minute, setMinute] = (0, import_react12.useState)(() => instant ? limit : 0);
  const done = minute >= FULL_TIME;
  const held = !done && holdAt != null && minute >= limit;
  const heldFor = (0, import_react12.useRef)(null);
  const listRef = (0, import_react12.useRef)(null);
  const told = (0, import_react12.useRef)(false);
  (0, import_react12.useEffect)(() => {
    if (done || held) return;
    if (instant) {
      setMinute(limit);
      return;
    }
    if (paused) return;
    let raf = 0;
    let last = performance.now();
    let hidden = typeof document !== "undefined" && document.hidden;
    const onVis = () => {
      hidden = document.hidden;
      last = performance.now();
    };
    document.addEventListener("visibilitychange", onVis);
    const perMs = FULL_TIME / (MATCH_SECONDS[speed] * 1e3);
    const tick = (now) => {
      const dt = Math.min(250, now - last);
      last = now;
      if (!hidden) setMinute((m) => Math.min(limit, m + dt * perMs));
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(raf);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, [done, held, limit, instant, paused, speed, FULL_TIME]);
  (0, import_react12.useEffect)(() => {
    if (done && !told.current) {
      told.current = true;
      onFullTime();
    }
  }, [done, onFullTime]);
  (0, import_react12.useEffect)(() => {
    if (held && holdAt != null && heldFor.current !== holdAt) {
      heldFor.current = holdAt;
      onHold?.();
    }
  }, [held, holdAt, onHold]);
  const shown = Math.floor(minute);
  const seen = game.events.filter((e) => e.min <= shown);
  const [us, them] = scoreAt(game.events, shown);
  (0, import_react12.useEffect)(() => {
    const el = listRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [seen.length]);
  const bugName = clock.short ?? ((name) => name);
  const homeName = bugName(game.home ? usName : themName);
  const awayName = bugName(game.home ? themName : usName);
  const hg = game.home ? us : them;
  const ag = game.home ? them : us;
  return /* @__PURE__ */ (0, import_jsx_runtime20.jsxs)("div", { "data-match-clock": true, "data-minute": shown, "data-score": `${us}-${them}`, "data-held": held ? "true" : void 0, children: [
    /* @__PURE__ */ (0, import_jsx_runtime20.jsxs)("div", { className: "flex items-center justify-between gap-2 rounded-xl bg-muted/30 px-3 py-2", children: [
      /* @__PURE__ */ (0, import_jsx_runtime20.jsx)("span", { className: "min-w-0 flex-1 truncate text-sm font-bold", children: homeName }),
      /* @__PURE__ */ (0, import_jsx_runtime20.jsxs)("span", { className: `${shown > 0 && !instant ? "cm-slam" : ""} shrink-0 text-xl font-black tabular-nums`, "data-score-bug": true, children: [
        hg,
        "-",
        ag
      ] }, `${hg}-${ag}`),
      /* @__PURE__ */ (0, import_jsx_runtime20.jsx)("span", { className: "min-w-0 flex-1 truncate text-right text-sm font-bold", children: awayName })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime20.jsxs)("div", { className: "mt-1 flex items-center justify-between text-[11px] text-muted-foreground", children: [
      /* @__PURE__ */ (0, import_jsx_runtime20.jsx)("span", { className: "tabular-nums", "data-clock-minute": true, children: done ? clock.endShort ?? "FT" : clock.label(shown) }),
      done && /* @__PURE__ */ (0, import_jsx_runtime20.jsx)("span", { className: `${instant ? "" : "cm-slam"} font-bold text-foreground`, "data-full-time": true, children: clock.end ?? "Full time" })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime20.jsxs)("ol", { ref: listRef, className: "mt-2 h-28 overflow-y-auto space-y-1 text-xs", "aria-live": "polite", "data-clock-events": true, children: [
      seen.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime20.jsx)("li", { className: "text-muted-foreground", children: clock.start ?? "Kick off." }),
      seen.map((e, i) => /* @__PURE__ */ (0, import_jsx_runtime20.jsxs)("li", { className: `${instant ? "" : "cm-tick-in"} flex gap-2`, children: [
        /* @__PURE__ */ (0, import_jsx_runtime20.jsx)("span", { className: `${clock.labelClass ?? "w-8"} shrink-0 tabular-nums text-muted-foreground`, children: clock.label(e.min) }),
        /* @__PURE__ */ (0, import_jsx_runtime20.jsx)("span", { className: e.mine ? "font-bold text-primary" : "", children: clock.words(e, usName, themName) })
      ] }, `${i}-${e.min}-${e.kind}`))
    ] })
  ] });
}

// src/components/season-centre/MomentHost.tsx
var import_react13 = __toESM(require_react(), 1);

// src/components/arcade/ArcadeShotFeedback.module.css
var ArcadeShotFeedback_default = {
  card: "ArcadeShotFeedback_card",
  success: "ArcadeShotFeedback_success",
  content: "ArcadeShotFeedback_content",
  heading: "ArcadeShotFeedback_heading",
  verdict: "ArcadeShotFeedback_verdict",
  miss: "ArcadeShotFeedback_miss",
  icon: "ArcadeShotFeedback_icon",
  ring: "ArcadeShotFeedback_ring",
  spark: "ArcadeShotFeedback_spark",
  sweep: "ArcadeShotFeedback_sweep",
  burst: "ArcadeShotFeedback_burst",
  score: "ArcadeShotFeedback_score"
};

// src/components/arcade/ArcadeShotFeedback.tsx
var import_jsx_runtime21 = __toESM(require_jsx_runtime(), 1);
var SPARKS = [[-32, -16], [-14, -30], [22, -26], [34, 8], [12, 30], [-26, 24]];
function ArcadeShotFeedback({ sport, success, verdict, points, score, detail, children }) {
  return /* @__PURE__ */ (0, import_jsx_runtime21.jsxs)("div", { "data-arcade-feedback": true, "data-outcome": success ? "success" : "miss", className: `rounded-2xl border border-border bg-card p-4 text-center ${ArcadeShotFeedback_default.card} ${success ? ArcadeShotFeedback_default.success : ArcadeShotFeedback_default.miss}`, children: [
    success && /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("span", { "aria-hidden": "true", className: ArcadeShotFeedback_default.sweep }),
    /* @__PURE__ */ (0, import_jsx_runtime21.jsxs)("div", { role: "status", className: ArcadeShotFeedback_default.content, children: [
      /* @__PURE__ */ (0, import_jsx_runtime21.jsxs)("div", { className: ArcadeShotFeedback_default.heading, children: [
        /* @__PURE__ */ (0, import_jsx_runtime21.jsxs)("span", { "aria-hidden": "true", className: ArcadeShotFeedback_default.icon, children: [
          success && /* @__PURE__ */ (0, import_jsx_runtime21.jsxs)(import_jsx_runtime21.Fragment, { children: [
            /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("span", { className: ArcadeShotFeedback_default.ring }),
            SPARKS.map(([x, y]) => /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("span", { className: ArcadeShotFeedback_default.spark, style: { "--spark-x": `${x}px`, "--spark-y": `${y}px` } }, `${x},${y}`))
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("svg", { viewBox: "0 0 28 28", fill: "none", stroke: "currentColor", strokeWidth: "1.5", strokeLinecap: "round", strokeLinejoin: "round", children: sport === "goal" ? /* @__PURE__ */ (0, import_jsx_runtime21.jsxs)(import_jsx_runtime21.Fragment, { children: [
            /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("path", { d: "M3 22V7h22v15M3 12h22M3 17h22M9 7v15M15 7v15M21 7v15" }),
            /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("circle", { cx: "19", cy: "20", r: "4", fill: "hsl(var(--card))" }),
            /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("path", { d: "m18 18 2 1-.5 2h-2l-.5-2Z" })
          ] }) : /* @__PURE__ */ (0, import_jsx_runtime21.jsxs)(import_jsx_runtime21.Fragment, { children: [
            /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("path", { d: "M5 8h18M7 8l3 15h8l3-15M9 12l10 7M19 12l-10 7M10 23l9-11M18 23 9 12" }),
            /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("circle", { cx: "14", cy: "4.5", r: "3", fill: "hsl(var(--card))" }),
            /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("path", { d: "M11 4.5h6M14 1.5v6" })
          ] }) })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("p", { className: `font-display font-black ${ArcadeShotFeedback_default.verdict}`, children: verdict })
      ] }),
      detail,
      success && /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("p", { className: `font-display font-black ${ArcadeShotFeedback_default.score}`, children: score ?? /* @__PURE__ */ (0, import_jsx_runtime21.jsxs)(import_jsx_runtime21.Fragment, { children: [
        points,
        " points."
      ] }) })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("div", { className: ArcadeShotFeedback_default.content, children })
  ] });
}

// src/components/season-centre/MomentHost.tsx
var import_jsx_runtime22 = __toESM(require_jsx_runtime(), 1);
var STARS_MAX = 3;
function MomentStars({ stars, reduced }) {
  return /* @__PURE__ */ (0, import_jsx_runtime22.jsx)("span", { className: "inline-flex gap-1 text-xl", role: "img", "aria-label": `${stars} of ${STARS_MAX} stars`, "data-moment-stars": stars, children: Array.from({ length: STARS_MAX }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime22.jsx)("span", { className: i < stars ? reduced ? "text-amber-400" : "cm-tick-in text-amber-400" : "text-muted-foreground/40", style: i < stars && !reduced ? { animationDelay: revealDelay(i, 0.25, 0.3) } : void 0, children: i < stars ? "\u2605" : "\u2606" }, i)) });
}
var focusOnMount = (el) => {
  el?.focus({ preventScroll: true });
};
function MomentHost({ moment, moments, scoreLine, reduced, onDone }) {
  const [step, setStep] = (0, import_react13.useState)(() => moment.taken ? "spent" : "offer");
  const [verdict, setVerdict] = (0, import_react13.useState)(null);
  const live = (0, import_react13.useRef)({ moment, moments });
  live.current = { moment, moments };
  const mounted = (0, import_react13.useRef)(true);
  const settled2 = (0, import_react13.useRef)(false);
  (0, import_react13.useEffect)(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);
  const take = (0, import_react13.useCallback)(async () => {
    setStep((s) => s === "offer" || s === "failed" ? "loading" : s);
    try {
      await live.current.moments.preload(live.current.moment);
    } catch {
      if (mounted.current) setStep("failed");
      return;
    }
    if (!mounted.current) return;
    if (live.current.moment.taken) {
      setStep("spent");
      return;
    }
    live.current.moments.use(live.current.moment);
    setStep("board");
  }, []);
  const done = (0, import_react13.useCallback)((input) => {
    if (settled2.current || !mounted.current) return;
    settled2.current = true;
    setVerdict(live.current.moments.settle(live.current.moment, input));
    setStep("verdict");
  }, []);
  const key = `${moment.md}|${moment.id}`;
  const board = (0, import_react13.useMemo)(() => step === "board" ? live.current.moments.board(live.current.moment, done) : null, [step, key, done]);
  const badge = moment.mode === "call" ? "YOUR CALL" : "RECREATE";
  if (step === "board") return /* @__PURE__ */ (0, import_jsx_runtime22.jsx)("div", { tabIndex: -1, ref: focusOnMount, className: "outline-none", "data-moment-board": true, "data-moment-mode": moment.mode, children: board }, "board");
  if (step === "spent") {
    const made = !!moment.taken?.made;
    return /* @__PURE__ */ (0, import_jsx_runtime22.jsxs)("div", { className: "space-y-3 rounded-2xl border border-border bg-card p-4", "data-moment-spent": true, "data-moment-mode": moment.mode, children: [
      /* @__PURE__ */ (0, import_jsx_runtime22.jsxs)("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ (0, import_jsx_runtime22.jsx)("span", { className: "rounded bg-muted px-1.5 py-0.5 text-[10px] font-black tracking-wider text-muted-foreground", "data-moment-badge": true, children: badge }),
        /* @__PURE__ */ (0, import_jsx_runtime22.jsx)("span", { className: "text-xs tabular-nums text-muted-foreground", children: scoreLine })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime22.jsx)("p", { className: "text-base font-black", children: "Your go at this one is used" }),
      /* @__PURE__ */ (0, import_jsx_runtime22.jsx)("p", { className: "text-xs text-muted-foreground", children: made ? "It is in the book with the stars you earned." : "One go a moment, and this one went in the book as a miss." }),
      made && /* @__PURE__ */ (0, import_jsx_runtime22.jsx)(MomentStars, { stars: moment.taken?.stars ?? 0, reduced: true }),
      /* @__PURE__ */ (0, import_jsx_runtime22.jsx)("button", { type: "button", autoFocus: true, onClick: () => onDone(true), className: "h-11 w-full rounded-lg bg-emerald-600 text-sm font-bold text-black hover:bg-emerald-500", "data-moment-back": true, children: "\u25B6 Back to the match" })
    ] }, "spent");
  }
  if (step === "verdict" && verdict) {
    return /* @__PURE__ */ (0, import_jsx_runtime22.jsxs)("div", { className: "relative", "data-moment-verdict": verdict.made ? "made" : "missed", "data-moment-mode": moment.mode, children: [
      verdict.wonMatch && !reduced && /* @__PURE__ */ (0, import_jsx_runtime22.jsx)(ConfettiBurst, { seed: confettiSeedOf(key) }),
      /* @__PURE__ */ (0, import_jsx_runtime22.jsx)(
        ArcadeShotFeedback,
        {
          sport: moments.feedback,
          success: verdict.made,
          verdict: verdict.verdict,
          points: verdict.stars,
          score: /* @__PURE__ */ (0, import_jsx_runtime22.jsx)(MomentStars, { stars: verdict.stars, reduced }),
          detail: /* @__PURE__ */ (0, import_jsx_runtime22.jsx)("p", { className: "mt-2 text-xs text-muted-foreground", "data-moment-after": true, children: verdict.after }),
          children: /* @__PURE__ */ (0, import_jsx_runtime22.jsx)("button", { type: "button", autoFocus: true, onClick: () => onDone(true), className: "mt-3 h-11 w-full rounded-lg bg-emerald-600 text-sm font-bold text-black hover:bg-emerald-500", "data-moment-back": true, children: "\u25B6 Back to the match" })
        }
      )
    ] }, "verdict");
  }
  return /* @__PURE__ */ (0, import_jsx_runtime22.jsxs)("div", { tabIndex: -1, ref: focusOnMount, className: `${reduced ? "" : "cm-slam"} space-y-3 rounded-2xl border border-primary/40 bg-card p-4 outline-none`, "data-moment-offer": true, "data-moment-mode": moment.mode, children: [
    /* @__PURE__ */ (0, import_jsx_runtime22.jsxs)("div", { className: "flex items-center gap-2", children: [
      /* @__PURE__ */ (0, import_jsx_runtime22.jsx)("span", { className: "rounded bg-primary/20 px-1.5 py-0.5 text-[10px] font-black tracking-wider text-primary", "data-moment-badge": true, children: badge }),
      /* @__PURE__ */ (0, import_jsx_runtime22.jsx)("span", { className: "text-xs tabular-nums text-muted-foreground", children: scoreLine })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime22.jsx)("p", { className: "text-base font-black", children: moment.line }),
    /* @__PURE__ */ (0, import_jsx_runtime22.jsx)("p", { className: "text-xs text-muted-foreground", "data-moment-objective": true, children: moment.objective }),
    /* @__PURE__ */ (0, import_jsx_runtime22.jsxs)("p", { className: "rounded-lg bg-muted/30 p-2 text-[11px] leading-snug text-muted-foreground", "data-moment-how": true, children: [
      /* @__PURE__ */ (0, import_jsx_runtime22.jsx)("span", { className: "font-bold text-foreground", children: "How it plays: " }),
      moment.how
    ] }),
    step === "failed" && /* @__PURE__ */ (0, import_jsx_runtime22.jsx)("p", { className: "text-xs text-amber-400", role: "alert", children: "The pitch did not load, so nothing was used. Try again or let it play." }),
    /* @__PURE__ */ (0, import_jsx_runtime22.jsxs)("div", { className: "flex flex-col gap-2 sm:flex-row", children: [
      /* @__PURE__ */ (0, import_jsx_runtime22.jsx)("button", { type: "button", disabled: step === "loading", onClick: take, className: "h-11 shrink-0 sm:flex-1 rounded-lg bg-emerald-600 text-sm font-bold text-black hover:bg-emerald-500 disabled:opacity-60", "data-moment-take": true, children: step === "loading" ? "Getting the pitch ready..." : "\u{1F3AF} Take it yourself" }),
      /* @__PURE__ */ (0, import_jsx_runtime22.jsx)("button", { type: "button", disabled: step === "loading", onClick: () => onDone(false), className: "h-11 shrink-0 sm:flex-1 rounded-lg border border-border text-sm font-semibold hover:bg-muted/40 disabled:opacity-60", "data-moment-pass": true, children: "\u25B6 Let it play" })
    ] })
  ] }, "offer");
}

// src/components/season-centre/SeasonCentreHelp.tsx
var import_react14 = __toESM(require_react(), 1);
var import_jsx_runtime23 = __toESM(require_jsx_runtime(), 1);
var SEEN_KEY = "seasonCentre:help";
function useHelpOnce(key = SEEN_KEY) {
  const [open, setOpen] = (0, import_react14.useState)(false);
  (0, import_react14.useEffect)(() => {
    let seen = false;
    try {
      seen = localStorage.getItem(key) === "1";
    } catch {
      seen = false;
    }
    if (seen) return;
    setOpen(true);
    try {
      localStorage.setItem(key, "1");
    } catch {
    }
  }, [key]);
  return [open, setOpen];
}
function SeasonCentreHelp({ words, onClose }) {
  return /* @__PURE__ */ (0, import_jsx_runtime23.jsx)("div", { className: "absolute inset-0 z-10 flex items-start justify-center overflow-y-auto bg-background/95 p-4 outline-none", role: "dialog", "aria-modal": "true", "aria-label": words.title, tabIndex: -1, ref: focusDialogOnMount, onKeyDown: (e) => {
    if (e.key === "Escape") e.stopPropagation();
    escapeCloses(onClose)(e);
  }, "data-season-help": true, children: /* @__PURE__ */ (0, import_jsx_runtime23.jsxs)("div", { className: "w-full max-w-lg space-y-3 rounded-2xl border border-border bg-card p-4 text-sm", children: [
    /* @__PURE__ */ (0, import_jsx_runtime23.jsx)("h3", { className: "text-base font-black", children: words.title }),
    words.intro.map((p) => /* @__PURE__ */ (0, import_jsx_runtime23.jsx)("p", { className: "leading-relaxed text-muted-foreground", children: p }, p)),
    /* @__PURE__ */ (0, import_jsx_runtime23.jsx)("p", { className: "leading-relaxed", children: words.controls }),
    words.moments && words.moments.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime23.jsxs)("div", { className: "space-y-2", "data-help-moments": true, children: [
      /* @__PURE__ */ (0, import_jsx_runtime23.jsx)("div", { className: "text-xs font-bold uppercase tracking-wider text-muted-foreground", children: "\u{1F3AF} Your moments" }),
      words.moments.map((p) => /* @__PURE__ */ (0, import_jsx_runtime23.jsx)("p", { className: "text-xs leading-relaxed text-muted-foreground", children: p }, p))
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime23.jsxs)("div", { className: "space-y-2", children: [
      /* @__PURE__ */ (0, import_jsx_runtime23.jsx)("div", { className: "text-xs font-bold uppercase tracking-wider text-muted-foreground", children: "Worked examples" }),
      words.examples.map((x) => /* @__PURE__ */ (0, import_jsx_runtime23.jsxs)("div", { className: "rounded-lg bg-muted/30 p-2", children: [
        /* @__PURE__ */ (0, import_jsx_runtime23.jsx)("div", { className: "text-xs font-bold", children: x.head }),
        /* @__PURE__ */ (0, import_jsx_runtime23.jsx)("div", { className: "text-xs leading-relaxed text-muted-foreground", children: x.body })
      ] }, x.head))
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime23.jsx)("p", { className: "text-[11px] text-muted-foreground", children: words.footnote }),
    /* @__PURE__ */ (0, import_jsx_runtime23.jsx)("button", { type: "button", onClick: onClose, className: "h-10 w-full rounded-lg bg-primary text-sm font-bold text-primary-foreground", children: "Got it" })
  ] }) });
}

// src/components/season-centre/RecordPanel.tsx
var import_react15 = __toESM(require_react(), 1);
var import_jsx_runtime24 = __toESM(require_jsx_runtime(), 1);
var resOf = (g) => g.us > g.them ? "W" : g.us < g.them ? "L" : "D";
var PILL = { W: "bg-emerald-500/20 text-emerald-400", D: "bg-muted text-muted-foreground", L: "bg-red-500/20 text-red-400" };
function recordOf(games) {
  let w = 0;
  let l = 0;
  let d = 0;
  for (const g of games) {
    const r2 = resOf(g);
    if (r2 === "W") w += 1;
    else if (r2 === "L") l += 1;
    else d += 1;
  }
  return d > 0 ? `${w}-${l}-${d}` : `${w}-${l}`;
}
function streakOf(games, tie) {
  if (games.length === 0) return "";
  const last = resOf(games[games.length - 1]);
  let n = 0;
  for (let i = games.length - 1; i >= 0 && resOf(games[i]) === last; i -= 1) n += 1;
  return `${last === "D" ? tie : last}${n}`;
}
function RecordPanel({ model, played, compact, reduced = false, tie = "D", groups, short }) {
  const [logOpen, setLogOpen] = (0, import_react15.useState)(false);
  const { season: s, names, words } = model;
  const done = s.games.filter((g) => g.md <= played);
  const rec = recordOf(done);
  const letter = (r2) => r2 === "D" ? tie : r2;
  const shorten = short ?? model.sport.clock.short;
  const nameOf = (g) => shorten ? shorten(names[g.opp]) : names[g.opp];
  const lineOf = (g) => [...model.sport.markChip ? [model.sport.markChip(g)] : [], ...model.sport.lineOf(g).bits].join(" ");
  const log2 = /* @__PURE__ */ (0, import_jsx_runtime24.jsxs)("ol", { className: "space-y-1 text-[11px]", "data-game-log": true, children: [
    done.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime24.jsx)("li", { className: "text-muted-foreground", children: "No games yet." }),
    [...done].reverse().map((g) => {
      const r2 = resOf(g);
      return /* @__PURE__ */ (0, import_jsx_runtime24.jsxs)("li", { className: "flex flex-wrap items-center gap-x-1.5 gap-y-0.5", "data-log-row": g.md, children: [
        /* @__PURE__ */ (0, import_jsx_runtime24.jsxs)("span", { className: "tabular-nums text-muted-foreground", children: [
          "G",
          g.md
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime24.jsx)("span", { className: "text-muted-foreground", children: g.home ? "H" : "A" }),
        /* @__PURE__ */ (0, import_jsx_runtime24.jsx)("span", { className: names[g.opp] === words.unnamed ? "italic text-muted-foreground" : "font-semibold", children: nameOf(g) }),
        /* @__PURE__ */ (0, import_jsx_runtime24.jsxs)("span", { className: `rounded px-1 font-bold tabular-nums ${PILL[r2]}`, children: [
          letter(r2),
          " ",
          g.us,
          "-",
          g.them
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime24.jsx)("span", { className: "tabular-nums", children: g.played ? lineOf(g) : model.sport.missed(g.why) })
      ] }, g.md);
    })
  ] });
  if (compact && logOpen) {
    return /* @__PURE__ */ (0, import_jsx_runtime24.jsxs)("div", { className: "space-y-2", "data-record-panel": true, "data-record": rec, children: [
      /* @__PURE__ */ (0, import_jsx_runtime24.jsx)("button", { type: "button", onClick: () => setLogOpen(false), className: "h-10 rounded-lg border border-border px-3 text-xs font-semibold", children: "\u2190 Back" }),
      /* @__PURE__ */ (0, import_jsx_runtime24.jsx)("div", { className: "h-48 overflow-y-auto rounded-lg bg-muted/30 p-2", children: log2 })
    ] });
  }
  const home = done.filter((g) => g.home);
  const away = done.filter((g) => !g.home);
  const streak = streakOf(done, tie);
  return /* @__PURE__ */ (0, import_jsx_runtime24.jsxs)("div", { className: "space-y-2", "data-record-panel": true, "data-record": rec, children: [
    /* @__PURE__ */ (0, import_jsx_runtime24.jsxs)("div", { className: "rounded-lg bg-muted/30 p-2", children: [
      /* @__PURE__ */ (0, import_jsx_runtime24.jsxs)("div", { className: "flex items-baseline justify-between gap-2", children: [
        /* @__PURE__ */ (0, import_jsx_runtime24.jsx)("span", { className: "text-xs font-bold", children: played === 0 ? "Before the first game" : `After ${words.round.toLowerCase()} ${played}` }),
        /* @__PURE__ */ (0, import_jsx_runtime24.jsx)("span", { className: `${reduced ? "" : "cm-tick-in"} text-2xl font-black tabular-nums`, "data-record-chip": true, children: rec }, rec)
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime24.jsxs)("div", { className: "mt-1 flex flex-wrap gap-x-3 gap-y-0.5 text-[11px] text-muted-foreground", children: [
        /* @__PURE__ */ (0, import_jsx_runtime24.jsxs)("span", { children: [
          "Home ",
          recordOf(home)
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime24.jsxs)("span", { children: [
          "Away ",
          recordOf(away)
        ] }),
        streak && /* @__PURE__ */ (0, import_jsx_runtime24.jsxs)("span", { children: [
          "Streak ",
          streak
        ] }),
        (groups ?? []).map((gr) => /* @__PURE__ */ (0, import_jsx_runtime24.jsxs)("span", { children: [
          gr.label,
          " ",
          recordOf(done.filter((g) => gr.slots.includes(g.opp)))
        ] }, gr.label))
      ] }),
      done.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime24.jsxs)("div", { className: "mt-1.5 flex flex-wrap items-center gap-1 text-[10px]", "data-last-ten": true, children: [
        /* @__PURE__ */ (0, import_jsx_runtime24.jsxs)("span", { className: "mr-0.5 text-muted-foreground", children: [
          "Last ",
          Math.min(10, done.length),
          ":"
        ] }),
        done.slice(-10).map((g) => /* @__PURE__ */ (0, import_jsx_runtime24.jsx)("span", { className: `rounded px-1 font-bold ${PILL[resOf(g)]}`, children: letter(resOf(g)) }, g.md))
      ] })
    ] }),
    compact ? /* @__PURE__ */ (0, import_jsx_runtime24.jsx)("button", { type: "button", onClick: () => setLogOpen(true), className: "h-10 w-full rounded-lg border border-border text-xs font-semibold", "data-game-log-open": true, children: "\u{1F4CB} Game log" }) : /* @__PURE__ */ (0, import_jsx_runtime24.jsxs)("div", { children: [
      /* @__PURE__ */ (0, import_jsx_runtime24.jsx)("div", { className: "mb-1 text-[10px] font-bold uppercase tracking-wider text-muted-foreground", children: "Game log" }),
      log2
    ] })
  ] });
}

// src/components/season-centre/SeasonCentre.tsx
var import_jsx_runtime25 = __toESM(require_jsx_runtime(), 1);
var SOCCER_COPY = {
  start: "\u25B6 Kick off",
  lastBadge: "FINAL DAY",
  lastHead: "Final day",
  lastBody: (round) => `The last ${round.toLowerCase()} of the season.`,
  best: "Best match",
  bestSoFar: "Best so far",
  scope: "All competitions, the same as your season summary.",
  soFarHead: "League so far",
  tie: "D",
  list: "Fixtures",
  side: "Table"
};
var copyOf = (model) => model.copy ? { ...SOCCER_COPY, ...model.copy } : SOCCER_COPY;
function postersFor(s, md) {
  const M = s.games.length;
  const out = [];
  if (s.clinch && md === s.clinch.md + 1) out.push("title");
  if (s.games[md - 1]?.fixedKey) out.push("derby");
  if (M >= 10 && md === Math.floor(M / 2) + 1) out.push("halfway");
  if (md === M && M > 1) out.push("final");
  return out;
}
function resultOf(g) {
  return g.us > g.them ? "W" : g.us < g.them ? "L" : "D";
}
var PILL2 = { W: "bg-emerald-500/20 text-emerald-400", D: "bg-muted text-muted-foreground", L: "bg-red-500/20 text-red-400" };
function useWide() {
  const query = "(min-width: 768px)";
  const [wide, setWide] = (0, import_react16.useState)(() => typeof window !== "undefined" && typeof window.matchMedia === "function" && window.matchMedia(query).matches);
  (0, import_react16.useEffect)(() => {
    if (typeof window.matchMedia !== "function") return;
    const m = window.matchMedia(query);
    const on = () => setWide(m.matches);
    m.addEventListener("change", on);
    return () => m.removeEventListener("change", on);
  }, []);
  return wide;
}
function useReducedMotion() {
  const [reduced] = (0, import_react16.useState)(() => typeof window !== "undefined" && typeof window.matchMedia === "function" && window.matchMedia("(prefers-reduced-motion: reduce)").matches);
  return reduced;
}
function FixtureList({ model, played, current, short }) {
  const { season: s, names, words } = model;
  const copy = copyOf(model);
  const yours = new Set((model.moments?.list ?? []).map((m) => m.md));
  return /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("ol", { className: "space-y-1", "data-fixtures": true, children: s.games.map((g) => {
    const done = g.md <= played;
    const r2 = resultOf(g);
    const on = current === g.md;
    return /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("li", { className: `flex items-center gap-2 rounded-lg px-2 py-1 text-xs ${on ? "bg-primary/15 ring-1 ring-primary/40" : ""}`, "aria-current": on ? "true" : void 0, children: [
      /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("span", { className: "w-6 shrink-0 tabular-nums text-muted-foreground", children: g.md }),
      /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("span", { className: "w-4 shrink-0 text-[10px] text-muted-foreground", children: g.home ? "H" : "A" }),
      /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("span", { className: `min-w-0 flex-1 truncate ${done ? "" : "text-muted-foreground"} ${names[g.opp] === words.unnamed ? "italic" : ""}`, children: short ? short(names[g.opp]) : names[g.opp] }),
      g.fixedKey && /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("span", { className: "shrink-0 rounded bg-amber-500/20 px-1 text-[9px] font-bold text-amber-400", children: model.sport.fixed.badge }),
      yours.has(g.md) && /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("span", { className: "shrink-0 text-[10px]", title: "One of your moments", "data-fixture-moment": true, children: "\u{1F3AF}" }),
      g.md === s.games.length && /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("span", { className: "shrink-0 rounded bg-sky-500/20 px-1 text-[9px] font-bold text-sky-400", children: copy.lastBadge }),
      done && /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("span", { className: `shrink-0 rounded px-1.5 text-[10px] font-bold tabular-nums ${PILL2[r2]}`, children: [
        r2 === "D" ? copy.tie : r2,
        " ",
        g.us,
        "-",
        g.them
      ] })
    ] }, g.md);
  }) });
}
function HisLine({ g, sport }) {
  if (!g.played) return /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("p", { className: "text-xs text-muted-foreground", "data-his-line": true, children: sport.missed(g.why) });
  const { bits, alarm } = sport.lineOf(g);
  return /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { className: `flex flex-wrap items-center gap-2 text-xs ${alarm ? "cm-loss-shake" : ""}`, "data-his-line": true, children: [
    /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("span", { className: "rounded-md bg-primary/15 px-2 py-0.5 font-black tabular-nums text-primary", children: sport.markChip ? sport.markChip(g) : sport.markOf(g).toFixed(1) }),
    bits.map((b) => /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("span", { children: b }, b)),
    alarm && /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("span", { className: "text-red-400", children: alarm })
  ] });
}
function TablePanel({ model, played, compact }) {
  const { season: s } = model;
  const rows = (0, import_react16.useMemo)(() => tableAt(s, played), [s, played]);
  const before = (0, import_react16.useMemo)(() => tableAt(s, Math.max(0, played - 1)), [s, played]);
  if (s.mode !== "table") return null;
  const keyOf = (slot) => s.labels[slot]?.key ?? `u${slot}`;
  const unnamed = new Set(s.labels.filter((l) => !l.named).map((l) => l.key));
  const at = rows.findIndex((r2) => r2.slot === 0) + 1;
  const was = before.findIndex((r2) => r2.slot === 0) + 1;
  const move = played > 1 ? was - at : 0;
  return /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { "data-centre-table": true, children: [
    /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { className: "mb-1 flex items-center justify-between text-xs", children: [
      /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("span", { className: "font-bold", children: played === 0 ? "Before a ball is kicked" : `After ${model.words.round.toLowerCase()} ${played}` }),
      played > 0 && /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("span", { className: "cm-tick-in font-bold tabular-nums", "data-his-position": true, children: [
        ordinal(at),
        move > 0 ? ` \u25B2${move}` : move < 0 ? ` \u25BC${-move}` : ""
      ] }, `${played}-${at}`)
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime25.jsx)(
      LeagueTableCard,
      {
        rows: rows.map((r2) => ({ club: keyOf(r2.slot), w: r2.w, d: r2.d, l: r2.l, gf: r2.gf, ga: r2.ga, pts: r2.pts })),
        myClub: keyOf(0),
        compact,
        preseason: played === 0,
        zoneTop: 1,
        isUnnamed: (k) => unnamed.has(k),
        footnote: "Clubs level on points are split by goal difference, then goals scored: this game's rule."
      }
    )
  ] });
}
function KickOff({ model, onKick, onStraight }) {
  const { season: s, header, names, occasion } = model;
  const copy = copyOf(model);
  return /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { className: "cm-rise space-y-3", "data-kickoff": true, children: [
    /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { children: [
      /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: "text-lg font-black", children: header.club }),
      /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { className: "text-xs text-muted-foreground", children: [
        header.seasonLabel,
        header.league ? ` \xB7 ${header.league}` : "",
        header.loanFrom ? ` \xB7 on loan from ${header.loanFrom}` : ""
      ] }),
      model.frameLine && /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: "mt-1 text-xs font-semibold", "data-frame-line": true, children: model.frameLine }),
      model.resultsWhy && /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: "mt-1 text-xs text-muted-foreground", "data-results-why": true, children: model.resultsWhy }),
      model.lastSeason && /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: "mt-1 text-xs text-muted-foreground", children: model.lastSeason }),
      model.moments?.kickoff && /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { className: "mt-1 text-xs font-semibold text-primary", "data-kickoff-moments": true, children: [
        "\u{1F3AF} ",
        model.moments.kickoff
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { children: [
      /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: "mb-1 text-[10px] font-bold uppercase tracking-wider text-muted-foreground", children: "First five" }),
      /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("ul", { className: "space-y-1", children: s.games.slice(0, 5).map((g) => /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("li", { className: "flex items-center gap-2 text-xs", children: [
        /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("span", { className: "w-6 tabular-nums text-muted-foreground", children: g.md }),
        /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("span", { className: "w-10 text-muted-foreground", children: g.home ? "Home" : "Away" }),
        /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("span", { className: `min-w-0 flex-1 truncate ${names[g.opp] === model.words.unnamed ? "italic text-muted-foreground" : ""}`, children: names[g.opp] }),
        g.fixedKey && /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("span", { className: "rounded bg-amber-500/20 px-1 text-[9px] font-bold text-amber-400", children: [
          model.sport.fixed.badge,
          " \xB7 ",
          occasion[g.fixedKey] ?? ""
        ] })
      ] }, g.md)) })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { className: "flex flex-col gap-2 sm:flex-row", children: [
      /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("button", { type: "button", onClick: onKick, className: "h-11 flex-1 rounded-lg bg-emerald-600 text-sm font-bold text-black hover:bg-emerald-500", children: copy.start }),
      /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("button", { type: "button", onClick: onStraight, className: "h-11 flex-1 rounded-lg border border-border text-sm font-semibold hover:bg-muted/40", children: s.mode === "table" ? "\u23ED Straight to the final table" : "\u23ED Straight to the season review" })
    ] })
  ] });
}
function Poster({ model, md, reduced }) {
  const { season: s, occasion } = model;
  const kinds = postersFor(s, md);
  const M = s.games.length;
  const g = s.games[md - 1];
  const moment = useCareerMoment(kinds.includes("title") && model.review.title ? `${model.momentKey}|clinch` : null);
  const slam = reduced ? "" : "cm-slam";
  const meetings = g?.fixedKey ? s.games.filter((x) => x.fixedKey === g.fixedKey) : [];
  const which = meetings.findIndex((x) => x.md === md);
  const rec = { ...model.derbyBefore };
  for (const x of s.games) if (x.fixedKey && x.md < md && x.played) rec[resultOf(x) === "W" ? "w" : resultOf(x) === "D" ? "d" : "l"] += 1;
  const half = soFar(s, Math.floor(M / 2));
  const mark = model.sport.markOf;
  const copy = copyOf(model);
  const markText = model.sport.markText ?? ((x) => `rated ${mark(x).toFixed(1)}`);
  const letter = (x) => resultOf(x) === "D" ? copy.tie : resultOf(x);
  const best = s.games.filter((x) => x.played && x.md < md).sort((a, b) => mark(b) - mark(a))[0];
  return /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { ref: moment.ref, className: "space-y-3", "data-poster": kinds.join(" "), children: [
    kinds.includes("title") && s.clinch && /* two elements on purpose: cm-slam and cm-gold-glow each set the
       animation, so on one element the glow would replace the slam and
       leave the slam's starting opacity of 0 for good */
    /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: slam, children: /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { className: `${reduced ? "" : "cm-gold-glow"} relative overflow-hidden rounded-xl border border-amber-500/40 bg-amber-500/10 p-3 text-amber-400`, children: [
      moment.fresh && moment.live && !reduced && /* @__PURE__ */ (0, import_jsx_runtime25.jsx)(Confetti, { pieces: 40, gold: true }),
      /* @__PURE__ */ (0, import_jsx_runtime25.jsx)(VictoryMoment, { compact: true, children: /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("span", { className: "text-sm font-black text-foreground", "data-clinch": true, children: [
        "Champions with ",
        M - s.clinch.md,
        " to play"
      ] }) })
    ] }) }),
    kinds.includes("derby") && g?.fixedKey && /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { className: `${slam} rounded-xl border border-amber-500/30 bg-card p-3`, children: [
      /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: "text-xs font-black uppercase tracking-wider text-amber-400", children: model.sport.fixed.poster }),
      /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { className: "text-sm font-bold", children: [
        occasion[g.fixedKey] ?? g.fixedKey,
        " \xB7 ",
        which === 0 ? "first of two" : which === 1 ? "second of two" : `meeting ${which + 1}`
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { className: "text-xs text-muted-foreground", children: [
        model.sport.fixed.recordSoFar,
        ": ",
        rec.w,
        "W ",
        rec.d,
        "D ",
        rec.l,
        "L"
      ] })
    ] }),
    kinds.includes("halfway") && /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { className: `${slam} rounded-xl border border-border bg-card p-3`, children: [
      /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: "text-xs font-black uppercase tracking-wider text-muted-foreground", children: "Halfway" }),
      /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: "text-sm", children: model.sport.half(half) }),
      best && /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { className: "text-xs text-muted-foreground", children: [
        copy.bestSoFar,
        ": ",
        model.words.round,
        " ",
        best.md,
        ", ",
        letter(best),
        " ",
        best.us,
        "-",
        best.them,
        ", ",
        markText(best)
      ] })
    ] }),
    kinds.includes("final") && /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { className: `${slam} rounded-xl border border-sky-500/30 bg-card p-3`, children: [
      /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: "text-xs font-black uppercase tracking-wider text-sky-400", children: copy.lastHead }),
      /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: "text-sm", children: copy.lastBody(model.words.round) })
    ] })
  ] });
}
function Review({ model, reduced }) {
  const { season: s, review, names, words } = model;
  const moment = useCareerMoment(review.title ? `${model.momentKey}|review` : null);
  const played = s.games.filter((g) => g.played);
  const mark = model.sport.markOf;
  const copy = copyOf(model);
  const markText = model.sport.markText ?? ((x) => `rated ${mark(x).toFixed(1)}`);
  const letter = (x) => resultOf(x) === "D" ? copy.tie : resultOf(x);
  const best = [...played].sort((a, b) => mark(b) - mark(a))[0];
  const form = s.games.slice(-5);
  const derbies = played.filter((g) => g.fixedKey);
  const dr = { w: 0, d: 0, l: 0 };
  for (const g of derbies) dr[resultOf(g) === "W" ? "w" : resultOf(g) === "D" ? "d" : "l"] += 1;
  const tiles = review.tiles;
  const rise = (i) => reduced ? void 0 : { animationDelay: revealDelay(i, 0.1, 0.16) };
  const bucket = s.bucket && s.bucket.apps > 0 ? s.bucket : null;
  return /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { ref: moment.ref, className: "relative space-y-3", "data-review": true, children: [
    review.title && moment.fresh && moment.live && !reduced && /* @__PURE__ */ (0, import_jsx_runtime25.jsx)(Confetti, { pieces: 55, gold: true }),
    /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { className: reduced ? "" : "cm-rise", style: rise(0), children: [
      /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: "text-lg font-black", children: "Season review" }),
      review.finishLine && /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: "text-sm font-semibold", "data-review-finish": true, children: review.finishLine }),
      review.championLine && /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: "text-xs text-muted-foreground", "data-review-champion": true, children: review.championLine })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: "grid grid-cols-4 gap-2", children: tiles.map(([label, value], i) => /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { className: `${reduced ? "" : "cm-rise"} rounded-lg bg-muted/30 p-2 text-center`, style: rise(i + 1), "data-review-tile": label, children: [
      /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: "text-lg font-black tabular-nums", children: value }),
      /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: "text-[10px] text-muted-foreground", children: label })
    ] }, label)) }),
    /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: "text-[11px] text-muted-foreground", children: copy.scope }),
    best && /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { className: `${reduced ? "" : "cm-rise"} text-xs`, style: rise(5), children: [
      "\u2B50 ",
      copy.best,
      ": ",
      words.round,
      " ",
      best.md,
      ", ",
      letter(best),
      " ",
      best.us,
      "-",
      best.them,
      " vs ",
      names[best.opp],
      ", ",
      markText(best)
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { className: `${reduced ? "" : "cm-rise"} flex items-center gap-1 text-xs`, style: rise(6), children: [
      /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("span", { className: "mr-1 text-muted-foreground", children: "Last five:" }),
      form.map((g) => /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("span", { className: `rounded px-1.5 font-bold ${PILL2[resultOf(g)]}`, children: letter(g) }, g.md))
    ] }),
    derbies.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { className: "text-xs", style: rise(7), children: [
      model.sport.fixed.recordPlayed,
      ": ",
      dr.w,
      "W ",
      dr.d,
      "D ",
      dr.l,
      "L"
    ] }),
    bucket && /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: "text-xs text-muted-foreground", "data-review-bucket": true, children: model.sport.bucket(bucket) }),
    review.notes.map((n) => /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: "text-xs text-muted-foreground", children: n }, n)),
    (model.moments?.review ?? []).map((n) => /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { className: "text-xs", "data-review-moments": true, children: [
      "\u{1F3AF} ",
      n
    ] }, n)),
    review.trophies.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: "rounded-lg border border-amber-500/20 bg-amber-500/10 p-2 text-center text-amber-400", children: review.title ? /* @__PURE__ */ (0, import_jsx_runtime25.jsx)(VictoryMoment, { compact: true, children: /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("span", { className: "text-sm font-bold text-foreground", children: review.trophies.join(" \xB7 ") }) }) : /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("span", { className: "text-sm font-bold text-foreground", children: review.trophies.join(" \xB7 ") }) }),
    review.path && /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { className: "rounded-lg border border-border bg-card p-2", "data-playoff-path": true, children: [
      /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: "mb-1 text-xs font-black uppercase tracking-wider text-muted-foreground", children: review.path.head }),
      /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("ol", { className: "space-y-1", children: review.path.steps.map((st, i) => /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("li", { className: `${reduced ? "" : "cm-rise"} flex items-center gap-2 text-xs`, style: rise(8 + i), "data-playoff-round": st.won ? "W" : "L", children: [
        /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("span", { className: `shrink-0 rounded px-1.5 font-bold ${PILL2[st.won ? "W" : "L"]}`, children: st.won ? "W" : "L" }),
        /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("span", { className: "shrink-0 font-semibold", children: st.label }),
        /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("span", { className: "min-w-0 text-muted-foreground", children: st.text })
      ] }, st.label)) }),
      review.path.line && /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: "mt-1 text-[11px] text-muted-foreground", "data-playoff-line": true, children: review.path.line })
    ] })
  ] });
}
function SeasonCentre({ model, exitLabel, onClose }) {
  const s = model.season;
  const M = s.games.length;
  const reduced = useReducedMotion();
  const wide = useWide();
  const [stage, setStage] = (0, import_react16.useState)({ kind: "kickoff" });
  const [played, setPlayed] = (0, import_react16.useState)(0);
  const [speed, setSpeed] = (0, import_react16.useState)(1);
  const [paused, setPaused] = (0, import_react16.useState)(false);
  const [ft, setFt] = (0, import_react16.useState)(false);
  const [fixturesOpen, setFixturesOpen] = (0, import_react16.useState)(false);
  const [helpOpen, setHelpOpen] = useHelpOnce(model.helpKey);
  const copy = copyOf(model);
  const [postersSeen] = (0, import_react16.useState)(() => /* @__PURE__ */ new Set());
  const [hosting, setHosting] = (0, import_react16.useState)(null);
  const [passed, setPassed] = (0, import_react16.useState)([]);
  const moments = model.moments ?? null;
  const momentKeyOf = (m) => `${m.md}|${m.id}`;
  const openMoment = (md) => (moments?.list ?? []).find((m) => m.md === md && !m.taken && !passed.includes(momentKeyOf(m))) ?? null;
  (0, import_react16.useEffect)(() => {
    const body = document.body;
    const prev = { overflow: body.style.overflow, paddingRight: body.style.paddingRight };
    const bar = window.innerWidth - document.documentElement.clientWidth;
    if (bar > 0) body.style.paddingRight = `${(parseFloat(window.getComputedStyle(body).paddingRight) || 0) + bar}px`;
    body.style.overflow = "hidden";
    return () => {
      body.style.overflow = prev.overflow;
      body.style.paddingRight = prev.paddingRight;
    };
  }, []);
  const dialogRef = (0, import_react16.useRef)(null);
  const setDialog = (0, import_react16.useCallback)((el) => {
    dialogRef.current = el;
    focusDialogOnMount(el);
  }, []);
  const closeHelp = (0, import_react16.useCallback)(() => {
    setHelpOpen(false);
    dialogRef.current?.focus();
  }, [setHelpOpen]);
  const go = (0, import_react16.useCallback)((md) => {
    setFt(false);
    setHosting(null);
    setPaused(false);
    setFixturesOpen(false);
    if (postersFor(s, md).length > 0 && !postersSeen.has(md)) {
      postersSeen.add(md);
      setStage({ kind: "poster", md });
    } else setStage({ kind: "match", md });
  }, [s, postersSeen]);
  const toEnd = (0, import_react16.useCallback)(() => {
    setHosting(null);
    setPlayed(M);
    setFt(true);
    setStage({ kind: "review" });
  }, [M]);
  const bankRef = (0, import_react16.useRef)(moments?.bank);
  bankRef.current = moments?.bank;
  (0, import_react16.useEffect)(() => {
    if (stage.kind === "review") bankRef.current?.(true);
  }, [stage.kind]);
  const leave = (0, import_react16.useCallback)(() => {
    bankRef.current?.(false);
    onClose();
  }, [onClose]);
  const current = stage.kind === "match" || stage.kind === "poster" ? stage.md : null;
  const onFullTime = (0, import_react16.useCallback)(() => {
    if (current !== null) {
      setPlayed((p) => Math.max(p, current));
      setFt(true);
    }
  }, [current]);
  let nextBig = null;
  for (let md = played + 1; md <= M && nextBig === null; md += 1) if (postersFor(s, md).length || openMoment(md)) nextBig = md;
  if (nextBig !== null && nextBig <= played + 1) nextBig = null;
  const roundWord = s.mode === "results" ? "League game" : model.words.round;
  const so = soFar(s, played);
  const soTiles = model.sport.soFar(so);
  const btn = "h-10 shrink-0 whitespace-nowrap rounded-lg px-3 text-xs font-bold";
  const fixturesShown = fixturesOpen && hosting === null;
  const stageBody = (() => {
    if (stage.kind === "kickoff") return /* @__PURE__ */ (0, import_jsx_runtime25.jsx)(KickOff, { model, onKick: () => go(1), onStraight: toEnd });
    if (stage.kind === "review") return /* @__PURE__ */ (0, import_jsx_runtime25.jsx)(Review, { model, reduced });
    if (stage.kind === "poster") return /* @__PURE__ */ (0, import_jsx_runtime25.jsx)(Poster, { model, md: stage.md, reduced }, `p${stage.md}`);
    const g = s.games[stage.md - 1];
    const pending = openMoment(stage.md);
    const host = hosting !== null ? (moments?.list ?? []).find((m) => momentKeyOf(m) === hosting && m.md === stage.md) ?? null : null;
    const [hu, ht] = host ? scoreAt(g.events, host.minute - 1) : [0, 0];
    return /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { className: `${reduced ? "" : "cm-rise"} space-y-3`, "data-matchday": stage.md, children: [
      /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { className: "text-xs text-muted-foreground", children: [
        roundWord,
        " ",
        stage.md,
        s.mode === "table" ? ` of ${M}` : "",
        " \xB7 ",
        g.home ? "Home" : "Away",
        g.fixedKey ? ` \xB7 ${model.occasion[g.fixedKey] ?? model.sport.fixed.poster}` : ""
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: host ? "hidden" : void 0, children: /* @__PURE__ */ (0, import_jsx_runtime25.jsx)(
        MatchClock,
        {
          game: g,
          clock: model.sport.clock,
          usName: model.header.club,
          themName: model.names[g.opp],
          speed,
          paused,
          reduced,
          onFullTime,
          holdAt: host ? host.minute : pending ? pending.minute : null,
          onHold: () => {
            if (pending) setHosting(momentKeyOf(pending));
          }
        },
        `clock-${stage.md}`
      ) }),
      host && moments && /* @__PURE__ */ (0, import_jsx_runtime25.jsx)(
        MomentHost,
        {
          moment: host,
          moments,
          reduced,
          scoreLine: `${model.sport.clock.label(host.minute)} \xB7 ${g.home ? `${hu}-${ht}` : `${ht}-${hu}`}`,
          onDone: (took) => {
            if (!took) setPassed((p) => [...p, momentKeyOf(host)]);
            setHosting(null);
          }
        },
        hosting
      ),
      (ft || !g.played) && /* @__PURE__ */ (0, import_jsx_runtime25.jsx)(HisLine, { g, sport: model.sport })
    ] }, `m${stage.md}`);
  })();
  return /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: "fixed inset-0 z-50 flex items-stretch justify-center bg-background/80 backdrop-blur-sm md:items-center md:p-4", "data-season-centre": true, children: /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)(
    "div",
    {
      role: "dialog",
      "aria-modal": "true",
      "aria-label": model.words.title,
      tabIndex: -1,
      ref: setDialog,
      onKeyDown: escapeCloses(leave),
      className: "relative flex h-full w-full max-w-[1100px] flex-col overflow-hidden bg-background outline-none md:h-[min(860px,calc(100vh-2rem))] md:rounded-2xl md:border md:border-border",
      children: [
        /* @__PURE__ */ (0, import_jsx_runtime25.jsx)(CelebrationStyles, {}),
        /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { className: "flex items-center gap-2 border-b border-border px-3 py-2", children: [
          /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("span", { className: "text-sm font-black", children: [
            "\u{1F4FA} ",
            model.words.title
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("span", { className: "min-w-0 flex-1 truncate text-xs text-muted-foreground", children: [
            model.header.club,
            " \xB7 ",
            model.header.seasonLabel
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("button", { type: "button", onClick: () => setHelpOpen(true), className: "h-9 w-9 shrink-0 rounded-lg border border-border text-sm font-bold", "aria-label": model.help.title, children: "?" }),
          /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("button", { type: "button", onClick: leave, className: "h-9 shrink-0 rounded-lg border border-border px-3 text-xs font-semibold", "data-centre-exit": true, children: exitLabel })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { className: "grid min-h-0 flex-1 grid-cols-1 md:grid-cols-[240px_1fr_380px]", children: [
          /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("aside", { className: "hidden min-h-0 overflow-y-auto border-r border-border p-2 md:block", "aria-label": copy.list, children: /* @__PURE__ */ (0, import_jsx_runtime25.jsx)(FixtureList, { model, played, current, short: model.sport.clock.short }) }),
          /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("main", { className: "min-h-0 overflow-y-auto p-3 md:p-4", "data-centre-stage": true, children: [
            fixturesShown ? /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { className: "space-y-2", children: [
              /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("button", { type: "button", onClick: () => setFixturesOpen(false), className: "h-9 rounded-lg border border-border px-3 text-xs font-semibold", children: "\u2190 Back" }),
              /* @__PURE__ */ (0, import_jsx_runtime25.jsx)(FixtureList, { model, played, current })
            ] }) : stageBody,
            !fixturesShown && /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { className: "mt-4 space-y-3 md:hidden", children: [
              hosting === null && /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("button", { type: "button", onClick: () => setFixturesOpen(true), className: "h-10 w-full rounded-lg border border-border text-xs font-semibold", "data-centre-fixtures": true, children: [
                "\u{1F5D3} ",
                copy.list
              ] }),
              !wide && /* @__PURE__ */ (0, import_jsx_runtime25.jsx)(TablePanel, { model, played, compact: true }),
              !wide && s.mode === "record" && /* @__PURE__ */ (0, import_jsx_runtime25.jsx)(RecordPanel, { model, played, compact: true, reduced, tie: copy.tie, groups: model.groups, short: model.sport.clock.short })
            ] }),
            /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: "mt-3 grid grid-cols-4 gap-2 text-center md:hidden", "data-so-far": true, children: soTiles.map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { children: [
              /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: "text-sm font-black tabular-nums", children: value }),
              /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: "text-[9px] text-muted-foreground", children: label })
            ] }, label)) })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("aside", { className: "hidden min-h-0 overflow-y-auto border-l border-border p-2 md:block", "aria-label": copy.side, children: [
            s.mode === "table" ? wide && /* @__PURE__ */ (0, import_jsx_runtime25.jsx)(TablePanel, { model, played, compact: false }) : s.mode === "record" ? wide && /* @__PURE__ */ (0, import_jsx_runtime25.jsx)(RecordPanel, { model, played, compact: false, reduced, tie: copy.tie, groups: model.groups }) : /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("p", { className: "text-xs text-muted-foreground", children: model.resultsWhy }),
            /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { className: "mt-3 rounded-lg bg-muted/30 p-2 text-xs", "data-so-far-desktop": true, children: [
              /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: "mb-1 font-bold", children: copy.soFarHead }),
              soTiles.filter(([, value]) => value !== "-").map(([label, value]) => `${value} ${label.toLowerCase()}`).join(" \xB7 ")
            ] })
          ] })
        ] }),
        stage.kind !== "kickoff" && hosting === null && /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { className: "flex flex-wrap items-center gap-2 border-t border-border bg-card px-2 py-2", "data-centre-bar": true, children: [
          stage.kind === "poster" && /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("button", { type: "button", className: `${btn} flex-1 basis-full bg-emerald-600 text-black sm:basis-0`, onClick: () => setStage({ kind: "match", md: stage.md }), children: [
            "\u25B6 ",
            roundWord,
            " ",
            stage.md
          ] }),
          stage.kind === "match" && !ft && /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("button", { type: "button", className: `${btn} flex-1 basis-full border border-border sm:basis-0`, onClick: () => setPaused((p) => !p), children: paused ? "\u25B6 Resume" : "\u23F8 Pause" }),
          stage.kind === "match" && ft && stage.md < M && /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("button", { type: "button", className: `${btn} flex-1 basis-full bg-emerald-600 text-black sm:basis-0`, onClick: () => go(stage.md + 1), children: [
            "\u25B6 ",
            roundWord,
            " ",
            stage.md + 1
          ] }),
          stage.kind === "match" && ft && stage.md === M && /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("button", { type: "button", className: `${btn} flex-1 basis-full bg-emerald-600 text-black sm:basis-0`, onClick: () => setStage({ kind: "review" }), children: "\u{1F4CB} Season review" }),
          (stage.kind === "match" || stage.kind === "poster") && nextBig !== null && ft && /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("button", { type: "button", className: `${btn} border border-border`, onClick: () => {
            setPlayed(nextBig - 1);
            go(nextBig);
          }, children: "\u23E9 To the next big game" }),
          (stage.kind === "match" || stage.kind === "poster") && /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("button", { type: "button", className: `${btn} border border-border`, onClick: toEnd, children: "\u23ED Sim the rest" }),
          stage.kind !== "review" && /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: "ml-auto flex shrink-0 gap-1", role: "group", "aria-label": "Clock speed", children: [1, 3, "results"].map((v) => /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("button", { type: "button", "aria-pressed": speed === v, onClick: () => setSpeed(v), className: `${btn} px-2 ${speed === v ? "bg-primary text-primary-foreground" : "border border-border"}`, children: v === "results" ? "Results" : `${v}x` }, String(v))) }),
          stage.kind === "review" && /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("button", { type: "button", className: `${btn} flex-1 basis-full bg-emerald-600 text-black sm:basis-0`, onClick: leave, children: exitLabel })
        ] }),
        helpOpen && /* @__PURE__ */ (0, import_jsx_runtime25.jsx)(SeasonCentreHelp, { words: model.help, onClose: closeHelp })
      ]
    }
  ) });
}

// src/components/soccer-career/SoccerSeasonCentre.tsx
init_clubManagerClock();
var import_jsx_runtime26 = __toESM(require_jsx_runtime(), 1);
var HELP = {
  title: "How the Season Centre works",
  intro: [
    "Your season was played the moment you pressed Next Season. This is that same season, match by match: the final table and your season totals are settled, and nothing here can change them.",
    "When a season shows a table, who was in the league, how many clubs it had and how many points a win was worth are real (from 2026-27 on, the league is your career's own world). Every score, every other club's result and every minute are your career's own.",
    "Own goals are fictional details of goals already in your season. You, a teammate or an opponent can cause one; (O.G) marks it without adding to your goals or assists."
  ],
  controls: "\u25B6 plays the next matchday. \u23E9 jumps to the next big game (a derby, halfway, the title or the final day). \u23ED goes straight to the end. 1x and 3x set the clock, Results shows each match at full time.",
  moments: [
    "Up to three moments a season are yours to play, marked \u{1F3AF} on the fixtures of the season you just played. The clock stops a beat before one. \u{1F3AF} Take it yourself plays it on your training ground board, one go. \u25B6 Let it play leaves the match as it was. Once the board opens the go is used, so closing the tab counts as a miss.",
    "YOUR CALL: what you do is what happened in that match. Score a chance that was missed and the goal is yours; miss one that went in and it is gone. The return game against the same club takes the other side of it, so the final table and your season totals end exactly where your season summary has them.",
    "RECREATE: the record stands whatever you do. You play a goal, an assist or a clean sheet again, for stars only.",
    "A make earns one to three stars for how well you struck it. The stars bank once a season, at the season review: 60% of the stars on offer is +1 to the stat your position trains, 85% is +2, never past your ceiling (your training drill and your moments share that room), and it arrives with next season's growth. Step out before the review and your moments stay open while your season summary is up. Press Continue on the summary and the stars you have bank as they stand, with any moment you left counting as no stars. After the bank the season's moments are closed."
  ],
  examples: [
    { head: "An own goal", body: "You turn the ball into your own net at 55 minutes. The opposition get the goal, marked (O.G), and your goals and assists stay the same. The final score and your season totals still match the season summary." },
    { head: "A YOUR CALL", body: "Matchday 9, 1-1 in the 82nd minute, and on your season this chance was missed. You take it and score: the match ends 2-1 and you climb the table that week. In the return game on matchday 28, a 2-1 win on your season, your goal there is not scored and it ends 1-1. You gain two points on matchday 9 and give two back on matchday 28, they lose one and get it back: the final table and your goals for the season end exactly where they were." },
    { head: "A RECREATE", body: "Derby day, and on the record you scored in the 74th minute. You play it again on the Wall Shot: through the gap and into the top corner is three stars, a miss is none. Either way the derby ends as it did. Three moments worth 3, 2 and 1 stars are 6 of 9, which is 67%: +1 next season." },
    { head: "A matchday", body: "Matchday 12: you win 2-1 at home and score in the 67th minute, rated 7.6. The table moves you from 6th to 4th (\u25B22)." },
    { head: "An injury", body: "Out for five weeks with a hamstring in a 38 game season: five weeks out of a 46 week year is four matchdays, so the club plays matchdays 14 to 17 without you. Your games played do not move. The table does." },
    { head: "Results only", body: "A season the game has no verified table for (before 1995-96, a league outside the big five, or a season cut short) shows your league games with no table. If your season summary has a finish, the review still prints it." }
  ],
  footnote: `Cup ties and European nights count in your totals as "Cups and other games" but are not shown match by match yet. Clubs level on points are split by goal difference, then goals scored: this game's rule.`
};
var exitLabelOf = (mode, phase) => mode === "live" && phase === "newspaper" ? "Back to the papers" : "Back to your career";
function eventWords(e, us, them) {
  if (e.kind === "goal" && e.ownGoalBy) {
    const who = e.ownGoalBy === "you" ? "You" : e.ownGoalBy === "teammate" ? "A teammate" : "An opponent";
    return `\u26BD ${who} (O.G), goal for ${e.side === "us" ? us : them}`;
  }
  if (e.kind === "goal") return e.side === "us" ? e.mine ? "\u26BD You score!" : `\u26BD Goal, ${us}` : `\u26BD Goal, ${them}`;
  if (e.kind === "assist") return "\u{1F170}\uFE0F You set it up";
  if (e.kind === "yellow") return "\u{1F7E8} You go in the book";
  if (e.kind === "red") return "\u{1F7E5} Sent off";
  if (e.kind === "injury") return "\u{1F691} You go off injured";
  if (e.kind === "on") return "\u{1F501} You come on";
  return "\u{1F501} You come off";
}
function soccerSport(keepsSheets) {
  return {
    clock: { length: SOCCER_FULL_TIME, label: (minute) => minuteLabel({ minute }), words: eventWords },
    fixed: { badge: "DERBY", poster: "Derby day", recordSoFar: "Your derby record so far", recordPlayed: "Derbies you played" },
    missed: (why) => why === "injured" ? "Not in the squad: injured" : why === "suspended" ? "Suspended" : "Not in the matchday squad",
    lineOf: (g) => {
      const bits = [];
      if ((g.line.goals ?? 0) > 0) bits.push(`\u26BD ${g.line.goals}`);
      if ((g.line.assists ?? 0) > 0) bits.push(`\u{1F170}\uFE0F ${g.line.assists}`);
      if (keepsSheets && g.them === 0) bits.push("\u{1F9E4} Clean sheet");
      if ((g.line.yellow ?? 0) > 0) bits.push("\u{1F7E8}");
      if ((g.line.red ?? 0) > 0) bits.push("\u{1F7E5} Sent off");
      if (g.onAt) bits.push(`Came on ${g.onAt}'`);
      return { bits, alarm: g.events.some((e) => e.kind === "injury") ? "\u{1F691} Injured" : null };
    },
    markOf: (g) => g.line.rating ?? 0,
    soFar: (so) => [
      ["Played", String(so.apps)],
      ["Goals", String(so.goals ?? 0)],
      ["Assists", String(so.assists ?? 0)],
      ["Rating", so.apps ? ((so.rating ?? 0) / so.apps).toFixed(1) : "-"]
    ],
    half: (so) => `First half: ${so.apps} games, ${so.goals ?? 0} goals, ${so.assists ?? 0} assists`,
    bucket: (b) => `Cups and other games: ${b.apps} apps, ${b.line.goals ?? 0} goals, ${b.line.assists ?? 0} assists`
  };
}
var RESULTS_WORDS = "Results only: the game does not have a verified table for this league that season.";
function buildModel(row, ctx, s, moments) {
  const occasion = {};
  for (const d of readSeasonDerbies(row)) occasion[d.rival] = d.name;
  const finish = ctx.finish;
  const leagueName = ctx.league?.name ?? null;
  const pts = s.mode === "table" ? tableAt(s, s.games.length).find((r2) => r2.slot === 0)?.pts ?? null : null;
  const finishLine = finish ? finish.finish === 1 ? `Champions${leagueName ? ` of ${leagueWithArticle(leagueName)}` : ""}${finish.size ? `, top of ${finish.size}` : ""}${pts !== null ? ` \xB7 ${pts} pts` : ""}` : `Finished ${ordinal(finish.finish)}${finish.size ? ` of ${finish.size}` : ""}${leagueName ? ` in ${leagueWithArticle(leagueName)}` : ""}${pts !== null ? ` \xB7 ${pts} pts` : ""}` : row.injurySevere ? "Your season ended early with an injury." : null;
  const trophies = [row.leagueTitle && "\u{1F3C6} League", row.domesticCup && "\u{1F3C6} Cup", row.championsLeague && "\u2B50 UCL", row.clubCupTitle && `\u2B50 ${row.clubCupTitle}`, row.worldCup && "\u{1F30D} World Cup", row.continentalCup && "\u{1F310} Continental", row.ballonDor && "\u{1F3C5} Ballon d'Or"].filter((t) => !!t);
  const notes = [];
  if (ctx.goldenBoot) notes.push(`\u{1F45F} League Golden Boot: ${row.goals} goals in all competitions.`);
  if (ctx.keepsSheets && ctx.position !== "GK") notes.push(`\u{1F9E4} ${row.cleanSheets} clean sheets in all competitions.`);
  const last = ctx.lastSeason;
  return {
    season: s,
    words: SOCCER.words,
    names: s.labels.map((l) => l.named ? l.name : SOCCER.words.unnamed),
    occasion,
    header: { club: row.club, seasonLabel: `${row.year}/${String(row.year + 1).slice(-2)}`, league: leagueName, loanFrom: row.onLoanFrom ?? null },
    frameLine: s.mode === "table" ? `${s.teams} clubs \xB7 ${s.games.length} matchdays \xB7 3 points for a win` : null,
    lastSeason: last ? last.finish === 1 ? `Last season: champions with ${last.club}` : `Last season: ${ordinal(last.finish)} with ${last.club}` : null,
    resultsWhy: s.mode === "table" ? null : ctx.why === "severe" ? "Results only: your season was cut short, so there is no final table." : RESULTS_WORDS,
    derbyBefore: { w: ctx.derbyBefore.w, d: ctx.derbyBefore.d, l: ctx.derbyBefore.l },
    review: {
      tiles: [
        ["Apps", String(row.apps)],
        ctx.position === "GK" ? ["Clean sheets", String(row.cleanSheets)] : ["Goals", String(row.goals)],
        ["Assists", String(row.assists)],
        ["Avg rating", row.rating.toFixed(1)]
      ],
      finishLine,
      championLine: ctx.champion ? `${ctx.champion} won it` : null,
      trophies,
      title: !!row.leagueTitle && !row.injurySevere,
      notes
    },
    sport: soccerSport(ctx.keepsSheets),
    help: HELP,
    momentKey: `centre|${s.key}`,
    moments
  };
}
var CentreBoundary = class extends import_react17.Component {
  state = { failed: false, tries: 0 };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  render() {
    if (!this.state.failed) return /* @__PURE__ */ (0, import_jsx_runtime26.jsx)("div", { className: "contents", children: this.props.children }, this.state.tries);
    return /* @__PURE__ */ (0, import_jsx_runtime26.jsx)(
      Tile,
      {
        text: "Something went wrong drawing this season. Your career is safe.",
        exitLabel: this.props.exitLabel,
        onClose: this.props.onClose,
        onRetry: () => this.setState((s) => ({ failed: false, tries: s.tries + 1 }))
      }
    );
  }
};
function Tile({ text, exitLabel, onClose, onRetry }) {
  return /* @__PURE__ */ (0, import_jsx_runtime26.jsx)("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-background/80 p-4 backdrop-blur-sm", "data-season-centre": true, "data-centre-tile": true, children: /* @__PURE__ */ (0, import_jsx_runtime26.jsxs)("div", { role: "dialog", "aria-modal": "true", "aria-label": "Season Centre", tabIndex: -1, ref: focusDialogOnMount, onKeyDown: escapeCloses(onClose), className: "w-full max-w-sm space-y-3 rounded-2xl border border-border bg-card p-4 text-center outline-none", children: [
    /* @__PURE__ */ (0, import_jsx_runtime26.jsx)("div", { className: "text-sm font-bold", children: "\u{1F4FA} Season Centre" }),
    /* @__PURE__ */ (0, import_jsx_runtime26.jsx)("p", { className: "text-sm text-muted-foreground", children: text }),
    /* @__PURE__ */ (0, import_jsx_runtime26.jsxs)("div", { className: "flex gap-2", children: [
      onRetry && /* @__PURE__ */ (0, import_jsx_runtime26.jsx)("button", { type: "button", onClick: onRetry, className: "h-10 flex-1 rounded-lg border border-border text-sm font-semibold", children: "\u21BB Retry" }),
      /* @__PURE__ */ (0, import_jsx_runtime26.jsx)("button", { type: "button", onClick: onClose, className: "h-10 flex-1 rounded-lg bg-primary text-sm font-bold text-primary-foreground", children: exitLabel })
    ] })
  ] }) });
}
function CentreBody({ career, clubs, row, mode, onClose, onCareer }) {
  const exitLabel = exitLabelOf(mode, career.phase);
  const ctx = (0, import_react17.useMemo)(() => buildSoccerSeasonCtx(career, clubs, row), [career.playerName, career.position, career.phone, career.awards, career.seasons, clubs, row]);
  const key = SOCCER.seasonKey(row, ctx);
  const plan = (0, import_react17.useMemo)(() => key ? deriveSeason(SOCCER, row, ctx) : null, [key, row, ctx]);
  const latest = career.seasons[career.seasons.length - 1];
  const canPlay = !!onCareer && !!plan && !!key && !!latest && soccerSeasonKey(career.playerName, latest) === key;
  const planned = (0, import_react17.useMemo)(() => plan ? planMoments(SOCCER, row, ctx, plan) : [], [plan, row, ctx]);
  const offered = (0, import_react17.useMemo)(() => canPlay ? planned : [], [canPlay, planned]);
  const ledger = readSeasonMoments(career.seasonMoments);
  const entriesKey = JSON.stringify(ledgerOf(ledger, key ?? ""));
  const decided = (0, import_react17.useMemo)(() => plan && offered.length ? applyDecisions(SOCCER, row, ctx, plan, offered, JSON.parse(entriesKey)) : plan, [plan, offered, entriesKey, row, ctx]);
  const season = (0, import_react17.useMemo)(() => decided ? soccerOwnGoals(decided, planned) : null, [decided, planned]);
  const moments = useSoccerMoments({ career, row, ctx, plan, key, offered, entriesKey, banked: !!ledger?.banked && ledger.key === key, onCareer });
  const model = (0, import_react17.useMemo)(() => season ? buildModel(row, ctx, season, moments) : null, [season, row, ctx, moments]);
  if (!model) return /* @__PURE__ */ (0, import_jsx_runtime26.jsx)(Tile, { text: "This season cannot be shown match by match.", exitLabel, onClose });
  return /* @__PURE__ */ (0, import_jsx_runtime26.jsx)(SeasonCentre, { model, exitLabel, onClose });
}
function SoccerSeasonCentre(props) {
  return /* @__PURE__ */ (0, import_jsx_runtime26.jsx)(CentreBoundary, { onClose: props.onClose, exitLabel: exitLabelOf(props.mode, props.career.phase), children: /* @__PURE__ */ (0, import_jsx_runtime26.jsx)(CentreBody, { ...props }) });
}

// ../../_temp/own-goals-1167.sj5mbQ/viewer-candidate/entry.tsx
var import_jsx_runtime27 = __toESM(require_jsx_runtime());
var fixture = await (await fetch("./fixture.json")).json();
window.__ogInitial = JSON.stringify(fixture);
window.__ogFixture = fixture;
window.__ogClose = 0;
(0, import_client.createRoot)(document.getElementById("root")).render(/* @__PURE__ */ (0, import_jsx_runtime27.jsx)(SoccerSeasonCentre, { career: fixture.career, clubs: fixture.clubs, row: fixture.row, mode: "watch", onClose: () => window.__ogClose++ }));
/*! Bundled license information:

react/cjs/react.production.min.js:
  (**
   * @license React
   * react.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

scheduler/cjs/scheduler.production.min.js:
  (**
   * @license React
   * scheduler.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

react-dom/cjs/react-dom.production.min.js:
  (**
   * @license React
   * react-dom.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

react/cjs/react-jsx-runtime.production.min.js:
  (**
   * @license React
   * react-jsx-runtime.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

lucide-react/dist/esm/shared/src/utils.js:
  (**
   * @license lucide-react v0.462.0 - ISC
   *
   * This source code is licensed under the ISC license.
   * See the LICENSE file in the root directory of this source tree.
   *)

lucide-react/dist/esm/defaultAttributes.js:
  (**
   * @license lucide-react v0.462.0 - ISC
   *
   * This source code is licensed under the ISC license.
   * See the LICENSE file in the root directory of this source tree.
   *)

lucide-react/dist/esm/Icon.js:
  (**
   * @license lucide-react v0.462.0 - ISC
   *
   * This source code is licensed under the ISC license.
   * See the LICENSE file in the root directory of this source tree.
   *)

lucide-react/dist/esm/createLucideIcon.js:
  (**
   * @license lucide-react v0.462.0 - ISC
   *
   * This source code is licensed under the ISC license.
   * See the LICENSE file in the root directory of this source tree.
   *)

lucide-react/dist/esm/icons/calendar-days.js:
  (**
   * @license lucide-react v0.462.0 - ISC
   *
   * This source code is licensed under the ISC license.
   * See the LICENSE file in the root directory of this source tree.
   *)

lucide-react/dist/esm/icons/infinity.js:
  (**
   * @license lucide-react v0.462.0 - ISC
   *
   * This source code is licensed under the ISC license.
   * See the LICENSE file in the root directory of this source tree.
   *)

lucide-react/dist/esm/icons/rotate-ccw.js:
  (**
   * @license lucide-react v0.462.0 - ISC
   *
   * This source code is licensed under the ISC license.
   * See the LICENSE file in the root directory of this source tree.
   *)

lucide-react/dist/esm/icons/x.js:
  (**
   * @license lucide-react v0.462.0 - ISC
   *
   * This source code is licensed under the ISC license.
   * See the LICENSE file in the root directory of this source tree.
   *)

lucide-react/dist/esm/lucide-react.js:
  (**
   * @license lucide-react v0.462.0 - ISC
   *
   * This source code is licensed under the ISC license.
   * See the LICENSE file in the root directory of this source tree.
   *)
*/
//# sourceMappingURL=candidate-bundle.js.map
