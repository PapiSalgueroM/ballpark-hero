import React from 'react';
import {createRoot} from 'react-dom/client';
import {AcademyScreen} from "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/AcademyScreen.tsx";
import {promoteProspect,releaseProspect} from "/home/runner/work/ballpark-hero/ballpark-hero/src/lib/clubManager.ts";
export function mount(fixture){
 let current=JSON.parse(JSON.stringify(fixture)), calls=[];
 const view=createRoot(document.getElementById('fixture-root'));
 function render(){view.render(<div>
  <button type="button" data-sentinel="before">Before academy</button>
  <section data-academy-board><AcademyScreen career={current} onUpgrade={kind=>calls.push({action:'unexpected-upgrade',id:kind})} onHire={id=>calls.push({action:'unexpected-hire',id})} onRecall={id=>calls.push({action:'unexpected-recall',id})} onPromote={id=>{calls.push({action:'sign',id});const next=promoteProspect(current,id);if(next){current=next;render();}}} onRelease={id=>{calls.push({action:'release',id});current=releaseProspect(current,id);render();}}/></section>
  <button type="button" data-sentinel="after">After academy</button><output id="callback-output" hidden>{JSON.stringify(calls)}</output>
 </div>);}
 window.__academy1162={snapshot:()=>({career:JSON.parse(JSON.stringify(current)),calls:JSON.parse(JSON.stringify(calls))})};
 render();
}