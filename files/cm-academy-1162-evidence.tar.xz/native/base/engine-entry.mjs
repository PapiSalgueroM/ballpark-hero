globalThis.localStorage={getItem:()=>null,setItem:()=>{},removeItem:()=>{}};
export const engine=await import("/home/runner/work/_temp/academy-1162.pTCxGz/base-root/src/lib/clubManager.ts");