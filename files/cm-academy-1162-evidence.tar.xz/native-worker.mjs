import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';

const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const save = (file, value) => fs.writeFileSync(file, JSON.stringify(value, null, 2));
const fontSheet = 'https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap';
const fontDir = path.join(process.env.E, 'font-cache');
const fontAgent = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36';
const fontUrls = css => [...new Set([...css.matchAll(/url\(['"]?(https:\/\/fonts\.gstatic\.com\/[^)'"\s]+)['"]?\)/g)].map(match => match[1]))];
export function assertTransport(row) {
  assert.deepEqual(row.blocked, [], 'No external HTTP attempts');
  assert.deepEqual(row.sockets, [], 'No WebSocket attempts');
}
function isEntry() {
  return process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url;
}

export function validateFontCss(css) {
  const clean = css.replace(/\/\*[\s\S]*?\*\//g, ''), faces = [], groups = new Set();
  for (const match of clean.matchAll(/@font-face\s*\{([^}]+)\}/g)) {
    const body = match[1], family = body.match(/\bfont-family:\s*(['"])([^'"]+)\1\s*;/)?.[2];
    const weight = body.match(/\bfont-weight:\s*([0-9]+)\s*;/)?.[1];
    assert(['Inter', 'Space Grotesk'].includes(family), 'Only declared font families');
    assert(['400', '500', '600', '700'].includes(weight), 'Only requested font weights');
    assert(/\bfont-style:\s*normal\s*;/.test(body), 'Declared font faces have normal style');
    const source = body.match(/\bsrc:\s*url\((['"]?)([^)'"\s]+)\1\)\s*format\((['"])woff2\3\)\s*;/);
    assert(source, 'Every declared face uses a concrete woff2 source');
    const url = source[2];
    assert(url.startsWith('https://fonts.gstatic.com/'), 'Declared font URL stays on exact HTTPS origin');
    assert.equal(new URL(url).origin, 'https://fonts.gstatic.com', 'Declared font URL stays on exact HTTPS origin');
    faces.push({ family, weight: Number(weight), url }); groups.add(family + '/' + weight);
  }
  const requested = ['Inter/400', 'Inter/500', 'Inter/600', 'Inter/700', 'Space Grotesk/400', 'Space Grotesk/500', 'Space Grotesk/600', 'Space Grotesk/700'];
  assert.deepEqual([...groups].sort(), requested, 'Every requested normal family and weight is declared');
  const urls = [...new Set(faces.map(face => face.url))];
  assert(urls.length > 1);
  const allUrls = [...new Set([...clean.matchAll(/url\((['"]?)([^)'"\s]+)\1\)/g)].map(match => match[2]))];
  assert.deepEqual(allUrls, urls, 'Every CSS URL is a validated declared woff2 face');
  return { faces, urls };
}
async function prepareFonts() {
  assert.equal(process.env.GITHUB_ACTIONS, 'true', 'Remote-only font preparation');
  const template = fs.readFileSync('index.html', 'utf8');
  assert.equal([...template.matchAll(/<link\b[^>]*>/g)].filter(tag => /\brel=["']stylesheet["']/.test(tag[0]) && tag[0].includes(fontSheet)).length, 1, 'Exact declared template font stylesheet');
  fs.mkdirSync(fontDir, { recursive: true });
  const entries = [];
  let declared;
  save(path.join(fontDir, 'partial-manifest.json'), { executionComplete: false, fontSheet, fontAgent, entries });
  const fetchAsset = async url => {
    assert(url === fontSheet || declared?.urls.includes(url), 'Only exact actual declared font assets');
    const response = await fetch(url, { headers: { 'User-Agent': fontAgent }, signal: AbortSignal.timeout(20000), redirect: 'error' });
    assert.equal(response.status, 200, 'Actual font asset ' + url);
    const bytes = Buffer.from(await response.arrayBuffer()), file = hash(Buffer.from(url));
    assert(bytes.length > 0); fs.writeFileSync(path.join(fontDir, file), bytes);
    entries.push({ url, file, bytes: bytes.length, sha256: hash(bytes), contentType: response.headers.get('content-type'), status: response.status });
    save(path.join(fontDir, 'partial-manifest.json'), { executionComplete: false, fontSheet, fontAgent, entries });
    return bytes;
  };
  const original = (await fetchAsset(fontSheet)).toString('utf8'); declared = validateFontCss(original);
  const controls = [], mutations = [
    { name: 'origin', from: declared.urls[0], to: declared.urls[0].replace('https://fonts.gstatic.com/', 'https://invalid.example/'), message: 'Declared font URL stays on exact HTTPS origin' },
    { name: 'family', from: "font-family: 'Inter';", to: "font-family: 'Unlisted Font';", message: 'Only declared font families' },
    { name: 'missing-weight', from: 'font-weight: 700;', to: 'font-weight: 600;', message: 'Every requested normal family and weight is declared' },
    { name: 'normal-style', from: 'font-style: normal;', to: 'font-style: italic;', message: 'Declared font faces have normal style' },
    { name: 'woff2-format', from: "format('woff2')", to: "format('truetype')", message: 'Every declared face uses a concrete woff2 source' },
    { name: 'weight-whitelist', from: 'font-weight: 700;', to: 'font-weight: 800;', message: 'Only requested font weights' },
    { name: 'undeclared-url', from: original, to: original + "\n.undeclared-control{background-image:url('https://fonts.gstatic.com/undeclared-control.woff2')}\n", message: 'Every CSS URL is a validated declared woff2 face' },
  ];
  fs.writeFileSync(path.join(fontDir, 'controls-baseline.css'), original);
  for (const mutation of mutations) {
    assert(original.includes(mutation.from)); assert.notEqual(mutation.from, mutation.to); assert(!original.includes(mutation.to) || mutation.name === 'missing-weight');
    const controlled = original.replaceAll(mutation.from, mutation.to); assert.notEqual(controlled, original, 'Copied actual CSS mutation is effective');
    const file = 'control-' + mutation.name + '.css'; fs.writeFileSync(path.join(fontDir, file), controlled);
    let error; try { validateFontCss(controlled); } catch (caught) { error = caught; }
    assert(error instanceof assert.AssertionError); assert(error.message.startsWith(mutation.message));
    controls.push({ ...mutation, file, sha256: hash(Buffer.from(controlled)), bytes: Buffer.byteLength(controlled), intendedFailure: { name: error.name, message: error.message, actual: error.actual, expected: error.expected, operator: error.operator } });
    save(path.join(fontDir, 'controls-partial.json'), { executionComplete: false, baselineSha256: hash(Buffer.from(original)), controls });
  }
  save(path.join(fontDir, 'controls.json'), { baselineFile: 'controls-baseline.css', baselineSha256: hash(Buffer.from(original)), baselineBytes: Buffer.byteLength(original), declared, controls, scope: 'Copied actual CSS validation only, no bad URL is fetched' });
  for (const url of declared.urls) await fetchAsset(url);
  let local = original;
  for (const entry of entries.slice(1)) local = local.replaceAll(entry.url, '/held-fonts/' + entry.file);
  assert.equal(fontUrls(local).length, 0); fs.writeFileSync(path.join(fontDir, 'local.css'), local);
  save(path.join(fontDir, 'manifest.json'), { fontSheet, fontAgent, templateSha256: hash(Buffer.from(template)), entries, declared, originalSha256: hash(Buffer.from(original)), localSha256: hash(Buffer.from(local)), localBytes: Buffer.byteLength(local) });
  console.log('Fonts1162 PASS: actual template CSS and all referenced declared-family woff2 bodies retained and mapped to local serving.');
}

async function main() {
  assert.equal(process.env.GITHUB_ACTIONS, 'true', 'Remote-only worker');
  const root = process.cwd(), out = path.join(process.env.E, 'native');
  fs.mkdirSync(out, { recursive: true });
  const browserTemp = path.join(process.env.WORK, 't');
  fs.mkdirSync(browserTemp, { recursive: true });
  for (const name of ['TMPDIR', 'TEMP', 'TMP']) process.env[name] = browserTemp;
  const require = createRequire(path.join(root, 'package.json'));
  const { chromium } = require('playwright'), { build } = require('esbuild');
  const epoch = Date.UTC(2026, 0, 1, 12);
  const core = ['src/components/club-manager/AcademyScreen.tsx', 'src/lib/clubManager.ts', 'src/lib/utils.ts', 'src/hooks/useRevealScroll.ts', 'src/components/club-manager/deskCue.tsx', 'src/components/club-manager/CelebrationStyles.tsx'];
  const clone = value => JSON.parse(JSON.stringify(value));
  let inverse=fs.readFileSync(path.join(root,core[0]),'utf8');
  for(const from of ['            aria-label={`Sign him: ${p.name}`}\n','            aria-label={`Let go: ${p.name}`}\n']){
    assert.equal(inverse.split(from).length,2,'Unique reviewed Academy action inverse');inverse=inverse.replace(from,'');
  }
  assert.equal(inverse,fs.readFileSync(path.join(process.env.BASE_ROOT,core[0]),'utf8'),'Exact untouched parent Academy component');
  for(const source of core.slice(1))assert.equal(hash(fs.readFileSync(path.join(root,source))),hash(fs.readFileSync(path.join(process.env.BASE_ROOT,source))),'Held actual core: '+source);
  const fonts = JSON.parse(fs.readFileSync(path.join(fontDir, 'manifest.json')));
  assert.equal(fonts.fontSheet, fontSheet); assert.equal(fonts.fontAgent, fontAgent);
  assert.equal(fonts.templateSha256, hash(fs.readFileSync(path.join(root, 'index.html'))));
  const originalFontCss = fs.readFileSync(path.join(fontDir, fonts.entries[0].file), 'utf8'), declared = validateFontCss(originalFontCss);
  assert.deepEqual(fonts.declared, declared);
  const fontAssets = new Map();
  for (const entry of fonts.entries) {
    const file = path.join(fontDir, entry.file), bytes = fs.readFileSync(file);
    assert.equal(bytes.length, entry.bytes); assert.equal(hash(bytes), entry.sha256); assert.equal(entry.status, 200);
    assert.equal(entry.file, hash(Buffer.from(entry.url)));
    assert(entry.url === fontSheet || declared.urls.includes(entry.url));
    if (entry.url !== fontSheet) fontAssets.set('/held-fonts/' + entry.file, { file, type: entry.contentType });
  }
  assert.equal(fonts.entries[0].url, fontSheet);
  assert.deepEqual(declared.urls, fonts.entries.slice(1).map(entry => entry.url));
  let localFontCss = originalFontCss;
  for (const entry of fonts.entries.slice(1)) localFontCss = localFontCss.replaceAll(entry.url, '/held-fonts/' + entry.file);
  assert.equal(localFontCss, fs.readFileSync(path.join(fontDir, 'local.css'), 'utf8'));
  assert.equal(hash(Buffer.from(originalFontCss)), fonts.originalSha256);
  assert.equal(hash(Buffer.from(localFontCss)), fonts.localSha256); assert.equal(Buffer.byteLength(localFontCss), fonts.localBytes);
  fontAssets.set('/held-fonts.css', { file: path.join(fontDir, 'local.css'), type: 'text/css' });
  const viteBindings = [], viteSeen = new Set(), viteDir = path.join(out, 'vite-core');
  fs.mkdirSync(viteDir, { recursive: true });
  for (const name of fs.readdirSync(path.join(root, 'dist/assets')).filter(name => name.endsWith('.js.map'))) {
    const file = path.join(root, 'dist/assets', name), bytes = fs.readFileSync(file), map = JSON.parse(bytes), matches = [];
    assert(Array.isArray(map.sources) && map.sources.length === map.sourcesContent.length);
    for (let i = 0; i < map.sources.length; i++) for (const source of core) {
      const normalized = map.sources[i].replaceAll('\\', '/');
      if (normalized !== source && !normalized.endsWith('/' + source)) continue;
      assert.equal(typeof map.sourcesContent[i], 'string');
      const sourceHash = hash(Buffer.from(map.sourcesContent[i])); assert.equal(sourceHash, hash(fs.readFileSync(path.join(root, source))));
      viteSeen.add(source); matches.push({ source, index: i, sha256: sourceHash });
    }
    if (matches.length) {
      const js = file.slice(0, -4), body = fs.readFileSync(js);
      fs.writeFileSync(path.join(viteDir, name), bytes); fs.writeFileSync(path.join(viteDir, path.basename(js)), body);
      viteBindings.push({ map: name, mapSha256: hash(bytes), js: path.basename(js), jsSha256: hash(body), matches });
    }
  }
  assert.deepEqual([...viteSeen].sort(), [...core].sort()); save(path.join(out, 'vite-bindings.json'), viteBindings);
  const servers = [], variants = [], results = [];
  save(path.join(out, 'partial-summary.json'), { executionComplete: false, results });
  const executable = chromium.executablePath();
  assert(executable.startsWith(process.env.PLAYWRIGHT_BROWSERS_PATH + path.sep));
  const runtime = { executablePath: executable, executableSha256: hash(fs.readFileSync(executable)), privateCache: process.env.PLAYWRIGHT_BROWSERS_PATH, temp: { directory: browserTemp, TMPDIR: process.env.TMPDIR, TEMP: process.env.TEMP, TMP: process.env.TMP } };
  save(path.join(out, 'browser-runtime.json'), runtime);
  const browser = await chromium.launch({ headless: true, executablePath: executable });
  save(path.join(out, 'browser-runtime.json'), { ...runtime, version: browser.version() });
  try {
    for (const [variant, sourceRoot] of [['candidate', root], ['base', process.env.BASE_ROOT]]) {
      const variantOut = path.join(out, variant), browserDir = path.join(variantOut, 'browser');
      fs.mkdirSync(browserDir, { recursive: true });
      const engineEntry = `globalThis.localStorage={getItem:()=>null,setItem:()=>{},removeItem:()=>{}};
export const engine=await import(${JSON.stringify(sourceRoot + '/src/lib/clubManager.ts')});`;
      const clientEntry = `import React from 'react';
import {createRoot} from 'react-dom/client';
import {AcademyScreen} from ${JSON.stringify(sourceRoot + '/src/components/club-manager/AcademyScreen.tsx')};
import {promoteProspect,releaseProspect} from ${JSON.stringify(sourceRoot + '/src/lib/clubManager.ts')};
export function mount(fixture){
 let current=JSON.parse(JSON.stringify(fixture)), calls=[];
 const view=createRoot(document.getElementById('fixture-root'));
 function render(){view.render(<div>
  <button type="button" data-sentinel="before">Before academy</button>
  <section data-academy-board><AcademyScreen career={current} onUpgrade={kind=>calls.push({action:'unexpected-upgrade',id:kind})} onHire={id=>calls.push({action:'unexpected-hire',id})} onRecall={id=>calls.push({action:'unexpected-recall',id})} onPromote={id=>{calls.push({action:'sign',id});const next=promoteProspect(current,id);if(next){current=next;render();}}} onRelease={id=>{calls.push({action:'release',id});current=releaseProspect(current,id);render();}}/></section>
  <button type="button" data-sentinel="after">After academy</button><output id="callback-output" hidden>{JSON.stringify(calls)}</output>
 </div>);}
 window.__academy1162={snapshot:()=>({career:JSON.parse(JSON.stringify(current)),calls:JSON.parse(JSON.stringify(calls))})};
 render();
}`;
      const bindBuild = (result, outfile, virtualName, virtualBytes, requiredCore) => {
        const metadata = result.metafile, mapPath = outfile + '.map';
        save(outfile + '.metafile.json', metadata);
        const nodeRoot = fs.realpathSync(path.join(root, 'node_modules')) + path.sep;
        const inputRows = Object.entries(metadata.inputs).map(([input, info]) => {
          const resolved = path.resolve(sourceRoot, input);
          const virtual = !fs.existsSync(resolved) && resolved === path.resolve(sourceRoot, virtualName);
          assert(virtual || fs.statSync(resolved).isFile(), 'Actual regular bundle input: ' + input);
          const file = virtual ? resolved : fs.realpathSync(resolved);
          const bytes = virtual ? Buffer.from(virtualBytes) : fs.readFileSync(file);
          assert.equal(info.bytes, bytes.length, 'Actual input bytes: ' + input);
          return { input, file, virtual, bytes: bytes.length, sha256: hash(bytes) };
        });
        assert.equal(inputRows.filter(row => row.virtual).length, 1, 'Only the exact retained stdin entry is virtual');
        save(outfile + '.inputs.json', inputRows);
        const consumed = new Map(inputRows.map(row => [row.file, row]));
        const packageSources = new Map(), mapProviders = [];
        const retainedDir = path.join(variantOut, 'dependency-maps');
        fs.mkdirSync(retainedDir, { recursive: true });
        for (const input of inputRows) {
          if (input.virtual || !input.file.startsWith(nodeRoot)) continue;
          const bytes = fs.readFileSync(input.file);
          assert.equal(hash(bytes), input.sha256);
          const refs = [...bytes.toString('utf8').matchAll(/^[\t ]*\/\/[#@]\s*sourceMappingURL=(\S+)[\t ]*\r?$/gm)];
          const references = [...new Set(refs.map(row => row[1]))];
          assert(references.length <= 1, 'At most one unique actual consumed package map reference');
          if (!references.length) continue;
          const reference = references[0];
          assert(!/^(?:\w+:|\/)/.test(reference), 'Actual relative installed package map reference');
          const mapFile = fs.realpathSync(path.resolve(path.dirname(input.file), reference));
          assert(mapFile.startsWith(nodeRoot) && fs.statSync(mapFile).isFile(), 'Provider map stays inside held installed packages');
          const raw = fs.readFileSync(mapFile), published = JSON.parse(raw);
          assert(Array.isArray(published.sources));
          assert(published.sourcesContent === undefined || Array.isArray(published.sourcesContent));
          if (published.sourcesContent !== undefined) assert.equal(published.sources.length, published.sourcesContent.length);
          assert(published.sourceRoot === undefined || typeof published.sourceRoot === 'string');
          const mapSha256 = hash(raw), retained = path.join(retainedDir, mapSha256 + '.map');
          const inputRetained = path.join(retainedDir, input.sha256 + '.input');
          fs.writeFileSync(retained, raw); fs.writeFileSync(inputRetained, bytes);
          const proof = { input: input.file, inputSha256: input.sha256, sourceMappingURL: reference, mapFile, mapSha256, retained, inputRetained };
          mapProviders.push(proof);
          for (let index = 0; index < published.sources.length; index++) {
            assert.equal(typeof published.sources[index], 'string');
            const name = path.resolve(path.dirname(mapFile), published.sourceRoot ?? '', published.sources[index]);
            let content, contentProof;
            if (typeof published.sourcesContent?.[index] === 'string') {
              content = Buffer.from(published.sourcesContent[index]);
              contentProof = { contentKind: 'published sourcesContent' };
            } else {
              if (!name.startsWith(nodeRoot) || !fs.existsSync(name)) continue;
              const sourceFile = fs.realpathSync(name);
              assert(sourceFile === name && sourceFile.startsWith(nodeRoot) && fs.statSync(sourceFile).isFile(), 'Map-named installed original source remains inside held packages');
              content = fs.readFileSync(sourceFile);
              const sourceRetained = path.join(retainedDir, hash(content) + '.source');
              fs.writeFileSync(sourceRetained, content);
              contentProof = { contentKind: 'published map named installed source', sourceFile, sourceRetained, sourceSha256: hash(content) };
            }
            const contentHash = hash(content);
            packageSources.set(name + '\0' + contentHash, { ...proof, index, ...contentProof });
          }
        }
        save(outfile + '.providers.json', mapProviders);
        const map = JSON.parse(fs.readFileSync(mapPath)), bindings = [], seen = new Set();
        assert.equal(map.sources.length, map.sourcesContent.length);
        for (let i = 0; i < map.sources.length; i++) {
          assert.equal(typeof map.sourcesContent[i], 'string');
          const file = path.resolve(path.dirname(mapPath), map.sources[i]);
          const actualHash = hash(Buffer.from(map.sourcesContent[i]));
          const input = consumed.get(file);
          if (!input) {
            assert(file.startsWith(nodeRoot), 'Missing app/core/entry mapped sources fail closed: ' + file);
            const provider = packageSources.get(file + '\0' + actualHash);
            assert(provider, 'Dependency original must match a consumed actual package map: ' + file);
            bindings.push({ source: map.sources[i], file, sha256: actualHash, virtual: false, kind: 'consumed package map original', provider });
            continue;
          }
          assert.equal(actualHash, input.sha256, 'Actual consumed emitted source content: ' + file);
          for (const source of requiredCore) if (file === path.join(sourceRoot, source)) seen.add(source);
          bindings.push({ source: map.sources[i], file, sha256: actualHash, virtual: input.virtual, kind: input.virtual ? 'retained stdin entry' : 'actual consumed input' });
        }
        assert.deepEqual([...seen].sort(), [...requiredCore].sort(), 'All actual core bodies bound');
        const js = fs.readFileSync(outfile);
        assert(js.toString().includes('//# sourceMappingURL=' + path.basename(mapPath)));
        const record = { js: outfile, jsSha256: hash(js), map: mapPath, mapSha256: hash(fs.readFileSync(mapPath)), inputRows, bindings, requiredCore, mapProviders };
        save(outfile + '.bindings.json', record); return record;
      };
      fs.writeFileSync(path.join(variantOut,'engine-entry.mjs'),engineEntry);
      const engineFile=path.join(variantOut,'engine.mjs');
      const engineBuild=await build({absWorkingDir:sourceRoot,stdin:{contents:engineEntry,sourcefile:'1162-engine-entry.mjs',resolveDir:sourceRoot,loader:'js'},outfile:engineFile,bundle:true,platform:'node',format:'esm',sourcemap:true,metafile:true,alias:{'@':path.join(sourceRoot,'src')},tsconfig:path.join(sourceRoot,'tsconfig.app.json')});
      const engineBinding=bindBuild(engineBuild,engineFile,'1162-engine-entry.mjs',engineEntry,['src/lib/clubManager.ts']);
      const {engine}=await import(pathToFileURL(engineFile).href);
      const RealDate=globalThis.Date, originalRandom=Math.random;let randomSeed=1162,started,intake;
      try{
        globalThis.Date=class extends RealDate{constructor(...args){super(...(args.length?args:[epoch]));}static now(){return epoch;}};
        Math.random=()=>{randomSeed=(Math.imul(randomSeed,1664525)+1013904223)>>>0;return randomSeed/4294967296;};
        started=clone(engine.startCareer('Arsenal')); intake=clone(engine.startNextSeason(clone(started)));
      }finally{globalThis.Date=RealDate;Math.random=originalRandom;}
      assert(started.academy&&intake.academy);assert.equal(started.academy.prospects.length,0);
      assert(intake.academy.prospects.length>=2,'Actual held engine creates at least two academy intake prospects');
      assert(intake.academy.prospects.every(p=>p.source==='Academy'&&p.fee===0));
      assert.equal(new Set(intake.academy.prospects.map(p=>p.id)).size,intake.academy.prospects.length);
      assert.equal(new Set(intake.academy.prospects.map(p=>p.name)).size,intake.academy.prospects.length);
      const normal=clone(intake);normal.squad=normal.squad.slice(0,29);
      assert(normal.squad.length>0&&normal.squad.length<30);
      const ordered=[...normal.academy.prospects].sort((a,b)=>b.highGuess-a.highGuess),target=ordered[1];
      assert(target&&target.id!==ordered[0].id&&target.name!==ordered[0].name);
      const fixtures={normal,money:clone(normal),full:clone(normal)};
      fixtures.money.budget=0;fixtures.money.academy.prospects.find(p=>p.id===target.id).fee=1;
      const additions=[];while(fixtures.full.squad.length<30){const original=normal.squad[additions.length%normal.squad.length],copy=clone(original);copy.id='fixture-full-'+additions.length;assert(!fixtures.full.squad.some(p=>p.id===copy.id));additions.push({originalId:original.id,copyId:copy.id});fixtures.full.squad.push(copy);}
      assert.equal(fixtures.full.squad.length,30);
      save(path.join(variantOut,'started-career.json'),started);save(path.join(variantOut,'actual-intake-career.json'),intake);
      for(const [kind,fixture]of Object.entries(fixtures))save(path.join(variantOut,'fixture-'+kind+'.json'),fixture);
      save(path.join(variantOut,'fixture-provenance.json'),{club:'Arsenal',epoch,initialSeed:1162,finalSeed:randomSeed,targetId:target.id,targetName:target.name,orderedProspectIds:ordered.map(p=>p.id),normalSquadCount:normal.squad.length,intakeSquadCount:intake.squad.length,fullAdditions:additions,scope:'Actual startCareer plus startNextSeason intake setup, not season gameplay. Normal squad capped at29. Full boundary copies actual player bodies with explicit fixture ids to30. Money boundary changes only budget0 and target fee1.'});
      fs.writeFileSync(path.join(variantOut, 'client-entry.jsx'), clientEntry);
      const clientFile = path.join(browserDir, 'fixture.js');
      const clientBuild = await build({ absWorkingDir: sourceRoot, stdin: { contents: clientEntry, sourcefile: '1162-client-entry.jsx', resolveDir: sourceRoot, loader: 'jsx' }, outfile: clientFile, bundle: true, platform: 'browser', format: 'esm', sourcemap: true, metafile: true, alias: { '@': path.join(sourceRoot, 'src') }, tsconfig: path.join(sourceRoot, 'tsconfig.app.json') });
      const clientBinding = bindBuild(clientBuild, clientFile, '1162-client-entry.jsx', clientEntry, core);
      const dist = path.join(root, 'dist'), css = [];
      const builtIndexFile = path.join(variantOut, 'built-index.html');
      const builtIndex = fs.readFileSync(path.join(dist, 'index.html'), 'utf8');
      fs.writeFileSync(builtIndexFile, builtIndex);
      const knownExternalFontHref = 'https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap';
      const classifyStylesheet = href => href === knownExternalFontHref ? 'held external font declaration' : href && href.startsWith('/assets/') && href.endsWith('.css') ? 'local application CSS' : 'unsupported stylesheet';
      const stylesheetRefs = text => [...text.matchAll(/<link\b[^>]*>/g)].filter(tag => /\brel=["']stylesheet["']/.test(tag[0])).map(tag => {
        const href = tag[0].match(/\bhref=["']([^"']+)["']/)?.[1] ?? null;
        return { tag: tag[0], href, classification: classifyStylesheet(href) };
      });
      const references = stylesheetRefs(builtIndex);
      save(path.join(variantOut, 'stylesheet-refs.json'), references);
      const sourceIndex = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
      assert.equal(stylesheetRefs(sourceIndex).filter(row => row.href === knownExternalFontHref).length, 1, 'One exact held font declaration exists in the original source');
      const selectApplicationCss = refs => {
        assert(refs.every(row => classifyStylesheet(row.href) !== 'unsupported stylesheet'), 'Every stylesheet is the exact held font declaration or local application CSS');
        const selected = refs.filter(row => classifyStylesheet(row.href) === 'local application CSS');
        assert(selected.length > 0, 'Actual built application CSS is required');
        return selected;
      };
      const selected = selectApplicationCss(references);
      assert.equal(references.filter(row => row.href === knownExternalFontHref).length, 1, 'One exact held font declaration exists in the actual built index');
      const controlReferences = references.map(row => row.href === knownExternalFontHref ? { ...row, href: 'https://invalid.example/unknown.css', classification: classifyStylesheet('https://invalid.example/unknown.css') } : { ...row });
      assert.equal(controlReferences.filter(row => row.classification === 'unsupported stylesheet').length, 1, 'The copied unknown stylesheet control changes one actual declaration');
      let controlFailure;
      try { selectApplicationCss(controlReferences); } catch (error) { controlFailure = error; }
      assert(controlFailure instanceof assert.AssertionError);
      assert.equal(controlFailure.message, 'Every stylesheet is the exact held font declaration or local application CSS');
      assert.deepEqual(controlReferences.filter(row => row.classification === 'local application CSS'), selected, 'The copied control keeps the real local CSS baseline');
      const cssSelection = { builtIndex: builtIndexFile, builtIndexSha256: hash(Buffer.from(builtIndex)), sourceIndexSha256: hash(Buffer.from(sourceIndex)), knownExternalFontHref, references, selected, controlReferences, intendedFailure: { name: controlFailure.name, message: controlFailure.message, actual: controlFailure.actual, expected: controlFailure.expected } };
      save(path.join(variantOut, 'stylesheet-selection.json'), cssSelection);
      const assertCssBytes = bytes => assert(bytes.length > 0, 'Selected application CSS has positive bytes');
      for (const row of selected) {
        const href = row.href;
        const bytes = fs.readFileSync(path.join(dist, href.slice(1)));
        assertCssBytes(bytes);
        css.push({ url: href, sha256: hash(bytes), bytes: bytes.length });
      }
      assert(css.length > 0, 'Actual built application CSS used by the component fixture');
      const emptyCss = Buffer.alloc(0), emptyCssFile = path.join(variantOut, 'empty-css-control.css');
      fs.writeFileSync(emptyCssFile, emptyCss);
      assert.notEqual(hash(emptyCss), css[0].sha256, 'The copied empty CSS control changes the actual selected payload');
      let emptyCssFailure;
      try { assertCssBytes(emptyCss); } catch (error) { emptyCssFailure = error; }
      assert(emptyCssFailure instanceof assert.AssertionError);
      assert.equal(emptyCssFailure.message, 'Selected application CSS has positive bytes');
      const cssByteControl = { baseline: css[0], controlledFile: emptyCssFile, controlledBytes: emptyCss.length, controlledSha256: hash(emptyCss), intendedFailure: { name: emptyCssFailure.name, message: emptyCssFailure.message, actual: emptyCssFailure.actual, expected: emptyCssFailure.expected } };
      save(path.join(variantOut, 'css-byte-control.json'), cssByteControl);
      const html = `<!doctype html><html class="dark"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="stylesheet" href="/held-fonts.css">${css.map(c => `<link rel="stylesheet" href="${c.url}">`).join('')}</head><body class="bg-background text-foreground"><main id="fixture-root" class="mx-auto max-w-2xl p-4"></main><script type="module">import{mount}from'/fixture.js';mount(window.__academyFixture);</script></body></html>`;
      fs.writeFileSync(path.join(browserDir, 'index.html'), html);
      save(path.join(variantOut, 'fixture-build.json'), { scope: 'Actual AcademyScreen direct component and held engine helpers, not ClubManager route or save persistence', engine: engineBinding, client: clientBinding, css, cssSelection, cssByteControl, fonts, htmlSha256: hash(Buffer.from(html)) });
      const records = [], payloadDir = path.join(variantOut, 'served-payloads'); fs.mkdirSync(payloadDir);
      const server = http.createServer((req, res) => {
        try {
          assert.equal(req.method, 'GET');
          const requestPath = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
          const font = fontAssets.get(requestPath);
          const source = font ? 'held-template-font' : requestPath === '/' ? 'component-fixture' : ['/fixture.js', '/fixture.js.map'].includes(requestPath) ? 'component-bundle' : 'candidate-dist';
          const file = font ? font.file : source === 'component-fixture' ? path.join(browserDir, 'index.html') : source === 'component-bundle' ? path.join(browserDir, requestPath.slice(1)) : path.resolve(dist, requestPath.slice(1));
          assert(source !== 'candidate-dist' || file.startsWith(dist + path.sep));
          const bytes = fs.readFileSync(file), sha256 = hash(bytes);
          fs.writeFileSync(path.join(payloadDir, sha256), bytes);
          records.push({ method: req.method, url: requestPath, file, source, sha256, bytes: bytes.length });
          save(path.join(variantOut, 'served.json'), records);
          const ext = path.extname(file);
          res.writeHead(200, { 'Content-Type': font ? font.type : ({ '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.woff2': 'font/woff2', '.json': 'application/json' })[ext] || 'application/octet-stream', 'Cache-Control': 'no-store' }); res.end(bytes);
        } catch (error) { records.push({ method: req.method, url: req.url, error: String(error) }); save(path.join(variantOut, 'served.json'), records); res.writeHead(404); res.end('Unavailable'); }
      });
      await new Promise(resolve => server.listen(0, '127.0.0.1', resolve)); servers.push(server);
      const origin = 'http://127.0.0.1:' + server.address().port;
      const plans=variant==='candidate'?[[320,'sign-enter'],[1280,'sign-space'],[320,'release-space'],[1280,'release-enter'],[320,'sign-pointer'],[1280,'release-pointer'],[320,'disabled-money'],[1280,'disabled-full']]:[[320,'sign-name-control'],[1280,'sign-name-control'],[320,'release-name-control'],[1280,'release-name-control']];
      for(const [width,action]of plans){
        const name=`${variant}-${width}-${action}`,dir=path.join(out,name);fs.mkdirSync(dir);
        const kind=action==='disabled-money'?'money':action==='disabled-full'?'full':'normal',fixture=clone(fixtures[kind]),operation=action.startsWith('release')?'release':'sign';
        const chosen=fixture.academy.prospects.find(p=>p.id===target.id);assert(chosen);
        save(path.join(dir,'fixture.json'),fixture);
        const row={name,variant,width,action,fixtureKind:kind,target:clone(chosen),fixtureSha256:hash(fs.readFileSync(path.join(dir,'fixture.json'))),status:'failed',pageErrors:[],localFailures:[],localRequests:[],blocked:[],sockets:[],checks:{}};
        let context,page;
        const snapshot=async stage=>{
          const board=page.locator('[data-academy-board]');
          const data=await board.evaluate(el=>{
            const state=window.__academy1162.snapshot(),ordered=[...state.career.academy.prospects].sort((a,b)=>b.highGuess-a.highGuess),buttons=[...el.querySelectorAll('button')].filter(b=>b.textContent.trim()==='Sign him');
            const rows=buttons.map((sign,i)=>{const node=sign.parentElement.parentElement.parentElement,release=sign.parentElement.children[1],r=node.getBoundingClientRect(),p=ordered[i],button=b=>({text:b.textContent.trim(),label:b.getAttribute('aria-label'),disabled:b.disabled,className:b.className,focused:b===document.activeElement,geometry:{width:b.getBoundingClientRect().width,height:b.getBoundingClientRect().height}});return{id:p?.id??null,name:p?.name??null,identity:node.children[1].children[0].textContent,report:node.children[1].children[1].textContent,position:node.children[0].textContent,fee:node.children[2].children[0].textContent,sign:button(sign),release:button(release),geometry:{x:r.x,y:r.y,width:r.width,height:r.height}};});
            return{html:el.outerHTML,text:el.innerText,state,rows,live:el.querySelector('[data-desk-cue-live="cm-academy-cue"]')?.textContent.trim()??'',geometry:{width:el.getBoundingClientRect().width,documentWidth:document.documentElement.scrollWidth,viewportWidth:innerWidth},focus:{tag:document.activeElement?.tagName,label:document.activeElement?.getAttribute('aria-label')??null,text:document.activeElement?.textContent.trim()??null,sentinel:document.activeElement?.getAttribute('data-sentinel')??null}};
          });
          data.aria=await board.ariaSnapshot();save(path.join(dir,stage+'.json'),data);await page.screenshot({path:path.join(dir,stage+'.png')});return data;
        };
        const assertRows=(data,current)=>{
          assert.deepEqual(data.state.career,current);const ordered=[...current.academy.prospects].sort((a,b)=>b.highGuess-a.highGuess);
          assert.deepEqual(data.rows.map(r=>r.id),ordered.map(p=>p.id));assert.equal(data.geometry.viewportWidth,width);assert(data.geometry.documentWidth<=width);
          for(let i=0;i<ordered.length;i++){const p=ordered[i],actual=data.rows[i],band=p.highGuess>=84?'Could be special':p.highGuess>=76?'First team ceiling':p.highGuess>=68?'Squad player at best':'One for the reserves';
            assert.equal(actual.identity,`${p.flag} ${p.name} (${p.age})`);assert.equal(actual.position,p.position);assert.equal(actual.report,`Now ${p.rating} · scout says he tops out ${p.lowGuess} to ${p.highGuess} · ${band}`);assert.equal(actual.fee,p.fee>0?engine.moneyIn(current)(p.fee):'Free');
            assert.equal(actual.sign.text,'Sign him');assert.equal(actual.release.text,'Let go');assert.equal(actual.sign.disabled,p.fee>current.budget||current.squad.length>=30);assert.equal(actual.release.disabled,false);
            assert.equal(actual.sign.label,variant==='candidate'?'Sign him: '+p.name:null);assert.equal(actual.release.label,variant==='candidate'?'Let go: '+p.name:null);
            assert(actual.geometry.width>0&&actual.geometry.height>0&&actual.geometry.x>=0&&actual.geometry.x+actual.geometry.width<=width);
          }
          assert(data.text.includes(`Showing ${ordered.length} of ${ordered.length} prospects`));assert.equal(data.text.includes('Your squad is full. Sell or release someone before you sign another kid.'),current.squad.length>=30&&ordered.length>0);
        };
        const desired=(op,p)=>`${op==='sign'?'Sign him':'Let go'}: ${p.name}`;
        const assertNamed=async(op,p)=>{const button=page.getByRole('button',{name:desired(op,p),exact:true});assert.equal(await button.count(),1,'Exactly one native Academy button named '+desired(op,p));return button;};
        const rowButton=(op,p)=>{const ordered=[...fixture.academy.prospects].sort((a,b)=>b.highGuess-a.highGuess),i=ordered.findIndex(item=>item.id===p.id);assert(i>=0);return page.locator('[data-academy-board]').getByRole('button',{name:op==='sign'?'Sign him':'Let go',exact:true}).nth(i);};
        const expectedFor=op=>op==='sign'?engine.promoteProspect(clone(fixture),chosen.id):engine.releaseProspect(clone(fixture),chosen.id);
        const assertConsequence=(data,expected,op)=>{
          assert(expected);assert.notDeepEqual(expected,fixture);assertRows(data,expected);assert.deepEqual(data.state.calls,[{action:op,id:chosen.id}]);
          assert.equal(expected.academy.prospects.some(p=>p.id===chosen.id),false);assert.deepEqual(expected.academy.prospects,fixture.academy.prospects.filter(p=>p.id!==chosen.id));
          if(op==='sign'){
            assert.equal(expected.squad.length,fixture.squad.length+1);assert.equal(expected.budget,Math.round((fixture.budget-chosen.fee)*10)/10);
            const got=expected.squad.find(p=>!fixture.squad.some(old=>old.id===p.id));assert(got&&got.academyGrad);assert.equal(got.name,chosen.name);assert.equal(got.position,chosen.position);assert.equal(got.rating,chosen.rating);assert.equal(got.age,chosen.age);assert.equal(got.potential,chosen.potential);
            const cue=`${got.name} has joined the first team. ${got.contractYears??0} years at ${got.wage??0}k a week, ${chosen.fee>0?`${engine.moneyIn(fixture)(chosen.fee)} to sign`:'free to sign'}.`;assert.equal(data.live,cue);
          }else{assert.deepEqual(expected.squad,fixture.squad);assert.equal(expected.budget,fixture.budget);assert.equal(data.live,'');}
        };
        const navigate=async()=>{await page.goto(origin,{waitUntil:'networkidle'});await page.locator('[data-academy-board]').locator('button').filter({hasText:/^Let go$/}).first().waitFor();};
        try{
          context=await browser.newContext({viewport:{width,height:900},reducedMotion:'reduce'});
          await context.routeWebSocket('**/*',socket=>{row.sockets.push(socket.url());socket.close();});
          await context.route('**/*',async route=>{const request=route.request(),url=request.url();if(!url.startsWith(origin+'/')){row.blocked.push({url,method:request.method()});await route.abort();return;}row.localRequests.push({url:new URL(url).pathname,method:request.method()});if(request.method()!=='GET'){row.localFailures.push({url,error:'Unexpected local write'});await route.abort();return;}await route.continue();});
          await context.addInitScript(fixture=>{window.__academyFixture=fixture;},fixture);page=await context.newPage();await page.clock.install({time:epoch});await page.clock.pauseAt(epoch);
          page.on('pageerror',error=>row.pageErrors.push({name:error.name,message:error.message,stack:error.stack}));page.on('requestfailed',request=>{if(request.url().startsWith(origin+'/'))row.localFailures.push({url:request.url(),error:request.failure()});});page.on('response',response=>{if(response.url().startsWith(origin+'/')&&response.status()>=400)row.localFailures.push({url:response.url(),status:response.status()});});
          await navigate();
          row.fonts=await page.evaluate(async()=>{await document.fonts.ready;const faces=[];for(const family of ['Inter','Space Grotesk'])for(const weight of [400,500,600,700]){const loaded=await document.fonts.load(`${weight} 16px "${family}"`,'Academy');faces.push({family,weight,loaded:loaded.map(face=>({family:face.family,weight:face.weight,status:face.status}))});}return faces;});
          assert.equal(row.fonts.length,8);assert(row.fonts.every(r=>r.loaded.length&&r.loaded.every(f=>f.status==='loaded'&&f.family.replaceAll('"','')===r.family&&f.weight===String(r.weight))));
          row.before=await snapshot('before');assertRows(row.before,fixture);assert.deepEqual(row.before.state.calls,[]);assert.equal(row.before.live,'');
          if(variant==='base'){
            assert.equal(await page.getByRole('button',{name:operation==='sign'?'Sign him':'Let go',exact:true}).count(),fixture.academy.prospects.length);
            const expected=expectedFor(operation);save(path.join(dir,'expected-held-helper-state.json'),expected);row.expectedStateSha256=hash(fs.readFileSync(path.join(dir,'expected-held-helper-state.json')));
            await rowButton(operation,chosen).click();await page.locator('#callback-output').filter({hasText:chosen.id}).waitFor({state:'attached'});if(operation==='sign')await page.locator('[data-desk-cue-live="cm-academy-cue"]').filter({hasText:chosen.name+' has joined the first team.'}).waitFor({state:'attached'});
            row.pointerBaseline=await snapshot('pointer-baseline');assertConsequence(row.pointerBaseline,expected,operation);
            await navigate();row.after=await snapshot('after');assertRows(row.after,fixture);assert.deepEqual(row.after.state,row.before.state);assert.equal(row.after.live,'');
            let error;try{await assertNamed(operation,chosen);}catch(caught){error=caught;}assert(error instanceof assert.AssertionError);assert.equal(error.actual,0);assert.equal(error.expected,1);assert(error.message.startsWith('Exactly one native Academy button named '+desired(operation,chosen)));
            row.intendedFailure={name:error.name,message:error.message,actual:error.actual,expected:error.expected,operator:error.operator};row.checks={actualParentPointerPassed:true,fullHeldHelperStateEqual:true,targetId:chosen.id,operation,actualFreshDocumentBaseline:true,intendedSameNameAssertionFailed:true};
          }else{
            for(const p of fixture.academy.prospects){await assertNamed('sign',p);await assertNamed('release',p);}
            const button=await assertNamed(operation,chosen);
            if(kind!=='normal'){
              assert(await button.isDisabled());assert.equal(engine.promoteProspect(clone(fixture),chosen.id),null,'Actual held engine refuses the disabled sign boundary');
              await button.scrollIntoViewIfNeeded();const box=await button.boundingBox();assert(box);
              const coordinates={x:box.x+box.width/2,y:box.y+box.height/2};
              const targetHit=await button.evaluate((el,point)=>{const hit=document.elementFromPoint(point.x,point.y);return{sameTarget:hit===el||el.contains(hit),tag:hit?.tagName??null,label:el.getAttribute('aria-label'),disabled:el.disabled,viewportWidth:innerWidth,viewportHeight:innerHeight,scrollY};},coordinates);
              row.disabledPointer={box,coordinates,targetHit,scope:'Actual disabled-button mouse attempt after intentional fixture setup scrolling; no no-scroll claim'};
              assert(box.width>0&&box.height>0&&coordinates.x>=0&&coordinates.x<width&&coordinates.y>=0&&coordinates.y<targetHit.viewportHeight);assert(targetHit.sameTarget&&targetHit.disabled);assert.equal(targetHit.label,desired('sign',chosen));
              await page.mouse.click(coordinates.x,coordinates.y);row.disabledPointer.state=await page.evaluate(()=>window.__academy1162.snapshot());save(path.join(dir,'disabled-pointer-state.json'),row.disabledPointer);
              assert.deepEqual(row.disabledPointer.state,row.before.state);
              await page.locator('[data-sentinel="before"]').focus();row.tabPath=[];let reached=false;for(let i=0;i<60;i++){await page.keyboard.press('Tab');const active=await page.evaluate(()=>({label:document.activeElement?.getAttribute('aria-label')??null,text:document.activeElement?.textContent.trim()??null,sentinel:document.activeElement?.getAttribute('data-sentinel')??null}));row.tabPath.push(active);assert.notEqual(active.label,desired('sign',chosen),'Disabled Sign is skipped by actual Tab');if(active.sentinel==='after'){reached=true;break;}}assert(reached);await page.keyboard.press('Enter');
              row.after=await snapshot('after');assertRows(row.after,fixture);assert.deepEqual(row.after.state,row.before.state);assert.equal(row.after.live,'');row.checks={allNamesPresent:true,selectedSignDisabled:true,actualTabSkippedDisabledSign:true,heldHelperRefused:true,completeStateUnchanged:true,noCue:true,boundary:kind};
            }else{
              assert(await button.isEnabled());const key=action.endsWith('space')?'Space':'Enter';
              if(action.endsWith('pointer'))await button.click();else{
                await page.locator('[data-sentinel="before"]').focus();row.tabPath=[];let reached=false;
                for(let i=0;i<60;i++){await page.keyboard.press('Tab');const active=await page.evaluate(()=>({label:document.activeElement?.getAttribute('aria-label')??null,text:document.activeElement?.textContent.trim()??null,sentinel:document.activeElement?.getAttribute('data-sentinel')??null}));row.tabPath.push(active);if(active.label===desired(operation,chosen)){reached=true;break;}}assert(reached,'Actual Tab reaches the named second prospect');row.tab=await snapshot('tab');assertRows(row.tab,fixture);assert.deepEqual(row.tab.state,row.before.state);assert.equal(row.tab.focus.label,desired(operation,chosen));await page.keyboard.press(key);
              }
              const expected=expectedFor(operation);save(path.join(dir,'expected-held-helper-state.json'),expected);row.expectedStateSha256=hash(fs.readFileSync(path.join(dir,'expected-held-helper-state.json')));
              await page.locator('#callback-output').filter({hasText:chosen.id}).waitFor({state:'attached'});if(operation==='sign')await page.locator('[data-desk-cue-live="cm-academy-cue"]').filter({hasText:chosen.name+' has joined the first team.'}).waitFor({state:'attached'});
              row.after=await snapshot('after');assertConsequence(row.after,expected,operation);row.checks={allNamesPresent:true,actualTab:!action.endsWith('pointer'),actualPointer:action.endsWith('pointer'),key:action.endsWith('pointer')?null:key,operation,targetId:chosen.id,callbackCount:1,fullHeldHelperStateEqual:true,otherProspectsHeld:true};
            }
          }
          const requests=new Set(row.localRequests.filter(r=>r.method==='GET').map(r=>r.url));assert(requests.has('/fixture.js')&&requests.has('/held-fonts.css'));assert([...requests].some(url=>url.startsWith('/held-fonts/')));for(const style of css)assert(requests.has(style.url));assertTransport(row);row.status='passed';
        }catch(error){row.error={name:error.name,message:error.message,stack:error.stack};}
        finally{if(context)try{await context.close();}catch(error){row.closeError=String(error);row.status='failed';}if(row.pageErrors.length||row.localFailures.length)row.status='failed';try{assertTransport(row);}catch(error){row.transportError={name:error.name,message:error.message,actual:error.actual,expected:error.expected};row.status='failed';}save(path.join(dir,'result.json'),row);results.push(row);save(path.join(out,'partial-summary.json'),{executionComplete:false,results});}
      }
      assert(records.every(r=>!r.error));for(const row of results.filter(r=>r.variant===variant))for(const request of row.localRequests)assert(records.some(r=>r.url===request.url&&r.method===request.method&&!r.error));
      variants.push({variant,engineBinding,clientBinding,servedRecords:records.length});
    }
    assert.deepEqual(JSON.parse(fs.readFileSync(path.join(out,'candidate/actual-intake-career.json'))),JSON.parse(fs.readFileSync(path.join(out,'base/actual-intake-career.json'))),'Actual candidate and parent engine intake setup is identical');
    for(const [width,operation]of [[320,'sign'],[1280,'sign'],[320,'release'],[1280,'release']]){
      const candidate=results.find(r=>r.name===`candidate-${width}-${operation}-${operation==='sign'?(width===320?'enter':'space'):(width===320?'space':'enter')}`),base=results.find(r=>r.name===`base-${width}-${operation}-name-control`);assert(candidate&&base);
      const visible=data=>data.rows.map(({sign,release,...r})=>({...r,sign:{...sign,label:null},release:{...release,label:null}}));assert.deepEqual(visible(candidate.before),visible(base.before));assert.deepEqual(candidate.before.state,base.before.state);assert.deepEqual(candidate.before.geometry,base.before.geometry);
    }
    assert.equal(results.filter(r=>r.variant==='candidate').length,8);assert.equal(results.filter(r=>r.variant==='base').length,4);assert(results.every(r=>r.status==='passed'));
const baselineName='candidate-320-sign-enter', baselineFile=path.join(out,baselineName,'result.json');
    const baseline=JSON.parse(fs.readFileSync(baselineFile)); assert.equal(baseline.status,'passed'); assertTransport(baseline);
    const controls=[];
    for(const key of ['blocked','sockets']) {
      const controlled=JSON.parse(JSON.stringify(baseline));
      controlled[key]=key==='blocked'?[{url:'https://invalid.example/blocked-control',method:'GET'}]:['wss://invalid.example/socket-control'];
      assert.notDeepEqual(controlled,baseline,'The copied record actually changes its selected empty transport collection');
      assert.deepEqual({...controlled,[key]:baseline[key]},baseline,'Exactly the selected transport collection changes');
      let error; try { assertTransport(controlled); } catch(caught) { error=caught; }
      assert(error instanceof assert.AssertionError); assert.deepEqual(error.actual,controlled[key]); assert.deepEqual(error.expected,[]); assert.equal(error.operator,'deepStrictEqual');
      const intendedMessage=key==='blocked'?'No external HTTP attempts':'No WebSocket attempts'; assert(error.message.startsWith(intendedMessage));
      controls.push({key,controlled,intendedFailure:{name:error.name,message:error.message,actual:error.actual,expected:error.expected,operator:error.operator}});
    }
    save(path.join(out,'transport-controls.json'),{baselineName,baselineSha256:hash(fs.readFileSync(baselineFile)),baseline,controls,scope:'Effective copied-record validator checks, not actual external requests'});
  } finally {await browser.close();for(const server of servers)await new Promise((resolve,reject)=>server.close(error=>error?reject(error):resolve()));}
  save(path.join(out,'summary.json'),{executionComplete:true,healthy:8,effectiveBaseControls:4,variants,results,scope:'Actual AcademyScreen component and held engine promote/release consequences from an engine-generated intake with disclosed boundary fixture deltas. No whole route/season gameplay/save/backend/live/event.isTrusted claim'});
  console.log('Native1162 PASS: eight candidate Academy sign/release/disabled cases and four unchanged-parent pointer baselines with effective name controls.');
}
if(isEntry())(process.argv.includes('--prefetch-fonts-only')?prepareFonts():main()).catch(error=>{console.error(error);process.exitCode=1;});
