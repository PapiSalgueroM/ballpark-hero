import { createRoot } from 'react-dom/client';
import { RolesScreen } from "/home/runner/work/_temp/roles-count-1152.wLoZBt/evidence/native/preview-control-source/RolesScreen.tsx";
import { startCareer, brokenPromises, promiseGap, squadByRole, ROLE_INFO } from "/home/runner/work/ballpark-hero/ballpark-hero/src/lib/clubManager.ts";
window.mountRoles1152 = total => {
  const base = startCareer('Brentford');
  if (base.squad.length < total + 3) throw new Error('Actual career has too few fixture players');
  const ids = base.squad.slice(0, total).map(p => p.id);
  const loanId = base.squad[total].id, shortId = base.squad[total + 1].id, satisfiedId = base.squad[total + 2].id;
  const career = { ...base, squad: base.squad.map(p => {
    const index = ids.indexOf(p.id), q = { ...p, role: 'backup', lastTen: Array(10).fill(1), onLoan: false, wantsOut: false };
    if (index >= 0) { q.role = 'star'; q.lastTen = [...Array(index).fill(1), ...Array(10 - index).fill(0)]; }
    if (p.id === loanId) { q.role = 'star'; q.lastTen = Array(10).fill(0); q.onLoan = true; q.wantsOut = total > 0; }
    if (p.id === shortId) { q.role = 'star'; q.lastTen = [0, 0, 0]; }
    if (p.id === satisfiedId) { q.role = 'star'; q.wantsOut = total >= 5; }
    return q;
  }) };
  const broken = brokenPromises(career);
  window.roles1152 = { career, initial: JSON.stringify(career), total, callbacks: [], expected: {
    ids, broken: broken.map(p => ({ id: p.id, name: p.name, gap: promiseGap(p) })),
    sentinels: { loanId, shortId, satisfiedId }, wantsOut: career.squad.filter(p => p.wantsOut).length,
    groups: squadByRole(career).map(g => ({ role: g.role, label: ROLE_INFO[g.role].label, ids: g.players.map(p => p.id), names: g.players.map(p => p.name) }))
  } };
  createRoot(document.getElementById('root')).render(<main id="roles-fixture" className="mx-auto max-w-xl p-4"><RolesScreen career={career} onSetRole={(id, role) => window.roles1152.callbacks.push({ id, role })} /></main>);
};
window.rolesBundleReady = true;
