import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';

assert.equal(process.env.GITHUB_ACTIONS, 'true', 'Remote-only retained runner proof');
const root = process.cwd(), out = path.join(process.env.E, 'discovery');
const digest = bytes => createHash('sha256').update(bytes).digest('hex');
const candidates = fs.readdirSync(path.join(root, '.sim-control'), { withFileTypes: true })
  .filter(row => row.isDirectory() && row.name.startsWith('browser-discovery-'));
assert.equal(candidates.length, 1, 'Exactly one actual owned discovery fixture');
const folder = path.join(root, '.sim-control', candidates[0].name);
fs.mkdirSync(out, { recursive: true });
fs.cpSync(folder, path.join(out, 'fixture'), { recursive: true, dereference: false });
const reportFile = path.join(folder, 'report.json');
const report = JSON.parse(fs.readFileSync(reportFile));
const held = ['scripts/runAllSims.mjs', 'scripts/lib/offlineTransport.cjs', 'scripts/lib/hostLikeServer.mjs',
  'scripts/playSoccerHubGrid1089.mjs', 'scripts/playSoccerOfferReview1082.mjs',
  'scripts/playTycoonSaleReview1083.mjs', 'scripts/simBracketMoment.mjs', 'scripts/simNoRivalNames.mjs'];
assert.deepEqual(Object.keys(report.before), held);
for (const file of held) assert.equal(digest(fs.readFileSync(path.join(root, file))), report.before[file], 'Held actual source: ' + file);
const actual = held.slice(3).map(file => ({ file: path.basename(file), browser: file !== 'scripts/simNoRivalNames.mjs', source: fs.readFileSync(path.join(root, file), 'utf8'), actualSourceSha256: report.before[file] }));
const synthetic = [
  { file: 'simStaticNamed.mjs', browser: true, source: "import { chromium } from 'playwright';" },
  { file: 'simStaticLoader.mjs', browser: true, source: "import { chromium } from './lib/playwrightLoader.mjs';" },
  { file: 'simDirectRequire.mjs', browser: true, source: "const module = require('playwright');" },
  { file: 'simDynamicSpaced.mjs', browser: true, source: "await import /* actual import */ ('./lib/playwrightLoader.mjs');" },
  { file: 'simLineComment.mjs', browser: false, source: "// import './lib/playwrightLoader.mjs';" },
  { file: 'simBlockComment.mjs', browser: false, source: "/* require('playwright'); */" },
  { file: 'simQuotedSource.mjs', browser: false, source: 'const example = "await import(\'./lib/playwrightLoader.mjs\')";' },
  { file: 'simTemplateSource.mjs', browser: false, source: 'const example = `import "playwright";`;' },
  { file: 'simPlainNode.mjs', browser: false, source: "import os from 'node:os'; const note = 'playwright';" },
];
const fixtures = [...actual, ...synthetic];
assert.equal(fixtures.length, 14);
assert.deepEqual(report.fixtures, fixtures.map(({ source, ...row }) => row));
for (const row of fixtures) {
  const prelude = `const _dukbDiscovery = await import('node:fs');\n` +
    `_dukbDiscovery.appendFileSync(process.env.DISCOVERY_MARKER, JSON.stringify({file:${JSON.stringify(row.file)},only:process.env.ONLY??null,browser:process.env.BROWSER??null,base:process.env.BASE??null,sweep:process.env.SWEEP_BASE??null})+'\\n');\n` +
    `console.log(${JSON.stringify(row.file + '\nOwned child selected\nNo game or browser executed\nSelection receipt complete')});\nprocess.exit(0);\n`;
  assert.equal(fs.readFileSync(path.join(folder, 'scripts', row.file), 'utf8'), prelude + row.source, 'Actual sentinel plus untouched source body: ' + row.file);
}
const runner = fs.readFileSync(path.join(root, held[0]), 'utf8').replace(/\r\n/g, '\n');
const anchor = 'node.expression.kind === ts.SyntaxKind.ImportKeyword';
assert.equal(runner.split(anchor).length - 1, 1);
const controlled = runner.replace(anchor, 'false');
assert.notEqual(controlled, runner);
assert.equal(controlled.split(anchor).length - 1, 0);
assert.equal(controlled.replace('false\n        || ts.isIdentifier(node.expression)', anchor + '\n        || ts.isIdentifier(node.expression)'), runner, 'Exact one-anchor control inverse');
assert.equal(fs.readFileSync(path.join(folder, 'scripts', 'runAllSims.mjs'), 'utf8'), controlled);
const normal = fixtures.filter(row => !row.browser).map(row => row.file).sort();
const all = fixtures.map(row => row.file).sort();
const five = [...held.slice(3, 7).map(file => path.basename(file)), 'simDynamicSpaced.mjs'].sort();
assert.equal(normal.length, 6); assert.equal(five.length, 5);
const expected = [normal, all, [...normal, ...five].sort()];
assert.equal(report.observations.length, 3);
for (let i = 0; i < 3; i++) {
  const row = report.observations[i], names = row.rows.map(r => r.file).sort();
  assert.equal(row.browser, i === 1); assert.equal(row.code, 0);
  assert.equal(row.sourceSha256, digest(i === 2 ? controlled : runner));
  assert.deepEqual(names, expected[i], 'Exact actual child set: ' + i);
  assert.equal(new Set(names).size, names.length, 'Each actual selected child ran once');
  assert(row.rows.every(r => r.only === null && r.browser === null), 'No runner selection controls leak');
  for (const child of row.rows) {
    if (i === 1 && fixtures.find(r => r.file === child.file).browser) {
      assert.match(child.base, /^http:\/\/127\.0\.0\.1:\d+$/); assert.equal(child.sweep, child.base);
    }
    assert.equal([...row.output.matchAll(new RegExp('^\\s*PASS\\s+' + child.file.replaceAll('.', '\\.') + '\\s', 'gm'))].length, 1, 'Actual printed child PASS: ' + child.file);
  }
  assert(!/^\s*(?:FAIL|EMPTY)\s+\S+\.mjs\s/m.test(row.output));
}
assert.deepEqual(report.observations[2].intendedFailure.actual, expected[2]);
assert.deepEqual(report.observations[2].intendedFailure.expected, normal);
assert.equal(report.observations[2].intendedFailure.name, 'AssertionError');
assert(report.observations[2].intendedFailure.message.startsWith('Default runner omits every actual and synthetic browser import'));
const marker = fs.readFileSync(path.join(folder, 'children.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
assert.deepEqual(marker, report.observations[2].rows, 'Actual final child marker file');
assert.equal(fs.readFileSync(path.join(folder, 'scripts/lib/offlineTransport.cjs')).equals(fs.readFileSync(path.join(root, 'scripts/lib/offlineTransport.cjs'))), true);
assert.equal(fs.readFileSync(path.join(folder, 'scripts/lib/hostLikeServer.mjs')).equals(fs.readFileSync(path.join(root, 'scripts/lib/hostLikeServer.mjs'))), true);
assert.equal(fs.readFileSync(path.join(folder, 'scripts/lib/playwrightLoader.mjs'), 'utf8'), 'export const chromium = {};\n');
assert.equal(fs.realpathSync(path.join(folder, 'node_modules/typescript')), fs.realpathSync(path.join(root, 'node_modules/typescript')));
const installed = JSON.parse(fs.readFileSync('node_modules/typescript/package.json'));
const lock = JSON.parse(fs.readFileSync('package-lock.json'));
assert.equal(installed.version, lock.packages['node_modules/typescript'].version);
assert.equal(digest(fs.readFileSync('node_modules/typescript/' + installed.main)), digest(fs.readFileSync(path.join(folder, 'node_modules/typescript', installed.main))));
const rawFiles = [];
function visit(dir) { for (const row of fs.readdirSync(dir, { withFileTypes: true })) { const file = path.join(dir, row.name); if (row.isDirectory()) visit(file); else if (row.isSymbolicLink()) rawFiles.push({ path: path.relative(folder, file), link: fs.readlinkSync(file), realpath: fs.realpathSync(file) }); else { const bytes = fs.readFileSync(file); rawFiles.push({ path: path.relative(folder, file), bytes: bytes.length, sha256: digest(bytes) }); } } }
visit(folder);
fs.writeFileSync(path.join(out, 'receipt.json'), JSON.stringify({ scope: 'Actual runner selection through early child sentinels, no game/browser execution', fixture: folder, reportSha256: digest(fs.readFileSync(reportFile)), baselineSourceSha256: digest(runner), controlledSourceSha256: digest(controlled), exactInverse: true, normalChildren: normal, browserOptInChildren: all, effectiveAddedChildren: five, totalActualChildReceipts: 31, installedTypeScript: { version: installed.version, main: installed.main, mainSha256: digest(fs.readFileSync('node_modules/typescript/' + installed.main)) }, rawFiles }, null, 2));
console.log('Actual selection proof PASS: 6 default node children, all 14 browser opt-in children and exactly 5 effective copied dynamic-import additions.');
console.log('All 31 child marker/PASS receipts, full fixture sources, concrete helper bytes and locked installed TypeScript binding are retained.');
