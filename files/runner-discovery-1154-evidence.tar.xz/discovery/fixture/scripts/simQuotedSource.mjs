const _dukbDiscovery = await import('node:fs');
_dukbDiscovery.appendFileSync(process.env.DISCOVERY_MARKER, JSON.stringify({file:"simQuotedSource.mjs",only:process.env.ONLY??null,browser:process.env.BROWSER??null,base:process.env.BASE??null,sweep:process.env.SWEEP_BASE??null})+'\n');
console.log("simQuotedSource.mjs\nOwned child selected\nNo game or browser executed\nSelection receipt complete");
process.exit(0);
const example = "await import('./lib/playwrightLoader.mjs')";