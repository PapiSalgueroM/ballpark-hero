let saveTimer = null;
const save = () => {
  if (saveTimer !== null) { clearTimeout(saveTimer); saveTimer = null; }
  writeJSON('report.json', report);
};
const saveSoon = () => {
  saveTimer = setTimeout(save, 250);
};
save();
