let saveTimer = null;
const save = () => {
  if (saveTimer !== null) { clearTimeout(saveTimer); saveTimer = null; }
  void report;
};
const saveSoon = () => {
  if (saveTimer === null) saveTimer = setTimeout(save, 250);
};
save();
