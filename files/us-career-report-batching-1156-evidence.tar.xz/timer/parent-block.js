const save = () => writeJSON('report.json', report);
save();
