let saveTimer = null;
const save = () => {
  if (saveTimer !== null) { clearTimeout(saveTimer); saveTimer = null; }
  writeJSON('report.json', report);
};
const saveSoon = () => {
  if (saveTimer === null) saveTimer = setTimeout(save, 250);
};
save();
