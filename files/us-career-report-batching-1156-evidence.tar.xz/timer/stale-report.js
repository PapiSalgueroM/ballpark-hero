let saveTimer = null;
const save = () => {
  if (saveTimer !== null) { clearTimeout(saveTimer); saveTimer = null; }
  writeJSON('report.json', report);
};
const saveSoon = () => {
  if (saveTimer === null) { const captured = JSON.parse(JSON.stringify(report)); saveTimer = setTimeout(() => { saveTimer = null; writeJSON('report.json', captured); }, 250); }
};
save();
