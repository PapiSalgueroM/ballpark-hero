import React from 'react';
import {createRoot} from 'react-dom/client';
import {FacilitiesScreen} from "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/FacilitiesScreen.tsx";
import {upgradeFacility} from "/home/runner/work/ballpark-hero/ballpark-hero/src/lib/clubManagerFacilities.ts";
export function mount(fixture){
 let current=JSON.parse(JSON.stringify(fixture)), calls=[];
 const view=createRoot(document.getElementById('fixture-root'));
 function render(){view.render(<FacilitiesScreen career={current} onUpgrade={id=>{
  calls.push(id); const next=upgradeFacility(current,id); if(next){current=next;render();}
 }}/>);}
 window.__facilities1158={snapshot:()=>({career:JSON.parse(JSON.stringify(current)),calls:[...calls]})};
 render();
}