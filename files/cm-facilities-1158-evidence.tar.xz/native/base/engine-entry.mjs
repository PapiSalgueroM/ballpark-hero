globalThis.localStorage={getItem:()=>null,setItem:()=>{},removeItem:()=>{}};
export const engine=await import("/home/runner/work/_temp/facilities-1158.23Fuw1/base-root/src/lib/clubManager.ts");
export const facilities=await import("/home/runner/work/_temp/facilities-1158.23Fuw1/base-root/src/lib/clubManagerFacilities.ts");