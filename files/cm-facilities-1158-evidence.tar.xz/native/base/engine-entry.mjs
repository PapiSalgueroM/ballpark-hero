globalThis.localStorage={getItem:()=>null,setItem:()=>{},removeItem:()=>{}};
export const engine=await import("/home/runner/work/_temp/facilities-1158.X7DMz5/base-root/src/lib/clubManager.ts");
export const facilities=await import("/home/runner/work/_temp/facilities-1158.X7DMz5/base-root/src/lib/clubManagerFacilities.ts");