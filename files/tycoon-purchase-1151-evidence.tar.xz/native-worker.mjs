import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';

const hash = value => createHash('sha256').update(value).digest('hex');
const save = (file, value) => fs.writeFileSync(file, JSON.stringify(value, null, 2));

async function main() {
  assert.equal(process.env.GITHUB_ACTIONS, 'true', 'Remote-only worker');
  const out = path.join(process.env.E, 'native');
  fs.mkdirSync(out, { recursive: true });
  const candidateRoot = process.cwd(), baseRoot = process.env.BASE_ROOT;
  const require = createRequire(path.join(candidateRoot, 'package.json'));
  const { chromium } = require('playwright'), { build } = require('esbuild');
  const epoch = Date.UTC(2026, 0, 1, 12);
  const core = ['src/pages/StadiumTycoon.tsx', 'src/hooks/useStadiumTycoon.ts', 'src/lib/stadiumTycoon.ts', 'src/components/tycoon/TicketPolicyCard.tsx', 'src/main.tsx'];
  const executable = chromium.executablePath(); assert(executable.startsWith(process.env.PLAYWRIGHT_BROWSERS_PATH + path.sep));
  const servers = [], browser = await chromium.launch({ headless: true, executablePath: executable });
  save(path.join(out, 'browser-runtime.json'), { version: browser.version(), executablePath: executable, executableSha256: hash(fs.readFileSync(executable)), privateCache: process.env.PLAYWRIGHT_BROWSERS_PATH });
  const results = [];
  try {
    for (const [variant, root] of [['candidate', candidateRoot], ['base', baseRoot]]) {
      const variantOut = path.join(out, variant); fs.mkdirSync(variantOut, { recursive: true });
      const bundle = path.join(variantOut, 'actual-engine.mjs');
      await build({ absWorkingDir: root, entryPoints: ['src/lib/stadiumTycoon.ts'], outfile: bundle, bundle: true, platform: 'node', format: 'esm', tsconfig: 'tsconfig.app.json' });
      const engine = await import(pathToFileURL(bundle).href);
      const zeroPerks = Object.fromEntries(engine.LEGACY_PERKS.map(p => [p.id, 0]));
      assert.deepEqual(Object.keys(zeroPerks).sort(), ['away', 'charm', 'payroll', 'rolling', 'roots', 'shield', 'sway', 'voltage']);
      assert(Object.values(zeroPerks).every(level => level === 0));
      const dist = path.join(root, 'dist'), records = [], maps = [], seen = new Set();
      for (const name of fs.readdirSync(path.join(dist, 'assets')).filter(n => n.endsWith('.map'))) {
        const raw = fs.readFileSync(path.join(dist, 'assets', name)), map = JSON.parse(raw), bindings = [];
        assert.equal(map.sources.length, map.sourcesContent.length);
        for (let i = 0; i < map.sources.length; i++) for (const source of core) if (map.sources[i].replaceAll('\\', '/').endsWith('/' + source)) {
          assert.equal(hash(Buffer.from(map.sourcesContent[i])), hash(fs.readFileSync(path.join(root, source))), source);
          seen.add(source); bindings.push({ source, sha256: hash(fs.readFileSync(path.join(root, source))) });
        }
        if (!bindings.length) continue;
        const jsName = name.slice(0, -4), js = fs.readFileSync(path.join(dist, 'assets', jsName));
        assert(js.toString().includes('//# sourceMappingURL=' + name));
        fs.mkdirSync(path.join(variantOut, 'core-dist', 'assets'), { recursive: true });
        for (const file of [name, jsName]) fs.copyFileSync(path.join(dist, 'assets', file), path.join(variantOut, 'core-dist', 'assets', file));
        maps.push({ map: name, mapSha256: hash(raw), url: '/assets/' + jsName, jsSha256: hash(js), bindings });
      }
      assert.deepEqual([...seen].sort(), [...core].sort()); save(path.join(variantOut, 'core-maps.json'), maps);
      fs.copyFileSync(path.join(dist, 'index.html'), path.join(variantOut, 'built-spa-index.html'));
      const payloadDir = path.join(variantOut, 'served-payloads'); fs.mkdirSync(payloadDir);
      const server = http.createServer((req, res) => {
        try {
          assert.equal(req.method, 'GET');
          const url = new URL(req.url, 'http://localhost'), requestPath = decodeURIComponent(url.pathname);
          const relative = requestPath === '/stadium-tycoon' || requestPath === '/stadium-tycoon/' ? 'index.html' : requestPath.replace(/^\/+/, '');
          const file = path.resolve(dist, relative);
          assert(file.startsWith(dist + path.sep));
          const bytes = fs.readFileSync(file), sha256 = hash(bytes);
          fs.writeFileSync(path.join(payloadDir, sha256), bytes);
          records.push({ method: req.method, url: requestPath, file: path.relative(dist, file).replaceAll('\\', '/'), sha256, bytes: bytes.length, delivery: relative === 'index.html' ? 'built-spa' : 'dist-file' });
          const ext = path.extname(file), contentType = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.svg': 'image/svg+xml' }[ext] || 'application/octet-stream';
          res.writeHead(200, { 'Content-Type': contentType, 'Cache-Control': 'no-store' }); res.end(bytes);
        } catch (error) { records.push({ method: req.method, url: req.url, error: String(error) }); res.writeHead(404); res.end('Unavailable'); }
      });
      await new Promise(resolve => server.listen(0, '127.0.0.1', resolve)); servers.push(server);
      const origin = 'http://127.0.0.1:' + server.address().port;
      const cases = variant === 'candidate'
        ? [[320, 'rolling'], [1280, 'rolling'], [320, 'roots'], [1280, 'roots'], [320, 'disabled'], [320, 'maxed']]
        : [[320, 'duplicate'], [1280, 'duplicate']];
      for (const [width, action] of cases) {
        const name = variant + '-' + width + '-' + action, dir = path.join(out, name); fs.mkdirSync(dir);
        const fixture = engine.newTycoon(epoch); fixture.legacyPoints = action === 'disabled' ? 0 : 3;
        if (action === 'maxed') fixture.legacyPerks = Object.fromEntries(engine.LEGACY_PERKS.map(p => [p.id, p.costs.length]));
        const originalRaw = engine.serializeTycoon(fixture, epoch); fs.writeFileSync(path.join(dir, 'original-engine-fixture.json'), originalRaw);
        const canonical = engine.deserializeTycoon(originalRaw, epoch); assert(canonical);
        const expectedPerks = action === 'maxed' ? fixture.legacyPerks : zeroPerks;
        assert.equal(canonical.legacyPoints, action === 'disabled' ? 0 : 3); assert.deepEqual(canonical.legacyPerks, expectedPerks);
        const raw = engine.serializeTycoon(canonical, epoch), restored = engine.deserializeTycoon(raw, epoch);
        assert(restored); assert.deepEqual(restored, canonical);
        fs.writeFileSync(path.join(dir, 'engine-fixture.json'), raw);
        const row = { name, variant, width, action, fixtureSha256: hash(raw), status: 'failed', pageErrors: [], localFailures: [], localRequests: [], blocked: [], sockets: [], checks: {} };
        let context, page;
        const snapshot = async label => {
          const board = page.locator('[data-legacy-board]');
          const data = await board.evaluate(el => ({ html: el.outerHTML, text: el.innerText, rows: [...el.querySelectorAll('[data-perk]')].map(node => ({ id: node.getAttribute('data-perk'), text: node.innerText, className: node.className, button: node.querySelector('button') ? { text: node.querySelector('button').textContent, className: node.querySelector('button').className, label: node.querySelector('button').getAttribute('aria-label'), disabled: node.querySelector('button').disabled } : null })) }));
          data.aria = await board.ariaSnapshot(); data.rawSave = await page.evaluate(key => localStorage.getItem(key), engine.TYCOON_SAVE_KEY);
          data.clock = await page.evaluate(() => ({ dateNow: Date.now(), performanceNow: performance.now() })); assert.equal(data.clock.dateNow, epoch);
          data.geometry = await board.evaluate(el => { const r = el.getBoundingClientRect(); return { x: r.x, width: r.width, documentWidth: document.documentElement.scrollWidth, viewportWidth: innerWidth }; });
          save(path.join(dir, label + '.json'), data); await board.screenshot({ path: path.join(dir, label + '.png') }); return data;
        };
        try {
          context = await browser.newContext({ viewport: { width, height: 900 } });
          await context.routeWebSocket('**/*', socket => { row.sockets.push(socket.url()); socket.close(); });
          await context.route('**/*', async route => {
            const request = route.request(), url = request.url();
            if (!url.startsWith(origin + '/')) { row.blocked.push({ url, method: request.method() }); await route.abort(); return; }
            row.localRequests.push({ url: new URL(url).pathname, method: request.method() });
            if (request.method() !== 'GET') { row.localFailures.push({ url, error: 'Unexpected local write' }); await route.abort(); return; }
            await route.continue();
          });
          await context.addInitScript(({ raw, key }) => { localStorage.setItem(key, raw); localStorage.setItem('cookie-consent', 'essential'); }, { raw, key: engine.TYCOON_SAVE_KEY });
          page = await context.newPage();
          await page.clock.install({ time: epoch - 1000 }); await page.clock.pauseAt(epoch);
          page.on('pageerror', error => row.pageErrors.push({ name: error.name, message: error.message, stack: error.stack }));
          page.on('requestfailed', request => { if (request.url().startsWith(origin + '/')) row.localFailures.push({ url: request.url(), error: request.failure() }); });
          page.on('response', response => { if (response.url().startsWith(origin + '/') && response.status() >= 400) row.localFailures.push({ url: response.url(), status: response.status() }); });
          await page.goto(origin + '/stadium-tycoon', { waitUntil: 'networkidle' });
          await page.getByRole('heading', { name: 'STADIUM TYCOON', exact: true }).waitFor();
          await page.locator('[data-office-panel="legacy"]').click();
          await page.locator('[data-legacy-board]').waitFor();
          row.before = await snapshot('before'); assert.equal(row.before.rows.length, 8);
          const rollingName = 'Buy Rolling Investment, level 1, 1 pt', rootsName = 'Buy Deep Roots, level 1, 1 pt';
          const assertNamed = async name => {
            const button = page.getByRole('button', { name, exact: true });
            assert.equal(await button.count(), 1, 'Exactly one native purchase button named ' + name);
            assert.equal(await button.textContent(), '1 pt');
          };
          if (action === 'duplicate') {
            assert.equal(await page.locator('[data-legacy-board]').getByRole('button', { name: '1 pt', exact: true }).count(), 2);
            assert.equal(await page.getByRole('button', { name: rollingName, exact: true }).count(), 0);
            assert.equal(await page.getByRole('button', { name: rootsName, exact: true }).count(), 0);
            let intendedFailure;
            try { await assertNamed(rollingName); } catch (error) { intendedFailure = error; }
            assert(intendedFailure); assert.equal(intendedFailure.name, 'AssertionError'); assert.equal(intendedFailure.actual, 0); assert.equal(intendedFailure.expected, 1);
            assert(intendedFailure.message.includes('Exactly one native purchase button named ' + rollingName));
            row.intendedNameFailure = { name: intendedFailure.name, message: intendedFailure.message, actual: intendedFailure.actual, expected: intendedFailure.expected };
            assert(row.before.rows.filter(r => r.id === 'rolling' || r.id === 'roots').every(r => r.button.text === '1 pt' && r.button.label === null && !r.button.disabled));
            const actual = engine.deserializeTycoon(row.before.rawSave, epoch); assert(actual); assert.equal(actual.legacyPoints, 3); assert.deepEqual(actual.legacyPerks, zeroPerks);
            row.checks = { unchangedBase: true, duplicateNames: 2, namedPerkButtons: 0, intendedNameContractFailed: true, unrelatedBoardAndSaveBaselinePassed: true };
          } else if (action === 'maxed') {
            assert.equal(await page.locator('[data-legacy-board] button').count(), 0);
            assert(row.before.rows.every(r => r.text.includes('MAXED') && r.button === null));
            for (const p of engine.LEGACY_PERKS) assert.equal(engine.perkCostOf(restored, p.id), null);
            row.checks = { maxedRows: 8, purchaseButtons: 0 };
          } else {
            for (const name of [rollingName, rootsName]) await assertNamed(name);
            if (action === 'disabled') {
              assert(await page.getByRole('button', { name: rollingName, exact: true }).isDisabled()); assert(await page.getByRole('button', { name: rootsName, exact: true }).isDisabled());
              row.after = await snapshot('after'); const actual = engine.deserializeTycoon(row.after.rawSave, epoch); assert.equal(actual.legacyPoints, 0); assert.deepEqual(actual.legacyPerks, zeroPerks);
              row.checks = { namedDisabledButtons: 2, points: 0, noPerkBought: true };
            } else {
              const name = action === 'rolling' ? rollingName : rootsName, button = page.getByRole('button', { name, exact: true }); assert(await button.isEnabled());
              await button.focus(); assert(await button.evaluate(el => el === document.activeElement)); await button.press('Enter');
              const nextName = action === 'rolling' ? 'Buy Rolling Investment, level 2, 2 pts' : 'Buy Deep Roots, level 2, 3 pts';
              const next = page.getByRole('button', { name: nextName, exact: true }); await next.waitFor();
              const before = engine.deserializeTycoon(row.before.rawSave, epoch); assert(before);
              const expected = engine.buyPerk(before, action); assert.notDeepEqual(expected, before);
              const expectedRaw = engine.serializeTycoon(expected, epoch); fs.writeFileSync(path.join(dir, 'expected-engine-save.json'), expectedRaw);
              row.after = await snapshot('after'); const actual = engine.deserializeTycoon(row.after.rawSave, epoch); assert(actual);
              assert.equal(row.after.clock.performanceNow, row.before.clock.performanceNow); assert.deepEqual(actual, expected);
              row.expectedEngineSaveSha256 = hash(expectedRaw);
              assert.equal(actual.legacyPoints, 2); assert.equal(engine.perkLevelOf(actual, action), 1); assert.equal(engine.perkLevelOf(actual, action === 'rolling' ? 'roots' : 'rolling'), 0);
              assert.equal(engine.perkCostOf(actual, action), action === 'rolling' ? 2 : 3); assert.equal(await next.isDisabled(), action === 'roots');
              row.checks = { enterActivated: true, pointsBefore: 3, pointsAfter: 2, selectedLevel: 1, otherLevel: 0, nextCost: action === 'rolling' ? 2 : 3, nextDisabled: action === 'roots' };
            }
          }
          const requested = new Set(row.localRequests.filter(r => r.method === 'GET').map(r => r.url));
          for (const map of maps) assert(requested.has(map.url), 'Case loaded actual core built JS: ' + map.url);
          row.status = 'passed';
        } catch (error) { row.error = { name: error.name, message: error.message, stack: error.stack }; }
        finally {
          if (context) try { await context.close(); } catch (error) { row.closeError = String(error); row.status = 'failed'; }
          if (row.pageErrors.length || row.localFailures.length) row.status = 'failed';
          save(path.join(dir, 'result.json'), row); results.push(row);
          save(path.join(out, 'partial-summary.json'), { executionComplete: false, results });
        }
      }
      save(path.join(variantOut, 'served.json'), records);
      assert(records.every(r => !r.error));
      for (const row of results.filter(r => r.variant === variant)) for (const req of row.localRequests) assert(records.some(r => r.url === req.url && r.method === req.method && !r.error));
    }
    for (const width of [320, 1280]) {
      const base = results.find(r => r.name === 'base-' + width + '-duplicate'), candidate = results.find(r => r.name === 'candidate-' + width + '-rolling');
      assert(base && candidate); assert.deepEqual(candidate.before.rows.map(({ button, ...r }) => ({ ...r, button: button && { text: button.text, className: button.className, disabled: button.disabled } })), base.before.rows.map(({ button, ...r }) => ({ ...r, button: button && { text: button.text, className: button.className, disabled: button.disabled } })));
      assert.equal(candidate.before.geometry.width, base.before.geometry.width); assert.equal(candidate.before.geometry.documentWidth, base.before.geometry.documentWidth);
    }
    assert.equal(results.filter(r => r.variant === 'candidate').length, 6); assert.equal(results.filter(r => r.variant === 'base').length, 2); assert(results.every(r => r.status === 'passed'));
    save(path.join(out, 'summary.json'), { executionComplete: true, healthy: 6, effectiveBaseControls: 2, results });
    console.log('Native1151 PASS: six actual candidate cases and two unchanged-base name controls. Enter purchases persist real selected perk and actual next costs.');
  } finally { await browser.close(); for (const server of servers) await new Promise(resolve => server.close(resolve)); }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
