// src/lib/leagueCore.ts
function roundRobinCalendar(n) {
  const teams = Array.from({ length: n }, (_, i) => i);
  if (n % 2 === 1) teams.push(-1);
  const half = teams.length / 2;
  const firstLeg = [];
  for (let round = 0; round < teams.length - 1; round++) {
    for (let k = 0; k < half; k++) {
      const a = teams[k];
      const b = teams[teams.length - 1 - k];
      if (a === -1 || b === -1) continue;
      firstLeg.push(round % 2 === 0 ? [a, b] : [b, a]);
    }
    teams.splice(1, 0, teams.pop());
  }
  return [...firstLeg, ...firstLeg.map(([h, a]) => [a, h])];
}
var tableOrder = (a, b) => b.pts - a.pts || b.gf - b.ga - (a.gf - a.ga) || b.gf - a.gf;
function mulberry32(seed) {
  let s = seed | 0;
  return () => {
    s = s + 1831565813 | 0;
    let t = Math.imul(s ^ s >>> 15, 1 | s);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
function hash32(...parts) {
  let h = 2166136261;
  for (const p of parts) {
    h ^= p | 0;
    h = Math.imul(h, 16777619);
    h ^= h >>> 13;
    h = Math.imul(h, 1540483477);
    h ^= h >>> 15;
  }
  return h >>> 0;
}

// src/lib/stadiumTycoon.ts
var TRACKS = [
  { id: "stands", name: "Stands", emoji: "\u{1F3DF}\uFE0F", blurb: "Seats. Every level adds room for 40 more fans", baseCost: 30, growth: 1.15, maxLevel: 200 },
  { id: "tickets", name: "Ticket Office", emoji: "\u{1F39F}\uFE0F", blurb: "Faster turnstiles, better prices per fan", baseCost: 25, growth: 1.14, maxLevel: 200 },
  { id: "snacks", name: "Snack Bar", emoji: "\u{1F32D}", blurb: "Every fan buys a little more each second", baseCost: 60, growth: 1.14, maxLevel: 200 },
  { id: "shop", name: "Club Shop", emoji: "\u{1F455}", blurb: "Scarves and shirts, higher spend per fan", baseCost: 220, growth: 1.16, maxLevel: 200 },
  { id: "parking", name: "Parking", emoji: "\u{1F697}", blurb: "Flat matchday money that never has a bad day", baseCost: 120, growth: 1.15, maxLevel: 200 },
  { id: "lights", name: "Floodlights", emoji: "\u{1F4A1}", blurb: "Night games. New fans find the club faster", baseCost: 400, growth: 1.165, maxLevel: 150 },
  { id: "squad", name: "Squad", emoji: "\u26BD", blurb: "Better players, more goals, longer win runs", baseCost: 150, growth: 1.16, maxLevel: 200 },
  { id: "academy", name: "Academy", emoji: "\u{1F331}", blurb: "Kids and community. The fanbase grows on its own", baseCost: 900, growth: 1.175, maxLevel: 150 },
  { id: "megaphone", name: "Megaphone", emoji: "\u{1F4E3}", blurb: "Your taps on the stadium hype the crowd for more", baseCost: 45, growth: 1.17, maxLevel: 120 }
];
var DIVISIONS = [
  { name: "Muddy Meadows League", emoji: "\u{1F327}\uFE0F", winsNeeded: 0, incomeMult: 1, oppBoost: 0 },
  { name: "Gravel Lane League", emoji: "\u{1F9F1}", winsNeeded: 6, incomeMult: 1.15, oppBoost: 6e-3 },
  { name: "Tin Cup Division", emoji: "\u{1F96B}", winsNeeded: 14, incomeMult: 1.32, oppBoost: 0.012 },
  { name: "Ironworks League", emoji: "\u2699\uFE0F", winsNeeded: 25, incomeMult: 1.55, oppBoost: 0.019 },
  { name: "Granite Division", emoji: "\u{1FAA8}", winsNeeded: 40, incomeMult: 1.85, oppBoost: 0.027 },
  { name: "Silverline League", emoji: "\u{1F948}", winsNeeded: 60, incomeMult: 2.25, oppBoost: 0.036 },
  { name: "Floodlit League", emoji: "\u{1F4A1}", winsNeeded: 85, incomeMult: 2.8, oppBoost: 0.046 },
  { name: "Velvet Division", emoji: "\u{1F3A9}", winsNeeded: 115, incomeMult: 3.5, oppBoost: 0.057 },
  { name: "Crown Circuit", emoji: "\u{1F451}", winsNeeded: 150, incomeMult: 4.4, oppBoost: 0.069 },
  { name: "The Summit", emoji: "\u{1F3D4}\uFE0F", winsNeeded: 200, incomeMult: 5.5, oppBoost: 0.082 }
];
function divisionIndex(s) {
  if (s.league) return Math.min(DIVISIONS.length - 1, Math.max(0, s.league.division | 0));
  return legacyDivisionIndex(s.groundWins ?? 0);
}
function legacyDivisionIndex(groundWins) {
  let idx = 0;
  for (let i = 0; i < DIVISIONS.length; i++) {
    if (groundWins >= DIVISIONS[i].winsNeeded) idx = i;
  }
  return idx;
}
function divisionOf(s) {
  return DIVISIONS[divisionIndex(s)];
}
var STAFF = [
  { id: "steward", name: "Turnstile Steward", emoji: "\u{1F9CD}", blurb: "Keeps the queue moving and the coins counted", baseCost: 100, growth: 1.13, rate: 0.6, maxLevel: 300 },
  { id: "pieChef", name: "Pie Chef", emoji: "\u{1F468}\u200D\u{1F373}", blurb: "The half time pie that people cross town for", baseCost: 650, growth: 1.13, rate: 3.5, maxLevel: 300 },
  { id: "kitman", name: "Kit Man", emoji: "\u{1F9FA}", blurb: "Shirts washed, boots ready, fines for lost socks", baseCost: 3500, growth: 1.13, rate: 16, maxLevel: 300 },
  { id: "groundsman", name: "Groundskeeper", emoji: "\u{1F331}", blurb: "A pitch so good visiting teams ask for a photo", baseCost: 18e3, growth: 1.135, rate: 70, maxLevel: 300 },
  { id: "photographer", name: "Club Photographer", emoji: "\u{1F4F7}", blurb: "Every goal framed and sold by the exit", baseCost: 95e3, growth: 1.135, rate: 300, maxLevel: 300 },
  { id: "megastore", name: "Megastore Manager", emoji: "\u{1F3EC}", blurb: "Third kits, fourth kits, a candle that smells of grass", baseCost: 52e4, growth: 1.14, rate: 1300, maxLevel: 300 },
  { id: "commercial", name: "Commercial Director", emoji: "\u{1F4BC}", blurb: "Shakes hands, signs deals, never watches the match", baseCost: 28e5, growth: 1.14, rate: 5800, maxLevel: 300 },
  { id: "legend", name: "Club Legend Ambassador", emoji: "\u{1F410}", blurb: "Retired, beloved, worth a stand full of season ticket renewals", baseCost: 15e6, growth: 1.145, rate: 26e3, maxLevel: 300 }
];
function staffById(id) {
  return STAFF.find((t) => t.id === id) ?? STAFF[0];
}
function staffLevelOf(s, id) {
  return (s.staffLevels ?? {})[id] ?? 0;
}
function staffCostOf(s, id) {
  const t = staffById(id);
  return Math.round(t.baseCost * Math.pow(t.growth, staffLevelOf(s, id)));
}
function canHire(s, id) {
  return staffLevelOf(s, id) < staffById(id).maxLevel && s.money >= staffCostOf(s, id);
}
function hire(s, id) {
  if (!canHire(s, id)) return s;
  const cost = staffCostOf(s, id);
  return {
    ...s,
    money: s.money - cost,
    staffLevels: { ...s.staffLevels ?? {}, [id]: staffLevelOf(s, id) + 1 }
  };
}
function totalStaffLevels(s) {
  return STAFF.reduce((sum, t) => sum + staffLevelOf(s, t.id), 0);
}
function staffBaseIncome(s) {
  return STAFF.reduce((sum, t) => sum + staffLevelOf(s, t.id) * t.rate, 0) * payrollMult(s);
}
var FRENZY_MULT = 7;
var TAP_RUSH_MULT = 25;
var GOLDEN_INFO = {
  frenzy: { label: "DERBY DAY", blurb: `income pays x${FRENZY_MULT}`, duration: 77 },
  tapRush: { label: "CROWD SURGE", blurb: `taps pay x${TAP_RUSH_MULT}`, duration: 30 },
  windfall: { label: "TV WINDFALL", blurb: "fifteen minutes of income, instantly", duration: 0 },
  fanWave: { label: "WONDERGOAL GOES VIRAL", blurb: "the fanbase jumps", duration: 0 },
  freeLevel: { label: "SPONSOR GIFT", blurb: "a free upgrade level", duration: 0 }
};
function rollGoldenKind(roll) {
  const r = roll();
  if (r < 0.34) return "frenzy";
  if (r < 0.54) return "tapRush";
  if (r < 0.79) return "windfall";
  if (r < 0.91) return "fanWave";
  return "freeLevel";
}
function goldenActive(s) {
  return (s.goldenLeftSec ?? 0) > 0 && !!s.goldenKind;
}
var WINDFALL_SEC = 900;
var GOLDEN_CATCH_SEC = 12;
var GOLDEN_MEAN_GAP_SEC = 150;
function catchGolden(s, kind) {
  if (goldenActive(s)) return { state: s };
  const st = { ...s, goldenCaught: (s.goldenCaught ?? 0) + 1 };
  if (kind === "frenzy" || kind === "tapRush") {
    st.goldenKind = kind;
    st.goldenLeftSec = GOLDEN_INFO[kind].duration * charmMult(s);
    return { state: st };
  }
  if (kind === "windfall") {
    const pay = Math.round(Math.min(incomePerSec(s) * WINDFALL_SEC, 1e15));
    st.money += pay;
    st.lifetime += pay;
    return { state: st, amount: pay };
  }
  if (kind === "fanWave") {
    const bump = Math.max(50, Math.round(s.fanbase * 0.12));
    st.fanbase = s.fanbase + bump;
    return { state: st, amount: bump };
  }
  const open = TRACKS.filter((t) => levelOf(s, t.id) < t.maxLevel);
  if (!open.length) return { state: st };
  const cheapest = open.sort((a, b) => costOf(s, a.id) - costOf(s, b.id))[0];
  st.levels = { ...st.levels, [cheapest.id]: levelOf(s, cheapest.id) + 1 };
  return { state: st };
}
var ACH_BONUS = 0.02;
var ACHIEVEMENTS = [
  // The fanbase.
  { id: "af500", label: "500 fans", emoji: "\u{1F465}", hit: (s) => s.fanbase >= 500 },
  { id: "af2k", label: "2,000 fans", emoji: "\u{1F465}", hit: (s) => s.fanbase >= 2e3 },
  { id: "af10k", label: "10,000 fans", emoji: "\u{1F465}", hit: (s) => s.fanbase >= 1e4 },
  { id: "af50k", label: "50,000 fans", emoji: "\u{1F306}", hit: (s) => s.fanbase >= 5e4 },
  { id: "af250k", label: "A quarter million fans", emoji: "\u{1F307}", hit: (s) => s.fanbase >= 25e4 },
  { id: "af1m", label: "A million fans", emoji: "\u{1F30D}", hit: (s) => s.fanbase >= 1e6 },
  // The ground.
  { id: "ac500", label: "500 seats", emoji: "\u{1F3DF}\uFE0F", hit: (s) => capacity(s) >= 500 },
  { id: "ac2000", label: "2,000 seats", emoji: "\u{1F3DF}\uFE0F", hit: (s) => capacity(s) >= 2e3 },
  { id: "ac8000", label: "8,000 seats", emoji: "\u{1F3DF}\uFE0F", hit: (s) => capacity(s) >= 8e3 },
  // Wins, career.
  { id: "aw1", label: "First career win", emoji: "\u{1F3C1}", hit: (s) => s.totalWins >= 1 },
  { id: "aw10", label: "10 career wins", emoji: "\u{1F3C1}", hit: (s) => s.totalWins >= 10 },
  { id: "aw50", label: "50 career wins", emoji: "\u{1F3C1}", hit: (s) => s.totalWins >= 50 },
  { id: "aw150", label: "150 career wins", emoji: "\u{1F3C6}", hit: (s) => s.totalWins >= 150 },
  { id: "aw400", label: "400 career wins", emoji: "\u{1F3C6}", hit: (s) => s.totalWins >= 400 },
  // Goals.
  { id: "ag25", label: "25 goals", emoji: "\u26BD", hit: (s) => s.totalGoals >= 25 },
  { id: "ag100", label: "100 goals", emoji: "\u26BD", hit: (s) => s.totalGoals >= 100 },
  { id: "ag500", label: "500 goals", emoji: "\u26BD", hit: (s) => s.totalGoals >= 500 },
  { id: "ag2000", label: "2,000 goals", emoji: "\u{1F945}", hit: (s) => s.totalGoals >= 2e3 },
  // Streaks.
  { id: "as5", label: "Five straight wins", emoji: "\u{1F525}", hit: (s) => s.streak >= 5 },
  { id: "as10", label: "Ten straight wins", emoji: "\u{1F525}", hit: (s) => s.streak >= 10 },
  // Taps.
  { id: "at100", label: "100 taps", emoji: "\u{1F446}", hit: (s) => s.totalTaps >= 100 },
  { id: "at1k", label: "1,000 taps", emoji: "\u{1F446}", hit: (s) => s.totalTaps >= 1e3 },
  { id: "at10k", label: "10,000 taps", emoji: "\u{1F590}\uFE0F", hit: (s) => s.totalTaps >= 1e4 },
  // Money, lifetime this ground.
  { id: "am10k", label: "$10K lifetime", emoji: "\u{1F4B5}", hit: (s) => s.lifetime >= 1e4 },
  { id: "am1m", label: "$1M lifetime", emoji: "\u{1F4B0}", hit: (s) => s.lifetime >= 1e6 },
  { id: "am100m", label: "$100M lifetime", emoji: "\u{1F4B0}", hit: (s) => s.lifetime >= 1e8 },
  { id: "am10b", label: "$10B lifetime", emoji: "\u{1F911}", hit: (s) => s.lifetime >= 1e10 },
  { id: "am1t", label: "$1T lifetime", emoji: "\u{1F3E6}", hit: (s) => s.lifetime >= 1e12 },
  // Matches.
  { id: "amt25", label: "25 matches played", emoji: "\u{1F4C5}", hit: (s) => (s.totalMatches ?? 0) >= 25 },
  { id: "amt100", label: "100 matches played", emoji: "\u{1F4C5}", hit: (s) => (s.totalMatches ?? 0) >= 100 },
  { id: "amt400", label: "400 matches played", emoji: "\u{1F4C5}", hit: (s) => (s.totalMatches ?? 0) >= 400 },
  // Staff.
  { id: "ast10", label: "10 staff hired", emoji: "\u{1F9D1}\u200D\u{1F91D}\u200D\u{1F9D1}", hit: (s) => totalStaffLevels(s) >= 10 },
  { id: "ast50", label: "50 staff hired", emoji: "\u{1F9D1}\u200D\u{1F91D}\u200D\u{1F9D1}", hit: (s) => totalStaffLevels(s) >= 50 },
  { id: "ast150", label: "150 staff hired", emoji: "\u{1F3E2}", hit: (s) => totalStaffLevels(s) >= 150 },
  { id: "astall", label: "Every role filled at least once", emoji: "\u{1F4CB}", hit: (s) => STAFF.every((t) => staffLevelOf(s, t.id) >= 1) },
  // Divisions (career best, survives selling up).
  { id: "ad2", label: "Reach the Tin Cup Division", emoji: "\u{1F96B}", hit: (s) => (s.bestDivision ?? 0) >= 2 },
  { id: "ad4", label: "Reach the Granite Division", emoji: "\u{1FAA8}", hit: (s) => (s.bestDivision ?? 0) >= 4 },
  { id: "ad6", label: "Reach the Floodlit League", emoji: "\u{1F4A1}", hit: (s) => (s.bestDivision ?? 0) >= 6 },
  { id: "ad8", label: "Reach the Crown Circuit", emoji: "\u{1F451}", hit: (s) => (s.bestDivision ?? 0) >= 8 },
  { id: "ad9", label: "Reach The Summit", emoji: "\u{1F3D4}\uFE0F", hit: (s) => (s.bestDivision ?? 0) >= 9 },
  // Reputation.
  { id: "ar1", label: "First reputation star", emoji: "\u2B50", hit: (s) => s.rep >= 1 },
  { id: "ar3", label: "Three reputation stars", emoji: "\u2B50", hit: (s) => s.rep >= 3 },
  { id: "ar6", label: "Six reputation stars", emoji: "\u{1F31F}", hit: (s) => s.rep >= 6 },
  // Hype and gold.
  { id: "ab3", label: "Three hype boosts pressed", emoji: "\u{1F4E3}", hit: (s) => (s.boostsUsed ?? 0) >= 3 },
  { id: "ab20", label: "Twenty hype boosts pressed", emoji: "\u{1F4E3}", hit: (s) => (s.boostsUsed ?? 0) >= 20 },
  { id: "agw5", label: "Five golden whistles caught", emoji: "\u{1FA99}", hit: (s) => (s.goldenCaught ?? 0) >= 5 },
  { id: "agw25", label: "Twenty five golden whistles caught", emoji: "\u{1FA99}", hit: (s) => (s.goldenCaught ?? 0) >= 25 }
];
function achMult(s) {
  return 1 + (s.ach ?? []).length * ACH_BONUS;
}
var LEGACY_PERKS = [
  { id: "sway", name: "Boardroom Sway", emoji: "\u{1F3DB}\uFE0F", blurb: "Matchday income pays 10% more per level, forever", costs: [3, 5, 8, 12, 17] },
  { id: "rolling", name: "Rolling Investment", emoji: "\u{1F4BC}", blurb: "Every next ground opens with seed money in the till", costs: [1, 2, 4] },
  { id: "roots", name: "Deep Roots", emoji: "\u{1F331}", blurb: "The fanbase grows 15% faster per level, every ground", costs: [1, 3, 6] },
  { id: "payroll", name: "Veteran Payroll", emoji: "\u{1F9D1}\u200D\u{1F4BC}", blurb: "Every staff member earns 20% more per level", costs: [2, 4, 8] },
  { id: "shield", name: "Steady Dressing Room", emoji: "\u{1F9E4}", blurb: "A loss keeps half the win streak instead of ending it", costs: [3] },
  { id: "away", name: "Away Day Deal", emoji: "\u{1F68C}", blurb: "Away pay rises to 65 then 80 percent, trips cap at 10 then 12 hours", costs: [2, 4] },
  { id: "voltage", name: "Stadium Voltage", emoji: "\u26A1", blurb: "Matchday Hype charges a full minute faster per level", costs: [2, 4] },
  { id: "charm", name: "Gold Polish", emoji: "\u{1FA99}", blurb: "Timed golden whistles run 25% longer per level", costs: [3, 6] }
];
var ROLLING_SEED = [0, 500, 2500, 12e3];
function perkById(id) {
  return LEGACY_PERKS.find((p) => p.id === id) ?? null;
}
function perkLevelOf(s, id) {
  return (s.legacyPerks ?? {})[id] ?? 0;
}
function legacyPointsOf(s) {
  return s.legacyPoints ?? 0;
}
function totalPerkLevels(s) {
  return LEGACY_PERKS.reduce((sum, p) => sum + perkLevelOf(s, p.id), 0);
}
function perkCostOf(s, id) {
  const p = perkById(id);
  if (!p) return null;
  const lvl = perkLevelOf(s, id);
  return lvl >= p.costs.length ? null : p.costs[lvl];
}
function canBuyPerk(s, id) {
  const cost = perkCostOf(s, id);
  return cost !== null && legacyPointsOf(s) >= cost;
}
function buyPerk(s, id) {
  if (!canBuyPerk(s, id)) return s;
  const cost = perkCostOf(s, id);
  return {
    ...s,
    legacyPoints: legacyPointsOf(s) - cost,
    legacyPerks: { ...s.legacyPerks ?? {}, [id]: perkLevelOf(s, id) + 1 }
  };
}
function pointsForSale(s) {
  return 1 + divisionIndex(s);
}
function swayMult(s) {
  return 1 + perkLevelOf(s, "sway") * 0.1;
}
function rootsMult(s) {
  return 1 + perkLevelOf(s, "roots") * 0.15;
}
function payrollMult(s) {
  return 1 + perkLevelOf(s, "payroll") * 0.2;
}
function charmMult(s) {
  return 1 + perkLevelOf(s, "charm") * 0.25;
}
function boostChargeSecOf(s) {
  return BOOST_CHARGE_SEC - perkLevelOf(s, "voltage") * 60;
}
function offlineRateOf(s) {
  return [0.5, 0.65, 0.8][perkLevelOf(s, "away")] ?? 0.5;
}
function offlineCapHoursOf(s) {
  return [8, 10, 12][perkLevelOf(s, "away")] ?? 8;
}
function startingMoneyOf(s) {
  return 40 + (ROLLING_SEED[perkLevelOf(s, "rolling")] ?? 0);
}
var TYCOON_SAVE_KEY = "stadiumTycoonSaveV1";
var SAVE_VERSION = 1;
function newTycoon(now) {
  return {
    v: SAVE_VERSION,
    money: 40,
    lifetime: 0,
    rep: 0,
    levels: Object.fromEntries(TRACKS.map((t) => [t.id, 0])),
    fanbase: 90,
    minute: 0,
    goalsFor: 0,
    goalsAgainst: 0,
    streak: 0,
    matchNo: 0,
    savedAt: now,
    totalGoals: 0,
    totalWins: 0,
    totalTaps: 0,
    boostChargeSec: 0,
    boostLeftSec: 0,
    claimed: [],
    groundWins: 0,
    bestDivision: 0,
    staffLevels: {},
    ach: [],
    goldenKind: null,
    goldenLeftSec: 0,
    goldenCaught: 0,
    boostsUsed: 0,
    totalMatches: 0,
    /* Round 196: a brand-new career needs no migration grant. */
    legacyPoints: 0,
    legacyPerks: {},
    legacySeeded: true,
    /* Round 582: a fresh club always meets the same Muddy Meadows. */
    league: newLeague(0, 0, 0),
    leagueTitles: 0
  };
}
var MILESTONES = [
  { id: "fans500", label: "500 fans follow the club", pay: 400, hit: (s) => s.fanbase >= 500 },
  { id: "fans2k", label: "2,000 fans follow the club", pay: 2500, hit: (s) => s.fanbase >= 2e3 },
  { id: "fans10k", label: "10,000 fans follow the club", pay: 2e4, hit: (s) => s.fanbase >= 1e4 },
  { id: "full", label: "First full house", pay: 600, hit: (s) => capacity(s) > 120 && attendance(s) >= capacity(s) },
  { id: "win1", label: "First win", pay: 250, hit: (s) => s.totalWins >= 1 },
  { id: "win10", label: "10 wins", pay: 3e3, hit: (s) => s.totalWins >= 10 },
  { id: "win50", label: "50 wins", pay: 3e4, hit: (s) => s.totalWins >= 50 },
  { id: "goals25", label: "25 goals scored", pay: 4e3, hit: (s) => s.totalGoals >= 25 },
  { id: "streak5", label: "Five wins in a row", pay: 6e3, hit: (s) => s.streak >= 5 },
  { id: "allTracks", label: "Every upgrade owned at least once", pay: 8e3, hit: (s) => TRACKS.every((t) => (s.levels[t.id] ?? 0) >= 1) }
];
var OPP_PLACES = [
  "Ironbridge",
  "Harborview",
  "Redmoor",
  "Saltcliff",
  "Windmere",
  "Ashvale",
  "Stonegate",
  "Brightwater",
  "Fernhill",
  "Oldmarket",
  "Kestrel Park",
  "Duskfield",
  "Northquay",
  "Silverbeck",
  "Crowhurst",
  "Emberton",
  "Foxglove",
  "Greyharbor",
  "Hollowbrook",
  "Larkspur",
  "Mistral",
  "Pinecrest",
  "Quarryside",
  "Thornbury"
];
var OPP_SUFFIXES = [
  "Rovers",
  "Athletic",
  "Wanderers",
  "Town",
  "County",
  "Albion",
  "Harriers",
  "Corinthians",
  "Swifts",
  "Rangers",
  "Olympic",
  "Victoria"
];
function legacyOpponentName(s) {
  const k = (s.matchNo ?? 0) + (s.rep ?? 0) * 137;
  const h = k * 2654435761 >>> 0;
  const place = OPP_PLACES[h % OPP_PLACES.length];
  const suffix = OPP_SUFFIXES[Math.floor(h / OPP_PLACES.length) % OPP_SUFFIXES.length];
  return `${place} ${suffix}`;
}
function allOpponentNames() {
  const out = [];
  for (const p of OPP_PLACES) for (const sfx of OPP_SUFFIXES) out.push(`${p} ${sfx}`);
  return out;
}
var YOUR_CLUB = "Your club";
var LEAGUE_NAME_MAX = 17;
var OFFSET_SPREAD = 6e-3;
var SINGLE_LEG_BELOW = 3;
function leagueShape(division) {
  const clubs = division <= 2 ? 6 : division <= 5 ? 8 : 10;
  const legs = division < SINGLE_LEG_BELOW ? 1 : 2;
  return { clubs, matchdays: (clubs - 1) * legs, perMatchday: clubs / 2 };
}
function leagueNameBank() {
  return allOpponentNames().filter((n) => n.length <= LEAGUE_NAME_MAX);
}
function blankClub(name, offset) {
  return { name, offset, w: 0, d: 0, l: 0, gf: 0, ga: 0, pts: 0 };
}
function spreadOffsets(count, rnd) {
  const out = Array.from({ length: count }, (_, i) => count <= 1 ? 0 : -OFFSET_SPREAD + 2 * OFFSET_SPREAD * i / (count - 1));
  for (let i = out.length - 1; i > 0; i -= 1) {
    const j = Math.floor(rnd() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}
function newLeague(rep, division, season, clubName, baseMatchNo = 0) {
  const { clubs } = leagueShape(division);
  const seed = hash32(rep | 0, division | 0, season | 0, 582);
  const rnd = mulberry32(seed);
  const you = clubName ?? YOUR_CLUB;
  const bank = leagueNameBank().filter((n) => n !== you);
  for (let i = 0; i < clubs - 1; i += 1) {
    const j = i + Math.floor(rnd() * (bank.length - i));
    [bank[i], bank[j]] = [bank[j], bank[i]];
  }
  const offsets = spreadOffsets(clubs - 1, mulberry32(hash32(seed, season | 0)));
  return {
    division,
    season,
    matchday: 0,
    seed,
    baseMatchNo: Math.max(0, Math.floor(baseMatchNo)),
    clubs: [blankClub(you, 0), ...bank.slice(0, clubs - 1).map((n, i) => blankClub(n, offsets[i]))]
  };
}
function nextSeason(lg) {
  const season = lg.season + 1;
  const offsets = spreadOffsets(lg.clubs.length - 1, mulberry32(hash32(lg.seed, season)));
  return {
    division: lg.division,
    season,
    matchday: 0,
    seed: lg.seed,
    baseMatchNo: lg.baseMatchNo,
    clubs: lg.clubs.map((c, i) => blankClub(c.name, i === 0 ? 0 : offsets[i - 1]))
  };
}
function matchdayFixtures(lg) {
  const { perMatchday } = leagueShape(lg.division);
  const calendar = roundRobinCalendar(lg.clubs.length);
  return calendar.slice(lg.matchday * perMatchday, (lg.matchday + 1) * perMatchday);
}
function yourOpponentIndex(lg) {
  const f = matchdayFixtures(lg).find(([h, a]) => h === 0 || a === 0);
  return f ? f[0] === 0 ? f[1] : f[0] : 1;
}
function leagueStandings(lg) {
  const you = lg.clubs[0];
  return [...lg.clubs].sort((a, b) => tableOrder(a, b) || (a === you ? -1 : b === you ? 1 : 0) || (a.name < b.name ? -1 : a.name > b.name ? 1 : 0));
}
function leaguePosition(lg) {
  return leagueStandings(lg).indexOf(lg.clubs[0]) + 1;
}
function opponentName(s) {
  const lg = s.league;
  if (!lg) return legacyOpponentName(s);
  if (lg.carryover) return lg.carryover;
  return lg.clubs[yourOpponentIndex(lg)]?.name ?? legacyOpponentName(s);
}
function currentOpponentOffset(s) {
  const lg = s.league;
  if (!lg || lg.carryover) return 0;
  return lg.clubs[yourOpponentIndex(lg)]?.offset ?? 0;
}
function clubNameOptions(s) {
  const taken = new Set((s.league?.clubs ?? []).map((c) => c.name));
  const bank = leagueNameBank().filter((n) => !taken.has(n));
  const rnd = mulberry32(hash32(s.rep | 0, s.league?.seed ?? 0, 91));
  const out = [];
  while (out.length < 3 && bank.length) out.push(bank.splice(Math.floor(rnd() * bank.length), 1)[0]);
  return out;
}
function setClubName(s, name) {
  if (!s.league || name !== YOUR_CLUB && !clubNameOptions(s).includes(name)) return s;
  return { ...s, clubName: name, league: { ...s.league, clubs: s.league.clubs.map((c, i) => i === 0 ? { ...c, name } : c) } };
}
function recordResult(c, gf, ga) {
  c.gf += gf;
  c.ga += ga;
  if (gf > ga) {
    c.w += 1;
    c.pts += 3;
  } else if (gf === ga) {
    c.d += 1;
    c.pts += 1;
  } else {
    c.l += 1;
  }
}
function leagueMatchNo(s) {
  const base = s.league?.baseMatchNo;
  return Number.isFinite(base) ? Math.min(s.matchNo, base) : s.matchNo;
}
function rivalChancePerMin(st, c) {
  return Math.max(8e-3, Math.min(0.14, 0.024 + leagueMatchNo(st) * 11e-4 + divisionOf(st).oppBoost + c.offset));
}
function playMatchday(st, gf, ga, events) {
  const lg = st.league;
  const clubs = lg.clubs.map((c) => ({ ...c }));
  const rnd = mulberry32(hash32(lg.seed, lg.season, lg.matchday, 7));
  for (const [h, a] of matchdayFixtures(lg)) {
    if (h === 0 || a === 0) {
      const opp = h === 0 ? a : h;
      recordResult(clubs[0], gf, ga);
      recordResult(clubs[opp], ga, gf);
      continue;
    }
    const ph = rivalChancePerMin(st, clubs[h]);
    const pa = rivalChancePerMin(st, clubs[a]);
    let hg = 0;
    let ag = 0;
    for (let m = 0; m < 90; m += 1) {
      if (rnd() < ph) hg += 1;
      if (rnd() < pa) ag += 1;
    }
    recordResult(clubs[h], hg, ag);
    recordResult(clubs[a], ag, hg);
  }
  const played = { ...lg, clubs, matchday: lg.matchday + 1 };
  if (played.matchday < leagueShape(lg.division).matchdays) return played;
  const position = leaguePosition(played);
  const d = DIVISIONS[played.division];
  if (position !== 1) {
    events.push({ kind: "seasonEnd", label: `Season over: ${ordinal(position)} of ${clubs.length} in the ${d.name}`, position, table: clubs });
    return nextSeason(played);
  }
  st.leagueTitles = (st.leagueTitles ?? 0) + 1;
  if (played.division >= DIVISIONS.length - 1) {
    const pay2 = Math.round(attendance(st) * 8 * d.incomeMult * repMult(st));
    st.money += pay2;
    st.lifetime += pay2;
    events.push({ kind: "title", amount: pay2, label: `${d.emoji} CHAMPIONS OF ${d.name.toUpperCase()}`, position, table: clubs });
    return nextSeason(played);
  }
  events.push({ kind: "title", label: `\u{1F3C6} Champions of the ${d.name}`, position, table: clubs });
  const up = played.division + 1;
  const nd = DIVISIONS[up];
  const next = newLeague(st.rep, up, played.season + 1, clubs[0].name === YOUR_CLUB ? void 0 : clubs[0].name, st.matchNo);
  const pay = Math.round(attendance(st) * 8 * nd.incomeMult * repMult(st));
  st.money += pay;
  st.lifetime += pay;
  st.bestDivision = Math.max(st.bestDivision ?? 0, up);
  events.push({ kind: "promoted", amount: pay, label: `${nd.emoji} PROMOTED: ${nd.name}` });
  return next;
}
function ordinal(n) {
  const v = n % 100;
  const sfx = v >= 11 && v <= 13 ? "th" : ["th", "st", "nd", "rd"][n % 10] ?? "th";
  return `${n}${sfx}`;
}
var BOOST_CHARGE_SEC = 8 * 60;
var BOOST_DURATION_SEC = 60;
var HYPE_MULT = 2;
function boostReady(s) {
  return (s.boostChargeSec ?? 0) >= boostChargeSecOf(s) && (s.boostLeftSec ?? 0) <= 0;
}
function boostActive(s) {
  return (s.boostLeftSec ?? 0) > 0;
}
function activateBoost(s) {
  if (!boostReady(s)) return s;
  return {
    ...s,
    boostChargeSec: 0,
    boostLeftSec: BOOST_DURATION_SEC,
    // Round 162: counted for the achievement wall.
    boostsUsed: (s.boostsUsed ?? 0) + 1
  };
}
function trackById(id) {
  return TRACKS.find((t) => t.id === id) ?? TRACKS[0];
}
function levelOf(s, id) {
  return s.levels[id] ?? 0;
}
function costOf(s, id) {
  const t = trackById(id);
  return Math.round(t.baseCost * Math.pow(t.growth, levelOf(s, id)));
}
function capacity(s) {
  return 120 + levelOf(s, "stands") * 40;
}
var TICKET_POLICIES = [
  { id: "community", label: "Community", gate: 0.85, demand: 1, growth: 1.5 },
  { id: "standard", label: "Standard", gate: 1, demand: 1, growth: 1 },
  { id: "premium", label: "Premium", gate: 1.25, demand: 0.75, growth: 0.75 }
];
function ticketPolicyOf(s) {
  return s.ticketPolicy === "community" || s.ticketPolicy === "premium" ? s.ticketPolicy : "standard";
}
function ticketTerms(s) {
  return TICKET_POLICIES.find((p) => p.id === ticketPolicyOf(s));
}
function setTicketPolicy(s, policy) {
  if (policy === ticketPolicyOf(s)) return s;
  const next = { ...s };
  if (policy === "community" || policy === "premium") next.ticketPolicy = policy;
  else delete next.ticketPolicy;
  return next;
}
function attendance(s) {
  return Math.min(capacity(s), Math.floor(s.fanbase * ticketTerms(s).demand));
}
function repMult(s) {
  return 1 + s.rep * 0.5;
}
function streakMult(s) {
  return 1 + Math.min(s.streak, 10) * 0.06;
}
function perFanRate(s) {
  const tk = levelOf(s, "tickets");
  const sn = levelOf(s, "snacks");
  const sh = levelOf(s, "shop");
  if (ticketPolicyOf(s) === "standard") return 0.05 + tk * 0.011 + sn * 9e-3 + sh * 0.016;
  return (0.05 + tk * 0.011) * ticketTerms(s).gate + sn * 9e-3 + sh * 0.016;
}
function incomePerSec(s) {
  const fans = attendance(s);
  const perFan = perFanRate(s);
  const parking = levelOf(s, "parking") * 0.9;
  const hype = boostActive(s) ? HYPE_MULT : 1;
  const golden = goldenActive(s) && s.goldenKind === "frenzy" ? FRENZY_MULT : 1;
  return (fans * perFan + parking + staffBaseIncome(s)) * repMult(s) * streakMult(s) * divisionOf(s).incomeMult * achMult(s) * swayMult(s) * hype * golden;
}
function tapValue(s) {
  const mg = levelOf(s, "megaphone");
  const rush = goldenActive(s) && s.goldenKind === "tapRush" ? TAP_RUSH_MULT : 1;
  return Math.max(1, Math.round((incomePerSec(s) * 0.7 + mg * 2) * repMult(s) * rush));
}
function fanGrowthPerSec(s) {
  const lights = levelOf(s, "lights");
  const academy = levelOf(s, "academy");
  const base = 0.05 + lights * 0.05 + academy * 0.11;
  const winPull = 1 + Math.min(s.streak, 10) * 0.08;
  const room = capacity(s) * 3;
  const pressure = s.fanbase >= room ? 0.15 : 1;
  return base * winPull * pressure * rootsMult(s) * ticketTerms(s).growth;
}
function ticketEconomy(s) {
  const crowd = attendance(s);
  const terms = ticketTerms(s);
  const multiplier = repMult(s) * streakMult(s) * divisionOf(s).incomeMult * achMult(s) * swayMult(s) * (boostActive(s) ? HYPE_MULT : 1) * (goldenActive(s) && s.goldenKind === "frenzy" ? FRENZY_MULT : 1);
  return {
    policy: terms.id,
    crowd,
    seats: capacity(s),
    supporters: Math.floor(s.fanbase),
    gatePerSec: crowd * (0.05 + levelOf(s, "tickets") * 0.011) * terms.gate * multiplier,
    concessionsPerSec: crowd * (levelOf(s, "snacks") * 9e-3 + levelOf(s, "shop") * 0.016) * multiplier,
    otherPerSec: (levelOf(s, "parking") * 0.9 + staffBaseIncome(s)) * multiplier,
    totalPerSec: incomePerSec(s),
    growthPerSec: fanGrowthPerSec(s),
    tap: tapValue(s)
  };
}
function goalChancePerMin(s) {
  const sq = levelOf(s, "squad");
  return Math.min(0.16, 0.028 + sq * 16e-4);
}
function oppChancePerMin(s, edge = 0) {
  const sq = levelOf(s, "squad");
  const opp = 0.024 + leagueMatchNo(s) * 11e-4 + divisionOf(s).oppBoost + currentOpponentOffset(s);
  const base = Math.max(8e-3, Math.min(0.14, opp - sq * 8e-4));
  const defence = Number.isFinite(edge) ? Math.max(0, Math.min(0.4, edge)) : 0;
  return Math.max(8e-3, base * (1 - defence));
}
function goalBonus(s) {
  return Math.round(attendance(s) * 0.6 * repMult(s) * streakMult(s));
}
var SET_PIECE_WINDOW_SEC = 12;
function setPieceDetails(s) {
  const match = s.totalMatches ?? 0;
  if (!Number.isSafeInteger(match) || match < 0 || match >= Number.MAX_SAFE_INTEGER || !Number.isInteger(s.rep) || s.rep < 0) return null;
  const minute = 20 + hash32(match) % 61;
  const penalty = match % 3 === 0;
  return {
    match,
    rep: s.rep,
    minute,
    kind: penalty ? "penalty" : "free-kick",
    kickIndex: penalty ? 0 : 2 + hash32(match, 587) % 5,
    seed: hash32(match, 587, 1),
    remainingSec: SET_PIECE_WINDOW_SEC - ((s.minute - minute) * MATCH_MINUTE_SEC + (s.matchSec ?? 0))
  };
}
function setPieceOffer(s, watched) {
  if (!watched) return null;
  const offer = setPieceDetails(s);
  if (!offer || s.setPieceAttemptedMatch === offer.match || s.setPieceUsedMatch === offer.match || s.minute >= 90) return null;
  return offer.remainingSec > 0 && offer.remainingSec <= SET_PIECE_WINDOW_SEC ? offer : null;
}
function sameSetPiece(a, b) {
  return a.match === b.match && a.rep === b.rep && a.minute === b.minute && a.kind === b.kind && a.kickIndex === b.kickIndex && a.seed === b.seed;
}
function beginSetPiece(s, offer) {
  const current = setPieceOffer(s, true);
  if (!current || !sameSetPiece(current, offer)) return s;
  return { ...s, setPieceAttemptedMatch: current.match };
}
function awardSetPieceGoal(s, offer) {
  const current = setPieceDetails(s);
  if (!current || !sameSetPiece(current, offer) || s.minute < current.minute || s.minute >= 90 || s.setPieceAttemptedMatch !== current.match) return null;
  if (s.setPieceUsedMatch === current.match) return null;
  const amount = goalBonus(s);
  return {
    state: { ...s, money: s.money + amount, lifetime: s.lifetime + amount, goalsFor: s.goalsFor + 1, totalGoals: s.totalGoals + 1, setPieceUsedMatch: current.match },
    event: { kind: "goal", amount, minute: s.minute }
  };
}
function winBonus(s) {
  return Math.round(attendance(s) * 2.2 * repMult(s));
}
function canBuy(s, id) {
  return levelOf(s, id) < trackById(id).maxLevel && s.money >= costOf(s, id);
}
function buy(s, id) {
  if (!canBuy(s, id)) return s;
  const cost = costOf(s, id);
  return {
    ...s,
    money: s.money - cost,
    levels: { ...s.levels, [id]: levelOf(s, id) + 1 }
  };
}
function tap(s) {
  const v = tapValue(s);
  return { ...s, money: s.money + v, lifetime: s.lifetime + v, totalTaps: s.totalTaps + 1 };
}
function playMinute(st, roll, events, opts, edge = 0) {
  st.minute += 1;
  if (st.minute <= 90) {
    if (roll() < goalChancePerMin(st)) {
      st.goalsFor += 1;
      st.totalGoals += 1;
      if (opts.pay) {
        const b = goalBonus(st);
        st.money += b;
        st.lifetime += b;
        events.push({ kind: "goal", amount: b, minute: st.minute });
      } else {
        events.push({ kind: "goal", minute: st.minute });
      }
    }
    if (roll() < oppChancePerMin(st, edge)) {
      st.goalsAgainst += 1;
      events.push({ kind: "conceded", minute: st.minute });
    }
  }
  if (st.minute >= 90) {
    if (st.goalsFor > st.goalsAgainst) {
      const b = opts.pay ? winBonus(st) : 0;
      st.money += b;
      st.lifetime += b;
      st.streak += 1;
      st.totalWins += 1;
      st.groundWins = (st.groundWins ?? 0) + 1;
      st.fanbase += 6 + st.streak * 2;
      events.push(opts.pay ? { kind: "win", amount: b } : { kind: "win" });
    } else if (st.goalsFor < st.goalsAgainst) {
      st.streak = perkLevelOf(st, "shield") > 0 ? Math.floor(st.streak / 2) : 0;
      events.push({ kind: "loss" });
    } else {
      events.push({ kind: "draw" });
    }
    if (st.league) {
      if (st.league.carryover) {
        const { carryover: _finished, ...rest } = st.league;
        st.league = rest;
      } else {
        st.league = playMatchday(st, st.goalsFor, st.goalsAgainst, events);
      }
    }
    st.matchNo += 1;
    st.totalMatches = (st.totalMatches ?? 0) + 1;
    st.minute = 0;
    st.goalsFor = 0;
    st.goalsAgainst = 0;
  }
}
var AWAY_MATCHDAY_SEC = 1800;
function awayMatchdaysPlayable(s, count) {
  const n = Math.max(0, Math.floor(count));
  const lg = s.league;
  if (!lg) return n;
  const beforeFinal = Math.max(0, leagueShape(lg.division).matchdays - 1 - lg.matchday);
  return Math.min(n, (lg.carryover ? 1 : 0) + beforeFinal);
}
function playAwayMatchdays(s, count, roll, edge = 0) {
  const st = { ...s, levels: { ...s.levels } };
  const events = [];
  const results = [];
  const n = awayMatchdaysPlayable(s, count);
  for (let i = 0; i < n; i += 1) {
    const friendly = Boolean(st.league?.carryover);
    let result = null;
    for (let guard = 0; guard <= 90 && result === null; guard += 1) {
      const k = events.length;
      playMinute(st, roll, events, { pay: false }, edge);
      for (let j = k; j < events.length; j += 1) {
        if (events[j].kind === "win" || events[j].kind === "draw" || events[j].kind === "loss") result = events[j].kind;
      }
    }
    settleFirsts(st, events);
    results.push({ result: result === "win" ? "W" : result === "loss" ? "L" : "D", friendly });
  }
  return { state: st, results, events };
}
function tick(s, dt, roll, edge = 0) {
  const events = [];
  let st = { ...s, levels: { ...s.levels } };
  const earned = incomePerSec(st) * dt;
  st.money += earned;
  st.lifetime += earned;
  st.fanbase += fanGrowthPerSec(st) * dt;
  if ((st.boostLeftSec ?? 0) > 0) {
    st.boostLeftSec = Math.max(0, (st.boostLeftSec ?? 0) - dt);
  } else {
    st.boostChargeSec = Math.min(boostChargeSecOf(st), (st.boostChargeSec ?? 0) + dt);
  }
  if ((st.goldenLeftSec ?? 0) > 0) {
    st.goldenLeftSec = Math.max(0, (st.goldenLeftSec ?? 0) - dt);
    if (st.goldenLeftSec <= 0) st.goldenKind = null;
  }
  const MIN_LEN = 1.4;
  st.matchSec = (st.matchSec ?? 0) + dt;
  let minutes = Math.floor(st.matchSec / MIN_LEN);
  st.matchSec -= minutes * MIN_LEN;
  if (minutes > 120) {
    minutes = 120;
    st.matchSec = 0;
  }
  minutes = Math.max(0, minutes);
  for (let i = 0; i < minutes; i++) playMinute(st, roll, events, { pay: true }, edge);
  settleFirsts(st, events);
  return { state: st, events };
}
function settleFirsts(st, events) {
  const claimed = st.claimed ?? [];
  let newlyClaimed = null;
  for (const m of MILESTONES) {
    if (claimed.includes(m.id) || newlyClaimed && newlyClaimed.includes(m.id)) continue;
    if (!m.hit(st)) continue;
    const pay = Math.round(m.pay * repMult(st));
    st.money += pay;
    st.lifetime += pay;
    if (!newlyClaimed) newlyClaimed = [...claimed];
    newlyClaimed.push(m.id);
    events.push({ kind: "milestone", amount: pay, label: m.label });
  }
  if (newlyClaimed) st.claimed = newlyClaimed;
  const achHave = st.ach ?? [];
  let newAch = null;
  for (const a of ACHIEVEMENTS) {
    if (achHave.includes(a.id) || newAch && newAch.includes(a.id)) continue;
    if (!a.hit(st)) continue;
    if (!newAch) newAch = [...achHave];
    newAch.push(a.id);
    events.push({ kind: "ach", label: `${a.emoji} ${a.label}` });
  }
  if (newAch) st.ach = newAch;
}
function prestigeThreshold(s) {
  return 4e6 * Math.pow(7, s.rep);
}
function canPrestige(s) {
  return s.lifetime >= prestigeThreshold(s);
}
function prestige(s, now) {
  if (!canPrestige(s)) return s;
  const fresh = newTycoon(now);
  return {
    ...fresh,
    rep: s.rep + 1,
    totalGoals: s.totalGoals,
    totalWins: s.totalWins,
    totalTaps: s.totalTaps,
    // Round 152: firsts stay first. See the MILESTONES comment for why.
    claimed: [...s.claimed ?? []],
    /* Round 162: what survives selling up, and what does not. Achievements
       and the career counters they read are FOREVER, that is their point.
       The division ladder and the payroll are THIS CLUB's: the new ground
       starts at the bottom of the Muddy Meadows League with an empty staff
       room, and the climb back up is the game. */
    ach: [...s.ach ?? []],
    bestDivision: s.bestDivision ?? 0,
    goldenCaught: s.goldenCaught ?? 0,
    boostsUsed: s.boostsUsed ?? 0,
    totalMatches: s.totalMatches ?? 0,
    ...s.setPieceAttemptedMatch !== void 0 ? { setPieceAttemptedMatch: s.setPieceAttemptedMatch } : {},
    ...s.setPieceUsedMatch !== void 0 ? { setPieceUsedMatch: s.setPieceUsedMatch } : {},
    /* Round 196: the sale pays its legacy, read off the ground BEFORE the
       reset, and the boardroom is forever like the badges. The Rolling
       Investment perk seeds the new till. */
    legacyPoints: legacyPointsOf(s) + pointsForSale(s),
    legacyPerks: { ...s.legacyPerks ?? {} },
    legacySeeded: true,
    money: startingMoneyOf(s),
    /* Round 582: the new ground starts at the bottom of a new league, so
       Round 196's "climb before you sell" still pays. Titles and the name are
       the career's. */
    league: newLeague(s.rep + 1, 0, 0, s.clubName === YOUR_CLUB ? void 0 : s.clubName, 0),
    leagueTitles: s.leagueTitles ?? 0,
    ...s.clubName ? { clubName: s.clubName } : {}
  };
}
function awaySecondsOf(s, now) {
  const elapsed = Math.max(0, (now - s.savedAt) / 1e3);
  const capped = Math.min(elapsed, offlineCapHoursOf(s) * 3600);
  return capped < 30 ? 0 : capped;
}
function offlineEarnings(s, now) {
  const capped = awaySecondsOf(s, now);
  if (capped === 0) return 0;
  return Math.round(incomePerSec({ ...s, boostLeftSec: 0, goldenLeftSec: 0, goldenKind: null }) * capped * offlineRateOf(s));
}
function serializeTycoon(s, now) {
  return JSON.stringify({ ...s, savedAt: now });
}
var MATCH_MINUTE_SEC = 1.4;
function cleanLeague(raw, clubName, bestDivision, matchNo) {
  if (!raw || typeof raw !== "object") return null;
  const r = raw;
  const division = r.division;
  if (!Number.isInteger(division) || division < 0 || division > DIVISIONS.length - 1) return null;
  if (division > bestDivision) return null;
  const shape = leagueShape(division);
  if (!Number.isInteger(r.matchday) || r.matchday < 0 || r.matchday >= shape.matchdays) return null;
  if (!Number.isInteger(r.season) || r.season < 0) return null;
  if (!Number.isFinite(r.seed)) return null;
  if (!Array.isArray(r.clubs) || r.clubs.length !== shape.clubs) return null;
  const bank = new Set(leagueNameBank());
  const names = /* @__PURE__ */ new Set();
  const clubs = [];
  for (let i = 0; i < r.clubs.length; i += 1) {
    const c = r.clubs[i];
    if (!c || typeof c.name !== "string" || names.has(c.name)) return null;
    if (i === 0 ? c.name !== (clubName ?? YOUR_CLUB) : !bank.has(c.name)) return null;
    const offset = i === 0 ? 0 : c.offset;
    if (!Number.isFinite(offset) || Math.abs(offset) > OFFSET_SPREAD + 1e-9) return null;
    const whole = [c.w, c.d, c.l, c.gf, c.ga];
    if (!whole.every((v) => Number.isInteger(v) && v >= 0)) return null;
    if (c.w + c.d + c.l !== r.matchday) return null;
    names.add(c.name);
    clubs.push({ name: c.name, offset, w: c.w, d: c.d, l: c.l, gf: c.gf, ga: c.ga, pts: 3 * c.w + c.d });
  }
  const sum = (k) => clubs.reduce((acc, c) => acc + c[k], 0);
  if (sum("w") !== sum("l") || sum("gf") !== sum("ga")) return null;
  const base = Number.isInteger(r.baseMatchNo) && r.baseMatchNo >= 0 && r.baseMatchNo <= matchNo ? r.baseMatchNo : matchNo;
  const out = { division, season: r.season, matchday: r.matchday, seed: r.seed >>> 0, baseMatchNo: base, clubs };
  if (typeof r.carryover === "string" && allOpponentNames().includes(r.carryover)) out.carryover = r.carryover;
  return out;
}
function wholeIn(v, lo, hi) {
  return Number.isFinite(v) ? Math.min(hi, Math.max(lo, Math.floor(v))) : lo;
}
function deserializeTycoon(raw, now) {
  if (!raw) return null;
  try {
    const p = JSON.parse(raw);
    if (!p || typeof p !== "object" || p.v !== SAVE_VERSION) return null;
    const base = newTycoon(now);
    const s = {
      ...base,
      ...p,
      levels: { ...base.levels, ...p.levels ?? {} }
    };
    if (p.ticketPolicy !== "community" && p.ticketPolicy !== "premium") delete s.ticketPolicy;
    for (const k of ["money", "lifetime", "fanbase"]) {
      if (!Number.isFinite(s[k]) || s[k] < 0) s[k] = base[k];
    }
    const cleanLevels = {};
    for (const t of TRACKS) {
      const lvl = s.levels[t.id];
      cleanLevels[t.id] = Number.isFinite(lvl) && lvl > 0 ? Math.min(Math.floor(lvl), t.maxLevel) : 0;
    }
    s.levels = cleanLevels;
    s.minute = wholeIn(s.minute, 0, 89);
    s.goalsFor = wholeIn(s.goalsFor, 0, 90);
    s.goalsAgainst = wholeIn(s.goalsAgainst, 0, 90);
    if (s.matchSec !== void 0 && !(Number.isFinite(s.matchSec) && s.matchSec >= 0 && s.matchSec < MATCH_MINUTE_SEC)) s.matchSec = 0;
    for (const k of ["streak", "matchNo", "totalGoals", "totalWins", "totalTaps"]) {
      s[k] = wholeIn(s[k], 0, Number.MAX_SAFE_INTEGER);
    }
    if (!Number.isFinite(s.savedAt) || s.savedAt > now) s.savedAt = now;
    if (!Number.isFinite(s.rep) || s.rep < 0 || s.rep > 50) s.rep = 0;
    if (!Number.isFinite(s.boostChargeSec) || s.boostChargeSec < 0) s.boostChargeSec = 0;
    s.boostChargeSec = Math.min(s.boostChargeSec, BOOST_CHARGE_SEC);
    if (!Number.isFinite(s.boostLeftSec) || s.boostLeftSec < 0) s.boostLeftSec = 0;
    s.boostLeftSec = Math.min(s.boostLeftSec, BOOST_DURATION_SEC);
    if (!Array.isArray(s.claimed)) s.claimed = [];
    s.claimed = s.claimed.filter((id) => MILESTONES.some((m) => m.id === id));
    if (!Array.isArray(s.ach)) s.ach = [];
    s.ach = s.ach.filter((id) => ACHIEVEMENTS.some((a) => a.id === id));
    const cleanStaff = {};
    for (const t of STAFF) {
      const lvl = (s.staffLevels ?? {})[t.id];
      cleanStaff[t.id] = Number.isFinite(lvl) && lvl > 0 ? Math.min(Math.floor(lvl), t.maxLevel) : 0;
    }
    s.staffLevels = cleanStaff;
    for (const k of ["groundWins", "bestDivision", "goldenCaught", "boostsUsed", "totalMatches"]) {
      if (!Number.isFinite(s[k]) || s[k] < 0) s[k] = 0;
    }
    for (const key of ["setPieceAttemptedMatch", "setPieceUsedMatch"]) {
      const value = p[key];
      if (value === void 0) delete s[key];
      else s[key] = Number.isSafeInteger(value) && value >= 0 && value <= (s.totalMatches ?? 0) ? value : s.totalMatches ?? 0;
    }
    if (s.setPieceUsedMatch !== void 0 && (s.setPieceAttemptedMatch === void 0 || s.setPieceAttemptedMatch < s.setPieceUsedMatch)) s.setPieceAttemptedMatch = s.setPieceUsedMatch;
    s.bestDivision = Math.min(s.bestDivision ?? 0, DIVISIONS.length - 1);
    if (!Number.isFinite(s.goldenLeftSec) || (s.goldenLeftSec ?? 0) < 0) s.goldenLeftSec = 0;
    s.goldenLeftSec = Math.min(s.goldenLeftSec ?? 0, Math.ceil(GOLDEN_INFO.frenzy.duration * 1.5));
    if (s.goldenKind !== "frenzy" && s.goldenKind !== "tapRush") {
      s.goldenKind = null;
      s.goldenLeftSec = 0;
    }
    const cleanPerks = {};
    for (const perk of LEGACY_PERKS) {
      const lvl = (s.legacyPerks ?? {})[perk.id];
      cleanPerks[perk.id] = Number.isFinite(lvl) && lvl > 0 ? Math.min(Math.floor(lvl), perk.costs.length) : 0;
    }
    s.legacyPerks = cleanPerks;
    if (!Number.isFinite(s.legacyPoints) || (s.legacyPoints ?? 0) < 0) s.legacyPoints = 0;
    s.legacyPoints = Math.min(Math.floor(s.legacyPoints ?? 0), 5e3);
    if (p.legacySeeded !== true) {
      s.legacyPoints = Math.min((s.legacyPoints ?? 0) + s.rep, 5e3);
      s.legacySeeded = true;
    }
    if (s.clubName !== void 0 && !(typeof s.clubName === "string" && (s.clubName === YOUR_CLUB || leagueNameBank().includes(s.clubName)))) delete s.clubName;
    const youName = s.clubName === YOUR_CLUB ? void 0 : s.clubName;
    s.leagueTitles = wholeIn(s.leagueTitles, 0, Number.MAX_SAFE_INTEGER);
    const rawLeague = p.league;
    if (rawLeague === void 0) {
      const division = legacyDivisionIndex(s.groundWins ?? 0);
      const seeded = newLeague(s.rep, division, 0, youName, s.matchNo);
      if (s.minute > 0 || s.goalsFor > 0 || s.goalsAgainst > 0) seeded.carryover = legacyOpponentName(s);
      s.league = seeded;
      s.bestDivision = Math.max(s.bestDivision ?? 0, division);
    } else {
      const best = s.bestDivision ?? 0;
      const claimed = rawLeague.division;
      s.league = cleanLeague(rawLeague, youName, best, s.matchNo) ?? newLeague(s.rep, Number.isInteger(claimed) ? Math.min(Math.max(0, claimed), best) : Math.min(legacyDivisionIndex(s.groundWins ?? 0), best), 0, youName, s.matchNo);
    }
    return s;
  } catch {
    return null;
  }
}
function fmtMoney(n) {
  if (n >= 1e15) return `$${(n / 1e15).toFixed(2)}Q`;
  if (n >= 1e12) return `$${(n / 1e12).toFixed(2)}T`;
  if (n >= 1e9) return `$${(n / 1e9).toFixed(2)}B`;
  if (n >= 1e6) return `$${(n / 1e6).toFixed(2)}M`;
  if (n >= 1e4) return `$${(n / 1e3).toFixed(1)}K`;
  return `$${Math.floor(n)}`;
}
export {
  ACHIEVEMENTS,
  ACH_BONUS,
  AWAY_MATCHDAY_SEC,
  BOOST_CHARGE_SEC,
  BOOST_DURATION_SEC,
  DIVISIONS,
  FRENZY_MULT,
  GOLDEN_CATCH_SEC,
  GOLDEN_INFO,
  GOLDEN_MEAN_GAP_SEC,
  HYPE_MULT,
  LEAGUE_NAME_MAX,
  LEGACY_PERKS,
  MILESTONES,
  SET_PIECE_WINDOW_SEC,
  SINGLE_LEG_BELOW,
  STAFF,
  TAP_RUSH_MULT,
  TICKET_POLICIES,
  TRACKS,
  TYCOON_SAVE_KEY,
  WINDFALL_SEC,
  YOUR_CLUB,
  achMult,
  activateBoost,
  allOpponentNames,
  attendance,
  awardSetPieceGoal,
  awayMatchdaysPlayable,
  awaySecondsOf,
  beginSetPiece,
  boostActive,
  boostChargeSecOf,
  boostReady,
  buy,
  buyPerk,
  canBuy,
  canBuyPerk,
  canHire,
  canPrestige,
  capacity,
  catchGolden,
  charmMult,
  clubNameOptions,
  costOf,
  currentOpponentOffset,
  deserializeTycoon,
  divisionIndex,
  divisionOf,
  fanGrowthPerSec,
  fmtMoney,
  goalBonus,
  goalChancePerMin,
  goldenActive,
  hire,
  incomePerSec,
  leagueMatchNo,
  leagueNameBank,
  leaguePosition,
  leagueShape,
  leagueStandings,
  legacyDivisionIndex,
  legacyOpponentName,
  legacyPointsOf,
  levelOf,
  matchdayFixtures,
  newLeague,
  newTycoon,
  offlineCapHoursOf,
  offlineEarnings,
  offlineRateOf,
  oppChancePerMin,
  opponentName,
  ordinal,
  payrollMult,
  perkById,
  perkCostOf,
  perkLevelOf,
  playAwayMatchdays,
  playMinute,
  pointsForSale,
  prestige,
  prestigeThreshold,
  repMult,
  rollGoldenKind,
  rootsMult,
  serializeTycoon,
  setClubName,
  setPieceOffer,
  setTicketPolicy,
  settleFirsts,
  staffBaseIncome,
  staffById,
  staffCostOf,
  staffLevelOf,
  startingMoneyOf,
  streakMult,
  swayMult,
  tap,
  tapValue,
  tick,
  ticketEconomy,
  ticketPolicyOf,
  totalPerkLevels,
  totalStaffLevels,
  trackById,
  winBonus,
  yourOpponentIndex
};
