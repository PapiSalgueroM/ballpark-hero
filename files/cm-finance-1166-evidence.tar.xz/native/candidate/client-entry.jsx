import React from 'react';
import {createRoot} from 'react-dom/client';
import {FinancesScreen} from "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/FinancesScreen.tsx";
import {TICKET_TIERS} from "/home/runner/work/ballpark-hero/ballpark-hero/src/lib/clubManager.ts";
import {setTicketPolicy,setConcessionTier,booksOf,projectFinances,ticketReaction,concessionReaction,ticketPerFan,concessionPerFan,sponsorTable,CONCESSION_TIERS} from "/home/runner/work/ballpark-hero/ballpark-hero/src/lib/clubManagerFinances.ts";
import {fanMeter} from "/home/runner/work/ballpark-hero/ballpark-hero/src/lib/clubManagerMeters.ts";
export function mount(fixture){
 let current=JSON.parse(JSON.stringify(fixture)),calls=[];
 const view=createRoot(document.getElementById('fixture-root'));
 function choose(key,value){calls.push({key,value});current=key==='tickets'?setTicketPolicy(current,value):setConcessionTier(current,value);render();}
 function render(){view.render(<div>
  <button type="button" data-sentinel="before">Before finances</button>
  <section data-finance-board><FinancesScreen career={current} onTickets={value=>choose('tickets',value)} onConcessions={value=>choose('concessions',value)} onSponsor={value=>calls.push({key:'sponsor',value})} onPush={value=>calls.push({key:'push',value})}/></section>
  <button type="button" data-sentinel="after">After finances</button>
 </div>);}
 window.__finance1166={snapshot:()=>JSON.parse(JSON.stringify({career:current,calls,pricing:{tickets:current.finance?.ticketTier??1,concessions:booksOf(current).concessionTier},books:booksOf(current),fan:fanMeter(current),projection:projectFinances(current),reactions:{tickets:ticketReaction(current.finance?.ticketTier??1),concessions:concessionReaction(booksOf(current).concessionTier)},prices:{tickets:ticketPerFan(current),concessions:concessionPerFan(current)},sponsor:sponsorTable(current)})),schema:[{key:'tickets',values:[0,1,2],texts:TICKET_TIERS.map(item=>item.label)},{key:'concessions',values:[0,1,2],texts:CONCESSION_TIERS.map(item=>item.label)}]};
 render();
}