globalThis.localStorage={getItem:()=>null,setItem:()=>{},removeItem:()=>{}};
export const engine=await import("/home/runner/work/ballpark-hero/ballpark-hero/src/lib/clubManager.ts");
export const finance=await import("/home/runner/work/ballpark-hero/ballpark-hero/src/lib/clubManagerFinances.ts");
export const meters=await import("/home/runner/work/ballpark-hero/ballpark-hero/src/lib/clubManagerMeters.ts");