globalThis.localStorage={getItem:()=>null,setItem:()=>{},removeItem:()=>{}};
export const engine=await import("/home/runner/work/_temp/finance-1166.yljZuo/base-root/src/lib/clubManager.ts");
export const finance=await import("/home/runner/work/_temp/finance-1166.yljZuo/base-root/src/lib/clubManagerFinances.ts");
export const meters=await import("/home/runner/work/_temp/finance-1166.yljZuo/base-root/src/lib/clubManagerMeters.ts");