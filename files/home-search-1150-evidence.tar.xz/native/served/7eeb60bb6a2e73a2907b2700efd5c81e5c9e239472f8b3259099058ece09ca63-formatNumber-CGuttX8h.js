function n(e){const r=String(e),t=/^([+-]?)(\d+)(\.\d+)?$/.exec(r);return t?t[1]+t[2].replace(/\B(?=(\d{3})+(?!\d))/g,",")+(t[3]??""):r}export{n as f};
//# sourceMappingURL=formatNumber-CGuttX8h.js.map
