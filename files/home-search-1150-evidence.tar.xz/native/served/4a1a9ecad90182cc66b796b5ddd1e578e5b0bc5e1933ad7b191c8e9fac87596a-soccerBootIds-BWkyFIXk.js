const e=["vortex_strike","vortex_ghost","kinetiq_blaze","kinetiq_void","aurora_nine","aurora_royal","pulse_gold","pulse_venom","retro_classica","bubblegum","vortex_frost","kinetiq_flare","aurora_dusk","pulse_copper","terrace_navy","sunday_league","carnival","midnight_chrome"];export{e as B};
//# sourceMappingURL=soccerBootIds-BWkyFIXk.js.map
