globalThis.localStorage={getItem:()=>null,setItem:()=>{},removeItem:()=>{}};
export const engine=await import("/home/runner/work/ballpark-hero/ballpark-hero/src/lib/clubManager.ts");
export const options=await import("/home/runner/work/ballpark-hero/ballpark-hero/src/lib/clubManagerStart.ts");