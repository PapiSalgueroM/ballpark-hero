globalThis.localStorage={getItem:()=>null,setItem:()=>{},removeItem:()=>{}};
export const engine=await import("/home/runner/work/_temp/start-options-1164.R75SGF/base-root/src/lib/clubManager.ts");
export const options=await import("/home/runner/work/_temp/start-options-1164.R75SGF/base-root/src/lib/clubManagerStart.ts");