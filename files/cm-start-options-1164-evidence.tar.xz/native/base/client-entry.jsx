import React from 'react';
import {createRoot} from 'react-dom/client';
import {StartOptionsScreen} from "/home/runner/work/_temp/start-options-1164.R75SGF/base-root/src/components/club-manager/StartOptionsScreen.tsx";
import {setStartOption,startOptionsOf,CURRENCY_CODES,CURRENCIES,STRICTNESS_MIN,STRICTNESS_MAX,STRICTNESS_INFO} from "/home/runner/work/_temp/start-options-1164.R75SGF/base-root/src/lib/clubManagerStart.ts";
export function mount(fixture){
 let current=JSON.parse(JSON.stringify(fixture)),calls=[];
 const view=createRoot(document.getElementById('fixture-root'));
 function choose(key,value){calls.push({key,value});const next=setStartOption(current,key,value);if(next)current=next;render();}
 function render(){view.render(<div>
  <button type="button" data-sentinel="before">Before start options</button>
  <section data-start-options-board><StartOptionsScreen career={current} onCurrency={value=>choose('currency',value)} onNationJobs={value=>choose('nationJobs',value)} onStrictness={value=>choose('strictness',value)}/></section>
  <button type="button" data-sentinel="after">After start options</button>
 </div>);}
 const levels=[];for(let n=STRICTNESS_MIN;n<=STRICTNESS_MAX;n++)levels.push(n);
 window.__start1164={snapshot:()=>({career:JSON.parse(JSON.stringify(current)),calls:JSON.parse(JSON.stringify(calls)),options:JSON.parse(JSON.stringify(startOptionsOf(current)))}),schema:[{key:'currency',values:[...CURRENCY_CODES],texts:CURRENCY_CODES.map(code=>CURRENCIES[code].symbol+' '+CURRENCIES[code].label),labels:CURRENCY_CODES.map(()=>null)},{key:'nationJobs',values:[true,false],texts:['On','Off'],labels:[null,null]},{key:'strictness',values:levels,texts:levels.map(String),labels:levels.map(n=>'Strictness '+n+', '+STRICTNESS_INFO[n].label)}]};
 render();
}