var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};

// src/lib/captaincy.ts
var init_captaincy = __esm({
  "src/lib/captaincy.ts"() {
  }
});

// src/lib/uclTieRule.ts
var init_uclTieRule = __esm({
  "src/lib/uclTieRule.ts"() {
  }
});

// src/lib/intlNames.ts
var init_intlNames = __esm({
  "src/lib/intlNames.ts"() {
  }
});

// src/data/nationalPools.ts
var init_nationalPools = __esm({
  "src/data/nationalPools.ts"() {
  }
});

// src/lib/intlFormatHistory.ts
var init_intlFormatHistory = __esm({
  "src/lib/intlFormatHistory.ts"() {
  }
});

// src/lib/soccerInternational.ts
var NATION_CONFED, CONFED_POOL, FIFA_POINTS, RANK_ORDER;
var init_soccerInternational = __esm({
  "src/lib/soccerInternational.ts"() {
    init_intlNames();
    init_nationalPools();
    init_intlFormatHistory();
    NATION_CONFED = {
      // UEFA
      Albania: "UEFA",
      Armenia: "UEFA",
      Austria: "UEFA",
      Azerbaijan: "UEFA",
      Belarus: "UEFA",
      Belgium: "UEFA",
      "Bosnia & Herzegovina": "UEFA",
      Bulgaria: "UEFA",
      Croatia: "UEFA",
      Cyprus: "UEFA",
      "Czech Republic": "UEFA",
      Denmark: "UEFA",
      England: "UEFA",
      Estonia: "UEFA",
      "Faroe Islands": "UEFA",
      Finland: "UEFA",
      France: "UEFA",
      Georgia: "UEFA",
      Germany: "UEFA",
      Greece: "UEFA",
      Hungary: "UEFA",
      Iceland: "UEFA",
      Ireland: "UEFA",
      Israel: "UEFA",
      Italy: "UEFA",
      Kazakhstan: "UEFA",
      Kosovo: "UEFA",
      Latvia: "UEFA",
      Liechtenstein: "UEFA",
      Lithuania: "UEFA",
      Luxembourg: "UEFA",
      Malta: "UEFA",
      Moldova: "UEFA",
      Montenegro: "UEFA",
      Netherlands: "UEFA",
      "North Macedonia": "UEFA",
      "Northern Ireland": "UEFA",
      Norway: "UEFA",
      Poland: "UEFA",
      Portugal: "UEFA",
      Romania: "UEFA",
      Russia: "UEFA",
      Scotland: "UEFA",
      Serbia: "UEFA",
      Slovakia: "UEFA",
      Slovenia: "UEFA",
      Spain: "UEFA",
      Sweden: "UEFA",
      Switzerland: "UEFA",
      Turkey: "UEFA",
      Ukraine: "UEFA",
      Wales: "UEFA",
      // CONMEBOL
      Argentina: "CONMEBOL",
      Bolivia: "CONMEBOL",
      Brazil: "CONMEBOL",
      Chile: "CONMEBOL",
      Colombia: "CONMEBOL",
      Ecuador: "CONMEBOL",
      Paraguay: "CONMEBOL",
      Peru: "CONMEBOL",
      Uruguay: "CONMEBOL",
      Venezuela: "CONMEBOL",
      // CAF
      Algeria: "CAF",
      Angola: "CAF",
      Benin: "CAF",
      "Burkina Faso": "CAF",
      Cameroon: "CAF",
      "Cape Verde": "CAF",
      Comoros: "CAF",
      Congo: "CAF",
      "DR Congo": "CAF",
      Egypt: "CAF",
      Ethiopia: "CAF",
      Gabon: "CAF",
      Ghana: "CAF",
      Guinea: "CAF",
      "Guinea-Bissau": "CAF",
      "Ivory Coast": "CAF",
      Kenya: "CAF",
      Liberia: "CAF",
      Libya: "CAF",
      Madagascar: "CAF",
      Mali: "CAF",
      Morocco: "CAF",
      Mozambique: "CAF",
      Nigeria: "CAF",
      Senegal: "CAF",
      "Sierra Leone": "CAF",
      "South Africa": "CAF",
      Tanzania: "CAF",
      "The Gambia": "CAF",
      Togo: "CAF",
      Tunisia: "CAF",
      Uganda: "CAF",
      Zambia: "CAF",
      Zimbabwe: "CAF",
      // AFC
      Australia: "AFC",
      Bahrain: "AFC",
      China: "AFC",
      India: "AFC",
      Indonesia: "AFC",
      Iran: "AFC",
      Iraq: "AFC",
      Japan: "AFC",
      Jordan: "AFC",
      Kuwait: "AFC",
      Lebanon: "AFC",
      "North Korea": "AFC",
      Oman: "AFC",
      Philippines: "AFC",
      Qatar: "AFC",
      "Saudi Arabia": "AFC",
      "South Korea": "AFC",
      Tajikistan: "AFC",
      Thailand: "AFC",
      "United Arab Emirates": "AFC",
      Uzbekistan: "AFC",
      Vietnam: "AFC",
      // Both play Asian Cup and AFC World Cup qualifying, both are inside the
      // published world top 100, so both are here as opponents.
      Syria: "AFC",
      Palestine: "AFC",
      // CONCACAF
      Canada: "CONCACAF",
      "Costa Rica": "CONCACAF",
      Cuba: "CONCACAF",
      "Cura\xE7ao": "CONCACAF",
      "Dominican Republic": "CONCACAF",
      "El Salvador": "CONCACAF",
      Guatemala: "CONCACAF",
      Haiti: "CONCACAF",
      Honduras: "CONCACAF",
      Jamaica: "CONCACAF",
      Mexico: "CONCACAF",
      Panama: "CONCACAF",
      Suriname: "CONCACAF",
      "Trinidad and Tobago": "CONCACAF",
      USA: "CONCACAF",
      /* OFC. New Zealand is the only Oceanian side the player picker offers, but
         a confederation of one cannot run a qualifying group, so the other ten
         full members are here as opponents. List and count from
         en.wikipedia.org/wiki/Oceania_Football_Confederation (11 full members),
         read August 2026. */
      "New Zealand": "OFC",
      "New Caledonia": "OFC",
      Tahiti: "OFC",
      Fiji: "OFC",
      "Solomon Islands": "OFC",
      "Papua New Guinea": "OFC",
      Vanuatu: "OFC",
      Samoa: "OFC",
      "American Samoa": "OFC",
      "Cook Islands": "OFC",
      Tonga: "OFC"
    };
    CONFED_POOL = {
      UEFA: [],
      CONMEBOL: [],
      CAF: [],
      AFC: [],
      CONCACAF: [],
      OFC: []
    };
    for (const [nation, conf] of Object.entries(NATION_CONFED)) CONFED_POOL[conf].push(nation);
    FIFA_POINTS = {
      Spain: 1995.88,
      Argentina: 1970.37,
      France: 1948.97,
      England: 1922.83,
      Brazil: 1804.92,
      Morocco: 1803.99,
      Portugal: 1787.85,
      Belgium: 1778.36,
      Netherlands: 1775.54,
      Mexico: 1754.3,
      Colombia: 1739.89,
      Germany: 1726.22,
      Croatia: 1723.05,
      Switzerland: 1710.88,
      Italy: 1704.73,
      USA: 1690.33,
      Japan: 1673.68,
      Senegal: 1653.43,
      Norway: 1651.29,
      Uruguay: 1634.7,
      Denmark: 1619.47,
      Iran: 1609.85,
      Austria: 1598.82,
      Egypt: 1597.04,
      Ecuador: 1592.59,
      Nigeria: 1585.02,
      Turkey: 1582.54,
      Australia: 1581.51,
      Algeria: 1576.8,
      Canada: 1571.34,
      "Ivory Coast": 1565.47,
      "South Korea": 1558.72,
      Ukraine: 1549.29,
      Paraguay: 1542.48,
      Russia: 1529.6,
      Poland: 1526.18,
      Sweden: 1525.58,
      Wales: 1516.95,
      Hungary: 1506.39,
      Serbia: 1502.13,
      "DR Congo": 1495.48,
      Scotland: 1491.22,
      Cameroon: 1481.24,
      Panama: 1478.41,
      Slovakia: 1473.66,
      Greece: 1473.19,
      Venezuela: 1469.18,
      "Czech Republic": 1467.26,
      Chile: 1458.2,
      Peru: 1457.69,
      "Costa Rica": 1456.03,
      Romania: 1455.89,
      Mali: 1455.59,
      "South Africa": 1451.24,
      Ireland: 1441.1,
      // listed as Republic of Ireland
      Slovenia: 1441.09,
      Tunisia: 1426.58,
      "Saudi Arabia": 1425.52,
      Qatar: 1411.06,
      Uzbekistan: 1409.73,
      "Bosnia & Herzegovina": 1408.93,
      "Burkina Faso": 1406.99,
      Iraq: 1404.17,
      "Cape Verde": 1402.97,
      // listed as Cabo Verde
      Ghana: 1387,
      Honduras: 1378.97,
      Albania: 1376.03,
      "United Arab Emirates": 1370.47,
      "North Macedonia": 1369.16,
      "Northern Ireland": 1365.3,
      Jamaica: 1357.84,
      Georgia: 1355.26,
      Jordan: 1350.41,
      Iceland: 1342.77,
      Finland: 1341.92,
      Israel: 1333.9,
      Bolivia: 1326,
      Kosovo: 1319.12,
      Oman: 1306.9,
      Montenegro: 1301.98,
      Guinea: 1295.6,
      "Cura\xE7ao": 1285.64,
      Syria: 1283.05,
      Gabon: 1272.51,
      Bulgaria: 1271.68,
      "New Zealand": 1269.8,
      Angola: 1265.58,
      Haiti: 1264.58,
      Uganda: 1264.09,
      Thailand: 1256.73,
      Zambia: 1255.82,
      China: 1254.81,
      // listed as China PR
      Bahrain: 1254.41,
      Benin: 1252.17,
      Palestine: 1243.71,
      Belarus: 1242.88,
      Guatemala: 1238.74,
      Luxembourg: 1232.82,
      Vietnam: 1230.67,
      "El Salvador": 1225.34
    };
    RANK_ORDER = Object.entries(FIFA_POINTS).sort((a, b) => b[1] - a[1]).map((e) => e[0]);
  }
});

// src/lib/clubManagerUclGroups.ts
var init_clubManagerUclGroups = __esm({
  "src/lib/clubManagerUclGroups.ts"() {
  }
});

// src/data/clubRivalries.ts
var init_clubRivalries = __esm({
  "src/data/clubRivalries.ts"() {
  }
});

// src/lib/managerOffers.ts
var init_managerOffers = __esm({
  "src/lib/managerOffers.ts"() {
  }
});

// src/lib/soccerCareerEngine.ts
init_captaincy();
init_uclTieRule();

// src/lib/soccerCareerContinental.ts
init_soccerInternational();

// src/lib/careerIdentity.ts
function agentOf(id, sport) {
  return sport.agents.find((a) => a.id === id);
}
function agentWage(id, sport) {
  return agentOf(id, sport)?.wageMult ?? 1;
}
function agentTransferCut(id, sport) {
  if (!id) return sport.noAgentTransferCut;
  return agentOf(id, sport)?.transferCut ?? sport.noAgentTransferCut;
}

// src/lib/soccerCareerLife.ts
var PERSONALITIES = [
  {
    id: "showman",
    name: "The Showman",
    emoji: "\u{1F3AD}",
    blurb: "Cameras find you. You find them first.",
    perk: "Followers grow 60% faster, sponsors pay 25% more, scandals hit harder",
    followerMult: 1.6,
    sponsorMult: 1.25
  },
  {
    id: "iceman",
    name: "Ice Cold",
    emoji: "\u{1F9CA}",
    blurb: "No celebration. No panic. No comment.",
    perk: "Sponsors trust you, drama slides off, slower follower growth",
    followerMult: 0.9,
    sponsorMult: 1.05
  },
  {
    id: "hothead",
    name: "The Hothead",
    emoji: "\u{1F30B}",
    blurb: "Plays angry. Lives angrier.",
    perk: "Exclusive chaos events and fear-factor edges, riskier sponsor money",
    followerMult: 1.15,
    sponsorMult: 0.9
  },
  {
    id: "professor",
    name: "The Professor",
    emoji: "\u{1F4D0}",
    blurb: "Watches film on the team bus. For fun.",
    perk: "Respected by managers and brands, fewer viral moments",
    followerMult: 0.85,
    sponsorMult: 1.1
  },
  {
    id: "enigma",
    name: "The Enigma",
    emoji: "\u{1F0CF}",
    blurb: "Nobody, including you, knows what happens next.",
    perk: "Wildcard bonuses, cult following, chaos both ways",
    followerMult: 1.25,
    sponsorMult: 1
  }
];
var AGENTS = [
  {
    id: "cousin",
    name: "Cousin Ricky",
    emoji: "\u{1F9E2}",
    blurb: "Family discount. Family-grade paperwork.",
    wageMult: 0.95,
    incomeCut: 0,
    transferCut: 0.03
  },
  {
    id: "shark",
    name: "Marco De Luca",
    emoji: "\u{1F988}",
    blurb: "Mid-table clubs fear his ringtone.",
    wageMult: 1.1,
    incomeCut: 0.05,
    transferCut: 0.08
  },
  {
    id: "super",
    name: "Zara Blackwood",
    emoji: "\u{1F451}",
    blurb: "Has three club presidents on speed dial. Uses all three.",
    wageMult: 1.25,
    incomeCut: 0.1,
    transferCut: 0.12
  },
  {
    id: "self",
    name: "No Agent",
    emoji: "\u{1F91D}",
    blurb: "You negotiate for yourself.",
    wageMult: 1,
    incomeCut: 0,
    transferCut: 0
  }
];
var SOCCER_IDENTITY = {
  personalities: PERSONALITIES,
  agents: AGENTS,
  noAgentTransferCut: 0.1,
  beats: { personalityAge: 18, agentAge: 19 }
};
function agentWageMult(id) {
  return agentWage(id, SOCCER_IDENTITY);
}
function agentTransferCutRate(id) {
  return agentTransferCut(id, SOCCER_IDENTITY);
}

// src/lib/careerEras.ts
var rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
var S = (name, nationality, position, club, g0, g1, power) => ({ name, nationality, position, club, baseGoals: [g0, g1], power });
var ERA_DEFS = [
  {
    from: 1990,
    to: 1994,
    stars: [
      S("Marco van Basten", "Netherlands", "ST", "AC Milan", 19, 32, 10),
      S("Ruud Gullit", "Netherlands", "CAM", "AC Milan", 10, 20, 8),
      S("Frank Rijkaard", "Netherlands", "CDM", "AC Milan", 4, 10, 7),
      S("Lothar Matth\xE4us", "Germany", "CM", "Bayern Munich", 8, 16, 9),
      S("Roberto Baggio", "Italy", "CAM", "Juventus", 15, 25, 10),
      S("Hristo Stoichkov", "Bulgaria", "ST", "Barcelona", 16, 28, 9),
      S("Rom\xE1rio", "Brazil", "ST", "PSV", 22, 34, 9),
      S("Gabriel Batistuta", "Argentina", "ST", "Fiorentina", 18, 28, 7),
      S("J\xFCrgen Klinsmann", "Germany", "ST", "Monaco", 15, 25, 7),
      S("Dennis Bergkamp", "Netherlands", "ST", "Ajax", 12, 22, 7),
      S("George Weah", "Liberia", "ST", "PSG", 14, 24, 8),
      S("Paolo Maldini", "Italy", "CB", "AC Milan", 1, 4, 8),
      S("Franco Baresi", "Italy", "CB", "AC Milan", 0, 3, 7),
      S("Eric Cantona", "France", "ST", "Man United", 14, 22, 8),
      S("Ryan Giggs", "Wales", "LW", "Man United", 8, 15, 6),
      S("Gheorghe Hagi", "Romania", "CAM", "Brescia", 8, 15, 7),
      S("Peter Schmeichel", "Denmark", "GK", "Man United", 0, 0, 7),
      S("Alan Shearer", "England", "ST", "Blackburn Rovers", 22, 34, 7),
      S("Matthias Sammer", "Germany", "CB", "Dortmund", 4, 8, 7),
      S("Ra\xED", "Brazil", "CAM", "Sao Paulo", 8, 16, 5)
    ],
    topClubs: ["AC Milan", "Barcelona", "Juventus", "Man United", "Real Madrid", "Inter Milan", "Ajax", "Marseille", "Bayern Munich", "Benfica"],
    uclExtras: ["Porto", "PSG", "Parma", "Sampdoria", "Red Star Belgrade", "Steaua Bucharest"],
    leagues: {
      "Premier League": ["Man United", "Arsenal", "Blackburn Rovers", "Newcastle", "Leeds United", "Liverpool"],
      "La Liga": ["Barcelona", "Real Madrid", "Atletico Madrid", "Deportivo", "Valencia"],
      "Bundesliga": ["Bayern Munich", "Dortmund", "Werder Bremen", "Kaiserslautern", "Stuttgart"],
      "Serie A": ["AC Milan", "Juventus", "Inter Milan", "Napoli", "Sampdoria", "Lazio"],
      "Ligue 1": ["Marseille", "PSG", "Monaco", "Nantes", "Bordeaux"],
      /* Round 302: the leagues the owner named join the title race feed, each
         window listing the clubs that actually contested that half decade
         (champions first, verified against season records). MLS is absent
         before 1995 because the league first kicked off in 1996, and K League
         joins from 2010 when its club identities settled into the names the
         game uses; simCareerEras pins both exemptions. */
      "Primeira Liga": ["Porto", "Benfica", "Sporting CP"],
      "Eredivisie": ["Ajax", "PSV", "Feyenoord"],
      "Scottish Premiership": ["Rangers", "Celtic", "Aberdeen"],
      "Brasileirao": ["Sao Paulo", "Palmeiras", "Flamengo", "Corinthians"],
      "Saudi Pro League": ["Al Shabab", "Al Nassr", "Al Hilal"]
    },
    rivalFirsts: ["Stefan", "Dario", "Gianluca", "Patrik", "Emile", "Dejan", "Tomas", "Brian", "Oliver", "Marcelo", "Iv\xE1n", "Predrag", "Davor", "Nwankwo", "Marcel", "Youri", "Ariel", "Christophe", "Darko", "Kenneth"]
  },
  {
    from: 1995,
    to: 1999,
    stars: [
      S("Ronaldo", "Brazil", "ST", "Inter Milan", 25, 40, 10),
      S("Zinedine Zidane", "France", "CAM", "Juventus", 8, 16, 10),
      S("George Weah", "Liberia", "ST", "AC Milan", 16, 26, 9),
      S("Matthias Sammer", "Germany", "CB", "Dortmund", 4, 9, 8),
      S("Alessandro Del Piero", "Italy", "ST", "Juventus", 15, 25, 8),
      S("Rivaldo", "Brazil", "LW", "Barcelona", 18, 28, 9),
      S("Davor \u0160uker", "Croatia", "ST", "Real Madrid", 16, 26, 7),
      S("Michael Owen", "England", "ST", "Liverpool", 15, 24, 8),
      S("David Beckham", "England", "RW", "Man United", 6, 12, 8),
      S("Lu\xEDs Figo", "Portugal", "RW", "Barcelona", 8, 14, 8),
      S("Dennis Bergkamp", "Netherlands", "CAM", "Arsenal", 12, 20, 8),
      S("Gabriel Batistuta", "Argentina", "ST", "Fiorentina", 18, 28, 7),
      S("Roberto Carlos", "Brazil", "LB", "Real Madrid", 4, 8, 7),
      S("Ra\xFAl", "Spain", "ST", "Real Madrid", 16, 25, 7),
      S("Andriy Shevchenko", "Ukraine", "ST", "Dynamo Kyiv", 18, 28, 7),
      S("Eric Cantona", "France", "ST", "Man United", 12, 18, 6),
      S("Paolo Maldini", "Italy", "CB", "AC Milan", 1, 3, 7),
      S("Oliver Kahn", "Germany", "GK", "Bayern Munich", 0, 0, 7),
      S("Christian Vieri", "Italy", "ST", "Inter Milan", 16, 26, 6),
      S("Jaap Stam", "Netherlands", "CB", "PSV", 1, 3, 6)
    ],
    topClubs: ["Juventus", "AC Milan", "Real Madrid", "Man United", "Bayern Munich", "Barcelona", "Dortmund", "Ajax", "Inter Milan", "Arsenal"],
    uclExtras: ["Parma", "Lazio", "PSG", "Porto", "Newcastle", "Valencia"],
    leagues: {
      "Premier League": ["Man United", "Arsenal", "Newcastle", "Liverpool", "Chelsea", "Leeds United"],
      "La Liga": ["Real Madrid", "Barcelona", "Atletico Madrid", "Valencia", "Deportivo"],
      "Bundesliga": ["Bayern Munich", "Dortmund", "Kaiserslautern", "Leverkusen"],
      "Serie A": ["Juventus", "AC Milan", "Inter Milan", "Lazio", "Parma", "Fiorentina"],
      "Ligue 1": ["PSG", "Monaco", "Marseille", "Lyon", "Bordeaux"],
      "Primeira Liga": ["Porto", "Benfica", "Sporting CP"],
      "Eredivisie": ["Ajax", "PSV", "Feyenoord"],
      "Scottish Premiership": ["Rangers", "Celtic", "Hearts"],
      "Brasileirao": ["Corinthians", "Vasco da Gama", "Gremio", "Botafogo"],
      "Saudi Pro League": ["Al Hilal", "Al Ittihad", "Al Nassr"],
      "MLS": ["DC United", "Chicago Fire", "LA Galaxy"]
    },
    rivalFirsts: ["Stefan", "Dario", "Gianluca", "Patrik", "Emile", "Dejan", "Tomas", "Brian", "Oliver", "Marcelo", "Iv\xE1n", "Predrag", "Davor", "Nwankwo", "Marcel", "Youri", "Ariel", "Christophe", "Darko", "Kenneth"]
  },
  {
    from: 2e3,
    to: 2004,
    stars: [
      S("Zinedine Zidane", "France", "CAM", "Real Madrid", 8, 15, 10),
      S("Lu\xEDs Figo", "Portugal", "RW", "Real Madrid", 8, 14, 9),
      S("Michael Owen", "England", "ST", "Liverpool", 16, 26, 8),
      S("Ronaldo", "Brazil", "ST", "Real Madrid", 20, 30, 9),
      S("Pavel Nedv\u011Bd", "Czech Republic", "CAM", "Juventus", 10, 18, 8),
      S("Andriy Shevchenko", "Ukraine", "ST", "AC Milan", 20, 30, 9),
      S("Ronaldinho", "Brazil", "CAM", "Barcelona", 15, 25, 9),
      S("Thierry Henry", "France", "ST", "Arsenal", 24, 34, 9),
      S("Oliver Kahn", "Germany", "GK", "Bayern Munich", 0, 0, 8),
      S("Ra\xFAl", "Spain", "ST", "Real Madrid", 16, 26, 8),
      S("Rivaldo", "Brazil", "CAM", "Barcelona", 14, 24, 7),
      S("David Beckham", "England", "RW", "Man United", 5, 10, 7),
      S("Roberto Carlos", "Brazil", "LB", "Real Madrid", 4, 8, 7),
      S("Ruud van Nistelrooy", "Netherlands", "ST", "Man United", 22, 32, 8),
      S("Francesco Totti", "Italy", "CAM", "Roma", 14, 22, 7),
      S("Paolo Maldini", "Italy", "CB", "AC Milan", 1, 3, 6),
      S("Deco", "Portugal", "CM", "Porto", 8, 14, 7),
      S("Steven Gerrard", "England", "CM", "Liverpool", 8, 14, 7),
      S("Frank Lampard", "England", "CM", "Chelsea", 10, 18, 7),
      S("Samuel Eto'o", "Cameroon", "ST", "Mallorca", 16, 26, 6),
      S("Alessandro Nesta", "Italy", "CB", "AC Milan", 0, 3, 6)
    ],
    topClubs: ["Real Madrid", "Bayern Munich", "AC Milan", "Porto", "Barcelona", "Man United", "Juventus", "Arsenal", "Liverpool", "Inter Milan"],
    uclExtras: ["Valencia", "Deportivo", "Leeds United", "Lazio", "PSV", "Monaco"],
    leagues: {
      "Premier League": ["Man United", "Arsenal", "Chelsea", "Liverpool", "Newcastle", "Leeds United"],
      "La Liga": ["Real Madrid", "Barcelona", "Valencia", "Deportivo", "Atletico Madrid"],
      "Bundesliga": ["Bayern Munich", "Dortmund", "Leverkusen", "Werder Bremen", "Stuttgart"],
      "Serie A": ["Juventus", "AC Milan", "Inter Milan", "Roma", "Lazio"],
      "Ligue 1": ["Lyon", "Monaco", "PSG", "Marseille", "Bordeaux"],
      "Primeira Liga": ["Porto", "Sporting CP", "Boavista", "Benfica"],
      "Eredivisie": ["PSV", "Ajax", "Feyenoord"],
      "Scottish Premiership": ["Celtic", "Rangers", "Hearts"],
      "Brasileirao": ["Santos", "Cruzeiro", "Vasco da Gama", "Sao Paulo"],
      "Saudi Pro League": ["Al Ittihad", "Al Hilal", "Al Shabab"],
      "MLS": ["LA Galaxy", "San Jose Earthquakes", "DC United"]
    },
    rivalFirsts: ["Fernando", "Diego", "Andr\xE9s", "Wesley", "Robin", "Arjen", "Franck", "Ricardo", "Milan", "Dimitar", "Emmanuel", "Obafemi", "Landon", "Gonzalo", "Sergio", "Karim", "Cesc", "Theo", "Mikel", "Klaas"]
  },
  {
    from: 2005,
    to: 2009,
    stars: [
      S("Ronaldinho", "Brazil", "CAM", "Barcelona", 18, 26, 10),
      S("Fabio Cannavaro", "Italy", "CB", "Real Madrid", 0, 3, 8),
      S("Kak\xE1", "Brazil", "CAM", "AC Milan", 15, 25, 9),
      S("Cristiano Ronaldo", "Portugal", "RW", "Man United", 24, 42, 10),
      S("Lionel Messi", "Argentina", "RW", "Barcelona", 23, 38, 10),
      S("Thierry Henry", "France", "ST", "Barcelona", 18, 28, 8),
      S("Samuel Eto'o", "Cameroon", "ST", "Barcelona", 20, 30, 8),
      S("Fernando Torres", "Spain", "ST", "Liverpool", 18, 28, 8),
      S("Steven Gerrard", "England", "CM", "Liverpool", 10, 18, 8),
      S("Frank Lampard", "England", "CM", "Chelsea", 12, 20, 8),
      S("Xavi", "Spain", "CM", "Barcelona", 4, 10, 8),
      S("Andr\xE9s Iniesta", "Spain", "CM", "Barcelona", 4, 9, 8),
      S("Wayne Rooney", "England", "ST", "Man United", 14, 26, 8),
      S("Zlatan Ibrahimovi\u0107", "Sweden", "ST", "Inter Milan", 16, 26, 8),
      S("Gianluigi Buffon", "Italy", "GK", "Juventus", 0, 0, 8),
      S("Didier Drogba", "Ivory Coast", "ST", "Chelsea", 15, 28, 8),
      S("Franck Rib\xE9ry", "France", "LW", "Bayern Munich", 10, 18, 7),
      S("David Villa", "Spain", "ST", "Valencia", 18, 28, 7),
      S("Andrea Pirlo", "Italy", "CM", "AC Milan", 4, 9, 7),
      S("John Terry", "England", "CB", "Chelsea", 1, 4, 6)
    ],
    topClubs: ["Barcelona", "AC Milan", "Liverpool", "Man United", "Chelsea", "Real Madrid", "Inter Milan", "Bayern Munich", "Arsenal", "Juventus"],
    uclExtras: ["Lyon", "Porto", "Sevilla", "Valencia", "Roma", "PSV"],
    leagues: {
      "Premier League": ["Man United", "Chelsea", "Arsenal", "Liverpool", "Tottenham", "Everton"],
      "La Liga": ["Barcelona", "Real Madrid", "Valencia", "Sevilla", "Villarreal"],
      "Bundesliga": ["Bayern Munich", "Werder Bremen", "Stuttgart", "Wolfsburg", "Dortmund"],
      "Serie A": ["Inter Milan", "AC Milan", "Juventus", "Roma", "Fiorentina"],
      "Ligue 1": ["Lyon", "Marseille", "Bordeaux", "PSG", "Monaco"],
      "Primeira Liga": ["Porto", "Benfica", "Sporting CP"],
      "Eredivisie": ["PSV", "Ajax", "AZ Alkmaar", "Feyenoord"],
      "Scottish Premiership": ["Celtic", "Rangers", "Aberdeen"],
      "Brasileirao": ["Sao Paulo", "Corinthians", "Flamengo", "Internacional"],
      "Saudi Pro League": ["Al Hilal", "Al Ittihad", "Al Shabab"],
      "MLS": ["LA Galaxy", "Houston Dynamo", "Columbus Crew"]
    },
    rivalFirsts: ["Fernando", "Diego", "Andr\xE9s", "Wesley", "Robin", "Arjen", "Franck", "Ricardo", "Milan", "Dimitar", "Emmanuel", "Obafemi", "Landon", "Gonzalo", "Sergio", "Karim", "Cesc", "Theo", "Mikel", "Klaas"]
  },
  {
    from: 2010,
    to: 2014,
    stars: [
      S("Lionel Messi", "Argentina", "RW", "Barcelona", 35, 55, 10),
      S("Cristiano Ronaldo", "Portugal", "ST", "Real Madrid", 35, 55, 10),
      S("Xavi", "Spain", "CM", "Barcelona", 4, 10, 8),
      S("Andr\xE9s Iniesta", "Spain", "CM", "Barcelona", 4, 9, 9),
      S("Neymar", "Brazil", "LW", "Santos", 15, 28, 8),
      S("Zlatan Ibrahimovi\u0107", "Sweden", "ST", "PSG", 20, 32, 8),
      S("Wayne Rooney", "England", "ST", "Man United", 15, 27, 7),
      S("Franck Rib\xE9ry", "France", "LW", "Bayern Munich", 10, 18, 9),
      S("Arjen Robben", "Netherlands", "RW", "Bayern Munich", 12, 20, 8),
      S("Radamel Falcao", "Colombia", "ST", "Atletico Madrid", 22, 32, 7),
      S("Gareth Bale", "Wales", "RW", "Tottenham", 14, 22, 8),
      S("Luis Su\xE1rez", "Uruguay", "ST", "Liverpool", 22, 32, 8),
      S("Robert Lewandowski", "Poland", "ST", "Dortmund", 20, 30, 8),
      S("Sergio Ag\xFCero", "Argentina", "ST", "Man City", 20, 30, 8),
      S("Manuel Neuer", "Germany", "GK", "Bayern Munich", 0, 0, 9),
      S("Thomas M\xFCller", "Germany", "CAM", "Bayern Munich", 12, 22, 8),
      S("Sergio Ramos", "Spain", "CB", "Real Madrid", 3, 6, 7),
      S("Yaya Tour\xE9", "Ivory Coast", "CM", "Man City", 12, 20, 7),
      S("Eden Hazard", "Belgium", "LW", "Chelsea", 12, 18, 7),
      S("Andrea Pirlo", "Italy", "CM", "Juventus", 3, 7, 7),
      S("James Rodr\xEDguez", "Colombia", "CAM", "Porto", 10, 16, 6)
    ],
    topClubs: ["Barcelona", "Real Madrid", "Bayern Munich", "Chelsea", "Inter Milan", "Man United", "Dortmund", "Atletico Madrid", "Man City", "Juventus"],
    uclExtras: ["PSG", "Liverpool", "Porto", "Napoli", "Sevilla", "AC Milan"],
    leagues: {
      "Premier League": ["Man United", "Man City", "Chelsea", "Arsenal", "Liverpool", "Tottenham"],
      "La Liga": ["Barcelona", "Real Madrid", "Atletico Madrid", "Valencia", "Sevilla"],
      "Bundesliga": ["Bayern Munich", "Dortmund", "Leverkusen", "Schalke"],
      "Serie A": ["Juventus", "AC Milan", "Inter Milan", "Napoli", "Roma"],
      "Ligue 1": ["PSG", "Marseille", "Lyon", "Monaco", "Lille"],
      "Primeira Liga": ["Porto", "Benfica", "Braga", "Sporting CP"],
      "Eredivisie": ["Ajax", "Twente", "PSV", "Feyenoord"],
      "Scottish Premiership": ["Celtic", "Rangers", "Aberdeen"],
      "Brasileirao": ["Fluminense", "Corinthians", "Cruzeiro", "Sao Paulo"],
      "Saudi Pro League": ["Al Hilal", "Al Nassr", "Al Shabab"],
      "MLS": ["LA Galaxy", "Sporting Kansas City", "Real Salt Lake"],
      "K League 1": ["FC Seoul", "Jeonbuk Motors", "Pohang Steelers", "Ulsan HD"]
    },
    rivalFirsts: ["Eden", "Isco", "Paulo", "Romelu", "Memphis", "Alexis", "\xC1ngel", "Edinson", "Mario", "Marco", "Antoine", "Ousmane", "Leroy", "Kingsley", "Dele", "Raheem", "Thiago", "Ciro", "James", "Granit"]
  },
  {
    from: 2015,
    to: 2019,
    stars: [
      S("Lionel Messi", "Argentina", "RW", "Barcelona", 30, 50, 10),
      S("Cristiano Ronaldo", "Portugal", "ST", "Real Madrid", 28, 48, 10),
      S("Neymar", "Brazil", "LW", "PSG", 18, 30, 8),
      S("Luis Su\xE1rez", "Uruguay", "ST", "Barcelona", 24, 40, 8),
      S("Antoine Griezmann", "France", "ST", "Atletico Madrid", 16, 26, 8),
      S("Kylian Mbapp\xE9", "France", "ST", "PSG", 18, 33, 9),
      S("Mohamed Salah", "Egypt", "RW", "Liverpool", 20, 32, 9),
      S("Kevin De Bruyne", "Belgium", "CAM", "Man City", 8, 16, 9),
      S("Eden Hazard", "Belgium", "LW", "Chelsea", 12, 21, 8),
      S("Luka Modri\u0107", "Croatia", "CM", "Real Madrid", 3, 8, 9),
      S("Robert Lewandowski", "Poland", "ST", "Bayern Munich", 25, 40, 9),
      S("Sergio Ag\xFCero", "Argentina", "ST", "Man City", 18, 28, 7),
      S("Harry Kane", "England", "ST", "Tottenham", 22, 32, 8),
      S("Sadio Man\xE9", "Senegal", "LW", "Liverpool", 16, 26, 8),
      S("Virgil van Dijk", "Netherlands", "CB", "Liverpool", 2, 6, 9),
      S("Gareth Bale", "Wales", "RW", "Real Madrid", 10, 18, 7),
      S("Paulo Dybala", "Argentina", "CAM", "Juventus", 12, 22, 7),
      S("N'Golo Kant\xE9", "France", "CDM", "Chelsea", 2, 5, 8),
      S("Raheem Sterling", "England", "LW", "Man City", 15, 25, 7),
      S("Alisson Becker", "Brazil", "GK", "Liverpool", 0, 0, 7)
    ],
    topClubs: ["Real Madrid", "Barcelona", "Bayern Munich", "Liverpool", "Atletico Madrid", "Juventus", "Man City", "PSG", "Tottenham", "Ajax"],
    uclExtras: ["Roma", "Monaco", "Napoli", "Dortmund", "Sevilla", "Porto"],
    leagues: {
      "Premier League": ["Man City", "Liverpool", "Chelsea", "Tottenham", "Arsenal", "Man United"],
      "La Liga": ["Barcelona", "Real Madrid", "Atletico Madrid", "Sevilla", "Valencia"],
      "Bundesliga": ["Bayern Munich", "Dortmund", "Leipzig", "Leverkusen"],
      "Serie A": ["Juventus", "Napoli", "Roma", "Inter Milan", "AC Milan"],
      "Ligue 1": ["PSG", "Monaco", "Lyon", "Marseille", "Lille"],
      "Primeira Liga": ["Benfica", "Porto", "Sporting CP"],
      "Eredivisie": ["PSV", "Ajax", "Feyenoord"],
      "Scottish Premiership": ["Celtic", "Rangers", "Aberdeen"],
      "Brasileirao": ["Palmeiras", "Corinthians", "Flamengo", "Santos"],
      "Saudi Pro League": ["Al Hilal", "Al Nassr", "Al Ahli"],
      "MLS": ["Seattle Sounders", "Toronto FC", "Atlanta United", "Portland Timbers"],
      "K League 1": ["Jeonbuk Motors", "FC Seoul", "Ulsan HD"]
    },
    rivalFirsts: ["Eden", "Isco", "Paulo", "Romelu", "Memphis", "Alexis", "\xC1ngel", "Edinson", "Mario", "Marco", "Antoine", "Ousmane", "Leroy", "Kingsley", "Dele", "Raheem", "Thiago", "Ciro", "James", "Granit"]
  },
  {
    from: 2020,
    to: 2024,
    stars: [
      S("Lionel Messi", "Argentina", "RW", "PSG", 16, 30, 10),
      S("Robert Lewandowski", "Poland", "ST", "Barcelona", 30, 48, 10),
      S("Karim Benzema", "France", "ST", "Real Madrid", 22, 40, 10),
      S("Kylian Mbapp\xE9", "France", "ST", "PSG", 25, 42, 9),
      S("Erling Haaland", "Norway", "ST", "Man City", 28, 48, 9),
      S("Kevin De Bruyne", "Belgium", "CAM", "Man City", 7, 15, 8),
      S("Mohamed Salah", "Egypt", "RW", "Liverpool", 18, 30, 8),
      S("Vin\xEDcius Jr", "Brazil", "LW", "Real Madrid", 15, 26, 9),
      S("Jude Bellingham", "England", "CAM", "Dortmund", 12, 23, 8),
      S("Rodri", "Spain", "CDM", "Man City", 4, 10, 9),
      S("Luka Modri\u0107", "Croatia", "CM", "Real Madrid", 2, 6, 7),
      S("Harry Kane", "England", "ST", "Tottenham", 25, 40, 8),
      S("Neymar", "Brazil", "LW", "PSG", 12, 22, 7),
      S("Lautaro Mart\xEDnez", "Argentina", "ST", "Inter Milan", 18, 28, 7),
      S("Bukayo Saka", "England", "RW", "Arsenal", 12, 22, 7),
      S("Phil Foden", "England", "CAM", "Man City", 12, 20, 7),
      S("Federico Valverde", "Uruguay", "CM", "Real Madrid", 5, 12, 7),
      S("Antoine Griezmann", "France", "CAM", "Atletico Madrid", 12, 20, 7),
      S("Virgil van Dijk", "Netherlands", "CB", "Liverpool", 2, 5, 7),
      S("Thibaut Courtois", "Belgium", "GK", "Real Madrid", 0, 0, 7)
    ],
    topClubs: ["Real Madrid", "Man City", "Bayern Munich", "Chelsea", "Liverpool", "PSG", "Inter Milan", "Barcelona", "Arsenal", "Dortmund"],
    uclExtras: ["Atletico Madrid", "Napoli", "Benfica", "Porto", "AC Milan", "Ajax"],
    leagues: {
      "Premier League": ["Man City", "Liverpool", "Arsenal", "Chelsea", "Man United", "Tottenham"],
      "La Liga": ["Real Madrid", "Barcelona", "Atletico Madrid", "Sevilla", "Real Sociedad"],
      "Bundesliga": ["Bayern Munich", "Dortmund", "Leipzig", "Leverkusen"],
      "Serie A": ["Inter Milan", "AC Milan", "Napoli", "Juventus", "Atalanta"],
      "Ligue 1": ["PSG", "Marseille", "Monaco", "Lille", "Lyon"],
      "Primeira Liga": ["Porto", "Sporting CP", "Benfica", "Braga"],
      "Eredivisie": ["Ajax", "PSV", "Feyenoord"],
      "Scottish Premiership": ["Celtic", "Rangers", "Hearts"],
      "Brasileirao": ["Palmeiras", "Flamengo", "Atletico Mineiro", "Botafogo"],
      "Saudi Pro League": ["Al Hilal", "Al Ittihad", "Al Nassr"],
      "MLS": ["LAFC", "Columbus Crew", "LA Galaxy", "Inter Miami"],
      "K League 1": ["Ulsan HD", "Jeonbuk Motors", "Pohang Steelers"]
    },
    rivalFirsts: ["Kylian", "Erling", "Jude", "Bukayo", "Lamine", "Jamal", "Florian", "Pablo", "Jules", "Aur\xE9lien", "Eduardo", "Rasmus", "Cole", "Alejandro", "Xavi", "Kenan", "Arda", "Endrick", "Mathys", "Kobbie"]
  },
  {
    from: 2025,
    to: 2029,
    stars: [
      S("Kylian Mbapp\xE9", "France", "ST", "Real Madrid", 28, 45, 10),
      S("Erling Haaland", "Norway", "ST", "Man City", 28, 46, 9),
      S("Jude Bellingham", "England", "CAM", "Real Madrid", 12, 24, 9),
      S("Vin\xEDcius Jr", "Brazil", "LW", "Real Madrid", 16, 28, 9),
      S("Lamine Yamal", "Spain", "RW", "Barcelona", 14, 28, 10),
      S("Florian Wirtz", "Germany", "CAM", "Liverpool", 10, 22, 8),
      S("Jamal Musiala", "Germany", "CAM", "Bayern Munich", 10, 20, 8),
      S("Bukayo Saka", "England", "RW", "Arsenal", 12, 24, 8),
      S("Pedri", "Spain", "CM", "Barcelona", 4, 12, 8),
      S("Rodri", "Spain", "CDM", "Barcelona", 3, 9, 8),
      S("Federico Valverde", "Uruguay", "CM", "Real Madrid", 6, 12, 7),
      S("Harry Kane", "England", "ST", "Bayern Munich", 24, 38, 8),
      S("Mohamed Salah", "Egypt", "RW", "Trabzonspor", 16, 28, 7),
      S("Phil Foden", "England", "CAM", "Man City", 10, 20, 7),
      S("Declan Rice", "England", "CDM", "Arsenal", 4, 10, 7),
      S("Raphinha", "Brazil", "RW", "Barcelona", 14, 26, 8),
      S("Endrick", "Brazil", "ST", "Real Madrid", 12, 24, 7),
      S("Nico Williams", "Spain", "LW", "Athletic Bilbao", 10, 20, 7),
      S("D\xE9sir\xE9 Dou\xE9", "France", "LW", "PSG", 8, 18, 7),
      S("Kobbie Mainoo", "England", "CM", "Man United", 3, 10, 6),
      S("Gianluigi Donnarumma", "Italy", "GK", "Man City", 0, 0, 7),
      S("Ousmane Demb\xE9l\xE9", "France", "LW", "PSG", 14, 28, 9)
    ],
    topClubs: ["Real Madrid", "Man City", "Barcelona", "Bayern Munich", "Arsenal", "Liverpool", "PSG", "Inter Milan", "Leverkusen", "Chelsea"],
    uclExtras: ["Newcastle", "Atletico Madrid", "Napoli", "Benfica", "Dortmund", "Juventus"],
    leagues: {
      "Premier League": ["Man City", "Arsenal", "Liverpool", "Chelsea", "Man United", "Newcastle"],
      "La Liga": ["Real Madrid", "Barcelona", "Atletico Madrid", "Athletic Bilbao", "Girona"],
      "Bundesliga": ["Bayern Munich", "Leverkusen", "Dortmund", "Leipzig"],
      "Serie A": ["Inter Milan", "Napoli", "AC Milan", "Juventus", "Atalanta"],
      "Ligue 1": ["PSG", "Monaco", "Marseille", "Lille", "Lyon"],
      "Primeira Liga": ["Sporting CP", "Benfica", "Porto"],
      "Eredivisie": ["PSV", "Ajax", "Feyenoord"],
      "Scottish Premiership": ["Celtic", "Rangers", "Aberdeen"],
      "Brasileirao": ["Flamengo", "Palmeiras", "Botafogo", "Cruzeiro"],
      "Saudi Pro League": ["Al Ittihad", "Al Hilal", "Al Nassr"],
      "MLS": ["Inter Miami", "LAFC", "Columbus Crew", "Seattle Sounders"],
      "K League 1": ["Jeonbuk Motors", "Ulsan HD", "Pohang Steelers"]
    },
    rivalFirsts: ["Kylian", "Erling", "Jude", "Bukayo", "Lamine", "Jamal", "Florian", "Pablo", "Jules", "Aur\xE9lien", "Eduardo", "Rasmus", "Cole", "Alejandro", "Xavi", "Kenan", "Arda", "Endrick", "Mathys", "Kobbie"]
  }
];
var CLUB_FOUNDED_AFTER = {
  "Leipzig": 2010,
  "RB Leipzig": 2010,
  "Inter Miami": 2020,
  "LAFC": 2018,
  "Los Angeles FC": 2018,
  "New York City FC": 2015,
  "Austin FC": 2021,
  "Charlotte FC": 2022,
  // Round 54 club expansion: keep the new-world clubs out of eras where they
  // did not exist yet (or were not professional outfits yet).
  "Toronto FC": 2006,
  "Vancouver Whitecaps": 2011,
  "Melbourne Victory": 2004,
  "Wellington Phoenix": 2007,
  "Auckland FC": 2024,
  "Mumbai City": 2014,
  "Buriram United": 2012,
  "Hanoi FC": 2006,
  "Al Duhail": 2009,
  "Shanghai Port": 2005,
  "Sheriff Tiraspol": 1997,
  "Beijing Guoan": 1992,
  /* Round 302 league depth pass. MLS kicked off in 1996, so its two founding
     era clubs date from there (a gap this table had all along for LA Galaxy),
     and the newer franchises from their own first seasons. */
  "LA Galaxy": 1996,
  "Columbus Crew": 1996,
  "Seattle Sounders": 2007,
  "Atlanta United": 2017,
  /* Round 1013: the club played as Bragantino until Red Bull's rebrand for
     the 2020 season (Planet Football's Red Bull in Brazil piece, and Lance!'s
     2020 badge and kit launch, read 2026-10-05). Same rule as RB Leipzig: the
     name did not exist before then. */
  "Red Bull Bragantino": 2020
};
var ERA_TIER_RULES = [
  { name: "Man City", until: 2008, tier: 4 },
  { name: "Man City", until: 2010, tier: 2 },
  { name: "Chelsea", until: 1996, tier: 3 },
  { name: "Chelsea", until: 2003, tier: 2 },
  { name: "PSG", until: 2011, tier: 2 },
  { name: "Arsenal", until: 1996, tier: 2 },
  { name: "Liverpool", until: 2e3, tier: 2 },
  { name: "AC Milan", until: 2011, tier: 1 },
  { name: "Napoli", until: 1992, tier: 2 },
  { name: "Napoli", until: 2010, tier: 4 },
  { name: "Newcastle", from: 2007, until: 2021, tier: 3 },
  { name: "Tottenham", until: 2009, tier: 3 },
  { name: "Atletico Madrid", until: 2010, tier: 3 },
  { name: "Dortmund", until: 1993, tier: 3 },
  { name: "Dortmund", until: 2002, tier: 1 },
  { name: "Monaco", until: 2004, tier: 2 },
  { name: "Marseille", until: 1993, tier: 1 },
  { name: "Al Hilal", until: 2022, tier: 4 },
  { name: "Al Nassr", until: 2022, tier: 4 },
  { name: "Leipzig", until: 2015, tier: 4 },
  // Round 54: era-honest tiers for the expansion clubs
  { name: "Girona", until: 2022, tier: 4 },
  { name: "Al Ittihad", until: 2022, tier: 4 },
  { name: "Brighton", until: 2016, tier: 4 },
  { name: "Brighton", until: 2021, tier: 3 },
  { name: "Wolves", until: 2017, tier: 4 },
  { name: "Zenit", until: 2006, tier: 4 },
  { name: "Shakhtar Donetsk", until: 1999, tier: 4 },
  /* Round 1013: Forest were relegated in 1999 and came back up through the
     2022 Championship play-off final, so 1999-00 to 2021-22 were spent
     outside the top flight (ESPN's 29 May 2022 match report and Sports
     Illustrated the same day, "the first time since 1999"). Their tier 2 is
     Club Manager's 2026 XI and would otherwise apply in every era. The two
     earlier second tier seasons, 1993-94 (Division One runners up) and
     1997-98 (Division One champions), get one season rules of their own
     (rsssf's Football League tables for both seasons and Wikipedia's list
     of the club's seasons, read 2026-10-05). */
  { name: "Nottingham Forest", from: 1993, until: 1993, tier: 4 },
  { name: "Nottingham Forest", from: 1997, until: 1997, tier: 4 },
  { name: "Nottingham Forest", from: 1999, until: 2021, tier: 4 }
];
function adjustClubsForYear(clubs, year) {
  return clubs.filter((c) => {
    const founded = CLUB_FOUNDED_AFTER[c.name];
    return founded === void 0 || year >= founded;
  }).map((c) => {
    for (const rule of ERA_TIER_RULES) {
      if (rule.name !== c.name) continue;
      if (rule.from !== void 0 && year < rule.from) continue;
      if (rule.until !== void 0 && year > rule.until) continue;
      if (c.tier === rule.tier) return c;
      return { ...c, tier: rule.tier };
    }
    return c;
  });
}
function rollPotential(startingOvr) {
  const r = Math.random();
  let pot;
  if (r < 0.5) pot = rand(70, 79);
  else if (r < 0.8) pot = rand(78, 84);
  else if (r < 0.93) pot = rand(84, 89);
  else if (r < 0.985) pot = rand(89, 93);
  else pot = rand(93, 97);
  return Math.min(99, Math.max(pot, startingOvr + 6));
}
var PHONE_POOL = [
  {
    id: "mum_call",
    from: "Mum",
    emoji: "\u2764\uFE0F",
    phase: "any",
    text: "Hi love, haven't heard from you in weeks. Everything ok? Call me when you can.",
    choices: [
      { label: "Call her tonight", reply: "Calling you after training, promise. Love you", karma: 8, morale: 6 },
      { label: "Leave it on read", reply: "", karma: -6, morale: -2 }
    ]
  },
  {
    id: "kid_dm",
    from: "Fan DM",
    emoji: "\u{1F9D2}",
    phase: "any",
    text: "ur my favorite player ever. im in hospital and my dream is a signed shirt. no worries if not",
    choices: [
      { label: "Send a signed shirt and visit", reply: "Shirt is on the way and I'm coming to see you next week. Stay strong", karma: 12, popularity: 6, cash: -0.1 },
      { label: "Send the shirt", reply: "On its way little legend", karma: 6, popularity: 3 },
      { label: "Ignore it", reply: "", karma: -8 }
    ]
  },
  {
    id: "agent_boots",
    from: "Agent",
    emoji: "\u{1F4BC}",
    phase: "any",
    text: "Boot deal on the table. Decent money but the brand got caught using sweatshops last year. Your call.",
    choices: [
      { label: "Take the money", reply: "Money is money. Send the contract", karma: -7, cash: 1.5 },
      { label: "Turn it down publicly", reply: "Not wearing that. And I'm saying why", karma: 9, popularity: 4 },
      { label: "Quietly decline", reply: "Pass on this one. Keep it quiet", karma: 4 }
    ]
  },
  {
    id: "teammate_benched",
    from: "Teammate",
    emoji: "\u{1F624}",
    phase: "pro",
    text: "Gaffer benched me again bro. Thinking of asking away in January. You think I should go?",
    choices: [
      { label: "Be honest with him", reply: "You deserve minutes mate. If he won't give them, go get them somewhere", karma: 6, morale: 2 },
      { label: "Tell him to stop whining", reply: "Train harder then. Nobody owes you a shirt", karma: -5 },
      { label: "Dodge the question", reply: "Tough one bro. Sleep on it", karma: -1 }
    ]
  },
  {
    id: "granny_scam",
    from: "Unknown",
    emoji: "\u{1F3A3}",
    phase: "any",
    text: "CONGRATULATIONS! You won 2 MILLION. Just send account details plus a small release fee to claim.",
    choices: [
      { label: "Report and warn fans", reply: "Posting this so nobody falls for it. Stay safe out there", karma: 7, popularity: 3 },
      { label: "Delete it", reply: "", karma: 1 },
      { label: "Reply as a joke and string them along", reply: "Amazing news!! My account number is 1-2-3-GET-A-JOB", karma: 2, popularity: 2 }
    ]
  },
  {
    id: "kitman_fine",
    from: "Kit man",
    emoji: "\u{1F9FA}",
    phase: "pro",
    text: "You left the away kit at the hotel AGAIN. Club wants to fine you. I can cover for you this once.",
    choices: [
      { label: "Own it, pay the fine", reply: "My fault Tony. I'll pay it. Pint on me too", karma: 7, cash: -0.05 },
      { label: "Let him cover for you", reply: "You're a legend. I owe you", karma: -5, morale: 2 }
    ]
  },
  {
    id: "charity_gala",
    from: "Foundation",
    emoji: "\u{1F397}\uFE0F",
    phase: "pro",
    minAge: 19,
    text: "We're hosting a children's hospital gala Friday. Would mean the world if you came. Press will be there.",
    choices: [
      { label: "Go and donate", reply: "Count me in. And put me down for a donation", karma: 10, popularity: 5, cash: -0.5 },
      { label: "Go for the cameras only", reply: "I'll swing by for an hour", karma: 2, popularity: 3 },
      { label: "Skip it", reply: "Can't make it, good luck", karma: -6 }
    ]
  },
  {
    id: "old_coach",
    from: "Youth coach",
    emoji: "\u{1F474}",
    phase: "pro",
    text: "Watched you play last weekend. Still remember you at 12 refusing to pass. Proud of you kid.",
    choices: [
      { label: "Thank him properly", reply: "Everything started with you coach. Tickets for you whenever you want, for life", karma: 8, morale: 5 },
      { label: "Thumbs up emoji", reply: "\u{1F44D}", karma: -3 }
    ]
  },
  {
    id: "party_final",
    from: "Promoter",
    emoji: "\u{1F389}",
    phase: "pro",
    minAge: 18,
    text: "Biggest party of the year Saturday night. VIP table with your name on it. Cup final is Sunday btw.",
    choices: [
      { label: "Stay home and rest", reply: "Final tomorrow. Another time", karma: 6, morale: 2 },
      { label: "Go but leave early", reply: "One hour max, then I'm gone", karma: -3, popularity: 2 },
      { label: "Full send", reply: "Save me the good seat", karma: -9, popularity: 4, morale: 3 }
    ]
  },
  {
    id: "rookie_advice",
    from: "Academy kid",
    emoji: "\u{1F331}",
    phase: "pro",
    minAge: 21,
    text: "Just got promoted to first team training. Any advice? Kinda terrified honestly.",
    choices: [
      { label: "Take him under your wing", reply: "Come in early tomorrow, we'll do finishing drills together. You'll be fine", karma: 9, morale: 3 },
      { label: "One line of advice", reply: "First ball, first tackle, win it. Rest follows", karma: 4 },
      { label: "Big time him", reply: "Earn it like I did", karma: -7 }
    ]
  },
  {
    id: "journalist_leak",
    from: "Journalist",
    emoji: "\u{1F4F0}",
    phase: "pro",
    text: "I know the dressing room fell out with the manager. Give me the inside story, I'll keep you anonymous.",
    choices: [
      { label: "Keep it in house", reply: "Nothing to tell. Dressing room stays in the dressing room", karma: 8, morale: 2 },
      { label: "Leak it", reply: "Ok but this NEVER came from me", karma: -10, popularity: 3 }
    ]
  },
  {
    id: "barber_cut",
    from: "Barber",
    emoji: "\u{1F488}",
    phase: "any",
    text: "New style idea for you. Bold. Might break the internet, might get you fined by the boss. You in?",
    choices: [
      { label: "Send it", reply: "Chair. Tomorrow. Do your worst", karma: 2, popularity: 4 },
      { label: "Keep it classic", reply: "Usual trim mate, big game week", karma: 1 }
    ]
  },
  {
    id: "lost_wallet",
    from: "Groundskeeper",
    emoji: "\u{1F45B}",
    phase: "any",
    text: "Found a wallet in the car park with 800 quid inside. No ID. What do I do with it?",
    choices: [
      { label: "Hand it to reception", reply: "Reception, mate. Someone's having a bad day", karma: 6 },
      { label: "Finders keepers", reply: "That's the football gods paying you. Keep it", karma: -6 }
    ]
  },
  {
    id: "ex_club_message",
    from: "Old teammate",
    emoji: "\u{1FAC2}",
    phase: "pro",
    minAge: 22,
    text: "Club legends match at your first club next month. They're asking if you'd come back and play 45 minutes.",
    choices: [
      { label: "Play the full 90", reply: "45? I'm playing the whole thing. That badge made me", karma: 8, popularity: 4, morale: 3 },
      { label: "Politely decline", reply: "Season's too heavy, give everyone my love", karma: -2 }
    ]
  },
  {
    id: "crypto_bro",
    from: "School friend",
    emoji: "\u{1FA99}",
    phase: "pro",
    minAge: 19,
    text: "Bro I need you to promote my new coin BallerCoin to your followers. It's guaranteed 100x. Family discount.",
    choices: [
      { label: "Hard pass", reply: "Not putting my fans into that. Look after yourself", karma: 7 },
      { label: "Promote it", reply: "Sending the post now. We better get rich", karma: -11, cash: 0.8, popularity: -3 }
    ]
  },
  {
    id: "training_extra",
    from: "Fitness coach",
    emoji: "\u{1F3CB}\uFE0F",
    phase: "any",
    text: "Optional double sessions next month. Brutal but they work. Most of the squad is dodging them.",
    choices: [
      { label: "Sign up", reply: "Put my name down. First one in, last one out", karma: 5, morale: -2 },
      { label: "Skip them", reply: "Rest is part of training too coach", karma: -3, morale: 2 }
    ]
  },
  {
    id: "youth_bully",
    from: "Academy mate",
    emoji: "\u{1F97A}",
    phase: "youth",
    text: "The older lads keep hiding my boots and binning my kit. Coach says toughen up. Don't know what to do.",
    choices: [
      { label: "Stand up for him", reply: "Sit with me at lunch. If they touch your stuff again they deal with me", karma: 10, morale: 2 },
      { label: "Stay out of it", reply: "Rough mate. Keep your head down", karma: -6 }
    ]
  },
  {
    id: "youth_homework",
    from: "Tutor",
    emoji: "\u{1F4DA}",
    phase: "youth",
    text: "You've missed three sessions. The academy requires passing grades to keep your registration. Tonight, 6pm?",
    choices: [
      { label: "Show up", reply: "I'll be there. Sorry, no excuses", karma: 6 },
      { label: "Blow it off for extra shooting", reply: "Football is my exam", karma: -4 }
    ]
  },
  {
    id: "youth_poach",
    from: "Stranger",
    emoji: "\u{1F576}\uFE0F",
    phase: "youth",
    text: "I represent players. Ditch the academy's advisor, sign with me quietly, I'll get your family paid NOW.",
    choices: [
      { label: "Tell the academy", reply: "Reported you to the club. Don't message me again", karma: 8 },
      { label: "Meet him in secret", reply: "Where and when?", karma: -8, cash: 0.05 }
    ]
  },
  {
    id: "nutrition_cheat",
    from: "Nutritionist",
    emoji: "\u{1F957}",
    phase: "any",
    text: "Your body fat crept up. I'm putting you on the strict plan. No takeaways for eight weeks. Confirm?",
    choices: [
      { label: "Commit fully", reply: "Locked in. Hide the menus", karma: 5, morale: -1 },
      { label: "Secret cheat days", reply: "Confirmed \u{1F607} (orders kebab)", karma: -4, morale: 3 }
    ]
  },
  {
    id: "grandad_game",
    from: "Grandad",
    emoji: "\u{1F9D3}",
    phase: "any",
    text: "Never miss you on the telly. My hip's too dodgy for the stadium now. One day take the trophy round mine eh?",
    choices: [
      { label: "Visit with your shirt", reply: "Coming round Sunday with a shirt and biscuits. Put the kettle on", karma: 9, morale: 5 },
      { label: "Promise vaguely", reply: "One day grandad, promise", karma: 1 }
    ]
  },
  {
    id: "referee_apology",
    from: "Referee assoc.",
    emoji: "\u{1F7E8}",
    phase: "pro",
    text: "Your comments about Saturday's officiating went viral. We'd welcome a public clarification.",
    choices: [
      { label: "Apologize properly", reply: "I was out of order. Refs have the hardest job in football. Apologies", karma: 6, popularity: -1 },
      { label: "Double down", reply: "I said what I said", karma: -7, popularity: 5 }
    ]
  },
  {
    id: "stadium_worker",
    from: "Steward",
    emoji: "\u{1F9BA}",
    phase: "pro",
    text: "30 years at this club, retiring Saturday. Would you sign my hi-vis after the game? Means a lot.",
    choices: [
      { label: "Sign it and get the squad to", reply: "I'll get the whole squad on it. Thanks for everything", karma: 9, popularity: 3 },
      { label: "If there's time", reply: "If I can, busy day", karma: -2 }
    ]
  },
  {
    id: "diving_tip",
    from: "Veteran",
    emoji: "\u{1F3AD}",
    phase: "pro",
    maxAge: 24,
    text: "Kid, lesson one. In the box, feel contact, go down. Refs give it every time. That's how you win games.",
    choices: [
      { label: "Refuse to dive", reply: "I stay on my feet. I score them properly", karma: 8 },
      { label: "Take the advice", reply: "Noted. Whatever wins", karma: -8 }
    ]
  },
  {
    id: "hometown_pitch",
    from: "Council",
    emoji: "\u{1F3D7}\uFE0F",
    phase: "pro",
    minAge: 20,
    text: "The pitch you grew up on is closing without funding. 200 kids play there weekly. Sponsorship would save it.",
    choices: [
      { label: "Fund it and rename it", reply: "I'll cover it. Name it after my old coach, not me", karma: 12, popularity: 5, cash: -1.2 },
      { label: "Fund it quietly", reply: "Invoice my foundation. No press", karma: 10, cash: -1.2 },
      { label: "Share a fundraiser", reply: "Posting the link, let's all chip in", karma: 4, popularity: 1 }
    ]
  },
  {
    id: "team_fine_pot",
    from: "Captain",
    emoji: "\u{1F37A}",
    phase: "pro",
    text: "End of season squad night out, fines pot pays. You're 400 in the pot for late gym arrivals. Coming?",
    choices: [
      { label: "Pay up and go", reply: "Fair cop. First round's the fine pot anyway", karma: 4, morale: 4, cash: -0.01 },
      { label: "Dispute the fines", reply: "The gym clock is WRONG and I have evidence", karma: -3, morale: 1 }
    ]
  },
  {
    id: "kids_camp",
    from: "Community team",
    emoji: "\u26BD",
    phase: "any",
    text: "Summer kids camp needs a surprise guest coach for a morning. No fee, just chaos and juice boxes.",
    choices: [
      { label: "Do the full morning", reply: "I'm in. Someone else does the juice run though", karma: 8, popularity: 3, morale: 3 },
      { label: "Send signed balls instead", reply: "Can't make it, sending a box of signed balls", karma: 3 }
    ]
  },
  {
    id: "tax_scheme",
    from: "Financial advisor",
    emoji: "\u{1F3DD}\uFE0F",
    phase: "pro",
    minAge: 21,
    text: "New structure for your image rights. Runs through three islands. Technically legal. Probably. Saves millions.",
    choices: [
      { label: "Keep it clean", reply: "Pay what I owe where I earn it. Not risking my name", karma: 8 },
      { label: "Do the scheme", reply: "If it's legal, file it", karma: -9, cash: 2 }
    ]
  },
  {
    id: "injury_teammate",
    from: "Teammate",
    emoji: "\u{1F3E5}",
    phase: "pro",
    text: "ACL gone. Nine months. Sitting in this hospital bed wondering if I'll ever be the same, honestly.",
    choices: [
      { label: "Visit weekly", reply: "I'm there every week bro. Rehab buddies. You're coming back stronger", karma: 10, morale: 2 },
      { label: "Send a message", reply: "Gutted for you. Speedy recovery brother", karma: 3 },
      { label: "Read it later", reply: "", karma: -6 }
    ]
  },
  {
    id: "boot_kid_swap",
    from: "Ballkid",
    emoji: "\u{1F45F}",
    phase: "pro",
    text: "You gave me your boots after the match!! My mum says I have to check you actually meant it??",
    choices: [
      { label: "Meant it, keep them", reply: "All yours. Score goals in them", karma: 7, popularity: 2 },
      { label: "Ask for them back", reply: "Actually those are my lucky pair... sorry kid", karma: -9, popularity: -3 }
    ]
  },
  {
    id: "podcast_invite",
    from: "Podcast",
    emoji: "\u{1F399}\uFE0F",
    phase: "pro",
    minAge: 20,
    text: "Come on the show. Fans love unfiltered. We WILL ask about your manager, your rival and your contract.",
    choices: [
      { label: "Go and stay classy", reply: "I'll come on. Keeping club stuff in house though", karma: 5, popularity: 3 },
      { label: "Go and spill everything", reply: "Unfiltered? You'll get unfiltered", karma: -6, popularity: 6 },
      { label: "Decline", reply: "Not my thing, good luck with the show", karma: 1 }
    ]
  },
  {
    id: "penalty_gift",
    from: "Rival striker",
    emoji: "\u{1F91D}",
    phase: "pro",
    minAge: 22,
    text: "You're one goal off the golden boot and we've got a dead rubber Sunday. Win a pen, I won't complain. Us strikers stick together.",
    choices: [
      { label: "Win it fair", reply: "If I get the boot I'm getting it properly. Respect though", karma: 7 },
      { label: "Take the free pen", reply: "Say less. Drinks on me if it lands", karma: -8 }
    ]
  },
  {
    id: "documentary",
    from: "Streaming service",
    emoji: "\u{1F3AC}",
    phase: "pro",
    minAge: 23,
    text: "All access documentary on your season. Big fee. Cameras everywhere including the bad days.",
    choices: [
      { label: "Do it honestly", reply: "Deal, but you show the real thing, not a highlight reel", karma: 5, popularity: 6, cash: 1 },
      { label: "Decline", reply: "Dressing room stays sacred. Pass", karma: 3 }
    ]
  },
  {
    id: "matchday_nerves",
    from: "Sports psych",
    emoji: "\u{1F9E0}",
    phase: "any",
    text: "Noticed you've been quiet before big games. My door is open Thursday if you want to talk it through.",
    choices: [
      { label: "Book the session", reply: "Thursday works. Cheers doc", karma: 5, morale: 5 },
      { label: "Tough it out", reply: "I'm fine. Just focused", karma: -2 }
    ]
  },
  {
    id: "old_boots_museum",
    from: "Club museum",
    emoji: "\u{1F3DB}\uFE0F",
    phase: "pro",
    minAge: 26,
    text: "We'd love your debut boots for the club museum display. Fans keep asking about you.",
    choices: [
      { label: "Donate with a note", reply: "They're yours. I'll write the story that goes with them", karma: 6, popularity: 3 },
      { label: "Keep them", reply: "Those stay with me forever, sorry", karma: 0 }
    ]
  }
];
function pickPhoneTexts(age, phase, usedIds, count) {
  const used = new Set(usedIds);
  const fits = PHONE_POOL.filter(
    (t) => !used.has(t.id) && (t.phase === "any" || t.phase === phase) && (t.minAge === void 0 || age >= t.minAge) && (t.maxAge === void 0 || age <= t.maxAge)
  );
  const out = [];
  const pool = [...fits];
  while (out.length < count && pool.length > 0) {
    const i = Math.floor(Math.random() * pool.length);
    out.push(pool[i]);
    pool.splice(i, 1);
  }
  return out;
}

// src/lib/soccerCareerContinental.ts
init_clubManagerUclGroups();
var ESPN_ELITE_SOURCE = { url: "https://www.espn.com/soccer/story/_/id/41270886/new-afc-champions-league-format-explained/" };
var ESPN_ELITE = 'ESPN, "The new AFC Champions League format explained", ' + ESPN_ELITE_SOURCE.url + ", 15 September 2024, read 2026-10-05: the AFC Champions League Elite from 2024-25, in place of the AFC Champions League, every tie from the quarter-finals one match";
function isStageRow(x) {
  if (!x || typeof x !== "object") return false;
  const r = x;
  return typeof r.club === "string" && ["w", "d", "l", "gf", "ga", "pts"].every((k) => Number.isFinite(r[k]));
}
function isFirstStageResult(x) {
  if (!x || typeof x !== "object") return false;
  const r = x;
  if (r.kind !== "groups" && r.kind !== "leaguePhase" || typeof r.through !== "boolean" || !Array.isArray(r.stages)) return false;
  return r.stages.every((st) => !!st && typeof st === "object" && typeof st.label === "string" && typeof st.footnote === "string" && Number.isFinite(st.position) && Number.isFinite(st.of) && isStageRow(st.myRow) && (st.table === void 0 || Array.isArray(st.table) && st.table.every(isStageRow)) && Array.isArray(st.games) && st.games.every((g) => !!g && typeof g === "object" && typeof g.opponent === "string" && Number.isFinite(g.matchday) && Number.isFinite(g.goalsFor) && Number.isFinite(g.goalsAgainst)));
}
var GRID_FROM = -1.5;
var GRID_STEP = 0.125;
var GRID_POINTS = 37;
var PASS_GRID = Array.from({ length: GRID_POINTS }, (_, i) => GRID_FROM + i * GRID_STEP);

// src/data/soccerCareerClubPool.ts
var CAREER_CLUB_POOL = [
  { id: "cm-bournemouth", name: "Bournemouth", country: "England", tier: 4, color: "#da291c", league: "Premier League" },
  { id: "cm-coventry-city", name: "Coventry City", country: "England", tier: 4, color: "#66b2e8", league: "Premier League" },
  { id: "cm-hull-city", name: "Hull City", country: "England", tier: 4, color: "#f5a12d", league: "Premier League" },
  { id: "cm-ipswich-town", name: "Ipswich Town", country: "England", tier: 4, color: "#2450a3", league: "Premier League" },
  { id: "cm-leeds-united", name: "Leeds United", country: "England", tier: 4, color: "#ffcd00", league: "Premier League" },
  { id: "cm-nottingham-forest", name: "Nottingham Forest", country: "England", tier: 2, color: "#dd0000", league: "Premier League" },
  { id: "cm-sunderland", name: "Sunderland", country: "England", tier: 4, color: "#eb172b", league: "Premier League" },
  { id: "cm-birmingham-city", name: "Birmingham City", country: "England", tier: 4, color: "#2966b0", league: "Championship" },
  { id: "cm-blackburn-rovers", name: "Blackburn Rovers", country: "England", tier: 4, color: "#009ee0", league: "Championship" },
  { id: "cm-bolton-wanderers", name: "Bolton Wanderers", country: "England", tier: 4, color: "#263c7e", league: "Championship" },
  { id: "cm-bristol-city", name: "Bristol City", country: "England", tier: 4, color: "#e21a23", league: "Championship" },
  { id: "cm-burnley", name: "Burnley", country: "England", tier: 4, color: "#8b2a4a", league: "Championship" },
  { id: "cm-cardiff-city", name: "Cardiff City", country: "Wales", tier: 4, color: "#0070b5", league: "Championship" },
  { id: "cm-charlton-athletic", name: "Charlton Athletic", country: "England", tier: 4, color: "#d4021d", league: "Championship" },
  { id: "cm-derby-county", name: "Derby County", country: "England", tier: 4, color: "#d8d8d8", league: "Championship" },
  { id: "cm-lincoln-city", name: "Lincoln City", country: "England", tier: 4, color: "#e30613", league: "Championship" },
  { id: "cm-middlesbrough", name: "Middlesbrough", country: "England", tier: 4, color: "#e21a23", league: "Championship" },
  { id: "cm-millwall", name: "Millwall", country: "England", tier: 4, color: "#25457a", league: "Championship" },
  { id: "cm-portsmouth", name: "Portsmouth", country: "England", tier: 4, color: "#2450a3", league: "Championship" },
  { id: "cm-preston-north-end", name: "Preston North End", country: "England", tier: 4, color: "#b9c4d1", league: "Championship" },
  { id: "cm-qpr", name: "QPR", country: "England", tier: 4, color: "#1d5ba4", league: "Championship" },
  { id: "cm-sheffield-united", name: "Sheffield United", country: "England", tier: 4, color: "#ee2737", league: "Championship" },
  { id: "cm-southampton", name: "Southampton", country: "England", tier: 4, color: "#d71920", league: "Championship" },
  { id: "cm-stoke-city", name: "Stoke City", country: "England", tier: 4, color: "#e03a3e", league: "Championship" },
  { id: "cm-swansea-city", name: "Swansea City", country: "Wales", tier: 4, color: "#c8c8c8", league: "Championship" },
  { id: "cm-watford", name: "Watford", country: "England", tier: 4, color: "#fbee23", league: "Championship" },
  { id: "cm-west-brom", name: "West Brom", country: "England", tier: 4, color: "#3a5da8", league: "Championship" },
  { id: "cm-wrexham", name: "Wrexham", country: "Wales", tier: 4, color: "#ce1126", league: "Championship" },
  { id: "cm-alaves", name: "Alaves", country: "Spain", tier: 4, color: "#0761af", league: "La Liga" },
  { id: "cm-deportivo", name: "Deportivo", country: "Spain", tier: 4, color: "#0068b3", league: "La Liga" },
  { id: "cm-elche", name: "Elche", country: "Spain", tier: 4, color: "#1a9349", league: "La Liga" },
  { id: "cm-espanyol", name: "Espanyol", country: "Spain", tier: 4, color: "#007fc8", league: "La Liga" },
  { id: "cm-getafe", name: "Getafe", country: "Spain", tier: 4, color: "#1265b3", league: "La Liga" },
  { id: "cm-levante", name: "Levante", country: "Spain", tier: 4, color: "#9c2743", league: "La Liga" },
  { id: "cm-malaga", name: "Malaga", country: "Spain", tier: 4, color: "#29a5dd", league: "La Liga" },
  { id: "cm-osasuna", name: "Osasuna", country: "Spain", tier: 4, color: "#d91a21", league: "La Liga" },
  { id: "cm-racing-santander", name: "Racing Santander", country: "Spain", tier: 4, color: "#009e49", league: "La Liga" },
  { id: "cm-rayo-vallecano", name: "Rayo Vallecano", country: "Spain", tier: 4, color: "#e53027", league: "La Liga" },
  { id: "cm-valencia", name: "Valencia", country: "Spain", tier: 4, color: "#ee7f24", league: "La Liga" },
  { id: "cm-athletico-paranaense", name: "Athletico Paranaense", country: "Brazil", tier: 4, color: "#c8102e", league: "Brasileirao" },
  { id: "cm-fluminense", name: "Fluminense", country: "Brazil", tier: 4, color: "#7a1e3a", league: "Brasileirao" },
  { id: "cm-bahia", name: "Bahia", country: "Brazil", tier: 4, color: "#0057b8", league: "Brasileirao" },
  { id: "cm-atletico-mineiro", name: "Atletico Mineiro", country: "Brazil", tier: 4, color: "#2b2b2b", league: "Brasileirao" },
  { id: "cm-coritiba", name: "Coritiba", country: "Brazil", tier: 4, color: "#0a7040", league: "Brasileirao" },
  { id: "cm-red-bull-bragantino", name: "Red Bull Bragantino", country: "Brazil", tier: 4, color: "#d9d9d9", league: "Brasileirao" },
  { id: "cm-vitoria", name: "Vitoria", country: "Brazil", tier: 4, color: "#d02128", league: "Brasileirao" },
  { id: "cm-mirassol", name: "Mirassol", country: "Brazil", tier: 4, color: "#f5d800", league: "Brasileirao" },
  { id: "cm-vasco-da-gama", name: "Vasco da Gama", country: "Brazil", tier: 4, color: "#2b2b2b", league: "Brasileirao" },
  { id: "cm-internacional", name: "Internacional", country: "Brazil", tier: 4, color: "#d02128", league: "Brasileirao" },
  { id: "cm-remo", name: "Remo", country: "Brazil", tier: 4, color: "#12294a", league: "Brasileirao" },
  { id: "cm-chapecoense", name: "Chapecoense", country: "Brazil", tier: 4, color: "#0a7040", league: "Brasileirao" }
];

// src/lib/soccerCareerLeague.ts
init_clubRivalries();

// src/lib/soccerCareerDerby.ts
init_clubRivalries();
var DERBY_WIN_POP = 2;
var DERBY_WIN_MORALE = 2;
var DERBY_LOSS_POP = -2;
var DERBY_HERO_POP = 2;
var DERBY_HELP_RULES = [
  "Derbies: if your club has a real rival in the same league, you meet them twice a season in the league. We only count a rivalry two separate sources back, in leagues and years where we checked how often the clubs meet, so some clubs have none yet.",
  `You play the derbies you are picked for, roughly in line with your league appearances. Each one you win adds ${DERBY_WIN_POP} popularity and ${DERBY_WIN_MORALE} morale, each one you lose takes ${-DERBY_LOSS_POP} off both, a draw changes nothing, the swing is capped every season and your rating is never touched.`,
  `Score the goal that puts you ahead for good in a derby win and the season counts as a Derby Hero season, worth ${DERBY_HERO_POP} more popularity. Example: at Arsenal you beat Tottenham 2-1 at home with the winner and draw 1-1 away, so that is +${DERBY_WIN_POP + DERBY_HERO_POP} popularity, +${DERBY_WIN_MORALE} morale and a Derby Hero.`
];

// src/lib/soccerCareerCup.ts
var ORDER = ["early", "QF", "SF", "F"];
var goalsOk = (n) => typeof n === "number" && Number.isInteger(n) && n >= 0 && n <= 30;
var nameOk = (s) => typeof s === "string" && s.length > 0 && s.length <= 60;
function readCupRun(row) {
  if (!row || typeof row !== "object") return null;
  const r = row;
  const raw = r.cupRun;
  if (!raw || typeof raw !== "object" || !Array.isArray(raw.stages)) return null;
  const list2 = raw.stages;
  if (list2.length < 1 || list2.length > ORDER.length) return null;
  const stages = [];
  let last = -1;
  for (let i = 0; i < list2.length; i++) {
    const t = list2[i];
    if (!t || typeof t !== "object" || typeof t.won !== "boolean") return null;
    const at = ORDER.indexOf(t.stage);
    if (at <= last || i === 0 !== (at === 0)) return null;
    last = at;
    if (!t.won && i !== list2.length - 1) return null;
    const tie = { stage: t.stage, won: t.won };
    if (at > 0) {
      if (!nameOk(t.opp)) return null;
      tie.opp = t.opp;
    }
    if (t.stage === "QF" || t.stage === "SF") {
      if (!goalsOk(t.for) || !goalsOk(t.against) || t.for === t.against || t.for > t.against !== t.won) return null;
      Object.assign(tie, { for: t.for, against: t.against });
      if (t.stage === "QF") {
        if (typeof t.home !== "boolean") return null;
        tie.home = t.home;
      }
    }
    stages.push(tie);
  }
  const end = stages[stages.length - 1];
  const won = end.stage === "F" && end.won;
  if (won !== (r.domesticCup === true)) return null;
  const run = { stages };
  if (raw.cup !== void 0) {
    if (!nameOk(raw.cup)) return null;
    run.cup = raw.cup;
  }
  if (raw.final !== void 0) {
    const f = raw.final;
    if (!f || typeof f !== "object" || end.stage !== "F" || !goalsOk(f.for) || !goalsOk(f.against) || f.legs !== 1 && f.legs !== 2) return null;
    const final = { for: f.for, against: f.against, legs: f.legs };
    if (f.decidedBy !== void 0 || f.pensFor !== void 0 || f.pensAgainst !== void 0) {
      const { pensFor: pf, pensAgainst: pa } = f;
      if (f.decidedBy !== "penalties" || f.for !== f.against || !goalsOk(pf) || !goalsOk(pa) || pf === pa || pf > pa !== won) return null;
      Object.assign(final, { decidedBy: "penalties", pensFor: pf, pensAgainst: pa });
    } else if (f.for === f.against || f.for > f.against !== won) return null;
    if (f.scored === true) {
      if (f.for < 1) return null;
      final.scored = true;
    }
    run.final = final;
  }
  return run;
}

// src/lib/soccerPhone.ts
var MAX_LINES = 6;
var MAX_THREADS = 8;
var MAX_SEEN = 8;
function nextSeed(s) {
  return s * 1664525 + 1013904223 >>> 0;
}
var Rng = class {
  constructor(s) {
    this.s = s;
    this.s = s >>> 0 || 1;
  }
  next() {
    this.s = nextSeed(this.s);
    return this.s / 4294967296;
  }
  get state() {
    return this.s;
  }
  int(lo, hi) {
    return lo + Math.floor(this.next() * (hi - lo + 1));
  }
  pick(arr) {
    return arr[Math.floor(this.next() * arr.length)];
  }
};
var clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
var CONTACTS = [
  { id: "mum", name: "Mum", emoji: "\u2764\uFE0F", blurb: "Answers on the first ring" },
  { id: "dad", name: "Dad", emoji: "\u{1F9D4}", blurb: "Watched every minute you ever played" },
  { id: "grandad", name: "Grandad", emoji: "\u{1F9D3}", blurb: "Shouts at the telly on your behalf" },
  { id: "partner", name: "Your partner", emoji: "\u{1F49E}", blurb: "The one who sees the bad days" },
  { id: "bestmate", name: "Best mate", emoji: "\u{1F919}", blurb: "Knew you before any of this" },
  { id: "agent", name: "Your agent", emoji: "\u{1F4BC}", blurb: "Always half a deal ahead of you" },
  { id: "gaffer", name: "The gaffer", emoji: "\u{1F4CB}", blurb: "Picks the team, picks his words" },
  { id: "captain", name: "Club captain", emoji: "\u{1F981}", blurb: "Runs the dressing room" },
  { id: "roomie", name: "Away room mate", emoji: "\u{1F634}", blurb: "Snores, shares everything else" },
  { id: "physio", name: "Club physio", emoji: "\u{1FA79}", blurb: "Knows your body better than you" },
  { id: "fitness", name: "Fitness coach", emoji: "\u{1F3CB}\uFE0F", blurb: "Owns the sadistic clipboard" },
  { id: "youthcoach", name: "Old youth coach", emoji: "\u{1F474}", blurb: "Still calls you kid" },
  { id: "academy", name: "Academy kid", emoji: "\u{1F331}", blurb: "Looks at you the way you looked at someone" },
  { id: "kitman", name: "Kit man", emoji: "\u{1F9FA}", blurb: "Has seen forty years of you lot" },
  { id: "journo", name: "Journalist", emoji: "\u{1F4F0}", blurb: "Friendly until he is not" },
  { id: "natcoach", name: "Country manager", emoji: "\u{1F30D}", blurb: "Names the squad in March" },
  { id: "rival", name: "Rival", emoji: "\u{1FA9E}", blurb: "The name next to yours, forever" }
];
var CONTACT_BY_ID = Object.fromEntries(CONTACTS.map((c) => [c.id, c]));
function contactName(id, s) {
  if (id === "rival" && s.rival?.name) return s.rival.name;
  if (id === "natcoach") return `${s.nationality} manager`;
  return CONTACT_BY_ID[id]?.name ?? id;
}
function contactEmoji(id) {
  return CONTACT_BY_ID[id]?.emoji ?? "\u{1F4AC}";
}
function contactAvailable(id, s, phase) {
  switch (id) {
    case "partner":
      return !!s.hasRelationship || !!s.family?.isMarried;
    case "rival":
      return !!s.rival && !s.rival.retired;
    case "natcoach":
      return !!s.internationalCareer;
    case "gaffer":
    case "captain":
    case "roomie":
    case "physio":
    case "kitman":
      return phase === "pro";
    case "journo":
      return phase === "pro" && s.age >= 19;
    case "academy":
      return phase === "youth" || s.age >= 21;
    default:
      return true;
  }
}
var R = (label, say, back, warm = 6, extra = {}) => ({ label, say, back, warm, ...extra });
var B = (text2, ...replies) => ({ text: text2, replies });
var C = (id, contact, phase, beats, opts = {}) => ({ id, contact, phase, beats, starter: true, ...opts });
var CONVOS = [
  /* ── Mum ── */
  C("mum_checkin", "mum", "any", [
    B(
      "Just checking you are eating something other than chicken and rice. Are you?",
      R("Send her a photo of dinner", "Sending you a photo. There are vegetables on it. Two kinds", "TWO kinds. My son. Look at you", 8, { morale: 3 }),
      R("Be honest", "Chicken and rice. Every day. I have made peace with it", "You are a professional athlete not a prisoner. I am posting you a lasagne", 6, { morale: 2 }),
      R("Turn it round on her", "Are YOU eating properly is the question", "Do not do that. Answer the question", 4)
    ),
    B(
      "Right. Next thing. Are you sleeping? And do not say fine.",
      R("Tell her the truth", "Not brilliant. Head is loud after games", "Then ring me after games instead of lying in the dark. Any time. I mean it", 9, { morale: 5, perk: "calm" }),
      R("Say you are fine", "I am fine mum", "You said fine. I said do not say fine", 3),
      R("Make her laugh", "I sleep like a baby. Wake up every two hours crying", "Cheeky. Go to bed", 6, { morale: 2 })
    ),
    B(
      "One more thing and I will leave you alone. Sunday dinner. Yes or no.",
      R("Yes", "Yes. What time", "One o clock and do not be late like your father", 9, { morale: 5 }),
      R("Bring the whole squad", "Can I bring two of the lads? They live on their own", "Two? I will do a leg of lamb. Tell them to bring nothing", 10, { morale: 6, perk: "lift" }),
      R("Cannot", "Away game Sunday mum", "Then the Sunday after. I am writing it down", 4)
    )
  ]),
  C("mum_proud", "mum", "any", [
    B(
      "Your nan told the whole street about you again. She has a photo in her purse and everything.",
      R("Send something for nan", "Tell her I am sending a signed shirt for the purse photo wall", "She is going to cry. Then she is going to tell the street again", 9, { karma: 4, morale: 3 }),
      R("Be embarrassed", "Mum that is so embarrassing please stop her", "Absolutely not. Let the woman have this", 5),
      R("Leave it", "Ok", "Ok? That is all I get? Ok?", -2, { warm: -2 })
    ),
    B(
      "She asked if you are happy. Not doing well. Happy. I said I would ask properly.",
      R("Say yes and mean it", "Honestly? Yeah. Tired, but yeah", "Good. That is the only bit I actually worry about", 8, { morale: 4 }),
      R("Admit it is heavy", "Some weeks it is a lot mum", "Then come home for a weekend. The kettle works and nobody wants anything from you here", 9, { morale: 6, perk: "calm" }),
      R("Dodge it", "Ask me after Saturday", "That is not an answer and you know it", 2)
    ),
    B(
      "She wants to know if you will come to the street party when you next win something.",
      R("Say yes", "If we win anything I am coming home with it. Tell her to get the bunting", "The bunting has been in the loft for two years waiting", 10, { karma: 4, morale: 4 }),
      R("Say it is too much", "I would get mobbed mum", "You would get fed. Different thing", 5)
    )
  ]),
  C("mum_worry", "mum", "any", [
    B(
      "I saw what they were saying about you online. I know you say do not read it. I read it.",
      R("Tell her to stop reading", "Mum. Log off. Please. It is noise", "It is my son they are talking about. But fine. Logging off", 7, { morale: 2 }),
      R("Let her be angry", "Go on then. Say what you want to say", "I want to say they have never kicked a ball in their lives. There. Done", 8, { morale: 4 }),
      R("Laugh it off", "Half of them are twelve mum", "The other half are grown men which is worse", 6, { morale: 2 })
    ),
    B(
      "Promise me you are talking to someone about it. Not just me at midnight.",
      R("Promise properly", "I will talk to the club doc this week. Promise", "Good boy. Now go and win something", 9, { morale: 5, karma: 3, perk: "calm" }),
      R("Say you have got it", "I have got it. Really", "Hm. I am checking back in a month", 4)
    ),
    B(
      "And do me a favour. Do not read the comments before a game. Read them never actually.",
      R("Agree to delete the apps", "Deleting the apps til the end of the season", "That is my boy. Watch how much lighter you feel", 10, { morale: 6, perk: "calm" }),
      R("Half agree", "I will stop before games at least", "Half a promise. I will take it", 6, { morale: 2 })
    )
  ]),
  /* ── Dad ── */
  C("dad_analysis", "dad", "any", [
    B(
      "Watched it back three times. You were dropping too deep in the second half son. Coming to get the ball because you wanted a touch.",
      R("Take it on the chin", "You are right. I got frustrated and went looking for it", "That is all I wanted to hear. Stay high, they have to deal with you", 8, { perk: "sharp" }),
      R("Argue back", "There was nobody else showing for it. What was I meant to do", "Then let them lose it. Not your job to fix their bottle", 5),
      R("Tell him to relax", "Dad it is one game", "Three times I watched it. THREE", 3)
    ),
    B(
      "Anyway. Your mother says I am not allowed to send you notes at midnight anymore.",
      R("Tell him to keep sending", "Keep sending them. Nobody else tells me the truth", "Right. Notes continue. Do not tell her", 9, { morale: 4 }),
      R("Agree with mum", "She might have a point", "Traitor", 4)
    ),
    B(
      "Right. Last one. What are you actually working on this week. In training. Specifically.",
      R("Give him a real answer", "First touch away from pressure. Doing 200 a day on my own", "THAT is an answer. Two hundred a day. Good lad", 9, { perk: "sharp" }),
      R("Say you do not know", "Whatever the coaches put on honestly", "Then pick something yourself. Nobody built a career doing the group session", 7, { perk: "sharp" }),
      R("Tell him to leave it", "Dad. Enough for tonight", "Alright alright. Night son", 3)
    )
  ]),
  C("dad_firstboots", "dad", "any", [
    B(
      "Found your first pair of boots in the loft. Size 3. Held together with tape and hope.",
      R("Ask him to keep them", "Do not throw those out. Ever", "They are going in a box with your name on it. Already done", 9, { morale: 5 }),
      R("Ask for a photo", "Send me a photo of them", "Sent. Look at the state of the left one", 7, { morale: 3 }),
      R("Bin them", "Chuck them, I have got hundreds of pairs now", "You have got hundreds of pairs because of that pair", -1, { warm: -4 })
    ),
    B(
      "Your mother wants to know if you remember who paid for them.",
      R("Say thank you properly", "I know exactly who paid for them. And the petrol to every away game. Thank you", "Stop it. You will set me off", 10, { morale: 6, karma: 4 }),
      R("Joke about it", "The council?", "The COUNCIL. Right", 5)
    ),
    B(
      "She says put them in the cabinet with your medals. I said you have not got a cabinet.",
      R("Promise the cabinet", "Tell her I am building one. Boots go on the top shelf", "Top shelf. Above the medals. She will love that", 10, { morale: 5 }),
      R("Admit you have no medals yet", "I have not won anything yet dad", "Yet. That word is doing a lot of work and I like it", 8, { morale: 4, perk: "sharp" })
    )
  ]),
  C("dad_pressure", "dad", "pro", [
    B(
      "Lads at work keep asking me when you are going to a bigger club. I keep telling them to ask you.",
      R("Give him something to say", "Tell them my dad has no idea and neither do I. Which is true", "Perfect. That will shut them up for a week", 7),
      R("Be honest about it", "Honestly? I think about it every day dad", "Then think about it properly and stop letting other people think it for you", 8, { perk: "sharp" }),
      R("Get annoyed", "Tell them to mind their business", "They are just proud of you in a stupid way. That is all it is", 3)
    )
  ], { minAge: 20 }),
  /* ── Grandad ── */
  C("grandad_ticket", "grandad", "any", [
    B(
      "Still got my seat. Row H. Been in that row since 1974 and I am not moving for anybody.",
      R("Offer him the good seats", "I can get you in the family box. Heated. Cup of tea and everything", "Heated? Row H it is then. But tell your mother I considered it", 8, { morale: 4 }),
      R("Respect the row", "Row H forever. I would not dare move you", "Good lad. You understand", 9, { morale: 3 })
    ),
    B(
      "Here. When you score, do the thing. You know the thing.",
      R("Promise the celebration", "Next one is for you. Point at Row H", "I will have my hat off and everything", 10, { morale: 6, karma: 3 }),
      R("Play it down", "I do not really do celebrations grandad", "You will do this one", 5)
    ),
    B(
      "And bring your nan a scarf from the away end. She collects them. Do not ask me why.",
      R("Get her the scarf", "Away scarf, next trip. Consider it done", "She has 31 of them. You are keeping a woman happy here", 9, { morale: 4 }),
      R("Get her the whole lot", "I will get her one from every away ground this season", "Now you have started something. She will count them", 10, { morale: 6, karma: 3 })
    )
  ]),
  C("grandad_oldtimes", "grandad", "any", [
    B(
      "In my day the ball was heavier and the pitch was mud from November. You lot play on a carpet.",
      R("Wind him up", "And you walked to the ground uphill both ways", "Do not be clever. I have got photographs", 7, { morale: 3 }),
      R("Ask him about it", "What was the best player you ever saw live?", "Now that is a proper question. Get the kettle on, this takes a while", 9, { morale: 4 })
    )
  ]),
  /* ── Partner ── */
  C("partner_time", "partner", "any", [
    B(
      "You have been home four nights this month. I counted. I was not going to say anything but I counted.",
      R("Own it", "That is on me. Not the schedule, me. I will fix it", "Thank you for not arguing with the number", 9, { morale: 5, karma: 4 }),
      R("Explain the schedule", "Away trip, then internationals, then away again. It is the calendar not me", "I know what the calendar is. I asked about you", 3),
      R("Get defensive", "This is the job. You knew that", "I did. Does not make the house any less quiet", -3, { warm: -6, morale: -3 })
    ),
    B(
      "So what does fixing it actually look like. Be specific.",
      R("Make a real plan", "Two nights a week, phone in a drawer, no exceptions. Starting Tuesday", "Tuesday. I am holding you to it and I am putting it in the calendar", 10, { morale: 8, perk: "calm" }),
      R("Promise vaguely", "I will be around more, I promise", "That is not specific. But ok", 3)
    ),
    B(
      "Ok. And when you are home, actually be home. Not on the phone reading about yourself.",
      R("Agree", "Phone in the drawer. I mean it", "Then I will stop pretending I do not check it either", 10, { morale: 6, perk: "calm" }),
      R("Push back gently", "Some of that is work though", "Some of it. Not all of it. You know the difference", 5)
    )
  ], { needs: (s) => !!s.hasRelationship || !!s.family?.isMarried }),
  C("partner_afterloss", "partner", "pro", [
    B(
      "I watched it. Do you want me to say something nice or do you want me to leave it alone.",
      R("Ask to be left alone", "Leave it alone tonight. Tomorrow I will talk", "Ok. Food is in the oven. Not talking about it", 8, { morale: 4 }),
      R("Ask for something nice", "Say something nice. I am on the floor here", "You were the only one who kept running. I watched you the whole way", 9, { morale: 7 }),
      R("Snap at her", "Do not watch them if you are going to analyse them", "Right. Noted", -4, { warm: -8, morale: -4 })
    ),
    B(
      "For what it is worth, the version of you that comes home is the one I actually like.",
      R("Say it back", "That version only exists because of you. I know that", "Now you are just being nice because I made food", 10, { morale: 8 }),
      R("Deflect", "Give it a week and you will change your mind", "Stop it", 4)
    ),
    B(
      "Do you want me at the next one or would you rather I was not in the stand?",
      R("Want them there", "I look for you every time. Be there", "Then I am there. Front row, terrible singing", 10, { morale: 7 }),
      R("Ask them to skip it", "Skip this one. It is going to be horrible", "Ok. But I am watching it at home and shouting anyway", 6, { morale: 2 })
    )
  ], { needs: (s) => !!s.hasRelationship || !!s.family?.isMarried }),
  C("partner_move", "partner", "pro", [
    B(
      "If you moved clubs, would you actually ask me first. Genuine question.",
      R("Say yes and mean it", "You would be the first call. Before my agent. Before anyone", "Good. Because I would go anywhere with you, I just want to be asked", 10, { morale: 6, karma: 4 }),
      R("Be honest about the business", "Honestly these things move fast and sometimes there is no time", "Then make time. It is my life too", 4),
      R("Joke", "Depends where", "Wrong answer. Try again", 2)
    ),
    B(
      "Where would you actually go, if it was only up to you.",
      R("Somewhere you would win", "Somewhere I would win everything. That is the whole point", "Then go and win it. I will find a coffee shop I like", 9, { morale: 5, perk: "offer" }),
      R("Somewhere you would play", "Somewhere I would play every week. Sick of watching", "That is the most honest thing you have said all month", 9, { morale: 5, perk: "offer" }),
      R("Nowhere", "Nowhere. I like it here", "Then stay and stop scrolling transfer rumours at 1am", 7, { morale: 3 })
    )
  ], { minAge: 20, needs: (s) => !!s.hasRelationship || !!s.family?.isMarried }),
  /* ── Best mate from home ── */
  C("mate_fivea", "bestmate", "any", [
    B(
      "Five a side Thursday. Same cage. Lads still think they can mark you. Are you coming or are you too famous",
      R("Turn up", "I am coming and I am not going easy on anyone", "The cage is going to be RAMMED. Word will get out in an hour", 8, { morale: 5, popularity: 2 }),
      R("Send money for the pitch", "Cannot make it but I have paid for the pitch for the rest of the year", "Absolute scenes. You are a legend", 6, { karma: 4, cash: -0.01 }),
      R("Leave him hanging", "", "Right. Say no more", -4, { warm: -8, karma: -4 })
    ),
    B(
      "Serious question though. Are you alright? You have gone quiet with everyone.",
      R("Open up", "Bit lost if I am honest mate", "Then get in the cage Thursday. Nobody in there cares what you earn", 10, { morale: 7, perk: "calm" }),
      R("Keep it light", "I am fine. Busy", "Busy. Right. Thursday. I am not asking", 5)
    ),
    B(
      "Also everyone keeps asking me if you have changed. I keep saying no. Have you?",
      R("Ask him honestly", "You tell me. You would know before I would", "Bit. Not in a bad way. You are just tired all the time", 9, { morale: 4 }),
      R("Say no", "Not a chance. Same idiot", "Correct answer and mostly true", 8, { morale: 3 }),
      R("Get defensive", "Why, what have they been saying", "Nothing. Forget I said it", 2)
    )
  ]),
  C("mate_wedding", "bestmate", "pro", [
    B(
      "Getting married in June. You are best man. Not a question, an announcement.",
      R("Say yes immediately", "Obviously. Try and stop me", "Speech better be good. No football stories. Ok one football story", 10, { morale: 7, karma: 4 }),
      R("Check the fixtures", "Let me check the fixture list first mate", "Mate. June. YOU are the fixture list", 3),
      R("Say no", "I cannot commit to anything that far out", "Wow. Ok", -5, { warm: -10, karma: -6 })
    ),
    B(
      "One more thing. Do not turn up with security. It is a village hall.",
      R("Agree", "Just me and a suit. Promise", "Perfect. Uncle Ray will still ask you for a trial", 9, { morale: 4 }),
      R("Insist", "I have to bring one guy, that is the club rule", "Fine. Put him on the buffet, he will love it", 6)
    ),
    B(
      "Last thing. The speech. Are you actually going to do it or are you going to wing it.",
      R("Write it properly", "I have already started writing it. Two pages", "TWO PAGES. Mate. I am going to cry in front of my in laws", 10, { morale: 6, karma: 3 }),
      R("Wing it", "I will wing it. It will be fine", "Famous last words from a man who cannot do a post match interview", 5)
    )
  ], { minAge: 22 }),
  /* ── Agent ── */
  C("agent_interest", "agent", "pro", [
    B(
      "Two clubs have called this week. One is serious, one is fishing. Do you want the names or do you want me to handle it",
      R("Ask for the names", "Names. Now. I want to know who actually rates me", "Sending them. Do not screenshot this to anyone", 8, { perk: "offer" }),
      R("Let him handle it", "Handle it. Bring me something real or nothing at all", "That is how I like to work. Leave it with me", 7, { perk: "offer" }),
      R("Shut it down", "Not interested. I am happy here", "Noted. I will tell them the door is shut. For now", 5, { morale: 3 })
    ),
    B(
      "Before I go back to them. What actually matters to you. Money, minutes, or medals.",
      R("Minutes", "Minutes. I cannot develop watching", "Good. That narrows it and it is the right answer at your age", 9, { perk: "sharp" }),
      R("Medals", "Medals. I want to win things while I still can", "Then we are aiming higher and I am asking for less. Understood", 9, { perk: "offer" }),
      R("Money", "Money. I am not going to pretend otherwise", "Refreshing. I can absolutely work with that", 6, { karma: -3, cash: 0.4 })
    ),
    B(
      "Right. I am going to go and be annoying at somebody on your behalf. Anything you do NOT want?",
      R("No sideways moves", "Nothing sideways. If it is not a step up I am not moving", "Understood. That rules out two of them already", 9, { perk: "offer" }),
      R("Nowhere I would not play", "Nowhere that signs me to sit me on a bench", "Right. I will ask about minutes before I ask about money", 9, { perk: "offer" }),
      R("Leave it with him", "Surprise me", "Dangerous words to say to an agent", 5)
    )
  ], { minAge: 18 }),
  C("agent_contract", "agent", "pro", [
    B(
      "Your club want to open contract talks early. That is a good sign and also a trap. They want to lock you in cheap.",
      R("Play it patient", "Let them wait. I will let the season do the talking", "That is the play. Every goal from here is a pay rise", 8, { perk: "offer" }),
      R("Sign now for security", "I would rather have it done. Get me a fair deal now", "Safe. Boring. Honestly, not wrong either", 7, { morale: 4 }),
      R("Demand the world", "Tell them the number and watch their faces", "I will enjoy that meeting. It may not end well", 4, { karma: -3 })
    ),
    B(
      "One more thing and then I will leave you alone. Are you happy at this club, actually.",
      R("Yes", "Yeah. I would stay", "Then I negotiate like a man who does not want to leave. Costs us a bit. Worth it", 8, { morale: 5 }),
      R("No", "No. I have outgrown it", "Right. Then we are having a very different conversation in January", 7, { perk: "offer" })
    ),
    B(
      "One last thing, and I ask everybody this. What do you want people to say about you at 35.",
      R("That he was hard to play against", "That I was a nightmare to play against for fifteen years", "Then we build the career around that sentence. Good", 9, { perk: "sharp" }),
      R("That he won things", "That I won. Everything else is noise", "Then we go where the trophies are, even if the money is worse", 9, { perk: "offer" }),
      R("Never thought about it", "Genuinely no idea", "Think about it. It is the only question that decides the rest", 5)
    )
  ], { minAge: 19 }),
  C("agent_brand", "agent", "pro", [
    B(
      "Boot brand wants you. Small money now, big money if you kick on. Or we wait for a bigger name to notice.",
      R("Take the small deal", "Take it. Money now, and I want to be loyal to whoever backs me early", "Loyalty plays well and pays later. Signing it", 7, { cash: 0.3, popularity: 2 }),
      R("Wait it out", "Wait. I back myself", "So do I. Risky. I like it", 7, { perk: "spotlight" }),
      R("Ask what he would do", "What would you do if it was your career", "I would wait. But I would also stop pretending my agent knows your body better than you", 8, { morale: 3 })
    )
  ], { minAge: 19 }),
  /* ── The gaffer ── */
  C("gaffer_role", "gaffer", "pro", [
    B(
      "Come see me at the training ground tomorrow. Nothing bad. I want to tell you what I actually want from you.",
      R("Ask for more", "Before I come in. I want more minutes and I will earn them", "Good. I like being asked. Bring that attitude tomorrow", 8, { perk: "sharp" }),
      R("Just listen", "I will be there. I will listen", "That is the right answer more often than players think", 7, { perk: "sharp" }),
      R("Be wary", "Should I be worried", "If you were, I would not have texted. I would have let you find out", 5)
    ),
    B(
      "One thing I want you to think about tonight. When we lose the ball, what do you do first.",
      R("Win it back", "Win it back. Within five seconds. That is the answer you want", "It is the answer I want AND the right one. See you at nine", 9, { perk: "sharp" }),
      R("Get in shape", "Get back in shape and hold the line", "Boring. Correct. Also see you at nine", 8),
      R("Admit you switch off", "Honestly? Sometimes I stand there annoyed", "At least you know. We can fix knowing. We cannot fix pretending", 8, { morale: 3, perk: "sharp" })
    ),
    B(
      "Good. Bring one question with you tomorrow. Any question. I will answer it straight.",
      R("Ask about your role", "Am I in your best eleven or am I in the squad", "In it. Not nailed on. That is the honest answer and you can change it by Friday", 9, { morale: 4, perk: "sharp" }),
      R("Ask about the team", "What is the one thing holding this team back", "Nobody talks. Including you. Fix that and we go up the table", 9, { perk: "lift" }),
      R("No question", "I will just listen", "Then listen properly. Nine o clock", 5)
    )
  ]),
  C("gaffer_dropped", "gaffer", "pro", [
    B(
      "You are on the bench Saturday. I would rather you heard it from me tonight than from a team sheet.",
      R("Ask what to fix", "Tell me exactly what gets me back in", "Two things. Sprint back after you lose it, and stop taking the safe pass. Do that and you start next week", 9, { perk: "sharp", morale: 2 }),
      R("Take it quietly", "Understood. I will be ready if you need me", "That is the response of somebody who plays a lot of games for me", 8, { morale: 3 }),
      R("Kick off", "This is a joke and you know it", "It is my team. Cool down and come see me Monday", -3, { warm: -8, morale: -5 })
    ),
    B(
      "For what it is worth I was dropped at your age and I sulked for a month. Waste of a month.",
      R("Take the lesson", "Then I will skip the month", "Ha. Good. Nine o clock, extra finishing", 9, { perk: "sharp" }),
      R("Stay annoyed", "I am still not happy about it", "I would be worried if you were", 6)
    ),
    B(
      "Be honest with me. Do you still trust that I will play you when you deserve it?",
      R("Yes", "Yeah. You have never lied to me about it", "Then we are fine. Everything else is just Saturdays", 9, { morale: 5, perk: "lift" }),
      R("Not really", "Honestly, not at the minute", "Fair. I will earn it back the same way you will. See you at nine", 8, { morale: 3 })
    )
  ]),
  /* ── Captain ── */
  C("captain_standards", "captain", "pro", [
    B(
      "Quick word. Nothing heavy. Couple of the young lads are drifting and they watch you more than they watch me.",
      R("Set the tone", "I will be first in all week. Let them see it rather than hear it", "That is exactly why I asked you and not somebody louder", 9, { perk: "lift" }),
      R("Talk to them", "I will pull them both aside quietly", "Quietly is right. Nobody learns anything from being embarrassed", 8, { karma: 4 }),
      R("Not your job", "Not really my problem mate", "Fair enough. It becomes your problem in about three years", -2, { warm: -5 })
    ),
    B(
      "Team meal Thursday. Everyone. Phones in a box at the door.",
      R("In", "In. And I am paying", "Right lads, he is paying. This is now a big night", 9, { morale: 5, cash: -0.02, perk: "lift" }),
      R("In, but not paying", "I will be there. Not paying, I paid last time", "Correct and I respect the memory", 7, { morale: 3 }),
      R("Skip it", "Cannot do Thursday", "Every time mate", -3, { warm: -7 })
    ),
    B(
      "Good. One more. If I go down injured for a long one, who speaks up in there?",
      R("Say you will", "Me. I will do it", "That is the answer I was fishing for and you did not even flinch", 10, { morale: 6, perk: "lift" }),
      R("Name somebody else", "The keeper. Everyone listens to him", "He would hate it. He would also be brilliant at it", 7)
    )
  ]),
  C("captain_armband", "captain", "pro", [
    B(
      "I am moving on in the summer. Between us, I have told the gaffer you should have the armband.",
      R("Say you are ready", "I am ready. I have been ready", "That is what I told him. Do not make me look daft", 9, { morale: 7, perk: "lift" }),
      R("Be honest about doubts", "Honestly I do not know if the lads would follow me", "They already do. You just have not noticed", 9, { morale: 6 }),
      R("Turn it down", "Give it to someone who wants it. I just want to play", "Respect that. Rare, but I respect it", 6)
    ),
    B(
      "Whoever gets it, one bit of advice. The armband is not for the good days.",
      R("Ask what he means", "So what is it for", "The week after a hammering, when nobody wants to be first to speak. That is the job", 9, { morale: 4, perk: "lift" }),
      R("Say you know", "I know. I have watched you do it", "Then you already have it, plastic or not", 8, { morale: 4 })
    )
  ], { minAge: 24 }),
  /* ── Room mate ── */
  C("roomie_nerves", "roomie", "pro", [
    B(
      "You alright? You have been staring at the ceiling for an hour and it is 1am.",
      R("Admit the nerves", "Big one tomorrow. Head is going", "Same. Every time. Nobody says it out loud though so we all lie awake separately", 9, { morale: 5 }),
      R("Say it is nothing", "Nothing mate. Go to sleep", "You are a terrible liar. Night", 5),
      R("Put the light on", "Put the light on, we are talking", "Great. Now neither of us sleeps. Worth it though", 8, { morale: 4 })
    ),
    B(
      "Can I ask you something daft. Do you ever feel like you got lucky and they will find out?",
      R("Admit you feel it too", "Every week. Waiting to be found out", "Thank god. I thought it was just me", 10, { morale: 6, perk: "calm" }),
      R("Talk him out of it", "You are here because you are good. Full stop", "Coming from you that actually lands", 9, { morale: 4, perk: "lift" }),
      R("Laugh at him", "Yeah you did get lucky", "Wow. Lights off", -2, { warm: -6 })
    ),
    B(
      "Do you ever think about what we do after? Like actually after.",
      R("Talk about it", "All the time. Coaching maybe. Or nothing at all for a year", "See I want to open a cafe. Everyone laughs. You did not laugh", 9, { morale: 4, perk: "calm" }),
      R("Refuse to", "I do not let myself think about it", "Probably healthy. Probably not", 6)
    )
  ]),
  C("roomie_snacks", "roomie", "pro", [
    B(
      "Mate the hotel food is a war crime. I have found a chip shop 400 metres away. Are we doing this",
      R("Go", "Go. Nutritionist will never know", "He will absolutely know. Worth it", 7, { morale: 4, karma: -2 }),
      R("Refuse", "Not the night before a game. Bring me a banana", "A BANANA. You have changed", 6),
      R("Order in for the whole squad", "Do one better. I am ordering proper food for everyone", "You are going to be the most popular man in this hotel", 8, { morale: 5, cash: -0.01, perk: "lift" })
    )
  ]),
  /* ── Physio ── */
  C("physio_niggle", "physio", "pro", [
    B(
      "That hamstring. You have been guarding it for two weeks and you think I have not noticed.",
      R("Come clean", "It is tight. I did not want to say in case I got left out", "Thank you. Now I can actually help instead of guessing. In at eight", 10, { perk: "calm", morale: 3 }),
      R("Deny it", "It is fine. Honestly", "Then you will not mind me testing it in front of the gaffer tomorrow", -2, { warm: -6 }),
      R("Ask to manage it", "Can we manage it without me missing games", "Sometimes. If you are honest with me every single day. Deal?", 9, { perk: "calm" })
    ),
    B(
      "Last thing. How is the sleep and the stress. Both of those show up in soft tissue before they show up anywhere else.",
      R("Be honest", "Sleep is bad. Stress is worse", "Right. Then we treat that too. Half of my job is not legs", 10, { morale: 6, perk: "calm" }),
      R("Say it is fine", "All fine there", "Ok. But that box is ticked in pencil", 4)
    ),
    B(
      "One rule then and we are done. If something feels wrong on a Friday, you tell me on the Friday.",
      R("Agree to the rule", "Friday. Every time. Even if it is nothing", "That one rule will add years to your career. I am not exaggerating", 10, { perk: "calm", morale: 4 }),
      R("Push back", "I do not want to be the one always in the treatment room", "You will not be. You will be the one still playing at 34", 8, { perk: "calm" })
    )
  ]),
  /* ── Fitness coach ── */
  C("fitness_extra", "fitness", "any", [
    B(
      "Optional extras start Monday. 6am. Nobody has signed up yet which tells you everything.",
      R("Sign up", "Put my name down. First one in", "Good. Bring a bin. I am not joking", 8, { perk: "sharp", morale: -2 }),
      R("Ask what it does", "What does it actually give me", "Two more sprints in the last ten minutes. That is the difference between a goal and a photo of you jogging", 8, { perk: "sharp" }),
      R("Pass", "I need the rest more", "Fine. Rest is training too. But nobody ever got quicker resting", 3)
    ),
    B(
      "If you come, I want a target. Give me one number to chase.",
      R("Top speed", "Top speed. I want to be the quickest at this club", "Now we are talking. Twelve weeks", 9, { perk: "sharp" }),
      R("Games played", "I just want to finish a season without breaking down", "Best target anyone has given me all year", 9, { perk: "calm" })
    ),
    B(
      "Last thing. Bring somebody with you. Nobody sticks at 6am on their own.",
      R("Drag a teammate in", "I will drag one of the young lads in with me", "Two of you at 6am and by March half the squad is there. Watch", 10, { perk: "lift" }),
      R("Go alone", "I will be fine on my own", "You will last three weeks. Prove me wrong", 6)
    )
  ]),
  /* ── Old youth coach ── */
  C("youth_pride", "youthcoach", "any", [
    B(
      "Still got the team photo from your first season up on the wall. You are the small angry one at the front.",
      R("Ask about the others", "Who else from that photo is still playing?", "Two. One is at a non league club and loves it. One is a physio now. Everyone else has a proper job", 9, { morale: 4 }),
      R("Thank him", "You made me. I will say that for the rest of my life", "Get away with you. You made you. I just stopped you kicking people", 10, { morale: 6, karma: 4 }),
      R("Brush it off", "Long time ago that", "It is. And I still watch every week", 3)
    ),
    B(
      "Do me one favour. When a kid asks you for a photo, say yes. Even when you are tired.",
      R("Promise", "Always yes. Even when I am tired. Especially then", "Good lad. That is the whole lesson", 10, { karma: 6, popularity: 3 }),
      R("Be honest about it", "Some days I really do not want to", "Nobody does. Do it anyway. That is what the word professional means", 8, { karma: 3 })
    ),
    B(
      "And one day, when you are done, come and coach here. I am putting it in writing now.",
      R("Say yes", "When I am done I am coming straight back here", "I will hold this message up in about fifteen years", 10, { morale: 5, karma: 4 }),
      R("Cannot think that far", "I cannot even think about next season coach", "Then do not. I will keep the message anyway", 6)
    )
  ]),
  C("youth_return", "youthcoach", "pro", [
    B(
      "We have got a session Thursday for the under 12s. Twenty minutes of you would blow their minds. No cameras.",
      R("Do the whole session", "I will do the full session. And no cameras, agreed", "They are going to be unbearable for a month. Thank you", 10, { karma: 8, popularity: 3, morale: 4 }),
      R("Twenty minutes", "Twenty minutes is all I have got but I will be there", "Twenty minutes is twenty more than most", 8, { karma: 4, popularity: 2 }),
      R("Send kit instead", "Cannot do Thursday. Sending a full set of kit for them", "That will help. They would rather have you though", 5, { karma: 2, cash: -0.03 })
    )
  ], { minAge: 21 }),
  /* ── Academy kid ── */
  C("academy_firstteam", "academy", "any", [
    B(
      "Training with the first team tomorrow. I have been sick twice. Any advice",
      R("Give him the one rule", "First ball, first tackle, win it. Everything else follows", "First ball first tackle. Ok. Ok I can do that", 8, { karma: 4, perk: "lift" }),
      R("Offer to pick him up", "I will pick you up. We go in together", "Are you serious. I am not going to sleep now", 10, { karma: 8, morale: 4, perk: "lift" }),
      R("Tell him to relax", "You are there because you are good enough. Breathe", "Nobody has said that to me yet. Thank you", 8, { karma: 4 })
    ),
    B(
      "Last thing sorry. What if I am rubbish and they send me back",
      R("Tell him the truth", "You probably will be rubbish for a bit. Everybody is. Then you are not", "That is weirdly the most calming thing anyone has said", 9, { karma: 4, perk: "lift" }),
      R("Big him up", "You will not be rubbish. I have watched you", "You have WATCHED me? I need to sit down", 8, { morale: 3 })
    ),
    B(
      "If it goes ok tomorrow can I text you after? I have got nobody else to tell.",
      R("Yes, any time", "Text me after every session. I mean it", "You have no idea what that means. See you tomorrow", 10, { karma: 6, morale: 4, perk: "lift" }),
      R("Set a boundary", "Text me after big ones. I am not your dad", "Fair enough. Big ones only", 5)
    )
  ]),
  /* ── Kit man ── */
  C("kitman_shirt", "kitman", "pro", [
    B(
      "Lad in the laundry has been here 30 years and never asked a player for anything. He asked me to ask you for a shirt.",
      R("Sign one properly", "Get me the shirt from Saturday. I will write him something proper on it", "He is going to have that framed by Tuesday", 9, { karma: 6, morale: 3 }),
      R("Do one better", "Shirt, boots, and get him and his wife in the box for a game", "Right. Now you have made an old man cry in a laundry room", 10, { karma: 8, popularity: 3, cash: -0.01 }),
      R("Later", "Remind me after the international break", "Course. He has waited 30 years, he can wait a fortnight", -1, { warm: -3 })
    )
  ]),
  /* ── Journalist ── */
  C("journo_column", "journo", "pro", [
    B(
      "Doing a piece on players your age carrying clubs. Not a hit job. Ten minutes on the phone, you see quotes before print.",
      R("Do it properly", "Ten minutes, and I want to talk about the lads not just me", "That makes it a better piece anyway. Thursday?", 8, { popularity: 3, karma: 3 }),
      R("Decline politely", "Not for me at the minute. No hard feelings", "None at all. Door is open", 5),
      R("Use it", "I will do it if I can say what I actually think about the club", "Now THAT is a phone call. Thursday, and I am recording", 6, { popularity: 5, karma: -4 })
    ),
    B(
      "Off the record before we set it up. Are you happy there?",
      R("Nothing off the record", "There is no off the record with you lot. Ask me Thursday", "Fair. Genuinely fair. Thursday", 9, { karma: 5 }),
      R("Give him a hint", "Ask me again in January", "January. Noted. Loudly noted", 4, { karma: -3, popularity: 3 })
    ),
    B(
      "Fine. Then give me one line for the piece that is actually about football and not about you.",
      R("Praise a teammate", "Put in that our left back is the most underrated player in this league", "That is a lovely line and he will never forget it", 9, { karma: 5, perk: "lift" }),
      R("Praise the fans", "Say the away end has been the best thing about this season", "Cheap. True though. Using it", 8, { popularity: 4 }),
      R("Refuse", "I do not do lines. Watch the games", "Ha. Print that then", 4)
    )
  ], { minAge: 19 }),
  /* ── Country manager ── */
  C("nat_squad", "natcoach", "pro", [
    B(
      "Naming the squad Monday. Before I do I want to know where your head is, because your club season has been noisy.",
      R("Commit fully", "My head is fine. I will run through a wall for that shirt", "That is what I needed to hear. See you Monday", 9, { morale: 6, perk: "lift" }),
      R("Ask for honesty back", "Am I starting or am I making up the numbers", "You are in the squad. Starting is earned in the week, same as everyone", 8, { perk: "sharp" }),
      R("Ask to be left out", "I am running on empty. Leave me out this window", "Brave call. I would rather have you in March than broken in October", 7, { morale: 4, perk: "calm" })
    )
  ], { needs: (s) => !!s.internationalCareer }),
  C("nat_tournament", "natcoach", "pro", [
    B(
      "Long summer coming. I need players who will still be sprinting in the 85th minute of a semi final.",
      R("Volunteer for anything", "Put me anywhere. Left back if you need it", "I might hold you to that and you will regret typing it", 9, { morale: 5, perk: "lift" }),
      R("Be realistic", "I can give you 60 big minutes every game, not 90", "Honest. Useful. Most players lie to me about this", 9, { perk: "sharp" })
    )
  ], { needs: (s) => !!s.internationalCareer, minAge: 21 }),
  /* ── Rival ── */
  C("rival_respect", "rival", "pro", [
    B(
      "Good game. You were the best player on that pitch and I am only saying it once so screenshot it.",
      R("Give it back", "You were the reason it was close. Screenshot that", "Look at us. Two grown men being nice. Disgusting", 8, { morale: 4, popularity: 2 }),
      R("Stay cold", "Scoreboard said what it said", "Ha. There he is. See you in March", -2, { warm: -6, perk: "needle" }),
      R("Take the compliment", "Appreciated. Genuinely", "Do not get used to it", 6)
    ),
    B(
      "Serious for a second. Does it get to you, the comparison thing?",
      R("Admit it", "Every single week. You?", "Constantly. Nobody else understands it which is the annoying part", 9, { morale: 5 }),
      R("Deny it", "Not once. I do not think about you at all", "You replied in four seconds", 3, { perk: "needle" })
    ),
    B(
      "Alright. One promise. Whoever finishes with more, the other one turns up to the testimonial.",
      R("Shake on it", "Deal. And I will be the one clapping you off", "We will see. Good luck this season. Genuinely", 9, { morale: 4, popularity: 2 }),
      R("Refuse the deal", "I am not planning a testimonial. I am planning to keep going", "Terrifying. See you in March", 4, { perk: "needle" })
    )
  ], { needs: (s) => !!s.rival && !s.rival.retired }),
  C("rival_needle", "rival", "pro", [
    B(
      "Saw your interview. Bold from someone with fewer trophies than me.",
      R("Fire back", "Count them again in three years", "Oh it is ON. See you in the derby", 4, { popularity: 4, morale: 3, perk: "needle" }),
      R("Kill it with kindness", "You are right. Come and help me get some", "That is so annoying. I cannot even argue with that", 8, { karma: 4 }),
      R("Ignore the bait", "", "Silence. Interesting.", 1, { warm: 0 })
    ),
    B(
      "Between us though. Would you ever play in the same team as me.",
      R("Yes", "In a heartbeat. We would be unplayable", "We would be. Do not tell anyone I agreed", 8, { morale: 4 }),
      R("Never", "Never. I want to beat you, not carry you", "That is the correct answer and you know it", 3, { perk: "needle", popularity: 3 })
    )
  ], { needs: (s) => !!s.rival && !s.rival.retired }),
  /* ── second wave: more to say to the same people ── */
  C("mum_money", "mum", "pro", [
    B(
      "Somebody at the shop asked me what you earn. I told them to mind their own business.",
      R("Back her up", "Good. It is nobody's business but ours", "That is what I said. Then I told them anyway. Sorry", 8, { morale: 3 }),
      R("Offer to sort her out", "Mum, let me buy you something. Anything. Please", "I do not need anything. Ask me again next year and I might say a new sofa", 9, { morale: 5 }),
      R("Get annoyed", "People are so nosy", "They are proud. It comes out sideways", 5)
    ),
    B(
      "Do not let it change how you are with people. That is my only rule.",
      R("Promise", "Same me. Always. You would tell me if it was not", "I would tell you loudly and in front of everyone", 10, { karma: 5, morale: 4 }),
      R("Joke", "Too late, I am insufferable", "You are not. But keep checking", 6)
    ),
    B(
      "Right. Go and get some sleep. And ring your nan.",
      R("Ring nan now", "Ringing her now before I forget", "You are a good boy. Night love", 10, { morale: 5, karma: 3 }),
      R("Tomorrow", "I will ring her tomorrow", "Tomorrow. I am writing it down", 4)
    )
  ]),
  C("dad_debut", "dad", "pro", [
    B(
      "Do you remember your first proper game? I do. You were sick behind the dugout.",
      R("Own the memory", "I remember. And I still nearly am, every time", "Everybody is. The ones who say they are not are lying", 9, { morale: 4 }),
      R("Deny it", "That never happened", "I have a photograph of the bucket", 7, { morale: 3 })
    ),
    B(
      "Point is you did it anyway. That has always been the thing about you.",
      R("Take it in", "I needed to hear that this week actually", "Then I will say it more often instead of sending you diagrams", 10, { morale: 6, perk: "calm" }),
      R("Deflect", "Soft in your old age dad", "Very. Do not tell the lads at work", 6)
    )
  ], { minAge: 19 }),
  C("partner_home", "partner", "pro", [
    B(
      "I found a house. It is too big and it has a stupid bath and I love it.",
      R("Go and see it", "Send me the link. We are going Saturday", "SATURDAY. Right. I am ringing them now", 9, { morale: 6 }),
      R("Talk about the move risk", "What if we get moved in January though", "Then we rent it out and cry. Come and look at the bath", 7, { morale: 3 }),
      R("Shut it down", "Not while the contract situation is up in the air", "Ok. It will be gone but ok", 2, { warm: -3 })
    ),
    B(
      "Whatever we do, I do not want to live somewhere that only makes sense if you keep winning.",
      R("Agree completely", "Nothing we cannot keep if it all goes wrong. Agreed", "That is the most attractive thing you have ever said", 10, { morale: 6 }),
      R("Play it big", "I am going to keep winning", "Not what I asked. But ok", 4)
    )
  ], { minAge: 21, needs: (s) => !!s.hasRelationship || !!s.family?.isMarried }),
  C("captain_newsigning", "captain", "pro", [
    B(
      "New lad signed today. Speaks about nine words of the language and looks terrified. Sound familiar?",
      R("Take him under your wing", "I will sit with him at lunch. And drive him in", "That is why I texted you and not the group chat", 9, { karma: 5, perk: "lift" }),
      R("Do the basics", "I will make sure he knows where everything is", "Do that much and he sleeps tonight", 7, { karma: 3 }),
      R("Not interested", "He will figure it out like the rest of us did", "We did. It was horrible. That was the point", -2, { warm: -6 })
    ),
    B(
      "Get him in the five a side on Thursday. That is where anyone actually joins a team.",
      R("Sort it", "He is on my team Thursday. Sorted", "Good. He will be one of us by Friday", 9, { perk: "lift" }),
      R("Let somebody else", "Get one of the young lads to do it", "I asked you because they copy you", 5)
    )
  ]),
  C("roomie_contract", "roomie", "pro", [
    B(
      "They have not offered me a new deal. Six months left. I am pretending I am fine.",
      R("Be straight with him", "You are not fine and that is fair enough. What do you actually want?", "To stay. Obviously. But nobody has said a word to me", 9, { morale: 3 }),
      R("Offer to ask for him", "Want me to say something to the gaffer? Quietly", "Would you? I would never have asked", 10, { karma: 6, perk: "lift" }),
      R("Change the subject", "Early game tomorrow mate", "Yeah. Night", -3, { warm: -7 })
    ),
    B(
      "If it goes the other way, will you still answer my messages when I am at some other club?",
      R("Obviously", "You will not get rid of me. Wherever you end up", "Right. Now I am the one lying awake being soft", 10, { morale: 5 }),
      R("Be realistic", "We will see. People drift", "Brutal. Honest though", 4)
    )
  ]),
  C("physio_comeback", "physio", "pro", [
    B(
      "Four weeks in. I know you feel good. I know you want to play Saturday. Ask me anyway.",
      R("Ask properly", "Am I ready for Saturday, honestly", "No. Two more weeks and you get the rest of the season. Push it and you get neither", 10, { perk: "calm" }),
      R("Push for it", "I am playing Saturday whatever you say", "Then you are picking a fortnight over a season and I will write that down", -2, { warm: -6, morale: -3 }),
      R("Defer to him", "Whatever you say. I will not fight you on it", "Good. Nobody ever regrets that call", 9, { perk: "calm", morale: 3 })
    ),
    B(
      "While I have got you. Rehab is boring and you have got a whole week of it. Do you want a job?",
      R("Take the job", "Give me something to do or I will lose my mind", "Right. You are coaching the under 18s finishers this week", 9, { morale: 5, perk: "sharp" }),
      R("Just rest", "I am going to switch off completely for a week", "Also a real answer. Go and be a person", 8, { morale: 4 })
    )
  ], { minAge: 19 }),
  C("agent_loan", "agent", "pro", [
    B(
      "There is a loan on the table. Lower league, guaranteed starter, nobody watching. Old fashioned option.",
      R("Take the loan", "I will go. I need games more than I need the badge", "Best decision a young player can make and almost none of them make it", 9, { perk: "sharp" }),
      R("Ask what he thinks", "What does it actually do for me", "Thirty games. Men's football. Somebody kicking you every week. It makes you", 8, { perk: "sharp" }),
      R("Refuse", "I am not dropping down. I will fight for my place here", "Brave. Could go either way. I will tell them no", 6, { morale: 3 })
    ),
    B(
      "Whatever you pick, do not disappear on me for six months. I work better when you talk to me.",
      R("Agree", "I will ring you every month whether there is news or not", "You would be the first player who ever did. Deal", 10, { perk: "offer" }),
      R("Push back", "Ring me when there is something to say", "Fine. There will be less than you think", 3)
    )
  ], { minAge: 18, maxAge: 25 }),
  C("kitman_boots", "kitman", "pro", [
    B(
      "Your boots have been in the same bag since August and they smell like a crime. Want me to sort them?",
      R("Let him sort them", "Please. And whatever it costs I will double it", "It costs nothing. That is the job. But I will take the tea", 8, { morale: 3 }),
      R("Do it yourself", "I will do them tonight. My mess", "A player cleaning his own boots. I need a lie down", 9, { karma: 4 })
    ),
    B(
      "Forty years I have done this. You lot come and go. The polite ones I remember.",
      R("Ask about the old days", "Who was the best one you ever kitted out?", "Not telling you. But you are in the top ten and you are 22", 9, { morale: 4 }),
      R("Say thanks", "Thanks for everything you do. Genuinely", "Get out of my kit room before I get emotional", 9, { karma: 4, morale: 3 })
    )
  ]),
  C("nat_debut", "natcoach", "pro", [
    B(
      "First cap. I want you to enjoy it, and I want you to remember one thing when you walk out.",
      R("Ask what", "Go on. What is the one thing", "Everybody in that stadium already thinks you belong. Only you are arguing", 9, { morale: 7, perk: "calm" }),
      R("Say you are ready", "I have been ready since I was nine", "Then go and prove it and stop texting me", 8, { morale: 5 })
    ),
    B(
      "Your family are in the players' box. All of them. I checked.",
      R("Thank him", "That means more than the cap does. Thank you", "Now go and have the best night of your life", 10, { morale: 8 }),
      R("Get emotional", "You have properly got me now", "Good. Use it in the first twenty minutes", 9, { morale: 6 })
    )
  ], { needs: (s) => !!s.internationalCareer }),
  C("grandad_advice", "grandad", "any", [
    B(
      "Your father says you are worrying too much. He worries too much. Runs in the family.",
      R("Admit it", "I do worry. All the time", "Course you do. So did I. Then I got old and it stopped mattering", 9, { morale: 5, perk: "calm" }),
      R("Blame dad", "He is worse than me", "He is much worse than you. Do not tell him I said it", 8, { morale: 3 })
    ),
    B(
      "Here is my advice and then I am going for my nap. Play like you did in the garden.",
      R("Take it", "Like the garden. I will remember that on Saturday", "That is all it ever was. Everything else is people talking", 10, { morale: 6, perk: "sharp" }),
      R("Ask what he means", "What, terribly and with one boot on?", "Cheeky sod. Nap time", 7, { morale: 3 })
    )
  ]),
  C("mate_home", "bestmate", "any", [
    B(
      "Went past your old house today. New people have painted the door red. Thought you should know.",
      R("Ask for a photo", "Send me a picture. Red? Really?", "Bright red. Your mum would have something to say", 8, { morale: 4 }),
      R("Get nostalgic", "I can still see the wall we used as a goal", "It is still there. Still has the mark", 9, { morale: 5 })
    ),
    B(
      "Do you miss it? Genuinely. Or is that a stupid question when you live where you live.",
      R("Say you miss it", "Every day. It is not stupid at all", "Then come back for a weekend. Nobody will make a fuss", 10, { morale: 6, perk: "calm" }),
      R("Say no", "No. I wanted out and I got out", "Fair. You always did want more than this place", 6)
    )
  ]),
  C("fitness_recovery", "fitness", "pro", [
    B(
      "Your numbers dip badly in the last fifteen minutes. Not fitness. Recovery. What are you doing after games?",
      R("Admit nothing", "Honestly? Nothing. I go home and sit on my phone", "Right. Then we have found free minutes lying on the floor", 9, { perk: "sharp" }),
      R("Claim you do everything", "Ice bath, stretch, the lot", "Your numbers disagree and numbers do not lie to me", 4),
      R("Ask for a plan", "Write me a proper recovery week and I will follow it", "Sending it tonight. Follow it and you get twenty minutes back", 10, { perk: "sharp" })
    ),
    B(
      "Sleep is the whole thing by the way. Everything else is decoration.",
      R("Fix the sleep", "Phone out the bedroom starting tonight", "That one change is worth more than anything I can do to you in a gym", 10, { perk: "calm", morale: 4 }),
      R("Say you cannot", "I cannot sleep after night games. Never could", "Then we work on the after, not the sleep. Come see me", 8, { perk: "calm" })
    )
  ]),
  C("academy_advice", "academy", "pro", [
    B(
      "They released my mate today. He is 18. He has not stopped crying and I do not know what to say to him.",
      R("Tell him what to say", "Say nothing. Just sit with him. That is the whole job today", "That is what I did. I did not know if it was enough", 10, { karma: 6, morale: 3 }),
      R("Offer to help him", "Give me his name. I know people at three clubs who would look", "Are you serious? He will not believe this", 10, { karma: 8, perk: "lift" }),
      R("Be blunt", "It happens to nearly everyone. He will be fine", "Yeah. Suppose", 1, { warm: -4 })
    ),
    B(
      "Does it ever stop being scary? Like, at your level?",
      R("Tell the truth", "No. You just get better at carrying it", "Weirdly that helps", 9, { morale: 4 }),
      R("Lie kindly", "It gets easier. Promise", "Ok. I am holding you to that", 6)
    )
  ], { minAge: 21 }),
  C("journo_column2", "journo", "pro", [
    B(
      "Story doing the rounds that your dressing room has split. I am running something. Do you want a right of reply?",
      R("Kill it flat", "There is no split. Print that and I will stand behind it all season", "That is a strong denial and I will print it word for word", 8, { karma: 5, perk: "lift" }),
      R("Say nothing", "No comment", "No comment reads like yes to every reader alive. Your call", 4),
      R("Point him elsewhere", "Ask whoever fed you it what they want out of it", "Now THAT is a better story than the one I had", 6, { karma: -2, popularity: 3 })
    ),
    B(
      "Between us, who is actually briefing against you lot? You must know.",
      R("Refuse", "Even if I knew I would not tell you", "Correct answer. Annoying. Respect", 9, { karma: 6 }),
      R("Give him a name", "I have got an idea. Off the record", "Off the record does not exist but go on", 3, { karma: -6, popularity: 4 })
    )
  ], { minAge: 21 }),
  C("gaffer_captainask", "gaffer", "pro", [
    B(
      "Something I want your read on, not as a player. Who do the group actually listen to in there?",
      R("Name somebody honestly", "The keeper. Nobody argues with him", "That matches what I see. Thank you for not saying yourself", 9, { perk: "lift" }),
      R("Say yourself", "Me, when it matters", "Bold. Prove it Tuesday when I make you run the warm up", 7, { morale: 4 }),
      R("Dodge it", "Not sure I should be answering that", "Fair. Forget I asked", 4)
    ),
    B(
      "Second question and then I will let you eat. What do the players say about ME when I leave the room?",
      R("Tell him straight", "That you are honest and that you are hard work. Both", "That is the most useful sentence anyone has said to me this season", 10, { perk: "lift", morale: 4 }),
      R("Protect him", "Nothing bad", "Now I know it is bad", 3)
    )
  ], { minAge: 24 }),
  C("rival_national", "rival", "pro", [
    B(
      "Wild that we are in the same squad this week. Do we have to pretend to like each other in front of the press?",
      R("Play nice for the country", "For ten days, yes. Then back to normal", "Ten days. Then war. Deal", 8, { morale: 4, popularity: 2 }),
      R("Refuse", "I am not pretending anything", "Honestly? Same. See you at breakfast", 3, { perk: "needle" })
    ),
    B(
      "Room next to yours by the way. If you snore I am telling everyone.",
      R("Wind him up", "I will snore on purpose", "You are the worst. See you at training", 7, { morale: 3 }),
      R("Call a truce", "Truce for the tournament. Properly", "Truce. And if we win it nobody ever mentions this chat again", 9, { morale: 5, perk: "lift" })
    )
  ], { needs: (s) => !!s.rival && !s.rival.retired && !!s.internationalCareer })
];
var CONVO_BY_ID = Object.fromEntries(CONVOS.map((c) => [c.id, c]));
var COLD_WARM = [
  [
    "Did you get my last one? No rush.",
    "Still waiting on you. Not sulking. Just saying.",
    "Hello? Anyone in there?"
  ],
  [
    "Wow. I see how it is then.",
    "Right. Message received. Loud and clear.",
    "Cool. Glad we are close."
  ],
  [
    "The fame has really gotten to you.",
    "You have changed. Everyone says it and I keep defending you.",
    "I will stop texting. You clearly have people for that now."
  ]
];
var COLD_WORK = [
  [
    "Chasing this one. Let me know either way.",
    "Still need an answer on that when you get a sec.",
    "Bumping this up your inbox."
  ],
  [
    "Wow. I see how it is.",
    "Two months, nothing. Noted.",
    "I will assume that is a no then."
  ],
  [
    "The fame has really gotten to you.",
    "You were easier to deal with before all this.",
    "I will stop bothering you. Best of luck."
  ]
];
var WARM_CONTACTS = ["mum", "dad", "grandad", "partner", "bestmate", "youthcoach", "academy"];
var REL_FLOOR = 22;
function blankPhone() {
  return {
    threads: [],
    feed: [],
    world: null,
    clubs: {},
    rivalClub: null,
    seed: 1,
    offers: 0,
    perksTaken: 0
  };
}
function ensurePhone(s) {
  const p = s.phone;
  if (!p || typeof p !== "object") return blankPhone();
  const out = {
    threads: Array.isArray(p.threads) ? p.threads.filter((t) => t && Array.isArray(t.lines)) : [],
    feed: Array.isArray(p.feed) ? p.feed.filter((f) => typeof f === "string") : [],
    world: p.world && typeof p.world === "object" ? p.world : null,
    clubs: p.clubs && typeof p.clubs === "object" ? p.clubs : {},
    rivalClub: typeof p.rivalClub === "string" ? p.rivalClub : null,
    seed: typeof p.seed === "number" && p.seed > 0 ? p.seed : 1,
    offers: typeof p.offers === "number" ? p.offers : 0,
    perksTaken: typeof p.perksTaken === "number" ? p.perksTaken : 0
  };
  for (const t of out.threads) {
    if (typeof t.rel !== "number" || !Number.isFinite(t.rel)) t.rel = 50;
    t.rel = clamp(Math.round(t.rel), 0, 100);
    if (typeof t.cold !== "number") t.cold = 0;
    if (!Array.isArray(t.seen)) t.seen = [];
    if (t.waiting === void 0) t.waiting = null;
    if (t.lastReplyYear === void 0) t.lastReplyYear = null;
    if (t.pending === void 0) t.pending = null;
  }
  return out;
}
function writePhone(s, p) {
  s.phone = p;
}
var yearOf = (s) => s.seasons.length > 0 ? s.seasons[s.seasons.length - 1].year : 2020;
function threadFor(p, id, s) {
  let t = p.threads.find((x) => x.c === id);
  if (t) {
    t.name = contactName(id, s);
    return t;
  }
  t = {
    id: `th_${id}`,
    c: id,
    name: contactName(id, s),
    emoji: contactEmoji(id),
    lines: [],
    rel: 50,
    pending: null,
    waiting: null,
    cold: 0,
    seen: [],
    lastReplyYear: null
  };
  p.threads.push(t);
  return t;
}
function pushLine(t, who, text2, year) {
  if (!text2) return;
  t.lines.push({ w: who, t: text2, y: year });
  if (t.lines.length > MAX_LINES) t.lines.splice(0, t.lines.length - MAX_LINES);
}
function trimThreads(p) {
  while (p.threads.length > MAX_THREADS) {
    let idx = p.threads.findIndex((t) => t.pending === null);
    if (idx === -1) idx = 0;
    p.threads.splice(idx, 1);
  }
}
function convoEligible(def, s, phase, t) {
  if (def.phase !== "any" && def.phase !== phase) return false;
  if (def.minAge !== void 0 && s.age < def.minAge) return false;
  if (def.maxAge !== void 0 && s.age > def.maxAge) return false;
  if (!contactAvailable(def.contact, s, phase)) return false;
  if (def.needs && !def.needs(s)) return false;
  if (t && t.seen.includes(def.id)) return false;
  return true;
}
function startConvo(t, def, year, override) {
  t.seen.push(def.id);
  if (t.seen.length > MAX_SEEN) t.seen.splice(0, t.seen.length - MAX_SEEN);
  pushLine(t, 0, override ?? def.beats[0].text, year);
  t.pending = { kind: "convo", convo: def.id, beat: 0 };
  t.waiting = year;
}
function pickConvo(s, p, t, phase) {
  const rng = new Rng(p.seed);
  const fits = CONVOS.filter((d) => d.contact === t.c && convoEligible(d, s, phase, t));
  p.seed = rng.state;
  if (fits.length === 0) return null;
  return fits[Math.floor(rng.next() * fits.length)];
}
function phoneSeasonTick(s, phase) {
  const p = ensurePhone(s);
  const year = yearOf(s);
  const rng = new Rng(p.seed || Math.floor(Math.random() * 4294967295) >>> 0 || 7);
  const BITE = [14, 9, 5];
  for (const t of p.threads) {
    if (t.pending && t.waiting !== null && t.waiting < year) {
      if (t.cold >= 3) {
        t.waiting = year;
        continue;
      }
      t.cold = Math.min(3, t.cold + 1);
      t.rel = clamp(t.rel - BITE[t.cold - 1], REL_FLOOR, 100);
      const table = WARM_CONTACTS.includes(t.c) ? COLD_WARM : COLD_WORK;
      const stage = table[Math.min(t.cold, table.length) - 1];
      pushLine(t, 0, stage[rng.int(0, stage.length - 1)], year);
      t.waiting = year;
    }
  }
  const standing = standingOf(p);
  if (p.threads.length > 0) {
    const ceiling = 56 + Math.round(standing * 0.38);
    if (standing < 42 && s.morale > 46) s.morale = clamp(Math.max(46, s.morale - 3), 0, 100);
    else if (standing > 60 && s.morale < ceiling) s.morale = clamp(Math.min(ceiling, s.morale + 3), 0, 100);
    if (standing >= 70 && s.popularity < 70) s.popularity = clamp(s.popularity + 1, 0, 100);
    else if (standing <= 30 && s.popularity > 40) s.popularity = clamp(s.popularity - 1, 0, 100);
  }
  const waitingNow = p.threads.filter((t) => t.pending !== null).length;
  let want = Math.max(0, 2 - waitingNow);
  const candidates = CONTACTS.map((c) => c.id).filter((id) => contactAvailable(id, s, phase)).filter((id) => {
    const t = p.threads.find((x) => x.c === id);
    return !t || t.pending === null;
  });
  for (let i = candidates.length - 1; i > 0; i--) {
    const j = Math.floor(rng.next() * (i + 1));
    [candidates[i], candidates[j]] = [candidates[j], candidates[i]];
  }
  for (const id of candidates) {
    if (want <= 0) break;
    const t = threadFor(p, id, s);
    const def = pickConvo(s, p, t, phase);
    if (!def) {
      if (t.lines.length === 0) p.threads = p.threads.filter((x) => x !== t);
      continue;
    }
    startConvo(t, def, year);
    want -= 1;
  }
  p.seed = rng.state;
  trimThreads(p);
  writePhone(s, p);
}
function legacyContact(from) {
  const f = from.toLowerCase();
  if (f.includes("mum")) return "mum";
  if (f.includes("grandad")) return "grandad";
  if (f.includes("agent")) return "agent";
  if (f.includes("kit man")) return "kitman";
  if (f.includes("journal")) return "journo";
  if (f.includes("youth coach")) return "youthcoach";
  if (f.includes("academy")) return "academy";
  if (f.includes("captain") || f.includes("veteran")) return "captain";
  if (f.includes("physio") || f.includes("psych") || f.includes("nutrition")) return "physio";
  if (f.includes("fitness")) return "fitness";
  if (f.includes("teammate")) return "roomie";
  if (f.includes("rival")) return "rival";
  if (f.includes("school friend")) return "bestmate";
  return null;
}
var slug = (v) => v.toLowerCase().replace(/[^a-z0-9]+/g, "").slice(0, 14) || "x";
function mirrorLegacyMessage(s, msgId, from, text2, year) {
  const p = ensurePhone(s);
  const id = legacyContact(from);
  let t;
  if (id) {
    t = threadFor(p, id, s);
  } else {
    const tid = `th_x_${slug(from)}`;
    const found = p.threads.find((x) => x.id === tid);
    if (found) t = found;
    else {
      t = { id: tid, c: "other", name: from, emoji: "\u{1F4AC}", lines: [], rel: 50, pending: null, waiting: null, cold: 0, seen: [], lastReplyYear: null };
      p.threads.push(t);
    }
  }
  if (t.pending) return;
  pushLine(t, 0, text2, year);
  t.pending = { kind: "legacy", msgId };
  t.waiting = year;
  trimThreads(p);
  writePhone(s, p);
}
function standingOf(p) {
  if (p.threads.length === 0) return 50;
  const sum = p.threads.reduce((a, t) => a + t.rel, 0);
  return Math.round(sum / p.threads.length);
}

// src/lib/careerMoney.ts
var MAX_HISTORY = 8;
var MAX_LEDGER = 12;
var CASH_FLOOR = 0.1;
var TRADE_FEE = 0.01;
var SAVINGS_RATE = 0.025;
var ASSETS = [
  {
    id: "ladder",
    name: "Steady Ladder Fund",
    emoji: "\u{1F4D7}",
    kind: "fund",
    blurb: "A bit of everything. Boring on purpose.",
    drift: 0.055,
    vol: 0.05,
    pull: 0.55,
    risk: "steady"
  },
  {
    id: "bricks",
    name: "Old Town Bricks",
    emoji: "\u{1F9F1}",
    kind: "property",
    blurb: "Flats above the shops back home.",
    drift: 0.04,
    vol: 0.11,
    pull: 0.4,
    risk: "steady"
  },
  {
    id: "cleats",
    name: "Cleatworks",
    emoji: "\u{1F45F}",
    kind: "share",
    blurb: "They make boots. Half the league wears them.",
    drift: 0.032,
    vol: 0.17,
    pull: 0.35,
    risk: "bumpy"
  },
  {
    id: "screens",
    name: "Matchday Screens",
    emoji: "\u{1F4FA}",
    kind: "share",
    blurb: "Sells the rights, sells the ads, sells the highlights.",
    drift: 0.025,
    vol: 0.22,
    pull: 0.32,
    risk: "bumpy"
  },
  {
    id: "spark",
    name: "SparkCoin",
    emoji: "\u26A1",
    kind: "coin",
    blurb: "A coin your mate's cousin made. Halves as often as it doubles.",
    drift: 0.01,
    vol: 0.5,
    pull: 0.25,
    risk: "wild"
  }
];
var ASSET_BY_ID = Object.fromEntries(ASSETS.map((a) => [a.id, a]));
var PAR = 100;
function nextSeed2(s) {
  return s * 1664525 + 1013904223 >>> 0;
}
var Rng2 = class {
  constructor(s) {
    this.s = s;
    this.s = s >>> 0 || 1;
  }
  next() {
    this.s = nextSeed2(this.s);
    return this.s / 4294967296;
  }
  get state() {
    return this.s;
  }
  int(lo, hi) {
    return lo + Math.floor(this.next() * (hi - lo + 1));
  }
  /** Roughly normal, mean 0, standard deviation 1. Three uniforms is plenty
   *  for a price shock and it costs nothing. */
  gauss() {
    return (this.next() + this.next() + this.next() - 1.5) / 0.5;
  }
};
var clamp2 = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
var r2 = (v) => Math.round(v * 100) / 100;
var r4 = (v) => Math.round(v * 1e4) / 1e4;
function seedFromName(name, salt) {
  const born = (name || "x").split("").reduce((h, c) => h * 31 + c.charCodeAt(0) >>> 0, 7);
  return born ^ salt * 2654435761;
}
function blankMoney(seed) {
  const price = {};
  const hist = {};
  const hold = {};
  const cost = {};
  for (const a of ASSETS) {
    price[a.id] = PAR;
    hist[a.id] = [PAR];
    hold[a.id] = 0;
    cost[a.id] = 0;
  }
  return {
    seed: seed >>> 0 || 1,
    vault: 0,
    hold,
    cost,
    price,
    hist,
    log: [],
    year: 0,
    age: 0,
    won: 0,
    lost: 0,
    cPlays: 0,
    cNet: 0,
    cYear: 0,
    cShut: false,
    aYear: 0,
    aBest: 0,
    aPlays: 0
  };
}
var num = (v, fallback) => typeof v === "number" && Number.isFinite(v) ? v : fallback;
function ensureMoney(s, sport) {
  const raw = s.money;
  const out = blankMoney(sport.seedOf(s));
  if (!raw || typeof raw !== "object") return out;
  out.seed = num(raw.seed, out.seed) >>> 0 || 1;
  out.vault = Math.max(0, r2(num(raw.vault, 0)));
  out.year = Math.round(num(raw.year, 0));
  out.age = Math.max(0, Math.round(num(raw.age, 0)));
  out.won = Math.max(0, r2(num(raw.won, 0)));
  out.lost = Math.max(0, r2(num(raw.lost, 0)));
  out.cPlays = Math.max(0, Math.round(num(raw.cPlays, 0)));
  out.cNet = r2(num(raw.cNet, 0));
  out.cYear = Math.round(num(raw.cYear, 0));
  out.cShut = raw.cShut === true;
  out.aYear = Math.round(num(raw.aYear, 0));
  out.aBest = clamp2(Math.round(num(raw.aBest, 0)), 0, 3);
  out.aPlays = Math.max(0, Math.round(num(raw.aPlays, 0)));
  for (const a of ASSETS) {
    const p = num(raw.price?.[a.id], PAR);
    out.price[a.id] = clamp2(r2(p), 1, PAR * 40);
    out.hold[a.id] = Math.max(0, r4(num(raw.hold?.[a.id], 0)));
    out.cost[a.id] = Math.max(0, r2(num(raw.cost?.[a.id], 0)));
    const h = Array.isArray(raw.hist?.[a.id]) ? raw.hist[a.id].filter((v) => typeof v === "number" && Number.isFinite(v)) : [];
    out.hist[a.id] = (h.length ? h : [out.price[a.id]]).slice(-MAX_HISTORY).map((v) => clamp2(r2(v), 1, PAR * 40));
  }
  const log2 = Array.isArray(raw.log) ? raw.log : [];
  out.log = log2.filter((e) => e && typeof e === "object" && typeof e.t === "string").slice(-MAX_LEDGER).map((e) => ({ y: Math.round(num(e.y, 0)), t: String(e.t).slice(0, 40), a: r2(num(e.a, 0)) }));
  return out;
}
function writeMoney(s, m) {
  s.money = m;
}
var cashOf = (s) => s.netWorth ?? 0;
function note(m, year, text2, amount) {
  m.log.push({ y: year, t: text2.slice(0, 40), a: r2(amount) });
  if (m.log.length > MAX_LEDGER) m.log.splice(0, m.log.length - MAX_LEDGER);
}
function holdingValue(m, id) {
  return r2((m.hold[id] ?? 0) * (m.price[id] ?? PAR) / PAR);
}
function investedValue(m) {
  let total = 0;
  for (const a of ASSETS) total += holdingValue(m, a.id);
  return r2(total);
}
function anchorOf(def, age) {
  return PAR * Math.pow(1 + def.drift, age);
}
function moneySeasonTick(s, year, sport) {
  const m = ensureMoney(s, sport);
  const fmt = (v) => fmtMoney(v, sport.currency);
  const events = [];
  if (m.year === year) {
    writeMoney(s, m);
    return { events };
  }
  m.year = year;
  m.age += 1;
  const rng = new Rng2(m.seed);
  if (m.vault > 0) {
    const interest = r2(m.vault * SAVINGS_RATE);
    if (interest >= 0.01) {
      m.vault = r2(m.vault + interest);
      m.won = r2(m.won + interest);
      note(m, year, "Savings interest", interest);
    }
  }
  for (const def of ASSETS) {
    const anchor = anchorOf(def, m.age);
    const p = m.price[def.id] ?? PAR;
    const shocked = p * (1 + def.vol * rng.gauss());
    let next = shocked + def.pull * (anchor - shocked);
    next = clamp2(next, anchor * 0.18, anchor * 3.4);
    next = clamp2(r2(next), 3, PAR * 40);
    const before = p;
    m.price[def.id] = next;
    const h = m.hist[def.id] ?? [];
    h.push(next);
    if (h.length > MAX_HISTORY) h.splice(0, h.length - MAX_HISTORY);
    m.hist[def.id] = h;
    if ((m.hold[def.id] ?? 0) > 0 && events.length < 2) {
      const move = (next - before) / Math.max(before, 1);
      if (move >= 0.28) {
        events.push(`${def.emoji} ${def.name} jumped ${Math.round(move * 100)}%. Your stake is worth ${fmt(holdingValue(m, def.id))} now.`);
      } else if (move <= -0.25) {
        events.push(`${def.emoji} ${def.name} dropped ${Math.round(-move * 100)}%. Your stake is down to ${fmt(holdingValue(m, def.id))}.`);
      }
    }
  }
  if (cashOf(s) < CASH_FLOOR) {
    let need = r2(CASH_FLOOR - cashOf(s));
    if (m.vault > 0 && need > 0) {
      const take = Math.min(m.vault, need);
      m.vault = r2(m.vault - take);
      s.netWorth = r2(cashOf(s) + take);
      need = r2(need - take);
      note(m, year, "Savings covered the bills", -take);
      events.push(`\u{1F3E6} Bills came out of savings this season. ${fmt(take)} gone.`);
    }
    const order = ASSETS.slice().sort((a, b) => holdingValue(m, b.id) - holdingValue(m, a.id));
    for (const def of order) {
      if (need <= 0) break;
      const value = holdingValue(m, def.id);
      if (value <= 0.01) continue;
      const frac = Math.min(1, need / value);
      const got = sellUnits(m, def.id, frac, year, true);
      s.netWorth = r2(cashOf(s) + got);
      need = r2(need - got);
      events.push(`\u{1F4C9} Had to sell ${def.name} to cover the bills. ${fmt(got)} raised at a bad price.`);
    }
  }
  const buffer = m.vault + investedValue(m);
  const bill = Math.max(0.2, sport.billOf(s) || 0.2);
  if (cashOf(s) + buffer < bill * 0.75) {
    if (s.morale > 44) s.morale = clamp2(Math.max(44, s.morale - 3), 0, 100);
  } else if (buffer >= bill * 3 && s.morale < 64) {
    s.morale = clamp2(Math.min(64, s.morale + 2), 0, 100);
  }
  const w = sport.words.cards;
  if (m.cPlays >= 4 && m.cNet <= -0.12 && !m.cShut && m.cYear === year) {
    s.morale = clamp2(s.morale - 3, 0, 100);
    sport.shame(s);
    events.push(`\u{1F0CF} Somebody at home asked how much you have actually lost ${w.thatPlace}. You did not have a good answer.`);
  }
  if (m.cNet <= -0.5 && !m.cShut) {
    m.cShut = true;
    events.push(`\u{1F0CF} ${w.crewCap} have stopped dealing you in. Honestly, that is probably for the best.`);
  }
  m.seed = rng.state;
  writeMoney(s, m);
  return { events };
}
function sellUnits(m, id, frac, year, forced = false) {
  const held = m.hold[id] ?? 0;
  if (held <= 0) return 0;
  const f = clamp2(frac, 0, 1);
  const units = r4(held * f);
  if (units <= 0) return 0;
  const gross = units * (m.price[id] ?? PAR) / PAR;
  const cash = r2(gross * (1 - TRADE_FEE));
  const basis = r2((m.cost[id] ?? 0) * f);
  m.hold[id] = r4(held - units);
  m.cost[id] = r2(Math.max(0, (m.cost[id] ?? 0) - basis));
  if (m.hold[id] <= 1e-4) {
    m.hold[id] = 0;
    m.cost[id] = 0;
  }
  const profit = r2(cash - basis);
  if (profit >= 0) m.won = r2(m.won + profit);
  else m.lost = r2(m.lost - profit);
  const def = ASSET_BY_ID[id];
  note(m, year, `${forced ? "Forced sale" : "Sold"} ${def.name}`, cash);
  return cash;
}
function fmtMoney(v, currency) {
  const neg = v < 0;
  const a = Math.abs(v);
  const body = a >= 1e3 ? `${currency}${(a / 1e3).toFixed(2)}bn` : a >= 1 ? `${currency}${a.toFixed(1)}M` : `${currency}${Math.round(a * 1e3)}k`;
  return neg ? `-${body}` : body;
}

// src/lib/soccerMoney.ts
var clamp3 = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
var SOCCER_MONEY = {
  currency: "\u20AC",
  seedOf: (s) => seedFromName(s.playerName, s.seasons?.length ?? 0),
  yearOf: (s) => s.seasons.length > 0 ? s.seasons[s.seasons.length - 1].year : 2020,
  billOf: (s) => s.lifestyleCostPerYear,
  shame: (s) => {
    s.karma = clamp3((s.karma ?? 50) - 2, 0, 100);
  },
  words: {
    cards: {
      ledger: "Cards on the bus",
      crew: "the lads",
      crewCap: "The lads",
      where: "on the bus",
      thatPlace: "on that bus",
      next: "Next away trip."
    },
    arcade: { ledger: "Won the phone quiz", name: "the ball quiz" }
  }
};
function ensureMoney2(s) {
  return ensureMoney(s, SOCCER_MONEY);
}
function moneySeasonTick2(s, year) {
  return moneySeasonTick(s, year, SOCCER_MONEY);
}

// src/lib/careerInbox.ts
var clamp4 = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
function pickInboxTexts(pool, age, phase, usedIds, count, rng = Math.random) {
  const used = new Set(usedIds);
  const fits = pool.filter(
    (t) => !used.has(t.id) && (t.phase === "any" || t.phase === phase) && (t.minAge === void 0 || age >= t.minAge) && (t.maxAge === void 0 || age <= t.maxAge)
  );
  const out = [];
  const left = [...fits];
  while (out.length < count && left.length > 0) {
    const i = Math.floor(rng() * left.length);
    out.push(left[i]);
    left.splice(i, 1);
  }
  return out;
}
function pickBeatTexts(pool, calendar, beats, age, phase, usedIds, count, rng = Math.random) {
  const atBeat = (b) => pool.filter((t) => t.beat === b.id);
  const open = calendar.filter(
    (b) => beats.includes(b.id) && pickInboxTexts(atBeat(b), age, phase, usedIds, 1, () => 0).length > 0
  );
  const chosen = open.filter((b) => b.oneOff).slice(0, count);
  const rest = open.filter((b) => !b.oneOff);
  while (chosen.length < count && rest.length > 0) {
    const i = Math.floor(rng() * rest.length);
    chosen.push(rest[i]);
    rest.splice(i, 1);
  }
  chosen.sort((a, b) => calendar.indexOf(a) - calendar.indexOf(b));
  return chosen.map((b) => ({ def: pickInboxTexts(atBeat(b), age, phase, usedIds, 1, rng)[0], beat: b.id }));
}
function receiveInboxTexts(s, phase, sport, rng = Math.random, beats) {
  driftInboxMood(s, sport);
  return deliverInboxTexts(s, phase, sport, rng, beats);
}
function driftInboxMood(s, sport) {
  const mood = sport.moodOf(s);
  const next = mood > 50 ? mood - 2 : mood < 50 ? Math.min(50, mood + 2) : mood;
  if (next >= 70) {
    sport.addPopularity(s, 2);
    s.morale = clamp4(s.morale + 2, 0, 100);
  } else if (next <= 30) {
    sport.addPopularity(s, -2);
    s.morale = clamp4(s.morale - 1, 0, 100);
  }
  sport.setMood(s, next);
}
function deliverInboxTexts(s, phase, sport, rng = Math.random, beats) {
  const inbox = [...s.phoneInbox ?? []];
  const used = [...s.phoneUsedIds ?? []];
  const unanswered = inbox.filter((m) => m.answered === void 0).length;
  const want = Math.max(0, sport.wantPerSeason - unanswered);
  const year = sport.yearOf(s);
  const age = sport.ageOf(s);
  const fresh = [];
  const deliver = (def, beat) => {
    const msg = { id: `${def.id}-${year}`, defId: def.id, from: def.from, emoji: def.emoji, text: def.text, year, choices: def.choices, ...beat ? { beat } : {} };
    inbox.push(msg);
    fresh.push(msg);
    used.push(def.id);
  };
  if (beats === void 0) {
    for (const def of pickInboxTexts(sport.pool, age, phase, used, want, rng)) {
      deliver(def);
    }
  } else {
    for (const pick2 of pickBeatTexts(sport.pool, sport.calendar ?? [], beats, age, phase, used, want, rng)) {
      deliver(pick2.def, pick2.beat);
    }
  }
  while (inbox.length > sport.maxInbox) {
    const idx = inbox.findIndex((m) => m.answered !== void 0);
    if (idx === -1) break;
    inbox.splice(idx, 1);
  }
  s.phoneInbox = inbox;
  s.phoneUsedIds = used;
  return fresh;
}

// src/lib/soccerCareerEngine.ts
init_intlNames();

// src/lib/soccerCurrency.ts
var CURRENCIES = [
  { code: "EUR", symbol: "\u20AC", name: "Euro", perEur: 1 },
  { code: "GBP", symbol: "\xA3", name: "British pound", perEur: 0.8567 },
  { code: "USD", symbol: "$", name: "US dollar", perEur: 1.1699 },
  { code: "BRL", symbol: "R$", name: "Brazilian real", perEur: 6.0518 },
  { code: "MXN", symbol: "MX$", name: "Mexican peso", perEur: 19.769 },
  { code: "JPY", symbol: "\xA5", name: "Japanese yen", perEur: 185.66 },
  { code: "INR", symbol: "\u20B9", name: "Indian rupee", perEur: 111.9595 },
  { code: "AUD", symbol: "A$", name: "Australian dollar", perEur: 1.6321 }
];
var EUR = CURRENCIES[0];
var STORAGE_KEY = "dukb-soccer-currency";
function currencyByCode(code) {
  if (!code) return EUR;
  return CURRENCIES.find((c) => c.code === code) ?? EUR;
}
function getCurrency() {
  try {
    return currencyByCode(localStorage.getItem(STORAGE_KEY));
  } catch {
    return EUR;
  }
}
function trim(v) {
  const a = Math.abs(v);
  if (a >= 100) return v.toFixed(0);
  if (a >= 10) return v.toFixed(1);
  return v.toFixed(2).replace(/(\.\d*[1-9])0+$/, "$1").replace(/\.0+$/, "");
}
var LADDER = ["", "k", "M", "B", "T"];
function normalise(value, unit) {
  let i = Math.max(0, LADDER.indexOf(unit));
  let v = value;
  while (Math.abs(v) >= 1e3 && i < LADDER.length - 1) {
    v /= 1e3;
    i += 1;
  }
  while (Math.abs(v) < 1 && v !== 0 && i > 0) {
    v *= 1e3;
    i -= 1;
  }
  return { value: v, unit: LADDER[i] };
}
var MONEY = /€(\d+(?:\.\d+)?)([kMB])?/g;
function localizeMoney(text2, cur = getCurrency()) {
  if (cur.code === "EUR" || !text2 || text2.indexOf("\u20AC") === -1) return text2;
  return text2.replace(MONEY, (_full, num2, unit) => {
    const n = normalise(Number(num2) * cur.perEur, unit ?? "");
    return `${cur.symbol}${trim(n.value)}${n.unit}`;
  });
}

// src/lib/soccerCareerToManager.ts
init_managerOffers();

// src/lib/soccerCareerEngine.ts
init_managerOffers();

// src/lib/soccerCareerBrand.ts
var log = (s, line) => {
  s.events = [...s.events, line];
};
var followers = {
  get: (s) => s.socialMediaFollowers,
  set: (s, v) => {
    s.socialMediaFollowers = v;
  }
};
var popularity = {
  get: (s) => s.popularity,
  set: (s, v) => {
    s.popularity = v;
  }
};
var SOCCER_SAVE_IDS = {
  local_deal: "local_brand",
  kit_deal: "nike_adidas",
  global_ambassador: "global_ambassador",
  own_line: "merchandise_line",
  game_cover: "cover_athlete"
};
var SOCCER_TIERS = [
  { id: "local_deal", name: "Local Brand Deal", emoji: "\u{1F3EA}", minFollowers: 1e6, income: 0.5 },
  { id: "kit_deal", name: "Global Boot Deal", emoji: "\u{1F45F}", minFollowers: 5e6, income: 3 },
  { id: "global_ambassador", name: "Global Brand Ambassador", emoji: "\u{1F30D}", minFollowers: 15e6, income: 8 },
  { id: "own_line", name: "Own Merchandise Line", emoji: "\u{1F455}", minFollowers: 3e7, income: 15 },
  { id: "game_cover", name: "Game Cover Athlete", emoji: "\u{1F3AE}", minFollowers: 5e7, income: 25 }
];
var SPONSORSHIP_TIERS = SOCCER_TIERS.map((t) => ({ tier: SOCCER_SAVE_IDS[t.id], name: t.name, emoji: t.emoji, minFollowers: t.minFollowers, income: t.income }));
var SOCCER_COVER = {
  minFollowers: 5e7,
  minRating: 90,
  pay: 25,
  followers: 5,
  declineStanding: 5,
  award: { name: "Game Cover Athlete", emoji: "\u{1F3AE}" }
};
var SOCCER_BRAND = {
  tiers: SOCCER_TIERS,
  saveIds: SOCCER_SAVE_IDS,
  followerUnit: 1e6,
  followers,
  standing: popularity,
  cash: {
    get: (s) => s.netWorth,
    set: (s, v) => {
      s.netWorth = v;
    }
  },
  rating: (s) => s.overall,
  tier: {
    get: (s) => s.activeSponsorship,
    set: (s, stored) => {
      s.activeSponsorship = stored;
    }
  },
  cover: {
    ...SOCCER_COVER,
    taken: {
      get: (s) => s.coverAthleteAccepted,
      set: (s, v) => {
        s.coverAthleteAccepted = v;
      }
    },
    waiting: {
      get: (s) => s.pendingCoverAthleteEvent,
      set: (s, v) => {
        s.pendingCoverAthleteEvent = v;
      }
    },
    record: (s, a) => {
      s.awards = [...s.awards, { year: s.seasons[s.seasons.length - 1]?.year || 2024, name: a.name, emoji: a.emoji }];
    }
  },
  fame: [[80, 2], [60, 1], [40, 0.3]],
  perFollower: 0.1,
  // €100k per 1M followers
  log,
  words: {
    signed: (t) => `${t.emoji} NEW SPONSORSHIP: ${t.name}, \u20AC${t.income}M/year!`,
    coverTaken: `\u{1F3AE} You are the cover athlete of the world's biggest football video game! \u20AC${SOCCER_COVER.pay}M + ${SOCCER_COVER.followers}M followers + Legacy +10`,
    coverDeclined: `\u{1F3AE} Declined the game cover: gained respect for being selective. Reputation +${SOCCER_COVER.declineStanding}`,
    money: (m) => `\u20AC${m}M`
  }
};

// src/lib/soccerCareerAttributes.ts
var HEIGHT_MIN = 155;
var HEIGHT_MAX = 210;
var WEIGHT_MIN = 50;
var WEIGHT_MAX = 110;
var SHAPE_MAX = 12;
var clampNum = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
var DEFAULT_PHYSIQUE = {
  GK: { heightCm: 190, weightKg: 84 },
  CB: { heightCm: 187, weightKg: 82 },
  LB: { heightCm: 178, weightKg: 73 },
  RB: { heightCm: 178, weightKg: 73 },
  CDM: { heightCm: 183, weightKg: 78 },
  CM: { heightCm: 180, weightKg: 75 },
  CAM: { heightCm: 176, weightKg: 71 },
  LW: { heightCm: 175, weightKg: 70 },
  RW: { heightCm: 175, weightKg: 70 },
  ST: { heightCm: 183, weightKg: 78 }
};
function defaultPhysique(position) {
  const d = DEFAULT_PHYSIQUE[position] || { heightCm: 180, weightKg: 76 };
  return { ...d };
}
function safePhysique(position, p) {
  const d = defaultPhysique(position);
  const h = Number(p?.heightCm);
  const w = Number(p?.weightKg);
  return {
    heightCm: Number.isFinite(h) ? Math.round(clampNum(h, HEIGHT_MIN, HEIGHT_MAX)) : d.heightCm,
    weightKg: Number.isFinite(w) ? Math.round(clampNum(w, WEIGHT_MIN, WEIGHT_MAX)) : d.weightKg
  };
}
var OUTFIELD_TREE = [
  {
    key: "pace",
    label: "Pace",
    children: [
      { id: "acceleration", label: "Acceleration", perCm: -0.2, perKg: -0.34, does: "The first three yards. Getting away from a defender who is already touching you" },
      { id: "sprint_speed", label: "Sprint Speed", perCm: 0.1, perKg: -0.18, does: "Top end over forty yards, once you are already moving" }
    ]
  },
  {
    key: "shooting",
    label: "Shooting",
    children: [
      { id: "finishing", label: "Finishing", does: "One touch inside the box, the chances that decide seasons" },
      { id: "shot_power", label: "Shot Power", perKg: 0.14, perCm: 0.06, does: "How hard you hit it, and whether a keeper can hold it" },
      { id: "long_shots", label: "Long Shots", does: "Anything from outside the area" },
      { id: "heading", label: "Heading", perCm: 0.36, perKg: 0.12, does: "Attacking headers from crosses and set pieces" },
      { id: "penalties", label: "Penalties", does: "From twelve yards, and in a shootout" }
    ]
  },
  {
    key: "passing",
    label: "Passing",
    children: [
      { id: "vision", label: "Vision", does: "Seeing the pass nobody else in the stadium saw" },
      { id: "short_pass", label: "Short Passing", does: "Keeping the ball under pressure in tight areas" },
      { id: "crossing", label: "Crossing", does: "Delivery from wide, both feet, both heights" },
      { id: "long_pass", label: "Long Passing", does: "Switching play, and the ball over the top" },
      { id: "free_kicks", label: "Free Kicks", does: "Dead ball delivery and the ones you shoot yourself" }
    ]
  },
  {
    key: "dribbling",
    label: "Dribbling",
    children: [
      { id: "ball_control", label: "Ball Control", perCm: -0.06, does: "First touch, and whether the ball sticks when it arrives fast" },
      { id: "agility", label: "Agility", perCm: -0.3, perKg: -0.22, does: "Turning, changing direction, getting out of a crowd" },
      { id: "balance", label: "Balance", perCm: -0.12, perKg: 0.16, does: "Staying on your feet when somebody leans on you" },
      { id: "flair", label: "Flair", does: "The trick nobody asked for that comes off anyway" }
    ]
  },
  {
    key: "defending",
    label: "Defending",
    children: [
      { id: "marking", label: "Marking", perCm: 0.1, does: "Staying with a man for ninety minutes" },
      { id: "tackling", label: "Tackling", perKg: 0.1, does: "Winning the ball cleanly, standing up and going to ground" },
      { id: "interceptions", label: "Interceptions", perCm: 0.08, does: "Reading the pass before it is played and stepping in front" },
      { id: "reading", label: "Reading The Game", does: "Where to be before anything happens" }
    ]
  },
  {
    key: "physical",
    label: "Physical",
    children: [
      { id: "strength", label: "Strength", perCm: 0.16, perKg: 0.46, does: "Holding the ball up and winning the shoulder to shoulder stuff" },
      { id: "stamina", label: "Stamina", perKg: -0.22, does: "Still running in the ninetieth minute, and playing every week" },
      { id: "aggression", label: "Aggression", perKg: 0.1, does: "How hard you go into a challenge you might not win" },
      { id: "jumping", label: "Jumping", perCm: 0.26, perKg: -0.1, does: "How high you get off the floor, which is not the same as being tall" }
    ]
  }
];
var GK_TREE = [
  {
    key: "reflexes",
    label: "Reflexes",
    children: [
      { id: "gk_reflex", label: "Shot Reflexes", perCm: -0.1, does: "The save nobody had time to think about" },
      { id: "gk_recovery", label: "Recovery Saves", perCm: -0.12, does: "Getting back up and stopping the rebound" }
    ]
  },
  {
    key: "shooting",
    label: "Shot Stopping",
    children: [
      { id: "gk_one_v_one", label: "One On Ones", perCm: 0.1, does: "A striker through on goal with only you to beat" },
      { id: "gk_long_range", label: "Long Range", does: "Everything struck from outside the box" }
    ]
  },
  {
    key: "defending",
    label: "Positioning",
    children: [
      { id: "gk_angles", label: "Angles", perCm: 0.16, does: "Making the goal look small before the shot is hit" },
      { id: "gk_reading", label: "Reading The Game", does: "Knowing where the ball is going before it goes there" }
    ]
  },
  {
    key: "physical",
    label: "Aerial Command",
    children: [
      { id: "gk_crosses", label: "Claiming Crosses", perCm: 0.3, perKg: 0.1, does: "Coming and taking it in a crowded six yard box" },
      { id: "gk_punching", label: "Punching", perKg: 0.2, does: "Clearing the danger when catching it is not on" }
    ]
  },
  {
    key: "passing",
    label: "Distribution",
    children: [
      { id: "gk_throwing", label: "Throwing", perKg: 0.16, does: "Starting a counter attack with your hands" },
      { id: "gk_kicking", label: "Kicking", does: "Playing out from the back and finding a man long" }
    ]
  },
  {
    key: "dribbling",
    label: "Penalty Saving",
    children: [
      { id: "gk_pen_read", label: "Reading The Penalty", does: "Picking the corner before he strikes it" },
      { id: "gk_nerve", label: "Shootout Nerve", does: "The fifth kick of a shootout, in front of their end" }
    ]
  },
  {
    key: "pace",
    label: "Sweeping Speed",
    children: [
      { id: "gk_rush", label: "Rushing Out", perKg: -0.24, does: "Beating a striker to a through ball outside your area" },
      { id: "gk_recovery_pace", label: "Recovery Pace", perCm: -0.12, perKg: -0.28, does: "Getting back when the ball goes over your head" }
    ]
  }
];
function attrTreeFor(position) {
  return position === "GK" ? GK_TREE : OUTFIELD_TREE;
}
var ALL_ATTR_IDS = [
  ...OUTFIELD_TREE.flatMap((f) => f.children.map((c) => c.id)),
  ...GK_TREE.flatMap((f) => f.children.map((c) => c.id))
];
function safeShape(position, raw) {
  const out = {};
  if (!raw || typeof raw !== "object") return out;
  for (const fam of attrTreeFor(position)) {
    const vals = [];
    for (const c of fam.children) {
      const v = Number(raw[c.id]);
      vals.push(Number.isFinite(v) ? Math.round(clampNum(v, -SHAPE_MAX, SHAPE_MAX)) : 0);
    }
    const sum = vals.reduce((a, b) => a + b, 0);
    if (sum !== 0) continue;
    fam.children.forEach((c, i) => {
      if (vals[i] !== 0) out[c.id] = vals[i];
    });
  }
  return out;
}

// src/lib/soccerCareerRealismB.ts
init_soccerInternational();

// src/lib/soccerCareerAcademy.ts
var ACADEMY_FOCUS_BONUS = 2;
var ACADEMY_FOCUS_NEAR = 3;
function academyFocusOptions(position) {
  return attrTreeFor(position).map((f) => ({ key: f.key, label: f.label }));
}
function academyFocusOf(s) {
  const f = s.academyFocus;
  if (typeof f !== "string") return null;
  return academyFocusOptions(s.position).some((o) => o.key === f) ? f : null;
}
function academyFocusBonus(overall, potential) {
  if (!(overall < potential)) return 0;
  if (overall >= potential - ACADEMY_FOCUS_NEAR) return 1;
  return ACADEMY_FOCUS_BONUS;
}
function applyAcademyFocus(s, potential) {
  const focus = academyFocusOf(s);
  if (!focus) return 0;
  const before = s[focus];
  s[focus] = Math.min(99, before + academyFocusBonus(s.overall, potential));
  s.academyFocusAdded = s[focus] - before;
  return s.academyFocusAdded;
}
var ACADEMY_FOCUS_RULE = `+${ACADEMY_FOCUS_BONUS} to that skill on top of the year's normal growth. If the year takes you close to your ceiling it adds +1, and nothing once you reach it.`;

// src/lib/season/momentsSave.ts
var LEDGER_MAX = 12;
var ENTRY_MIN = 3;
var ENTRY_MAX = 8;
var KEY_MAX = 200;
var MD_MAX = 400;
var YEAR_MAX = 9999;
var PAID_MAX = 2;
var TALLY_MAX = { seasons: 200, moments: 2400, stars: 7200 };
var isInt = (v, lo, hi) => typeof v === "number" && Number.isInteger(v) && v >= lo && v <= hi;
function readSeasonMoments(raw) {
  try {
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) return null;
    const r = raw;
    if (r.v !== 1) return null;
    if (typeof r.key !== "string" || r.key.length === 0 || r.key.length > KEY_MAX) return null;
    if (!Array.isArray(r.m) || r.m.length > LEDGER_MAX) return null;
    const m = [];
    for (const e of r.m) {
      if (!Array.isArray(e) || e.length < ENTRY_MIN || e.length > ENTRY_MAX) return null;
      if (!e.every((x) => typeof x === "number" && Number.isFinite(x))) return null;
      if (!isInt(e[0], 1, MD_MAX) || !isInt(e[1], 0, LEDGER_MAX - 1) || !isInt(e[2], -1, 3)) return null;
      if (m.some((x) => x[0] === e[0] && x[1] === e[1])) continue;
      m.push(e.slice());
    }
    const out = { v: 1, key: r.key, m };
    if (r.banked !== void 0) {
      if (r.banked !== 1) return null;
      out.banked = 1;
    }
    if (r.paid !== void 0) {
      const p = r.paid;
      if (out.banked !== 1 || !Array.isArray(p) || p.length !== 2 || !isInt(p[0], 0, YEAR_MAX) || !isInt(p[1], 1, PAID_MAX)) return null;
      out.paid = [p[0], p[1]];
    }
    if (r.tally !== void 0) {
      const t = r.tally;
      if (!t || typeof t !== "object" || Array.isArray(t)) return null;
      if (!isInt(t.seasons, 0, TALLY_MAX.seasons) || !isInt(t.moments, 0, TALLY_MAX.moments) || !isInt(t.stars, 0, TALLY_MAX.stars)) return null;
      out.tally = { seasons: t.seasons, moments: t.moments, stars: t.stars };
    }
    return out;
  } catch {
    return null;
  }
}

// src/lib/soccerCareerEngine.ts
init_soccerInternational();
init_soccerInternational();
var SOCCER_INBOX = {
  pool: PHONE_POOL,
  moodOf: (s) => s.karma ?? 50,
  setMood: (s, v) => {
    s.karma = v;
  },
  addPopularity: (s, delta) => {
    s.popularity = clamp5(s.popularity + delta, 0, 100);
  },
  addCash: (s, amount) => {
    s.netWorth = Math.round((s.netWorth + amount) * 100) / 100;
  },
  ageOf: (s) => s.age,
  yearOf: (s) => s.seasons[s.seasons.length - 1]?.year ?? 2020,
  maxInbox: 6,
  wantPerSeason: 2
};
function receivePhoneTexts(s, phase) {
  const fresh = receiveInboxTexts(s, phase, SOCCER_INBOX);
  for (const m of fresh) mirrorLegacyMessage(s, m.id, m.from, m.text, m.year);
  phoneSeasonTick(s, phase);
}
var SOCCER_RIVALRY_CHOICES = [
  {
    id: "rival_club_offer",
    emoji: "\u{1F4DE}",
    title: "THE ENEMY CALLS",
    description: "Your great rival's club triggers your release clause. Their sporting director says one sentence: come win everything next to him instead of against him. Your fans are already burning shirts preemptively.",
    when: (s) => s.age >= 24,
    choices: [
      {
        label: "Join forces with your rival",
        emoji: "\u{1F91D}",
        consequence: "The most talked-about transfer of the decade. Signing bonus 10M, old fans furious",
        apply: (s, r) => {
          s.netWorth = Math.round((s.netWorth + 10) * 100) / 100;
          s.popularity = clamp5(s.popularity - 10, 0, 100);
          s.morale = clamp5(s.morale + 5, 0, 100);
          s.rivalryIntensity = clamp5((s.rivalryIntensity ?? 0) - 30, 0, 100);
          return `\u{1F4DE} You answered the enemy's call. 10M signing bonus banked, and the football world lost its mind. Old fans are furious, ${r?.name ?? "your rival"} posted a handshake emoji.`;
        }
      },
      {
        label: "Leak the offer and refuse",
        emoji: "\u{1F4F0}",
        consequence: "Your fans crown you a legend of loyalty. Popularity +12, integrity +5",
        apply: (s) => {
          s.popularity = clamp5(s.popularity + 12, 0, 100);
          s.integrityBonus += 5;
          s.rivalryIntensity = clamp5((s.rivalryIntensity ?? 0) + 10, 0, 100);
          return "\u{1F4F0} The leaked offer made the front page. Your fans crowned you a legend of loyalty. Popularity +12.";
        }
      },
      {
        label: "Refuse quietly",
        emoji: "\u{1F910}",
        consequence: "Nobody ever knows how close it came",
        apply: () => "\u{1F910} You refused quietly. Somewhere in a drawer sits the most explosive transfer that never happened."
      }
    ]
  },
  {
    id: "rival_bad_tackle",
    emoji: "\u{1F9B5}",
    title: "THE TACKLE",
    description: "Your rival went through your ankle in the derby, studs up, no ball. The referee gave a yellow. Your physio says you are fine. Your teammates want blood. The rematch is in May.",
    when: () => true,
    choices: [
      {
        label: "Plot revenge for the rematch",
        emoji: "\u{1F608}",
        consequence: "The feud goes nuclear",
        risk: "30% chance you see red doing it: popularity and morale -5",
        apply: (s, r, rng) => {
          s.rivalryIntensity = clamp5((s.rivalryIntensity ?? 0) + 25, 0, 100);
          if (rng() < 0.3) {
            s.popularity = clamp5(s.popularity - 5, 0, 100);
            s.morale = clamp5(s.morale - 5, 0, 100);
            return `\u{1F7E5} Revenge tasted sweet for four seconds, then the red card came out. Popularity and morale -5, and ${r?.name ?? "your rival"} smiled the whole time.`;
          }
          s.morale = clamp5(s.morale + 8, 0, 100);
          return `\u{1F608} You got him back, clean enough to escape a card. The derby now has its own documentary crew.`;
        }
      },
      {
        label: "Accept his apology publicly",
        emoji: "\u{1F54A}\uFE0F",
        consequence: "Integrity +8, popularity +5, the feud cools",
        apply: (s) => {
          s.integrityBonus += 8;
          s.popularity = clamp5(s.popularity + 5, 0, 100);
          s.rivalryIntensity = clamp5((s.rivalryIntensity ?? 0) - 15, 0, 100);
          return "\u{1F54A}\uFE0F You accepted the apology on camera. The adults in the room won today. Integrity +8.";
        }
      },
      {
        label: "Say nothing. Score twice in May.",
        emoji: "\u{1F976}",
        consequence: "+1 Shooting next season, ice in the veins",
        apply: (s) => {
          s.statBoostNextSeason = { ...s.statBoostNextSeason, shooting: (s.statBoostNextSeason.shooting || 0) + 1 };
          s.rivalryIntensity = clamp5((s.rivalryIntensity ?? 0) + 10, 0, 100);
          return "\u{1F976} You said nothing. May is circled on your calendar in red ink. +1 Shooting next season.";
        }
      }
    ]
  },
  {
    id: "goat_debate_show",
    emoji: "\u{1F3A4}",
    title: "THE DEBATE SHOW",
    description: "A global sports network offers 2M for one live hour: you versus a panel of pundits arguing that your rival is better. No script, no edits, one microphone.",
    when: (s) => s.overall >= 85,
    choices: [
      {
        label: "Go on and cook them",
        emoji: "\u{1F525}",
        consequence: "2M fee",
        risk: "35% chance a clip goes viral badly: popularity -8",
        apply: (s, _r, rng) => {
          s.netWorth = Math.round((s.netWorth + 2) * 100) / 100;
          if (rng() < 0.35) {
            s.popularity = clamp5(s.popularity - 8, 0, 100);
            return "\u{1F3A4} You went on the debate show and one heated clip went viral for the wrong reasons. 2M banked, popularity -8.";
          }
          s.popularity = clamp5(s.popularity + 6, 0, 100);
          return "\u{1F525} You cooked the whole panel live on air. 2M banked and the clip is a permanent argument-ender. Popularity +6.";
        }
      },
      {
        label: "Send a highlight reel instead",
        emoji: "\u{1F4FC}",
        consequence: "The reel does the talking. Popularity +8",
        apply: (s) => {
          s.popularity = clamp5(s.popularity + 8, 0, 100);
          return "\u{1F4FC} You sent a four-minute highlight reel with no caption. It out-rated the show. Popularity +8.";
        }
      },
      {
        label: "Decline. Legends do not debate.",
        emoji: "\u{1F60E}",
        consequence: "Integrity +5, the mystique grows",
        apply: (s) => {
          s.integrityBonus += 5;
          return "\u{1F60E} You declined. Legends do not debate. The mystique compounds like interest.";
        }
      }
    ]
  },
  {
    id: "rival_charity_match",
    emoji: "\u{1F49B}",
    title: "TRUCE FOR ONE NIGHT",
    description: "Your rival's foundation asks you to co-headline a charity match for children's hospitals. Same pitch, same team, one night only. The photo of you two in the same shirt would break the internet.",
    when: () => true,
    choices: [
      {
        label: "Play, and split the donation",
        emoji: "\u{1F91D}",
        consequence: "1M donated, popularity +10, integrity +8, the feud softens",
        apply: (s, r) => {
          s.netWorth = Math.round((s.netWorth - 1) * 100) / 100;
          s.popularity = clamp5(s.popularity + 10, 0, 100);
          s.integrityBonus += 8;
          s.rivalryIntensity = clamp5((s.rivalryIntensity ?? 0) - 20, 0, 100);
          return `\u{1F49B} One night, one shirt, one cause. You and ${r?.name ?? "your rival"} raised millions for children's hospitals. The feud took the night off.`;
        }
      },
      {
        label: "Play, but start a playful nutmeg war",
        emoji: "\u{1F609}",
        consequence: "The clips are legendary. Popularity +12",
        apply: (s, r) => {
          s.popularity = clamp5(s.popularity + 12, 0, 100);
          return `\u{1F609} The charity match turned into a nutmeg war with ${r?.name ?? "your rival"}. The kids loved it, the internet melted. Popularity +12.`;
        }
      },
      {
        label: "Send a check, skip the match",
        emoji: "\u{1F4B8}",
        consequence: "1M donated quietly, integrity +3",
        apply: (s) => {
          s.netWorth = Math.round((s.netWorth - 1) * 100) / 100;
          s.integrityBonus += 3;
          return "\u{1F4B8} You sent the donation and skipped the cameras. The quiet kind of good. Integrity +3.";
        }
      }
    ]
  }
];
function rivalChoiceDilemma(id) {
  const d = SOCCER_RIVALRY_CHOICES.find((c) => c.id === id);
  return {
    id: d.id,
    emoji: d.emoji,
    title: d.title,
    description: typeof d.description === "string" ? d.description : "",
    choices: d.choices.map((c) => c.risk === void 0 ? { label: c.label, emoji: c.emoji, consequence: c.consequence } : { label: c.label, emoji: c.emoji, consequence: c.consequence, risk: c.risk })
  };
}
var MORAL_DILEMMAS = [
  {
    id: "match_fixing",
    emoji: "\u{1F3B0}",
    title: "MATCH FIXING",
    description: "A mysterious figure approaches you before a big match. He offers \u20AC5M to intentionally perform poorly. The money would be untraceable. No one would ever know... probably.",
    choices: [
      { label: "Accept the money", emoji: "\u{1F4B0}", consequence: "\u20AC5M added to your accounts", risk: "30% chance you are caught: banned for a season and the 5M taken back" },
      { label: "Refuse and report it", emoji: "\u{1F6E1}\uFE0F", consequence: "Reputation +20, Legacy +10, Fair Play Award" },
      { label: "Refuse silently", emoji: "\u{1F910}", consequence: "Walk away. Nothing happens." }
    ]
  },
  {
    id: "ped_offer",
    emoji: "\u{1F489}",
    title: "PERFORMANCE ENHANCING DRUGS",
    description: `A private trainer you met over the summer, nobody from your club, gets you alone after a session. He offers you an 'undetectable' substance that will boost all your stats by +5 for 3 seasons. "Nobody ever has to know," he whispers.`,
    choices: [
      { label: "Take the substance", emoji: "\u{1F48A}", consequence: "All stats +5 for 3 seasons", risk: "20% chance of a failed test each season: banned for a season" },
      { label: "Refuse", emoji: "\u270B", consequence: "Morale -5, but integrity +10 legacy bonus at retirement" }
    ]
  },
  {
    id: "diving_reputation",
    emoji: "\u{1F93F}",
    title: "DIVING REPUTATION",
    description: "You've developed a reputation for simulation. Journalists are running front-page stories about your theatrical falls in the box. Pundits are calling you 'the greatest actor in football.'",
    choices: [
      { label: "Embrace the dark arts", emoji: "\u{1F3AD}", consequence: "+2 goals per season from penalties, but reputation -15" },
      { label: "Clean up your game", emoji: "\u{1F91D}", consequence: "Reputation +10, integrity +5" },
      { label: "Ignore the noise", emoji: "\u{1F507}", consequence: "No change, let them talk" }
    ]
  },
  {
    id: "agent_corruption",
    emoji: "\u{1F574}\uFE0F",
    title: "AGENT CORRUPTION",
    description: "Your accountant finds your agent has been skimming double the agreed commission for the last 3 years. That is real money stolen from you, and your agent is sitting in your living room, sweating.",
    choices: [
      { label: "Fire your agent and sue", emoji: "\u2696\uFE0F", consequence: "Legal costs \u20AC500k, the stolen money back (up to \u20AC3M), and you negotiate your own deals from now on" },
      { label: "Keep your agent: the results are real", emoji: "\u{1F91D}", consequence: "Swallow the loss, morale -5" },
      { label: "Make them pay some of it back", emoji: "\u{1F4DD}", consequence: "Your agent stays, about a third of the money comes back" }
    ]
  },
  {
    id: "pitch_invader",
    emoji: "\u{1F3C3}",
    title: "PITCH INVADER",
    description: "Mid-match, a fan hops the barrier and sprints straight at you, phone out, screaming your name. Stewards are way behind. He's five yards away and closing.",
    choices: [
      { label: "Pose for the selfie", emoji: "\u{1F933}", consequence: "Popularity +10, but you concede possession and the crowd loves it" },
      { label: "Juke him like a defender", emoji: "\u{1F57A}", consequence: "Viral clip! Popularity +15, morale +5" },
      { label: "Push him away hard", emoji: "\u270B", consequence: "Crowd boos, popularity -10, but stewards praise your composure" }
    ]
  },
  {
    id: "match_fixer_approach",
    emoji: "\u{1F3AD}",
    title: "THE HOTEL BAR",
    description: 'A smooth operator finds you at a hotel bar the night before a meaningless end-of-season game. "Nobody cares about this one. Just miss a penalty if you get one. \u20AC2M, cash, tonight."',
    choices: [
      { label: "Take the deal", emoji: "\u{1F4B5}", consequence: "\u20AC2M added instantly", risk: "25% chance a recording leaks: banned for a season and the 2M taken back" },
      { label: "Film him and expose it", emoji: "\u{1F3A5}", consequence: "Hero status! Popularity +25, Fair Play recognition" },
      { label: "Politely decline, tell no one", emoji: "\u{1F6AA}", consequence: "Walk away clean. Nothing happens." }
    ]
  },
  {
    id: "captain_armband_feud",
    emoji: "\xA9\uFE0F",
    title: "THE ARMBAND WAR",
    description: "The manager is stripping the captaincy from a veteran teammate and offering it to you. The dressing room is split. The veteran hasn't spoken to you in three days.",
    choices: [
      { label: "Accept the armband", emoji: "\u{1F396}\uFE0F", consequence: "Popularity +10 with fans, morale -8 with a chunk of the squad" },
      { label: "Refuse out of respect", emoji: "\u{1F64F}", consequence: "Dressing room loyalty +, missed leadership bonus" },
      { label: "Broker peace between camps", emoji: "\u{1F54A}\uFE0F", consequence: "Morale +10 long term, no armband this season" }
    ]
  },
  {
    id: "tunnel_brawl",
    emoji: "\u{1F94A}",
    title: "TUNNEL INCIDENT",
    description: "After a brutal loss, an opposition player shoves you in the tunnel and says something about your family. Cameras are everywhere. Your teammates are already grabbing your shirt to hold you back.",
    choices: [
      { label: "Swing back", emoji: "\u{1F44A}", consequence: "Fined two weeks' wages, popularity -10 (your ultras loved it, nobody else did)" },
      { label: "Walk away, report it", emoji: "\u{1F6B6}", consequence: "Federation fines the other player, your reputation +15" },
      { label: "Trash talk, no contact", emoji: "\u{1F5E3}\uFE0F", consequence: "Fined a week's wages, the clip goes viral either way" }
    ]
  },
  {
    id: "sponsor_scandal",
    emoji: "\u{1F4F8}",
    title: "SPONSOR MELTDOWN",
    description: "Your energy drink sponsor just got exposed in a tax fraud scandal. Journalists are calling your phone nonstop asking if you'll cut ties with a \u20AC3M-a-year deal.",
    choices: [
      { label: "Cut ties publicly", emoji: "\u2702\uFE0F", consequence: "Lose \u20AC3M/year income, popularity +15" },
      { label: "Stay quiet, keep the money", emoji: "\u{1F910}", consequence: "Keep the deal, popularity -10 as backlash builds" },
      { label: "Donate the year's fee to charity", emoji: "\u2764\uFE0F", consequence: "Keep the deal, popularity +20, net worth unchanged this year" }
    ]
  },
  {
    id: "betting_ring_teammate",
    emoji: "\u{1F3B2}",
    title: "AN OLD FRIEND IN TROUBLE",
    description: "Your best mate from the academy, now playing a division below, confesses he owes a betting syndicate a huge sum and they've started asking him about your injury news. He's begging you not to tell anyone.",
    choices: [
      { label: "Report it to the federation", emoji: "\u{1F4E2}", consequence: "He gets suspended, integrity +15, morale -5 (you lost a friend)" },
      { label: "Lend him the money quietly", emoji: "\u{1F4B6}", consequence: "Net worth -1.5M, loyalty earned, risk buried" },
      { label: "Tell him to fix it himself", emoji: "\u{1F937}", consequence: "Nothing happens. You hope it stays that way" }
    ]
  },
  {
    id: "wonderkid_jealousy",
    emoji: "\u{1F31F}",
    title: "THE NEW WONDERKID",
    description: "The club just paid a fortune for a hyped 18-year-old who plays your exact position. The manager is clearly grooming him to replace you. He's also incredibly likeable, which makes it worse.",
    choices: [
      { label: "Mentor him openly", emoji: "\u{1F91D}", consequence: "Popularity +15, and the kid never forgets it" },
      { label: "Freeze him out", emoji: "\u{1F9CA}", consequence: "Morale -10, the dressing room turns cold on you" },
      { label: "Focus on yourself, ignore it", emoji: "\u{1F3AF}", consequence: "No change, business as usual" }
    ]
  },
  {
    id: "night_out_photo",
    emoji: "\u{1F37E}",
    title: "THE NIGHT OUT PHOTO",
    description: "A photo leaks of you out until 4am, three days before a huge cup final. It is blowing up online. Training is in six hours and the manager wants to see you immediately.",
    choices: [
      { label: "Own it, apologize publicly", emoji: "\u{1F647}", consequence: "Popularity +5 for honesty, morale -5, fined one week's wages" },
      { label: "Deny everything", emoji: "\u{1F645}", consequence: "Story drags on", risk: "35% chance it resurfaces: popularity -15" },
      { label: "Let your agent spin it", emoji: "\u{1F399}\uFE0F", consequence: "Story dies down fast, small net worth cost for the PR team" }
    ]
  },
  // 2026-08-05 storyline expansion (owner request: mafia arc, magazine offer, pitch chaos, more)
  {
    id: "magazine_shoot",
    emoji: "\u{1F4F8}",
    title: "THE MAGAZINE CALL",
    description: "A famous magazine wants you on the cover. The tasteful version pays well. The bold version, shirt off with a football under your arm, pays absurdly. Your agent is already laughing.",
    choices: [
      { label: "Tasteful calendar shoot", emoji: "\u{1F60E}", consequence: "2M fee, popularity +10" },
      { label: "The full artistic cover", emoji: "\u{1F648}", consequence: "6M fee, popularity +18", risk: "25% chance a sponsor drops you for 2M" },
      { label: "Decline politely", emoji: "\u{1F6AA}", consequence: "Nothing happens. Your grandmother approves." }
    ]
  },
  {
    id: "mafia_cup_ask",
    emoji: "\u{1F574}\uFE0F",
    title: "AN OFFER FROM SERIOUS PEOPLE",
    description: "Two men in beautiful suits find you at a family restaurant. They know your order. They want next month's cup tie thrown. 8M, offshore, untouchable. A small favor between friends, they say.",
    choices: [
      { label: "Take the money", emoji: "\u{1F4B0}", consequence: "8M offshore, morale -5. They now consider you a friend.", risk: "They ALWAYS come back" },
      { label: "Refuse and go to the police", emoji: "\u{1F694}", consequence: "Federation protection, popularity +20, integrity +15" },
      { label: "Refuse, say nothing", emoji: "\u{1F910}", consequence: "They nod and leave. You sleep badly for a week." }
    ]
  },
  {
    id: "mafia_second_ask",
    emoji: "\u{1F3A9}",
    title: "THE FRIENDS RETURN",
    description: "Same restaurant. Same suits. This time it is the title decider they want, and the number is 15M. The smile is thinner now. Friends help friends twice, they say.",
    choices: [
      { label: "Do it one last time", emoji: "\u{1F4B6}", consequence: "15M offshore", risk: "50% chance the investigation lands: banned for two seasons, legacy shattered" },
      { label: "Refuse them", emoji: "\u270B", consequence: "Morale -10, and they mention the first favor on the way out", risk: "40% chance the first fix leaks: banned for a season" },
      { label: "Go to the police, full confession", emoji: "\u{1F694}", consequence: "Immunity for testimony, popularity +25, integrity +10, the arc ends" }
    ]
  },
  {
    id: "streaker_proposal",
    emoji: "\u{1F48D}",
    title: "PITCH SIDE PROPOSAL",
    description: "A fan in a full wedding dress clears the hoardings, drops to one knee in the center circle, and holds up a ring the size of a grape. The stadium is HOWLING. The referee has given up.",
    choices: [
      { label: "Say yes as a joke", emoji: "\u{1F48D}", consequence: "The clip breaks the internet. Popularity +15" },
      { label: "Sign her sign, keep it moving", emoji: "\u{1F58A}\uFE0F", consequence: "Wholesome moment, popularity +8" },
      { label: "Play on, total professional", emoji: "\u26BD", consequence: "Pundits praise the focus, morale +3" }
    ]
  },
  {
    id: "deepfake_scandal",
    emoji: "\u{1F916}",
    title: "THE DEEPFAKE",
    description: "An AI video of you insulting your own fans is everywhere. It is fake, it is convincing, and your mentions are a war zone. The club wants a response within the hour.",
    choices: [
      { label: "Sue everyone involved", emoji: "\u2696\uFE0F", consequence: "1M legal costs, vindicated in court, popularity +15" },
      { label: "Post a parody of the parody", emoji: "\u{1F3AD}", consequence: "Popularity +20 if it lands", risk: "20% chance it reads wrong and costs 10 popularity" },
      { label: "Ignore it entirely", emoji: "\u{1F9D8}", consequence: "It burns out in a week. Small morale dip." }
    ]
  },
  {
    id: "hometown_statue",
    emoji: "\u{1F5FF}",
    title: "THE STATUE PROBLEM",
    description: "Your hometown commissioned a statue of you. The unveiling photos leak early. It looks like a melted action figure of someone else entirely. The sculptor is very proud.",
    choices: [
      { label: "Quietly fund a redo", emoji: "\u{1F4B6}", consequence: "2M cost, the new one is beautiful, popularity +12" },
      { label: "Embrace the meme statue", emoji: "\u{1F5FF}", consequence: "It becomes a pilgrimage site. Popularity +18" },
      { label: "Ask them to take it down", emoji: "\u{1F645}", consequence: "The town is hurt. Popularity -5" }
    ]
  },
  {
    id: "haunted_hotel",
    emoji: "\u{1F47B}",
    title: "THE HAUNTED HOTEL",
    description: "Night before the biggest match of the season, half the squad swears the team hotel is haunted. Two defenders are refusing to sleep alone. The manager is furious. Somebody has to lead here.",
    choices: [
      { label: "Lead a squad seance", emoji: "\u{1F56F}\uFE0F", consequence: "Team bonding of the strangest kind. Morale +8" },
      { label: "Demand a hotel change", emoji: "\u{1F3E8}", consequence: "Awkward with the club, but everyone sleeps. Morale +3" },
      { label: "Sleep in the team bus", emoji: "\u{1F68C}", consequence: "The photo goes viral. Popularity +10" }
    ]
  },
  {
    id: "valet_crash",
    emoji: "\u{1F511}",
    title: "THE VALET INCIDENT",
    description: "A hotel valet just reversed your hypercar into a fountain at 40 km/h. He is 19, shaking, and pretty sure his life is over. Forty phones are already filming.",
    choices: [
      { label: "Hug him, forgive publicly", emoji: "\u{1F917}", consequence: "The clip melts hearts. Popularity +12, the car costs 1.5M" },
      { label: "Insurance war", emoji: "\u{1F4CB}", consequence: "Insurance covers the 1.5M, popularity -8, he loses his job" },
      { label: "Gift him a bus pass and a smile", emoji: "\u{1F68C}", consequence: "Perfect comedy. Popularity +15, the car still costs 1.5M" }
    ]
  },
  {
    id: "wag_reality_show",
    emoji: "\u{1F4FA}",
    title: "THE REALITY SHOW",
    description: "A production company offers serious money to film a reality series inside your house. Your partner is excited. Your center back already texted: do NOT do this.",
    choices: [
      { label: "Full season, full access", emoji: "\u{1F3AC}", consequence: "3M fee, popularity +8", risk: "25% chance a dressing-room secret airs: morale -10" },
      { label: "One tasteful episode", emoji: "\u{1F39E}\uFE0F", consequence: "1M fee, everyone survives" },
      { label: "Hard no", emoji: "\u{1F6AA}", consequence: "Partner sulks for a week, morale +4 long term" }
    ]
  },
  {
    id: "ultras_tattoo",
    emoji: "\u{1F409}",
    title: "THE ULTRAS' DEMAND",
    description: "After your late winner, the ultras unfurl a banner: TATTOO THE CREST OR YOU NEVER LOVED US. They are outside training with a tattoo artist. He seems extremely available.",
    choices: [
      { label: "Get the crest tattooed", emoji: "\u{1F409}", consequence: "Popularity +15 here forever. Awkward if you ever transfer" },
      { label: "Henna prank first", emoji: "\u{1F58C}\uFE0F", consequence: "Popularity +8 for the joke", risk: "30% chance they find out it washed off: -10" },
      { label: "Respectfully decline", emoji: "\u{1F64F}", consequence: "Popularity -5, your skin remains yours" }
    ]
  },
  {
    id: "bdor_snub",
    emoji: "\u{1F948}",
    title: "THE SNUB",
    description: "Everyone in your camp thought this was your Ballon d'Or. It went to someone else. The cameras cut to your face at the exact wrong moment and the whole world saw it.",
    choices: [
      { label: "Fuel. Pure fuel.", emoji: "\u{1F525}", consequence: "+3 to every stat next season, morale -5. Revenge tour begins" },
      { label: "Congratulate the winner beautifully", emoji: "\u{1F91D}", consequence: "Popularity +10, integrity +5, the high road" },
      { label: "Skip the afterparty, train at midnight", emoji: "\u{1F319}", consequence: "The gym photo goes viral. +2 stats next season, popularity +5" }
    ]
  },
  {
    id: "biscuit_gate",
    emoji: "\u{1F36A}",
    title: "BISCUIT GATE",
    description: "You were photographed enjoying a rival brand's biscuit while your cereal sponsor pays you millions. The internet has named it Biscuit Gate. The sponsor's lawyers have named it a breach.",
    choices: [
      { label: "Apologize with a taste test video", emoji: "\u{1F3A5}", consequence: "Sponsor placated, the video hits huge, popularity +10" },
      { label: "Declare biscuit independence", emoji: "\u{1F36A}", consequence: "Lose 1M sponsor fee, popularity +15, folk hero status" },
      { label: "Blame a lookalike", emoji: "\u{1F978}", consequence: "Nobody believes you, popularity -5, it becomes a meme" }
    ]
  },
  // 2026-08-05 rivalry expansion: the feud gets interactive. Round 796: the
  // four live in SOCCER_RIVALRY_CHOICES above and are drawn from there, in
  // the same four places in this list.
  rivalChoiceDilemma("rival_club_offer"),
  rivalChoiceDilemma("rival_bad_tackle"),
  rivalChoiceDilemma("goat_debate_show"),
  rivalChoiceDilemma("rival_charity_match")
];
var FLAG_MAP = {
  "England": "\u{1F3F4}\u{E0067}\u{E0062}\u{E0065}\u{E006E}\u{E0067}\u{E007F}",
  "Spain": "\u{1F1EA}\u{1F1F8}",
  "France": "\u{1F1EB}\u{1F1F7}",
  "Germany": "\u{1F1E9}\u{1F1EA}",
  "Brazil": "\u{1F1E7}\u{1F1F7}",
  "Argentina": "\u{1F1E6}\u{1F1F7}",
  "Portugal": "\u{1F1F5}\u{1F1F9}",
  "Italy": "\u{1F1EE}\u{1F1F9}",
  "Netherlands": "\u{1F1F3}\u{1F1F1}",
  "USA": "\u{1F1FA}\u{1F1F8}",
  "Mexico": "\u{1F1F2}\u{1F1FD}",
  "Japan": "\u{1F1EF}\u{1F1F5}",
  "South Korea": "\u{1F1F0}\u{1F1F7}",
  "Nigeria": "\u{1F1F3}\u{1F1EC}",
  "Senegal": "\u{1F1F8}\u{1F1F3}",
  "Ghana": "\u{1F1EC}\u{1F1ED}",
  "Morocco": "\u{1F1F2}\u{1F1E6}",
  "Colombia": "\u{1F1E8}\u{1F1F4}",
  "Uruguay": "\u{1F1FA}\u{1F1FE}",
  "Belgium": "\u{1F1E7}\u{1F1EA}",
  "Croatia": "\u{1F1ED}\u{1F1F7}",
  "Denmark": "\u{1F1E9}\u{1F1F0}",
  "Sweden": "\u{1F1F8}\u{1F1EA}",
  "Norway": "\u{1F1F3}\u{1F1F4}",
  "Switzerland": "\u{1F1E8}\u{1F1ED}",
  "Austria": "\u{1F1E6}\u{1F1F9}",
  "Scotland": "\u{1F3F4}\u{E0067}\u{E0062}\u{E0073}\u{E0063}\u{E0074}\u{E007F}",
  "Wales": "\u{1F3F4}\u{E0067}\u{E0062}\u{E0077}\u{E006C}\u{E0073}\u{E007F}",
  "Ireland": "\u{1F1EE}\u{1F1EA}",
  "Poland": "\u{1F1F5}\u{1F1F1}",
  "Czech Republic": "\u{1F1E8}\u{1F1FF}",
  "Serbia": "\u{1F1F7}\u{1F1F8}",
  "Romania": "\u{1F1F7}\u{1F1F4}",
  "Greece": "\u{1F1EC}\u{1F1F7}",
  "Turkey": "\u{1F1F9}\u{1F1F7}",
  "Russia": "\u{1F1F7}\u{1F1FA}",
  "Ukraine": "\u{1F1FA}\u{1F1E6}",
  "Australia": "\u{1F1E6}\u{1F1FA}",
  "New Zealand": "\u{1F1F3}\u{1F1FF}",
  "Canada": "\u{1F1E8}\u{1F1E6}",
  "Jamaica": "\u{1F1EF}\u{1F1F2}",
  "Costa Rica": "\u{1F1E8}\u{1F1F7}",
  "Ecuador": "\u{1F1EA}\u{1F1E8}",
  "Peru": "\u{1F1F5}\u{1F1EA}",
  "Chile": "\u{1F1E8}\u{1F1F1}",
  "Cameroon": "\u{1F1E8}\u{1F1F2}",
  "Ivory Coast": "\u{1F1E8}\u{1F1EE}",
  "Egypt": "\u{1F1EA}\u{1F1EC}",
  "Algeria": "\u{1F1E9}\u{1F1FF}",
  "Tunisia": "\u{1F1F9}\u{1F1F3}",
  // Round 54 expansion: more flags, more nations, more everything
  "Saudi Arabia": "\u{1F1F8}\u{1F1E6}",
  "Qatar": "\u{1F1F6}\u{1F1E6}",
  "UAE": "\u{1F1E6}\u{1F1EA}",
  "Iran": "\u{1F1EE}\u{1F1F7}",
  "Iraq": "\u{1F1EE}\u{1F1F6}",
  "Israel": "\u{1F1EE}\u{1F1F1}",
  "China": "\u{1F1E8}\u{1F1F3}",
  "India": "\u{1F1EE}\u{1F1F3}",
  "Indonesia": "\u{1F1EE}\u{1F1E9}",
  "Thailand": "\u{1F1F9}\u{1F1ED}",
  "Vietnam": "\u{1F1FB}\u{1F1F3}",
  "Malaysia": "\u{1F1F2}\u{1F1FE}",
  "Philippines": "\u{1F1F5}\u{1F1ED}",
  "Singapore": "\u{1F1F8}\u{1F1EC}",
  "Uzbekistan": "\u{1F1FA}\u{1F1FF}",
  "Kazakhstan": "\u{1F1F0}\u{1F1FF}",
  "Georgia": "\u{1F1EC}\u{1F1EA}",
  "Armenia": "\u{1F1E6}\u{1F1F2}",
  "Azerbaijan": "\u{1F1E6}\u{1F1FF}",
  "South Africa": "\u{1F1FF}\u{1F1E6}",
  "Kenya": "\u{1F1F0}\u{1F1EA}",
  "Ethiopia": "\u{1F1EA}\u{1F1F9}",
  "Tanzania": "\u{1F1F9}\u{1F1FF}",
  "Angola": "\u{1F1E6}\u{1F1F4}",
  "Mozambique": "\u{1F1F2}\u{1F1FF}",
  "DR Congo": "\u{1F1E8}\u{1F1E9}",
  "Mali": "\u{1F1F2}\u{1F1F1}",
  "Burkina Faso": "\u{1F1E7}\u{1F1EB}",
  "Guinea": "\u{1F1EC}\u{1F1F3}",
  "Gabon": "\u{1F1EC}\u{1F1E6}",
  "Zambia": "\u{1F1FF}\u{1F1F2}",
  "Zimbabwe": "\u{1F1FF}\u{1F1FC}",
  "Venezuela": "\u{1F1FB}\u{1F1EA}",
  "Bolivia": "\u{1F1E7}\u{1F1F4}",
  "Paraguay": "\u{1F1F5}\u{1F1FE}",
  "Panama": "\u{1F1F5}\u{1F1E6}",
  "Honduras": "\u{1F1ED}\u{1F1F3}",
  "El Salvador": "\u{1F1F8}\u{1F1FB}",
  "Guatemala": "\u{1F1EC}\u{1F1F9}",
  "Haiti": "\u{1F1ED}\u{1F1F9}",
  "Trinidad and Tobago": "\u{1F1F9}\u{1F1F9}",
  "Iceland": "\u{1F1EE}\u{1F1F8}",
  "Finland": "\u{1F1EB}\u{1F1EE}",
  "Slovakia": "\u{1F1F8}\u{1F1F0}",
  "Slovenia": "\u{1F1F8}\u{1F1EE}",
  "Hungary": "\u{1F1ED}\u{1F1FA}",
  "Bulgaria": "\u{1F1E7}\u{1F1EC}",
  "Albania": "\u{1F1E6}\u{1F1F1}",
  "Bosnia": "\u{1F1E7}\u{1F1E6}",
  "North Macedonia": "\u{1F1F2}\u{1F1F0}",
  "Montenegro": "\u{1F1F2}\u{1F1EA}",
  "Kosovo": "\u{1F1FD}\u{1F1F0}",
  "Cuba": "\u{1F1E8}\u{1F1FA}",
  "Dominican Republic": "\u{1F1E9}\u{1F1F4}",
  "Monaco": "\u{1F1F2}\u{1F1E8}",
  "Luxembourg": "\u{1F1F1}\u{1F1FA}",
  "Cyprus": "\u{1F1E8}\u{1F1FE}",
  "Malta": "\u{1F1F2}\u{1F1F9}",
  "Estonia": "\u{1F1EA}\u{1F1EA}",
  "Latvia": "\u{1F1F1}\u{1F1FB}",
  "Lithuania": "\u{1F1F1}\u{1F1F9}",
  "Moldova": "\u{1F1F2}\u{1F1E9}"
};
function getFlag(country) {
  return FLAG_MAP[country] || "\u{1F3F3}\uFE0F";
}
var rand2 = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
var clamp5 = (v, min, max) => Math.max(min, Math.min(max, v));
var pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
var LEAGUE_DRAW_CAP = 5;
function leagueDrawGroups(candidates) {
  const groups = /* @__PURE__ */ new Map();
  for (const club of candidates) {
    const key = `${club.league}|${club.tier}`;
    const list2 = groups.get(key);
    if (list2) list2.push(club);
    else groups.set(key, [club]);
  }
  return [...groups].map(([key, clubs]) => ({ key, clubs, weight: Math.min(clubs.length, LEAGUE_DRAW_CAP) }));
}
function pickAcrossLeagues(candidates) {
  const groups = leagueDrawGroups(candidates);
  if (!groups.length) return candidates[0];
  let r = Math.random() * groups.reduce((s, g) => s + g.weight, 0);
  let chosen = groups[groups.length - 1];
  for (const g of groups) {
    if (r < g.weight) {
      chosen = g;
      break;
    }
    r -= g.weight;
  }
  return chosen.clubs[Math.floor(Math.random() * chosen.clubs.length)];
}
function getClubsByTier(clubs, tier) {
  return clubs.filter((c) => c.tier === tier);
}
function getYouthAcademyClub(clubs, nationality, overall) {
  const ovr = overall ?? 50;
  if (ovr >= 75) {
    const eliteFromHome = clubs.filter((c) => c.country === nationality && c.tier === 1 && ELITE_CLUBS.includes(c.name));
    if (eliteFromHome.length > 0) return pick(eliteFromHome);
    const anyT1Home = clubs.filter((c) => c.country === nationality && c.tier === 1);
    if (anyT1Home.length > 0) return pick(anyT1Home);
    const anyElite = clubs.filter((c) => ELITE_CLUBS.includes(c.name));
    if (anyElite.length > 0) return pick(anyElite);
    return pickAcrossLeagues(getClubsByTier(clubs, 1));
  }
  if (ovr >= 66) {
    const homeTiers = clubs.filter((c) => c.country === nationality && (c.tier === 1 || c.tier === 2));
    if (homeTiers.length > 0) return pick(homeTiers);
    const anyT1T2 = clubs.filter((c) => c.tier === 1 || c.tier === 2);
    if (anyT1T2.length > 0) return pickAcrossLeagues(anyT1T2);
    return pickAcrossLeagues(getClubsByTier(clubs, 2));
  }
  if (ovr >= 55) {
    const homeTiers = clubs.filter((c) => c.country === nationality && (c.tier === 2 || c.tier === 3));
    if (homeTiers.length > 0) return pick(homeTiers);
    const anyT2T3 = clubs.filter((c) => c.tier === 2 || c.tier === 3);
    if (anyT2T3.length > 0) return pickAcrossLeagues(anyT2T3);
    return pickAcrossLeagues(getClubsByTier(clubs, 3));
  }
  if (ovr >= 40) {
    const homeClubs = clubs.filter((c) => c.country === nationality && c.tier >= 3);
    if (homeClubs.length > 0) return pick(homeClubs);
    const anyT3T4 = clubs.filter((c) => c.tier >= 3);
    if (anyT3T4.length > 0) return pickAcrossLeagues(anyT3T4);
    return pickAcrossLeagues(getClubsByTier(clubs, 4));
  }
  const homeT4 = clubs.filter((c) => c.country === nationality && c.tier === 4);
  if (homeT4.length > 0) return pick(homeT4);
  const t4 = getClubsByTier(clubs, 4);
  if (t4.length > 0) return pickAcrossLeagues(t4);
  return pickAcrossLeagues(getClubsByTier(clubs, 3));
}
function calcOverall(s, position) {
  if (position === "GK") {
    return Math.round(s.reflexes * 0.3 + s.defending * 0.2 + s.physical * 0.2 + s.pace * 0.1 + s.passing * 0.1 + s.dribbling * 0.05 + s.shooting * 0.05);
  }
  return Math.round((s.pace + s.shooting + s.passing + s.dribbling + s.defending + s.physical) / 6);
}
function rollPrimeType() {
  const r = Math.random();
  if (r < 0.25) return "early";
  if (r < 0.65) return "normal";
  if (r < 0.9) return "late";
  return "extended";
}
function isInPrime(age, primeType) {
  switch (primeType) {
    case "early":
      return age >= 22 && age <= 26;
    case "normal":
      return age >= 24 && age <= 28;
    case "late":
      return age >= 27 && age <= 31;
    case "extended":
      return age >= 23 && age <= 32;
  }
}
function isPastPrime(age, primeType) {
  switch (primeType) {
    case "early":
      return age > 26;
    case "normal":
      return age > 28;
    case "late":
      return age > 31;
    case "extended":
      return age > 32;
  }
}
function effectivePotential(s) {
  const base = Math.max(s.potential ?? Math.max(90, s.overall + 3), s.overall);
  const earned = Number(s.potentialEarned);
  return Math.min(99, base + (Number.isFinite(earned) ? Math.max(0, earned) : 0));
}
var STORY_LINES_PER_SEASON = 40;
var STORY_SEASONS_MAX = 60;
function isStorySeason(v) {
  if (!v || typeof v !== "object" || Array.isArray(v)) return false;
  const e = v;
  return typeof e.year === "number" && Number.isFinite(e.year) && typeof e.age === "number" && Number.isFinite(e.age) && typeof e.club === "string" && Array.isArray(e.lines) && e.lines.every((l) => typeof l === "string") && (e.more === void 0 || typeof e.more === "number" && Number.isFinite(e.more) && e.more >= 0);
}
function cleanCareerStory(raw) {
  if (!Array.isArray(raw)) return [];
  const kept = raw.every(isStorySeason) ? raw : raw.filter(isStorySeason);
  return kept.length > STORY_SEASONS_MAX ? kept.slice(-STORY_SEASONS_MAX) : kept;
}
function archiveSeasonStory(s) {
  const story = cleanCareerStory(s.story);
  const lines = Array.isArray(s.events) ? s.events.filter((l) => typeof l === "string") : [];
  if (lines.length === 0) return story;
  const row = s.seasons.length > 0 ? s.seasons[s.seasons.length - 1] : null;
  const year = row ? row.year : 0;
  const age = row ? row.age : s.age;
  const club = row ? row.club : s.currentClub;
  const last = story.length > 0 ? story[story.length - 1] : null;
  const same = last !== null && last.year === year && last.age === age && last.club === club;
  const all = same ? [...last.lines, ...lines] : lines;
  const dropped = (same ? last.more ?? 0 : 0) + Math.max(0, all.length - STORY_LINES_PER_SEASON);
  const entry = { year, age, club, lines: all.slice(0, STORY_LINES_PER_SEASON) };
  if (dropped > 0) entry.more = dropped;
  const next = same ? [...story.slice(0, -1), entry] : [...story, entry];
  return next.length > STORY_SEASONS_MAX ? next.slice(-STORY_SEASONS_MAX) : next;
}
function repairCareer(state) {
  if (!state || typeof state !== "object") return state;
  const s = state;
  if (s.phase === "season_summary" && !s.pendingSummary) s.phase = "playing";
  if (!s.primeType) s.primeType = rollPrimeType();
  if (s.loan === void 0) s.loan = null;
  if (s.pendingLoanOffers === void 0) s.pendingLoanOffers = null;
  if (s.frozenOut === void 0) s.frozenOut = 0;
  if (s.badSeasonStreak === void 0) s.badSeasonStreak = 0;
  if (s.lastUCLResult && typeof s.lastUCLResult === "object") {
    const u = s.lastUCLResult;
    const badStage = u.firstStage !== void 0 && !isFirstStageResult(u.firstStage);
    const badName = u.competition !== void 0 && typeof u.competition !== "string";
    const badNote = u.simplified !== void 0 && typeof u.simplified !== "string";
    if (badStage || badName || badNote) {
      const fixed = { ...u };
      if (badStage) delete fixed.firstStage;
      if (badName) delete fixed.competition;
      if (badNote) delete fixed.simplified;
      s.lastUCLResult = fixed;
    }
  }
  if (Array.isArray(s.seasons) && s.seasons.some((x) => x && x.clubCupTitle !== void 0 && typeof x.clubCupTitle !== "string")) {
    s.seasons = s.seasons.map((x) => {
      if (!x || x.clubCupTitle === void 0 || typeof x.clubCupTitle === "string") return x;
      const { clubCupTitle: _dropped, ...rest } = x;
      return rest;
    });
  }
  if (Array.isArray(s.seasons) && s.seasons.some((x) => x && x.cupRun !== void 0 && !readCupRun(x))) {
    s.seasons = s.seasons.map((x) => {
      if (!x || x.cupRun === void 0 || readCupRun(x)) return x;
      const { cupRun: _dropped, ...rest } = x;
      return rest;
    });
  }
  if (s.seasonMoments !== void 0 && !readSeasonMoments(s.seasonMoments)) delete s.seasonMoments;
  s.story = cleanCareerStory(s.story);
  if ((s.isClubCaptain ?? false) && s.captainClub !== s.currentClub) {
    s.isClubCaptain = false;
    s.captainClub = null;
  }
  if (s.captainSeasons !== void 0 && (typeof s.captainSeasons !== "number" || !Number.isFinite(s.captainSeasons) || s.captainSeasons < 0)) {
    s.captainSeasons = 0;
  }
  const legacySponsor = s;
  if (legacySponsor.activeSponsorship === "fifa_cover") s.activeSponsorship = "cover_athlete";
  const legacyLifestyle = s;
  if (legacyLifestyle.lifestyleLevel === "Billionaire") s.lifestyleLevel = "Untouchable";
  if (s.eventLastFired !== void 0 && (typeof s.eventLastFired !== "object" || s.eventLastFired === null || Array.isArray(s.eventLastFired))) {
    delete s.eventLastFired;
  }
  const bonus = Number(s.sponsorBonus);
  s.sponsorBonus = Number.isFinite(bonus) ? clamp5(Math.round(bonus * 100) / 100, -20, 60) : 0;
  const legacyCover = s;
  if (legacyCover.fifaCoverAccepted === true) s.coverAthleteAccepted = true;
  if (legacyCover.pendingFifaCoverEvent === true) s.pendingCoverAthleteEvent = true;
  const earned = Number(s.potentialEarned);
  s.potentialEarned = Number.isFinite(earned) ? Math.max(0, Math.round(earned)) : 0;
  const streak = Number(s.eliteStreak);
  s.eliteStreak = Number.isFinite(streak) ? Math.max(0, Math.round(streak)) : 0;
  s.physique = safePhysique(s.position, s.physique);
  s.attrShape = safeShape(s.position, s.attrShape);
  const start = Number(s.startingOverall);
  if (Number.isFinite(start)) s.startingOverall = Math.round(clamp5(start, 1, 99));
  else delete s.startingOverall;
  if (typeof s.peakOverall !== "number" || !Number.isFinite(s.peakOverall)) s.peakOverall = s.overall;
  s.money = ensureMoney2(s);
  return state;
}
function developmentRate(s, justPlayed) {
  const pot = effectivePotential(s);
  const gap = pot - s.overall;
  const headroom = gap <= 0 ? 0.15 : gap <= 3 ? 0.5 : gap <= 8 ? 1 : gap <= 15 ? 1.5 : 1.9;
  let form = 1;
  const last = justPlayed ?? (s.seasons.length ? s.seasons[s.seasons.length - 1] : null);
  if (last && last.type !== "youth") {
    const apps = last.apps ?? 0;
    form *= apps >= 30 ? 1.25 : apps >= 18 ? 1 : apps >= 8 ? 0.78 : 0.5;
    const r = last.rating ?? 6.5;
    form *= r >= 7.6 ? 1.45 : r >= 7.1 ? 1.2 : r >= 6.6 ? 1 : r >= 6 ? 0.82 : 0.62;
  }
  const tierBase = s.currentClubTier === 1 ? 1.2 : s.currentClubTier === 2 ? 1.07 : 1;
  const lastApps = last && last.type !== "youth" ? last.apps ?? 0 : 25;
  const tierShare = lastApps >= 25 ? 1 : lastApps >= 12 ? 0.5 : 0.25;
  const tierF = 1 + (tierBase - 1) * tierShare;
  return clamp5(headroom * form * tierF, 0.1, 2.6);
}
function growStat(current, age, isYouth, isPace, primeType, potential = 99, currentOverall = 0, dev = 1) {
  let growth;
  if (isYouth) {
    growth = current >= 78 ? rand2(0, 1) : rand2(1, 3);
  } else if (isInPrime(age, primeType)) {
    growth = rand2(1, 3);
  } else if (!isPastPrime(age, primeType)) {
    growth = rand2(0, 2);
  } else {
    if (age >= 40) {
      growth = rand2(-7, -4);
    } else if (age >= 38) {
      growth = rand2(-6, -3);
    } else if (age >= 35) {
      growth = rand2(-5, -2);
    } else if (age >= 32) {
      growth = rand2(-3, -1);
    } else {
      const primeEnd = primeType === "early" ? 26 : primeType === "normal" ? 28 : primeType === "late" ? 31 : 32;
      const yearsPost = age - primeEnd;
      if (yearsPost <= 2) {
        growth = rand2(-2, 0);
      } else {
        growth = rand2(-3, -1);
      }
    }
  }
  if (growth > 0 && dev !== 1) {
    const scaled = growth * dev;
    growth = Math.floor(scaled) + (Math.random() < scaled % 1 ? 1 : 0);
  }
  if (growth > 0 && !isYouth) {
    if (current >= 94) growth = Math.random() < 0.2 ? 1 : 0;
    else if (current >= 90) growth = Math.random() < 0.45 ? 1 : 0;
    else if (current >= 86) growth = Math.min(growth, Math.random() < 0.5 ? 1 : 2);
  }
  if (growth > 0 && currentOverall > 0) {
    if (currentOverall >= potential) growth = Math.random() < 0.12 ? 1 : 0;
    else if (currentOverall >= potential - 3) growth = Math.min(growth, Math.random() < 0.55 ? 1 : 0);
  }
  if (isPace && age >= 28 && !isYouth) {
    growth -= 1;
    if (age >= 35) growth -= 1;
  }
  return clamp5(current + growth, 20, 99);
}
function calcMarketValue(overall, age, _position, _socialMediaFollowers) {
  let minVal, maxVal;
  if (overall >= 95) {
    if (age >= 20 && age <= 28) {
      minVal = 280;
      maxVal = 400;
    } else if (age >= 29 && age <= 31) {
      minVal = 180;
      maxVal = 280;
    } else if (age >= 32 && age <= 34) {
      minVal = 80;
      maxVal = 150;
    } else if (age >= 35) {
      minVal = 20;
      maxVal = 60;
    } else {
      minVal = 100;
      maxVal = 200;
    }
  } else if (overall >= 90) {
    if (age >= 20 && age <= 28) {
      minVal = 160;
      maxVal = 260;
    } else if (age >= 29 && age <= 31) {
      minVal = 100;
      maxVal = 180;
    } else if (age >= 32 && age <= 34) {
      minVal = 40;
      maxVal = 90;
    } else if (age >= 35) {
      minVal = 10;
      maxVal = 35;
    } else {
      minVal = 60;
      maxVal = 120;
    }
  } else if (overall >= 85) {
    if (age >= 20 && age <= 28) {
      minVal = 80;
      maxVal = 140;
    } else if (age >= 29 && age <= 31) {
      minVal = 50;
      maxVal = 100;
    } else if (age >= 32 && age <= 34) {
      minVal = 20;
      maxVal = 55;
    } else if (age >= 35) {
      minVal = 5;
      maxVal = 20;
    } else {
      minVal = 30;
      maxVal = 70;
    }
  } else if (overall >= 80) {
    if (age >= 20 && age <= 28) {
      minVal = 40;
      maxVal = 80;
    } else if (age >= 29 && age <= 31) {
      minVal = 25;
      maxVal = 55;
    } else if (age >= 32 && age <= 34) {
      minVal = 10;
      maxVal = 30;
    } else if (age >= 35) {
      minVal = 3;
      maxVal = 12;
    } else {
      minVal = 15;
      maxVal = 40;
    }
  } else if (overall >= 75) {
    if (age >= 20 && age <= 28) {
      minVal = 20;
      maxVal = 45;
    } else if (age >= 29 && age <= 31) {
      minVal = 10;
      maxVal = 25;
    } else if (age >= 32 && age <= 34) {
      minVal = 5;
      maxVal = 15;
    } else if (age >= 35) {
      minVal = 1;
      maxVal = 8;
    } else {
      minVal = 8;
      maxVal = 25;
    }
  } else if (overall >= 70) {
    if (age <= 28) {
      minVal = 8;
      maxVal = 25;
    } else if (age <= 31) {
      minVal = 4;
      maxVal = 14;
    } else {
      minVal = 1;
      maxVal = 6;
    }
  } else if (overall >= 65) {
    if (age <= 28) {
      minVal = 3;
      maxVal = 12;
    } else {
      minVal = 0.5;
      maxVal = 5;
    }
  } else {
    minVal = 0.1;
    maxVal = Math.max(0.5, overall * 0.05);
  }
  const value = minVal + Math.random() * (maxVal - minVal);
  return Math.max(0.1, Math.round(value * 10) / 10);
}
var ELITE_CLUBS = ["Bayern Munich", "PSG", "Man City", "Real Madrid", "Barcelona", "Liverpool"];
var HAND_CLUBS = [
  // Tier 1, elite
  { id: "fb-1", name: "Real Madrid", country: "Spain", tier: 1, color: "#FEBE10", league: "La Liga" },
  { id: "fb-2", name: "Barcelona", country: "Spain", tier: 1, color: "#A50044", league: "La Liga" },
  { id: "fb-3", name: "Man City", country: "England", tier: 1, color: "#6CABDD", league: "Premier League" },
  { id: "fb-4", name: "Liverpool", country: "England", tier: 1, color: "#C8102E", league: "Premier League" },
  { id: "fb-5", name: "Bayern Munich", country: "Germany", tier: 1, color: "#DC052D", league: "Bundesliga" },
  { id: "fb-6", name: "PSG", country: "France", tier: 1, color: "#004170", league: "Ligue 1" },
  { id: "fb-7", name: "Juventus", country: "Italy", tier: 1, color: "#000000", league: "Serie A" },
  { id: "fb-8", name: "Inter Milan", country: "Italy", tier: 1, color: "#0068A8", league: "Serie A" },
  { id: "fb-9", name: "Man United", country: "England", tier: 1, color: "#DA291C", league: "Premier League" },
  { id: "fb-10", name: "Arsenal", country: "England", tier: 1, color: "#EF0107", league: "Premier League" },
  { id: "fb-11", name: "Chelsea", country: "England", tier: 1, color: "#034694", league: "Premier League" },
  { id: "fb-12", name: "Ajax", country: "Netherlands", tier: 1, color: "#D2122E", league: "Eredivisie" },
  { id: "fb-13", name: "Benfica", country: "Portugal", tier: 1, color: "#E30613", league: "Primeira Liga" },
  { id: "fb-14", name: "Porto", country: "Portugal", tier: 1, color: "#003399", league: "Primeira Liga" },
  { id: "fb-15", name: "Boca Juniors", country: "Argentina", tier: 1, color: "#003DA5", league: "Liga Profesional" },
  { id: "fb-16", name: "River Plate", country: "Argentina", tier: 1, color: "#E9040F", league: "Liga Profesional" },
  { id: "fb-17", name: "Flamengo", country: "Brazil", tier: 1, color: "#C8102E", league: "Brasileirao" },
  { id: "fb-18", name: "Sao Paulo", country: "Brazil", tier: 1, color: "#B40404", league: "Brasileirao" },
  // Tier 2, strong mid-table
  { id: "fb-19", name: "Atletico Madrid", country: "Spain", tier: 2, color: "#CB3524", league: "La Liga" },
  { id: "fb-20", name: "Sevilla", country: "Spain", tier: 2, color: "#D0021B", league: "La Liga" },
  { id: "fb-21", name: "Tottenham", country: "England", tier: 2, color: "#132257", league: "Premier League" },
  { id: "fb-22", name: "Newcastle", country: "England", tier: 2, color: "#241F20", league: "Premier League" },
  { id: "fb-23", name: "Dortmund", country: "Germany", tier: 2, color: "#FDE100", league: "Bundesliga" },
  { id: "fb-24", name: "Leipzig", country: "Germany", tier: 2, color: "#DD0741", league: "Bundesliga" },
  { id: "fb-25", name: "AC Milan", country: "Italy", tier: 2, color: "#FB090B", league: "Serie A" },
  { id: "fb-26", name: "Napoli", country: "Italy", tier: 2, color: "#12A0D7", league: "Serie A" },
  { id: "fb-27", name: "Roma", country: "Italy", tier: 2, color: "#8E1F2F", league: "Serie A" },
  { id: "fb-28", name: "Marseille", country: "France", tier: 2, color: "#2FA0DA", league: "Ligue 1" },
  { id: "fb-29", name: "Lyon", country: "France", tier: 2, color: "#1C2C5B", league: "Ligue 1" },
  { id: "fb-30", name: "Feyenoord", country: "Netherlands", tier: 2, color: "#00A03C", league: "Eredivisie" },
  { id: "fb-31", name: "PSV", country: "Netherlands", tier: 2, color: "#ED1C24", league: "Eredivisie" },
  { id: "fb-32", name: "Sporting CP", country: "Portugal", tier: 2, color: "#008148", league: "Primeira Liga" },
  { id: "fb-33", name: "Fenerbahce", country: "Turkey", tier: 2, color: "#0A2C59", league: "Super Lig" },
  { id: "fb-34", name: "Galatasaray", country: "Turkey", tier: 2, color: "#A90432", league: "Super Lig" },
  { id: "fb-35", name: "Al Hilal", country: "Saudi Arabia", tier: 2, color: "#003DA5", league: "Saudi Pro League" },
  { id: "fb-36", name: "Celtic", country: "Scotland", tier: 2, color: "#018749", league: "Scottish Premiership" },
  { id: "fb-37", name: "Rangers", country: "Scotland", tier: 2, color: "#1E3A8A", league: "Scottish Premiership" },
  { id: "fb-38", name: "Palmeiras", country: "Brazil", tier: 2, color: "#006437", league: "Brasileirao" },
  { id: "fb-39", name: "LA Galaxy", country: "USA", tier: 2, color: "#00245D", league: "MLS" },
  { id: "fb-40", name: "Inter Miami", country: "USA", tier: 2, color: "#F7B5CD", league: "MLS" },
  // Tier 3, solid domestic clubs
  { id: "fb-41", name: "Real Sociedad", country: "Spain", tier: 3, color: "#0067B1", league: "La Liga" },
  { id: "fb-42", name: "Villarreal", country: "Spain", tier: 3, color: "#FFE667", league: "La Liga" },
  { id: "fb-43", name: "West Ham", country: "England", tier: 3, color: "#7A263A", league: "Championship" },
  { id: "fb-44", name: "Aston Villa", country: "England", tier: 3, color: "#670E36", league: "Premier League" },
  { id: "fb-45", name: "Everton", country: "England", tier: 3, color: "#003399", league: "Premier League" },
  { id: "fb-46", name: "Leverkusen", country: "Germany", tier: 3, color: "#E32221", league: "Bundesliga" },
  { id: "fb-47", name: "Frankfurt", country: "Germany", tier: 3, color: "#E1000F", league: "Bundesliga" },
  { id: "fb-48", name: "Atalanta", country: "Italy", tier: 3, color: "#1E71B8", league: "Serie A" },
  { id: "fb-49", name: "Fiorentina", country: "Italy", tier: 3, color: "#5B2A86", league: "Serie A" },
  { id: "fb-50", name: "Lille", country: "France", tier: 3, color: "#C60C30", league: "Ligue 1" },
  { id: "fb-51", name: "Monaco", country: "Monaco", tier: 3, color: "#E2231A", league: "Ligue 1" },
  { id: "fb-52", name: "Genk", country: "Belgium", tier: 3, color: "#0055A4", league: "Belgian Pro League" },
  { id: "fb-53", name: "Anderlecht", country: "Belgium", tier: 3, color: "#5E2C81", league: "Belgian Pro League" },
  { id: "fb-54", name: "FC Copenhagen", country: "Denmark", tier: 3, color: "#FFFFFF", league: "Danish Superliga" },
  { id: "fb-55", name: "Malmo FF", country: "Sweden", tier: 3, color: "#5CB8E4", league: "Allsvenskan" },
  { id: "fb-56", name: "Red Bull Salzburg", country: "Austria", tier: 3, color: "#DB021D", league: "Austrian Bundesliga" },
  { id: "fb-57", name: "Basel", country: "Switzerland", tier: 3, color: "#DB021D", league: "Swiss Super League" },
  { id: "fb-58", name: "Al Nassr", country: "Saudi Arabia", tier: 3, color: "#FFF200", league: "Saudi Pro League" },
  { id: "fb-59", name: "Cruz Azul", country: "Mexico", tier: 3, color: "#00539F", league: "Liga MX" },
  { id: "fb-60", name: "Club America", country: "Mexico", tier: 3, color: "#FFC72C", league: "Liga MX" },
  // Tier 4, smaller / lower league
  { id: "fb-61", name: "Real Betis", country: "Spain", tier: 4, color: "#00954C", league: "La Liga" },
  { id: "fb-62", name: "Celta Vigo", country: "Spain", tier: 4, color: "#8AC3EE", league: "La Liga" },
  { id: "fb-63", name: "Crystal Palace", country: "England", tier: 4, color: "#1B458F", league: "Premier League" },
  { id: "fb-64", name: "Brentford", country: "England", tier: 4, color: "#D20000", league: "Premier League" },
  { id: "fb-65", name: "Norwich City", country: "England", tier: 4, color: "#FFF200", league: "Championship" },
  { id: "fb-66", name: "Hertha Berlin", country: "Germany", tier: 4, color: "#004C9E", league: "2. Bundesliga" },
  { id: "fb-67", name: "Werder Bremen", country: "Germany", tier: 4, color: "#1D9053", league: "Bundesliga" },
  { id: "fb-68", name: "Torino", country: "Italy", tier: 4, color: "#881B1E", league: "Serie A" },
  { id: "fb-69", name: "Bologna", country: "Italy", tier: 4, color: "#A61C2E", league: "Serie A" },
  { id: "fb-70", name: "Nantes", country: "France", tier: 4, color: "#FCE300", league: "Ligue 2" },
  { id: "fb-71", name: "Strasbourg", country: "France", tier: 4, color: "#0072BB", league: "Ligue 1" },
  { id: "fb-72", name: "Utrecht", country: "Netherlands", tier: 4, color: "#D2122E", league: "Eredivisie" },
  { id: "fb-73", name: "Braga", country: "Portugal", tier: 4, color: "#DA020E", league: "Primeira Liga" },
  { id: "fb-74", name: "Aberdeen", country: "Scotland", tier: 4, color: "#D71920", league: "Scottish Premiership" },
  { id: "fb-75", name: "Santos", country: "Brazil", tier: 4, color: "#FFFFFF", league: "Brasileirao" },
  { id: "fb-76", name: "Colo-Colo", country: "Chile", tier: 4, color: "#FFFFFF", league: "Primera Division" },
  { id: "fb-77", name: "Al Ahly", country: "Egypt", tier: 4, color: "#C8102E", league: "Egyptian Premier League" },
  { id: "fb-78", name: "Kaizer Chiefs", country: "South Africa", tier: 4, color: "#FFD100", league: "PSL" },
  { id: "fb-79", name: "Yokohama F. Marinos", country: "Japan", tier: 4, color: "#00559A", league: "J1 League" },
  { id: "fb-80", name: "Urawa Red Diamonds", country: "Japan", tier: 4, color: "#D2001C", league: "J1 League" },
  { id: "fb-81", name: "Seattle Sounders", country: "USA", tier: 4, color: "#5D9741", league: "MLS" },
  // ── Round 54 expansion: 60+ new clubs so careers can wind through nearly
  // every football country on earth (owner: "more teams and more flags and
  // more of everything"). Tier 2, big names outside the usual five leagues.
  { id: "fb-82", name: "Al Ittihad", country: "Saudi Arabia", tier: 2, color: "#F9C623", league: "Saudi Pro League" },
  { id: "fb-83", name: "Club Brugge", country: "Belgium", tier: 2, color: "#0B4494", league: "Belgian Pro League" },
  { id: "fb-84", name: "Olympiacos", country: "Greece", tier: 2, color: "#D6202B", league: "Super League Greece" },
  { id: "fb-85", name: "Shakhtar Donetsk", country: "Ukraine", tier: 2, color: "#F26522", league: "Ukrainian Premier League" },
  { id: "fb-86", name: "Corinthians", country: "Brazil", tier: 2, color: "#141414", league: "Brasileirao" },
  { id: "fb-87", name: "Monterrey", country: "Mexico", tier: 2, color: "#0A2240", league: "Liga MX" },
  { id: "fb-88", name: "Tigres UANL", country: "Mexico", tier: 2, color: "#FDB913", league: "Liga MX" },
  { id: "fb-89", name: "Athletic Bilbao", country: "Spain", tier: 2, color: "#EE2523", league: "La Liga" },
  { id: "fb-90", name: "Brighton", country: "England", tier: 2, color: "#0057B8", league: "Premier League" },
  { id: "fb-91", name: "Stuttgart", country: "Germany", tier: 2, color: "#E32219", league: "Bundesliga" },
  { id: "fb-92", name: "LAFC", country: "USA", tier: 2, color: "#C39E6D", league: "MLS" },
  { id: "fb-93", name: "River Plate Asuncion", country: "Paraguay", tier: 4, color: "#CE1126", league: "Primera B Paraguay" },
  { id: "fb-94", name: "Racing Club", country: "Argentina", tier: 2, color: "#75AADB", league: "Liga Profesional" },
  { id: "fb-95", name: "Zenit", country: "Russia", tier: 2, color: "#009FDF", league: "Russian Premier League" },
  { id: "fb-96", name: "Girona", country: "Spain", tier: 2, color: "#CD2534", league: "Segunda Division" },
  // Tier 3, strong clubs across Europe, Asia, Africa and the Americas.
  { id: "fb-97", name: "PAOK", country: "Greece", tier: 3, color: "#2B2B2B", league: "Super League Greece" },
  { id: "fb-98", name: "Panathinaikos", country: "Greece", tier: 3, color: "#00743F", league: "Super League Greece" },
  { id: "fb-99", name: "Dinamo Zagreb", country: "Croatia", tier: 3, color: "#1F4C9C", league: "HNL" },
  { id: "fb-100", name: "Red Star Belgrade", country: "Serbia", tier: 3, color: "#D6202B", league: "Serbian SuperLiga" },
  { id: "fb-101", name: "Legia Warsaw", country: "Poland", tier: 3, color: "#0F5B2F", league: "Ekstraklasa" },
  { id: "fb-102", name: "Slavia Prague", country: "Czech Republic", tier: 3, color: "#D6202B", league: "Czech First League" },
  { id: "fb-103", name: "Besiktas", country: "Turkey", tier: 3, color: "#2B2B2B", league: "Super Lig" },
  { id: "fb-104", name: "Trabzonspor", country: "Turkey", tier: 3, color: "#5C1F33", league: "Super Lig" },
  { id: "fb-105", name: "Nice", country: "France", tier: 3, color: "#CC0000", league: "Ligue 1" },
  { id: "fb-106", name: "Wolves", country: "England", tier: 3, color: "#FDB913", league: "Championship" },
  { id: "fb-107", name: "Fulham", country: "England", tier: 3, color: "#111111", league: "Premier League" },
  { id: "fb-108", name: "Gremio", country: "Brazil", tier: 3, color: "#0D80BF", league: "Brasileirao" },
  { id: "fb-109", name: "Atletico Nacional", country: "Colombia", tier: 3, color: "#00A650", league: "Liga BetPlay" },
  { id: "fb-110", name: "Penarol", country: "Uruguay", tier: 3, color: "#FFD100", league: "Primera Division Uruguay" },
  { id: "fb-111", name: "Kawasaki Frontale", country: "Japan", tier: 3, color: "#009FE8", league: "J1 League" },
  { id: "fb-112", name: "Jeonbuk Motors", country: "South Korea", tier: 3, color: "#0C6B3E", league: "K League 1" },
  { id: "fb-113", name: "Al Sadd", country: "Qatar", tier: 3, color: "#2B2B2B", league: "Qatar Stars League" },
  { id: "fb-114", name: "Persepolis", country: "Iran", tier: 3, color: "#D6202B", league: "Persian Gulf Pro League" },
  { id: "fb-115", name: "Shanghai Port", country: "China", tier: 3, color: "#D6202B", league: "Chinese Super League" },
  { id: "fb-116", name: "Zamalek", country: "Egypt", tier: 3, color: "#FFFFFF", league: "Egyptian Premier League" },
  { id: "fb-117", name: "Wydad Casablanca", country: "Morocco", tier: 3, color: "#D6202B", league: "Botola Pro" },
  { id: "fb-118", name: "Esperance", country: "Tunisia", tier: 3, color: "#BC0C12", league: "Ligue 1 Tunisia" },
  { id: "fb-119", name: "Mamelodi Sundowns", country: "South Africa", tier: 3, color: "#FBC403", league: "PSL" },
  { id: "fb-120", name: "Toronto FC", country: "Canada", tier: 3, color: "#B81137", league: "MLS" },
  // Tier 4, the wide world where most careers actually start.
  { id: "fb-121", name: "Sparta Prague", country: "Czech Republic", tier: 4, color: "#7B0C11", league: "Czech First League" },
  { id: "fb-122", name: "Partizan", country: "Serbia", tier: 4, color: "#2B2B2B", league: "Serbian SuperLiga" },
  { id: "fb-123", name: "Ferencvaros", country: "Hungary", tier: 4, color: "#0E5C2F", league: "NB I" },
  { id: "fb-124", name: "Hajduk Split", country: "Croatia", tier: 4, color: "#0C4076", league: "HNL" },
  { id: "fb-125", name: "HJK Helsinki", country: "Finland", tier: 4, color: "#0056A3", league: "Veikkausliiga" },
  { id: "fb-126", name: "Breidablik", country: "Iceland", tier: 4, color: "#00954C", league: "Besta deild" },
  { id: "fb-127", name: "Slovan Bratislava", country: "Slovakia", tier: 4, color: "#57A8E2", league: "Slovak First League" },
  { id: "fb-128", name: "Ludogorets", country: "Bulgaria", tier: 4, color: "#00954C", league: "First League Bulgaria" },
  { id: "fb-129", name: "Sheriff Tiraspol", country: "Moldova", tier: 4, color: "#FBC403", league: "Super Liga Moldova" },
  { id: "fb-130", name: "Dinamo Tbilisi", country: "Georgia", tier: 4, color: "#0C4076", league: "Erovnuli Liga" },
  { id: "fb-131", name: "Pyunik", country: "Armenia", tier: 4, color: "#D6202B", league: "Armenian Premier League" },
  { id: "fb-132", name: "Qarabag", country: "Azerbaijan", tier: 4, color: "#2B2B2B", league: "Azerbaijan Premier League" },
  { id: "fb-133", name: "Kairat Almaty", country: "Kazakhstan", tier: 4, color: "#FBC403", league: "Kazakhstan Premier League" },
  { id: "fb-134", name: "Pakhtakor", country: "Uzbekistan", tier: 4, color: "#0056A3", league: "Uzbekistan Super League" },
  { id: "fb-135", name: "Mumbai City", country: "India", tier: 4, color: "#57A8E2", league: "Indian Super League" },
  { id: "fb-136", name: "Buriram United", country: "Thailand", tier: 4, color: "#0C2E5C", league: "Thai League 1" },
  { id: "fb-137", name: "Persija Jakarta", country: "Indonesia", tier: 4, color: "#D6202B", league: "Super League Indonesia" },
  { id: "fb-138", name: "Hanoi FC", country: "Vietnam", tier: 4, color: "#5C2D91", league: "V.League 1" },
  { id: "fb-139", name: "Johor Darul Tazim", country: "Malaysia", tier: 4, color: "#0C2E5C", league: "Malaysia Super League" },
  { id: "fb-140", name: "Melbourne Victory", country: "Australia", tier: 4, color: "#0C2E5C", league: "A-League" },
  { id: "fb-141", name: "Auckland FC", country: "New Zealand", tier: 4, color: "#2B2B2B", league: "A-League" },
  { id: "fb-142", name: "Wellington Phoenix", country: "New Zealand", tier: 4, color: "#FBC403", league: "A-League" },
  { id: "fb-143", name: "Raja Casablanca", country: "Morocco", tier: 4, color: "#00954C", league: "Botola Pro" },
  { id: "fb-144", name: "TP Mazembe", country: "DR Congo", tier: 4, color: "#2B2B2B", league: "Linafoot" },
  { id: "fb-145", name: "Enyimba", country: "Nigeria", tier: 4, color: "#0056A3", league: "NPFL" },
  { id: "fb-146", name: "Asante Kotoko", country: "Ghana", tier: 4, color: "#D6202B", league: "Ghana Premier League" },
  { id: "fb-147", name: "Gor Mahia", country: "Kenya", tier: 4, color: "#00954C", league: "Kenyan Premier League" },
  { id: "fb-148", name: "Orlando Pirates", country: "South Africa", tier: 4, color: "#2B2B2B", league: "PSL" },
  { id: "fb-149", name: "Saint George", country: "Ethiopia", tier: 4, color: "#FBC403", league: "Ethiopian Premier League" },
  { id: "fb-150", name: "Young Africans", country: "Tanzania", tier: 4, color: "#00954C", league: "NBC Premier League" },
  { id: "fb-151", name: "Atletico Petroleos", country: "Angola", tier: 4, color: "#FBC403", league: "Girabola" },
  { id: "fb-152", name: "Nacional", country: "Uruguay", tier: 4, color: "#FFFFFF", league: "Primera Division Uruguay" },
  { id: "fb-153", name: "Universidad de Chile", country: "Chile", tier: 4, color: "#0C2E5C", league: "Primera Division" },
  { id: "fb-154", name: "Millonarios", country: "Colombia", tier: 4, color: "#0056A3", league: "Liga BetPlay" },
  { id: "fb-155", name: "LDU Quito", country: "Ecuador", tier: 4, color: "#FFFFFF", league: "LigaPro" },
  { id: "fb-156", name: "Alianza Lima", country: "Peru", tier: 4, color: "#0C2E5C", league: "Liga 1 Peru" },
  { id: "fb-157", name: "Olimpia", country: "Paraguay", tier: 4, color: "#2B2B2B", league: "Primera Division Paraguay" },
  { id: "fb-158", name: "Caracas FC", country: "Venezuela", tier: 4, color: "#7B0C11", league: "Liga FUTVE" },
  { id: "fb-159", name: "Bolivar", country: "Bolivia", tier: 4, color: "#57A8E2", league: "Division Profesional" },
  { id: "fb-160", name: "Saprissa", country: "Costa Rica", tier: 4, color: "#5C2D91", league: "Liga FPD" },
  { id: "fb-161", name: "Olimpia Tegucigalpa", country: "Honduras", tier: 4, color: "#FFFFFF", league: "Liga Nacional Honduras" },
  { id: "fb-162", name: "Alianza FC", country: "El Salvador", tier: 4, color: "#FFFFFF", league: "Primera Division El Salvador" },
  { id: "fb-163", name: "Comunicaciones", country: "Guatemala", tier: 4, color: "#FFFFFF", league: "Liga Nacional Guatemala" },
  { id: "fb-164", name: "Violette AC", country: "Haiti", tier: 4, color: "#5C2D91", league: "Ligue Haitienne" },
  { id: "fb-165", name: "Waterhouse FC", country: "Jamaica", tier: 4, color: "#D6202B", league: "Jamaica Premier League" },
  { id: "fb-166", name: "Defence Force FC", country: "Trinidad and Tobago", tier: 4, color: "#7B0C11", league: "TT Premier League" },
  { id: "fb-167", name: "Vancouver Whitecaps", country: "Canada", tier: 4, color: "#0C2E5C", league: "MLS" },
  { id: "fb-168", name: "Chivas", country: "Mexico", tier: 4, color: "#D6202B", league: "Liga MX" },
  { id: "fb-169", name: "Pumas", country: "Mexico", tier: 4, color: "#0C2E5C", league: "Liga MX" },
  { id: "fb-170", name: "Al Duhail", country: "Qatar", tier: 4, color: "#D6202B", league: "Qatar Stars League" },
  { id: "fb-171", name: "Al Ain", country: "UAE", tier: 4, color: "#5C2D91", league: "UAE Pro League" },
  { id: "fb-172", name: "Beijing Guoan", country: "China", tier: 4, color: "#00954C", league: "Chinese Super League" },
  { id: "fb-173", name: "Maccabi Tel Aviv", country: "Israel", tier: 4, color: "#FBC403", league: "Israeli Premier League" },
  { id: "fb-174", name: "APOEL", country: "Cyprus", tier: 4, color: "#F26522", league: "Cypriot First Division" },
  { id: "fb-175", name: "Flora Tallinn", country: "Estonia", tier: 4, color: "#00954C", league: "Meistriliiga" },
  { id: "fb-176", name: "Zalgiris Vilnius", country: "Lithuania", tier: 4, color: "#00954C", league: "A Lyga" },
  /* Round 302, off the owner's tweaks document: the leagues he named by name
     (Liga Portugal here as Primeira Liga, Eredivisie, Scottish, MLS, Saudi,
     K League) get real depth instead of two or three clubs each. League
     labels are byte identical to the strings already in this array, because
     league is free text and a near miss silently creates a new league. */
  { id: "fb-177", name: "AZ Alkmaar", country: "Netherlands", tier: 3, color: "#DD0000", league: "Eredivisie" },
  { id: "fb-178", name: "Twente", country: "Netherlands", tier: 4, color: "#E70011", league: "Eredivisie" },
  { id: "fb-179", name: "Vitoria Guimaraes", country: "Portugal", tier: 4, color: "#F5F5F5", league: "Primeira Liga" },
  { id: "fb-180", name: "Hearts", country: "Scotland", tier: 4, color: "#800910", league: "Scottish Premiership" },
  { id: "fb-181", name: "Hibernian", country: "Scotland", tier: 4, color: "#006A4E", league: "Scottish Premiership" },
  { id: "fb-182", name: "Columbus Crew", country: "USA", tier: 3, color: "#FEDD00", league: "MLS" },
  { id: "fb-183", name: "Atlanta United", country: "USA", tier: 4, color: "#80000A", league: "MLS" },
  { id: "fb-184", name: "Al Ahli", country: "Saudi Arabia", tier: 3, color: "#006B3F", league: "Saudi Pro League" },
  { id: "fb-185", name: "Al Shabab", country: "Saudi Arabia", tier: 4, color: "#F2F2F2", league: "Saudi Pro League" },
  { id: "fb-186", name: "Ulsan HD", country: "South Korea", tier: 3, color: "#0053A0", league: "K League 1" },
  { id: "fb-187", name: "FC Seoul", country: "South Korea", tier: 4, color: "#AC1A2F", league: "K League 1" },
  { id: "fb-188", name: "Pohang Steelers", country: "South Korea", tier: 4, color: "#C8102E", league: "K League 1" },
  { id: "fb-189", name: "Botafogo", country: "Brazil", tier: 3, color: "#1A1A1A", league: "Brasileirao" },
  { id: "fb-190", name: "Cruzeiro", country: "Brazil", tier: 4, color: "#0033A0", league: "Brasileirao" }
];
var FALLBACK_CLUBS = [...HAND_CLUBS, ...CAREER_CLUB_POOL];
function wageForTier(tier, overall) {
  if (tier === 1) {
    if (overall >= 95) return rand2(38e4, 55e4);
    if (overall >= 90) return rand2(25e4, 38e4);
    if (overall >= 85) return rand2(15e4, 25e4);
    if (overall >= 80) return rand2(8e4, 15e4);
    return rand2(3e4, 8e4);
  }
  if (tier === 2) {
    if (overall >= 85) return rand2(7e4, 12e4);
    if (overall >= 80) return rand2(4e4, 8e4);
    if (overall >= 75) return rand2(2e4, 5e4);
    return rand2(8e3, 2e4);
  }
  if (tier === 3) {
    if (overall >= 75) return rand2(1e4, 25e3);
    return rand2(5e3, 15e3);
  }
  return rand2(500, 5e3);
}
function formatWage(wage) {
  if (wage >= 1e3) return localizeMoney(`\u20AC${(wage / 1e3).toFixed(0)}k/wk`);
  return localizeMoney(`\u20AC${wage}/wk`);
}
function generateContractOffers(clubs, overall, age, academyClubName) {
  let targetTiers;
  if (overall >= 66) targetTiers = [2, 2, 3];
  else if (overall >= 56) targetTiers = [3, 3, 3];
  else targetTiers = [3, 4, 4];
  const offers = [];
  const usedNames = /* @__PURE__ */ new Set();
  if (academyClubName) {
    const parentClub = clubs.find((c) => c.name === academyClubName);
    if (parentClub) {
      usedNames.add(parentClub.name);
      offers.push({
        club: parentClub,
        contractYears: rand2(3, 5),
        wage: Math.round(wageForTier(parentClub.tier, overall) * 0.8),
        transferFee: 0,
        isHomegrown: true
      });
    }
  }
  for (const tier of targetTiers) {
    const candidates = getClubsByTier(clubs, tier).filter((c) => !usedNames.has(c.name));
    if (candidates.length === 0) continue;
    const club = pickAcrossLeagues(candidates);
    usedNames.add(club.name);
    offers.push({ club, contractYears: rand2(2, 4), wage: wageForTier(tier, overall), transferFee: 0 });
  }
  return offers;
}
function initCareer(playerName, nationality, position, era, stats, overall, startYear, clubs, appearance, potential, physique, attrShape) {
  const academyClub = getYouthAcademyClub(adjustClubsForYear(clubs, startYear), nationality, overall);
  const seedTexts = pickPhoneTexts(16, "youth", [], 1);
  const created = {
    playerName,
    nationality,
    position,
    era,
    age: 16,
    // Round 78: the hidden ceiling this career will fight to reach.
    // Round 79: clamped above the final overall, since the point-spend build
    // editor can nudge a keeper's overall a few points past the roll.
    /* Round 131: clamped at 99 as well as floored above the overall. Without
       the clamp a player who built himself to 99 on the creation screen was
       handed a ceiling of 101, a number the growth code can never reach, which
       quietly turned the wall off for exactly the player who most needs it. */
    potential: Math.min(99, Math.max(potential ?? rollPotential(overall), overall + 2)),
    potentialEarned: 0,
    eliteStreak: 0,
    startingOverall: overall,
    physique: safePhysique(position, physique ?? defaultPhysique(position)),
    attrShape: safeShape(position, attrShape),
    // Round 80: the phone starts neutral with one text waiting on day one
    karma: 50,
    phoneUsedIds: seedTexts.map((d) => d.id),
    phoneInbox: seedTexts.map((def) => ({
      id: `${def.id}-${startYear}`,
      defId: def.id,
      from: def.from,
      emoji: def.emoji,
      text: def.text,
      year: startYear,
      choices: def.choices
    })),
    currentClub: `${academyClub.name} Youth`,
    currentClubCountry: academyClub.country,
    currentClubTier: academyClub.tier,
    currentClubColor: academyClub.color,
    currentLeague: academyClub.league,
    contractYearsLeft: 2,
    weeklyWage: 500,
    marketValue: 0.1,
    ...stats,
    overall,
    seasons: [{
      year: startYear,
      age: 16,
      club: `${academyClub.name} Youth`,
      clubCountry: academyClub.country,
      clubTier: academyClub.tier,
      apps: 0,
      goals: 0,
      assists: 0,
      cleanSheets: 0,
      yellowCards: 0,
      redCards: 0,
      rating: 0,
      leagueTitle: false,
      domesticCup: false,
      championsLeague: false,
      worldCup: false,
      ballonDor: false,
      ballonDorRank: null,
      type: "youth",
      intApps: 0,
      intGoals: 0,
      intAssists: 0,
      intRating: 0,
      tournament: null,
      tournamentResult: null
    }],
    events: [`\u{1F4CB} Joined ${academyClub.name} Youth Academy aged 16`],
    retired: false,
    phase: "youth",
    pendingOffers: [],
    pendingSummary: null,
    transferSituation: null,
    loan: null,
    pendingLoanOffers: null,
    pendingEvents: [],
    lastEventId: null,
    statBoostNextSeason: {},
    pendingNews: [],
    internationalCareer: false,
    sponsorDeal: null,
    totalEarnings: 0,
    popularity: 10,
    morale: 70,
    isLeader: false,
    hasRelationship: false,
    intStats: {
      caps: 0,
      goals: 0,
      assists: 0,
      tournaments: 0,
      worldCups: 0,
      continentals: 0,
      worldCupWins: 0,
      continentalWins: 0,
      isCaptain: false,
      isRetired: false,
      debutYear: null,
      debutAge: null,
      worldCupResults: [],
      squadSnubs: 0,
      failedQualifications: 0
    },
    pendingWorldCup: null,
    pendingTournament: null,
    lastTournament: null,
    intlHistory: [],
    rival: null,
    rivalCreated: false,
    pendingRivalryEvent: null,
    lastRivalryEventId: null,
    rivalrySummary: null,
    netWorth: 0,
    lifestyleLevel: "Humble",
    lifestyleCostPerYear: 0.02,
    socialMediaFollowers: 0,
    sponsorshipIncome: 0,
    properties: [],
    investments: [],
    consecutiveDeficitYears: 0,
    agentFeesPaid: 0,
    family: { isMarried: false, marriedAge: null, children: 0, isDivorced: false, divorceAge: null },
    purchasedItems: [],
    investmentHoldings: [],
    totalAssetValue: 0,
    customYearlyCosts: 0,
    awards: [],
    pendingBallonDor: null,
    lastUCLResult: null,
    legacy: null,
    postRetirementChoice: null,
    managerState: null,
    isFinalSeason: false,
    isPundit: false,
    punditEvents: [],
    primeType: rollPrimeType(),
    socialMediaActionUsedThisSeason: false,
    socialMediaFocusBoost: false,
    pendingCoverAthleteEvent: false,
    coverAthleteAccepted: false,
    activeSponsorship: null,
    personality: null,
    agentId: null,
    lifeFlags: {},
    appearance: appearance ?? null,
    corruptionHeat: 0,
    dirtyMoney: 0,
    prisonSeasons: 0,
    academyClubName: academyClub.name,
    moralDilemmasTriggered: [],
    pendingMoralDilemma: null,
    pedSeasonsRemaining: 0,
    pedActive: false,
    matchFixBanned: 0,
    divingActive: false,
    integrityBonus: 0,
    pendingAppealResult: null,
    childEventsSeen: [],
    pregnancyAnnounced: false,
    punditState: null,
    ownerState: null,
    peakOverall: overall,
    retirementSuggested: false,
    /* Round 130: the phone gets its own random stream so replying to a text
       can never shift the world sim's dice. That is what makes a "did I bother
       messaging" A/B test in the harness honest. */
    phone: {
      threads: [],
      feed: [],
      world: null,
      clubs: {},
      rivalClub: null,
      seed: Math.floor(Math.random() * 4294967295) >>> 0 || 7,
      offers: 0,
      perksTaken: 0
    }
  };
  for (const m of created.phoneInbox ?? []) {
    mirrorLegacyMessage(created, m.id, m.from, m.text, m.year);
  }
  phoneSeasonTick(created, "youth");
  return created;
}
function advanceYouthYear(prev, clubs) {
  const s = repairCareer({ ...prev });
  s.age += 1;
  s.story = archiveSeasonStory(s);
  s.events = [];
  receivePhoneTexts(s, "youth");
  const pot = effectivePotential(s);
  const devY = developmentRate(s);
  s.pace = growStat(s.pace, s.age, true, true, s.primeType, pot, s.overall, devY);
  s.shooting = growStat(s.shooting, s.age, true, false, s.primeType, pot, s.overall, devY);
  s.passing = growStat(s.passing, s.age, true, false, s.primeType, pot, s.overall, devY);
  s.dribbling = growStat(s.dribbling, s.age, true, false, s.primeType, pot, s.overall, devY);
  s.defending = growStat(s.defending, s.age, true, false, s.primeType, pot, s.overall, devY);
  s.physical = growStat(s.physical, s.age, true, false, s.primeType, pot, s.overall, devY);
  s.reflexes = growStat(s.reflexes, s.age, true, false, s.primeType, pot, s.overall, devY);
  s.overall = calcOverall(s, s.position);
  if (applyAcademyFocus(s, pot) > 0) s.overall = calcOverall(s, s.position);
  const lastYear = s.seasons[s.seasons.length - 1].year;
  s.seasons = [...s.seasons, {
    year: lastYear + 1,
    age: s.age,
    club: s.currentClub,
    clubCountry: s.currentClubCountry,
    clubTier: s.currentClubTier,
    apps: rand2(10, 25),
    goals: s.position === "GK" ? 0 : rand2(0, 8),
    assists: rand2(0, 5),
    cleanSheets: s.position === "GK" || s.position === "CB" || s.position === "LB" || s.position === "RB" ? rand2(2, 8) : 0,
    yellowCards: rand2(0, 4),
    redCards: 0,
    rating: 0,
    leagueTitle: false,
    domesticCup: false,
    championsLeague: false,
    worldCup: false,
    ballonDor: false,
    ballonDorRank: null,
    type: "youth",
    intApps: 0,
    intGoals: 0,
    intAssists: 0,
    intRating: 0,
    tournament: null,
    tournamentResult: null
  }];
  s.events.push(`\u{1F4C8} Stats improved during youth development (OVR ${s.overall})`);
  moneySeasonTick2(s, s.seasons[s.seasons.length - 1].year);
  if (s.age >= 17) {
    s.events.push("\u{1F4E9} Professional contract offers received!");
    const academyName = s.academyClubName || (s.currentClub.endsWith(" Youth") ? s.currentClub.slice(0, -6) : void 0);
    s.pendingOffers = generateContractOffers(adjustClubsForYear(clubs, lastYear + 1), s.overall, s.age, academyName);
    s.phase = "contract_offer";
  }
  s.marketValue = calcMarketValue(s.overall, s.age, s.position);
  return s;
}
function acceptOffer(prev, offer2) {
  const s = { ...prev };
  s.currentClub = offer2.club.name;
  s.currentClubCountry = offer2.club.country;
  s.currentClubTier = offer2.club.tier;
  s.currentClubColor = offer2.club.color;
  s.currentLeague = offer2.club.league;
  s.contractYearsLeft = offer2.contractYears;
  s.weeklyWage = Math.round(offer2.wage * agentWageMult(prev.agentId));
  s.frozenOut = 0;
  s.badSeasonStreak = 0;
  s.phase = "playing";
  s.pendingOffers = [];
  s.transferSituation = null;
  s.pendingLoanOffers = null;
  const feeRate = agentTransferCutRate(prev.agentId);
  const agentFee = offer2.transferFee > 0 ? Math.round(offer2.transferFee * feeRate * 100) / 100 : 0;
  if (agentFee > 0) {
    s.agentFeesPaid = Math.round((s.agentFeesPaid + agentFee) * 100) / 100;
    s.events = [...s.events, `\u270D\uFE0F Signed with ${offer2.club.name} ${getFlag(offer2.club.country)} (${offer2.contractYears}yr, ${formatWage(s.weeklyWage)}) \xB7 Agent fee: \u20AC${agentFee.toFixed(1)}M`];
  } else {
    s.events = [...s.events, `\u270D\uFE0F Signed with ${offer2.club.name} ${getFlag(offer2.club.country)} (${offer2.contractYears}yr, ${formatWage(s.weeklyWage)})`];
  }
  endClubCaptaincy(s, "transfer");
  if (offer2.isHomegrown) {
    s.popularity = clamp5(s.popularity + 10, 0, 100);
    s.morale = clamp5(s.morale + 8, 0, 100);
    const cameThrough = prev.academyClubName && offer2.club.name === prev.academyClubName || prev.currentClub === `${offer2.club.name} Youth`;
    s.events.push(cameThrough && prev.currentClub.endsWith(" Youth") ? `\u{1F3E0} One of our own! The ${offer2.club.name} academy kid signs a first-team deal. The ultras already have a chant ready.` : `\u{1F3E0} THE HOMECOMING! ${s.playerName} returns to ${offer2.club.name}, the club that raised them. Scenes outside the stadium.`);
  }
  return s;
}
function endClubCaptaincy(s, reason, year) {
  if (!(s.isClubCaptain ?? false)) return;
  const n = s.captainSeasons ?? 0;
  const club = s.captainClub ?? s.currentClub;
  if (n >= 1) {
    const endYear = year ?? (s.seasons.length > 0 ? s.seasons[s.seasons.length - 1].year : 0);
    s.awards = [...s.awards ?? [], {
      year: endYear,
      name: `Club Captain of ${club} (${n} season${n === 1 ? "" : "s"})`,
      emoji: "\xA9\uFE0F"
    }];
  }
  s.isClubCaptain = false;
  s.captainClub = null;
  if (reason === "transfer") s.events.push(`\xA9\uFE0F The ${club} armband stays behind. A new captain will be chosen`);
  else if (reason === "loan") s.events.push(`\xA9\uFE0F The armband stays at ${club} while he is away`);
  else if (reason === "handover") s.events.push(`\xA9\uFE0F Passed the captaincy on after ${n} season${n === 1 ? "" : "s"} wearing it. The dressing room stood and clapped`);
  else s.events.push(n >= 1 ? `\xA9\uFE0F Retires as a club captain: ${n} season${n === 1 ? "" : "s"} with the ${club} armband` : "\xA9\uFE0F Hands back the armband on the way out");
}
function nextSeasonYear(s) {
  return (s.seasons[s.seasons.length - 1]?.year ?? 0) + 1;
}

// src/data/clubSquads.ts
var CLUB_SQUAD_YEARS = { first: 2016, last: 2026 };
var CLUB_DATA_NAME = {
  "Real Madrid": "Real Madrid",
  "Barcelona": "FC Barcelona",
  "Man City": "Manchester City",
  "Liverpool": "Liverpool FC",
  "Bayern Munich": "Bayern Munich",
  "PSG": "Paris Saint-Germain",
  "Juventus": "Juventus FC",
  "Inter Milan": "Inter Milan",
  "Man United": "Manchester United",
  "Arsenal": "Arsenal FC",
  "Chelsea": "Chelsea FC",
  "Ajax": "Ajax Amsterdam",
  "Benfica": "SL Benfica",
  "Porto": "FC Porto",
  "Boca Juniors": "CA Boca Juniors",
  "River Plate": "CA River Plate",
  "Flamengo": "CR Flamengo",
  "Sao Paulo": "S\xE3o Paulo Futebol Clube",
  "Atletico Madrid": "Atl\xE9tico de Madrid",
  "Sevilla": "Sevilla FC",
  "Tottenham": "Tottenham Hotspur",
  "Newcastle": "Newcastle United",
  "Dortmund": "Borussia Dortmund",
  "Leipzig": "RB Leipzig",
  "AC Milan": "AC Milan",
  "Napoli": "SSC Napoli",
  "Roma": "AS Roma",
  "Marseille": "Olympique Marseille",
  "Lyon": "Olympique Lyon",
  "Feyenoord": "Feyenoord Rotterdam",
  "PSV": "PSV Eindhoven",
  "Sporting CP": "Sporting CP",
  "Fenerbahce": "Fenerbahce",
  "Galatasaray": "Galatasaray",
  "Al Hilal": "Al-Hilal SFC",
  "Celtic": "Celtic FC",
  "Rangers": "Rangers FC",
  "Palmeiras": "Sociedade Esportiva Palmeiras",
  "LA Galaxy": "Los Angeles Galaxy",
  "Inter Miami": "Inter Miami CF",
  "Al Ittihad": "Al-Ittihad Club",
  "Club Brugge": "Club Brugge KV",
  "Olympiacos": "Olympiacos Piraeus",
  "Shakhtar Donetsk": "Shakhtar Donetsk",
  "Corinthians": "Sport Club Corinthians Paulista",
  "Monterrey": "CF Monterrey",
  "Tigres UANL": "Tigres UANL",
  "Athletic Bilbao": "Athletic Bilbao",
  "Brighton": "Brighton & Hove Albion",
  "Stuttgart": "VfB Stuttgart",
  "LAFC": "Los Angeles FC",
  "Racing Club": "Racing Club",
  "Zenit": "Zenit St. Petersburg",
  "Girona": "Girona FC"
};
var CLUB_SQUADS = {
  "AC Milan|2016": "Carlos Bacca:ST:82,Alessio Romagnoli:CB:81,Giacomo Bonaventura:CAM:81,Andrea Bertolacci:CM:79,Gianluigi Donnarumma:GK:79,J\xE9r\xE9my M\xE9nez:ST:79,M'Baye Niang:ST:79,Juraj Kucka:CM:77,Alessio Cerci:RW:76,Ignazio Abate:RB:76,Keisuke Honda:CAM:76,Luca Antonelli:LB:76,Andrea Poli:CM:74,Mattia De Sciglio:RB:74,Jos\xE9 Mauri:CM:73,Riccardo Montolivo:CDM:73,Cristian Zapata:CB:70,Manuel Locatelli:CDM:68",
  "AC Milan|2017": "Gianluigi Donnarumma:GK:85,Alessio Romagnoli:CB:82,Carlos Bacca:ST:82,Giacomo Bonaventura:CAM:82,Suso:CAM:82,Gerard Deulofeu:ST:78,Andrea Bertolacci:CM:77,Juraj Kucka:CM:77,Mattia De Sciglio:RB:77,Gianluca Lapadula:ST:76,Ignazio Abate:RB:76,Manuel Locatelli:CDM:76,Mario Pa\u0161ali\u0107:CM:76,Gabriel Paletta:CB:75,Luca Antonelli:LB:75,Gustavo G\xF3mez:CB:74,Andrea Poli:CM:73,Riccardo Montolivo:CDM:72,Cristian Zapata:CB:70",
  "AC Milan|2018": "Suso:CAM:86,Alessio Romagnoli:CB:85,Gianluigi Donnarumma:GK:85,Andr\xE9 Silva:ST:84,Franck Kessi\xE9:CM:84,Leonardo Bonucci:CB:84,Hakan \xC7alhano\u011Flu:CDM:83,Patrick Cutrone:ST:83,Giacomo Bonaventura:CAM:82,Davide Calabria:RB:80,Nikola Kalini\u0107:ST:80,Ricardo Rodr\xEDguez:LB:80,Andrea Conti:RB:79,Lucas Biglia:CDM:79,Mateo Musacchio:CB:79,Luca Antonelli:LB:68,Riccardo Forte:CF:64",
  "AC Milan|2019": "Gianluigi Donnarumma:GK:87,Alessio Romagnoli:CB:86,Suso:CAM:86,Krzysztof Piatek:ST:85,Franck Kessi\xE9:CM:84,Lucas Paquet\xE1:CAM:84,Tiemou\xE9 Bakayoko:CDM:84,Patrick Cutrone:ST:83,Davide Calabria:RB:81,Hakan \xC7alhano\u011Flu:CDM:81,Mattia Caldara:CB:81,Andrea Conti:RB:80,Ricardo Rodr\xEDguez:LB:80,Samu Castillejo:RW:80,Mateo Musacchio:CB:79,Diego Laxalt:LB:78,Fabio Borini:ST:76,Pepe Reina:GK:64,Raoul Bellanova:RM:64",
  "AC Milan|2020": "Gianluigi Donnarumma:GK:87,Theo Hern\xE1ndez:LB:86,Franck Kessi\xE9:CM:85,Isma\xEBl Bennacer:CDM:85,Alessio Romagnoli:CB:84,Ante Rebi\u0107:LW:84,Hakan \xC7alhano\u011Flu:CDM:84,Lucas Paquet\xE1:CAM:83,Rafael Le\xE3o:LW:83,Alexis Saelemaekers:RM:80,Davide Calabria:RB:80,Samu Castillejo:RW:79,Andrea Conti:RB:78,Giacomo Bonaventura:CAM:78,L\xE9o Duarte:CB:74,Zlatan Ibrahimovi\u0107:ST:73,Asmir Begovic:GK:70",
  "AC Milan|2021": "Gianluigi Donnarumma:GK:88,Franck Kessi\xE9:CM:87,Fikayo Tomori:CB:86,Theo Hern\xE1ndez:LB:86,Isma\xEBl Bennacer:CDM:85,Ante Rebi\u0107:LW:84,Hakan \xC7alhano\u011Flu:CDM:84,Rafael Le\xE3o:LW:84,Alessio Romagnoli:CB:83,Brahim D\xEDaz:RW:82,Davide Calabria:RB:82,Alexis Saelemaekers:RM:81,Diogo Dalot:RB:78,Pierre Kalulu:CB:77,Simon Kjaer:CB:77,Lorenzo Colombo:ST:72,Zlatan Ibrahimovi\u0107:ST:72",
  "AC Milan|2022": "Rafael Le\xE3o:LW:89,Theo Hern\xE1ndez:LB:87,Fikayo Tomori:CB:86,Franck Kessi\xE9:CM:86,Sandro Tonali:CDM:86,Isma\xEBl Bennacer:CDM:85,Mike Maignan:GK:84,Pierre Kalulu:CB:84,Ante Rebi\u0107:LW:82,Brahim D\xEDaz:RW:82,Davide Calabria:RB:82,Alessio Romagnoli:CB:80,Alexis Saelemaekers:RM:80,Matteo Gabbia:CB:76,Alessandro Florenzi:RB:74,Junior Messias:RW:74,Fod\xE9 Ballo-Tour\xE9:LB:72,Olivier Giroud:ST:72,Marko Lazeti\u0107:ST:70",
  "AC Milan|2023": "Rafael Le\xE3o:LW:90,Theo Hern\xE1ndez:LB:87,Fikayo Tomori:CB:86,Mike Maignan:GK:86,Charles De Ketelaere:CAM:83,Malick Thiaw:CB:83,Pierre Kalulu:CB:83,Brahim D\xEDaz:RW:81,Davide Calabria:RB:81,Sergi\xF1o Dest:RB:80,Alexis Saelemaekers:RM:79,Tommaso Pobega:CM:79,Aster Vranckx:CM:78,Ante Rebi\u0107:LW:77,Divock Origi:ST:76,Junior Messias:RW:73,Matteo Gabbia:CB:73,Fod\xE9 Ballo-Tour\xE9:LB:72,Olivier Giroud:ST:72",
  "AC Milan|2024": "Rafael Le\xE3o:LW:90,Theo Hern\xE1ndez:LB:87,Christian Pulisic:RW:86,Tijjani Reijnders:CM:86,Fikayo Tomori:CB:85,Mike Maignan:GK:85,Pierre Kalulu:CB:83,Malick Thiaw:CB:82,Ruben Loftus-Cheek:CM:82,Yunus Musah:CM:82,Matteo Gabbia:CB:81,Noah Okafor:LW:81,Samuel Chukwueze:RW:81,Davide Calabria:RB:79,Tommaso Pobega:CM:77,Luka Jovi\u0107:ST:76,\xC1lex Jim\xE9nez:RB:73,Mattia Liberali:CAM:73",
  "AC Milan|2025": "Rafael Le\xE3o:LW:88,Tijjani Reijnders:CM:88,Christian Pulisic:RW:87,Malick Thiaw:CB:85,Theo Hern\xE1ndez:LB:85,Strahinja Pavlovi\u0107:CB:83,Mike Maignan:GK:82,Fikayo Tomori:CB:81,Matteo Gabbia:CB:81,Yunus Musah:CM:81,\xC1lex Jim\xE9nez:RB:80,Davide Bartesaghi:LB:80,Ruben Loftus-Cheek:CM:80,\xC1lvaro Morata:ST:79,Francesco Camarda:ST:79,Samuel Chukwueze:RW:79,Tammy Abraham:ST:79,Emerson Royal:RB:77",
  "AC Milan|2026": "Rafael Le\xE3o:LW:88,Christian Pulisic:RW:86,Strahinja Pavlovi\u0107:CB:84,Christopher Nkunku:ST:83,Alexis Saelemaekers:RM:82,Davide Bartesaghi:LB:82,Koni De Winter:CB:82,Mike Maignan:GK:82,Adrien Rabiot:CM:81,Fikayo Tomori:CB:81,Matteo Gabbia:CB:81,Santiago Gimenez:ST:81,Pervis Estupi\xF1\xE1n:LB:79,Ruben Loftus-Cheek:CM:77,Zachary Athekame:RB:77,Niclas F\xFCllkrug:ST:73,Luka Modri\u0107:CM:72",
  "AS Roma|2016": "Miralem Pjani\u0107:CM:85,Radja Nainggolan:CM:84,Mohamed Salah:RW:83,Alessandro Florenzi:RB:82,Konstantinos Manolas:CB:82,Lucas Digne:LB:80,Stephan El Shaarawy:LW:80,Edin Dzeko:ST:79,Gervinho:LW:79,Kevin Strootman:CM:79,Antonio R\xFCdiger:CB:78,Wojciech Szcz\u0119sny:GK:78,Daniele De Rossi:CDM:76,Iago Falque:RW:76,Leandro Cast\xE1n:CB:76,William Vainqueur:CDM:73,Vasilios Torosidis:RB:72,Umar Sadiq:ST:70,Francesco Totti:CF:64",
  "AS Roma|2017": "Radja Nainggolan:CM:86,Mohamed Salah:RW:85,Konstantinos Manolas:CB:84,Alessandro Florenzi:RB:82,Antonio R\xFCdiger:CB:82,Edin Dzeko:ST:82,Kevin Strootman:CM:82,Diego Perotti:LW:81,Stephan El Shaarawy:LW:81,Alisson:GK:80,Leandro Paredes:CDM:80,Wojciech Szcz\u0119sny:GK:80,Bruno Peres:RB:79,Emerson:LB:79,Federico Fazio:CB:77,Gerson:CM:77,Juan Jesus:CB:77,M\xE1rio Rui:LB:76,Daniele De Rossi:CDM:73,Cl\xE9ment Grenier:CM:72,Francesco Totti:CF:64",
  "AS Roma|2018": "Alisson:GK:88,Konstantinos Manolas:CB:86,Radja Nainggolan:CM:86,Cengiz \xDCnder:RW:84,Lorenzo Pellegrini:CAM:84,Alessandro Florenzi:RB:83,Kevin Strootman:CM:83,Edin Dzeko:ST:82,Stephan El Shaarawy:LW:82,Diego Perotti:LW:81,Patrik Schick:ST:81,Federico Fazio:CB:79,Gerson:CM:79,Juan Jesus:CB:79,Aleksandar Kolarov:LB:78,Gr\xE9goire Defrel:ST:78,Rick Karsdorp:RB:77,Lukasz Skorupski:GK:76,Maxime Gonalons:CDM:76,Daniele De Rossi:CDM:72",
  "AS Roma|2019": "Konstantinos Manolas:CB:86,Nicol\xF2 Zaniolo:CF:86,Lorenzo Pellegrini:CAM:85,Cengiz \xDCnder:RW:84,Stephan El Shaarawy:LW:83,Alessandro Florenzi:RB:82,Bryan Cristante:CDM:82,Justin Kluivert:CAM:82,Steven Nzonzi:CDM:82,Diego Perotti:LW:79,Edin Dzeko:ST:79,Patrik Schick:ST:79,Juan Jesus:CB:77,Aleksandar Kolarov:LB:76,Robin Olsen:GK:76,Federico Fazio:CB:74,Iv\xE1n Marcano:CB:72",
  "AS Roma|2020": "Nicol\xF2 Zaniolo:CF:87,Lorenzo Pellegrini:CAM:85,Jordan Veretout:CM:83,Amadou Diawara:CDM:82,Gianluca Mancini:CB:82,Justin Kluivert:CAM:82,Leonardo Spinazzola:LB:82,Bryan Cristante:CDM:81,Chris Smalling:CB:81,Henrikh Mkhitaryan:CM:81,Pau L\xF3pez:GK:81,Roger Iba\xF1ez:CB:81,Davide Zappacosta:RM:78,Edin Dzeko:ST:78,Aleksandar Kolarov:LB:75,Diego Perotti:LW:75,Nikola Kalini\u0107:ST:75,Juan Jesus:CB:73,Bruno Peres:RB:70,Antonio Mirante:GK:68",
  "AS Roma|2021": "Lorenzo Pellegrini:CAM:86,Nicol\xF2 Zaniolo:CF:85,Jordan Veretout:CM:84,Gianluca Mancini:CB:83,Leonardo Spinazzola:LB:83,Marash Kumbulla:CB:82,Roger Iba\xF1ez:CB:82,Bryan Cristante:CDM:81,Amadou Diawara:CDM:79,Borja Mayoral:ST:79,Chris Smalling:CB:79,Gonzalo Villar:CM:79,Henrikh Mkhitaryan:CM:79,Rick Karsdorp:RB:79,Pau L\xF3pez:GK:77,Carles P\xE9rez:RW:76,Stephan El Shaarawy:LW:76,Bryan Reynolds:RB:74,Edin Dzeko:ST:73,Riccardo Calafiori:LB:72,Javier Pastore:CAM:68,Antonio Mirante:GK:64",
  "AS Roma|2022": "Lorenzo Pellegrini:CAM:86,Tammy Abraham:ST:86,Nicol\xF2 Zaniolo:CF:84,Roger Iba\xF1ez:CB:83,Gianluca Mancini:CB:82,Jordan Veretout:CM:82,Bryan Cristante:CDM:81,Leonardo Spinazzola:LB:81,Marash Kumbulla:CB:80,Rick Karsdorp:RB:79,S\xE9rgio Oliveira:CM:79,Ainsley Maitland-Niles:RB:77,Eldor Shomurodov:ST:77,Mat\xEDas Vi\xF1a:LB:77,Chris Smalling:CB:76,Henrikh Mkhitaryan:CM:76,Carles P\xE9rez:RW:74,Felix Afena-Gyan:LW:74,Rui Patr\xEDcio:GK:74,Stephan El Shaarawy:LW:74",
  "AS Roma|2023": "Tammy Abraham:ST:85,Lorenzo Pellegrini:CAM:84,Nicol\xF2 Zaniolo:CF:83,Roger Iba\xF1ez:CB:83,Gianluca Mancini:CB:81,Edoardo Bove:CM:79,Diego Llorente:CB:78,Andrea Belotti:ST:77,Leonardo Spinazzola:LB:77,Marash Kumbulla:CB:77,Zeki \xC7elik:RB:77,Georginio Wijnaldum:CM:76,Rick Karsdorp:RB:76,Benjamin Tahirovi\u0107:CM:74,Rui Patr\xEDcio:GK:73,Niccol\xF2 Pisilli:CM:72,Ola Solbakken:RW:72,Mile Svilar:GK:68,Nicola Zalewski:LM:64",
  "AS Roma|2024": "Romelu Lukaku:ST:83,Tammy Abraham:ST:83,Evan Ndicka:CB:82,Gianluca Mancini:CB:82,Lorenzo Pellegrini:CAM:82,Paulo Dybala:CF:81,Dean Huijsen:CB:80,Edoardo Bove:CM:80,Nicola Zalewski:LM:80,Mile Svilar:GK:79,Niccol\xF2 Pisilli:CM:78,Houssem Aouar:CAM:77,Rasmus Kristensen:RB:77,Angeli\xF1o:LB:76,Diego Llorente:CB:76,Renato Sanches:CM:76,Sardar Azmoun:ST:76,Zeki \xC7elik:RB:74,Stephan El Shaarawy:LW:73,Leonardo Spinazzola:LB:72,Rui Patr\xEDcio:GK:68",
  "AS Roma|2025": "Manu Kon\xE9:CM:86,Mat\xEDas Soul\xE9:RW:84,Mile Svilar:GK:84,Artem Dovbyk:ST:83,Evan Ndicka:CB:83,Alexis Saelemaekers:RM:82,Angeli\xF1o:LB:81,Nicola Zalewski:LM:81,Gianluca Mancini:CB:79,Niccol\xF2 Pisilli:CM:79,Tommaso Baldanzi:CAM:78,Zeki \xC7elik:RB:78,Lorenzo Pellegrini:CAM:77,Victor Nelsson:CB:77,Paulo Dybala:CF:76,Eldor Shomurodov:ST:73,Saud Abdulhamid:RB:70",
  "AS Roma|2026": "Manu Kon\xE9:CM:86,Wesley:RB:85,Donyell Malen:ST:84,Evan Ndicka:CB:84,Mat\xEDas Soul\xE9:RW:84,Mile Svilar:GK:84,Evan Ferguson:ST:82,Neil El Aynaoui:CM:81,Niccol\xF2 Pisilli:CM:81,Robinio Vaz:ST:80,Daniele Ghilardi:CB:79,Gianluca Mancini:CB:79,Angeli\xF1o:LB:77,Bryan Zaragoza:LW:77,Lorenzo Pellegrini:CAM:77,Devyne Rensch:RB:76,Konstantinos Tsimikas:LB:76,Mario Hermoso:CB:76,Lorenzo Venturino:RW:73",
  "Ajax Amsterdam|2016": "Arkadiusz Milik:ST:81,Davy Klaassen:CM:79,Riechedly Bazoer:CB:79,Jasper Cillessen:GK:78,Anwar El Ghazi:RW:76,Jo\xEBl Veltman:RB:76,Amin Younes:LW:75,Ja\xEFro Riedewald:CDM:75,Kenny Tete:RB:75,Nemanja Gudelj:CDM:75,Daley Sinkgraven:LB:72,Mitchell Dijks:LB:72,Mike van der Hoorn:CB:70,Donny van de Beek:CM:68,Kasper Dolberg:ST:68,Nick Viergever:CB:68,Vaclav Cerny:RW:68",
  "Ajax Amsterdam|2017": "Davinson S\xE1nchez:CB:82,Davy Klaassen:CM:80,Hakim Ziyech:RW:79,Kasper Dolberg:ST:79,David Neres:RW:77,Amin Younes:LW:76,Andr\xE9 Onana:GK:76,Jo\xEBl Veltman:RB:76,Ja\xEFro Riedewald:CDM:75,Donny van de Beek:CM:74,Kenny Tete:RB:74,Matthijs de Ligt:CB:73,Daley Sinkgraven:LB:72,Frenkie de Jong:CM:72,Lasse Sch\xF6ne:CDM:72,Mateo Cassierra:ST:72,Nick Viergever:CB:72,Abdelhak Nouri:CM:70,Justin Kluivert:CAM:70,Dennis Johnsen:LW:64",
  "Ajax Amsterdam|2018": "Matthijs de Ligt:CB:88,Frenkie de Jong:CM:87,Hakim Ziyech:RW:84,Andr\xE9 Onana:GK:83,David Neres:RW:82,Donny van de Beek:CM:81,Justin Kluivert:CAM:81,Nicol\xE1s Tagliafico:LB:81,Kasper Dolberg:ST:80,Noussair Mazraoui:RB:78,Jo\xEBl Veltman:RB:76,Maximilian W\xF6ber:CB:76,Amin Younes:LW:75,Carel Eiting:CM:72,Lasse Sch\xF6ne:CDM:72,Siem de Jong:CAM:72,Daley Sinkgraven:LB:70,Mateo Cassierra:ST:70,Dennis Johnsen:LW:64,Mitchel Bakker:LM:64",
  "Ajax Amsterdam|2019": "Frenkie de Jong:CM:90,Matthijs de Ligt:CB:89,Donny van de Beek:CM:87,Andr\xE9 Onana:GK:86,David Neres:RW:86,Hakim Ziyech:RW:86,Nicol\xE1s Tagliafico:LB:84,Daley Blind:CB:82,Kasper Dolberg:ST:82,Noussair Mazraoui:RB:80,Sergi\xF1o Dest:RB:78,Hassane Band\xE9:LW:76,Perr Schuurs:CB:76,Lisandro Magall\xE1n:CB:74,Carel Eiting:CM:72,Daley Sinkgraven:LB:72,Lassina Traor\xE9:ST:72,Zakaria Labyad:CAM:72,Bruno Varela:GK:70,Dani de Wit:CAM:70,Noa Lang:LW:70",
  "Ajax Amsterdam|2020": "Donny van de Beek:CM:86,Hakim Ziyech:RW:86,Andr\xE9 Onana:GK:84,David Neres:RW:84,Nicol\xE1s Tagliafico:LB:83,Lisandro Mart\xEDnez:CB:82,Daley Blind:CB:81,Quincy Promes:LW:80,Ryan Gravenberch:CDM:78,Edson \xC1lvarez:CDM:77,R\u0103zvan Marin:CM:77,Jo\xEBl Veltman:RB:76,Lassina Traor\xE9:ST:74,Naci \xDCn\xFCvar:LW:74,Carel Eiting:CM:73,Brian Brobbey:ST:72,Bruno Varela:GK:70,Jurgen Ekkelenkamp:CM:70,Kik Pierie:CB:70,Zakaria Labyad:CAM:70,Siem de Jong:CAM:68",
  "Ajax Amsterdam|2021": "Ryan Gravenberch:CDM:84,Andr\xE9 Onana:GK:83,David Neres:RW:83,Antony:RW:82,Lisandro Mart\xEDnez:CB:82,Nicol\xE1s Tagliafico:LB:82,Davy Klaassen:CM:80,Edson \xC1lvarez:CDM:80,Noussair Mazraoui:RB:80,Daley Blind:CB:79,Quincy Promes:LW:79,Perr Schuurs:CB:78,Devyne Rensch:RB:77,Lassina Traor\xE9:ST:77,Oussama Idrissi:LW:77,Brian Brobbey:ST:76,Jurgen Ekkelenkamp:CM:72,Zakaria Labyad:CAM:72,Kenneth Taylor:CM:70",
  "Ajax Amsterdam|2022": "Antony:RW:89,Jurri\xEBn Timber:RB:86,Lisandro Mart\xEDnez:CB:86,Edson \xC1lvarez:CDM:84,Ryan Gravenberch:CDM:84,S\xE9bastien Haller:ST:84,Noussair Mazraoui:RB:83,Mohammed Kudus:RW:81,Nicol\xE1s Tagliafico:LB:80,Andr\xE9 Onana:GK:79,Brian Brobbey:ST:79,Daley Blind:CB:79,Davy Klaassen:CM:79,Kenneth Taylor:CM:79,Perr Schuurs:CB:78,Mohamed Ihattaren:CAM:73",
  "Ajax Amsterdam|2023": "Mohammed Kudus:RW:86,Jurri\xEBn Timber:RB:85,Jorrel Hato:LB:82,Steven Bergwijn:LW:82,Calvin Bassey:CB:80,Brian Brobbey:ST:79,Kenneth Taylor:CM:78,Steven Berghuis:RW:78,Davy Klaassen:CM:77,Ger\xF3nimo Rulli:GK:77,Owen Wijndal:LB:77,Lorenzo Lucca:ST:74,Ahmetcan Kaplan:CB:73,Jorge S\xE1nchez:RB:73,Kristian Hlynsson:CAM:73,Mika Godts:LW:68",
  "Ajax Amsterdam|2024": "Brian Brobbey:ST:84,Jorrel Hato:LB:83,Diant Ramaj:GK:80,Josip Sutalo:CB:80,Kenneth Taylor:CM:80,Steven Bergwijn:LW:80,Chuba Akpom:ST:78,Devyne Rensch:RB:78,Ahmetcan Kaplan:CB:77,Mika Godts:LW:77,Borna Sosa:LB:76,Branco van den Boomen:CM:76,Carlos Forbs:RW:76,Kristian Hlynsson:CAM:76,Ger\xF3nimo Rulli:GK:74,Steven Berghuis:RW:74,Kian Fitz-Jim:CM:73,Anton Gaaei:RB:72",
  "Ajax Amsterdam|2025": "Jorrel Hato:LB:85,Brian Brobbey:ST:83,Kenneth Taylor:CM:83,Josip Sutalo:CB:82,Takehiro Tomiyasu:RB:82,Youri Baas:CB:80,Devyne Rensch:RB:77,Bertrand Traor\xE9:RW:76,Vitezslav Jaros:GK:74,Ahmetcan Kaplan:CB:73,Kian Fitz-Jim:CM:73,Owen Wijndal:LB:73,Branco van den Boomen:CM:72,Davy Klaassen:CM:72,Steven Berghuis:RW:72,Wout Weghorst:ST:72,Matheus:GK:70",
  "Ajax Amsterdam|2026": "Mika Godts:LW:82,Youri Baas:CB:81,Josip Sutalo:CB:79,Oscar Gloukh:CAM:79,Kasper Dolberg:ST:77,Ko Itakura:CB:77,Maher Carrizo:RW:77,Oleksandr Zinchenko:LB:77,Takehiro Tomiyasu:RB:76,Sean Steur:CM:74,Anton Gaaei:RB:73,Ra\xFAl Moro:LW:73,Rayane Bounida:CAM:73,Vitezslav Jaros:GK:73,Kian Fitz-Jim:CM:72,Owen Wijndal:LB:72,Maarten Paes:GK:68",
  "Arsenal FC|2016": "Alexis S\xE1nchez:CF:87,Mesut \xD6zil:CAM:86,Aaron Ramsey:CM:84,Olivier Giroud:ST:83,Jack Wilshere:CM:82,Laurent Koscielny:CB:82,Santi Cazorla:CM:82,Theo Walcott:RW:82,Alex Oxlade-Chamberlain:CM:81,H\xE9ctor Beller\xEDn:RB:81,Danny Welbeck:ST:80,Francis Coquelin:CDM:79,Kieran Gibbs:LB:79,Nacho Monreal:LB:79,Per Mertesacker:CB:79,Calum Chambers:CB:78,Gabriel Paulista:CB:78,Petr Cech:GK:78,Alex Iwobi:LW:76,David Ospina:GK:76,Mohamed Elneny:CDM:76,Ramiro Carrera:RM:70,Gonzalo Baz\xE1n:LM:64,Mariano Barbieri:LW:64",
  "Arsenal FC|2017": "Alexis S\xE1nchez:CF:88,Mesut \xD6zil:CAM:86,Aaron Ramsey:CM:84,Granit Xhaka:CDM:84,Alex Oxlade-Chamberlain:CM:83,H\xE9ctor Beller\xEDn:RB:83,Shkodran Mustafi:CB:83,Laurent Koscielny:CB:82,Olivier Giroud:ST:82,Theo Walcott:RW:82,Danny Welbeck:ST:80,Lucas P\xE9rez:ST:80,Francis Coquelin:CDM:79,Gabriel Paulista:CB:79,Nacho Monreal:LB:79,Alex Iwobi:LW:77,Kieran Gibbs:LB:77,Petr Cech:GK:77,David Ospina:GK:76,Per Mertesacker:CB:76,Carl Jenkinson:RB:74,Juan Brunetta:CAM:68,Gonzalo Baz\xE1n:LM:64",
  "Arsenal FC|2018": "Alexandre Lacazette:ST:88,Alexis S\xE1nchez:CF:88,Aaron Ramsey:CM:86,Granit Xhaka:CDM:86,Mesut \xD6zil:CAM:86,H\xE9ctor Beller\xEDn:RB:85,Henrikh Mkhitaryan:CM:84,Shkodran Mustafi:CB:83,Alex Iwobi:LW:82,Jack Wilshere:CM:81,Laurent Koscielny:CB:81,Olivier Giroud:ST:81,Sead Kolasinac:CB:81,Theo Walcott:RW:81,Reiss Nelson:LW:80,Calum Chambers:CB:79,Danny Welbeck:ST:79,Nacho Monreal:LB:79,Mohamed Elneny:CDM:77,Ainsley Maitland-Niles:RB:76,Petr Cech:GK:74,David Ospina:GK:73,Gabriel Alan\xEDs:LM:64",
  "Arsenal FC|2019": "Alexandre Lacazette:ST:88,Pierre-Emerick Aubameyang:ST:88,Lucas Torreira:CDM:87,Granit Xhaka:CDM:86,Matt\xE9o Guendouzi:CM:86,Aaron Ramsey:CM:85,H\xE9ctor Beller\xEDn:RB:85,Alex Iwobi:LW:84,Bernd Leno:GK:84,Henrikh Mkhitaryan:CM:82,Mesut \xD6zil:CAM:82,Shkodran Mustafi:CB:82,Sead Kolasinac:CB:81,Sokratis:CB:81,Ainsley Maitland-Niles:RB:80,Gabriel Martinelli:LW:80,Joe Willock:CM:80,Bukayo Saka:RW:79,Denis Su\xE1rez:CAM:78,Rob Holding:CB:78,Eddie Nketiah:ST:76,Nacho Monreal:LB:76,Xavier Amaechi:RW:72",
  "Arsenal FC|2020": "Alexandre Lacazette:ST:87,Pierre-Emerick Aubameyang:ST:87,Matt\xE9o Guendouzi:CM:86,Nicolas P\xE9p\xE9:RW:86,Bukayo Saka:RW:85,Bernd Leno:GK:84,Dani Ceballos:CM:84,H\xE9ctor Beller\xEDn:RB:84,Kieran Tierney:LB:84,Lucas Torreira:CDM:84,Gabriel Martinelli:LW:83,Granit Xhaka:CDM:83,Eddie Nketiah:ST:81,Ainsley Maitland-Niles:RB:80,Emiliano Mart\xEDnez:GK:80,Joe Willock:CM:80,Mesut \xD6zil:CAM:80,Sead Kolasinac:CB:80,Reiss Nelson:LW:79,Nicol\xE1s Gim\xE9nez:CAM:68",
  "Arsenal FC|2021": "Bukayo Saka:RW:88,Thomas Partey:CDM:86,Emile Smith Rowe:CAM:85,Martin \xD8degaard:CAM:85,Nicolas P\xE9p\xE9:RW:85,Alexandre Lacazette:ST:84,Kieran Tierney:LB:84,Pierre-Emerick Aubameyang:ST:84,Dani Ceballos:CM:83,Gabriel Martinelli:LW:83,Bernd Leno:GK:82,Gabriel:CB:82,Granit Xhaka:CDM:82,H\xE9ctor Beller\xEDn:RB:82,Joe Willock:CM:82,Ainsley Maitland-Niles:RB:80,Eddie Nketiah:ST:80,Rob Holding:CB:80,Calum Chambers:CB:78,Willian:LW:78,Pablo Mar\xED:CB:76,Mathew Ryan:GK:74,Ramiro Luna:RM:64",
  "Arsenal FC|2022": "Bukayo Saka:RW:90,Gabriel Martinelli:LW:87,Martin \xD8degaard:CAM:87,Ben White:RB:86,Emile Smith Rowe:CAM:85,Gabriel:CB:85,Thomas Partey:CDM:85,Kieran Tierney:LB:84,Aaron Ramsdale:GK:83,Granit Xhaka:CDM:83,Takehiro Tomiyasu:RB:82,Eddie Nketiah:ST:80,Nuno Tavares:LB:80,Albert Sambi Lokonga:CM:79,Alexandre Lacazette:ST:79,Bernd Leno:GK:77,Rob Holding:CB:77,Charlie Pati\xF1o:CM:72",
  "Arsenal FC|2023": "Bukayo Saka:RW:91,Martin \xD8degaard:CAM:90,Gabriel Jesus:ST:89,Gabriel Martinelli:LW:89,William Saliba:CB:89,Ben White:RB:87,Gabriel:CB:87,Aaron Ramsdale:GK:85,Leandro Trossard:LW:85,Oleksandr Zinchenko:LB:85,Eddie Nketiah:ST:84,F\xE1bio Vieira:CAM:83,Takehiro Tomiyasu:RB:83,Jakub Kiwior:CB:82,Kieran Tierney:LB:82,Matt Turner:GK:77,Rob Holding:CB:76,Ethan Nwaneri:CAM:74,Amario Cozier-Duberry:RW:68",
  "Arsenal FC|2024": "Bukayo Saka:RW:92,Declan Rice:CM:91,Martin \xD8degaard:CAM:91,Gabriel:CB:89,Gabriel Martinelli:LW:89,Kai Havertz:ST:89,William Saliba:CB:89,Gabriel Jesus:ST:88,Ben White:RB:87,Jurri\xEBn Timber:RB:86,David Raya:GK:85,Oleksandr Zinchenko:LB:85,Emile Smith Rowe:CAM:84,Eddie Nketiah:ST:83,Jakub Kiwior:CB:83,Aaron Ramsdale:GK:82,Reiss Nelson:LW:80,Myles Lewis-Skelly:LB:77,Amario Cozier-Duberry:RW:68",
  "Arsenal FC|2025": "Bukayo Saka:RW:92,Declan Rice:CM:91,Martin \xD8degaard:CAM:90,William Saliba:CB:90,Gabriel:CB:89,Jurri\xEBn Timber:RB:88,Kai Havertz:ST:88,Ethan Nwaneri:CAM:87,Gabriel Martinelli:LW:87,Ben White:RB:86,Myles Lewis-Skelly:LB:86,Riccardo Calafiori:LB:86,David Raya:GK:85,Gabriel Jesus:ST:85,Mikel Merino:CM:84,Jakub Kiwior:CB:83,Leandro Trossard:LW:82,Raheem Sterling:RW:79,Neto:GK:68,Valent\xEDn Serrano:LM:64",
  "Arsenal FC|2026": "Bukayo Saka:RW:91,Declan Rice:CM:91,William Saliba:CB:90,Gabriel:CB:89,Jurri\xEBn Timber:RB:88,Martin \xD8degaard:CAM:88,Viktor Gy\xF6keres:ST:88,Eberechi Eze:CAM:87,Gabriel Martinelli:LW:86,Kai Havertz:ST:86,Noni Madueke:RW:86,Piero Hincapi\xE9:CB:86,Riccardo Calafiori:LB:86,Cristhian Mosquera:CB:84,David Raya:GK:84,Myles Lewis-Skelly:LB:84,Ben White:RB:83,Mikel Merino:CM:83,Gabriel Jesus:ST:81,Leandro Trossard:LW:81,Kepa Arrizabalaga:GK:76,Valent\xEDn Serrano:LM:64",
  "Athletic Bilbao|2016": "Aymeric Laporte:CB:82,I\xF1aki Williams:RW:81,Iker Muniain:LW:79,Ra\xFAl Garc\xEDa:CAM:78,Markel Susaeta:RW:77,Mikel San Jos\xE9:CDM:77,Ander Iturraspe:CDM:76,\xD3scar de Marcos:RB:76,Mikel Balenziaga:LB:73,Mikel Rico:CM:73,Xabi Etxeita:CB:72,Aritz Aduriz:ST:70,Iago Herrer\xEDn:GK:70,I\xF1igo Lekue:RB:70,Sabin Merino:ST:70,Gorka Iraizoz:GK:68",
  "Athletic Bilbao|2017": "Aymeric Laporte:CB:82,I\xF1aki Williams:RW:82,Iker Muniain:LW:79,Yeray \xC1lvarez:CB:79,Mikel San Jos\xE9:CDM:78,Ra\xFAl Garc\xEDa:CAM:78,Markel Susaeta:RW:77,Be\xF1at Etxebarria:CM:76,Kepa Arrizabalaga:GK:76,\xD3scar de Marcos:RB:76,Ander Iturraspe:CDM:73,Mikel Balenziaga:LB:73,I\xF1igo Lekue:RB:72,Xabi Etxeita:CB:72,Aritz Aduriz:ST:70,Mikel Rico:CM:70,Sabin Merino:ST:70,Javi Eraso:CM:68,Gorka Iraizoz:GK:64",
  "Athletic Bilbao|2018": "Kepa Arrizabalaga:GK:87,I\xF1aki Williams:RW:83,Unai N\xFA\xF1ez:CB:79,Yeray \xC1lvarez:CB:79,Iker Muniain:LW:77,Markel Susaeta:RW:77,Mikel San Jos\xE9:CDM:77,Ra\xFAl Garc\xEDa:CAM:77,I\xF1igo Lekue:RB:76,\xD3scar de Marcos:RB:74,Ander Iturraspe:CDM:73,Be\xF1at Etxebarria:CM:73,I\xF1igo C\xF3rdoba:LW:73,Iago Herrer\xEDn:GK:72",
  "Athletic Bilbao|2019": "I\xF1aki Williams:RW:86,I\xF1igo Mart\xEDnez:CB:84,Yeray \xC1lvarez:CB:83,Yuri Berchiche:LB:81,Iker Muniain:LW:80,Unai N\xFA\xF1ez:CB:79,Ander Capa:RB:76,Mikel San Jos\xE9:CDM:76,Ra\xFAl Garc\xEDa:CAM:76,Dani Garc\xEDa:CDM:74,Markel Susaeta:RW:74,\xD3scar de Marcos:RB:74,Be\xF1at Etxebarria:CM:72,Iago Herrer\xEDn:GK:72,Mikel Balenziaga:LB:68",
  "Athletic Bilbao|2020": "I\xF1aki Williams:RW:85,I\xF1igo Mart\xEDnez:CB:83,Unai Sim\xF3n:GK:83,Yeray \xC1lvarez:CB:82,Unai N\xFA\xF1ez:CB:81,Yuri Berchiche:LB:80,Iker Muniain:LW:79,Unai L\xF3pez:CM:77,Ander Capa:RB:74,Ra\xFAl Garc\xEDa:CAM:74,Dani Garc\xEDa:CDM:73,Mikel San Jos\xE9:CDM:73,Asier Villalibre:ST:72,Be\xF1at Etxebarria:CM:70,Iago Herrer\xEDn:GK:70,Ibai G\xF3mez:LW:70,\xD3scar de Marcos:RB:70,Mikel Balenziaga:LB:68,Unai Vencedor:CM:68",
  "Athletic Bilbao|2021": "Unai Sim\xF3n:GK:83,I\xF1aki Williams:RW:82,I\xF1igo Mart\xEDnez:CB:82,Unai N\xFA\xF1ez:CB:81,Yeray \xC1lvarez:CB:81,Yuri Berchiche:LB:80,\xC1lex Berenguer:LW:79,Iker Muniain:LW:79,Unai L\xF3pez:CM:78,Unai Vencedor:CM:77,Ander Capa:RB:76,Dani Garc\xEDa:CDM:72,Ra\xFAl Garc\xEDa:CAM:72,I\xF1igo Lekue:RB:70,Mikel Vesga:CDM:68,Mikel Balenziaga:LB:64",
  "Athletic Bilbao|2022": "I\xF1aki Williams:RW:82,I\xF1igo Mart\xEDnez:CB:82,Nico Williams:LW:82,Unai Sim\xF3n:GK:82,Oihan Sancet:CAM:81,Unai Vencedor:CM:81,Iker Muniain:LW:80,Dani Vivian:CB:79,Yeray \xC1lvarez:CB:79,Unai N\xFA\xF1ez:CB:77,Mikel Vesga:CDM:73,Oier Zarraga:CM:72,Ander Capa:RB:70,Asier Villalibre:ST:70,I\xF1igo Lekue:RB:70,Ra\xFAl Garc\xEDa:CAM:70,Peru Nolaskoain:CDM:68,Mikel Balenziaga:LB:64",
  "Athletic Bilbao|2023": "Nico Williams:LW:86,Oihan Sancet:CAM:84,I\xF1aki Williams:RW:82,Unai Sim\xF3n:GK:82,Dani Vivian:CB:81,\xC1lex Berenguer:LW:79,Yeray \xC1lvarez:CB:79,Aitor Paredes:CB:78,Gorka Guruzeta:ST:77,I\xF1igo Mart\xEDnez:CB:77,Unai Vencedor:CM:77,Ander Herrera:CM:70,Ander Herrera (dup):CM:70,I\xF1igo Lekue:RB:70,Oier Zarraga:CM:70,Ander Capa:RB:68",
  "Athletic Bilbao|2024": "Nico Williams:LW:88,Oihan Sancet:CAM:86,Dani Vivian:CB:85,Unai Sim\xF3n:GK:83,Aitor Paredes:CB:82,I\xF1aki Williams:RW:82,Be\xF1at Prados:CM:81,Gorka Guruzeta:ST:80,Julen Agirrezabala:GK:79,\xC1lex Berenguer:LW:78,Mikel Jauregizar:CM:77,Unai G\xF3mez:CAM:76,Yeray \xC1lvarez:CB:76,I\xF1igo Ruiz de Galarreta:CM:73,I\xF1igo Lekue:RB:70,Adu Ares:RW:68,\xD3scar de Marcos:RB:68,Yuri Berchiche:LB:68,Imanol Garc\xEDa de Alb\xE9niz:LB:64",
  "Athletic Bilbao|2025": "Nico Williams:LW:88,Oihan Sancet:CAM:87,Dani Vivian:CB:85,Mikel Jauregizar:CM:83,Unai Sim\xF3n:GK:83,Aitor Paredes:CB:82,Be\xF1at Prados:CM:80,I\xF1aki Williams:RW:79,Julen Agirrezabala:GK:79,Gorka Guruzeta:ST:78,\xC1lex Berenguer:LW:77,Maroan Sannadi:ST:77,Yeray \xC1lvarez:CB:76,Unai G\xF3mez:CAM:74,Andoni Gorosabel:RB:73,Selton S\xE1nchez:CM:70,I\xF1igo Lekue:RB:68,Yuri Berchiche:LB:68",
  "Athletic Bilbao|2026": "Nico Williams:LW:86,Mikel Jauregizar:CM:84,Oihan Sancet:CAM:84,Dani Vivian:CB:82,Unai Sim\xF3n:GK:82,Be\xF1at Prados:CM:80,Aitor Paredes:CB:79,Aymeric Laporte:CB:77,I\xF1aki Williams:RW:77,Jes\xFAs Areso:RB:76,Robert Navarro:RW:74,Gorka Guruzeta:ST:73,Maroan Sannadi:ST:73,Unai G\xF3mez:CAM:73,Andoni Gorosabel:RB:72,Adama Boiro:LB:70,Alejandro Rego:CM:70,\xC1lex Padilla:GK:70,Selton S\xE1nchez:CM:70",
  "Atl\xE9tico de Madrid|2016": "Antoine Griezmann:CF:89,Koke:CM:87,Diego God\xEDn:CB:85,Jan Oblak:GK:84,Sa\xFAl \xD1\xEDguez:CM:84,Jos\xE9 Mar\xEDa Gim\xE9nez:CB:83,Yannick Carrasco:LW:83,Filipe Lu\xEDs:LB:82,Stefan Savic:CB:82,Jackson Mart\xEDnez:ST:80,Juanfran Torres:RB:80,Luciano Vietto:ST:80,\xD3liver Torres:CM:79,Fernando Torres:ST:77,Gabi:CM:77,Lucas Hern\xE1ndez:LB:77,Mat\xEDas Kranevitter:CDM:74,Miguel \xC1ngel Moy\xE1:GK:73,Thomas Partey:CDM:73,Jes\xFAs G\xE1mez:RB:72",
  "Atl\xE9tico de Madrid|2017": "Antoine Griezmann:CF:89,Koke:CM:87,Diego God\xEDn:CB:85,Jan Oblak:GK:85,Sa\xFAl \xD1\xEDguez:CM:85,Yannick Carrasco:LW:85,Jos\xE9 Mar\xEDa Gim\xE9nez:CB:83,Stefan Savic:CB:83,Filipe Lu\xEDs:LB:82,K\xE9vin Gameiro:ST:82,Nico Gait\xE1n:CAM:82,Sime Vrsaljko:RB:80,Juanfran Torres:RB:79,Lucas Hern\xE1ndez:LB:79,Augusto Fern\xE1ndez:CM:74,Fernando Torres:ST:74,Gabi:CM:74,Alessio Cerci:RW:73,Thomas Partey:CDM:73,Miguel \xC1ngel Moy\xE1:GK:70",
  "Atl\xE9tico de Madrid|2018": "Antoine Griezmann:CF:92,Sa\xFAl \xD1\xEDguez:CM:90,Jan Oblak:GK:89,Koke:CM:88,Diego Costa:ST:87,Lucas Hern\xE1ndez:LB:87,Jos\xE9 Mar\xEDa Gim\xE9nez:CB:86,Stefan Savic:CB:85,Thomas Partey:CDM:85,Yannick Carrasco:LW:85,Diego God\xEDn:CB:84,Sime Vrsaljko:RB:82,Vitolo:LW:82,K\xE9vin Gameiro:ST:81,Filipe Lu\xEDs:LB:80,Nico Gait\xE1n:CAM:79,Juanfran Torres:RB:76,Augusto Fern\xE1ndez:CM:72,Fernando Torres:ST:72,Gabi:CM:70,Axel Werner:GK:64",
  "Atl\xE9tico de Madrid|2019": "Antoine Griezmann:CF:92,Jan Oblak:GK:90,Sa\xFAl \xD1\xEDguez:CM:90,Rodri:CDM:89,Jos\xE9 Mar\xEDa Gim\xE9nez:CB:88,Koke:CM:88,Lucas Hern\xE1ndez:LB:88,Thomas Lemar:CAM:86,Thomas Partey:CDM:86,Stefan Savic:CB:84,Diego Costa:ST:82,Diego God\xEDn:CB:81,Santiago Arias:RB:80,Vitolo:LW:80,Javi Montero:CB:77,Nikola Kalini\u0107:ST:77,V\xEDctor Mollejo:RW:73,Filipe Lu\xEDs:LB:70,Antonio Ad\xE1n:GK:68",
  "Atl\xE9tico de Madrid|2020": "Jan Oblak:GK:90,Jo\xE3o F\xE9lix:CF:90,Jos\xE9 Mar\xEDa Gim\xE9nez:CB:88,Sa\xFAl \xD1\xEDguez:CM:88,Koke:CM:87,\xC1lvaro Morata:ST:86,Marcos Llorente:RB:86,Renan Lodi:LB:86,Thomas Partey:CDM:86,Felipe:CB:84,Kieran Trippier:RB:83,Stefan Savic:CB:83,Mario Hermoso:CB:82,Thomas Lemar:CAM:82,Yannick Carrasco:LW:82,H\xE9ctor Herrera:CM:80,Diego Costa:ST:79,Vitolo:LW:79,Manu S\xE1nchez:LB:76,Antonio Ad\xE1n:GK:64",
  "Atl\xE9tico de Madrid|2021": "Jan Oblak:GK:90,Jo\xE3o F\xE9lix:CF:90,Marcos Llorente:RB:89,Jos\xE9 Mar\xEDa Gim\xE9nez:CB:88,Koke:CM:87,Sa\xFAl \xD1\xEDguez:CM:87,Renan Lodi:LB:85,Thomas Lemar:CAM:85,Yannick Carrasco:LW:85,Mario Hermoso:CB:84,Lucas Torreira:CDM:83,Moussa Demb\xE9l\xE9:ST:83,Stefan Savic:CB:82,Felipe:CB:81,Kieran Trippier:RB:81,Geoffrey Kondogbia:CDM:79,Luis Su\xE1rez:ST:79,H\xE9ctor Herrera:CM:76,Vitolo:LW:76",
  "Atl\xE9tico de Madrid|2022": "Jo\xE3o F\xE9lix:CF:88,Jan Oblak:GK:86,Jos\xE9 Mar\xEDa Gim\xE9nez:CB:86,Marcos Llorente:RB:86,Rodrigo De Paul:CM:85,Thomas Lemar:CAM:85,Yannick Carrasco:LW:85,Koke:CM:84,Matheus Cunha:ST:83,Renan Lodi:LB:83,Mario Hermoso:CB:82,Geoffrey Kondogbia:CDM:81,Stefan Savic:CB:80,Felipe:CB:76,H\xE9ctor Herrera:CM:73,Sime Vrsaljko:RB:73",
  "Atl\xE9tico de Madrid|2023": "Nahuel Molina:RB:86,Rodrigo De Paul:CM:85,\xC1ngel Correa:CF:84,Jan Oblak:GK:84,Jos\xE9 Mar\xEDa Gim\xE9nez:CB:84,Marcos Llorente:RB:84,Mario Hermoso:CB:82,Pablo Barrios:CM:82,Reinildo Mandava:LB:82,Thomas Lemar:CAM:82,Yannick Carrasco:LW:82,\xC1lvaro Morata:ST:81,Koke:CM:80,Sergio Reguil\xF3n:LB:79,Sa\xFAl \xD1\xEDguez:CM:78,Stefan Savic:CB:76,Ivo Grbic:GK:72",
  "Atl\xE9tico de Madrid|2024": "Pablo Barrios:CM:86,Nahuel Molina:RB:84,Jan Oblak:GK:83,Marcos Llorente:RB:83,Rodrigo De Paul:CM:83,Samuel Lino:LW:83,Antoine Griezmann:CF:82,Jos\xE9 Mar\xEDa Gim\xE9nez:CB:82,Mario Hermoso:CB:82,Rodrigo Riquelme:LW:82,\xC1lvaro Morata:ST:80,Koke:CM:78,Reinildo Mandava:LB:78,Sa\xFAl \xD1\xEDguez:CM:76",
  "Atl\xE9tico de Madrid|2025": "Juli\xE1n Alvarez:ST:90,Pablo Barrios:CM:87,Conor Gallagher:CM:85,Robin Le Normand:CB:85,Alexander S\xF8rloth:ST:82,Marcos Llorente:RB:82,Rodrigo De Paul:CM:82,Samuel Lino:LW:82,Jan Oblak:GK:81,Jos\xE9 Mar\xEDa Gim\xE9nez:CB:81,Nahuel Molina:RB:81,Antoine Griezmann:CF:80,Rodrigo Riquelme:LW:80,Cl\xE9ment Lenglet:CB:76,Koke:CM:76,Reinildo Mandava:LB:73,Thomas Lemar:CAM:73,Javi Gal\xE1n:LB:72,Juan Musso:GK:72",
  "Atl\xE9tico de Madrid|2026": "Juli\xE1n Alvarez:ST:90,Pablo Barrios:CM:87,\xC1lex Baena:LW:86,Giuliano Simeone:RW:85,D\xE1vid Hancko:CB:84,Marc Pubill:CB:83,Johnny Cardoso:CM:82,Marcos Llorente:RB:82,Nico Gonz\xE1lez:LW:82,Robin Le Normand:CB:82,Alexander S\xF8rloth:ST:81,Matteo Ruggeri:LB:81,Jan Oblak:GK:80,Nahuel Molina:RB:79,Jos\xE9 Mar\xEDa Gim\xE9nez:CB:78,Obed Vargas:CM:76,Koke:CM:74,Juan Musso:GK:70,Julio D\xEDaz:LB:68",
  "Bayern Munich|2016": "Robert Lewandowski:ST:89,Thomas M\xFCller:CF:89,David Alaba:CB:86,J\xE9r\xF4me Boateng:CB:86,Manuel Neuer:GK:86,Arturo Vidal:CM:85,Mario G\xF6tze:CAM:85,Douglas Costa:RW:84,Javi Mart\xEDnez:CB:82,Thiago Alc\xE1ntara:CM:82,Arjen Robben:RW:81,Joshua Kimmich:CDM:81,Kingsley Coman:LW:81,Juan Bernat:LB:80,Medhi Benatia:CB:80,Philipp Lahm:RB:80,Franck Rib\xE9ry:LW:77,Sebastian Rode:CM:77,Xabi Alonso:CDM:73,Sven Ulreich:GK:72",
  "Bayern Munich|2017": "Robert Lewandowski:ST:89,Thomas M\xFCller:CF:87,Manuel Neuer:GK:86,Thiago Alc\xE1ntara:CM:86,Arturo Vidal:CM:85,David Alaba:CB:85,J\xE9r\xF4me Boateng:CB:85,Joshua Kimmich:CDM:85,Mats Hummels:CB:85,Douglas Costa:RW:84,Javi Mart\xEDnez:CB:84,Kingsley Coman:LW:84,Renato Sanches:CM:83,Juan Bernat:LB:80,Philipp Lahm:RB:78,Arjen Robben:RW:77,Franck Rib\xE9ry:LW:76,Xabi Alonso:CDM:72,Sven Ulreich:GK:70",
  "Bayern Munich|2018": "Robert Lewandowski:ST:90,James Rodr\xEDguez:CAM:89,David Alaba:CB:87,Joshua Kimmich:CDM:87,Mats Hummels:CB:87,Thiago Alc\xE1ntara:CM:87,Thomas M\xFCller:CF:87,Corentin Tolisso:CM:86,J\xE9r\xF4me Boateng:CB:86,Kingsley Coman:LW:86,Niklas S\xFCle:CB:86,Arturo Vidal:CM:84,Manuel Neuer:GK:84,Sandro Wagner:ST:79,Sebastian Rudy:CDM:79,Juan Bernat:LB:78,Arjen Robben:RW:76,Sven Ulreich:GK:74",
  "Bayern Munich|2019": "Joshua Kimmich:CDM:89,Serge Gnabry:CF:89,David Alaba:CB:88,Robert Lewandowski:ST:88,Thiago Alc\xE1ntara:CM:88,Kingsley Coman:LW:87,Niklas S\xFCle:CB:87,James Rodr\xEDguez:CAM:86,Leon Goretzka:CM:86,Corentin Tolisso:CM:85,Mats Hummels:CB:84,Javi Mart\xEDnez:CB:83,Alphonso Davies:LB:82,Manuel Neuer:GK:80,Renato Sanches:CM:80,Sven Ulreich:GK:73,Arjen Robben:RW:72,Franck Rib\xE9ry:LW:72",
  "Bayern Munich|2020": "Serge Gnabry:CF:90,Alphonso Davies:LB:89,Joshua Kimmich:CDM:89,David Alaba:CB:88,Leon Goretzka:CM:87,Lucas Hern\xE1ndez:LB:87,Philippe Coutinho:CAM:87,Robert Lewandowski:ST:87,Benjamin Pavard:CB:86,Kingsley Coman:LW:86,Niklas S\xFCle:CB:86,Thiago Alc\xE1ntara:CM:86,Corentin Tolisso:CM:84,\xC1lvaro Odriozola:RB:80,Ivan Peri\u0161i\u0107:LW:80,Javi Mart\xEDnez:CB:80,Manuel Neuer:GK:80,Jamal Musiala:CAM:77,Micha\xEBl Cuisance:CM:77,Sven Ulreich:GK:72",
  "Bayern Munich|2021": "Joshua Kimmich:CDM:90,Alphonso Davies:LB:89,Kingsley Coman:LW:88,Leon Goretzka:CM:88,Leroy San\xE9:RW:88,Serge Gnabry:CF:88,David Alaba:CB:87,Jamal Musiala:CAM:87,Robert Lewandowski:ST:87,Lucas Hern\xE1ndez:LB:86,Niklas S\xFCle:CB:85,Benjamin Pavard:CB:84,Corentin Tolisso:CM:82,Manuel Neuer:GK:80,Douglas Costa:RW:78,Marc Roca:CDM:78,Tanguy Nianzou:CB:78,Alexander N\xFCbel:GK:75,Bouna Sarr:RB:74,Eric-Maxim Choupo-Moting:ST:72,Josip Stanisic:RB:72,Tiago Dantas:CM:72",
  "Bayern Munich|2022": "Jamal Musiala:CAM:90,Joshua Kimmich:CDM:89,Alphonso Davies:LB:88,Leon Goretzka:CM:88,Leroy San\xE9:RW:88,Serge Gnabry:CF:88,Dayot Upamecano:CB:87,Kingsley Coman:LW:87,Lucas Hern\xE1ndez:LB:86,Robert Lewandowski:ST:86,Benjamin Pavard:CB:84,Niklas S\xFCle:CB:84,Marcel Sabitzer:CM:82,Corentin Tolisso:CM:79,Manuel Neuer:GK:79,Marc Roca:CDM:78,Tanguy Nianzou:CB:77,Josip Stanisic:RB:76,Eric-Maxim Choupo-Moting:ST:74,Bouna Sarr:RB:70,Gabriel Vidovic:LW:70,Malik Tillman:CAM:70,Christian Fr\xFCchtl:GK:64",
  "Bayern Munich|2023": "Jamal Musiala:CAM:91,Leroy San\xE9:RW:89,Matthijs de Ligt:CB:89,Alphonso Davies:LB:88,Kingsley Coman:LW:88,Dayot Upamecano:CB:87,Serge Gnabry:CF:87,Leon Goretzka:CM:86,Mathys Tel:ST:86,Sadio Man\xE9:LW:86,Benjamin Pavard:CB:85,Noussair Mazraoui:RB:83,Josip Stanisic:RB:78,Manuel Neuer:GK:76,Eric-Maxim Choupo-Moting:ST:73,Yann Sommer:GK:73,Arijon Ibrahimovic:CAM:72,Frans Kr\xE4tzig:LB:68,Christopher Scott:LM:65",
  "Bayern Munich|2024": "Jamal Musiala:CAM:92,Harry Kane:ST:90,Leroy San\xE9:RW:88,Matthijs de Ligt:CB:88,Alphonso Davies:LB:87,Min-jae Kim:CB:87,Dayot Upamecano:CB:86,Kingsley Coman:LW:86,Mathys Tel:ST:85,Serge Gnabry:CF:85,Noussair Mazraoui:RB:84,Konrad Laimer:RB:83,Leon Goretzka:CM:83,Bryan Zaragoza:LW:78,Eric Dier:CB:78,Rapha\xEBl Guerreiro:CAM:78,Manuel Neuer:GK:72,Daniel Peretz:GK:70",
  "Bayern Munich|2025": "Jamal Musiala:CAM:92,Michael Olise:RW:92,Harry Kane:ST:89,Dayot Upamecano:CB:88,Lennart Karl:CAM:87,Alphonso Davies:LB:86,Leroy San\xE9:RW:85,Min-jae Kim:CB:85,Josip Stanisic:RB:84,Konrad Laimer:RB:84,Kingsley Coman:LW:83,Hiroki Ito:CB:82,Leon Goretzka:CM:82,Serge Gnabry:CF:82,Jonas Urbig:GK:78,Adam Aznou:LB:76,Eric Dier:CB:76,Wisdom Mike:LW:73,Jonah Kusi-Asare:ST:72,Manuel Neuer:GK:72",
  "Bayern Munich|2026": "Michael Olise:RW:92,Jamal Musiala:CAM:91,Dayot Upamecano:CB:88,Harry Kane:ST:88,Luis D\xEDaz:LW:88,Lennart Karl:CAM:87,Alphonso Davies:LB:86,Nicolas Jackson:ST:85,Tom Bischof:CM:85,Josip Stanisic:RB:84,Konrad Laimer:RB:84,Jonathan Tah:CB:83,Min-jae Kim:CB:82,Hiroki Ito:CB:80,Jonas Urbig:GK:79,Leon Goretzka:CM:79,Manuel Neuer:GK:72",
  "Borussia Dortmund|2016": "Marco Reus:CAM:86,Pierre-Emerick Aubameyang:ST:86,Henrikh Mkhitaryan:CM:85,Mats Hummels:CB:85,\u0130lkay G\xFCndo\u011Fan:CM:83,Sokratis:CB:82,Julian Weigl:CDM:80,Shinji Kagawa:CAM:80,Gonzalo Castro:CM:79,Matthias Ginter:CB:79,Neven Subotic:CB:78,Sven Bender:CDM:78,Marcel Schmelzer:LB:77,Lukasz Piszczek:RB:76,Adri\xE1n Ramos:ST:74,Roman B\xFCrki:GK:74,Christian Pulisic:RW:73,Erik Durm:RB:73,Ju-ho Park:LB:70,Moritz Leitner:CM:68,Roman Weidenfeller:GK:64",
  "Borussia Dortmund|2017": "Pierre-Emerick Aubameyang:ST:88,Christian Pulisic:RW:86,Marco Reus:CAM:85,Ousmane Demb\xE9l\xE9:ST:84,Julian Weigl:CDM:83,Sokratis:CB:83,Andr\xE9 Sch\xFCrrle:LW:82,Mario G\xF6tze:CAM:82,Matthias Ginter:CB:80,Gonzalo Castro:CM:79,Marc Bartra:CB:79,Sven Bender:CDM:78,Marcel Schmelzer:LB:77,Roman B\xFCrki:GK:77,Mikel Merino:CM:76,Sebastian Rode:CM:76,Alexander Isak:ST:74,Lukasz Piszczek:RB:74,Dan-Axel Zagadou:CB:73,Emre Mor:RW:73,Erik Durm:RB:73,Jadon Sancho:LW:73,Roman Weidenfeller:GK:64",
  "Borussia Dortmund|2018": "Pierre-Emerick Aubameyang:ST:89,Jadon Sancho:LW:88,Christian Pulisic:RW:86,Marco Reus:CAM:86,Manuel Akanji:CB:85,Michy Batshuayi:ST:85,Julian Weigl:CDM:83,Andriy Yarmolenko:RW:82,Dan-Axel Zagadou:CB:81,Maximilian Philipp:CF:81,Rapha\xEBl Guerreiro:CAM:81,Sokratis:CB:81,Mahmoud Dahoud:CM:80,Andr\xE9 Sch\xFCrrle:LW:79,\xD6mer Toprak:CB:78,Gonzalo Castro:CM:77,Roman B\xFCrki:GK:77,Alexander Isak:ST:74,Jeremy Toljan:RB:73,Marcel Schmelzer:LB:73,Nuri \u015Eahin:CDM:73,Lukasz Piszczek:RB:72,Sergio G\xF3mez:LB:70",
  "Borussia Dortmund|2019": "Jadon Sancho:LW:91,Christian Pulisic:RW:87,Achraf Hakimi:RB:86,Marco Reus:CAM:86,Paco Alc\xE1cer:ST:86,Manuel Akanji:CB:85,Abdou Diallo:CB:84,Axel Witsel:CDM:84,Dan-Axel Zagadou:CB:83,Thomas Delaney:CM:83,Julian Weigl:CDM:82,Mario G\xF6tze:CAM:82,Jacob Bruun Larsen:LW:79,Leonardo Balerdi:CB:79,Mahmoud Dahoud:CM:79,Maximilian Philipp:CF:79,Roman B\xFCrki:GK:79,Lukasz Piszczek:RB:70,Marcel Schmelzer:LB:70,Marwin Hitz:GK:70,Yan Couto:RM:64",
  "Borussia Dortmund|2020": "Jadon Sancho:LW:92,Erling Haaland:ST:90,Achraf Hakimi:RB:87,Julian Brandt:CAM:85,Dan-Axel Zagadou:CB:84,Marco Reus:CAM:84,Emre Can:CB:83,Manuel Akanji:CB:82,Mats Hummels:CB:82,Axel Witsel:CDM:81,Nico Schulz:LB:80,Thomas Delaney:CM:80,Roman B\xFCrki:GK:78,Mahmoud Dahoud:CM:77,Youssoufa Moukoko:ST:77,Mateu Morey:RB:70,Marwin Hitz:GK:68,Marcel Schmelzer:LB:64",
  "Borussia Dortmund|2021": "Erling Haaland:ST:92,Jadon Sancho:LW:90,Jude Bellingham:CAM:89,Giovanni Reyna:CAM:85,Emre Can:CB:83,Manuel Akanji:CB:83,Dan-Axel Zagadou:CB:82,Mahmoud Dahoud:CM:80,Thomas Delaney:CM:80,Thomas Meunier:RB:80,Youssoufa Moukoko:ST:80,Mats Hummels:CB:79,Axel Witsel:CDM:78,Mateu Morey:RB:76,Nico Schulz:LB:76,Roman B\xFCrki:GK:76,Marwin Hitz:GK:68",
  "Borussia Dortmund|2022": "Erling Haaland:ST:93,Jude Bellingham:CAM:91,Giovanni Reyna:CAM:84,Donyell Malen:ST:83,Manuel Akanji:CB:83,Youssoufa Moukoko:ST:83,Gregor Kobel:GK:82,Emre Can:CB:80,Mahmoud Dahoud:CM:80,Dan-Axel Zagadou:CB:77,Jamie Gittens:LW:76,Marius Wolf:RB:75,Mats Hummels:CB:75,Thomas Meunier:RB:75,Axel Witsel:CDM:73,Nico Schulz:LB:72,Tom Rothe:LB:72,Roman B\xFCrki:GK:68",
  "Borussia Dortmund|2023": "Jude Bellingham:CAM:93,Gregor Kobel:GK:85,Julian Brandt:CAM:85,Karim Adeyemi:RW:85,Nico Schlotterbeck:CB:85,Donyell Malen:ST:84,Niklas S\xFCle:CB:84,Jamie Gittens:LW:83,S\xE9bastien Haller:ST:83,Youssoufa Moukoko:ST:83,Emre Can:CB:79,Julian Ryerson:RB:79,Mahmoud Dahoud:CM:79,Marius Wolf:RB:77,Julien Duranville:LW:76,Souma\xEFla Coulibaly:CB:76,Tom Rothe:LB:74",
  "Borussia Dortmund|2024": "Jamie Gittens:LW:86,Donyell Malen:ST:85,Gregor Kobel:GK:85,Ian Maatsen:LB:85,Julian Brandt:CAM:85,Nico Schlotterbeck:CB:85,Karim Adeyemi:RW:84,Felix Nmecha:CM:83,Jadon Sancho:LW:83,Youssoufa Moukoko:ST:82,Julian Ryerson:RB:81,Marcel Sabitzer:CM:81,Niclas F\xFCllkrug:ST:79,Niklas S\xFCle:CB:79,Emre Can:CB:77,Ramy Bensebaini:CB:77,Marco Reus:CAM:73,Marius Wolf:RB:73",
  "Borussia Dortmund|2025": "Karim Adeyemi:RW:87,Nico Schlotterbeck:CB:87,Felix Nmecha:CM:86,Jamie Gittens:LW:86,Serhou Guirassy:ST:86,Gregor Kobel:GK:85,Maximilian Beier:ST:83,Carney Chukwuemeka:CM:82,Daniel Svensson:LB:82,Julian Brandt:CAM:82,Julian Ryerson:RB:81,Yan Couto:RM:81,Waldemar Anton:CB:80,Giovanni Reyna:CAM:77,Marcel Sabitzer:CM:77,Emre Can:CB:76,Julien Duranville:LW:76,Niklas S\xFCle:CB:76,Cole Campbell:RW:73,Pascal Gro\xDF:CM:73",
  "Borussia Dortmund|2026": "Nico Schlotterbeck:CB:87,Felix Nmecha:CM:86,Karim Adeyemi:RW:86,Gregor Kobel:GK:85,Maximilian Beier:ST:85,Serhou Guirassy:ST:85,F\xE1bio Silva:ST:83,Jobe Bellingham:CM:83,Daniel Svensson:LB:82,Julian Ryerson:RB:82,Carney Chukwuemeka:CM:81,Julian Brandt:CAM:81,Yan Couto:RM:81,Waldemar Anton:CB:80,Aar\xF3n Anselmino:CB:78,Marcel Sabitzer:CM:76,Ramy Bensebaini:CB:76,Almugera Kabar:LB:70",
  "Brighton & Hove Albion|2018": "Davy Pr\xF6pper:CM:79,Jos\xE9 Izquierdo:LW:79,J\xFCrgen Locadia:ST:79,Lewis Dunk:CB:78,Shane Duffy:CB:78,Pascal Gro\xDF:CM:77,Anthony Knockaert:RW:76,Mathew Ryan:GK:76,Solly March:RW:76,Dale Stephens:CM:74,Ezequiel Schelotto:RM:73,Izzy Brown:LW:73,Leonardo Ulloa:ST:73,Glenn Murray:ST:70,Markus Suttner:LB:70,Tim Krul:GK:70,Ga\xEBtan Bong:LB:68,Liam Rosenior:RB:64",
  "Brighton & Hove Albion|2019": "Lewis Dunk:CB:81,Davy Pr\xF6pper:CM:80,Alireza Jahanbakhsh:RW:79,Yves Bissouma:CDM:79,J\xFCrgen Locadia:ST:78,Pascal Gro\xDF:CM:78,Shane Duffy:CB:78,Bernardo:LB:77,Jos\xE9 Izquierdo:LW:77,Mathew Ryan:GK:77,Anthony Knockaert:RW:76,Mart\xEDn Montoya:RB:76,Dale Stephens:CM:74,Florin Andone:ST:74,Dan Burn:CB:73,Steven Alzate:CM:70,David Button:GK:68",
  "Brighton & Hove Albion|2020": "Lewis Dunk:CB:83,Neal Maupay:ST:82,Tariq Lamptey:RB:80,Adam Webster:CB:79,Davy Pr\xF6pper:CM:79,Leandro Trossard:LW:79,Yves Bissouma:CDM:79,Alexis Mac Allister:CM:78,Aaron Mooy:CM:77,Pascal Gro\xDF:CM:77,Solly March:RW:77,Aaron Connolly:ST:76,Mathew Ryan:GK:76,Alireza Jahanbakhsh:RW:75,Jos\xE9 Izquierdo:LW:75,Mart\xEDn Montoya:RB:75,Bernardo:LB:73,Dan Burn:CB:73,David Button:GK:64,Ezequiel Schelotto:RM:64",
  "Brighton & Hove Albion|2021": "Ben White:RB:85,Lewis Dunk:CB:82,Yves Bissouma:CDM:82,Neal Maupay:ST:81,Adam Webster:CB:80,Leandro Trossard:LW:80,Tariq Lamptey:RB:80,Robert S\xE1nchez:GK:78,Alexis Mac Allister:CM:77,Jakub Moder:CM:77,Solly March:RW:77,Aaron Connolly:ST:76,Davy Pr\xF6pper:CM:76,Pascal Gro\xDF:CM:76,Adam Lallana:CAM:74,Michal Karbownik:LB:74,Dan Burn:CB:73,Danny Welbeck:ST:73,Bernardo:LB:72,Percy Tau:RW:72",
  "Brighton & Hove Albion|2022": "Marc Cucurella:LB:87,Alexis Mac Allister:CM:85,Mois\xE9s Caicedo:CDM:85,Robert S\xE1nchez:GK:84,Yves Bissouma:CDM:84,Leandro Trossard:LW:83,Adam Webster:CB:82,Lewis Dunk:CB:81,Enock Mwepu:CM:80,Neal Maupay:ST:80,Tariq Lamptey:RB:80,Jakub Moder:CM:78,Solly March:RW:78,Danny Welbeck:ST:76,Pascal Gro\xDF:CM:76,Shane Duffy:CB:73,Jeremy Sarmiento:LW:70,Adam Lallana:CAM:68",
  "Brighton & Hove Albion|2023": "Alexis Mac Allister:CM:88,Evan Ferguson:ST:88,Levi Colwill:CB:87,Kaoru Mitoma:LW:86,Pervis Estupi\xF1\xE1n:LB:84,Robert S\xE1nchez:GK:83,Adam Webster:CB:82,Julio Enciso:CAM:82,Solly March:RW:82,Deniz Undav:ST:80,Lewis Dunk:CB:80,Jan Paul van Hecke:CB:79,Facundo Buonanotte:CAM:78,Tariq Lamptey:RB:78,Jakub Moder:CM:77,Danny Welbeck:ST:76,Pascal Gro\xDF:CM:76,Yasin Ayari:CM:74,Jason Steele:GK:72",
  "Brighton & Hove Albion|2024": "Evan Ferguson:ST:87,Jo\xE3o Pedro:ST:86,Kaoru Mitoma:LW:86,Jan Paul van Hecke:CB:84,Pervis Estupi\xF1\xE1n:LB:83,Simon Adingra:LW:83,Bart Verbruggen:GK:82,Facundo Buonanotte:CAM:82,Igor Julio:CB:82,Julio Enciso:CAM:82,Adam Webster:CB:81,Solly March:RW:80,Valent\xEDn Barco:CM:79,Lewis Dunk:CB:78,Tariq Lamptey:RB:78,Jakub Moder:CM:77,Jo\xEBl Veltman:RB:77,Pascal Gro\xDF:CM:76,Jason Steele:GK:72",
  "Brighton & Hove Albion|2025": "Jo\xE3o Pedro:ST:88,Kaoru Mitoma:LW:85,Yankuba Minteh:RW:85,Bart Verbruggen:GK:84,Evan Ferguson:ST:84,Georginio Rutter:ST:84,Jan Paul van Hecke:CB:84,Brajan Gruda:CAM:83,Ferdi Kad\u0131o\u011Flu:LB:83,Mats Wieffer:RB:83,Pervis Estupi\xF1\xE1n:LB:83,Simon Adingra:LW:83,Yasin Ayari:CM:83,Diego G\xF3mez:CM:82,Julio Enciso:CAM:82,Matt O'Riley:CM:82,Igor Julio:CB:81,Adam Webster:CB:78,Jakub Moder:CM:78,Tariq Lamptey:RB:78,Eiran Cashin:CB:76,Solly March:RW:76,Jason Steele:GK:68",
  "Brighton & Hove Albion|2026": "Bart Verbruggen:GK:85,Yankuba Minteh:RW:85,Jan Paul van Hecke:CB:84,Brajan Gruda:CAM:83,Ferdi Kad\u0131o\u011Flu:LB:83,Georginio Rutter:ST:83,Yasin Ayari:CM:83,Charalampos Kostoulas:ST:82,Diego G\xF3mez:CM:82,Kaoru Mitoma:LW:82,Mats Wieffer:RB:82,Maxim De Cuyper:LB:82,Matt O'Riley:CM:81,Stefanos Tzimas:ST:81,Olivier Boscagli:CB:79,Igor Julio:CB:78,Tom Watson:LW:77,Harry Howell:CAM:76,Adam Webster:CB:73,Pascal Gro\xDF:CM:72,Jo\xEBl Veltman:RB:70,Solly March:RW:68",
  "CA Boca Juniors|2016": "Carlos T\xE9vez:ST:79,Gino Peruzzi:RB:74,Nicol\xE1s Lodeiro:CAM:74,Rodrigo Bentancur:CDM:74,Andr\xE9s Ch\xE1vez:ST:73,Daniel Osvaldo:ST:73,Fernando Gago:CDM:73,Cristian Pav\xF3n:RB:72,Jonathan Silva:LB:72,Marcelo Meli:CM:72,Sebasti\xE1n Palacios:RW:72,Nicol\xE1s Colazo:LB:70,Agust\xEDn Ori\xF3n:GK:68,Fernando Tobio:CB:68,Guillermo Sara:GK:68,Pablo P\xE9rez:CM:68",
  "CA Boca Juniors|2017": "Cristian Pav\xF3n:RB:79,Rodrigo Bentancur:CDM:79,Dar\xEDo Benedetto:ST:78,Frank Fabra:LB:73,Ricardo Centuri\xF3n:LW:73,Walter Bou:ST:73,Wilmar Barrios:CDM:73,Jonathan Silva:LB:72,Fernando Zuqui:CM:70,Leonardo Jara:RB:70,Santiago Vergini:CB:70,Agust\xEDn Rossi:GK:68,Fernando Tobio:CB:68,Guillermo Sara:GK:68,Pablo P\xE9rez:CM:68,Nazareno Sol\xEDs:LW:64",
  "CA Boca Juniors|2018": "Cristian Pav\xF3n:RB:81,Dar\xEDo Benedetto:ST:79,Nahitan N\xE1ndez:CM:79,Wilmar Barrios:CDM:78,Edwin Cardona:CAM:74,Emanuel Reynoso:CAM:74,Frank Fabra:LB:74,Lisandro Magall\xE1n:CB:74,Ram\xF3n \xC1bila:ST:74,Agust\xEDn Almendra:CM:73,Leonardo Jara:RB:72,Agust\xEDn Rossi:GK:70,Emmanuel M\xE1s:LB:70,Leonardo Balerdi:CB:70,Cristian Espinoza:RW:68,Fernando Gago:CDM:68,Pablo P\xE9rez:CM:68",
  "CA Boca Juniors|2019": "Nahitan N\xE1ndez:CM:83,Wilmar Barrios:CDM:81,Agust\xEDn Almendra:CM:79,Dar\xEDo Benedetto:ST:79,Esteban Andrada:GK:77,Sebasti\xE1n Villa:LW:77,Emanuel Reynoso:CAM:76,Iv\xE1n Marcone:CDM:76,Ram\xF3n \xC1bila:ST:76,Agust\xEDn Obando:LW:72,Exequiel Zeballos:RW:72,Frank Fabra:LB:72,Lisandro L\xF3pez:CB:72,Emmanuel M\xE1s:LB:70,Julio Buffarini:RB:70,Marcelo Weigandt:RB:68,Marcos D\xEDaz:GK:68",
  "CA Boca Juniors|2021": "Cristian Pav\xF3n:RB:78,Alan Varela:CDM:76,Eduardo Salvio:RW:76,Esteban Andrada:GK:76,Cristian Medina:CM:74,Agust\xEDn Almendra:CM:73,Edwin Cardona:CAM:73,Exequiel Zeballos:RW:73,Gast\xF3n \xC1vila:CB:73,Marcos Rojo:CB:73,Ram\xF3n \xC1bila:ST:73,Aar\xF3n Molinas:CAM:72,Carlos Izquierdoz:CB:72,Jorman Campuzano:CDM:72,Agust\xEDn Obando:LW:70,Agust\xEDn Rossi:GK:70,Agust\xEDn S\xE1ndez:LB:68,Emmanuel M\xE1s:LB:68,Leonardo Jara:RB:68",
  "CA Boca Juniors|2022": "Alan Varela:CDM:77,Agust\xEDn Rossi:GK:76,Exequiel Zeballos:RW:75,Cristian Medina:CM:74,Sebasti\xE1n Villa:LW:74,Agust\xEDn Almendra:CM:73,Gast\xF3n \xC1vila:CB:73,Aar\xF3n Molinas:CAM:72,Eduardo Salvio:RW:72,Juan Ram\xEDrez:CM:72,Nicol\xE1s Figal:CB:72,\xD3scar Romero:CAM:72,Pol Fern\xE1ndez:CM:70,Agust\xEDn S\xE1ndez:LB:68,Frank Fabra:LB:68,Luis Adv\xEDncula:RB:64",
  "CA River Plate|2016": "Gonzalo Mart\xEDnez:CAM:77,Lucas Alario:ST:77,Emanuel Mammana:CB:76,Gabriel Mercado:CB:74,Sebasti\xE1n Driussi:ST:74,Rodrigo Mora:ST:73,\xC9der Balanta:CDM:72,Jonatan Maidana:CB:72,Leonel Vangioni:LB:72,Marcelo Barovero:GK:72,Milton Casco:LB:72,Augusto Batalla:GK:70,Camilo Mayada:RB:70,Joaqu\xEDn Arzura:CM:70,Leandro Vega:CB:70,Tabar\xE9 Vi\xFAdez:RW:70,Andr\xE9s D'Alessandro:CAM:68,Nicol\xE1s Bertolo:LW:64",
  "CA River Plate|2017": "Lucas Alario:ST:81,Sebasti\xE1n Driussi:ST:78,Gonzalo Mart\xEDnez:CAM:77,Jorge Moreira:RB:72,Lucas Mart\xEDnez Quarta:CB:72,Milton Casco:LB:72,Arturo Mina:CB:70,Augusto Batalla:GK:70,Carlos Auzqui:RW:70,Jonatan Maidana:CB:70,Luciano Lollo:CB:70,Marcelo Larrondo:ST:70,Ariel Rojas:CM:68,Camilo Mayada:RB:68,Exequiel Palacios:CM:68,Iv\xE1n Rossi:CDM:68,Luis Olivera:LB:68,Tom\xE1s Andrade:CAM:68",
  "CA River Plate|2018": "Exequiel Palacios:CM:81,Gonzalo Mart\xEDnez:CAM:81,Marcelo Saracchi:LB:79,Juan Fernando Quintero:CAM:77,Franco Armani:GK:76,Gonzalo Montiel:RB:76,Lucas Pratto:ST:76,Rafael Borr\xE9:ST:76,Lucas Mart\xEDnez Quarta:CB:75,Ignacio Scocco:ST:72,Enzo P\xE9rez:CDM:70,Camilo Mayada:RB:68,Carlos Auzqui:RW:68,Javier Pinola:LB:64",
  "CA River Plate|2019": "Exequiel Palacios:CM:82,Cristian Ferreira:CM:79,Juan Fernando Quintero:CAM:79,Lucas Mart\xEDnez Quarta:CB:79,Nicol\xE1s de la Cruz:CM:79,Rafael Borr\xE9:ST:79,Gonzalo Montiel:RB:77,Juli\xE1n Alvarez:ST:77,Franco Armani:GK:76,Lucas Pratto:ST:76,Santiago Sosa:CDM:76,Bruno Zuculini:CDM:70,Jorge Carrascal:CAM:70,Milton Casco:LB:70,Javier Pinola:LB:64",
  "CA River Plate|2021": "Juli\xE1n Alvarez:ST:81,Gonzalo Montiel:RB:80,Nicol\xE1s de la Cruz:CM:80,Rafael Borr\xE9:ST:80,Jorge Carrascal:CAM:76,Paulo D\xEDaz:CB:76,Franco Armani:GK:74,Robert Rojas:CB:74,Cristian Ferreira:CM:73,Fabrizio Angileri:LB:73,Federico Girotti:ST:72,Enzo P\xE9rez:CDM:70,Milton Casco:LB:68,Santiago Sim\xF3n:RB:68",
  "CA River Plate|2022": "Enzo Fern\xE1ndez:CM:87,Juli\xE1n Alvarez:ST:86,Nicol\xE1s de la Cruz:CM:80,Esequiel Barco:CAM:77,Paulo D\xEDaz:CB:76,David Mart\xEDnez:CB:75,Agust\xEDn Palavecino:CM:74,Santiago Sim\xF3n:RB:74,Emanuel Mammana:CB:73,Robert Rojas:CB:73,Braian Romero:ST:72,Franco Armani:GK:72,Mat\xEDas Su\xE1rez:ST:72,Tom\xE1s Pochettino:CAM:72,Andr\xE9s Herrera:RB:70,El\xEDas G\xF3mez:LB:70,Bruno Zuculini:CDM:68,Enzo P\xE9rez:CDM:68,Milton Casco:LB:68",
  "CA River Plate|2023": "Nicol\xE1s de la Cruz:CM:79,Claudio Echeverri:CAM:78,Lucas Beltr\xE1n:ST:78,Esequiel Barco:CAM:77,Pablo Solari:RW:76,Santiago Sim\xF3n:RB:74,Miguel Borja:ST:73,Paulo D\xEDaz:CB:73,Agust\xEDn Palavecino:CM:72,David Mart\xEDnez:CB:72,Emanuel Mammana:CB:72,Jos\xE9 Paradela:CM:72,Robert Rojas:CB:72,Franco Armani:GK:70,Andr\xE9s Herrera:RB:68,El\xEDas G\xF3mez:LB:68,Franco Alfonso:RW:68",
  "CA River Plate|2024": "Claudio Echeverri:CAM:80,Esequiel Barco:CAM:79,Pablo Solari:RW:76,Facundo Colidio:ST:74,Paulo D\xEDaz:CB:74,Santiago Sim\xF3n:RB:74,Enzo D\xEDaz:LB:72,Miguel Borja:ST:72,Agust\xEDn Sant'Anna:RB:70,Manuel Lanzini:CAM:70,Santiago Beltr\xE1n:GK:68",
  "CA River Plate|2026": "Lautaro Rivero:CB:76,Gonzalo Montiel:RB:73,Lucas Mart\xEDnez Quarta:CB:73,Maximiliano Salas:ST:73,Sebasti\xE1n Driussi:ST:73,Giuliano Galoppo:CM:72,Ian Subiabre:RW:72,Mat\xEDas Vi\xF1a:LB:72,Fabricio Bustos:RB:70,Santiago Lencina:CAM:70,Tom\xE1s Galv\xE1n:CAM:70,Ezequiel Centuri\xF3n:GK:68,Santiago Beltr\xE1n:GK:68",
  "CF Monterrey|2016": "Edwin Cardona:CAM:74,Dorlan Pab\xF3n:RW:73,Rogelio Funes Mori:ST:73,C\xE9sar Montes:CB:70,Jonathan Orozco:GK:70,Walter Gargano:CDM:70,Edgar Castillo:LB:68,Jos\xE9 Mar\xEDa Basanta:CB:68,Neri Cardozo:CAM:68,Pablo Barrera:RW:68,C\xE1ndido Ram\xEDrez:LW:64,Efra\xEDn Ju\xE1rez:RB:64",
  "CF Monterrey|2017": "Dorlan Pab\xF3n:RW:73,Edwin Cardona:CAM:73,Rogelio Funes Mori:ST:73,C\xE9sar Montes:CB:70,Jes\xFAs Molina:CDM:70,Yimmi Char\xE1:RW:70,Alexander Dom\xEDnguez:GK:68,Arturo Gonz\xE1lez:LW:68,Celso Ortiz:CDM:68,Edgar Castillo:LB:68,Hugo Gonz\xE1lez:GK:68,Iv\xE1n Piris:RB:68,Luis Fuentes:LB:68",
  "CF Monterrey|2018": "Rogelio Funes Mori:ST:74,Dorlan Pab\xF3n:RW:73,Jonathan Gonz\xE1lez:CDM:73,Avil\xE9s Hurtado:LW:72,C\xE9sar Montes:CB:72,Jonathan Urretaviscaya:RW:72,Stefan Medina:RB:72,Celso Ortiz:CDM:70,Jes\xFAs Molina:CDM:70,Arturo Gonz\xE1lez:LW:68,Efra\xEDn Velarde:LB:68,Hugo Gonz\xE1lez:GK:68,Leonel Vangioni:LB:68",
  "CF Monterrey|2019": "Maximiliano Meza:RW:79,Rodolfo Pizarro:CAM:77,Rogelio Funes Mori:ST:76,Jonathan Gonz\xE1lez:CDM:75,Carlos Rodr\xEDguez:CDM:73,C\xE9sar Montes:CB:73,Jes\xFAs Gallardo:LB:73,Dorlan Pab\xF3n:RW:72,Stefan Medina:RB:72,Avil\xE9s Hurtado:LW:70,Arturo Gonz\xE1lez:LW:68,Leonel Vangioni:LB:68,Marcelo Barovero:GK:68",
  "CF Monterrey|2020": "Maximiliano Meza:RW:77,Carlos Rodr\xEDguez:CDM:76,Rogelio Funes Mori:ST:76,Vincent Janssen:ST:76,C\xE9sar Montes:CB:75,Jes\xFAs Gallardo:LB:74,Ak\xE9 Loba:ST:73,Jonathan Gonz\xE1lez:CDM:72,Stefan Medina:RB:72,Celso Ortiz:CDM:70,Dorlan Pab\xF3n:RW:70,Miguel Lay\xFAn:RB:70,Avil\xE9s Hurtado:LW:68,Leonel Vangioni:LB:68,Marcelo Barovero:GK:68",
  "CF Monterrey|2021": "Carlos Rodr\xEDguez:CDM:77,C\xE9sar Montes:CB:76,Rogelio Funes Mori:ST:75,Sebasti\xE1n Vegas:CB:74,Ak\xE9 Loba:ST:73,Mat\xEDas Kranevitter:CDM:72,Stefan Medina:RB:72,Celso Ortiz:CDM:68,Dorlan Pab\xF3n:RW:68,Hugo Gonz\xE1lez:GK:68,Miguel Lay\xFAn:RB:68",
  "CF Monterrey|2022": "Maximiliano Meza:RW:77,C\xE9sar Montes:CB:76,Luis Romo:CDM:76,Arturo Gonz\xE1lez:LW:74,Sebasti\xE1n Vegas:CB:74,Vincent Janssen:ST:74,\xC9rick Aguirre:RB:73,Rogelio Funes Mori:ST:73,Duv\xE1n Vergara:LW:72,Esteban Andrada:GK:72,Stefan Medina:RB:72,Jes\xFAs Gallardo:LB:70,Joel Campbell:CF:70,Mat\xEDas Kranevitter:CDM:70,Celso Ortiz:CDM:68",
  "CF Monterrey|2025": "Nelson Deossa:CM:77,Germ\xE1n Berterame:ST:76,Lucas Ocampos:LW:75,Sergio Canales:CAM:75,V\xEDctor Guzm\xE1n:CB:74,\xD3liver Torres:CM:73,Gerardo Arteaga:LB:72,Iker Fimbres:CAM:72,\xC9rick Aguirre:RB:70,Jordi Cortizo:RW:70,Ricardo Ch\xE1vez:RB:70,Esteban Andrada:GK:68,Jes\xFAs Corona:RW:68",
  "CF Monterrey|2026": "Luca Orellano:RW:76,Anthony Martial:ST:73,Iker Fimbres:CAM:73,Sergio Canales:CAM:73,V\xEDctor Guzm\xE1n:CB:73,Lucas Ocampos:LW:72,\xD3liver Torres:CM:72,Alonso Aceves:LB:70,Gerardo Arteaga:LB:70,Ricardo Ch\xE1vez:RB:70,\xC9rick Aguirre:RB:68,Jes\xFAs Corona:RW:68,Santiago Mele:GK:68",
  "CR Flamengo|2016": "Alan Patrick:CAM:72,Alex Muralha:GK:72,Paolo Guerrero:ST:72,Paulo Victor:GK:72,Willian Ar\xE3o:CDM:72,\xC9verton:RW:70,H\xE9ctor Canteros:CM:70,Jorge:LB:70,C\xE9sar Martins:CB:68,Par\xE1:RB:68,Rodinei:RB:68,Chiquinho:CAM:64,Emerson:LW:64,Gustavo Cu\xE9llar:CDM:64",
  "CR Flamengo|2018": "Vinicius Junior:LW:84,Lucas Paquet\xE1:CAM:79,Everton Ribeiro:CAM:76,Diego Alves:GK:73,Lincoln:ST:73,\xC9verton:RW:72,Gustavo Cu\xE9llar:CDM:72,Henrique Dourado:ST:72,Paolo Guerrero:ST:70,Geuv\xE2nio:RW:68,Miguel Trauco:LB:68,Ren\xEA:LB:68,Rodinei:RB:68,Par\xE1:RB:64",
  "CR Flamengo|2019": "Gabriel Barbosa:ST:82,Reinier:CAM:82,Giorgian de Arrascaeta:CAM:81,L\xE9o Duarte:CB:76,Vitinho:LW:76,Bruno Henrique:ST:75,Lincoln:ST:74,Rodrigo Caio:CB:74,Diego Alves:GK:72,Gustavo Cu\xE9llar:CDM:72,Ren\xEA:LB:70,Miguel Trauco:LB:68,Piris da Motta:CDM:68,Rodinei:RB:68",
  "CR Flamengo|2021": "Gabriel Barbosa:ST:83,Gerson:CM:81,Giorgian de Arrascaeta:CAM:80,Pedro:ST:79,Everton Ribeiro:CAM:76,Matheuzinho:RB:76,Michael:LW:76,Willian Ar\xE3o:CDM:76,Rodrigo Caio:CB:75,Bruno Henrique:ST:74,Jo\xE3o Gomes:CM:73,Thiago Maia:CDM:73,Hugo Souza:GK:72,L\xE9o Pereira:CB:72,Natan:CB:72,Jo\xE3o Lucas:RB:70,Diego Alves:GK:68,Ramon:LB:68,Ren\xEA:LB:68",
  "CR Flamengo|2022": "Gabriel Barbosa:ST:83,Giorgian de Arrascaeta:CAM:81,Pedro:ST:81,Andreas Pereira:CM:79,Jo\xE3o Gomes:CM:79,L\xE1zaro:ST:76,Matheuzinho:RB:76,Pablo:CB:76,Willian Ar\xE3o:CDM:76,Everton Ribeiro:CAM:74,Thiago Maia:CDM:74,Rodrigo Caio:CB:73,Hugo Souza:GK:72,L\xE9o Pereira:CB:72,Victor Hugo:CM:70,Rodinei:RB:64",
  "CR Flamengo|2023": "Pedro:ST:82,Gabriel Barbosa:ST:81,Giorgian de Arrascaeta:CAM:81,Gerson:CM:80,Matheus Fran\xE7a:CAM:79,Everton:LW:78,Ayrton Lucas:LB:77,Matheuzinho:RB:75,L\xE9o Pereira:CB:74,Victor Hugo:CM:73,Matheus Gon\xE7alves:RW:70,Santos:GK:70,Guillermo Varela:RB:68,Marinho:RW:68",
  "CR Flamengo|2024": "Pedro:ST:82,Gerson:CM:81,Nicol\xE1s de la Cruz:CM:80,Giorgian de Arrascaeta:CAM:79,Lorran:CAM:78,Everton:LW:77,Gabriel Barbosa:ST:77,L\xE9o Pereira:CB:77,Mat\xEDas Vi\xF1a:LB:77,Agust\xEDn Rossi:GK:76,Ayrton Lucas:LB:76,Fabr\xEDcio Bruno:CB:76,Victor Hugo:CM:73,Matheus Gon\xE7alves:RW:72,Guillermo Varela:RB:68",
  "CR Flamengo|2025": "Wesley:RB:84,Gerson:CM:82,Pedro:ST:82,Nicol\xE1s de la Cruz:CM:80,Giorgian de Arrascaeta:CAM:79,L\xE9o Ortiz:CB:79,Lorran:CAM:78,Agust\xEDn Rossi:GK:77,L\xE9o Pereira:CB:77,Matheus Gon\xE7alves:RW:77,Everton:LW:76,Gonzalo Plata:RW:76,Michael:LW:74,Alex Sandro:LB:68",
  "CR Flamengo|2026": "Samuel Lino:LW:80,Giorgian de Arrascaeta:CAM:79,L\xE9o Ortiz:CB:79,Jorge Carrascal:CAM:78,Vit\xE3o:CB:78,Agust\xEDn Rossi:GK:77,L\xE9o Pereira:CB:77,Nicol\xE1s de la Cruz:CM:77,Emerson Royal:RB:76,Everton:LW:76,Gonzalo Plata:RW:76,Wallace Yan:ST:74,Ayrton Lucas:LB:72,Alex Sandro:LB:68",
  "Celtic FC|2017": "Patrick Roberts:RW:76,Moussa Demb\xE9l\xE9:ST:73,Jozo Simunovic:CB:72,Mikael Lustig:RB:72,Scott Brown:CM:72,Scott Sinclair:LW:72,Craig Gordon:GK:70,Erik Sviatchenko:CB:70,Leigh Griffiths:ST:70,Nir Bitton:CB:70,Eboue Kouassi:CDM:68,James Forrest:RW:68,Kieran Tierney:LB:68,Stuart Armstrong:CM:68,Tom Rogic:CAM:68,Callum McGregor:CDM:64,Gary Mackay-Steven:LM:64",
  "Celtic FC|2018": "Moussa Demb\xE9l\xE9:ST:81,Kieran Tierney:LB:79,Patrick Roberts:RW:76,Stuart Armstrong:CM:76,Scott Sinclair:LW:73,Jozo Simunovic:CB:72,Mikael Lustig:RB:72,Scott Brown:CM:72,Craig Gordon:GK:70,Leigh Griffiths:ST:70,Odsonne \xC9douard:ST:70,Olivier Ntcham:CM:70,Tom Rogic:CAM:70,Callum McGregor:CDM:68,Eboue Kouassi:CDM:68,Cristian Gamboa:RB:64,Jonny Hayes:RM:64",
  "Celtic FC|2019": "Kieran Tierney:LB:82,Filip Benkovic:CB:78,Dedryck Boyata:CB:77,Odsonne \xC9douard:ST:76,Oliver Burke:ST:76,Timothy Weah:RM:76,Callum McGregor:CDM:73,James Forrest:RW:73,Olivier Ntcham:CM:73,Jozo Simunovic:CB:72,Ryan Christie:CM:72,Scott Brown:CM:72,Scott Sinclair:LW:72,Tom Rogic:CAM:70,Craig Gordon:GK:68,Emilio Izaguirre:LB:64,Mikey Johnston:LW:64",
  "Celtic FC|2020": "Odsonne \xC9douard:ST:79,Mohamed Elyounoussi:CF:78,Fraser Forster:GK:76,James Forrest:RW:76,Christopher Jullien:CB:75,Ryan Christie:CM:75,Callum McGregor:CDM:74,Olivier Ntcham:CM:73,Kristoffer Ajer:CB:72,Patryk Klimala:ST:72,Boli Bolingoli:LB:70,Jeremie Frimpong:RB:70,Jozo Simunovic:CB:70,Tom Rogic:CAM:70,Maryan Shved:RW:68,Moritz Bauer:RB:68,Greg Taylor:LB:64,Jonny Hayes:RM:64,Mikey Johnston:LW:64",
  "Celtic FC|2021": "Jeremie Frimpong:RB:81,Kristoffer Ajer:CB:80,Odsonne \xC9douard:ST:80,Mohamed Elyounoussi:CF:78,Ryan Christie:CM:77,Callum McGregor:CDM:76,Shane Duffy:CB:76,David Turnbull:CM:75,James Forrest:RW:74,Jonjoe Kenny:RB:74,Albian Ajeti:ST:73,Patryk Klimala:ST:72,Vasilios Barkas:GK:72,Greg Taylor:LB:68,Tom Rogic:CAM:68",
  "Celtic FC|2022": "Jota:LW:78,Cameron Carter-Vickers:CB:77,Josip Juranovic:RB:77,Callum McGregor:CDM:76,Liel Abada:RW:76,David Turnbull:CM:75,Carl Starfelt:CB:74,Kyogo Furuhashi:ST:74,Christopher Jullien:CB:73,Daizen Maeda:LW:73,Georgios Giakoumakis:ST:73,James Forrest:RW:73,Reo Hatate:CM:73,Greg Taylor:LB:72,Anthony Ralston:RB:68,Joe Hart:GK:68,Tom Rogic:CAM:68",
  "Celtic FC|2023": "Cameron Carter-Vickers:CB:79,Jota:LW:79,Kyogo Furuhashi:ST:79,Matt O'Riley:CM:79,Reo Hatate:CM:78,Alistair Johnston:RB:76,Greg Taylor:LB:76,Liel Abada:RW:76,Carl Starfelt:CB:75,Daizen Maeda:LW:75,Georgios Giakoumakis:ST:74,Aaron Mooy:CM:72,Anthony Ralston:RB:68,Joe Hart:GK:68",
  "Celtic FC|2024": "Matt O'Riley:CM:82,Cameron Carter-Vickers:CB:79,Kyogo Furuhashi:ST:79,Reo Hatate:CM:78,Alistair Johnston:RB:77,Nicolas K\xFChn:RW:77,Daizen Maeda:LW:76,Greg Taylor:LB:76,Liel Abada:RW:76,Alexandro Bernabei:LB:74,Luis Palma:LW:73,Paulo Bernardo:CM:73,Liam Scales:CB:72,Anthony Ralston:RB:68,Viljami Sinisalo:GK:64",
  "Celtic FC|2026": "Arne Engels:CM:80,Benjamin Nygren:RW:79,Daizen Maeda:LW:79,Cameron Carter-Vickers:CB:77,Juli\xE1n Araujo:RB:77,Reo Hatate:CM:77,Alistair Johnston:RB:76,Kieran Tierney:LB:76,Auston Trusty:CB:74,Hyun-jun Yang:RW:73,Liam Scales:CB:73,Junior Adamu:ST:72,Michel-Ange Balikwisha:LW:72,Paulo Bernardo:CM:72,Marcelo Saracchi:LB:68,Viljami Sinisalo:GK:64",
  "Chelsea FC|2016": "Eden Hazard:LW:88,Cesc F\xE0bregas:CM:86,Diego Costa:ST:86,Nemanja Mati\u0107:CDM:85,Oscar:CAM:84,Thibaut Courtois:GK:84,Willian:LW:84,Pedro:RW:82,Radamel Falcao:ST:82,C\xE9sar Azpilicueta:CB:81,Gary Cahill:CB:80,Kurt Zouma:CB:80,Abdul Rahman Baba:LB:79,Ramires:CM:79,Asmir Begovic:GK:78,Branislav Ivanovic:RB:78,John Obi Mikel:CDM:78,Lo\xEFc R\xE9my:ST:77,Ruben Loftus-Cheek:CM:73,Bertrand Traor\xE9:RW:72,John Terry:CB:70",
  "Chelsea FC|2017": "Eden Hazard:LW:89,Diego Costa:ST:86,N'Golo Kant\xE9:CDM:86,Thibaut Courtois:GK:85,Cesc F\xE0bregas:CM:84,Nemanja Mati\u0107:CDM:84,Willian:LW:84,C\xE9sar Azpilicueta:CB:83,David Luiz:CB:83,Pedro:RW:83,Marcos Alonso:CB:82,Michy Batshuayi:ST:82,Gary Cahill:CB:80,Victor Moses:RW:80,Asmir Begovic:GK:76,Dominic Solanke:ST:73,Ruben Loftus-Cheek:CM:73,Ola Aina:RB:68",
  "Chelsea FC|2018": "Eden Hazard:LW:92,N'Golo Kant\xE9:CDM:90,\xC1lvaro Morata:ST:88,Thibaut Courtois:GK:88,Antonio R\xFCdiger:CB:86,Marcos Alonso:CB:86,Willian:LW:86,Andreas Christensen:CB:85,C\xE9sar Azpilicueta:CB:85,Tiemou\xE9 Bakayoko:CDM:85,Cesc F\xE0bregas:CM:84,Pedro:RW:82,Ross Barkley:CM:82,Danny Drinkwater:CM:81,Davide Zappacosta:RM:81,Emerson:LB:81,Victor Moses:RW:81,Willy Caballero:GK:64",
  "Chelsea FC|2019": "Eden Hazard:LW:92,N'Golo Kant\xE9:CDM:90,Jorginho:CDM:88,Kepa Arrizabalaga:GK:87,\xC1lvaro Morata:ST:86,Antonio R\xFCdiger:CB:86,Gonzalo Higua\xEDn:ST:86,Mateo Kovacic:CM:86,Marcos Alonso:CB:85,Willian:LW:85,Andreas Christensen:CB:84,C\xE9sar Azpilicueta:CB:84,Emerson:LB:83,Ross Barkley:CM:83,Ruben Loftus-Cheek:CM:83,Pedro:RW:81,Davide Zappacosta:RM:79,Olivier Giroud:ST:79,Tino Anjorin:CAM:70,Willy Caballero:GK:64",
  "Chelsea FC|2020": "N'Golo Kant\xE9:CDM:89,Christian Pulisic:RW:87,Jorginho:CDM:86,Mason Mount:CAM:86,Mateo Kovacic:CM:86,Antonio R\xFCdiger:CB:85,Kepa Arrizabalaga:GK:85,Tammy Abraham:ST:85,Callum Hudson-Odoi:LW:84,Kurt Zouma:CB:84,Reece James:RB:84,Willian:LW:83,Andreas Christensen:CB:82,C\xE9sar Azpilicueta:CB:82,Emerson:LB:82,Ruben Loftus-Cheek:CM:82,Ross Barkley:CM:81,Michy Batshuayi:ST:80,Olivier Giroud:ST:76,Tino Anjorin:CAM:68",
  "Chelsea FC|2021": "Mason Mount:CAM:89,Kai Havertz:ST:88,Timo Werner:ST:88,N'Golo Kant\xE9:CDM:87,Reece James:RB:87,Ben Chilwell:LB:86,Christian Pulisic:RW:86,Jorginho:CDM:86,Mateo Kovacic:CM:86,Hakim Ziyech:RW:85,Tammy Abraham:ST:85,Andreas Christensen:CB:84,Antonio R\xFCdiger:CB:84,Callum Hudson-Odoi:LW:84,Edouard Mendy:GK:84,Kurt Zouma:CB:84,C\xE9sar Azpilicueta:CB:80,Emerson:LB:79,Kepa Arrizabalaga:GK:79,Tino Anjorin:CAM:70,Harvey Vale:RM:64",
  "Chelsea FC|2022": "Mason Mount:CAM:89,Romelu Lukaku:ST:89,Kai Havertz:ST:88,Reece James:RB:88,Antonio R\xFCdiger:CB:85,Ben Chilwell:LB:85,Christian Pulisic:RW:85,Jorginho:CDM:85,Mateo Kovacic:CM:85,N'Golo Kant\xE9:CDM:85,Timo Werner:ST:85,Andreas Christensen:CB:84,Edouard Mendy:GK:84,Hakim Ziyech:RW:84,Callum Hudson-Odoi:LW:83,Sa\xFAl \xD1\xEDguez:CM:83,Ruben Loftus-Cheek:CM:82,Trevoh Chalobah:CB:82,Kepa Arrizabalaga:GK:79,Marcos Alonso:CB:78,Ross Barkley:CM:78,Kenedy:LW:76,Harvey Vale:RM:68",
  "Chelsea FC|2023": "Enzo Fern\xE1ndez:CM:89,Mason Mount:CAM:88,Reece James:RB:88,Kai Havertz:ST:87,Mykhaylo Mudryk:LW:87,Raheem Sterling:RW:87,Wesley Fofana:CB:87,Jo\xE3o F\xE9lix:CF:86,Beno\xEEt Badiashile:CB:85,Conor Gallagher:CM:85,Marc Cucurella:LB:85,Mateo Kovacic:CM:85,Ben Chilwell:LB:84,Christian Pulisic:RW:84,Armando Broja:ST:83,Kalidou Koulibaly:CB:82,Ruben Loftus-Cheek:CM:82,Kepa Arrizabalaga:GK:81,Edouard Mendy:GK:80,Trevoh Chalobah:CB:80,David Datro Fofana:ST:77,Omari Hutchinson:CAM:70,Harvey Vale:RM:68",
  "Chelsea FC|2024": "Cole Palmer:CAM:92,Enzo Fern\xE1ndez:CM:89,Christopher Nkunku:ST:88,Levi Colwill:CB:87,Nicolas Jackson:ST:87,Conor Gallagher:CM:86,Axel Disasi:CB:85,Noni Madueke:RW:85,Reece James:RB:85,Beno\xEEt Badiashile:CB:84,Malo Gusto:RB:84,Mykhaylo Mudryk:LW:84,Raheem Sterling:RW:84,Ben Chilwell:LB:83,Marc Cucurella:LB:83,Wesley Fofana:CB:83,Armando Broja:ST:82,Robert S\xE1nchez:GK:82,Djordje Petrovic:GK:81,Carney Chukwuemeka:CM:79,Cesare Casadei:CM:77",
  "Chelsea FC|2025": "Cole Palmer:CAM:91,Enzo Fern\xE1ndez:CM:89,Levi Colwill:CB:87,Pedro Neto:RW:87,Christopher Nkunku:ST:86,Marc Cucurella:LB:86,Nicolas Jackson:ST:86,Noni Madueke:RW:86,Reece James:RB:86,Malo Gusto:RB:84,Trevoh Chalobah:CB:84,Jadon Sancho:LW:83,Kiernan Dewsbury-Hall:CM:83,Wesley Fofana:CB:83,Axel Disasi:CB:82,Jo\xE3o F\xE9lix:CF:82,Robert S\xE1nchez:GK:82,Tyrique George:LW:82,Filip J\xF8rgensen:GK:80,Marc Guiu:ST:78,Mathis Amougou:CM:77",
  "Chelsea FC|2026": "Cole Palmer:CAM:91,Enzo Fern\xE1ndez:CM:90,Est\xEAv\xE3o:RW:89,Jo\xE3o Pedro:ST:89,Pedro Neto:RW:87,Reece James:RB:87,Andrey Santos:CM:86,Levi Colwill:CB:86,Marc Cucurella:LB:86,Alejandro Garnacho:LW:85,Trevoh Chalobah:CB:85,Jamie Gittens:LW:84,Jorrel Hato:LB:84,Liam Delap:ST:84,Malo Gusto:RB:84,Wesley Fofana:CB:83,Mamadou Sarr:CB:82,Robert S\xE1nchez:GK:82,Filip J\xF8rgensen:GK:79",
  "Club Brugge KV|2016": "Bj\xF6rn Engels:CB:77,Jos\xE9 Izquierdo:LW:77,Thomas Meunier:RB:76,Abdoulay Diaby:RW:74,Hans Vanaken:CAM:74,Jelle Vossen:ST:73,Ruud Vormer:CM:73,Stefano Denswil:CB:73,Brandon Mechele:CB:72,Laurens De Bock:LB:72,Lior Refaelov:CAM:72,Boli Bolingoli:LB:68,Claudemir:CDM:68,Leandro Pereira:ST:68,Ludovic Butelle:GK:68,Tuur Dierckx:RW:68,Dion Cools:RB:64,Mikel Agu:CDM:64,S\xE9bastien Bruzzese:GK:64",
  "Club Brugge KV|2017": "Jos\xE9 Izquierdo:LW:79,Bj\xF6rn Engels:CB:77,Ruud Vormer:CM:74,Hans Vanaken:CAM:73,Jelle Vossen:ST:73,Stefano Denswil:CB:73,Abdoulay Diaby:RW:72,Laurens De Bock:LB:72,Anthony Limbombe:LW:70,Beno\xEEt Poulain:CB:70,Dorin Rotariu:RW:70,Lior Refaelov:CAM:70,Ricardo van Rhijn:RB:70,Wesley Moraes:ST:70,Claudemir:CDM:68,Ethan Horvath:GK:64,Helibelton Palacios:RB:64,Ludovic Butelle:GK:64",
  "Club Brugge KV|2018": "Wesley Moraes:ST:79,Hans Vanaken:CAM:77,Marvelous Nakamba:CDM:77,Anthony Limbombe:LW:76,Jordy Clasie:CDM:76,Ruud Vormer:CM:76,Abdoulay Diaby:RW:74,Brandon Mechele:CB:74,Emmanuel Dennis:ST:74,Stefano Denswil:CB:73,Kenneth Vermeer:GK:72,Dion Cools:RB:70,Jelle Vossen:ST:70,Kr\xE9pin Diatta:RM:70,Ethan Horvath:GK:68,Ivan Tomecak:RB:64",
  "Club Brugge KV|2019": "Wesley Moraes:ST:83,Kr\xE9pin Diatta:RM:80,Arnaut Danjuma:LW:78,Emmanuel Dennis:ST:78,Marvelous Nakamba:CDM:77,Sofyan Amrabat:CDM:77,Siebe Schrijvers:CM:76,Brandon Mechele:CB:74,Clinton Mata:CB:74,Lo\xEFs Openda:ST:74,Ruud Vormer:CM:74,Stefano Denswil:CB:74,Matej Mitrovic:CB:70,Dion Cools:RB:68,Ethan Horvath:GK:68",
  "Club Brugge KV|2020": "Kr\xE9pin Diatta:RM:81,Emmanuel Dennis:ST:80,Hans Vanaken:CAM:79,Charles De Ketelaere:CAM:78,Simon Mignolet:GK:77,David Okereke:ST:76,Brandon Mechele:CB:74,\xC9der Balanta:CDM:74,Odilon Kossounou:CB:74,Simon Deli:CB:74,Lo\xEFs Openda:ST:73,Mats Rits:CDM:73,Percy Tau:RW:73,Ruud Vormer:CM:73,Siebe Schrijvers:CM:73,Eduard Sobol:LB:72,Ethan Horvath:GK:68",
  "Club Brugge KV|2021": "Charles De Ketelaere:CAM:82,Noa Lang:LW:82,Odilon Kossounou:CB:82,Hans Vanaken:CAM:80,Clinton Mata:CB:77,Brandon Mechele:CB:76,Simon Mignolet:GK:76,\xC9der Balanta:CDM:74,Mats Rits:CDM:74,David Okereke:ST:73,Ruud Vormer:CM:72,Stefano Denswil:CB:72,Youssouph Badji:ST:72,Eduard Sobol:LB:70,Noah Mbamba:CM:70,Ethan Horvath:GK:64,Ignace Van der Brempt:RB:64",
  "Club Brugge KV|2022": "Charles De Ketelaere:CAM:83,Noa Lang:LW:82,Andreas Skov Olsen:RW:81,Hans Vanaken:CAM:80,Tajon Buchanan:RW:78,Abakar Sylla:CB:77,Stanley Nsoki:CB:77,Clinton Mata:CB:76,Brandon Mechele:CB:75,\xC9der Balanta:CDM:75,Simon Mignolet:GK:75,Mats Rits:CDM:74,Noah Mbamba:CM:73,Eduard Sobol:LB:70,Ruud Vormer:CM:70",
  "Club Brugge KV|2023": "Antonio Nusa:LW:81,Noa Lang:LW:81,Andreas Skov Olsen:RW:80,Abakar Sylla:CB:79,Hans Vanaken:CAM:78,Roman Yaremchuk:ST:77,Casper Nielsen:CM:75,Brandon Mechele:CB:73,Clinton Mata:CB:73,Jorne Spileers:CB:73,Kamal Sowah:CM:72,Kyriani Sabbe:RB:70,Simon Mignolet:GK:70",
  "Club Brugge KV|2024": "Antonio Nusa:LW:83,Igor Thiago:ST:82,Andreas Skov Olsen:RW:80,Joel Ord\xF3\xF1ez:CB:80,Maxim De Cuyper:LB:78,Bjorn Meijer:LB:76,Ferran Jutgl\xE0:RW:76,Hans Vanaken:CAM:76,Hugo Vetlesen:CM:76,Jorne Spileers:CB:73,Kyriani Sabbe:RB:73,Michal Skoras:LW:73,Casper Nielsen:CM:72,Nordin Jackers:GK:68,Simon Mignolet:GK:68",
  "Club Brugge KV|2026": "Joel Ord\xF3\xF1ez:CB:84,Christos Tzolis:LW:83,Carlos Forbs:RW:80,Joaquin Seys:LB:80,Nicol\xF2 Tresoldi:ST:79,Romeo Vermant:ST:78,Mamadou Diakhon:LW:77,Kyriani Sabbe:RB:76,Hans Vanaken:CAM:74,Ludovit Reis:CM:73,Bjorn Meijer:LB:72,Hugo Siquet:RB:70,Hugo Vetlesen:CM:70,Nordin Jackers:GK:68,Shion Homma:LM:64",
  "FC Barcelona|2016": "Lionel Messi:RW:91,Luis Su\xE1rez:ST:90,Neymar:CAM:90,Sergio Busquets:CDM:87,Ivan Rakitic:CM:86,Gerard Piqu\xE9:CB:85,Andr\xE9s Iniesta:CM:84,Arda Turan:LW:84,Jordi Alba:LB:84,Sergi Roberto:CM:82,Marc-Andr\xE9 ter Stegen:GK:80,Claudio Bravo:GK:79,Javier Mascherano:CDM:79,Marc Bartra:CB:78,Rafinha:CAM:78,Aleix Vidal:RW:77,Dani Alves:RB:77,J\xE9r\xE9my Mathieu:LB:77,Sandro Ram\xEDrez:ST:73,Thomas Vermaelen:CB:72",
  "FC Barcelona|2017": "Neymar:CAM:92,Lionel Messi:RW:91,Luis Su\xE1rez:ST:90,Sergio Busquets:CDM:87,Ivan Rakitic:CM:86,Gerard Piqu\xE9:CB:85,Jordi Alba:LB:84,Andr\xE9 Gomes:CM:83,Andr\xE9s Iniesta:CM:83,Arda Turan:LW:83,Samuel Umtiti:CB:83,Marc-Andr\xE9 ter Stegen:GK:82,Sergi Roberto:CM:82,Paco Alc\xE1cer:ST:81,Denis Su\xE1rez:CAM:80,Lucas Digne:LB:80,Jasper Cillessen:GK:78,Javier Mascherano:CDM:78,Aleix Vidal:RW:76,Marlon:CB:73",
  "FC Barcelona|2018": "Lionel Messi:RW:93,Philippe Coutinho:CAM:92,Luis Su\xE1rez:ST:89,Marc-Andr\xE9 ter Stegen:GK:89,Ousmane Demb\xE9l\xE9:ST:89,Sergio Busquets:CDM:89,Ivan Rakitic:CM:88,Jordi Alba:LB:88,Samuel Umtiti:CB:88,Sergi Roberto:CM:87,Gerard Piqu\xE9:CB:86,Paco Alc\xE1cer:ST:85,Paulinho:CM:85,N\xE9lson Semedo:RB:84,Andr\xE9 Gomes:CM:83,Yerry Mina:CB:83,Lucas Digne:LB:82,Jasper Cillessen:GK:81,Denis Su\xE1rez:CAM:80,Jos\xE9 Manuel Arn\xE1iz:LW:77,Aleix Vidal:RW:76,Javier Mascherano:CDM:74,Thomas Vermaelen:CB:73,Mat\xEDas Nahuel:LW:64",
  "FC Barcelona|2019": "Lionel Messi:RW:92,Ousmane Demb\xE9l\xE9:ST:91,Marc-Andr\xE9 ter Stegen:GK:90,Philippe Coutinho:CAM:90,Arthur Melo:CM:88,Cl\xE9ment Lenglet:CB:87,Ivan Rakitic:CM:86,Jordi Alba:LB:86,Luis Su\xE1rez:ST:86,Samuel Umtiti:CB:86,Sergi Roberto:CM:86,Sergio Busquets:CDM:86,Ansu Fati:LW:85,Malcom:RW:85,N\xE9lson Semedo:RB:85,Gerard Piqu\xE9:CB:84,Carles Ale\xF1\xE1:CM:83,Jasper Cillessen:GK:80,Rafinha:CAM:79,Jean-Clair Todibo:CB:77,Moussa Wagu\xE9:RB:76",
  "FC Barcelona|2020": "Lionel Messi:RW:91,Antoine Griezmann:CF:90,Ansu Fati:LW:89,Marc-Andr\xE9 ter Stegen:GK:89,Frenkie de Jong:CM:88,Ousmane Demb\xE9l\xE9:ST:88,Arthur Melo:CM:87,Cl\xE9ment Lenglet:CB:86,Jordi Alba:LB:85,N\xE9lson Semedo:RB:85,Sergi Roberto:CM:85,Luis Su\xE1rez:ST:84,Samuel Umtiti:CB:84,Sergio Busquets:CDM:83,Riqui Puig:CM:82,Gerard Piqu\xE9:CB:81,Junior Firpo:LB:81,Neto:GK:79,Ronald Araujo:CB:79,Martin Braithwaite:ST:78,Carles P\xE9rez:RW:77,Konrad de la Fuente:LW:70",
  "FC Barcelona|2021": "Frenkie de Jong:CM:90,Ansu Fati:LW:89,Lionel Messi:RW:89,Marc-Andr\xE9 ter Stegen:GK:89,Pedri:CM:89,Antoine Griezmann:CF:87,Ousmane Demb\xE9l\xE9:ST:86,Philippe Coutinho:CAM:86,Cl\xE9ment Lenglet:CB:85,Miralem Pjani\u0107:CM:85,Ronald Araujo:CB:84,Sergi\xF1o Dest:RB:83,Francisco Trinc\xE3o:CAM:82,Ilaix Moriba:CM:82,Jordi Alba:LB:82,\xD3scar Mingueza:RB:79,Gerard Piqu\xE9:CB:78,Junior Firpo:LB:78,Martin Braithwaite:ST:77",
  "FC Barcelona|2022": "Gavi:CM:90,Pedri:CM:90,Ansu Fati:LW:87,Frenkie de Jong:CM:87,Ousmane Demb\xE9l\xE9:ST:87,Ronald Araujo:CB:87,Ferran Torres:ST:86,Memphis Depay:CF:84,Marc-Andr\xE9 ter Stegen:GK:83,Nico Gonz\xE1lez:CDM:82,Eric Garc\xEDa:CB:80,Sergi\xF1o Dest:RB:80,Alejandro Balde:LB:79,Ferran Jutgl\xE0:RW:79,Pierre-Emerick Aubameyang:ST:79,Cl\xE9ment Lenglet:CB:78,Jordi Alba:LB:77,Sergio Busquets:CDM:77,Abde Ezzalzouli:LW:76,Riqui Puig:CM:76,\xD3scar Mingueza:RB:74,Gerard Piqu\xE9:CB:73,Ilias Akhomach:RW:70,Neto:GK:70",
  "FC Barcelona|2023": "Frenkie de Jong:CM:90,Gavi:CM:90,Pedri:CM:90,Ronald Araujo:CB:88,Jules Kound\xE9:RB:87,Lamine Yamal:RW:87,Ousmane Demb\xE9l\xE9:ST:87,Raphinha:LW:87,Alejandro Balde:LB:86,Andreas Christensen:CB:85,Marc-Andr\xE9 ter Stegen:GK:85,Robert Lewandowski:ST:85,Ansu Fati:LW:84,Ferran Torres:ST:84,Franck Kessi\xE9:CM:83,Eric Garc\xEDa:CB:79,I\xF1aki Pe\xF1a:GK:76,Marcos Alonso:CB:76,Jordi Alba:LB:73,Ilias Akhomach:RW:70,Pablo Torre:CAM:70",
  "FC Barcelona|2024": "Lamine Yamal:RW:93,Gavi:CM:90,Pedri:CM:90,Raphinha:LW:89,Frenkie de Jong:CM:88,Pau Cubars\xED:CB:88,Ronald Araujo:CB:88,Jules Kound\xE9:RB:87,Alejandro Balde:LB:86,Ferm\xEDn L\xF3pez:CAM:86,Andreas Christensen:CB:85,Ferran Torres:ST:83,Jo\xE3o Cancelo:RB:83,Jo\xE3o F\xE9lix:CF:83,Marc-Andr\xE9 ter Stegen:GK:83,Vitor Roque:ST:83,\u0130lkay G\xFCndo\u011Fan:CM:80,Robert Lewandowski:ST:79,I\xF1aki Pe\xF1a:GK:77,I\xF1igo Mart\xEDnez:CB:74,Gerard Mart\xEDn:LB:73",
  "FC Barcelona|2025": "Lamine Yamal:RW:94,Pedri:CM:92,Raphinha:LW:90,Pau Cubars\xED:CB:89,Ferm\xEDn L\xF3pez:CAM:88,Gavi:CM:88,Jules Kound\xE9:RB:88,Alejandro Balde:LB:87,Dani Olmo:CAM:87,Ferran Torres:ST:86,Frenkie de Jong:CM:86,Ronald Araujo:CB:86,Eric Garc\xEDa:CB:83,Gerard Mart\xEDn:LB:81,Andreas Christensen:CB:79,H\xE9ctor Fort:RB:78,Marc-Andr\xE9 ter Stegen:GK:78,Robert Lewandowski:ST:78,Pau V\xEDctor:ST:77,I\xF1aki Pe\xF1a:GK:76",
  "FC Barcelona|2026": "Lamine Yamal:RW:94,Pedri:CM:92,Ferm\xEDn L\xF3pez:CAM:90,Pau Cubars\xED:CB:89,Raphinha:LW:89,Jules Kound\xE9:RB:88,Alejandro Balde:LB:87,Dani Olmo:CAM:87,Ferran Torres:ST:86,Frenkie de Jong:CM:86,Joan Garc\xEDa:GK:85,Marcus Rashford:LW:85,Eric Garc\xEDa:CB:84,Gavi:CM:83,Gerard Mart\xEDn:LB:82,Ronald Araujo:CB:81,Roony Bardghji:RW:79,Andreas Christensen:CB:77,Jo\xE3o Cancelo:RB:77,Robert Lewandowski:ST:76",
  "FC Porto|2016": "Yacine Brahimi:LW:82,H\xE9ctor Herrera:CM:80,Danilo Pereira:CB:79,Bruno Martins Indi:CB:78,R\xFAben Neves:CDM:78,Andr\xE9 Silva:ST:77,Jes\xFAs Corona:RW:77,Miguel Lay\xFAn:RB:77,Vincent Aboubakar:ST:77,Andr\xE9 Andr\xE9:CM:76,Iv\xE1n Marcano:CB:76,Maicon:CB:76,Maxi Pereira:RB:76,Alberto Bueno:CF:73,Iker Casillas:GK:72,Evandro:CAM:70,S\xE9rgio Oliveira:CM:70,Varela:LW:70,Francisco Ramos:CM:68,Gleison Moreira:RW:64",
  "FC Porto|2017": "Andr\xE9 Silva:ST:82,Danilo Pereira:CB:81,Yacine Brahimi:LW:81,H\xE9ctor Herrera:CM:79,\xD3liver Torres:CM:79,Jes\xFAs Corona:RW:78,Alex Telles:LB:77,Felipe:CB:77,R\xFAben Neves:CDM:77,Diogo Jota:LW:76,Iv\xE1n Marcano:CB:76,Miguel Lay\xFAn:RB:76,Ot\xE1vio:CAM:76,Laurent Depoitre:ST:72,Willy Boly:CB:72,Iker Casillas:GK:70,Kelvin Oliveira:RW:70,Jo\xE3o Carlos Teixeira:CAM:64,Jos\xE9 S\xE1:GK:64",
  "FC Porto|2018": "Yacine Brahimi:LW:83,Alex Telles:LB:82,Danilo Pereira:CB:82,Moussa Marega:ST:82,H\xE9ctor Herrera:CM:81,Ricardo Pereira:RB:81,Vincent Aboubakar:ST:80,Felipe:CB:79,\xD3liver Torres:CM:78,Ot\xE1vio:CAM:77,Iv\xE1n Marcano:CB:76,S\xE9rgio Oliveira:CM:76,Tiquinho Soares:ST:76,Diego Reyes:CB:74,Andr\xE9 Andr\xE9:CM:73,Miguel Lay\xFAn:RB:73,Hern\xE2ni:LW:70,Jos\xE9 S\xE1:GK:70,Iker Casillas:GK:64",
  "FC Porto|2019": "\xC9der Milit\xE3o:CB:86,Alex Telles:LB:85,Danilo Pereira:CB:83,Moussa Marega:ST:83,Yacine Brahimi:LW:83,Felipe:CB:82,H\xE9ctor Herrera:CM:82,Jes\xFAs Corona:RW:82,\xD3liver Torres:CM:80,Ot\xE1vio:CAM:80,Vincent Aboubakar:ST:80,Tiquinho Soares:ST:78,Chancel Mbemba:CB:72,Hern\xE2ni:LW:70,Bruno Costa:CM:68,Tom\xE1s Esteves:RM:68,Iker Casillas:GK:64",
  "FC Porto|2020": "Alex Telles:LB:85,Jes\xFAs Corona:RW:83,Danilo Pereira:CB:82,F\xE1bio Silva:ST:82,Moussa Marega:ST:81,Ot\xE1vio:CAM:80,Shoya Nakajima:CAM:80,Luis D\xEDaz:LW:79,Matheus Uribe:CDM:77,Tiquinho Soares:ST:77,Agust\xEDn Marches\xEDn:GK:76,Rom\xE1rio Bar\xF3:CDM:76,S\xE9rgio Oliveira:CM:76,Tom\xE1s Esteves:RM:76,Diogo Costa:GK:73,Wilson Manaf\xE1:RB:72,Renzo Saravia:RB:70",
  "FC Porto|2021": "Luis D\xEDaz:LW:85,Jes\xFAs Corona:RW:83,Ot\xE1vio:CAM:82,Moussa Marega:ST:81,S\xE9rgio Oliveira:CM:81,Chancel Mbemba:CB:80,Felipe Anderson:LW:80,Malang Sarr:CB:80,Matheus Uribe:CDM:80,Mehdi Taremi:ST:80,Marko Gruji\u0107:CDM:79,Agust\xEDn Marches\xEDn:GK:77,Diogo Leite:CB:77,F\xE1bio Vieira:CAM:77,Francisco Concei\xE7\xE3o:RW:76,Wilson Manaf\xE1:RB:76,Zaidu Sanusi:LB:76",
  "FC Porto|2022": "Vitinha:CDM:86,Diogo Costa:GK:84,F\xE1bio Vieira:CAM:83,Ot\xE1vio:CAM:83,Evanilson:ST:82,Pep\xEA:RW:82,Mehdi Taremi:ST:81,Chancel Mbemba:CB:80,Matheus Uribe:CDM:80,Jo\xE3o M\xE1rio:RB:79,Zaidu Sanusi:LB:77,Francisco Concei\xE7\xE3o:RW:76,Toni Mart\xEDnez:ST:76,R\xFAben Semedo:CB:73,Agust\xEDn Marches\xEDn:GK:72,Bruno Costa:CM:70,Tom\xE1s Esteves:RM:68",
  "FC Porto|2023": "Diogo Costa:GK:86,Ot\xE1vio:CAM:84,Evanilson:ST:82,Galeno:LW:82,Pep\xEA:RW:82,David Carmo:CB:80,Jo\xE3o M\xE1rio:RB:80,Mehdi Taremi:ST:80,Stephen Eustaquio:CM:79,Gabriel Veron:RW:78,Toni Mart\xEDnez:ST:76,Zaidu Sanusi:LB:76,F\xE1bio Cardoso:CB:72,Rodrigo Mora:CAM:70,Cl\xE1udio Ramos:GK:68",
  "FC Porto|2024": "Diogo Costa:GK:86,Evanilson:ST:84,Francisco Concei\xE7\xE3o:RW:84,Galeno:LW:83,Pep\xEA:RW:83,Jo\xE3o M\xE1rio:RB:79,Stephen Eustaquio:CM:79,David Carmo:CB:78,Mehdi Taremi:ST:77,Rodrigo Mora:CAM:77,Iv\xE1n Jaime:CAM:76,Martim Fernandes:RB:76,Wendell:LB:76,Toni Mart\xEDnez:ST:73,Vasco Sousa:CM:73,Jo\xE3o Mendes:LB:70",
  "FC Porto|2025": "Samu Aghehowa:ST:86,Diogo Costa:GK:85,Rodrigo Mora:CAM:85,F\xE1bio Vieira:CAM:82,Galeno:LW:82,Pep\xEA:RW:82,William Gomes:RW:81,Francisco Moura:LB:79,Nehu\xE9n P\xE9rez:CB:79,Martim Fernandes:RB:78,Jo\xE3o M\xE1rio:RB:77,Stephen Eustaquio:CM:77,Tiago Djal\xF3:CB:77,Danny Namaso:LW:73,Vasco Sousa:CM:72,Cl\xE1udio Ramos:GK:64",
  "FC Porto|2026": "Samu Aghehowa:ST:86,Diogo Costa:GK:85,Rodrigo Mora:CAM:85,Jakub Kiwior:CB:83,Victor Froholdt:CM:83,Borja Sainz:LW:82,Gabri Veiga:CAM:82,Oskar Pietuszewski:LW:81,Pep\xEA:RW:81,William Gomes:RW:81,Alberto Costa:RB:79,Nehu\xE9n P\xE9rez:CB:79,Francisco Moura:LB:78,Jan Bednarek:CB:78,Martim Fernandes:RB:78,Terem Moffi:ST:77,Stephen Eustaquio:CM:76,Deniz G\xFCl:ST:74,Dominik Prpi\u0107:CB:73,Zaidu Sanusi:LB:70",
  "Fenerbahce|2016": "Nani:LW:80,Lazar Markovic:RW:79,Caner Erkin:LB:78,Mehmet Topal:CDM:78,Robin van Persie:ST:78,Simon Kjaer:CB:77,Alper Potuk:LW:76,Fernand\xE3o:ST:76,Ozan Tufan:CM:76,Souza:CDM:76,G\xF6khan G\xF6n\xFCl:RB:75,Diego:CAM:74,Fabiano:GK:73,Hasan Ali Kald\u0131r\u0131m:LB:73,\u015Eener \xD6zbayrakl\u0131:RB:73,Abdoulaye Ba:CB:70,Salih U\xE7an:CM:70,Volkan Demirel:GK:70,Bruno Alves:CB:68,Mehmet Topuz:RM:64",
  "Fenerbahce|2017": "Simon Kjaer:CB:79,Jeremain Lens:RW:78,Moussa Sow:ST:78,Souza:CDM:77,Alper Potuk:LW:76,Emmanuel Emenike:ST:76,Mehmet Topal:CDM:76,Ozan Tufan:CM:76,Robin van Persie:ST:76,Martin Skrtel:CB:75,Volkan \u015Een:LW:75,Hasan Ali Kald\u0131r\u0131m:LB:74,Mehmet Ekici:CAM:74,Gregory van der Wiel:RB:73,\u0130smail K\xF6yba\u015F\u0131:LM:73,Roman Neust\xE4dter:CB:73,\u015Eener \xD6zbayrakl\u0131:RB:73,Aatif Chahechouhe:CAM:70,Salih U\xE7an:CM:70,Fabiano:GK:68,Volkan Demirel:GK:68",
  "Fenerbahce|2018": "Giuliano:CAM:78,Souza:CDM:77,Vincent Janssen:ST:77,Alper Potuk:LW:73,Hasan Ali Kald\u0131r\u0131m:LB:72,Mauricio Isla:RB:72,Mehmet Topal:CDM:72,Eljif Elmas:CAM:70,Lu\xEDs Neto:CB:70,Martin Skrtel:CB:70,Roberto Soldado:ST:70,Roman Neust\xE4dter:CB:70,\u0130smail K\xF6yba\u015F\u0131:LM:68,Nabil Dirar:RB:68,Volkan Demirel:GK:64",
  "Fenerbahce|2019": "Eljif Elmas:CAM:80,Victor Moses:RW:79,Andr\xE9 Ayew:ST:77,Islam Slimani:ST:77,Jailson:CDM:74,Miha Zajc:CM:74,Tolgay Arslan:CAM:73,Serdar Aziz:CB:72,Hasan Ali Kald\u0131r\u0131m:LB:70,Alper Potuk:LW:68,Ferdi Kad\u0131o\u011Flu:LB:68,Harun Tekin:GK:68,Mauricio Isla:RB:68,Mehmet Topal:CDM:68,\u0130smail K\xF6yba\u015F\u0131:LM:64",
  "Fenerbahce|2021": "Altay Bay\u0131nd\u0131r:GK:80,Ozan Tufan:CM:78,Dimitrios Pelkas:CAM:76,Ferdi Kad\u0131o\u011Flu:LB:75,Ally Samatta:ST:74,Bright Osayi-Samuel:RB:73,Luiz Gustavo:CDM:73,Mesut \xD6zil:CAM:73,Enner Valencia:ST:72,Marcel Tisserand:CB:72,Filip Novak:LB:68,Sinan G\xFCm\xFC\u015F:RW:64",
  "Fenerbahce|2022": "Min-jae Kim:CB:84,Altay Bay\u0131nd\u0131r:GK:80,Attila Szalai:CB:79,Ferdi Kad\u0131o\u011Flu:LB:78,Arda G\xFCler:CAM:77,\u0130rfan Can Kahveci:RW:77,Mergim Berisha:ST:77,Miguel Crespo:CM:77,Ozan Tufan:CM:75,Miha Zajc:CM:74,Berke \xD6zer:GK:72,Enner Valencia:ST:72,Marcel Tisserand:CB:72,Mert Hakan Yanda\u015F:CAM:72,Serdar Dursun:ST:72,Luiz Gustavo:CDM:70,Filip Novak:LB:68,Arda Okan Kurtulan:RM:64,Burak Kapacak:RB:64",
  "Fenerbahce|2023": "Ferdi Kad\u0131o\u011Flu:LB:81,Altay Bay\u0131nd\u0131r:GK:79,Arda G\xFCler:CAM:79,Attila Szalai:CB:79,\u0130rfan Can Kahveci:RW:77,Michy Batshuayi:ST:77,Miguel Crespo:CM:77,Bright Osayi-Samuel:RB:76,Jayden Oosterwolde:CB:76,Joshua King:ST:74,Lincoln:CAM:74,Miha Zajc:CM:74,Emre Mor:RW:73,Ezgjan Alioski:LB:73,Luan Peres:CB:73,Enner Valencia:ST:72,\u0130rfan Can E\u011Fribayat:GK:68",
  "Fenerbahce|2024": "Ferdi Kad\u0131o\u011Flu:LB:83,Fred:CM:81,Sebastian Szymanski:CAM:81,Cengiz \xDCnder:RW:80,Jayden Oosterwolde:CB:79,\xC7a\u011Flar S\xF6y\xFCnc\xFC:CB:78,Dominik Livakovic:GK:78,Alexander Djiku:CB:77,\u0130rfan Can Kahveci:RW:77,Rodrigo Bec\xE3o:CB:77,Bright Osayi-Samuel:RB:76,Mert M\xFCld\xFCr:RB:76,Michy Batshuayi:ST:76,Ryan Kent:LW:73,Edin Dzeko:ST:70,Miha Zajc:CM:70,Mert Hakan Yanda\u015F:CAM:68",
  "Fenerbahce|2026": "Jhon Dur\xE1n:ST:82,Kerem Akt\xFCrko\u011Flu:LW:82,Youssef En-Nesyri:ST:81,Dorgeles Nene:RW:80,Jayden Oosterwolde:CB:80,Ederson:GK:79,Marco Asensio:CAM:79,Milan \u0160kriniar:CB:78,Sebastian Szymanski:CAM:78,Archie Brown:LB:77,Mert M\xFCld\xFCr:RB:76,N\xE9lson Semedo:RB:76,O\u011Fuz Ayd\u0131n:LW:76,Fred:CM:74,\xC7a\u011Flar S\xF6y\xFCnc\xFC:CB:73,Levent Mercan:LB:73",
  "Feyenoord Rotterdam|2016": "Kenneth Vermeer:GK:75,Sven van Beek:CB:74,Terence Kongolo:CB:74,Eric Botteghin:CB:73,Marko Vejinovi\u0107:CDM:73,Rick Karsdorp:RB:73,Eljero Elia:LW:72,Jens Toornstra:CAM:72,Jan-Arie van der Heijden:CB:70,Karim El Ahmadi:CDM:70,Michiel Kramer:ST:70,Simon Gustafson:CAM:70,Bilal Ba\u015Fa\xE7\u0131ko\u011Flu:LW:68,Dirk Kuyt:RW:68,Miquel Nelom:LB:64",
  "Feyenoord Rotterdam|2017": "Nicolai J\xF8rgensen:ST:79,Rick Karsdorp:RB:77,Terence Kongolo:CB:77,Tonny Vilhena:CM:77,Eric Botteghin:CB:76,Jens Toornstra:CAM:76,Eljero Elia:LW:74,Kenneth Vermeer:GK:74,Jan-Arie van der Heijden:CB:73,Sven van Beek:CB:73,Karim El Ahmadi:CDM:72,Bilal Ba\u015Fa\xE7\u0131ko\u011Flu:LW:70,Marko Vejinovi\u0107:CDM:70,Michiel Kramer:ST:70,Brad Jones:GK:68,Lucas Woudenberg:LB:68,Simon Gustafson:CAM:68,Miquel Nelom:LB:64",
  "Feyenoord Rotterdam|2018": "Nicolai J\xF8rgensen:ST:79,Steven Berghuis:RW:78,Tonny Vilhena:CM:78,Eric Botteghin:CB:74,Jeremiah St. Juste:CB:74,Ridgeciano Haps:LB:74,Sam Larsson:CAM:74,Sven van Beek:CB:74,Sofyan Amrabat:CDM:73,Jan-Arie van der Heijden:CB:72,Jean-Paul Bo\xEBtius:CAM:72,Karim El Ahmadi:CDM:72,Justin Bijlow:GK:70,Tyrell Malacia:LB:70,Bart Nieuwkoop:RB:68,Bilal Ba\u015Fa\xE7\u0131ko\u011Flu:LW:68,Brad Jones:GK:68",
  "Feyenoord Rotterdam|2019": "Steven Berghuis:RW:79,Tonny Vilhena:CM:79,Jeremiah St. Juste:CB:77,Nicolai J\xF8rgensen:ST:76,Orkun K\xF6k\xE7\xFC:CM:76,Jordy Clasie:CDM:74,Ridgeciano Haps:LB:74,Sam Larsson:CAM:74,Jens Toornstra:CAM:72,Yassin Ayoub:CM:72,Justin Bijlow:GK:70,Luis Sinisterra:LW:70,Tyrell Malacia:LB:70,Calvin Verdonk:LB:68,Kenneth Vermeer:GK:68,Wouter Burger:CDM:68",
  "Feyenoord Rotterdam|2020": "Orkun K\xF6k\xE7\xFC:CM:80,Marcos Senesi:CB:79,Steven Berghuis:RW:79,Luis Sinisterra:LW:78,Justin Bijlow:GK:76,Uros Spajic:CB:75,Rick Karsdorp:RB:74,Nicolai J\xF8rgensen:ST:73,Ridgeciano Haps:LB:73,Leroy Fer:CDM:72,Lutsharel Geertruida:RB:72,R\xF3bert Bo\u017Een\xEDk:ST:72,Sam Larsson:CAM:72,Tyrell Malacia:LB:72,Jens Toornstra:CAM:70,Renato Tapia:CDM:70,Luciano Narsingh:RW:68,O\u011Fuzhan \xD6zyakup:CM:68",
  "Feyenoord Rotterdam|2021": "Marcos Senesi:CB:81,Orkun K\xF6k\xE7\xFC:CM:79,Steven Berghuis:RW:79,Justin Bijlow:GK:78,Luis Sinisterra:LW:78,Tyrell Malacia:LB:77,Lutsharel Geertruida:RB:76,Ridgeciano Haps:LB:73,Bart Nieuwkoop:RB:70,Leroy Fer:CDM:70,R\xF3bert Bo\u017Een\xEDk:ST:70,Jens Toornstra:CAM:68",
  "Feyenoord Rotterdam|2022": "Orkun K\xF6k\xE7\xFC:CM:83,Luis Sinisterra:LW:82,Tyrell Malacia:LB:82,Marcos Senesi:CB:80,Fredrik Aursnes:CM:79,Justin Bijlow:GK:79,Lutsharel Geertruida:RB:78,Guus Til:CAM:76,Reiss Nelson:LW:76,Cyriel Dessers:ST:74,Marcus Pedersen:RB:74,Gernot Trauner:CB:73,Patrik W\xE5lemark:CAM:73,Alireza Jahanbakhsh:RW:72,Quilindschy Hartman:LB:64",
  "Feyenoord Rotterdam|2023": "Santiago Gimenez:ST:86,D\xE1vid Hancko:CB:84,Lutsharel Geertruida:RB:84,Orkun K\xF6k\xE7\xFC:CM:84,Quilindschy Hartman:LB:82,Quinten Timber:CM:82,Sebastian Szymanski:CAM:81,Mats Wieffer:RB:80,Igor Paix\xE3o:LW:79,Justin Bijlow:GK:79,Javair\xF4 Dilrosun:LW:74,Gernot Trauner:CB:73,Alireza Jahanbakhsh:RW:72,Antoni Milambo:CAM:72,Marcos L\xF3pez:LB:72,Timon Wellenreuther:GK:70",
  "Feyenoord Rotterdam|2024": "Santiago Gimenez:ST:86,D\xE1vid Hancko:CB:84,Lutsharel Geertruida:RB:84,Quinten Timber:CM:84,Mats Wieffer:RB:83,Yankuba Minteh:RW:83,Quilindschy Hartman:LB:82,Antoni Milambo:CAM:80,Igor Paix\xE3o:LW:80,Calvin Stengs:CAM:79,Justin Bijlow:GK:79,Thomas Beelen:CB:78,Ayase Ueda:ST:76,Timon Wellenreuther:GK:76,Leo Sauer:LW:73,Gjivai Zechi\xEBl:CM:72,Marcos L\xF3pez:LB:70,Jorrit Hendrix:LM:68",
  "Feyenoord Rotterdam|2025": "D\xE1vid Hancko:CB:84,Igor Paix\xE3o:LW:84,Quinten Timber:CM:83,Santiago Gimenez:ST:83,Givairo Read:RB:82,Anis Hadj Moussa:RW:81,Antoni Milambo:CAM:81,Quilindschy Hartman:LB:80,Ayase Ueda:ST:79,Ibrahim Osman:LW:78,Hugo Bueno:LB:77,Calvin Stengs:CAM:76,Gjivai Zechi\xEBl:CM:76,Thomas Beelen:CB:76,Jordan Lotomba:RB:75,Timon Wellenreuther:GK:74,Juli\xE1n Carranza:ST:73,Justin Bijlow:GK:73",
  "Feyenoord Rotterdam|2026": "Givairo Read:RB:82,Anis Hadj Moussa:RW:81,Luciano Valente:CM:80,Ayase Ueda:ST:79,Anel Ahmedhodzic:CB:78,Sem Steijn:CAM:78,Jakub Moder:CM:77,Tsuyoshi Watanabe:CB:77,Jordan Bos:LB:76,Leo Sauer:LW:76,Thomas Beelen:CB:76,Gijs Smal:LB:74,Timon Wellenreuther:GK:74,Raheem Sterling:RW:73,Casper Tengstedt:ST:72,Jordan Lotomba:RB:72,Aymen Sliti:LW:70,Steven Benda:GK:64",
  "Galatasaray|2016": "Fernando Muslera:GK:79,Wesley Sneijder:CAM:79,Aur\xE9lien Chedjou:CB:76,Burak Y\u0131lmaz:ST:76,Lukas Podolski:ST:76,Sel\xE7uk \u0130nan:CM:76,Semih Kaya:CB:76,Yasin \xD6ztekin:ST:74,Ryan Donk:CB:73,Emre \xC7olak:CAM:72,Jason Denayer:CB:72,Sinan G\xFCm\xFC\u015F:RW:72,Jos\xE9 Rodr\xEDguez:CM:70,Olcan Ad\u0131n:RW:70,Cenk G\xF6nen:GK:68,Lionel Carole:LB:68,Martin Linnes:RB:68,Tar\u0131k \xC7amdal:RB:68,Hakan Balta:LB:64,Hamit Alt\u0131ntop:RM:64",
  "Galatasaray|2017": "Bruma:LW:79,Fernando Muslera:GK:79,Wesley Sneijder:CAM:77,Eren Derdiyok:ST:74,Lukas Podolski:ST:74,Ahmet \xC7al\u0131k:CB:73,Josu\xE9:CAM:73,Semih Kaya:CB:73,Serdar Aziz:CB:73,Tolga Cigerci:CDM:73,Yasin \xD6ztekin:ST:73,Aur\xE9lien Chedjou:CB:72,Garry Rodrigues:RW:72,Lionel Carole:LB:72,Sel\xE7uk \u0130nan:CM:72,Nigel de Jong:CDM:70,Sinan G\xFCm\xFC\u015F:RW:70,Luis Pedro Cavanda:RB:68,Sabri Sar\u0131o\u011Flu:RB:68,Cenk G\xF6nen:GK:64,Hakan Balta:LB:64",
  "Galatasaray|2018": "Henry Onyekuru:LW:77,Fernando:CDM:76,Fernando Muslera:GK:76,Garry Rodrigues:RW:76,Jason Denayer:CB:76,Maicon:CB:76,Youn\xE8s Belhanda:CAM:76,Mariano:RB:73,Baf\xE9timbi Gomis:ST:72,Eren Derdiyok:ST:72,Serdar Aziz:CB:72,Tolga Cigerci:CDM:72,Martin Linnes:RB:68,Sel\xE7uk \u0130nan:CM:68,Sinan G\xFCm\xFC\u015F:RW:68",
  "Galatasaray|2019": "Henry Onyekuru:LW:79,Badou Ndiaye:CDM:78,Mbaye Diagne:ST:77,Christian Luyindama:CB:76,Sofiane Feghouli:CAM:76,Emre Akbaba:CAM:74,Fernando Muslera:GK:73,Mariano:RB:70,Martin Linnes:RB:70,\xD6mer Bayram:LB:68,Sinan G\xFCm\xFC\u015F:RW:68,Yunus Akg\xFCn:RW:68",
  "Galatasaray|2020": "Mario Lemina:CDM:79,Jean Micha\xEBl Seri:CDM:78,Marcelo Saracchi:LB:77,Henry Onyekuru:LW:76,Sofiane Feghouli:CAM:76,Radamel Falcao:ST:74,Fernando Muslera:GK:73,Mbaye Diagne:ST:73,Youn\xE8s Belhanda:CAM:73,Florin Andone:ST:72,\xD6mer Bayram:LB:72,Emre Mor:RW:68,Martin Linnes:RB:68,Mariano:RB:64,Okan Kocuk:GK:64",
  "Galatasaray|2021": "Gedson Fernandes:CM:79,Marc\xE3o:CB:78,Christian Luyindama:CB:76,Henry Onyekuru:LW:76,Mostafa Mohamed:ST:75,Emre K\u0131l\u0131n\xE7:LW:74,Marcelo Saracchi:LB:74,Taylan Antalyal\u0131:CDM:74,Halil Dervi\u015Fo\u011Flu:ST:73,Fernando Muslera:GK:72,Sofiane Feghouli:CAM:72,Youn\xE8s Belhanda:CAM:72,Martin Linnes:RB:70,Mbaye Diagne:ST:70,Peter Etebo:CDM:70,\xD6mer Bayram:LB:68",
  "Galatasaray|2022": "Kerem Akt\xFCrko\u011Flu:LW:80,Marc\xE3o:CB:79,Victor Nelsson:CB:79,Alexandru Cic\xE2ld\u0103u:CAM:77,Erick Pulgar:CDM:76,Mostafa Mohamed:ST:75,Sacha Boey:RB:75,Berkan Kutlu:CM:74,Olimpiu Moru\u021Ban:RW:73,Patrick van Aanholt:LB:73,Emre K\u0131l\u0131n\xE7:LW:72,Halil Dervi\u015Fo\u011Flu:ST:72,DeAndre Yedlin:RB:70,Fernando Muslera:GK:70,Sofiane Feghouli:CAM:68",
  "Galatasaray|2023": "Sacha Boey:RB:82,Mauro Icardi:ST:81,Victor Nelsson:CB:81,Kerem Akt\xFCrko\u011Flu:LW:80,Abd\xFClkerim Bardakc\u0131:CB:77,Bar\u0131\u015F Alper Y\u0131lmaz:LW:76,Milot Rashica:RW:76,S\xE9rgio Oliveira:CM:76,Yunus Akg\xFCn:RW:76,L\xE9o Dubois:RB:75,Fredrik Midtsj\xF8:CM:74,Berkan Kutlu:CM:73,Dries Mertens:CF:72,Kaz\u0131mcan Karata\u015F:LB:70,Fernando Muslera:GK:68,Okan Kocuk:GK:64",
  "Girona FC|2023": "Savinho:LW:83,Rodrigo Riquelme:LW:82,Viktor Tsygankov:RW:82,Aleix Garc\xEDa:CM:81,Miguel Guti\xE9rrez:LB:81,Yangel Herrera:CM:81,Arnau Mart\xEDnez:RB:79,Taty Castellanos:ST:79,Yan Couto:RM:78,Iv\xE1n Mart\xEDn:CM:77,Santiago Bueno:CB:76,Paulo Gazzaniga:GK:72,Ram\xF3n Terrats:CM:72,Javi Hern\xE1ndez:LB:70,Valery Fern\xE1ndez:RW:70",
  "Girona FC|2026": "Vitor Reis:CB:83,Claudio Echeverri:CAM:79,Viktor Tsygankov:RW:79,Vladyslav Vanat:ST:79,Y\xE1ser Asprilla:RW:79,Bryan Gil:LW:78,Arnau Mart\xEDnez:RB:77,Azzedine Ounahi:CM:77,Iv\xE1n Mart\xEDn:CM:74,Fran Beltr\xE1n:CM:73,\xC1lex Moreno:LB:72,Hugo Rinc\xF3n:RB:72,Marc-Andr\xE9 ter Stegen:GK:72,Paulo Gazzaniga:GK:68,Thomas Lemar:CAM:68",
  "Inter Milan|2016": "Mauro Icardi:ST:85,Geoffrey Kondogbia:CDM:82,Ivan Peri\u0161i\u0107:LW:82,Marcelo Brozovi\u0107:CDM:81,Jeison Murillo:CB:80,Miranda:CB:80,Stevan Joveti\u0107:CF:80,Adem Ljajic:CAM:79,Gary Medel:CB:79,Samir Handanovi\u010D:GK:79,Fredy Guar\xEDn:CM:77,Juan Jesus:CB:77,Alex Telles:LB:76,Davide Santon:LB:76,Jonathan Biabiany:RW:76",
  "Inter Milan|2017": "Mauro Icardi:ST:89,Ivan Peri\u0161i\u0107:LW:86,Jo\xE3o M\xE1rio:CAM:84,Antonio Candreva:RW:82,Marcelo Brozovi\u0107:CDM:82,\xC9ver Banega:CM:81,Gabriel Barbosa:ST:81,Geoffrey Kondogbia:CDM:81,Roberto Gagliardini:CM:81,Danilo D'Ambrosio:CB:79,Gary Medel:CB:79,Jeison Murillo:CB:79,Miranda:CB:79,Samir Handanovi\u010D:GK:79,\xC9der:ST:78,Cristian Ansaldi:LB:74,Davide Santon:LB:74,Jonathan Biabiany:RW:73,Daniele Padelli:GK:64",
  "Inter Milan|2018": "Mauro Icardi:ST:90,Jo\xE3o Cancelo:RB:87,Milan \u0160kriniar:CB:87,Ivan Peri\u0161i\u0107:LW:86,Marcelo Brozovi\u0107:CDM:86,Rafinha:CAM:83,Mat\xEDas Vecino:CM:82,Roberto Gagliardini:CM:81,Antonio Candreva:RW:80,Dalbert:LB:78,Danilo D'Ambrosio:CB:78,Nicol\xF2 Zaniolo:CF:77,Yann Karamoh:LW:77,\xC9der:ST:76,Miranda:CB:76,Samir Handanovi\u010D:GK:76,Borja Valero:CM:74,Andrea Ranocchia:CB:73,Davide Santon:LB:73,Andrea Pinamonti:ST:72,Jens Odgaard:CAM:68",
  "Inter Milan|2019": "Mauro Icardi:ST:90,Lautaro Mart\xEDnez:ST:89,Marcelo Brozovi\u0107:CDM:87,Milan \u0160kriniar:CB:87,Stefan de Vrij:CB:87,Ivan Peri\u0161i\u0107:LW:84,Matteo Politano:RW:83,Radja Nainggolan:CM:83,Keita Bald\xE9:LW:82,Mat\xEDas Vecino:CM:82,Jo\xE3o M\xE1rio:CAM:80,Danilo D'Ambrosio:CB:79,Kwadwo Asamoah:LM:79,Roberto Gagliardini:CM:79,Dalbert:LB:78,Antonio Candreva:RW:76,Samir Handanovi\u010D:GK:74,Miranda:CB:72,Borja Valero:CM:70",
  "Inter Milan|2020": "Romelu Lukaku:ST:90,Lautaro Mart\xEDnez:ST:88,Nicol\xF2 Barella:CM:87,Stefan de Vrij:CB:87,Alessandro Bastoni:CB:86,Marcelo Brozovi\u0107:CDM:86,Milan \u0160kriniar:CB:86,Matteo Politano:RW:82,Stefano Sensi:CM:82,Alexis S\xE1nchez:CF:81,Mat\xEDas Vecino:CM:81,Roberto Gagliardini:CM:79,Cristiano Biraghi:LB:77,Federico Dimarco:LB:76,Victor Moses:RW:76,Samir Handanovi\u010D:GK:73,Lucien Agoum\xE9:CDM:72,Ashley Young:RB:70",
  "Inter Milan|2021": "Romelu Lukaku:ST:90,Lautaro Mart\xEDnez:ST:89,Achraf Hakimi:RB:88,Milan \u0160kriniar:CB:88,Nicol\xF2 Barella:CM:88,Alessandro Bastoni:CB:87,Stefan de Vrij:CB:86,Christian Eriksen:CAM:85,Marcelo Brozovi\u0107:CDM:85,Andrea Pinamonti:ST:80,Roberto Gagliardini:CM:79,Stefano Sensi:CM:79,Ivan Peri\u0161i\u0107:LW:77,Alexis S\xE1nchez:CF:76,Mat\xEDas Vecino:CM:76,Matteo Darmian:RB:76,Ionu\u021B Radu:GK:74,Samir Handanovi\u010D:GK:70,Aleksandar Kolarov:LB:68",
  "Inter Milan|2022": "Lautaro Mart\xEDnez:ST:89,Milan \u0160kriniar:CB:88,Nicol\xF2 Barella:CM:88,Alessandro Bastoni:CB:87,Marcelo Brozovi\u0107:CDM:85,Stefan de Vrij:CB:84,Denzel Dumfries:RB:83,Joaqu\xEDn Correa:CF:83,Robin Gosens:LB:83,Federico Dimarco:LB:82,Ivan Peri\u0161i\u0107:LW:77,Roberto Gagliardini:CM:77,Mat\xEDas Vecino:CM:73,Matteo Darmian:RB:73,Edin Dzeko:ST:72,Ionu\u021B Radu:GK:72,Samir Handanovi\u010D:GK:68",
  "Inter Milan|2023": "Lautaro Mart\xEDnez:ST:91,Nicol\xF2 Barella:CM:89,Alessandro Bastoni:CB:87,Federico Dimarco:LB:86,Milan \u0160kriniar:CB:86,Andr\xE9 Onana:GK:85,Romelu Lukaku:ST:85,Denzel Dumfries:RB:83,Joaqu\xEDn Correa:CF:79,Robin Gosens:LB:79,Stefan de Vrij:CB:77,Raoul Bellanova:RM:76,Henrikh Mkhitaryan:CM:74,Edin Dzeko:ST:72,Francesco Acerbi:CB:72,Matteo Darmian:RB:72,Roberto Gagliardini:CM:72",
  "Inter Milan|2024": "Lautaro Mart\xEDnez:ST:91,Alessandro Bastoni:CB:89,Marcus Thuram:ST:89,Nicol\xF2 Barella:CM:89,Federico Dimarco:LB:87,Benjamin Pavard:CB:86,Davide Frattesi:CM:84,Denzel Dumfries:RB:83,Yann Bisseck:CB:83,Carlos Augusto:LB:82,Stefan de Vrij:CB:76,Tajon Buchanan:RW:76,Henrikh Mkhitaryan:CM:74,Yann Sommer:GK:73,Davy Klaassen:CM:72,Marko Arnautovic:ST:72,Matteo Darmian:RB:72,Alexis S\xE1nchez:CF:70,Juan Cuadrado:RM:68",
  "Inter Milan|2025": "Lautaro Mart\xEDnez:ST:90,Alessandro Bastoni:CB:89,Marcus Thuram:ST:89,Nicol\xF2 Barella:CM:89,Federico Dimarco:LB:86,Davide Frattesi:CM:84,Denzel Dumfries:RB:84,Yann Bisseck:CB:84,Benjamin Pavard:CB:83,Carlos Augusto:LB:83,Piotr Zielinski:CM:79,Josep Mart\xEDnez:GK:78,Tajon Buchanan:RW:77,Mehdi Taremi:ST:73,Stefan de Vrij:CB:73,Henrikh Mkhitaryan:CM:72,Yann Sommer:GK:72,Joaqu\xEDn Correa:CF:70,Matteo Darmian:RB:70",
  "Inter Milan|2026": "Lautaro Mart\xEDnez:ST:89,Alessandro Bastoni:CB:88,Federico Dimarco:LB:86,Marcus Thuram:ST:86,Nicol\xF2 Barella:CM:86,Pio Esposito:ST:86,Yann Bisseck:CB:85,Carlos Augusto:LB:83,Petar Su\u010Di\u0107:CM:83,Davide Frattesi:CM:82,Denzel Dumfries:RB:82,Luis Henrique:RM:82,Andy Diouf:CM:80,Manuel Akanji:CB:80,Josep Mart\xEDnez:GK:76,Yann Sommer:GK:70,Matteo Darmian:RB:68",
  "Juventus FC|2016": "Paul Pogba:CM:89,Paulo Dybala:CF:86,\xC1lvaro Morata:ST:85,Leonardo Bonucci:CB:85,Alex Sandro:LB:83,Claudio Marchisio:CM:83,Juan Cuadrado:RM:82,Mario Mand\u017Euki\u0107:ST:81,Sami Khedira:CM:81,Roberto Pereyra:CM:80,Daniele Rugani:CB:79,Giorgio Chiellini:CB:79,Kwadwo Asamoah:LM:79,Simone Zaza:ST:79,Hernanes:CAM:76,Mario Lemina:CDM:76,Mart\xEDn C\xE1ceres:CB:76,Neto:GK:76,Stephan Lichtsteiner:RB:76",
  "Juventus FC|2017": "Gonzalo Higua\xEDn:ST:89,Paulo Dybala:CF:89,Leonardo Bonucci:CB:86,Miralem Pjani\u0107:CM:86,Alex Sandro:LB:85,Claudio Marchisio:CM:83,Juan Cuadrado:RM:83,Sami Khedira:CM:83,Daniele Rugani:CB:81,Mario Mand\u017Euki\u0107:ST:81,Marko Pjaca:LW:80,Medhi Benatia:CB:80,Kwadwo Asamoah:LM:79,Giorgio Chiellini:CB:78,Mario Lemina:CDM:78,Stefano Sturaro:CM:78,Tom\xE1s Rinc\xF3n:CDM:77,Moise Kean:ST:76,Dani Alves:RB:74,Neto:GK:74,Hernanes:CAM:73,Stephan Lichtsteiner:RB:72,Emil Audero:GK:64",
  "Juventus FC|2018": "Paulo Dybala:CF:91,Miralem Pjani\u0107:CM:88,Douglas Costa:RW:87,Gonzalo Higua\xEDn:ST:87,Alex Sandro:LB:86,Federico Bernardeschi:RW:86,Rodrigo Bentancur:CDM:84,Blaise Matuidi:CM:83,Juan Cuadrado:RM:83,Sami Khedira:CM:83,Wojciech Szcz\u0119sny:GK:83,Daniele Rugani:CB:82,Mario Mand\u017Euki\u0107:ST:82,Medhi Benatia:CB:82,Kwadwo Asamoah:LM:79,Mattia De Sciglio:RB:79,Benedikt H\xF6wedes:CB:78,Claudio Marchisio:CM:77,Giorgio Chiellini:CB:77,Gianluigi Buffon:GK:68,Stephan Lichtsteiner:RB:68",
  "Juventus FC|2023": "Du\u0161an Vlahovi\u0107:ST:89,Bremer:CB:86,Federico Chiesa:RW:86,Adrien Rabiot:CM:85,Nicol\xF2 Fagioli:CM:84,Mat\xEDas Soul\xE9:RW:82,Paul Pogba:CM:81,Federico Gatti:CB:80,Moise Kean:ST:80,Fabio Miretti:CM:79,Kenan Y\u0131ld\u0131z:LW:77,Wojciech Szcz\u0119sny:GK:77,Arkadiusz Milik:ST:76,Daniele Rugani:CB:72,Juan Cuadrado:RM:72,Mattia Perin:GK:72,Mattia De Sciglio:RB:70",
  "Juventus FC|2024": "Du\u0161an Vlahovi\u0107:ST:88,Bremer:CB:87,Kenan Y\u0131ld\u0131z:LW:86,Andrea Cambiaso:LB:85,Federico Chiesa:RW:85,Adrien Rabiot:CM:84,Moise Kean:ST:83,Weston McKennie:CM:83,Federico Gatti:CB:82,Nicol\xF2 Fagioli:CM:81,Timothy Weah:RM:80,Carlos Alcaraz:CM:79,Tiago Djal\xF3:CB:78,Samuel Mbangula:LW:76,Arkadiusz Milik:ST:74,Wojciech Szcz\u0119sny:GK:74,Samuel Iling-Junior:LM:71,Mattia Perin:GK:70,Alex Sandro:LB:68",
  "Juventus FC|2025": "Kenan Y\u0131ld\u0131z:LW:89,Bremer:CB:86,Du\u0161an Vlahovi\u0107:ST:86,Douglas Luiz:CM:85,Kh\xE9phren Thuram:CM:85,Andrea Cambiaso:LB:84,Francisco Concei\xE7\xE3o:RW:83,Nico Gonz\xE1lez:LW:83,Pierre Kalulu:CB:83,Randal Kolo Muani:ST:83,Edon Zhegrova:RW:82,Federico Gatti:CB:82,Filip Kosti\u0107:LM:82,Renato Veiga:CB:82,Weston McKennie:CM:82,Timothy Weah:RM:81,Michele Di Gregorio:GK:80,Nicol\xF2 Fagioli:CM:80,Alberto Costa:RB:79,Nicol\xF2 Savona:RB:79,Juan Cabal:LB:77,Vasilije Ad\u017Ei\u0107:CAM:76,Mattia Perin:GK:70",
  "Juventus FC|2026": "Kenan Y\u0131ld\u0131z:LW:89,Kh\xE9phren Thuram:CM:85,Bremer:CB:84,Du\u0161an Vlahovi\u0107:ST:84,Jonathan David:ST:84,Lo\xEFs Openda:ST:84,Pierre Kalulu:CB:84,Andrea Cambiaso:LB:83,Francisco Concei\xE7\xE3o:RW:83,Weston McKennie:CM:83,Lloyd Kelly:CB:81,Fabio Miretti:CM:80,Federico Gatti:CB:80,Edon Zhegrova:RW:79,Michele Di Gregorio:GK:79,Samuel Iling-Junior:LM:79,Juan Cabal:LB:77,J\xE9r\xE9mie Boga:LW:76,Jo\xE3o M\xE1rio:RB:76,Vasilije Ad\u017Ei\u0107:CAM:76,Mattia Perin:GK:68",
  "Liverpool FC|2016": "Philippe Coutinho:CAM:84,Roberto Firmino:ST:84,Christian Benteke:ST:83,Jordan Henderson:CDM:83,Daniel Sturridge:ST:82,Adam Lallana:CAM:81,Nathaniel Clyne:RB:81,Emre Can:CB:80,Mamadou Sakho:CB:80,Alberto Moreno:LB:79,Dejan Lovren:CB:79,James Milner:CM:79,Martin Skrtel:CB:79,Joe Allen:CM:78,Lucas Leiva:CDM:78,Simon Mignolet:GK:78,Jordon Ibe:RW:77,Jon Flanagan:RB:76,\xC1d\xE1m Bogd\xE1n:GK:68,Brad Smith:LB:68",
  "Liverpool FC|2017": "Philippe Coutinho:CAM:88,Sadio Man\xE9:LW:86,Roberto Firmino:ST:85,Georginio Wijnaldum:CM:83,Jordan Henderson:CDM:83,Adam Lallana:CAM:82,Daniel Sturridge:ST:82,Emre Can:CB:82,Jo\xEBl Matip:CB:82,Nathaniel Clyne:RB:81,Dejan Lovren:CB:80,James Milner:CM:79,Divock Origi:ST:78,Simon Mignolet:GK:78,Alberto Moreno:LB:77,Joe Gomez:CB:76,Loris Karius:GK:76,Lucas Leiva:CDM:76,Trent Alexander-Arnold:RB:73",
  "Liverpool FC|2018": "Mohamed Salah:RW:92,Roberto Firmino:ST:89,Sadio Man\xE9:LW:89,Virgil van Dijk:CB:89,Andrew Robertson:LB:86,Trent Alexander-Arnold:RB:86,Alex Oxlade-Chamberlain:CM:85,Georginio Wijnaldum:CM:85,Joe Gomez:CB:84,Emre Can:CB:83,Jordan Henderson:CDM:83,Adam Lallana:CAM:82,Jo\xEBl Matip:CB:82,Nathaniel Clyne:RB:81,James Milner:CM:79,Alberto Moreno:LB:78,Danny Ings:ST:78,Loris Karius:GK:78,Simon Mignolet:GK:78,Dominic Solanke:ST:77,Ben Woodburn:CAM:73",
  "Liverpool FC|2019": "Mohamed Salah:RW:92,Sadio Man\xE9:LW:92,Trent Alexander-Arnold:RB:91,Alisson:GK:90,Roberto Firmino:ST:90,Virgil van Dijk:CB:90,Andrew Robertson:LB:89,Fabinho:CDM:88,Naby Ke\xEFta:CM:87,Georginio Wijnaldum:CM:86,Jo\xEBl Matip:CB:85,Alex Oxlade-Chamberlain:CM:84,Joe Gomez:CB:84,Jordan Henderson:CDM:84,Xherdan Shaqiri:CAM:82,Dejan Lovren:CB:81,Divock Origi:ST:81,Adam Lallana:CAM:79,Daniel Sturridge:ST:79,James Milner:CM:79,Alberto Moreno:LB:77,Simon Mignolet:GK:77,Ki-Jana Hoever:RB:72,Rafael Camacho:RW:72",
  "Liverpool FC|2020": "Mohamed Salah:RW:91,Sadio Man\xE9:LW:91,Trent Alexander-Arnold:RB:91,Alisson:GK:89,Andrew Robertson:LB:89,Virgil van Dijk:CB:89,Roberto Firmino:ST:88,Fabinho:CDM:87,Georginio Wijnaldum:CM:85,Joe Gomez:CB:85,Naby Ke\xEFta:CM:85,Jo\xEBl Matip:CB:84,Alex Oxlade-Chamberlain:CM:83,Jordan Henderson:CDM:83,Xherdan Shaqiri:CAM:81,Curtis Jones:CM:80,Dejan Lovren:CB:80,Divock Origi:ST:80,Adam Lallana:CAM:77,Neco Williams:LB:77,Takumi Minamino:LW:77,Caoimh\xEDn Kelleher:GK:68",
  "Liverpool FC|2021": "Mohamed Salah:RW:91,Sadio Man\xE9:LW:90,Trent Alexander-Arnold:RB:90,Alisson:GK:88,Andrew Robertson:LB:88,Virgil van Dijk:CB:88,Diogo Jota:LW:87,Fabinho:CDM:87,Roberto Firmino:ST:87,Naby Ke\xEFta:CM:85,Georginio Wijnaldum:CM:84,Joe Gomez:CB:84,Thiago Alc\xE1ntara:CM:84,Curtis Jones:CM:83,Jo\xEBl Matip:CB:82,Jordan Henderson:CDM:82,Divock Origi:ST:80,Xherdan Shaqiri:CAM:79,Konstantinos Tsimikas:LB:77,Nat Phillips:CB:76,Caoimh\xEDn Kelleher:GK:70",
  "Liverpool FC|2022": "Mohamed Salah:RW:90,Luis D\xEDaz:LW:89,Trent Alexander-Arnold:RB:89,Andrew Robertson:LB:88,Sadio Man\xE9:LW:88,Fabinho:CDM:87,Virgil van Dijk:CB:87,Alisson:GK:86,Ibrahima Konat\xE9:CB:85,Harvey Elliott:CAM:84,Roberto Firmino:ST:84,Curtis Jones:CM:83,Joe Gomez:CB:83,Naby Ke\xEFta:CM:82,Thiago Alc\xE1ntara:CM:81,Alex Oxlade-Chamberlain:CM:80,Jo\xEBl Matip:CB:80,Konstantinos Tsimikas:LB:80,Jordan Henderson:CDM:79,Divock Origi:ST:78,Caoimh\xEDn Kelleher:GK:76,Kaide Gordon:RW:68",
  "Liverpool FC|2023": "Luis D\xEDaz:LW:89,Darwin N\xFA\xF1ez:ST:88,Mohamed Salah:RW:88,Trent Alexander-Arnold:RB:88,Cody Gakpo:LW:87,Alisson:GK:86,Andrew Robertson:LB:86,Virgil van Dijk:CB:86,Ibrahima Konat\xE9:CB:85,Harvey Elliott:CAM:84,Curtis Jones:CM:83,Joe Gomez:CB:82,Konstantinos Tsimikas:LB:82,Roberto Firmino:ST:82,F\xE1bio Carvalho:CAM:80,Naby Ke\xEFta:CM:80,Arthur Melo:CM:79,Caoimh\xEDn Kelleher:GK:79,Thiago Alc\xE1ntara:CM:79,Jo\xEBl Matip:CB:78,Ben Gannon-Doak:RW:77",
  "Liverpool FC|2024": "Alexis Mac Allister:CM:89,Dominik Szoboszlai:CAM:89,Luis D\xEDaz:LW:89,Trent Alexander-Arnold:RB:89,Darwin N\xFA\xF1ez:ST:88,Cody Gakpo:LW:87,Mohamed Salah:RW:87,Curtis Jones:CM:86,Ibrahima Konat\xE9:CB:86,Harvey Elliott:CAM:84,Alisson:GK:83,Andrew Robertson:LB:83,Joe Gomez:CB:83,Virgil van Dijk:CB:83,Caoimh\xEDn Kelleher:GK:82,Jarell Quansah:CB:82,Konstantinos Tsimikas:LB:82,Conor Bradley:RB:81,Thiago Alc\xE1ntara:CM:77,Bobby Clark:CM:76",
  "Liverpool FC|2025": "Alexis Mac Allister:CM:90,Dominik Szoboszlai:CAM:89,Trent Alexander-Arnold:RB:89,Cody Gakpo:LW:88,Luis D\xEDaz:LW:88,Ibrahima Konat\xE9:CB:87,Curtis Jones:CM:86,Darwin N\xFA\xF1ez:ST:86,Mohamed Salah:RW:86,Jarell Quansah:CB:85,Harvey Elliott:CAM:84,Conor Bradley:RB:83,Caoimh\xEDn Kelleher:GK:82,Joe Gomez:CB:82,Virgil van Dijk:CB:82,Alisson:GK:81,Andrew Robertson:LB:81,Federico Chiesa:RW:80,Konstantinos Tsimikas:LB:80,Trey Nyoni:CM:74",
  "Liverpool FC|2026": "Florian Wirtz:CAM:91,Alexander Isak:ST:90,Dominik Szoboszlai:CAM:90,Hugo Ekitik\xE9:ST:90,Alexis Mac Allister:CM:89,Cody Gakpo:LW:88,Ibrahima Konat\xE9:CB:86,Milos Kerkez:LB:85,Curtis Jones:CM:84,Jeremie Frimpong:RB:84,Conor Bradley:RB:83,Giorgi Mamardashvili:GK:83,Mohamed Salah:RW:83,Giovanni Leoni:CB:82,Rio Ngumoha:LW:81,Alisson:GK:80,Virgil van Dijk:CB:80,Federico Chiesa:RW:79,Joe Gomez:CB:79,Andrew Robertson:LB:77,Trey Nyoni:CM:74",
  "Manchester City|2016": "Kevin De Bruyne:CAM:87,Sergio Ag\xFCero:ST:87,Raheem Sterling:RW:86,David Silva:CAM:85,Nicol\xE1s Otamendi:CB:84,Eliaquim Mangala:CB:83,Fernandinho:CDM:83,Vincent Kompany:CB:83,Wilfried Bony:ST:82,Jes\xFAs Navas:RM:81,Yaya Tour\xE9:CM:81,Fernando:CDM:80,Joe Hart:GK:80,Pablo Zabaleta:RB:79,Aleksandar Kolarov:LB:78,Fabian Delph:CM:77,Ga\xEBl Clichy:LB:77,Kelechi Iheanacho:ST:77,Bacary Sagna:RB:76,Willy Caballero:GK:70",
  "Manchester City|2017": "Kevin De Bruyne:CAM:89,Sergio Ag\xFCero:ST:88,Gabriel Jesus:ST:86,Leroy San\xE9:RW:86,Raheem Sterling:RW:86,John Stones:CB:84,David Silva:CAM:83,\u0130lkay G\xFCndo\u011Fan:CM:83,Nicol\xE1s Otamendi:CB:83,Fernandinho:CDM:82,Vincent Kompany:CB:82,Jes\xFAs Navas:RM:79,Kelechi Iheanacho:ST:79,Aleksandar Kolarov:LB:78,Claudio Bravo:GK:78,Yaya Tour\xE9:CM:77,Fabian Delph:CM:76,Ga\xEBl Clichy:LB:76,Pablo Zabaleta:RB:76,Willy Caballero:GK:68",
  "Manchester City|2018": "Kevin De Bruyne:CAM:92,Raheem Sterling:RW:91,Leroy San\xE9:RW:90,Gabriel Jesus:ST:89,Sergio Ag\xFCero:ST:89,Bernardo Silva:CAM:88,Aymeric Laporte:CB:87,Ederson:GK:87,John Stones:CB:87,Benjamin Mendy:LB:86,Kyle Walker:RB:86,\u0130lkay G\xFCndo\u011Fan:CM:85,Nicol\xE1s Otamendi:CB:84,Danilo:CB:81,Fabian Delph:CM:79,Fernandinho:CDM:79,Oleksandr Zinchenko:LB:79,Claudio Bravo:GK:73,Yaya Tour\xE9:CM:73",
  "Manchester City|2019": "Raheem Sterling:RW:93,Kevin De Bruyne:CAM:92,Bernardo Silva:CAM:90,Leroy San\xE9:RW:90,Aymeric Laporte:CB:89,Ederson:GK:88,Gabriel Jesus:ST:88,Sergio Ag\xFCero:ST:88,John Stones:CB:87,\u0130lkay G\xFCndo\u011Fan:CM:86,Kyle Walker:RB:86,Benjamin Mendy:LB:85,Nicol\xE1s Otamendi:CB:83,Oleksandr Zinchenko:LB:83,Danilo:CB:81,Fabian Delph:CM:79,Fernandinho:CDM:78,Arijanet Muri\u0107:GK:68",
  "Manchester City|2020": "Kevin De Bruyne:CAM:91,Raheem Sterling:RW:91,Bernardo Silva:CAM:89,Leroy San\xE9:RW:89,Rodri:CDM:88,Aymeric Laporte:CB:87,Ederson:GK:87,Gabriel Jesus:ST:87,Jo\xE3o Cancelo:RB:86,John Stones:CB:86,Sergio Ag\xFCero:ST:86,\u0130lkay G\xFCndo\u011Fan:CM:85,Kyle Walker:RB:85,Benjamin Mendy:LB:83,Oleksandr Zinchenko:LB:82,Eric Garc\xEDa:CB:81,Fernandinho:CDM:76,Zack Steffen:GK:76,Adri\xE1n Bernab\xE9:CM:68",
  "Manchester City|2021": "Kevin De Bruyne:CAM:90,Raheem Sterling:RW:90,Bernardo Silva:CAM:89,R\xFAben Dias:CB:89,Rodri:CDM:88,Ederson:GK:87,Gabriel Jesus:ST:87,Jo\xE3o Cancelo:RB:87,Aymeric Laporte:CB:86,Ferran Torres:ST:86,\u0130lkay G\xFCndo\u011Fan:CM:85,Riyad Mahrez:RW:85,Kyle Walker:RB:84,Nathan Ak\xE9:CB:84,John Stones:CB:83,Oleksandr Zinchenko:LB:83,Benjamin Mendy:LB:82,Sergio Ag\xFCero:ST:82,Zack Steffen:GK:74,Fernandinho:CDM:70",
  "Manchester City|2022": "Phil Foden:CAM:91,Bernardo Silva:CAM:89,Gabriel Jesus:ST:89,Rodri:CDM:89,R\xFAben Dias:CB:89,Jack Grealish:LW:88,Jo\xE3o Cancelo:RB:88,Raheem Sterling:RW:88,Aymeric Laporte:CB:86,Ederson:GK:86,Oleksandr Zinchenko:LB:84,Riyad Mahrez:RW:84,John Stones:CB:83,Nathan Ak\xE9:CB:83,\u0130lkay G\xFCndo\u011Fan:CM:82,Kyle Walker:RB:80,Juan Larios:LB:76,Liam Delap:ST:76,Zack Steffen:GK:74",
  "Manchester City|2023": "Erling Haaland:ST:93,Phil Foden:CAM:91,Juli\xE1n Alvarez:ST:90,Bernardo Silva:CAM:89,Jack Grealish:LW:89,R\xFAben Dias:CB:89,Jo\xE3o Cancelo:RB:87,Ederson:GK:85,John Stones:CB:85,Manuel Akanji:CB:85,Nathan Ak\xE9:CB:85,Rico Lewis:RB:85,\u0130lkay G\xFCndo\u011Fan:CM:81,Riyad Mahrez:RW:81,Oscar Bobb:RW:79,Sergio G\xF3mez:LB:79,Stefan Ortega:GK:77",
  "Manchester City|2024": "Erling Haaland:ST:94,Phil Foden:CAM:92,Juli\xE1n Alvarez:ST:90,Josko Gvardiol:CB:89,R\xFAben Dias:CB:89,Bernardo Silva:CAM:88,Jack Grealish:LW:88,J\xE9r\xE9my Doku:LW:88,Manuel Akanji:CB:86,Matheus Nunes:RB:86,John Stones:CB:85,Rico Lewis:RB:85,Ederson:GK:84,Mateo Kovacic:CM:83,Oscar Bobb:RW:82,Sergio G\xF3mez:LB:81,Stefan Ortega:GK:77",
  "Manchester City|2025": "Erling Haaland:ST:94,Phil Foden:CAM:92,Josko Gvardiol:CB:89,Omar Marmoush:ST:89,J\xE9r\xE9my Doku:LW:88,R\xFAben Dias:CB:88,Bernardo Silva:CAM:86,Savinho:LW:86,Matheus Nunes:RB:85,Nico O'Reilly:LB:85,Rico Lewis:RB:85,Abdukodir Khusanov:CB:84,Manuel Akanji:CB:84,Oscar Bobb:RW:83,Ederson:GK:82,Mateo Kovacic:CM:82,\u0130lkay G\xFCndo\u011Fan:CM:76,Stefan Ortega:GK:76,Christian McFarlane:LB:68",
  "Manchester City|2026": "Erling Haaland:ST:94,Phil Foden:CAM:89,J\xE9r\xE9my Doku:LW:88,Josko Gvardiol:CB:88,Rayan Cherki:CAM:88,Omar Marmoush:ST:87,R\xFAben Dias:CB:87,Tijjani Reijnders:CM:87,Gianluigi Donnarumma:GK:86,Matheus Nunes:RB:86,Nico O'Reilly:LB:86,Rayan A\xEFt-Nouri:LB:85,Savinho:LW:85,Abdukodir Khusanov:CB:84,Rico Lewis:RB:84,James Trafford:GK:82,John Stones:CB:79,Mateo Kovacic:CM:78",
  "Manchester United|2016": "David de Gea:GK:85,Wayne Rooney:ST:85,Anthony Martial:ST:84,Juan Mata:CAM:84,Ander Herrera:CM:83,Morgan Schneiderlin:CDM:83,Daley Blind:CB:82,Memphis Depay:CF:82,Chris Smalling:CB:81,Luke Shaw:LB:81,Marcos Rojo:CB:81,Marouane Fellaini:CM:81,Bastian Schweinsteiger:CM:79,Matteo Darmian:RB:79,Phil Jones:CB:79,Ashley Young:RB:77,Jesse Lingard:CAM:77,Marcus Rashford:LW:77,Adnan Januzaj:RW:76,Michael Carrick:CDM:72,Andreas Pereira:CM:70",
  "Manchester United|2017": "Paul Pogba:CM:89,David de Gea:GK:85,Henrikh Mkhitaryan:CM:85,Anthony Martial:ST:84,Juan Mata:CAM:84,Ander Herrera:CM:83,Eric Bailly:CB:83,Marcus Rashford:LW:83,Daley Blind:CB:82,Chris Smalling:CB:81,Luke Shaw:LB:81,Marcos Rojo:CB:81,Wayne Rooney:ST:81,Jesse Lingard:CAM:78,Marouane Fellaini:CM:78,Matteo Darmian:RB:78,Zlatan Ibrahimovi\u0107:ST:78,Antonio Valencia:RB:77,Sergio Romero:GK:74",
  "Manchester United|2018": "Paul Pogba:CM:90,Romelu Lukaku:ST:90,Anthony Martial:ST:88,David de Gea:GK:88,Marcus Rashford:LW:88,Jesse Lingard:CAM:85,Nemanja Mati\u0107:CDM:85,Eric Bailly:CB:84,Ander Herrera:CM:83,Juan Mata:CAM:83,Victor Lindel\xF6f:CB:82,Daley Blind:CB:81,Phil Jones:CB:81,Luke Shaw:LB:80,Marouane Fellaini:CM:79,Matteo Darmian:RB:78,Antonio Valencia:RB:77,Scott McTominay:CM:76,Sergio Romero:GK:74,Cameron Borthwick-Jackson:LB:70",
  "Manchester United|2019": "Paul Pogba:CM:90,Marcus Rashford:LW:89,Romelu Lukaku:ST:89,David de Gea:GK:88,Anthony Martial:ST:87,Jesse Lingard:CAM:85,Alexis S\xE1nchez:CF:84,Fred:CM:84,Victor Lindel\xF6f:CB:84,Luke Shaw:LB:83,Nemanja Mati\u0107:CDM:83,Scott McTominay:CM:83,Ander Herrera:CM:82,Eric Bailly:CB:82,Chris Smalling:CB:81,Diogo Dalot:RB:81,Juan Mata:CAM:81,Mason Greenwood:RW:81,Phil Jones:CB:81,Brandon Williams:LB:76,Sergio Romero:GK:72,James Garner:CDM:70,Ethan Laird:RB:68",
  "Manchester United|2020": "Marcus Rashford:LW:89,Paul Pogba:CM:89,Anthony Martial:ST:87,Harry Maguire:CB:87,David de Gea:GK:86,Mason Greenwood:RW:86,Aaron Wan-Bissaka:RB:85,Victor Lindel\xF6f:CB:83,Daniel James:RW:82,Jesse Lingard:CAM:82,Luke Shaw:LB:82,Scott McTominay:CM:82,Fred:CM:81,Andreas Pereira:CM:80,Diogo Dalot:RB:80,Eric Bailly:CB:80,Nemanja Mati\u0107:CDM:80,Brandon Williams:LB:78,Juan Mata:CAM:78,Odion Ighalo:ST:74,Sergio Romero:GK:70",
  "Manchester United|2021": "Bruno Fernandes:CAM:90,Marcus Rashford:LW:89,Paul Pogba:CM:87,Anthony Martial:ST:86,Harry Maguire:CB:86,Mason Greenwood:RW:86,Aaron Wan-Bissaka:RB:85,Luke Shaw:LB:85,Donny van de Beek:CM:84,Scott McTominay:CM:84,Alex Telles:LB:83,David de Gea:GK:82,Dean Henderson:GK:82,Fred:CM:82,Victor Lindel\xF6f:CB:82,Amad Diallo:RW:80,Eric Bailly:CB:79,Nemanja Mati\u0107:CDM:77,Axel Tuanzebe:CB:76,Edinson Cavani:ST:76,Juan Mata:CAM:74,Shola Shoretire:LW:70,Connor Stanley:RM:64",
  "Manchester United|2022": "Bruno Fernandes:CAM:89,Jadon Sancho:LW:89,Marcus Rashford:LW:88,Rapha\xEBl Varane:CB:87,Paul Pogba:CM:86,Harry Maguire:CB:85,Luke Shaw:LB:85,Diogo Dalot:RB:84,Scott McTominay:CM:84,Aaron Wan-Bissaka:RB:83,Anthony Martial:ST:83,Cristiano Ronaldo:ST:83,Anthony Elanga:RW:82,Dean Henderson:GK:82,Victor Lindel\xF6f:CB:82,Fred:CM:81,Alex Telles:LB:80,Jesse Lingard:CAM:80,David de Gea:GK:79,Nemanja Mati\u0107:CDM:73",
  "Manchester United|2023": "Bruno Fernandes:CAM:89,Marcus Rashford:LW:89,Antony:RW:88,Jadon Sancho:LW:87,Lisandro Mart\xEDnez:CB:86,Diogo Dalot:RB:85,Luke Shaw:LB:85,Rapha\xEBl Varane:CB:84,Scott McTominay:CM:83,Christian Eriksen:CAM:82,Harry Maguire:CB:82,Tyrell Malacia:LB:82,Fred:CM:81,Marcel Sabitzer:CM:81,Anthony Elanga:RW:80,Donny van de Beek:CM:80,Victor Lindel\xF6f:CB:80,Anthony Martial:ST:79,David de Gea:GK:79,Wout Weghorst:ST:78",
  "Manchester United|2024": "Bruno Fernandes:CAM:88,Rasmus H\xF8jlund:ST:88,Kobbie Mainoo:CM:87,Marcus Rashford:LW:87,Alejandro Garnacho:LW:86,Lisandro Mart\xEDnez:CB:86,Diogo Dalot:RB:85,Mason Mount:CAM:85,Scott McTominay:CM:85,Andr\xE9 Onana:GK:84,Luke Shaw:LB:84,Antony:RW:83,Aaron Wan-Bissaka:RB:82,Amad Diallo:RW:82,Rapha\xEBl Varane:CB:81,Harry Maguire:CB:80,Tyrell Malacia:LB:80,Victor Lindel\xF6f:CB:79,Altay Bay\u0131nd\u0131r:GK:77",
  "Manchester United|2025": "Leny Yoro:CB:87,Alejandro Garnacho:LW:86,Amad Diallo:RW:86,Bruno Fernandes:CAM:86,Kobbie Mainoo:CM:86,Lisandro Mart\xEDnez:CB:86,Rasmus H\xF8jlund:ST:86,Matthijs de Ligt:CB:85,Andr\xE9 Onana:GK:84,Antony:RW:84,Diogo Dalot:RB:84,Joshua Zirkzee:ST:84,Mason Mount:CAM:84,Patrick Dorgu:LB:83,Noussair Mazraoui:RB:82,Luke Shaw:LB:80,Harry Maguire:CB:79,Altay Bay\u0131nd\u0131r:GK:76,Chido Obi:ST:73",
  "Manchester United|2026": "Bryan Mbeumo:RW:89,Benjamin Sesko:ST:88,Matheus Cunha:ST:88,Amad Diallo:RW:86,Kobbie Mainoo:CM:86,Leny Yoro:CB:86,Bruno Fernandes:CAM:85,Lisandro Mart\xEDnez:CB:85,Matthijs de Ligt:CB:85,Patrick Dorgu:LB:84,Diogo Dalot:RB:83,Mason Mount:CAM:83,Senne Lammens:GK:83,Joshua Zirkzee:ST:82,Ayden Heaven:CB:81,Noussair Mazraoui:RB:81,Luke Shaw:LB:77,Altay Bay\u0131nd\u0131r:GK:76",
  "Newcastle United|2016": "Georginio Wijnaldum:CM:82,Moussa Sissoko:CM:81,Aleksandar Mitrovi\u0107:ST:79,Andros Townsend:RW:78,Florian Thauvin:RW:78,Jonjo Shelvey:CM:78,Seydou Doumbia:ST:78,Chancel Mbemba:CB:77,Ayoze P\xE9rez:ST:76,Daryl Janmaat:RB:76,Jack Colback:CDM:76,Siem de Jong:CAM:76,Cheik Tiot\xE9:CDM:74,Henri Saivet:CM:73,Jamaal Lascelles:CB:72,Paul Dummett:LB:72,Yoan Gouffran:LW:72,Karl Darlow:GK:70,Rob Elliot:GK:68,Sylvain Marveaux:CAM:68,Rolando Aarons:LW:64",
  "Newcastle United|2017": "Jonjo Shelvey:CM:78,Aleksandar Mitrovi\u0107:ST:77,Dwight Gayle:ST:77,Matt Ritchie:RM:77,Ayoze P\xE9rez:ST:76,Chancel Mbemba:CB:76,Jack Colback:CDM:74,Mohamed Diam\xE9:CM:74,Christian Atsu:LW:73,Ciaran Clark:CB:73,DeAndre Yedlin:RB:73,Grant Hanley:CB:73,Isaac Hayden:CDM:73,Jamaal Lascelles:CB:73,Karl Darlow:GK:73,Paul Dummett:LB:72,Yoan Gouffran:LW:72,Achraf Lazaar:LM:70,Jes\xFAs G\xE1mez:RB:70,Massadio Ha\xEFdara:LB:68,Rob Elliot:GK:68",
  "Newcastle United|2018": "Jamaal Lascelles:CB:79,Jonjo Shelvey:CM:79,Matt Ritchie:RM:78,Mikel Merino:CM:78,Ayoze P\xE9rez:ST:77,Dwight Gayle:ST:77,Kenedy:LW:77,Chancel Mbemba:CB:76,DeAndre Yedlin:RB:76,Florian Lejeune:CB:76,Isaac Hayden:CDM:76,Jacob Murphy:RW:76,Christian Atsu:LW:74,Ciaran Clark:CB:74,Javier Manquillo:RB:73,Karl Darlow:GK:73,Martin D\xFAbravka:GK:73,Mohamed Diam\xE9:CM:73,Joselu:ST:72",
  "Newcastle United|2019": "Ayoze P\xE9rez:ST:83,Sean Longstaff:CM:82,Miguel Almir\xF3n:RW:81,Fabian Sch\xE4r:CB:80,Jamaal Lascelles:CB:80,Jonjo Shelvey:CM:80,Salom\xF3n Rond\xF3n:ST:79,Kenedy:LW:78,Matt Ritchie:RM:78,Isaac Hayden:CDM:77,Yoshinori Muto:ST:77,Antonio Barreca:LB:76,DeAndre Yedlin:RB:76,Federico Fern\xE1ndez:CB:76,Florian Lejeune:CB:76,Martin D\xFAbravka:GK:76,Paul Dummett:LB:76,Christian Atsu:LW:74,Jacob Murphy:RW:74,Sung-yueng Ki:CDM:74,Javier Manquillo:RB:73,Karl Darlow:GK:72",
  "Newcastle United|2020": "Allan Saint-Maximin:LW:84,Joelinton:CM:82,Danny Rose:LB:80,Miguel Almir\xF3n:RW:80,Sean Longstaff:CM:80,Jonjo Shelvey:CM:79,Valentino Lazaro:RM:79,Dwight Gayle:ST:77,Isaac Hayden:CDM:77,Martin D\xFAbravka:GK:76,DeAndre Yedlin:RB:75,Federico Fern\xE1ndez:CB:74,Jetro Willems:CB:74,Paul Dummett:LB:74,Yoshinori Muto:ST:74,Christian Atsu:LW:73,Ciaran Clark:CB:73,Florian Lejeune:CB:73,Matty Longstaff:CM:73,Emil Krafth:RB:72,Nabil Bentaleb:CDM:72,Andy Carroll:ST:70,Karl Darlow:GK:70",
  "Newcastle United|2021": "Allan Saint-Maximin:LW:84,Callum Wilson:ST:82,Jamal Lewis:LB:80,Joelinton:CM:80,Miguel Almir\xF3n:RW:80,Jamaal Lascelles:CB:79,Jonjo Shelvey:CM:79,Sean Longstaff:CM:79,Fabian Sch\xE4r:CB:78,Ryan Fraser:LW:78,Isaac Hayden:CDM:77,Jeff Hendrick:CM:77,Martin D\xFAbravka:GK:74,Dwight Gayle:ST:73,Jacob Murphy:RW:73,Ciaran Clark:CB:72,Emil Krafth:RB:72,Matt Ritchie:RM:72,Paul Dummett:LB:72,Javier Manquillo:RB:70,Karl Darlow:GK:70",
  "Newcastle United|2022": "Allan Saint-Maximin:LW:85,Joelinton:CM:84,Joe Willock:CM:83,Sean Longstaff:CM:82,Miguel Almir\xF3n:RW:81,Callum Wilson:ST:80,Matt Targett:LB:80,Kieran Trippier:RB:79,Dan Burn:CB:78,Chris Wood:ST:77,Fabian Sch\xE4r:CB:77,Jamal Lewis:LB:77,Jonjo Shelvey:CM:77,Martin D\xFAbravka:GK:72,Javier Manquillo:RB:70,Karl Darlow:GK:70,Matt Ritchie:RM:68",
  "Newcastle United|2023": "Bruno Guimar\xE3es:CM:89,Alexander Isak:ST:88,Anthony Gordon:LW:86,Sven Botman:CB:86,Joe Willock:CM:85,Joelinton:CM:85,Allan Saint-Maximin:LW:84,Miguel Almir\xF3n:RW:84,Sean Longstaff:CM:82,Nick Pope:GK:81,Callum Wilson:ST:80,Jacob Murphy:RW:79,Matt Targett:LB:79,Kieran Trippier:RB:78,Dan Burn:CB:77,Fabian Sch\xE4r:CB:77,Chris Wood:ST:76,Jamaal Lascelles:CB:76,Jamal Lewis:LB:74,Javier Manquillo:RB:70,Martin D\xFAbravka:GK:70,Matt Ritchie:RM:64",
  "Newcastle United|2024": "Alexander Isak:ST:89,Bruno Guimar\xE3es:CM:89,Anthony Gordon:LW:87,Sven Botman:CB:86,Joelinton:CM:85,Harvey Barnes:LW:84,Tino Livramento:RB:84,Joe Willock:CM:83,Elliot Anderson:CM:82,Lewis Hall:LB:82,Miguel Almir\xF3n:RW:81,Nick Pope:GK:80,Callum Wilson:ST:79,Jacob Murphy:RW:79,Fabian Sch\xE4r:CB:77,Kieran Trippier:RB:77,Matt Targett:LB:77,Dan Burn:CB:76,Jamaal Lascelles:CB:76,Matt Ritchie:RM:64",
  "Newcastle United|2025": "Alexander Isak:ST:92,Bruno Guimar\xE3es:CM:89,Anthony Gordon:LW:88,Sven Botman:CB:85,Tino Livramento:RB:85,Harvey Barnes:LW:84,Joelinton:CM:84,Lewis Hall:LB:84,Joe Willock:CM:82,Lewis Miley:CM:82,Lloyd Kelly:CB:81,Jacob Murphy:RW:80,William Osula:ST:79,Miguel Almir\xF3n:RW:78,Nick Pope:GK:77,Callum Wilson:ST:76,Fabian Sch\xE4r:CB:76,Kieran Trippier:RB:73,Matt Targett:LB:73",
  "Newcastle United|2026": "Bruno Guimar\xE3es:CM:89,Nick Woltemade:ST:88,Anthony Gordon:LW:87,Malick Thiaw:CB:86,Anthony Elanga:RW:85,Tino Livramento:RB:85,Harvey Barnes:LW:84,Jacob Ramsey:CM:84,Lewis Hall:LB:84,Sven Botman:CB:84,Joelinton:CM:83,Yoane Wissa:ST:83,Lewis Miley:CM:82,Jacob Murphy:RW:79,William Osula:ST:79,Aaron Ramsdale:GK:78,Nick Pope:GK:76,Fabian Sch\xE4r:CB:74,Dan Burn:CB:73,Kieran Trippier:RB:70,Alex Murphy:LB:68",
  "Olympiacos Piraeus|2016": "Konstantinos Fortounis:CAM:77,Arthur Masuaku:LB:76,Luka Milivojevic:CDM:76,Roberto:GK:76,Brown Ideye:ST:74,Jimmy Durmaz:CM:72,Seb\xE1:LW:72,Alan Pulido:ST:70,Alberto Bot\xEDa:CB:70,Andr\xE9 Martins:CM:70,Dimitrios Siovas:CB:70,Giannis Maniatis:CDM:70,Hern\xE2ni:LW:70,Manuel da Costa:CB:70,Stefanos Kapino:GK:70,Alejandro Dom\xEDnguez:CAM:64",
  "Olympiacos Piraeus|2019": "Mady Camara:CM:76,Daniel Podence:LW:74,Leonardo Koutris:LB:74,Omar Elabdellaoui:RB:74,Pape Abou Ciss\xE9:CB:74,Konstantinos Tsimikas:LB:73,Guilherme:CDM:72,Jos\xE9 S\xE1:GK:72,Yassine Meriah:CB:72,Ahmed Hassan:ST:70,Bibars Natcho:CAM:70,Andreas Bouchalakis:CM:68,El Arbi Hillel Soudani:RW:68,Georgios Masouras:LW:68,Yuriy Lodygin:GK:68,Giannis Fetfatzidis:RW:64",
  "Olympiacos Piraeus|2020": "Mady Camara:CM:78,Konstantinos Tsimikas:LB:77,Konstantinos Fortounis:CAM:76,Jos\xE9 S\xE1:GK:74,Omar Elabdellaoui:RB:74,Guilherme:CDM:73,Pape Abou Ciss\xE9:CB:73,Ousseynou Ba:CB:72,Andreas Bouchalakis:CM:70,Georgios Masouras:LW:70,Lazar Randjelovic:RW:70,Maximiliano Lovera:LW:70,Youssef El Arabi:ST:70,Bruno Gaspar:RB:68,El Arbi Hillel Soudani:RW:64",
  "Olympiacos Piraeus|2022": "Mady Camara:CM:79,Georgios Masouras:LW:77,Pape Abou Ciss\xE9:CB:76,Henry Onyekuru:LW:74,Aguibou Camara:CAM:73,Andreas Bouchalakis:CM:73,Konstantinos Manolas:CB:73,Rony Lopes:RW:73,Michal Karbownik:LB:72,Oleg Reabciuk:LB:72,Tom\xE1\u0161 Vacl\xEDk:GK:72,Yann M'Vila:CDM:72,Garry Rodrigues:RW:70,Jo\xE3o Carvalho:CAM:70,Kenny Lala:RB:70",
  "Olympiacos Piraeus|2023": "Georgios Masouras:LW:74,Pep Biel:CAM:74,C\xE9dric Bakambu:ST:73,Oleg Reabciuk:LB:73,Omar Richards:LB:73,Ui-jo Hwang:CAM:73,Ousseynou Ba:CB:72,Pape Abou Ciss\xE9:CB:72,Konstantinos Fortounis:CAM:70,Garry Rodrigues:RW:68,Konstantinos Tzolakis:GK:68,Rodinei:RB:68",
  "Olympiacos Piraeus|2024": "Daniel Podence:LW:79,Fran Navarro:ST:76,Mady Camara:CM:76,Francisco Ortega:LB:74,Konstantinos Tzolakis:GK:74,Panagiotis Retsos:CB:73,Giulian Biancone:CB:72,Christos Mouzakitis:CM:70,Gelson Martins:RW:70,Jovane Cabral:LW:70,Omar Richards:LB:70,Sotiris Alexandropoulos:CM:70,Rodinei:RB:68,Athanasios Koutsogoulas:RM:64,Stevan Joveti\u0107:CF:64",
  "Olympiacos Piraeus|2025": "Charalampos Kostoulas:ST:82,Christos Mouzakitis:CM:82,Konstantinos Tzolakis:GK:79,David Carmo:CB:77,Lorenzo Pirola:CB:77,Francisco Ortega:LB:76,Yusuf Yaz\u0131c\u0131:CAM:76,Panagiotis Retsos:CB:74,Ayoub El Kaabi:ST:73,Chiquinho:CAM:73,Marko Stameni\u0107:CM:72,Gelson Martins:RW:70",
  "Olympiacos Piraeus|2026": "Christos Mouzakitis:CM:82,Konstantinos Tzolakis:GK:79,Lorenzo Pirola:CB:77,Francisco Ortega:LB:76,Costinha:RB:74,Panagiotis Retsos:CB:74,Ayoub El Kaabi:ST:73,Chiquinho:CAM:73,Daniel Podence:LW:73,Diogo Nascimento:CM:72,Yusuf Yaz\u0131c\u0131:CAM:72,Bruno Onyemaechi:LB:70,Gelson Martins:RW:70,Athanasios Koutsogoulas:RM:64",
  "Olympique Lyon|2017": "Alexandre Lacazette:ST:86,Corentin Tolisso:CM:85,Memphis Depay:CF:81,Nabil Fekir:CAM:81,Anthony Lopes:GK:79,Maxime Gonalons:CDM:79,Emanuel Mammana:CB:77,Lucas Tousart:CM:77,Maxwel Cornet:LW:77,Jordan Ferri:CM:76,Nicolas N'Koulou:CB:76,Rachid Ghezzal:RW:76,Mapou Yanga-Mbiwa:CB:75,Mouctar Diakhaby:CB:74,Maciej Rybus:LB:72,Jean-Philippe Mateta:ST:70,Christophe Jallet:RB:68,J\xE9r\xE9my Morel:LB:64",
  "Olympique Lyon|2018": "Nabil Fekir:CAM:88,Memphis Depay:CF:86,Tanguy Ndomb\xE9l\xE9:CM:86,Houssem Aouar:CAM:85,Lucas Tousart:CM:82,Mariano D\xEDaz:ST:82,Anthony Lopes:GK:81,Bertrand Traor\xE9:RW:80,Maxwel Cornet:LW:80,Mouctar Diakhaby:CB:79,Ferland Mendy:LB:78,Kenny Tete:RB:77,Myziane Maolida:LW:77,Rafael:RB:77,Mar\xE7al:LB:76,Pape Cheikh:CM:76,Mapou Yanga-Mbiwa:CB:73,Amine Gouiri:ST:72,Jordan Ferri:CM:72,Mathieu Gorgelin:GK:64",
  "Olympique Lyon|2019": "Tanguy Ndomb\xE9l\xE9:CM:88,Memphis Depay:CF:87,Nabil Fekir:CAM:87,Houssem Aouar:CAM:86,Ferland Mendy:LB:85,Moussa Demb\xE9l\xE9:ST:85,Anthony Lopes:GK:82,Lucas Tousart:CM:81,Bertrand Traor\xE9:RW:79,Jason Denayer:CB:79,L\xE9o Dubois:RB:79,Martin Terrier:LW:79,Maxwel Cornet:LW:79,Rafael:RB:77,Pape Cheikh:CM:76,Maxence Caqueret:CM:74,Amine Gouiri:ST:73,Mar\xE7al:LB:73,Mathieu Gorgelin:GK:64",
  "Olympique Lyon|2020": "Houssem Aouar:CAM:87,Memphis Depay:CF:86,Moussa Demb\xE9l\xE9:ST:86,Bruno Guimar\xE3es:CM:84,Jeff Reine-Ad\xE9la\xEFde:CAM:82,Anthony Lopes:GK:81,Joachim Andersen:CB:81,Lucas Tousart:CM:81,Thiago Mendes:CDM:81,Jason Denayer:CB:80,Amine Gouiri:ST:79,Bertrand Traor\xE9:RW:79,Karl Toko Ekambi:ST:79,L\xE9o Dubois:RB:79,Martin Terrier:LW:78,Maxence Caqueret:CM:78,Maxwel Cornet:LW:77,Kenny Tete:RB:74,Jean Lucas:CM:73,Melvin Bard:LB:72,Mar\xE7al:LB:70,Ciprian T\u0103t\u0103ru\u0219anu:GK:64",
  "Olympique Lyon|2021": "Memphis Depay:CF:86,Houssem Aouar:CAM:85,Lucas Paquet\xE1:CAM:84,Bruno Guimar\xE3es:CM:83,Jason Denayer:CB:82,Anthony Lopes:GK:80,L\xE9o Dubois:RB:80,Maxence Caqueret:CM:80,Thiago Mendes:CDM:80,Karl Toko Ekambi:ST:79,Maxwel Cornet:LW:79,Tino Kadewere:ST:79,Melvin Bard:LB:77,Jean Lucas:CM:76,Malo Gusto:RB:76,Sinaly Diomand\xE9:CB:76,Islam Slimani:ST:72",
  "Olympique Lyon|2022": "Bruno Guimar\xE3es:CM:87,Lucas Paquet\xE1:CAM:86,Tanguy Ndomb\xE9l\xE9:CM:84,Houssem Aouar:CAM:83,Tet\xEA:RW:83,Maxence Caqueret:CM:82,Castello Lukeba:CB:81,Moussa Demb\xE9l\xE9:ST:81,Jason Denayer:CB:80,Emerson:LB:79,Karl Toko Ekambi:ST:79,Malo Gusto:RB:79,Anthony Lopes:GK:77,L\xE9o Dubois:RB:77,Thiago Mendes:CDM:77,Tino Kadewere:ST:74,Sinaly Diomand\xE9:CB:73,Bradley Barcola:LW:68",
  "Olympique Lyon|2023": "Castello Lukeba:CB:85,Bradley Barcola:LW:84,Rayan Cherki:CAM:83,Malo Gusto:RB:82,Maxence Caqueret:CM:82,Alexandre Lacazette:ST:79,Corentin Tolisso:CM:79,Houssem Aouar:CAM:79,Moussa Demb\xE9l\xE9:ST:79,Sa\xEBl Kumbedi:RB:78,Amin Sarr:ST:77,Nicol\xE1s Tagliafico:LB:77,Sinaly Diomand\xE9:CB:77,Anthony Lopes:GK:76",
  "Olympique Lyon|2024": "Rayan Cherki:CAM:83,Malick Fofana:LW:82,Maxence Caqueret:CM:81,Sa\xEFd Benrahma:LW:81,Ernest Nuamah:RW:80,Gift Orban:ST:79,Jake O'Brien:RB:79,Ainsley Maitland-Niles:RB:77,Alexandre Lacazette:ST:77,Corentin Tolisso:CM:76,Duje Caleta-Car:CB:76,Lucas Perri:GK:76,Nicol\xE1s Tagliafico:LB:76,Anthony Lopes:GK:72,Mama Bald\xE9:ST:72,Mahamadou Diawara:CM:70",
  "Olympique Lyon|2025": "Rayan Cherki:CAM:86,Georges Mikautadze:ST:83,Malick Fofana:LW:83,Thiago Almada:LW:82,Lucas Perri:GK:80,Ernest Nuamah:RW:79,Moussa Niakhat\xE9:CB:79,Ainsley Maitland-Niles:RB:78,Corentin Tolisso:CM:78,Sa\xEBl Kumbedi:RB:77,Abner:LB:76,Duje Caleta-Car:CB:76,Khalis Merah:CM:76,Nicol\xE1s Tagliafico:LB:74,Jordan Veretout:CM:73,R\xE9my Descamps:GK:68",
  "Olympique Lyon|2026": "Endrick:ST:84,Malick Fofana:LW:83,Pavel Sulc:CAM:81,Moussa Niakhat\xE9:CB:80,Noah Nartey:CAM:79,Corentin Tolisso:CM:78,Ernest Nuamah:RW:78,Abner:LB:77,Afonso Moreira:LW:77,Ainsley Maitland-Niles:RB:77,Khalis Merah:CM:77,Dominik Greif:GK:76,Mart\xEDn Satriano:ST:74,Ruben Kluivert:CB:74,Hans Hateboer:RB:68,R\xE9my Descamps:GK:68",
  "Olympique Marseille|2016": "Michy Batshuayi:ST:82,Benjamin Mendy:LB:77,Nicolas N'Koulou:CB:77,Steve Mandanda:GK:77,Georges-Kevin N'Koudou:LW:76,Lassana Diarra:CDM:76,R\xE9my Cabella:CAM:76,Lucas Ocampos:LW:75,Lucas Silva:CDM:75,Mauricio Isla:RB:74,Javier Manquillo:RB:73,Romain Alessandrini:RW:73,Steven Fletcher:ST:73,Abdelaziz Barrada:CAM:72,Karim Rekik:CB:72,Paolo De Ceglie:LB:64",
  "Olympique Marseille|2017": "Florian Thauvin:RW:80,Steve Mandanda:GK:77,Baf\xE9timbi Gomis:ST:76,Clinton N'Jie:RW:76,Karim Rekik:CB:76,R\xE9my Cabella:CAM:76,William Vainqueur:CDM:74,Lassana Diarra:CDM:73,Hiroki Sakai:RB:70,Matheus D\xF3ria:CB:70,Bouna Sarr:RB:68,Frank Anguissa:CM:68,Zin\xE9dine Machach:CAM:68,Henri Bedimo:LB:64,Patrice Evra:LB:64",
  "Olympique Marseille|2018": "Florian Thauvin:RW:86,Dimitri Payet:CAM:82,Frank Anguissa:CM:82,Morgan Sanson:CM:82,Jordan Amavi:LB:80,Clinton N'Jie:RW:79,Lucas Ocampos:LW:79,Boubacar Kamara:CDM:77,Konstantinos Mitroglou:ST:77,Val\xE8re Germain:ST:77,Adil Rami:CB:76,Bouna Sarr:RB:76,Hiroki Sakai:RB:76,Maxime Lopez:CDM:76,Aymen Abdennour:CB:72,Steve Mandanda:GK:70",
  "Olympique Marseille|2019": "Florian Thauvin:RW:86,Morgan Sanson:CM:83,Boubacar Kamara:CDM:82,Lucas Ocampos:LW:82,Kevin Strootman:CM:81,Mario Balotelli:ST:81,Duje Caleta-Car:CB:80,Maxime Lopez:CDM:80,Dimitri Payet:CAM:79,Jordan Amavi:LB:78,Bouna Sarr:RB:76,Hiroki Sakai:RB:76,Konstantinos Mitroglou:ST:76,Nemanja Radonjic:LW:76,Val\xE8re Germain:ST:76,Adil Rami:CB:73,Isaac Lihadji:RW:72,Steve Mandanda:GK:70",
  "Olympique Marseille|2020": "Boubacar Kamara:CDM:84,Florian Thauvin:RW:84,Duje Caleta-Car:CB:82,Morgan Sanson:CM:82,Valentin Rongier:CM:80,Maxime Lopez:CDM:79,Dar\xEDo Benedetto:ST:78,Bouna Sarr:RB:77,Dimitri Payet:CAM:77,Kevin Strootman:CM:77,Hiroki Sakai:RB:76,Nemanja Radonjic:LW:76,Val\xE8re Germain:ST:72,Marley Ak\xE9:LW:70,Steve Mandanda:GK:70,Sa\xEEf-Eddine Khaoui:CAM:68,Yuto Nagatomo:LB:64",
  "Olympique Marseille|2021": "Boubacar Kamara:CDM:85,Florian Thauvin:RW:83,Arkadiusz Milik:ST:82,Duje Caleta-Car:CB:82,Morgan Sanson:CM:81,Valentin Rongier:CM:79,Dar\xEDo Benedetto:ST:77,Jordan Amavi:LB:77,Leonardo Balerdi:CB:77,Pape Gueye:CM:77,Pol Lirola:RB:77,\xC1lvaro Gonz\xE1lez:CB:76,Bamba Dieng:ST:76,Dimitri Payet:CAM:76,Luis Henrique:RM:76,Micha\xEBl Cuisance:CM:76,Marley Ak\xE9:LW:70,Steve Mandanda:GK:68,Christopher Rocchia:LB:64",
  "Olympique Marseille|2022": "William Saliba:CB:86,Boubacar Kamara:CDM:82,Cengiz \xDCnder:RW:82,Gerson:CM:82,Matt\xE9o Guendouzi:CM:82,Arkadiusz Milik:ST:80,Duje Caleta-Car:CB:80,Amine Harit:LW:79,Valentin Rongier:CM:79,C\xE9dric Bakambu:ST:78,Pape Gueye:CM:78,Pau L\xF3pez:GK:78,Bamba Dieng:ST:77,Leonardo Balerdi:CB:77,Eric Bailly:CB:76,Pol Lirola:RB:76,Konrad de la Fuente:LW:74,Luis Henrique:RM:74,Rub\xE9n Blanco:GK:70",
  "Olympique Marseille|2023": "Matt\xE9o Guendouzi:CM:82,Valentin Rongier:CM:82,Vitinha:ST:82,Cengiz \xDCnder:RW:81,Chancel Mbemba:CB:81,Jordan Veretout:CM:80,Nuno Tavares:LB:80,Amine Harit:LW:79,Jonathan Clauss:RB:79,Pau L\xF3pez:GK:79,Ruslan Malinovskyi:CM:79,Issa Kabor\xE9:RB:77,Leonardo Balerdi:CB:77,Samuel Gigot:CB:77,Bamba Dieng:ST:76,Sead Kolasinac:CB:76,Alexis S\xE1nchez:CF:72,Rub\xE9n Blanco:GK:72,Dimitri Payet:CAM:68,Cheick Souar\xE9:LM:64",
  "Olympique Marseille|2024": "Isma\xEFla Sarr:RW:81,Leonardo Balerdi:CB:81,Iliman Ndiaye:RW:80,Amine Harit:LW:79,Chancel Mbemba:CB:79,Jordan Veretout:CM:79,Luis Henrique:RM:79,Valentin Rongier:CM:79,Vitinha:ST:79,Azzedine Ounahi:CM:78,Jonathan Clauss:RB:78,Faris Moumbagna:ST:77,Pau L\xF3pez:GK:77,Samuel Gigot:CB:77,Amir Murillo:RB:76,Bamo Me\xEFt\xE9:CB:76,Joaqu\xEDn Correa:CF:76,Pape Gueye:CM:76,Pierre-Emerick Aubameyang:ST:73,Ulisses Garcia:LB:72,Rub\xE9n Blanco:GK:68",
  "Olympique Marseille|2025": "Mason Greenwood:RW:86,Adrien Rabiot:CM:82,Elye Wahi:ST:82,Luis Henrique:RM:82,Leonardo Balerdi:CB:81,Jonathan Rowe:LW:80,Amar Dedi\u0107:RB:79,Isma\xEBl Kon\xE9:CM:79,Quentin Merlin:LB:79,Amine Harit:LW:77,Amir Murillo:RB:77,Bilal Nadir:CM:77,Ger\xF3nimo Rulli:GK:77,Lilian Brassier:CB:77,Neal Maupay:ST:77,Robinio Vaz:ST:77,Valentin Rongier:CM:77,Luiz Felipe:CB:74,Derek Cornelius:CB:73,Ulisses Garcia:LB:73,Jeffrey de Lange:GK:68",
  "Olympique Marseille|2026": "Mason Greenwood:RW:87,Ethan Nwaneri:CAM:85,Igor Paix\xE3o:LW:84,Amine Gouiri:ST:83,Quinten Timber:CM:82,Nayef Aguerd:CB:81,Timothy Weah:RM:81,Facundo Medina:CB:80,Leonardo Balerdi:CB:80,Benjamin Pavard:CB:79,Hamed Traor\xE9:LW:79,Bilal Nadir:CM:77,Emerson:LB:77,Amir Murillo:RB:76,Ger\xF3nimo Rulli:GK:76,Himad Abdelli:CAM:76,Jeffrey de Lange:GK:70",
  "PSV Eindhoven|2016": "Davy Pr\xF6pper:CM:77,Jeffrey Bruma:CB:77,Jetro Willems:CB:77,Luuk de Jong:ST:77,Andr\xE9s Guardado:CM:76,Gast\xF3n Pereiro:CAM:76,H\xE9ctor Moreno:CB:76,Jeroen Zoet:GK:76,Maxime Lestienne:RW:76,Adam Maher:CM:74,J\xFCrgen Locadia:ST:74,Santiago Arias:RB:74,Jorrit Hendrix:LM:73,Luciano Narsingh:RW:73,Joshua Brenet:RB:72,Nicolas Isimat-Mirin:CB:70",
  "PSV Eindhoven|2017": "Davy Pr\xF6pper:CM:77,Gast\xF3n Pereiro:CAM:77,Jeroen Zoet:GK:77,Luuk de Jong:ST:77,Andr\xE9s Guardado:CM:76,Bart Ramselaar:LW:76,H\xE9ctor Moreno:CB:76,Jetro Willems:CB:76,J\xFCrgen Locadia:ST:76,Marco van Ginkel:CM:76,Santiago Arias:RB:76,Siem de Jong:CAM:74,Jorrit Hendrix:LM:73,Joshua Brenet:RB:73,Oleksandr Zinchenko:LB:73,Nicolas Isimat-Mirin:CB:72,Steven Bergwijn:LW:72,Albert Gudmundsson:CF:64,Florian Jozefzoon:RW:64",
  "PSV Eindhoven|2018": "Hirving Lozano:LW:85,Steven Bergwijn:LW:83,Santiago Arias:RB:81,Gast\xF3n Pereiro:CAM:79,Jeroen Zoet:GK:79,Marco van Ginkel:CM:78,Jorrit Hendrix:LM:77,Luuk de Jong:ST:77,Pablo Rosario:CDM:77,Maximiliano Romero:ST:76,Donyell Malen:ST:73,Joshua Brenet:RB:73,Daniel Schwaab:CB:72,Derrick Luckassen:CB:72,Mauro J\xFAnior:LB:72,Albert Gudmundsson:CF:70,Kenneth Paal:LB:64",
  "PSV Eindhoven|2019": "Hirving Lozano:LW:85,Steven Bergwijn:LW:84,Donyell Malen:ST:83,Mohamed Ihattaren:CAM:82,Angeli\xF1o:LB:80,Denzel Dumfries:RB:79,Gast\xF3n Pereiro:CAM:78,Jeroen Zoet:GK:78,Luuk de Jong:ST:78,Jorrit Hendrix:LM:76,\xC9rick Guti\xE9rrez:CM:75,Maximiliano Romero:ST:73,Daniel Schwaab:CB:72,Michal Sad\xEDlek:CM:72,Nick Viergever:CB:72,Ryan Thomas:CDM:70,Dante Rigo:CDM:68,Zakaria Aboukhlal:RW:68",
  "PSV Eindhoven|2021": "Donyell Malen:ST:83,Cody Gakpo:LW:82,Denzel Dumfries:RB:80,Mohamed Ihattaren:CAM:80,Noni Madueke:RW:80,Philipp Max:LB:80,Mario G\xF6tze:CAM:78,Ibrahim Sangar\xE9:CDM:77,Jordan Teze:RB:76,Olivier Boscagli:CB:76,Pablo Rosario:CDM:75,Timo Baumgartl:CB:73,Yvon Mvogo:GK:73,\xC9rick Guti\xE9rrez:CM:72,Marco van Ginkel:CM:70,Maximiliano Romero:ST:70,Lars Unnerstall:GK:68",
  "PSV Eindhoven|2022": "Cody Gakpo:LW:87,Noni Madueke:RW:80,Joey Veerman:CM:79,Mario G\xF6tze:CAM:79,Ritsu Doan:RW:79,Carlos Vin\xEDcius:ST:78,Jordan Teze:RB:77,\xC9rick Guti\xE9rrez:CM:76,Olivier Boscagli:CB:76,Armando Obispo:CB:74,Bruma:LW:74,Mauro J\xFAnior:LB:74,Jo\xEBl Drommel:GK:73,Yvon Mvogo:GK:72,Phillipp Mwene:LB:70",
  "PSV Eindhoven|2024": "Johan Bakayoko:RW:86,Joey Veerman:CM:85,Malik Tillman:CAM:83,Olivier Boscagli:CB:83,Ismael Saibari:CAM:82,Sergi\xF1o Dest:RB:82,Noa Lang:LW:81,Hirving Lozano:LW:80,Jordan Teze:RB:80,Ricardo Pepi:ST:80,Walter Ben\xEDtez:GK:79,Armel Bella-Kotchap:CB:78,Mauro J\xFAnior:LB:76,Matteo Dams:LB:73,Jo\xEBl Drommel:GK:70,Luuk de Jong:ST:70,Tygo Land:CM:70",
  "PSV Eindhoven|2025": "Ismael Saibari:CAM:84,Johan Bakayoko:RW:84,Malik Tillman:CAM:84,Joey Veerman:CM:83,Noa Lang:LW:82,Olivier Boscagli:CB:82,Ryan Flamingo:CB:81,Mauro J\xFAnior:LB:80,Ricardo Pepi:ST:80,Sergi\xF1o Dest:RB:80,Walter Ben\xEDtez:GK:77,Adamo Nagalo:CB:74,Esmir Bajraktarevic:RW:73,Richard Ledezma:RB:72,Jo\xEBl Drommel:GK:68",
  "PSV Eindhoven|2026": "Ismael Saibari:CAM:84,Joey Veerman:CM:83,Ricardo Pepi:ST:82,Mauro J\xFAnior:LB:80,Paul Wanner:CAM:80,Sergi\xF1o Dest:RB:80,Yarek Gasiorowski:CB:80,Dennis Man:RW:79,Ryan Flamingo:CB:79,Ruben van Bommel:LW:78,Matej Kovar:GK:76,Couhaib Driouech:LW:74,Esmir Bajraktarevic:RW:73,Kiliann Sildillia:RB:73,Myron Boadu:ST:73,Nick Olij:GK:70",
  "Paris Saint-Germain|2016": "\xC1ngel Di Mar\xEDa:RW:87,Edinson Cavani:ST:85,Marco Verratti:CM:85,Lucas Moura:RW:84,Blaise Matuidi:CM:83,David Luiz:CB:83,Marquinhos:CB:83,Javier Pastore:CAM:82,Layvin Kurzawa:LB:82,Thiago Silva:CB:81,Serge Aurier:RB:79,Zlatan Ibrahimovi\u0107:ST:79,Adrien Rabiot:CM:78,Kevin Trapp:GK:78,Ezequiel Lavezzi:CF:77,Salvatore Sirigu:GK:77,Benjamin Stambouli:CDM:76,Gregory van der Wiel:RB:76,Presnel Kimpembe:CB:76,Jean-K\xE9vin Augustin:ST:70,Thiago Motta:CDM:70,Hervin Ongenda:CAM:68",
  "Paris Saint-Germain|2017": "Marco Verratti:CM:87,\xC1ngel Di Mar\xEDa:RW:86,Edinson Cavani:ST:86,Lucas Moura:RW:85,Julian Draxler:LW:84,Marquinhos:CB:84,Blaise Matuidi:CM:83,Grzegorz Krychowiak:CDM:83,Adrien Rabiot:CM:82,Layvin Kurzawa:LB:82,Javier Pastore:CAM:81,Gon\xE7alo Guedes:LW:80,Jean-K\xE9vin Augustin:ST:80,Thiago Silva:CB:80,Hatem Ben Arfa:CAM:79,Serge Aurier:RB:79,Alphonse Areola:GK:77,Kevin Trapp:GK:77,Thomas Meunier:RB:77,Presnel Kimpembe:CB:76,Christopher Nkunku:ST:70,Maxwell:LB:64",
  "Paris Saint-Germain|2018": "Kylian Mbapp\xE9:ST:94,Neymar:CAM:93,Marco Verratti:CM:88,Edinson Cavani:ST:87,Marquinhos:CB:87,Adrien Rabiot:CM:86,\xC1ngel Di Mar\xEDa:RW:86,Julian Draxler:LW:85,Thomas Meunier:RB:84,Giovani Lo Celso:CAM:83,Presnel Kimpembe:CB:83,Layvin Kurzawa:LB:82,Yuri Berchiche:LB:81,Alphonse Areola:GK:79,Christopher Nkunku:ST:78,Kevin Trapp:GK:77,Thiago Silva:CB:77,Dani Alves:RB:74,Stanley Nsoki:CB:73,Timothy Weah:RM:73,Antoine Bernede:CM:70,Lassana Diarra:CDM:70",
  "Paris Saint-Germain|2019": "Kylian Mbapp\xE9:ST:94,Neymar:CAM:93,Marco Verratti:CM:89,Marquinhos:CB:88,Edinson Cavani:ST:86,\xC1ngel Di Mar\xEDa:RW:85,Leandro Paredes:CDM:85,Julian Draxler:LW:84,Presnel Kimpembe:CB:84,Thilo Kehrer:CB:84,Thomas Meunier:RB:83,Christopher Nkunku:ST:82,Juan Bernat:LB:81,Moussa Diaby:RW:81,Alphonse Areola:GK:80,Colin Dagba:RB:80,Layvin Kurzawa:LB:80,Stanley Nsoki:CB:77,Adil Aouchiche:CAM:74,Gianluigi Buffon:GK:64",
  "Paris Saint-Germain|2020": "Kylian Mbapp\xE9:ST:93,Neymar:CAM:91,Marquinhos:CB:88,Marco Verratti:CM:87,Mauro Icardi:ST:87,\xC1ngel Di Mar\xEDa:RW:84,Presnel Kimpembe:CB:84,Abdou Diallo:CB:83,Pablo Sarabia:CAM:83,Thilo Kehrer:CB:83,Idrissa Gueye:CDM:82,Julian Draxler:LW:82,Thomas Meunier:RB:82,Edinson Cavani:ST:81,Leandro Paredes:CDM:81,Ander Herrera:CM:80,Colin Dagba:RB:80,Juan Bernat:LB:80,Layvin Kurzawa:LB:78,Keylor Navas:GK:77,Sergio Rico:GK:76,Mitchel Bakker:LM:72",
  "Paris Saint-Germain|2021": "Kylian Mbapp\xE9:ST:93,Neymar:CAM:91,Marquinhos:CB:89,Marco Verratti:CM:87,Mauro Icardi:ST:85,Presnel Kimpembe:CB:85,Moise Kean:ST:84,\xC1ngel Di Mar\xEDa:RW:83,Abdou Diallo:CB:82,Leandro Paredes:CDM:82,Pablo Sarabia:CAM:82,Thilo Kehrer:CB:82,Julian Draxler:LW:81,Idrissa Gueye:CDM:80,Juan Bernat:LB:80,Alessandro Florenzi:RB:79,Ander Herrera:CM:79,Colin Dagba:RB:78,Keylor Navas:GK:78,Layvin Kurzawa:LB:78,Sergio Rico:GK:76",
  "Paris Saint-Germain|2022": "Kylian Mbapp\xE9:ST:93,Neymar:CAM:89,Achraf Hakimi:RB:88,Marquinhos:CB:88,Nuno Mendes:LB:87,Gianluigi Donnarumma:GK:86,Lionel Messi:RW:86,Marco Verratti:CM:86,Presnel Kimpembe:CB:85,Abdou Diallo:CB:82,Georginio Wijnaldum:CM:82,Mauro Icardi:ST:82,Thilo Kehrer:CB:82,Julian Draxler:LW:80,Leandro Paredes:CDM:80,Xavi Simons:CAM:80,\xC1ngel Di Mar\xEDa:RW:78,Idrissa Gueye:CDM:78,Juan Bernat:LB:78,Ander Herrera:CM:77,Colin Dagba:RB:76,Junior Dina Ebimbe:RM:76,Keylor Navas:GK:76,Warren Za\xEFre-Emery:CM:74,Isma\xEBl Gharbi:LW:68",
  "Paris Saint-Germain|2023": "Kylian Mbapp\xE9:ST:93,Achraf Hakimi:RB:88,Marquinhos:CB:88,Neymar:CAM:88,Nuno Mendes:LB:88,Warren Za\xEFre-Emery:CM:87,Gianluigi Donnarumma:GK:86,Lionel Messi:RW:86,Lucas Hern\xE1ndez:LB:86,Fabi\xE1n Ruiz:CM:85,Marco Verratti:CM:85,Presnel Kimpembe:CB:84,Carlos Soler:CM:83,Hugo Ekitik\xE9:ST:81,Nordi Mukiele:RB:80,El Chadaille Bitshiabu:CB:79,Danilo Pereira:CB:77,Mitchel Bakker:LM:77,Isma\xEBl Gharbi:LW:73,Ilyes Housni:ST:72",
  "Paris Saint-Germain|2024": "Kylian Mbapp\xE9:ST:93,Bradley Barcola:LW:88,Achraf Hakimi:RB:87,Marquinhos:CB:87,Nuno Mendes:LB:87,Ousmane Demb\xE9l\xE9:ST:87,Randal Kolo Muani:ST:87,Warren Za\xEFre-Emery:CM:87,Gianluigi Donnarumma:GK:85,Lucas Hern\xE1ndez:LB:85,Milan \u0160kriniar:CB:85,Fabi\xE1n Ruiz:CM:84,Kang-in Lee:CAM:83,Lucas Beraldo:CB:83,Carlos Soler:CM:81,Marco Asensio:CAM:81,Nordi Mukiele:RB:77,Danilo Pereira:CB:76,Senny Mayulu:CM:73,Ibrahim Mbaye:RW:68",
  "Paris Saint-Germain|2025": "Jo\xE3o Neves:CM:91,D\xE9sir\xE9 Dou\xE9:RW:90,Khvicha Kvaratskhelia:LW:90,Ousmane Demb\xE9l\xE9:ST:90,Achraf Hakimi:RB:89,Nuno Mendes:LB:89,Bradley Barcola:LW:88,Willian Pacho:CB:88,Warren Za\xEFre-Emery:CM:87,Gianluigi Donnarumma:GK:86,Gon\xE7alo Ramos:ST:86,Fabi\xE1n Ruiz:CM:85,Senny Mayulu:CM:85,Marquinhos:CB:84,Lucas Hern\xE1ndez:LB:83,Ibrahim Mbaye:RW:82,Kang-in Lee:CAM:82,Lucas Beraldo:CB:82,Matvey Safonov:GK:81,Axel Tape:CB:76,Yoram Zague:RB:70",
  "Paris Saint-Germain|2026": "Jo\xE3o Neves:CM:91,D\xE9sir\xE9 Dou\xE9:RW:90,Khvicha Kvaratskhelia:LW:90,Ousmane Demb\xE9l\xE9:ST:90,Achraf Hakimi:RB:89,Nuno Mendes:LB:89,Bradley Barcola:LW:88,Willian Pacho:CB:88,Warren Za\xEFre-Emery:CM:87,Ilya Zabarnyi:CB:86,Fabi\xE1n Ruiz:CM:85,Senny Mayulu:CM:85,Gon\xE7alo Ramos:ST:84,Ibrahim Mbaye:RW:83,Kang-in Lee:CAM:83,Lucas Chevalier:GK:83,Marquinhos:CB:83,Matvey Safonov:GK:82,Lucas Beraldo:CB:81,Lucas Hern\xE1ndez:LB:81,Dro Fern\xE1ndez:CAM:77",
  "RB Leipzig|2016": "Davie Selke:ST:73,Emil Forsberg:LW:73,Marcel Sabitzer:CM:73,Yussuf Poulsen:ST:73,Marcel Halstenberg:CB:72,At\u0131n\xE7 Nukan:CB:70,Dominik Kaiser:CM:70,Lukas Klostermann:CB:70,Massimo Bruno:CAM:70,Stefan Ilsanker:CDM:70,Willi Orb\xE1n:CB:70,Diego Demme:CDM:68,P\xE9ter Gul\xE1csi:GK:68,Idrissa Tour\xE9:RM:64",
  "RB Leipzig|2017": "Timo Werner:ST:87,Naby Ke\xEFta:CM:86,Emil Forsberg:LW:82,Dayot Upamecano:CB:81,Marcel Sabitzer:CM:80,Oliver Burke:ST:78,Diego Demme:CDM:77,Willi Orb\xE1n:CB:77,Yussuf Poulsen:ST:77,Lukas Klostermann:CB:76,Marcel Halstenberg:CB:76,Bernardo:LB:74,Stefan Ilsanker:CDM:74,P\xE9ter Gul\xE1csi:GK:73,Dominik Kaiser:CM:70",
  "RB Leipzig|2018": "Naby Ke\xEFta:CM:88,Timo Werner:ST:88,Dayot Upamecano:CB:83,Emil Forsberg:LW:82,Jean-K\xE9vin Augustin:ST:82,Marcel Sabitzer:CM:82,Ademola Lookman:LW:81,Yussuf Poulsen:ST:81,Ibrahima Konat\xE9:CB:80,Kevin Kampl:CM:80,Lukas Klostermann:CB:80,Diego Demme:CDM:79,Willi Orb\xE1n:CB:79,Bernardo:LB:77,P\xE9ter Gul\xE1csi:GK:77,Konrad Laimer:RB:76,Stefan Ilsanker:CDM:73,Yvon Mvogo:GK:70",
  "RB Leipzig|2019": "Timo Werner:ST:89,Dayot Upamecano:CB:86,Ibrahima Konat\xE9:CB:86,Marcel Sabitzer:CM:85,Lukas Klostermann:CB:84,Yussuf Poulsen:ST:84,Emil Forsberg:LW:83,Kevin Kampl:CM:82,Konrad Laimer:RB:82,Marcel Halstenberg:CB:82,Nordi Mukiele:RB:82,Amadou Haidara:CM:81,Jean-K\xE9vin Augustin:ST:81,Diego Demme:CDM:80,Tyler Adams:CDM:79,P\xE9ter Gul\xE1csi:GK:78,Bruma:LW:77,Marcelo Saracchi:LB:77,Yvon Mvogo:GK:70",
  "RB Leipzig|2020": "Timo Werner:ST:89,Dayot Upamecano:CB:87,Ibrahima Konat\xE9:CB:85,Lukas Klostermann:CB:85,Christopher Nkunku:ST:84,Dani Olmo:CAM:84,Marcel Sabitzer:CM:84,Konrad Laimer:RB:83,Yussuf Poulsen:ST:83,Angeli\xF1o:LB:82,Emil Forsberg:LW:82,Nordi Mukiele:RB:82,Marcel Halstenberg:CB:81,Amadou Haidara:CM:80,Kevin Kampl:CM:80,Tyler Adams:CDM:80,Ademola Lookman:LW:79,Hannes Wolf:RW:78,P\xE9ter Gul\xE1csi:GK:78,Ethan Ampadu:CDM:77,Yvon Mvogo:GK:70",
  "RB Leipzig|2021": "Christopher Nkunku:ST:87,Dayot Upamecano:CB:87,Dani Olmo:CAM:86,Marcel Sabitzer:CM:85,Angeli\xF1o:LB:84,Ibrahima Konat\xE9:CB:84,Lukas Klostermann:CB:84,Dominik Szoboszlai:CAM:83,Konrad Laimer:RB:83,Amadou Haidara:CM:82,Nordi Mukiele:RB:82,Yussuf Poulsen:ST:82,Emil Forsberg:LW:81,Tyler Adams:CDM:81,Alexander S\xF8rloth:ST:80,Marcel Halstenberg:CB:80,Kevin Kampl:CM:79,P\xE9ter Gul\xE1csi:GK:79,Josep Mart\xEDnez:GK:70",
  "RB Leipzig|2022": "Christopher Nkunku:ST:89,Josko Gvardiol:CB:89,Dani Olmo:CAM:86,Andr\xE9 Silva:ST:84,Dominik Szoboszlai:CAM:84,Angeli\xF1o:LB:83,Konrad Laimer:RB:83,Mohamed Simakan:CB:83,Amadou Haidara:CM:82,Nordi Mukiele:RB:81,Lukas Klostermann:CB:80,Tyler Adams:CDM:80,Yussuf Poulsen:ST:79,Emil Forsberg:LW:78,Willi Orb\xE1n:CB:77,P\xE9ter Gul\xE1csi:GK:76,Kevin Kampl:CM:74",
  "RB Leipzig|2023": "Christopher Nkunku:ST:89,Dominik Szoboszlai:CAM:89,Josko Gvardiol:CB:89,Dani Olmo:CAM:86,Mohamed Simakan:CB:84,Konrad Laimer:RB:83,Xaver Schlager:CM:83,Timo Werner:ST:82,Andr\xE9 Silva:ST:81,Benjamin Henrichs:RB:81,David Raum:LB:81,Amadou Haidara:CM:80,Lukas Klostermann:CB:78,Abdou Diallo:CB:77,Emil Forsberg:LW:76,P\xE9ter Gul\xE1csi:GK:73,Janis Blaswich:GK:72",
  "RB Leipzig|2024": "Xavi Simons:CAM:89,Dani Olmo:CAM:87,Lo\xEFs Openda:ST:87,Benjamin Sesko:ST:86,Castello Lukeba:CB:86,Mohamed Simakan:CB:84,Xaver Schlager:CM:83,David Raum:LB:82,Amadou Haidara:CM:81,Benjamin Henrichs:RB:81,El Chadaille Bitshiabu:CB:78,Willi Orb\xE1n:CB:77,Yussuf Poulsen:ST:74,Kevin Kampl:CM:72,Janis Blaswich:GK:70,P\xE9ter Gul\xE1csi:GK:70",
  "RB Leipzig|2025": "Benjamin Sesko:ST:88,Xavi Simons:CAM:88,Castello Lukeba:CB:86,Lo\xEFs Openda:ST:86,Antonio Nusa:LW:84,Assan Ou\xE9draogo:CM:83,Lutsharel Geertruida:RB:83,Christoph Baumgartner:CAM:81,David Raum:LB:81,Amadou Haidara:CM:80,El Chadaille Bitshiabu:CB:80,Xaver Schlager:CM:80,Benjamin Henrichs:RB:79,Lukas Klostermann:CB:76,Maarten Vandevoordt:GK:76,Willi Orb\xE1n:CB:76,Yussuf Poulsen:ST:73,P\xE9ter Gul\xE1csi:GK:68",
  "RB Leipzig|2026": "Yan Diomande:LW:89,Castello Lukeba:CB:86,Antonio Nusa:LW:84,Assan Ou\xE9draogo:CM:83,Christoph Baumgartner:CAM:83,R\xF4mulo:ST:83,David Raum:LB:82,Conrad Harder:ST:81,Ezechiel Banzuzi:CM:80,El Chadaille Bitshiabu:CB:79,Andrija Maksimovic:CAM:78,Ridle Baku:RB:78,Benjamin Henrichs:RB:77,Xaver Schlager:CM:77,Maarten Vandevoordt:GK:76,Willi Orb\xE1n:CB:74,Adri Mehmeti:CM:70,Max Finkgr\xE4fe:LB:70,Christopher Lenz:LM:68,P\xE9ter Gul\xE1csi:GK:68",
  "Racing Club|2021": "Mat\xEDas Rojas:CAM:74,An\xEDbal Moreno:CDM:73,Gabriel Arias:GK:73,Tom\xE1s Chancalay:LW:72,Leonel Miranda:CM:70,Nicol\xE1s Reniero:ST:70,Alexis Soto:LB:68,Eugenio Mena:LB:68,H\xE9ctor F\xE9rtoli:LW:68,Juan Jos\xE9 C\xE1ceres:RB:68,Ezequiel Schelotto:RM:64,Fabricio Dom\xEDnguez:RB:64",
  "Racing Club|2022": "An\xEDbal Moreno:CDM:76,Carlos Alcaraz:CM:76,Enzo Copetti:ST:74,Edwin Cardona:CAM:72,Facundo Mura:RB:72,Mat\xEDas Rojas:CAM:72,Tom\xE1s Chancalay:LW:72,Benjam\xEDn Garr\xE9:RW:70,Gabriel Arias:GK:70,Leonel Miranda:CM:70,Maximiliano Romero:ST:70,Eugenio Mena:LB:68,Gast\xF3n G\xF3mez:GK:68,Fabricio Dom\xEDnguez:RB:64,Juan Jos\xE9 C\xE1ceres:RB:64",
  "Racing Club|2026": "Juan Nardoni:CM:77,Valent\xEDn Carboni:CAM:76,Marco Di C\xE9sare:CB:74,Baltasar Rodr\xEDguez:CAM:73,Gast\xF3n Martirena:RB:73,Gabriel Rojas:LB:72,Santiago Solari:RW:72,Adri\xE1n Mart\xEDnez:ST:70,Duv\xE1n Vergara:LW:70,Ezequiel Cannavo:RB:70,Tom\xE1s Conechny:LW:70,Mat\xEDas Tagliamonte:GK:68",
  "Rangers FC|2023": "Malik Tillman:CAM:78,Ryan Kent:LW:78,Todd Cantwell:CAM:77,Alfredo Morelos:ST:76,Connor Goldson:CB:76,James Tavernier:RB:76,Borna Barisic:LB:75,Fashion Sakala:LW:74,Glen Kamara:CM:74,Antonio Colak:ST:73,R\u0131dvan Y\u0131lmaz:LB:73,Kemar Roofe:ST:72,Ryan Jack:CM:72,Jack Butland:GK:70,Scott Wright:RW:68",
  "Rangers FC|2024": "F\xE1bio Silva:ST:80,Abdallah Sima:LW:77,Todd Cantwell:CAM:76,James Tavernier:RB:75,Mohamed Diomand\xE9:CM:74,Connor Goldson:CB:73,John Souttar:CB:73,R\u0131dvan Y\u0131lmaz:LB:73,Cyriel Dessers:ST:72,Dujon Sterling:RB:72,\xD3scar Cort\xE9s:LW:72,Jack Butland:GK:70,Tom Lawrence:CAM:70,Ross McCausland:RW:68",
  "Rangers FC|2026": "Mikey Moore:LW:80,Emmanuel Fernandez:CB:77,Youssef Chermiti:ST:77,Djeidi Gassama:LW:76,Mohamed Diomand\xE9:CM:76,Nasser Djiga:CB:74,Tuur Rommens:LB:73,Max Aarons:RB:72,Oliver Antman:RW:72,Dujon Sterling:RB:70,Nedim Bajrami:CAM:70,Thelo Aasgaard:CAM:70,Jack Butland:GK:68,Jayden Meghoma:LB:68",
  "Real Madrid|2016": "Cristiano Ronaldo:ST:91,Gareth Bale:RW:90,James Rodr\xEDguez:CAM:89,Karim Benzema:ST:87,Toni Kroos:CM:87,Isco:CAM:86,Luka Modri\u0107:CM:86,Sergio Ramos:CB:85,Marcelo:LB:83,Rapha\xEBl Varane:CB:83,Daniel Carvajal:RB:82,Casemiro:CDM:81,Keylor Navas:GK:81,Mateo Kovacic:CM:81,Danilo:CB:80,Jes\xE9:LW:79,Lucas V\xE1zquez:RB:77,Kiko Casilla:GK:76,Nacho Fern\xE1ndez:CB:73,Borja Mayoral:ST:70",
  "Real Madrid|2017": "Cristiano Ronaldo:ST:90,Gareth Bale:RW:90,Toni Kroos:CM:88,Karim Benzema:ST:87,\xC1lvaro Morata:ST:86,James Rodr\xEDguez:CAM:86,Luka Modri\u0107:CM:86,Isco:CAM:85,Marcelo:LB:85,Sergio Ramos:CB:85,Daniel Carvajal:RB:84,Rapha\xEBl Varane:CB:84,Casemiro:CDM:83,Mateo Kovacic:CM:82,Keylor Navas:GK:81,Danilo:CB:80,Lucas V\xE1zquez:RB:79,Nacho Fern\xE1ndez:CB:79,F\xE1bio Coentr\xE3o:LB:76,Kiko Casilla:GK:74",
  "Real Madrid|2018": "Cristiano Ronaldo:ST:91,Gareth Bale:RW:90,Isco:CAM:90,Marco Asensio:CAM:90,Rapha\xEBl Varane:CB:89,Toni Kroos:CM:89,Casemiro:CDM:88,Marcelo:LB:88,Daniel Carvajal:RB:87,Karim Benzema:ST:86,Sergio Ramos:CB:86,Luka Modri\u0107:CM:85,Mateo Kovacic:CM:84,Nacho Fern\xE1ndez:CB:84,Achraf Hakimi:RB:82,Dani Ceballos:CM:81,Theo Hern\xE1ndez:LB:81,Keylor Navas:GK:80,Jes\xFAs Vallejo:CB:79,Borja Mayoral:ST:76,Kiko Casilla:GK:74",
  "Real Madrid|2019": "Rapha\xEBl Varane:CB:89,Casemiro:CDM:88,Gareth Bale:RW:88,Vinicius Junior:LW:88,Isco:CAM:87,Marco Asensio:CAM:87,Thibaut Courtois:GK:87,Toni Kroos:CM:87,Dani Ceballos:CM:86,Daniel Carvajal:RB:86,Federico Valverde:CM:86,Karim Benzema:ST:85,Marcelo:LB:84,\xC1lvaro Odriozola:RB:82,Nacho Fern\xE1ndez:CB:82,Sergio Ramos:CB:82,Sergio Reguil\xF3n:LB:82,Luka Modri\u0107:CM:81,Mariano D\xEDaz:ST:81,Brahim D\xEDaz:RW:80,Keylor Navas:GK:78,Jes\xFAs Vallejo:CB:77,Cristo:LW:73",
  "Real Madrid|2020": "Eden Hazard:LW:90,Casemiro:CDM:89,Thibaut Courtois:GK:89,Federico Valverde:CM:88,Rapha\xEBl Varane:CB:88,Rodrygo:RW:86,Toni Kroos:CM:86,Vinicius Junior:LW:86,Daniel Carvajal:RB:85,\xC9der Milit\xE3o:CB:85,Ferland Mendy:LB:85,Isco:CAM:85,Marco Asensio:CAM:85,Gareth Bale:RW:84,Karim Benzema:ST:84,Luka Jovi\u0107:ST:84,Lucas V\xE1zquez:RB:80,Marcelo:LB:80,Alphonse Areola:GK:79,Mariano D\xEDaz:ST:79,Luka Modri\u0107:CM:78",
  "Real Madrid|2021": "Vinicius Junior:LW:90,Thibaut Courtois:GK:89,Casemiro:CDM:88,Federico Valverde:CM:88,Rapha\xEBl Varane:CB:88,\xC9der Milit\xE3o:CB:87,Eden Hazard:LW:86,Ferland Mendy:LB:86,Rodrygo:RW:86,Toni Kroos:CM:86,Daniel Carvajal:RB:85,Marco Asensio:CAM:85,Karim Benzema:ST:82,Lucas V\xE1zquez:RB:79,Sergio Ramos:CB:79,Luka Modri\u0107:CM:77,Marcelo:LB:77,Mariano D\xEDaz:ST:77,Hugo Duro:ST:76,Andriy Lunin:GK:70,Sergio Arribas:CAM:70",
  "Real Madrid|2022": "Vinicius Junior:LW:91,Federico Valverde:CM:90,Rodrygo:RW:89,David Alaba:CB:87,\xC9der Milit\xE3o:CB:87,Eduardo Camavinga:CM:87,Thibaut Courtois:GK:87,Casemiro:CDM:86,Ferland Mendy:LB:85,Marco Asensio:CAM:85,Karim Benzema:ST:84,Toni Kroos:CM:81,Daniel Carvajal:RB:80,Eden Hazard:LW:80,Luka Jovi\u0107:ST:80,Dani Ceballos:CM:79,Lucas V\xE1zquez:RB:78,Isco:CAM:77,Nacho Fern\xE1ndez:CB:76,Mariano D\xEDaz:ST:74,Andriy Lunin:GK:72,Gareth Bale:RW:70,Marcelo:LB:70",
  "Real Madrid|2023": "Vinicius Junior:LW:92,Eduardo Camavinga:CM:90,Federico Valverde:CM:90,Rodrygo:RW:90,\xC9der Milit\xE3o:CB:88,David Alaba:CB:86,Thibaut Courtois:GK:86,Antonio R\xFCdiger:CB:84,Ferland Mendy:LB:84,Karim Benzema:ST:82,Marco Asensio:CAM:82,Toni Kroos:CM:80,Daniel Carvajal:RB:79,Dani Ceballos:CM:78,Andriy Lunin:GK:76,Lucas V\xE1zquez:RB:76,\xC1lvaro Rodr\xEDguez:ST:74,Nacho Fern\xE1ndez:CB:74,Eden Hazard:LW:73",
  "Real Madrid|2024": "Vinicius Junior:LW:94,Jude Bellingham:CAM:93,Federico Valverde:CM:92,Rodrygo:RW:91,Eduardo Camavinga:CM:90,\xC9der Milit\xE3o:CB:87,Arda G\xFCler:CAM:86,Brahim D\xEDaz:RW:85,Thibaut Courtois:GK:83,Andriy Lunin:GK:82,Antonio R\xFCdiger:CB:82,David Alaba:CB:82,Ferland Mendy:LB:82,Fran Garc\xEDa:LB:79,Daniel Carvajal:RB:78,Toni Kroos:CM:78,Dani Ceballos:CM:76,Joselu:ST:73,Lucas V\xE1zquez:RB:72,\xC1lvaro Rodr\xEDguez:ST:70",
  "Real Madrid|2025": "Kylian Mbapp\xE9:ST:94,Jude Bellingham:CAM:93,Vinicius Junior:LW:93,Federico Valverde:CM:92,Arda G\xFCler:CAM:90,Rodrygo:RW:90,Eduardo Camavinga:CM:88,Brahim D\xEDaz:RW:86,Ra\xFAl Asencio:CB:85,Endrick:ST:84,\xC9der Milit\xE3o:CB:83,Antonio R\xFCdiger:CB:81,Thibaut Courtois:GK:81,Andriy Lunin:GK:80,Fran Garc\xEDa:LB:80,Jacobo Ram\xF3n:CB:80,Ferland Mendy:LB:79,Gonzalo Garc\xEDa:ST:79,Dani Ceballos:CM:77,V\xEDctor Mu\xF1oz:LW:77,Daniel Carvajal:RB:76,Luka Modri\u0107:CM:72,Lucas V\xE1zquez:RB:70",
  "Real Madrid|2026": "Kylian Mbapp\xE9:ST:94,Jude Bellingham:CAM:92,Vinicius Junior:LW:92,Federico Valverde:CM:91,Arda G\xFCler:CAM:90,Dean Huijsen:CB:88,Trent Alexander-Arnold:RB:88,\xC1lvaro Carreras:LB:87,Eduardo Camavinga:CM:86,Franco Mastantuono:RW:86,Rodrygo:RW:86,Gonzalo Garc\xEDa:ST:83,\xC9der Milit\xE3o:CB:82,Ra\xFAl Asencio:CB:82,Thiago Pitarch:CM:81,Thibaut Courtois:GK:80,Andriy Lunin:GK:79,Fran Garc\xEDa:LB:78,Antonio R\xFCdiger:CB:77,Dani Ceballos:CM:76,Daniel Carvajal:RB:74",
  "SL Benfica|2016": "Nico Gait\xE1n:CAM:83,Renato Sanches:CM:83,Eduardo Salvio:RW:80,Pizzi:CAM:79,Jonas:CF:78,Konstantinos Mitroglou:ST:78,Ljubomir Fejsa:CDM:78,Ra\xFAl Jim\xE9nez:ST:78,Victor Lindel\xF6f:CB:78,Andr\xE9 Carrillo:CM:77,Andreas Samaris:CDM:77,Gon\xE7alo Guedes:LW:77,Alejandro Grimaldo:LB:76,Andr\xE9 Almeida:RB:76,Ederson:GK:76,Jardel:CB:76,Lisandro L\xF3pez:CB:76,N\xE9lson Semedo:RB:76,Andrija Zivkovic:RW:75,Luis\xE3o:CB:70,Luka Jovi\u0107:ST:70,Diogo Gon\xE7alves:LW:64,J\xFAlio C\xE9sar:GK:64",
  "SL Benfica|2017": "Ederson:GK:82,Victor Lindel\xF6f:CB:82,N\xE9lson Semedo:RB:81,Pizzi:CAM:81,Rafa Silva:CF:79,Konstantinos Mitroglou:ST:78,Ljubomir Fejsa:CDM:78,Ra\xFAl Jim\xE9nez:ST:78,Alejandro Grimaldo:LB:77,Andr\xE9 Carrillo:CM:76,Andreas Samaris:CDM:76,Andrija Zivkovic:RW:76,Franco Cervi:LW:76,Lisandro L\xF3pez:CB:74,Jardel:CB:73,Andr\xE9 Horta:CM:72,Diogo Gon\xE7alves:LW:70,Mile Svilar:GK:70,Eliseu:LB:68,Pedro Pereira:RB:68",
  "SL Benfica|2018": "R\xFAben Dias:CB:83,Alejandro Grimaldo:LB:82,Eduardo Salvio:RW:82,Pizzi:CAM:82,Andrija Zivkovic:RW:80,Franco Cervi:LW:80,Ra\xFAl Jim\xE9nez:ST:80,Gedson Fernandes:CM:79,Ljubomir Fejsa:CDM:79,Rafa Silva:CF:79,Jo\xE3o Carvalho:CAM:77,Andr\xE9 Almeida:RB:76,Andreas Samaris:CDM:76,Bruno Varela:GK:76,Haris Seferovic:ST:74,Jardel:CB:72,Mile Svilar:GK:70,Heri Tavares:LW:68,Douglas:RB:64",
  "SL Benfica|2019": "Jo\xE3o F\xE9lix:CF:90,R\xFAben Dias:CB:85,Alejandro Grimaldo:LB:84,Pizzi:CAM:83,Gedson Fernandes:CM:82,Florentino:CDM:81,Andrija Zivkovic:RW:80,Eduardo Salvio:RW:80,Ferro:CB:80,Franco Cervi:LW:80,Haris Seferovic:ST:80,Gabriel Pires:CDM:79,Odysseas Vlachodimos:GK:79,Jota:LW:77,Andr\xE9 Almeida:RB:76,Facundo Ferreyra:ST:74,Nicol\xE1s Castillo:ST:74,Adel Taarabt:CM:73,Nuno Tavares:LB:73,Mile Svilar:GK:70,Nuno Santos:CAM:68",
  "SL Benfica|2020": "R\xFAben Dias:CB:87,Alejandro Grimaldo:LB:83,Pizzi:CAM:82,Rafa Silva:CF:82,Carlos Vin\xEDcius:ST:81,Julian Weigl:CDM:81,Florentino:CDM:80,Odysseas Vlachodimos:GK:80,Gedson Fernandes:CM:79,Haris Seferovic:ST:78,Chiquinho:CAM:76,Franco Cervi:LW:76,Andr\xE9 Almeida:RB:75,Adel Taarabt:CM:74,Gon\xE7alo Ramos:ST:73,Nuno Tavares:LB:73,Andrija Zivkovic:RW:72,Tiago Dantas:CM:72,Mile Svilar:GK:68",
  "SL Benfica|2021": "Darwin N\xFA\xF1ez:ST:84,Alejandro Grimaldo:LB:83,Rafa Silva:CF:83,Everton:LW:82,Julian Weigl:CDM:82,Haris Seferovic:ST:80,Luca Waldschmidt:ST:80,Odysseas Vlachodimos:GK:80,Pedrinho:RW:80,Pizzi:CAM:80,Nuno Tavares:LB:79,Gabriel Pires:CDM:78,Jan Vertonghen:CB:77,Diogo Gon\xE7alves:LW:76,Ferro:CB:76,Helton Leite:GK:76,Morato:CB:76,Nicol\xE1s Otamendi:CB:76,Andr\xE9 Almeida:RB:74,Chiquinho:CAM:74,Adel Taarabt:CM:72,Gilberto:RB:72",
  "SL Benfica|2022": "Darwin N\xFA\xF1ez:ST:88,Gon\xE7alo Ramos:ST:83,David Neres:RW:82,Julian Weigl:CDM:82,Rafa Silva:CF:82,Alejandro Grimaldo:LB:81,Odysseas Vlachodimos:GK:80,Roman Yaremchuk:ST:80,Ant\xF3nio Silva:CB:79,Everton:LW:79,Morato:CB:79,Lucas Ver\xEDssimo:CB:77,Valentino Lazaro:RM:75,Diogo Gon\xE7alves:LW:74,Gilberto:RB:74,Paulo Bernardo:CM:73,Soualiho Me\xEFt\xE9:CDM:73,Adel Taarabt:CM:70,Helton Leite:GK:70,Tiago Gouveia:RW:70",
  "SL Benfica|2023": "Ant\xF3nio Silva:CB:86,Gon\xE7alo Ramos:ST:86,Jo\xE3o Neves:CM:86,Alejandro Grimaldo:LB:84,Gon\xE7alo Guedes:LW:83,David Neres:RW:82,Rafa Silva:CF:82,Fredrik Aursnes:CM:81,Odysseas Vlachodimos:GK:80,Alexander Bah:RB:79,Morato:CB:79,Andreas Schjelderup:LW:77,Casper Tengstedt:ST:76,Lucas Ver\xEDssimo:CB:76,Petar Musa:ST:76,Chiquinho:CAM:74,Cher Ndour:CM:72,Gilberto:RB:72,Samuel Soares:GK:70,Hugo F\xE9lix:CAM:68",
  "SL Benfica|2024": "Jo\xE3o Neves:CM:87,Ant\xF3nio Silva:CB:86,David Neres:RW:83,Orkun K\xF6k\xE7\xFC:CM:83,Tom\xE1s Ara\xFAjo:CB:83,Anatoliy Trubin:GK:82,Marcos Leonardo:ST:82,Fredrik Aursnes:CM:81,\xC1lvaro Carreras:LB:80,Alexander Bah:RB:79,Arthur Cabral:ST:79,Gon\xE7alo Guedes:LW:79,Morato:CB:79,Rafa Silva:CF:79,Benjam\xEDn Rollheiser:RW:77,Casper Tengstedt:ST:76,Chiquinho:CAM:73,Juan Bernat:LB:73,Samuel Soares:GK:70,Diego Moreira:LM:68,Hugo F\xE9lix:CAM:68",
  "SL Benfica|2025": "\xC1lvaro Carreras:LB:87,Ant\xF3nio Silva:CB:84,Tom\xE1s Ara\xFAjo:CB:84,Vangelis Pavlidis:ST:84,Anatoliy Trubin:GK:83,Orkun K\xF6k\xE7\xFC:CM:83,Kerem Akt\xFCrko\u011Flu:LW:82,Fredrik Aursnes:CM:81,Andreas Schjelderup:LW:79,Leandro Barreiro:CM:79,Alexander Bah:RB:78,Gianluca Prestianni:RW:78,Zeki Amdouni:ST:78,Arthur Cabral:ST:77,Samuel Dahl:LB:77,Benjam\xEDn Rollheiser:RW:76,Renato Sanches:CM:72,Samuel Soares:GK:72,Hugo F\xE9lix:CAM:70,Jo\xE3o Rego:CAM:70",
  "SL Benfica|2026": "Vangelis Pavlidis:ST:84,Ant\xF3nio Silva:CB:83,Georgiy Sudakov:CAM:83,Tom\xE1s Ara\xFAjo:CB:83,Anatoliy Trubin:GK:82,Andreas Schjelderup:LW:81,Dodi Luk\xE9bakio:RW:81,Franjo Ivanovi\u0107:ST:80,Fredrik Aursnes:CM:80,Amar Dedi\u0107:RB:79,Leandro Barreiro:CM:79,Samuel Dahl:LB:78,Alexander Bah:RB:77,An\xEDsio Cabral:ST:73,Samuel Soares:GK:72,Jo\xE3o Rego:CAM:70,Jos\xE9 Neto:LB:70",
  "SSC Napoli|2016": "Gonzalo Higua\xEDn:ST:89,Marek Hamsik:CM:85,Kalidou Koulibaly:CB:83,Jos\xE9 Callej\xF3n:RW:82,Lorenzo Insigne:LW:82,Jorginho:CDM:81,Allan:CDM:80,Dries Mertens:CF:80,Manolo Gabbiadini:ST:80,Elseid Hysaj:RB:79,Faouzi Ghoulam:LB:79,Ra\xFAl Albiol:CB:76,David L\xF3pez:CB:75,Ivan Strinic:LB:73,Omar El Kaddouri:CAM:73,Pepe Reina:GK:70,Christian Maggio:RB:64",
  "SSC Napoli|2017": "Lorenzo Insigne:LW:87,Kalidou Koulibaly:CB:85,Marek Hamsik:CM:85,Dries Mertens:CF:84,Jorginho:CDM:83,Faouzi Ghoulam:LB:82,Jos\xE9 Callej\xF3n:RW:82,Piotr Zielinski:CM:82,Allan:CDM:81,Arkadiusz Milik:ST:81,Elseid Hysaj:RB:81,Leonardo Pavoletti:ST:79,Nikola Maksimovi\u0107:CB:78,Marko Rog:CM:77,Lorenzo Tonelli:CB:76,Ra\xFAl Albiol:CB:76,Ivan Strinic:LB:73,Emanuele Giaccherini:LM:70,Luigi Sepe:GK:70,Rafael Cabral:GK:68",
  "SSC Napoli|2018": "Lorenzo Insigne:LW:89,Jorginho:CDM:88,Kalidou Koulibaly:CB:88,Allan:CDM:86,Piotr Zielinski:CM:85,Marek Hamsik:CM:84,Dries Mertens:CF:83,Arkadiusz Milik:ST:82,Elseid Hysaj:RB:82,Faouzi Ghoulam:LB:82,Jos\xE9 Callej\xF3n:RW:82,M\xE1rio Rui:LB:79,Nikola Maksimovi\u0107:CB:78,Lorenzo Tonelli:CB:76,Marko Rog:CM:76,Ra\xFAl Albiol:CB:76,Luigi Sepe:GK:72,Pepe Reina:GK:64",
  "SSC Napoli|2019": "Kalidou Koulibaly:CB:89,Lorenzo Insigne:LW:88,Allan:CDM:87,Fabi\xE1n Ruiz:CM:87,Alex Meret:GK:85,Arkadiusz Milik:ST:85,Piotr Zielinski:CM:85,Dries Mertens:CF:82,Elseid Hysaj:RB:82,Faouzi Ghoulam:LB:82,Marek Hamsik:CM:82,Simone Verdi:CAM:82,Amadou Diawara:CDM:81,Jos\xE9 Callej\xF3n:RW:81,K\xE9vin Malcuit:RB:80,Nikola Maksimovi\u0107:CB:80,M\xE1rio Rui:LB:79,Adam Ounas:RW:77,Amin Younes:LW:76,Sebastiano Luperto:CB:73,David Ospina:GK:72",
  "SSC Napoli|2020": "Kalidou Koulibaly:CB:88,Fabi\xE1n Ruiz:CM:86,Lorenzo Insigne:LW:86,Allan:CDM:85,Hirving Lozano:LW:85,Piotr Zielinski:CM:85,Alex Meret:GK:84,Arkadiusz Milik:ST:84,Konstantinos Manolas:CB:84,Giovanni Di Lorenzo:RB:82,Dries Mertens:CF:81,Stanislav Lobotka:CDM:81,Eljif Elmas:CAM:80,Nikola Maksimovi\u0107:CB:80,Elseid Hysaj:RB:79,M\xE1rio Rui:LB:79,Faouzi Ghoulam:LB:78,Jos\xE9 Callej\xF3n:RW:78,David Ospina:GK:73,Fernando Llorente:ST:72,Sebastiano Luperto:CB:72",
  "SSC Napoli|2021": "Fabi\xE1n Ruiz:CM:87,Victor Osimhen:ST:87,Hirving Lozano:LW:86,Kalidou Koulibaly:CB:86,Lorenzo Insigne:LW:86,Piotr Zielinski:CM:86,Konstantinos Manolas:CB:83,Matteo Politano:RW:83,Amir Rrahmani:CB:82,Eljif Elmas:CAM:82,Giovanni Di Lorenzo:RB:82,Tiemou\xE9 Bakayoko:CDM:82,Alex Meret:GK:81,Diego Demme:CDM:80,Andrea Petagna:ST:79,Elseid Hysaj:RB:79,Dries Mertens:CF:78,Nikola Maksimovi\u0107:CB:78,M\xE1rio Rui:LB:77,David Ospina:GK:73,Faouzi Ghoulam:LB:70",
  "SSC Napoli|2022": "Victor Osimhen:ST:88,Fabi\xE1n Ruiz:CM:87,Frank Anguissa:CM:85,Piotr Zielinski:CM:85,Hirving Lozano:LW:84,Kalidou Koulibaly:CB:84,Stanislav Lobotka:CDM:83,Amir Rrahmani:CB:82,Eljif Elmas:CAM:82,Giovanni Di Lorenzo:RB:82,Lorenzo Insigne:LW:82,Matteo Politano:RW:81,Alex Meret:GK:79,Andrea Petagna:ST:78,Diego Demme:CDM:77,Adam Ounas:RW:76,Axel Tuanzebe:CB:76,M\xE1rio Rui:LB:76,Dries Mertens:CF:72,Juan Jesus:CB:72,K\xE9vin Malcuit:RB:68,Faouzi Ghoulam:LB:64",
  "SSC Napoli|2023": "Victor Osimhen:ST:91,Khvicha Kvaratskhelia:LW:89,Min-jae Kim:CB:87,Frank Anguissa:CM:85,Giacomo Raspadori:CF:84,Piotr Zielinski:CM:84,Eljif Elmas:CAM:83,Amir Rrahmani:CB:82,Giovanni Di Lorenzo:RB:82,Hirving Lozano:LW:82,Tanguy Ndomb\xE9l\xE9:CM:82,Alex Meret:GK:80,Math\xEDas Olivera:LB:80,Giovanni Simeone:ST:79,Matteo Politano:RW:79,Leo \xD8stig\xE5rd:CB:77,M\xE1rio Rui:LB:76,Alessio Zerbin:RM:72",
  "SSC Napoli|2024": "Victor Osimhen:ST:90,Khvicha Kvaratskhelia:LW:89,Frank Anguissa:CM:83,Giacomo Raspadori:CF:83,Jesper Lindstr\xF8m:RW:82,Piotr Zielinski:CM:82,Giovanni Di Lorenzo:RB:80,Hamed Traor\xE9:LW:80,Math\xEDas Olivera:LB:80,Amir Rrahmani:CB:79,Matteo Politano:RW:79,Alex Meret:GK:78,Natan:CB:78,Giovanni Simeone:ST:77,Leo \xD8stig\xE5rd:CB:76,Alessio Zerbin:RM:72,M\xE1rio Rui:LB:72,Pierluigi Gollini:GK:72,Pasquale Mazzocchi:RB:70",
  "SSC Napoli|2025": "Alessandro Buongiorno:CB:86,Scott McTominay:CM:86,David Neres:RW:83,Frank Anguissa:CM:83,Giacomo Raspadori:CF:82,Romelu Lukaku:ST:82,Math\xEDas Olivera:LB:81,Alex Meret:GK:80,Noah Okafor:LW:80,Amir Rrahmani:CB:78,Giovanni Di Lorenzo:RB:78,Cyril Ngonge:RW:77,Giovanni Simeone:ST:76,Alessio Zerbin:RM:72,Pasquale Mazzocchi:RB:70",
  "SSC Napoli|2026": "Rasmus H\xF8jlund:ST:86,Scott McTominay:CM:86,Alessandro Buongiorno:CB:84,David Neres:RW:83,Lorenzo Lucca:ST:82,Noa Lang:LW:82,Sam Beukema:CB:82,Frank Anguissa:CM:81,Vanja Milinkovi\u0107-Savi\u0107:GK:81,Miguel Guti\xE9rrez:LB:80,Alex Meret:GK:79,Alisson Santos:LW:79,Antonio Vergara:CAM:79,Eljif Elmas:CAM:79,Math\xEDas Olivera:LB:79,Romelu Lukaku:ST:78,Giovanni Di Lorenzo:RB:77,Luca Marianucci:CB:76,Pasquale Mazzocchi:RB:68",
  "Sevilla FC|2016": "Grzegorz Krychowiak:CDM:83,K\xE9vin Gameiro:ST:82,Yevgen Konoplyanka:LW:82,\xC9ver Banega:CM:81,Steven Nzonzi:CDM:81,Vitolo:LW:80,Sergio Rico:GK:79,Adil Rami:CB:76,Beno\xEEt Tr\xE9moulinas:LB:76,Daniel Carri\xE7o:CB:76,Federico Fazio:CB:76,Fernando Llorente:ST:76,Mariano:RB:76,Timoth\xE9e Kolodziejczak:CB:76,Coke:RB:72,Ga\xEBl Kakuta:CAM:72,Michael Krohn-Dehli:CM:72,Sergio Escudero:LB:72,Sebasti\xE1n Crist\xF3foro:CM:70,Beto:GK:68,Jos\xE9 Antonio Reyes:RW:68,Curro S\xE1nchez:RW:64",
  "Sevilla FC|2017": "Steven Nzonzi:CDM:83,Vitolo:LW:83,Samir Nasri:CAM:81,Sergio Rico:GK:81,Franco V\xE1zquez:CAM:80,Luciano Vietto:ST:80,Wissam Ben Yedder:ST:79,Joaqu\xEDn Correa:CF:77,Vicente Iborra:CDM:77,Adil Rami:CB:76,Cl\xE9ment Lenglet:CB:76,Mariano:RB:76,Sergio Escudero:LB:76,Gabriel Mercado:CB:74,Walter Montoya:CM:73,Daniel Carri\xE7o:CB:72,Michael Krohn-Dehli:CM:70,David Soria:GK:68",
  "Sevilla FC|2018": "Cl\xE9ment Lenglet:CB:85,Pablo Sarabia:CAM:85,Wissam Ben Yedder:ST:84,Steven Nzonzi:CDM:83,\xC9ver Banega:CM:81,Sergio Rico:GK:81,Franco V\xE1zquez:CAM:79,Guido Pizarro:CDM:79,Joaqu\xEDn Correa:CF:79,Luis Muriel:ST:79,Simon Kjaer:CB:79,David Soria:GK:77,Roque Mesa:CM:77,Sandro Ram\xEDrez:ST:77,S\xE9bastien Corchia:RB:76,Sergio Escudero:LB:76,Jes\xFAs Navas:RM:74,Nolito:LW:74,Gabriel Mercado:CB:73,Guilherme Arana:LB:73,Daniel Carri\xE7o:CB:70",
  "Sevilla FC|2019": "Pablo Sarabia:CAM:85,Wissam Ben Yedder:ST:85,Andr\xE9 Silva:ST:82,Quincy Promes:LW:82,Tom\xE1\u0161 Vacl\xEDk:GK:80,\xC9ver Banega:CM:79,Franco V\xE1zquez:CAM:79,Marko Rog:CM:79,Bryan Gil:LW:77,Maximilian W\xF6ber:CB:77,Sergi G\xF3mez:CB:77,Ibrahim Amadou:CDM:76,Roque Mesa:CM:76,Sergio Escudero:LB:76,Simon Kjaer:CB:76,Joris Gnagnon:CB:74,Aleix Vidal:RW:73,Jes\xFAs Navas:RM:72,Maxime Gonalons:CDM:72,Juan Soriano:GK:70",
  "Sevilla FC|2020": "Diego Carlos:CB:86,Lucas Ocampos:LW:86,Jules Kound\xE9:RB:85,Sergio Reguil\xF3n:LB:83,Suso:CAM:82,Joan Jord\xE1n:CM:81,\xD3liver Torres:CM:79,Tom\xE1\u0161 Vacl\xEDk:GK:79,Yassine Bounou:GK:79,Youssef En-Nesyri:ST:79,Luuk de Jong:ST:78,\xC9ver Banega:CM:77,Fernando:CDM:77,Franco V\xE1zquez:CAM:77,Rony Lopes:RW:77,Chicharito:ST:76,Nemanja Gudelj:CDM:74,Sergio Escudero:LB:73,Sergi G\xF3mez:CB:72,Jes\xFAs Navas:RM:70,Nolito:LW:68",
  "Sevilla FC|2021": "Jules Kound\xE9:RB:87,Diego Carlos:CB:86,Lucas Ocampos:LW:86,Youssef En-Nesyri:ST:85,Joan Jord\xE1n:CM:83,Suso:CAM:81,Marcos Acu\xF1a:LB:80,Yassine Bounou:GK:80,\xD3liver Torres:CM:79,Luuk de Jong:ST:78,\xD3scar Rodr\xEDguez:CAM:78,Ivan Rakitic:CM:77,Papu G\xF3mez:LW:77,Tom\xE1\u0161 Vacl\xEDk:GK:76,Nemanja Gudelj:CDM:74,Karim Rekik:CB:72,Sergi G\xF3mez:CB:72,Jes\xFAs Navas:RM:70,Aleix Vidal:RW:68",
  "Sevilla FC|2022": "Jules Kound\xE9:RB:87,Diego Carlos:CB:85,Youssef En-Nesyri:ST:84,Joan Jord\xE1n:CM:82,Lucas Ocampos:LW:82,Erik Lamela:RW:80,Jes\xFAs Corona:RW:80,Marcos Acu\xF1a:LB:80,Rafa Mir:ST:80,Yassine Bounou:GK:80,Gonzalo Montiel:RB:79,\xD3liver Torres:CM:77,\xD3scar Rodr\xEDguez:CAM:77,Suso:CAM:77,Ivan Rakitic:CM:76,Thomas Delaney:CM:76,Papu G\xF3mez:LW:74,Marko Dmitrovic:GK:73,Nemanja Gudelj:CDM:72,Jes\xFAs Navas:RM:70",
  "Sevilla FC|2023": "Youssef En-Nesyri:ST:81,Alex Telles:LB:78,Gonzalo Montiel:RB:78,Joan Jord\xE1n:CM:78,Lo\xEFc Bad\xE9:CB:78,Lucas Ocampos:LW:78,Marcos Acu\xF1a:LB:78,Yassine Bounou:GK:78,Erik Lamela:RW:77,Jes\xFAs Corona:RW:77,Marc\xE3o:CB:77,\xD3liver Torres:CM:77,Rafa Mir:ST:77,Tanguy Nianzou:CB:76,Suso:CAM:74,Ivan Rakitic:CM:72,Karim Rekik:CB:72,Marko Dmitrovic:GK:72,Jes\xFAs Navas:RM:70,Papu G\xF3mez:LW:70",
  "Sevilla FC|2025": "Lo\xEFc Bad\xE9:CB:83,Dodi Luk\xE9bakio:RW:82,Juanlu S\xE1nchez:RB:79,Jos\xE9 \xC1ngel Carmona:RB:78,Albert Sambi Lokonga:CM:77,Isaac Romero:ST:77,Djibril Sow:CM:76,Kike Salas:CB:76,Odysseas Vlachodimos:GK:73,Stanis Idumbo:CAM:73,Chidera Ejuke:LW:72,Peque Fern\xE1ndez:CF:72,\xC1lvaro Fern\xE1ndez:GK:68,Oso:LB:68",
  "Shakhtar Donetsk|2017": "Bernard:LW:79,Taison:LW:78,Fred:CM:77,Marlos:RW:77,Yaroslav Rakitskyi:CB:77,Taras Stepanenko:CDM:76,Viktor Kovalenko:CM:74,Andriy Pyatov:GK:72,Facundo Ferreyra:ST:72,Ismaily:LB:72,Darijo Srna:RB:70,Dentinho:ST:70,Ivan Ordets:CB:70,Maksym Malyshev:CDM:70,Alan Patrick:CAM:68,Anton Kanibolotskyi:GK:68,Bogdan Butko:RB:68,M\xE1rcio Azevedo:LB:68",
  "Shakhtar Donetsk|2018": "Fred:CM:86,Bernard:LW:80,Ismaily:LB:80,Taison:LW:79,Marlos:RW:78,Taras Stepanenko:CDM:77,Facundo Ferreyra:ST:76,Yaroslav Rakitskyi:CB:76,Viktor Kovalenko:CM:73,Alan Patrick:CAM:72,Ivan Ordets:CB:72,Andriy Pyatov:GK:70,Davit Khocholava:CB:70,Maksym Malyshev:CDM:70,Mykola Matvienko:CB:70,Olarenwaju Kayode:ST:70,Bogdan Butko:RB:68,Dod\xF4:RB:68,Wellington Nem:RW:68,Marquinhos Cipriano:LB:64",
  "Shakhtar Donetsk|2019": "Ismaily:LB:81,Tet\xEA:RW:79,Marlos:RW:78,Taison:LW:78,Taras Stepanenko:CDM:77,Maycon:CM:76,Marcos Ant\xF4nio:CM:74,Viktor Kovalenko:CM:74,J\xFAnior Moraes:ST:73,Alan Patrick:CAM:72,Sergiy Kryvtsov:CB:72,Andriy Pyatov:GK:70,Bogdan Butko:RB:68,Marquinhos Cipriano:LB:64,Oleksiy Shevchenko:GK:64",
  "Shakhtar Donetsk|2020": "Ismaily:LB:81,Tet\xEA:RW:80,Taison:LW:78,Dod\xF4:RB:77,Marlos:RW:77,Taras Stepanenko:CDM:77,Manor Solomon:LW:76,Maycon:CM:74,Viktor Kovalenko:CM:74,J\xFAnior Moraes:ST:73,Marcos Ant\xF4nio:CM:73,Sergiy Kryvtsov:CB:73,Davit Khocholava:CB:72,Vit\xE3o:CB:72,Andriy Pyatov:GK:68,Marquinhos Cipriano:LB:68,Anatoliy Trubin:GK:64",
  "Shakhtar Donetsk|2021": "Dod\xF4:RB:81,Manor Solomon:LW:81,Tet\xEA:RW:81,Mykola Matvienko:CB:78,Alan Patrick:CAM:76,Anatoliy Trubin:GK:76,Ismaily:LB:76,Marcos Ant\xF4nio:CM:76,Marlos:RW:76,Maycon:CM:76,Taison:LW:76,Taras Stepanenko:CDM:76,Sergiy Kryvtsov:CB:73,Davit Khocholava:CB:72,Valeriy Bondar:CB:72,Viktor Korniyenko:LB:70,Andriy Pyatov:GK:64",
  "Shakhtar Donetsk|2023": "Anatoliy Trubin:GK:82,Mykola Matvienko:CB:81,Georgiy Sudakov:CAM:80,Artem Bondarenko:CAM:77,Lassina Traor\xE9:ST:76,Danylo Sikan:ST:74,Dmytro Riznyk:GK:73,Oleksandr Zubkov:RW:73,Bogdan Mykhaylichenko:LB:72,Dmytro Kryskiv:CM:72,Yukhym Konoplya:RB:72,Giorgi Gocholeishvili:RB:70,Newerton:LW:70",
  "Shakhtar Donetsk|2024": "Georgiy Sudakov:CAM:84,Mykola Matvienko:CB:80,Kevin:LW:78,Marlon Gomes:CM:78,Artem Bondarenko:CAM:77,Danylo Sikan:ST:76,Dmytro Kryskiv:CM:76,Dmytro Riznyk:GK:76,Yukhym Konoplya:RB:76,Valeriy Bondar:CB:74,Irakli Azarovi:LB:73,Lassina Traor\xE9:ST:73,Eguinaldo:LW:70,Giorgi Gocholeishvili:RB:70,Pedro Henrique:LB:70,Kiril Fesyun:GK:68",
  "Shakhtar Donetsk|2025": "Georgiy Sudakov:CAM:84,Kevin:LW:83,Mykola Matvienko:CB:80,Kau\xE3 Elias:ST:79,Artem Bondarenko:CAM:77,Marlon Gomes:CM:77,Dmytro Kryskiv:CM:76,Dmytro Riznyk:GK:76,Pedrinho:RW:76,Valeriy Bondar:CB:76,Newerton:LW:74,Pedro Henrique:LB:74,Vin\xEDcius Tobias:RB:74,Yukhym Konoplya:RB:73,Irakli Azarovi:LB:72,Lassina Traor\xE9:ST:72,Kiril Fesyun:GK:68",
  "Shakhtar Donetsk|2026": "Kau\xE3 Elias:ST:79,Mykola Matvienko:CB:79,Marlon Gomes:CM:78,Luca Meirelles:ST:77,Pedrinho:RW:77,Artem Bondarenko:CAM:76,Dmytro Riznyk:GK:76,Isaque:CAM:76,Lucas Ferreira:RW:76,Valeriy Bondar:CB:76,Newerton:LW:74,Pedro Henrique:LB:74,Vin\xEDcius Tobias:RB:74,Dmytro Kryskiv:CM:73,Eguinaldo:LW:73,Lassina Traor\xE9:ST:73,Irakli Azarovi:LB:70,Kiril Fesyun:GK:68",
  "Sociedade Esportiva Palmeiras|2018": "Gustavo Scarpa:CAM:77,Dudu:LW:76,Lucas Lima:CAM:76,Keno:LW:73,Miguel Borja:ST:73,Tch\xEA Tch\xEA:CM:73,Deyverson:ST:72,Diogo Barbosa:LB:72,Gustavo G\xF3mez:CB:72,Marcos Rocha:RB:72,Mois\xE9s:CM:72,Jean:CDM:70,Weverton:GK:70,Willian Bigode:CF:70,Victor Lu\xEDs:LB:68,Mayke:RB:64",
  "Sociedade Esportiva Palmeiras|2020": "Gabriel Veron:RW:82,Gabriel Menino:CM:77,Patrick de Paula:CDM:77,Gustavo Scarpa:CAM:75,Gustavo G\xF3mez:CB:73,Ramires:CM:73,Rony:ST:73,Vitor Hugo:CB:73,Diogo Barbosa:LB:72,Luiz Adriano:ST:72,Mat\xEDas Vi\xF1a:LB:72,Weverton:GK:72,Z\xE9 Rafael:CM:72,Wesley:LW:70,Marcos Rocha:RB:68,Raphael Veiga:CAM:68,Willian Bigode:CF:68,Mayke:RB:64",
  "Sociedade Esportiva Palmeiras|2021": "Gabriel Veron:RW:82,Patrick de Paula:CDM:80,Gabriel Menino:CM:79,Raphael Veiga:CAM:77,Renan:CB:77,Rony:ST:77,Gustavo G\xF3mez:CB:76,Wesley:LW:76,Danilo Barbosa:CDM:75,Giovani:RW:74,Weverton:GK:74,Z\xE9 Rafael:CM:73,Breno Lopes:LW:70,Jorge:LB:70,Marcos Rocha:RB:68,Willian Bigode:CF:68,Mayke:RB:64",
  "Sociedade Esportiva Palmeiras|2023": "Endrick:ST:86,Raphael Veiga:CAM:80,Joaqu\xEDn Piquerez:LB:79,Rony:ST:79,Gustavo G\xF3mez:CB:77,Murilo:CB:77,Jos\xE9 Manuel L\xF3pez:ST:76,Jhon Jhon:CAM:72,Kevin:LW:72,Vanderlan:LB:72,Bruno Tabata:RW:70,Eduard Atuesta:CM:70,Mayke:RB:70,Weverton:GK:70,Breno Lopes:LW:68,Garcia:RB:68",
  "Sociedade Esportiva Palmeiras|2024": "Endrick:ST:87,Est\xEAv\xE3o:RW:86,Lu\xEDs Guilherme:RW:82,Raphael Veiga:CAM:80,Joaqu\xEDn Piquerez:LB:79,Vitor Reis:CB:79,Gabriel Menino:CM:77,Jos\xE9 Manuel L\xF3pez:ST:77,Murilo:CB:77,Rony:ST:77,Dudu:LW:76,Gustavo G\xF3mez:CB:76,Jhon Jhon:CAM:73,Z\xE9 Rafael:CM:73,Bruno Rodrigues:LW:72,Caio Paulista:LB:72,Mayke:RB:70,Garcia:RB:68,Weverton:GK:68",
  "Sociedade Esportiva Palmeiras|2025": "Est\xEAv\xE3o:RW:89,Jos\xE9 Manuel L\xF3pez:ST:81,Paulinho:CF:80,Facundo Torres:RW:79,Joaqu\xEDn Piquerez:LB:79,Raphael Veiga:CAM:79,Agust\xEDn Giay:RB:78,Mauricio:CAM:78,Murilo:CB:76,Rony:ST:75,Bruno Fuchs:CB:73,Gustavo G\xF3mez:CB:73,Luighi:ST:73,Micael:CB:73,Eduard Atuesta:CM:72,Lucas Evangelista:CM:72,Vanderlan:LB:72,Mayke:RB:70,Weverton:GK:68",
  "Sociedade Esportiva Palmeiras|2026": "Vitor Roque:ST:85,Jos\xE9 Manuel L\xF3pez:ST:82,Andreas Pereira:CM:79,Mauricio:CAM:79,Agust\xEDn Giay:RB:77,Raphael Veiga:CAM:76,Khellven:RB:74,Carlos Miguel:GK:73,Luighi:ST:73,Murilo:CB:73,Jeft\xE9:LB:72,Lucas Evangelista:CM:72,Luis Benedetti:CB:72,Felipe Anderson:LW:68",
  "Sport Club Corinthians Paulista|2016": "Elias:CM:76,C\xE1ssio:GK:73,Giovanni Augusto:CAM:73,Andr\xE9 Felipe:ST:72,Fagner:RB:72,Luciano:ST:72,Marlone:CAM:70,Uendel:LB:70,Willians:CDM:70,\xC1ngel Romero:RW:68,Ed\xEDlson:RB:68,Guilherme Arana:LB:64",
  "Sport Club Corinthians Paulista|2018": "Fagner:RB:76,Maycon:CM:76,Fabi\xE1n Balbuena:CB:74,Rodriguinho:CAM:74,Pedrinho:RW:73,Sidcley:LB:73,C\xE1ssio:GK:72,Gabriel:CDM:72,\xC1ngel Romero:RW:70,Clayson:LW:70,Lucca:LW:70,Mateus Vital:CM:70,J\xE1dson:CAM:68,Juninho Capixaba:LB:64,Sergio D\xEDaz:CF:64,Walter:GK:64",
  "Sport Club Corinthians Paulista|2019": "Pedrinho:RW:79,Fagner:RB:74,L\xE9o Santos:CB:74,Clayson:LW:73,J\xFAnior Sornoza:CAM:73,C\xE1ssio:GK:72,Mateus Vital:CM:72,J\xE1dson:CAM:68,J\xFAnior Urso:CM:68,Michel Macedo:RB:68,Richard:CDM:68,Carlos Augusto:LB:64,Sergio D\xEDaz:CF:64",
  "Sport Club Corinthians Paulista|2020": "Pedrinho:RW:80,Luan:CAM:75,\xC9derson:CM:74,Lucas Piton:LB:74,Fagner:RB:72,Gil:CB:72,Sidcley:LB:72,V\xEDctor Cantillo:CDM:72,C\xE1ssio:GK:70,Janderson:RW:70,J\xF4:ST:70,Mateus Vital:CM:70,Ramiro:CM:70,L\xE9o Natel:LW:64,Michel Macedo:RB:64",
  "Sport Club Corinthians Paulista|2022": "Jo\xE3o Victor:CB:76,Maycon:CM:76,R\xF3ger Guedes:CF:76,Lucas Piton:LB:74,Willian:LW:74,Adson:RW:73,Du Queiroz:CM:73,Gabriel Pereira:RW:73,Raul Gustavo:CB:72,Renato Augusto:CM:72,Roni:CDM:72,Fagner:RB:70,Giuliano:CAM:70,Gustavo Mantuan:RB:70,Ivan:GK:70,Matheus Donelli:GK:70",
  "Sport Club Corinthians Paulista|2024": "Rodrigo Garro:CAM:79,Yuri Alberto:ST:79,Wesley:LW:77,Breno Bidon:CM:76,F\xE9lix Torres:CB:74,Matheuzinho:RB:74,Igor Coronado:CAM:73,Maycon:CM:73,Carlos Miguel:GK:72,Giovane:ST:72,Pedro Raul:ST:72,Raul Gustavo:CB:72,Matheus Bidu:LB:70,Hugo:LB:68,Matheus Donelli:GK:68",
  "Sport Club Corinthians Paulista|2026": "Breno Bidon:CM:82,Yuri Alberto:ST:82,Andr\xE9:CM:80,Hugo Souza:GK:78,Rodrigo Garro:CAM:78,Gui Neg\xE3o:ST:76,Matheuzinho:RB:76,Matheus Bidu:LB:74,Dieguinho:RW:72,Tchoca:CB:72,Jesse Lingard:CAM:68,Matheus Donelli:GK:68,Pedro Milans:RB:68",
  "Sporting CP|2016": "Jo\xE3o M\xE1rio:CAM:84,William Carvalho:CDM:83,Adrien Silva:CM:82,Islam Slimani:ST:82,Rui Patr\xEDcio:GK:80,Gelson Martins:RW:78,Bryan Ruiz:CAM:76,Fredy Montero:ST:76,Jefferson:LB:76,Paulo Oliveira:CB:76,Carlos Man\xE9:RW:74,Naldo:CB:73,Alberto Aquilani:CM:72,Bruno C\xE9sar:CM:72,Ezequiel Schelotto:RM:72,Hern\xE1n Barcos:ST:72,Ricardo Esgaio:RB:72,Ewerton:CB:70,Bruno Paulista:CDM:68,Marcelo Boeck:GK:64",
  "Sporting CP|2017": "William Carvalho:CDM:83,Adrien Silva:CM:82,Gelson Martins:RW:81,Bas Dost:ST:80,Rui Patr\xEDcio:GK:80,R\xFAben Semedo:CB:79,Alan Ruiz:CAM:76,Joel Campbell:CF:76,Sebasti\xE1n Coates:CB:76,Bryan Ruiz:CAM:75,Jefferson:LB:74,Bruno C\xE9sar:CM:73,Ezequiel Schelotto:RM:73,Andr\xE9 Felipe:ST:72,Marvin Zeegelaar:LB:72,Paulo Oliveira:CB:72,Elias:CM:70,Luc Castaignos:ST:70,Ricardo Esgaio:RB:70,Andr\xE9 Geraldes:RB:64,Beto:GK:64",
  "Sporting CP|2018": "Gelson Martins:RW:84,Bruno Fernandes:CAM:83,Bas Dost:ST:82,William Carvalho:CDM:82,Rui Patr\xEDcio:GK:80,Marcos Acu\xF1a:LB:79,Rodrigo Battaglia:CDM:77,Sebasti\xE1n Coates:CB:77,Cristiano Piccini:CB:76,Wendel:CM:75,F\xE1bio Coentr\xE3o:LB:74,Rafael Le\xE3o:LW:74,Daniel Podence:LW:73,Iuri Medeiros:RW:73,Seydou Doumbia:ST:73,Bruno C\xE9sar:CM:72,Stefan Ristovski:RB:72,Andr\xE9 Pinto:CB:70,Fredy Montero:ST:70,Bryan Ruiz:CAM:68",
  "Sporting CP|2019": "Bruno Fernandes:CAM:87,Bas Dost:ST:82,Marcos Acu\xF1a:LB:80,Raphinha:LW:80,Sebasti\xE1n Coates:CB:79,Rodrigo Battaglia:CDM:77,Wendel:CM:77,Jovane Cabral:LW:76,Luiz Phellype:ST:76,Nemanja Gudelj:CDM:76,Abdoulay Diaby:RW:74,Cristi\xE1n Borja:LB:72,Renan Ribeiro:GK:72,Stefan Ristovski:RB:72,Miguel Lu\xEDs:CAM:70,Lu\xEDs Maximiano:GK:68,Gonzalo Plata:RW:64",
  "Sporting CP|2020": "Bruno Fernandes:CAM:90,Wendel:CM:79,Marcos Acu\xF1a:LB:78,Nuno Mendes:LB:78,Jovane Cabral:LW:77,Luciano Vietto:ST:76,Luiz Phellype:ST:75,Andraz Sporar:ST:74,Joelson Fernandes:LW:74,Lu\xEDs Maximiano:GK:74,Rodrigo Battaglia:CDM:74,Valentin Rosier:RB:73,Gonzalo Plata:RW:72,Rafael Camacho:RW:72,Stefan Ristovski:RB:72,Eduardo Henrique:CDM:70,Miguel Lu\xEDs:CAM:70",
  "Sporting CP|2021": "Nuno Mendes:LB:85,Pedro Gon\xE7alves:LW:85,Jo\xE3o Palhinha:CDM:83,Pedro Porro:RB:82,Gon\xE7alo In\xE1cio:CB:80,Jo\xE3o M\xE1rio:CAM:79,Paulinho:ST:79,Sebasti\xE1n Coates:CB:79,Jovane Cabral:LW:77,Daniel Bragan\xE7a:CM:76,Lu\xEDs Maximiano:GK:76,Nuno Santos:LB:76,Andraz Sporar:ST:74,Eduardo Quaresma:CB:74,Tiago Tom\xE1s:RW:74,Zouhair Feddal:CB:74,Gonzalo Plata:RW:73,Antonio Ad\xE1n:GK:70,Gon\xE7alo Esteves:RB:70",
  "Sporting CP|2023": "Gon\xE7alo In\xE1cio:CB:85,Ousmane Diomande:CB:85,Pedro Gon\xE7alves:LW:84,Francisco Trinc\xE3o:CAM:79,Jeremiah St. Juste:CB:79,Nuno Santos:LB:79,Hidemasa Morita:CM:78,Youssef Chermiti:ST:77,Abdul Fatawu:RW:76,H\xE9ctor Beller\xEDn:RB:76,Matheus Reis:LB:76,Daniel Bragan\xE7a:CM:73,Sebasti\xE1n Coates:CB:73,Jovane Cabral:LW:72,Ricardo Esgaio:RB:72,Franco Israel:GK:70,Sotiris Alexandropoulos:CM:70,Antonio Ad\xE1n:GK:68",
  "Sporting CP|2024": "Viktor Gy\xF6keres:ST:89,Gon\xE7alo In\xE1cio:CB:86,Ousmane Diomande:CB:85,Pedro Gon\xE7alves:LW:84,Francisco Trinc\xE3o:CAM:83,Geovany Quenda:RW:83,Marcus Edwards:RW:82,Daniel Bragan\xE7a:CM:79,Eduardo Quaresma:CB:79,Hidemasa Morita:CM:79,Nuno Santos:LB:79,Iv\xE1n Fresneda:RB:78,Franco Israel:GK:76,Jeremiah St. Juste:CB:76,Matheus Reis:LB:76,R\xFAben Vinagre:LM:73,Ricardo Esgaio:RB:70,Jo\xE3o Virg\xEDnia:GK:64",
  "Sporting CP|2025": "Viktor Gy\xF6keres:ST:89,Geovany Quenda:RW:86,Gon\xE7alo In\xE1cio:CB:86,Ousmane Diomande:CB:86,Francisco Trinc\xE3o:CAM:84,Pedro Gon\xE7alves:LW:83,Zeno Debast:CB:83,Conrad Harder:ST:82,Maxi Ara\xFAjo:LB:82,Eduardo Quaresma:CB:80,Geny Catamo:RW:79,Hidemasa Morita:CM:79,Jo\xE3o Sim\xF5es:CM:79,Daniel Bragan\xE7a:CM:78,Iv\xE1n Fresneda:RB:78,Nuno Santos:LB:77,Rui Silva:GK:76,Franco Israel:GK:74,Afonso Moreira:LW:73,Salvador Blopa:RB:70",
  "Sporting CP|2026": "Ousmane Diomande:CB:86,Geovany Quenda:RW:85,Gon\xE7alo In\xE1cio:CB:85,Francisco Trinc\xE3o:CAM:84,Luis Su\xE1rez:ST:83,Pedro Gon\xE7alves:LW:83,Zeno Debast:CB:83,Maxi Ara\xFAjo:LB:82,Geny Catamo:RW:81,Fotis Ioannidis:ST:80,Eduardo Quaresma:CB:79,Jo\xE3o Sim\xF5es:CM:79,Georgios Vagiannidis:RB:78,Iv\xE1n Fresneda:RB:78,Daniel Bragan\xE7a:CM:77,Hidemasa Morita:CM:77,Rui Silva:GK:76,Giorgi Kochorashvili:CM:73,Nuno Santos:LB:73,Jo\xE3o Virg\xEDnia:GK:64",
  "S\xE3o Paulo Futebol Clube|2016": "Ganso:CAM:77,Jonathan Calleri:ST:77,Rodrigo Caio:CB:77,Alan Kardec:ST:73,Michel Bastos:LM:72,Thiago Mendes:CDM:72,Carlinhos:LB:70,Eugenio Mena:LB:70,Kelvin Oliveira:RW:70,Wellington:CDM:70,Bruno:RB:68,Denis:GK:68,Rog\xE9rio:RW:68,Wesley:CM:68",
  "S\xE3o Paulo Futebol Clube|2017": "Maicon:CB:76,Rodrigo Caio:CB:76,Luiz Ara\xFAjo:RW:74,Lucas Pratto:ST:73,Andr\xE9s Ch\xE1vez:ST:72,Douglas:CB:72,Jucilei:CDM:72,Christian Cueva:CAM:70,C\xEDcero:CM:70,\xC9der Milit\xE3o:CB:68,Julio Buffarini:RB:68,Neilton:LW:68,Wellington:CDM:68,Bruno:RB:64,Edimar:LB:64,Sid\xE3o:GK:64",
  "S\xE3o Paulo Futebol Clube|2020": "Antony:RW:80,Igor Gomes:CAM:75,Alexandre Pato:ST:73,Tch\xEA Tch\xEA:CM:73,Gabriel Sara:CM:72,Igor Vin\xEDcius:RB:72,Jonas Tor\xF3:LW:72,Pablo:ST:72,Tiago Volpi:GK:72,Reinaldo:LB:70,Dani Alves:RB:68,\xC9verton:RW:68,Juanfran Torres:RB:68,Liziero:CM:68,Hernanes:CAM:64,Paulinho B\xF3ia:LW:64",
  "S\xE3o Paulo Futebol Clube|2021": "Brenner:ST:77,Igor Gomes:CAM:76,Gabriel Sara:CM:75,Luan:CDM:73,Rodrigo Nestor:CM:73,Liziero:CM:72,Luciano:ST:72,Tch\xEA Tch\xEA:CM:72,Tiago Volpi:GK:72,Igor Vin\xEDcius:RB:70,Reinaldo:LB:70,Dani Alves:RB:68,Jonas Tor\xF3:LW:68,Vitor Bueno:CAM:68,Welington:LB:68,Antonio Galeano:RW:64,Lucas Perri:GK:64,Paulinho B\xF3ia:LW:64",
  "S\xE3o Paulo Futebol Clube|2022": "Igor Gomes:CAM:76,Rodrigo Nestor:CM:76,Gabriel Sara:CM:75,Jonathan Calleri:ST:73,Luan:CDM:73,Emiliano Rigoni:RW:72,Luciano:ST:72,Nik\xE3o:CAM:72,Patrick:CM:72,Tiago Volpi:GK:70,Welington:LB:70,Jo\xE3o Moreira:RB:68,Jonas Tor\xF3:LW:68,Reinaldo:LB:68,Jandrei:GK:64,Patryck:LB:64",
  "S\xE3o Paulo Futebol Clube|2024": "Rodrigo Nestor:CM:77,Diego Costa:CB:76,Giuliano Galoppo:CM:76,Ferreirinha:LW:74,William Gomes:RW:74,James Rodr\xEDguez:CAM:73,Lucas Moura:RW:73,Welington:LB:72,Igor Vin\xEDcius:RB:70,Jo\xE3o Moreira:RB:70,Jonathan Calleri:ST:70,Carlos Coronel:GK:68,Patryck:LB:68",
  "Tigres UANL|2016": "Andr\xE9-Pierre Gignac:ST:76,Lucas Zelaray\xE1n:CAM:74,Guido Pizarro:CDM:72,Javier Aquino:RB:72,J\xFCrgen Damm:RW:72,Hugo Ayala:CB:70,Jes\xFAs Due\xF1as:CDM:70,Nahuel Guzm\xE1n:GK:70,Rafael S\xF3bis:ST:70,Israel Jim\xE9nez:RB:68,Dami\xE1n \xC1lvarez:LW:64,Enrique Palos:GK:64,Fernando Fern\xE1ndez:CF:64,Jorge Iv\xE1n Estrada:RB:64",
  "Tigres UANL|2017": "Andr\xE9-Pierre Gignac:ST:74,Eduardo Vargas:ST:74,Guido Pizarro:CDM:74,Javier Aquino:RB:73,Ismael Sosa:ST:72,J\xFCrgen Damm:RW:72,Lucas Zelaray\xE1n:CAM:72,Hugo Ayala:CB:70,Jes\xFAs Due\xF1as:CDM:70,Jorge Torres Nilo:LB:70,Nahuel Guzm\xE1n:GK:70,Israel Jim\xE9nez:RB:68,Alberto Acosta:LB:64,Luis Qui\xF1\xF3nes:RW:64",
  "Tigres UANL|2018": "Enner Valencia:ST:74,Timoth\xE9e Kolodziejczak:CB:74,Javier Aquino:RB:73,Lucas Zelaray\xE1n:CAM:73,Rafael Carioca:CDM:73,Andr\xE9-Pierre Gignac:ST:72,Ismael Sosa:ST:72,Jes\xFAs Due\xF1as:CDM:72,J\xFCrgen Damm:RW:72,Luis Rodr\xEDguez:RB:70,Nahuel Guzm\xE1n:GK:70,Jorge Torres Nilo:LB:68",
  "Tigres UANL|2019": "Carlos Salcedo:CB:77,Guido Pizarro:CDM:76,Eduardo Vargas:ST:73,Enner Valencia:ST:73,Javier Aquino:RB:73,Luis Qui\xF1\xF3nes:RW:73,Andr\xE9-Pierre Gignac:ST:72,Jes\xFAs Due\xF1as:CDM:72,Lucas Zelaray\xE1n:CAM:72,Luis Rodr\xEDguez:RB:72,J\xFCrgen Damm:RW:70,Nahuel Guzm\xE1n:GK:70,Jorge Torres Nilo:LB:68,Francisco Venegas:LB:64",
  "Tottenham Hotspur|2016": "Harry Kane:ST:85,Christian Eriksen:CAM:84,Erik Lamela:RW:83,Toby Alderweireld:CB:83,Heung-min Son:LW:82,Hugo Lloris:GK:82,Jan Vertonghen:CB:82,Dele Alli:CAM:81,Eric Dier:CB:80,Mousa Demb\xE9l\xE9:CM:80,Danny Rose:LB:79,Kyle Walker:RB:79,Nacer Chadli:LW:79,Ben Davies:CB:77,Clinton N'Jie:RW:77,Nabil Bentaleb:CDM:77,Ryan Mason:CM:76,Kieran Trippier:RB:74,Michel Vorm:GK:73,Tom Carroll:CM:73,Josh Onomah:CM:68",
  "Tottenham Hotspur|2017": "Harry Kane:ST:89,Dele Alli:CAM:87,Christian Eriksen:CAM:86,Kyle Walker:RB:84,Toby Alderweireld:CB:84,Danny Rose:LB:83,Eric Dier:CB:83,Erik Lamela:RW:83,Heung-min Son:LW:83,Jan Vertonghen:CB:83,Hugo Lloris:GK:82,Victor Wanyama:CDM:82,Moussa Sissoko:CM:81,Mousa Demb\xE9l\xE9:CM:80,Ben Davies:CB:79,Vincent Janssen:ST:79,Kieran Trippier:RB:78,Georges-Kevin N'Koudou:LW:76,Harry Winks:CDM:73,Michel Vorm:GK:73,Josh Onomah:CM:70",
  "Tottenham Hotspur|2018": "Harry Kane:ST:92,Dele Alli:CAM:90,Christian Eriksen:CAM:89,Heung-min Son:LW:86,Davinson S\xE1nchez:CB:85,Eric Dier:CB:85,Toby Alderweireld:CB:85,Jan Vertonghen:CB:84,Kieran Trippier:RB:84,Lucas Moura:RW:84,Danny Rose:LB:83,Hugo Lloris:GK:83,Victor Wanyama:CDM:83,Erik Lamela:RW:82,Moussa Sissoko:CM:81,Serge Aurier:RB:81,Mousa Demb\xE9l\xE9:CM:80,Harry Winks:CDM:79,Fernando Llorente:ST:76,Michel Vorm:GK:70",
  "Tottenham Hotspur|2019": "Harry Kane:ST:92,Christian Eriksen:CAM:90,Dele Alli:CAM:90,Heung-min Son:LW:89,Davinson S\xE1nchez:CB:87,Eric Dier:CB:85,Harry Winks:CDM:85,Lucas Moura:RW:85,Toby Alderweireld:CB:85,Jan Vertonghen:CB:83,Danny Rose:LB:82,Erik Lamela:RW:82,Hugo Lloris:GK:82,Moussa Sissoko:CM:82,Victor Wanyama:CDM:81,Kyle Walker-Peters:RB:77,Vincent Janssen:ST:76,Fernando Llorente:ST:73,Paulo Gazzaniga:GK:72",
  "Tottenham Hotspur|2020": "Harry Kane:ST:91,Heung-min Son:LW:90,Christian Eriksen:CAM:89,Dele Alli:CAM:89,Davinson S\xE1nchez:CB:86,Tanguy Ndomb\xE9l\xE9:CM:86,Harry Winks:CDM:84,Lucas Moura:RW:84,Ryan Sessegnon:LB:84,Toby Alderweireld:CB:83,Eric Dier:CB:82,Erik Lamela:RW:81,Moussa Sissoko:CM:81,Serge Aurier:RB:81,Ben Davies:CB:80,Hugo Lloris:GK:79,Oliver Skipp:CDM:76,Paulo Gazzaniga:GK:72,Troy Parrott:ST:72",
  "Tottenham Hotspur|2021": "Harry Kane:ST:91,Heung-min Son:LW:89,Tanguy Ndomb\xE9l\xE9:CM:86,Pierre-Emile H\xF8jbjerg:CDM:85,Davinson S\xE1nchez:CB:84,Dele Alli:CAM:84,Giovani Lo Celso:CAM:83,Sergio Reguil\xF3n:LB:83,Eric Dier:CB:82,Harry Winks:CDM:82,Lucas Moura:RW:82,Steven Bergwijn:LW:82,Carlos Vin\xEDcius:ST:81,Erik Lamela:RW:81,Serge Aurier:RB:81,Ben Davies:CB:80,Matt Doherty:RB:80,Japhet Tanganga:CB:79,Moussa Sissoko:CM:79,Hugo Lloris:GK:77,Joe Hart:GK:68",
  "Tottenham Hotspur|2022": "Harry Kane:ST:90,Heung-min Son:LW:89,Cristian Romero:CB:87,Dejan Kulusevski:CAM:86,Pierre-Emile H\xF8jbjerg:CDM:86,Rodrigo Bentancur:CDM:85,Davinson S\xE1nchez:CB:83,Emerson Royal:RB:83,Eric Dier:CB:83,Steven Bergwijn:LW:83,Giovani Lo Celso:CAM:82,Ryan Sessegnon:LB:82,Sergio Reguil\xF3n:LB:82,Ben Davies:CB:81,Lucas Moura:RW:81,Matt Doherty:RB:78,Pierluigi Gollini:GK:77,Hugo Lloris:GK:76",
  "Tottenham Hotspur|2023": "Harry Kane:ST:91,Cristian Romero:CB:88,Dejan Kulusevski:CAM:87,Heung-min Son:LW:87,Pedro Porro:RB:86,Richarlison:ST:86,Pape Matar Sarr:CM:84,Arnaut Danjuma:LW:83,Emerson Royal:RB:82,Eric Dier:CB:82,Davinson S\xE1nchez:CB:81,Ryan Sessegnon:LB:80,Ben Davies:CB:79,Djed Spence:LB:77,Lucas Moura:RW:77,Hugo Lloris:GK:72,Fraser Forster:GK:68,Jamie Donley:CAM:68",
  "Tottenham Hotspur|2024": "Cristian Romero:CB:88,James Maddison:CAM:88,Dejan Kulusevski:CAM:87,Micky van de Ven:CB:87,Brennan Johnson:RW:86,Destiny Udogie:LB:86,Heung-min Son:LW:86,Pape Matar Sarr:CM:86,Pedro Porro:RB:86,Richarlison:ST:85,Guglielmo Vicario:GK:84,Radu Dr\u0103gu\u0219in:CB:82,Emerson Royal:RB:80,Timo Werner:ST:80,Bryan Gil:LW:79,Ben Davies:CB:78,Ryan Sessegnon:LB:77",
  "Tottenham Hotspur|2025": "Micky van de Ven:CB:88,Cristian Romero:CB:87,Dejan Kulusevski:CAM:86,James Maddison:CAM:86,Archie Gray:CM:85,Brennan Johnson:RW:85,Destiny Udogie:LB:85,Dominic Solanke:ST:85,Lucas Bergvall:CM:85,Mathys Tel:ST:85,Pape Matar Sarr:CM:85,Pedro Porro:RB:85,Djed Spence:LB:84,Guglielmo Vicario:GK:84,Heung-min Son:LW:83,Richarlison:ST:83,Kevin Danso:CB:82,Radu Dr\u0103gu\u0219in:CB:82,Wilson Odobert:LW:82,Anton\xEDn Kinsk\xFD:GK:79",
  "Tottenham Hotspur|2026": "Micky van de Ven:CB:88,Mohammed Kudus:RW:87,Cristian Romero:CB:86,Xavi Simons:CAM:86,Lucas Bergvall:CM:85,Pedro Porro:RB:85,Archie Gray:CM:84,Conor Gallagher:CM:84,Dejan Kulusevski:CAM:84,Destiny Udogie:LB:84,Dominic Solanke:ST:84,Pape Matar Sarr:CM:84,Djed Spence:LB:83,Richarlison:ST:83,Guglielmo Vicario:GK:82,Mathys Tel:ST:82,Kevin Danso:CB:81,Radu Dr\u0103gu\u0219in:CB:81,Wilson Odobert:LW:81,Anton\xEDn Kinsk\xFD:GK:79",
  "VfB Stuttgart|2016": "Filip Kosti\u0107:LM:77,Daniel Didavi:CAM:76,Timo Werner:ST:76,Lukas Rupp:CAM:73,Christian Gentner:CM:72,Daniel Ginczek:ST:72,Emiliano Ins\xFAa:LB:72,Martin Harnik:ST:72,Timo Baumgartl:CB:72,Kevin Gro\xDFkreutz:RB:70,Przemyslaw Tyton:GK:70,Toni Sunjic:CB:70,Florian Klein:RB:68,Mitchell Langerak:GK:68",
  "VfB Stuttgart|2017": "Benjamin Pavard:CB:78,Timo Baumgartl:CB:74,Carlos Man\xE9:RW:73,Emiliano Ins\xFAa:LB:72,Simon Terodde:ST:72,Berkay \xD6zcan:CM:70,Daniel Ginczek:ST:70,Marcin Kami\u0144ski:CB:70,Takuma Asano:RW:70,Christian Gentner:CM:68,Ebenezer Ofori:CDM:68,Jean Zimmer:RB:68,Kevin Gro\xDFkreutz:RB:68,Mitchell Langerak:GK:68,Tobias Werner:LW:64",
  "VfB Stuttgart|2018": "Benjamin Pavard:CB:85,Santiago Ascac\xEDbar:CDM:82,Jacob Bruun Larsen:LW:81,Timo Baumgartl:CB:79,Daniel Ginczek:ST:78,Ron-Robert Zieler:GK:76,Mario G\xF3mez:ST:74,Chadrac Akolo:ST:73,Emiliano Ins\xFAa:LB:73,Erik Thommy:CAM:73,Holger Badstuber:CB:73,Anastasios Donis:LW:72,Andreas Beck:RB:70,Berkay \xD6zcan:CM:70,Orel Mangala:CDM:70,Christian Gentner:CM:68,Dennis Aogo:LB:68,Takuma Asano:RW:68",
  "VfB Stuttgart|2019": "Benjamin Pavard:CB:84,Ozan Kabak:CB:82,Santiago Ascac\xEDbar:CDM:80,Timo Baumgartl:CB:77,Steven Zuber:LW:76,Marc Oliver Kempf:CB:74,Ron-Robert Zieler:GK:73,Anastasios Donis:LW:72,Borna Sosa:LB:72,Daniel Didavi:CAM:72,Emiliano Ins\xFAa:LB:70,Gonzalo Castro:CM:70,Leon Dajaku:LW:68",
  "VfB Stuttgart|2021": "Nico Gonz\xE1lez:LW:82,Orel Mangala:CDM:82,Sasa Kalajdzic:ST:82,Silas:RW:82,Borna Sosa:LB:81,Gregor Kobel:GK:81,Konstantinos Mavropanos:CB:80,Waldemar Anton:CB:77,Wataru Endo:CDM:77,Marc Oliver Kempf:CB:76,Erik Thommy:CAM:73,Tanguy Coulibaly:RW:73,Philipp F\xF6rster:CAM:72,Pascal Stenzel:RB:70",
  "VfB Stuttgart|2022": "Borna Sosa:LB:82,Sasa Kalajdzic:ST:82,Konstantinos Mavropanos:CB:79,Orel Mangala:CDM:79,Silas:RW:79,Tiago Tom\xE1s:RW:76,Wataru Endo:CDM:76,Florian M\xFCller:GK:74,Hiroki Ito:CB:74,Naouirou Ahamada:CM:74,Omar Marmoush:ST:74,Waldemar Anton:CB:74,Chris F\xFChrich:LW:72,Enzo Millot:CAM:70,Philipp F\xF6rster:CAM:70,Pascal Stenzel:RB:68",
  "VfB Stuttgart|2024": "Enzo Millot:CAM:85,Serhou Guirassy:ST:85,Chris F\xFChrich:LW:83,Deniz Undav:ST:83,Hiroki Ito:CB:83,Waldemar Anton:CB:82,Jamie Leweling:RW:81,Maximilian Mittelst\xE4dt:LB:81,Alexander N\xFCbel:GK:78,Josha Vagnoman:RB:78,Anthony Rouault:CB:77,Dan-Axel Zagadou:CB:77,Silas:RW:77,Mahmoud Dahoud:CM:76,Leonidas Stergiou:RB:73,Woo-yeong Jeong:CAM:72",
  "VfB Stuttgart|2025": "Nick Woltemade:ST:88,Enzo Millot:CAM:84,Deniz Undav:ST:82,Ermedin Demirovic:ST:82,Maximilian Mittelst\xE4dt:LB:81,El Bilal Tour\xE9:LW:80,Chris F\xFChrich:LW:79,Jeff Chabot:CB:79,Alexander N\xFCbel:GK:78,Josha Vagnoman:RB:77,Ameen Al-Dakhil:CB:76,Fabian Rieder:CAM:76,Leonidas Stergiou:RB:73,Ramon Hendriks:CB:73,Laurin Ulrich:CAM:70",
  "Zenit St. Petersburg|2016": "Hulk:ST:85,Axel Witsel:CDM:83,Ezequiel Garay:CB:82,Javi Garc\xEDa:CDM:79,Oleg Shatov:CAM:79,Igor Smolnikov:RB:78,Artem Dzyuba:ST:77,Domenico Criscito:LB:77,Aleksandr Kokorin:CF:76,Yuriy Lodygin:GK:76,Nicolas Lombaerts:CB:74,Artur Yusupov:CM:73,Danny:CAM:72,Lu\xEDs Neto:CB:72,Yuriy Zhirkov:LM:70,Aleksandr Anyukov:RB:68,Mikhail Kerzhakov:GK:68",
  "Zenit St. Petersburg|2017": "Aleksandr Kokorin:CF:78,Artem Dzyuba:ST:77,Giuliano:CAM:77,Oleg Shatov:CAM:77,Andrey Lunev:GK:76,Branislav Ivanovic:RB:76,Igor Smolnikov:RB:76,Javi Garc\xEDa:CDM:76,Domenico Criscito:LB:73,Hernani:CM:72,Lu\xEDs Neto:CB:72,Maur\xEDcio:CDM:72,Yuriy Lodygin:GK:72,Ivan Novoseltsev:CB:70,Yohan Mollo:RW:70,Artur Yusupov:CM:68,Yuriy Zhirkov:LM:68",
  "Zenit St. Petersburg|2018": "Leandro Paredes:CDM:82,Sebasti\xE1n Driussi:ST:79,Aleksandr Kokorin:CF:78,Daler Kuzyaev:CM:78,Emanuel Mammana:CB:78,Andrey Lunev:GK:77,Aleksandr Erokhin:CAM:76,Emiliano Rigoni:RW:76,Igor Smolnikov:RB:76,Mat\xEDas Kranevitter:CDM:76,Dmitriy Poloz:LW:74,Miha Mevlja:CB:73,Domenico Criscito:LB:72,Branislav Ivanovic:RB:70,Yuriy Lodygin:GK:70,Yuriy Zhirkov:LM:64",
  "Zenit St. Petersburg|2020": "Malcom:RW:85,Sardar Azmoun:ST:82,Wilmar Barrios:CDM:80,Artem Dzyuba:ST:79,Douglas Santos:LB:79,Sebasti\xE1n Driussi:ST:79,Andrey Lunev:GK:76,Daler Kuzyaev:CM:76,Aleksandr Erokhin:CAM:74,Emanuel Mammana:CB:74,Emiliano Rigoni:RW:74,Magomed Ozdoev:CDM:74,Vyacheslav Karavaev:RB:74,Oleg Shatov:CAM:72,Yordan Osorio:CB:72,Igor Smolnikov:RB:70,Mikhail Kerzhakov:GK:68,Yuriy Zhirkov:LM:64",
  "Zenit St. Petersburg|2021": "Malcom:RW:82,Sardar Azmoun:ST:82,Wendel:CM:81,Wilmar Barrios:CDM:81,Douglas Santos:LB:80,Artem Dzyuba:ST:78,Daler Kuzyaev:CM:77,Dejan Lovren:CB:77,Sebasti\xE1n Driussi:ST:76,Vyacheslav Karavaev:RB:76,Yaroslav Rakitskyi:CB:74,Andrey Lunev:GK:73,Magomed Ozdoev:CDM:73,Dmitriy Chistyakov:CB:72,Aleksey Sutormin:RW:70,Andrey Mostovoy:LW:70,Mikhail Kerzhakov:GK:68",
  "Zenit St. Petersburg|2022": "Malcom:RW:82,Wendel:CM:82,Wilmar Barrios:CDM:81,Claudinho:CAM:80,Douglas Santos:LB:80,Yuri Alberto:ST:80,Daler Kuzyaev:CM:77,Artem Dzyuba:ST:74,Vyacheslav Karavaev:RB:74,Yaroslav Rakitskyi:CB:74,Dejan Lovren:CB:73,Andrey Mostovoy:LW:72,Dmitriy Chistyakov:CB:72,Ivan Sergeev:ST:72,Aleksandr Erokhin:CAM:68,Arsen Adamov:RB:68,Daniil Odoevskiy:GK:64,Vladislav Saus:RM:64"
};

// src/lib/soccerClubSquad.ts
var GROUP_OF = {
  GK: "GK",
  CB: "DEF",
  LB: "DEF",
  RB: "DEF",
  CDM: "MID",
  CM: "MID",
  CAM: "MID",
  LM: "MID",
  RM: "MID",
  LW: "ATT",
  RW: "ATT",
  ST: "ATT",
  CF: "ATT"
};
function groupOf(pos) {
  return GROUP_OF[pos] ?? "MID";
}
var cache = /* @__PURE__ */ new Map();
function clubSquad(club, year) {
  if (!club || !Number.isFinite(year)) return null;
  if (year < CLUB_SQUAD_YEARS.first || year > CLUB_SQUAD_YEARS.last) return null;
  const dataName = CLUB_DATA_NAME[club];
  if (!dataName) return null;
  const key = `${dataName}|${year}`;
  if (cache.has(key)) return cache.get(key) ?? null;
  const blob = CLUB_SQUADS[key];
  if (!blob) {
    cache.set(key, null);
    return null;
  }
  const men = [];
  for (const entry of blob.split(",")) {
    const [name, pos, ovr] = entry.split(":");
    if (!name || !pos || !ovr) continue;
    men.push({ name, pos, ovr: Number(ovr), group: groupOf(pos) });
  }
  men.sort((a, b) => b.ovr - a.ovr || a.name.localeCompare(b.name));
  const value = men.length ? men : null;
  cache.set(key, value);
  return value;
}
function depthChart(club, year, position, myOverall, myName) {
  const squad = clubSquad(club, year);
  if (!squad) return null;
  const group = groupOf(position);
  const rivals = squad.filter((m) => m.group === group);
  if (!rivals.length) return null;
  const me = { name: myName, pos: position, ovr: Math.round(myOverall), group, me: true };
  const ahead = rivals.filter((m) => m.ovr >= me.ovr).length;
  const men = [...rivals];
  men.splice(ahead, 0, me);
  return {
    club,
    year,
    group,
    men,
    ahead,
    aheadOfMe: ahead > 0 ? men[ahead - 1] : null,
    squad
  };
}
var GROUP_LABEL = {
  GK: "goalkeepers",
  DEF: "defenders",
  MID: "midfielders",
  ATT: "forwards"
};

// src/lib/soccerCareerSave.ts
var record = (v) => typeof v === "object" && v !== null && !Array.isArray(v);
var text = (v) => typeof v === "string";
var number = (v) => typeof v === "number" && Number.isFinite(v);
var list = (v, check) => Array.isArray(v) && v.every(check);
var fields = (v, names, check) => names.every((name) => check(v[name]));
var phases = ["youth", "contract_offer", "playing", "newspaper", "season_summary", "transfer_window", "random_events", "international_debut", "world_cup", "rivalry_event", "ballon_dor", "retirement_ceremony", "retirement_suggestion", "post_retirement", "manager_season", "pundit_season", "owner_season", "social_media_action", "moral_dilemma", "red_card_appeal_result", "rehab_choice", "retired"];
var season = (v) => record(v) && fields(v, ["club", "clubCountry", "type"], text) && fields(v, ["year", "age", "clubTier", "apps", "goals", "assists", "cleanSheets", "yellowCards", "redCards", "rating"], number);
var offer = (v) => record(v) && record(v.club) && fields(v.club, ["name", "country", "color", "league"], text) && number(v.club.tier) && fields(v, ["contractYears", "wage"], number);
var event = (v) => record(v) && number(v.id) && fields(v, ["title", "description"], text) && list(v.choices, (choice) => record(choice) && fields(choice, ["label", "consequence"], text)) && v.choices.length > 0;
function isSoccerCareerSave(value) {
  if (!record(value)) return false;
  if (!fields(value, ["playerName", "nationality", "position", "era", "currentClub", "currentClubCountry", "currentClubColor", "currentLeague", "lifestyleLevel"], text) || !fields(value, ["age", "currentClubTier", "contractYearsLeft", "weeklyWage", "marketValue", "pace", "shooting", "passing", "dribbling", "defending", "physical", "reflexes", "overall", "netWorth", "socialMediaFollowers", "popularity", "morale"], number) || typeof value.retired !== "boolean" || !phases.includes(value.phase)) return false;
  if (!list(value.seasons, season) || value.seasons.length === 0 || !list(value.events, text) || !list(value.pendingEvents, event) || !list(value.pendingOffers, offer) || !list(value.pendingNews, (row) => record(row) && fields(row, ["newspaper", "headline", "body"], text)) || !list(value.awards, (row) => record(row) && number(row.year) && fields(row, ["name", "emoji"], text)) || !list(value.properties, text) || !list(value.investments, text)) return false;
  if (!record(value.family) || !number(value.family.children) || typeof value.family.isMarried !== "boolean" || typeof value.family.isDivorced !== "boolean" || !record(value.intStats) || !fields(value.intStats, ["caps", "goals", "assists"], number)) return false;
  if (value.pendingSummary != null && !season(value.pendingSummary)) return false;
  if (value.legacy != null && (!record(value.legacy) || !number(value.legacy.score) || !text(value.legacy.tier) || !list(value.legacy.breakdown, (row) => record(row) && text(row.label) && number(row.points)))) return false;
  for (const name of ["managerState", "ownerState"]) {
    const tail = value[name];
    if (tail != null && (!record(tail) || !text(tail.club) || !fields(tail, ["clubTier", "season", "trophies", "promotions"], number) || !list(tail.seasonResults, (row) => record(row) && fields(row, ["club", "result"], text) && number(row.year)))) return false;
  }
  if (value.ownerState != null && (!record(value.ownerState) || !number(value.ownerState.budget))) return false;
  if (value.punditState != null && (!record(value.punditState) || !fields(value.punditState, ["season", "controversies"], number) || !list(value.punditState.predictions, (row) => record(row) && text(row.prediction) && typeof row.cameTrue === "boolean"))) return false;
  return true;
}
export {
  FALLBACK_CLUBS,
  GROUP_LABEL,
  acceptOffer,
  advanceYouthYear,
  depthChart,
  formatWage,
  generateContractOffers,
  initCareer,
  isSoccerCareerSave,
  nextSeasonYear,
  repairCareer
};
