import{j as r,c as f}from"./index-BGBLzPC2.js";import{ConfettiBurst as u}from"./Celebration-CdABTlLr.js";const d=400,h=180,p=9;function l(a){return h+Math.max(0,a)*d}function g(a,n){const o=e=>{if(!e||typeof e!="object")return null;const s=typeof e.playerName=="string"?e.playerName.trim():"",c=typeof e.team=="string"?e.team.trim():"";if(!s||!c)return null;const m=Number.isFinite(e.grade)?Math.round(e.grade):0;return{team:c,playerName:s,pos:typeof e.pos=="string"?e.pos:"",grade:m}},t=[],i=o(a);i&&t.push({...i,overall:1,mine:!0});for(const e of Array.isArray(n)?n:[]){if(t.length>=p)break;const s=o(e);s&&t.push({...s,overall:t.length+1,mine:!1})}return{picks:t,totalMs:t.length?l(t.length-1)+d:0}}function x(a){const n=a.picks.length;if(n===0)return"";const o=a.picks.filter(i=>i.mine).length,t=n-o;return o===0?t===1?"One went off the board.":`${t} went off the board.`:t===0?"Your pick is in.":`Your pick is in, and ${t} more went off the board.`}function w({night:a,onContinue:n,headline:o}){if(!a||a.picks.length===0)return null;const t=a.picks.find(e=>e.mine),i=l(a.picks.length-1)+d;return r.jsxs("div",{"data-draft-night":!0,className:"relative overflow-hidden rounded-2xl border border-border bg-card p-3",children:[t&&r.jsx(u,{seed:t.overall+t.playerName.length,count:18}),r.jsxs("div",{className:"relative",children:[r.jsx("p",{className:"text-[10px] uppercase tracking-wider text-muted-foreground",children:"On the clock"}),r.jsx("p",{className:"fo-draft-head text-sm font-bold text-foreground",children:o??x(a)}),r.jsx("ol",{className:"mt-2 space-y-1",children:a.picks.map((e,s)=>r.jsxs("li",{className:f("fo-draft-row flex items-center justify-between gap-2 rounded-lg border px-2.5 py-1.5",e.mine?"border-gold/50 bg-gold/10":"border-border bg-secondary/40"),style:{animationDelay:`${l(s)}ms`},children:[r.jsxs("span",{className:"min-w-0",children:[r.jsxs("span",{className:"block truncate text-xs font-bold text-foreground",children:[r.jsxs("span",{className:"text-muted-foreground",children:[e.overall,". "]}),e.team," ",e.mine?"select":"take"," ",e.playerName]}),r.jsxs("span",{className:"block text-[10px] text-muted-foreground",children:[e.pos,e.mine?" · your pick":""]})]}),r.jsx("span",{className:f("shrink-0 rounded-full px-2 py-0.5 text-xs font-black tabular-nums",e.mine?"bg-gold/20 text-gold":"bg-primary/15 text-primary"),children:e.grade})]},`${e.overall}-${e.playerName}`))}),n&&r.jsx("button",{type:"button","data-draft-continue":!0,onClick:n,className:"fo-draft-continue mt-3 min-h-11 w-full rounded-full bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground hover:brightness-110",style:{animationDelay:`${i}ms`},children:"Continue to the hub"})]}),r.jsx("style",{children:`
        @keyframes foDraftIn {
          0% { opacity: 0; transform: translateY(6px) scale(0.98); }
          100% { opacity: 1; transform: translateY(0) scale(1); }
        }
        .fo-draft-row { opacity: 0; animation: foDraftIn 0.34s ease-out forwards; }
        .fo-draft-continue { opacity: 0; animation: foDraftIn 0.34s ease-out forwards; }
        @keyframes foDraftHead { 0% { opacity: 0; } 100% { opacity: 1; } }
        .fo-draft-head { opacity: 0; animation: foDraftHead 0.3s ease-out forwards; }
        /* Round 423's rule, and it matters more here than usual: every row above
           starts invisible, so cancelling the animation without landing it would
           hide the entire pick list from the people who asked for less motion.
           The rows end on their final frame instead, which is the whole board
           shown at once with no movement. The Continue button is on the same
           rule, or the way off the draft would be invisible to them. */
        @media (prefers-reduced-motion: reduce) {
          .fo-draft-row, .fo-draft-head, .fo-draft-continue {
            animation: none;
            opacity: 1;
            transform: none;
          }
        }
      `})]})}export{w as D,p as M,d as P,g as b,l as p};
