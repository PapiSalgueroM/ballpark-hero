import { jsxDEV as _jsxDEV, Fragment as _Fragment } from "react/jsx-dev-runtime";
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { AuthModal } from '@/components/auth/AuthModal';
import { useAuth } from '@/contexts/AuthContext';
import { Flame } from 'lucide-react';
export function GuestScoreBanner({ score }) {
    const { user } = useAuth();
    const [authModal, setAuthModal] = useState({
        open: false,
        tab: 'signup'
    });
    if (user) return null;
    return /*#__PURE__*/ _jsxDEV(_Fragment, {
        children: [
            /*#__PURE__*/ _jsxDEV("div", {
                className: "mt-4 p-4 rounded-xl border border-primary/20 bg-primary/5 text-center",
                children: [
                    /*#__PURE__*/ _jsxDEV("p", {
                        className: "text-lg font-medium mb-2",
                        children: [
                            "You scored ",
                            /*#__PURE__*/ _jsxDEV("span", {
                                className: "text-primary font-bold",
                                children: String(score)
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/guest.tsx",
                                lineNumber: 25,
                                columnNumber: 22
                            }, this),
                            "! 🎉"
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/guest.tsx",
                        lineNumber: 24,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("p", {
                        className: "text-sm text-muted-foreground mb-3",
                        children: [
                            "Create a free account to save your score and track your streak ",
                            /*#__PURE__*/ _jsxDEV(Flame, {
                                className: "inline w-4 h-4 text-orange-500"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/guest.tsx",
                                lineNumber: 28,
                                columnNumber: 74
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/guest.tsx",
                        lineNumber: 27,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "flex items-center justify-center gap-2",
                        children: [
                            /*#__PURE__*/ _jsxDEV(Button, {
                                variant: "outline",
                                size: "sm",
                                onClick: ()=>setAuthModal({
                                        open: true,
                                        tab: 'login'
                                    }),
                                children: "Log In"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/guest.tsx",
                                lineNumber: 31,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ _jsxDEV(Button, {
                                size: "sm",
                                onClick: ()=>setAuthModal({
                                        open: true,
                                        tab: 'signup'
                                    }),
                                children: "Sign Up"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/guest.tsx",
                                lineNumber: 38,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/guest.tsx",
                        lineNumber: 30,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/guest.tsx",
                lineNumber: 23,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV(AuthModal, {
                isOpen: authModal.open,
                onClose: ()=>setAuthModal({
                        ...authModal,
                        open: false
                    }),
                defaultTab: authModal.tab
            }, void 0, false, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/guest.tsx",
                lineNumber: 47,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
