import { jsxDEV as _jsxDEV } from "react/jsx-dev-runtime";
import { useEffect, useRef, useState } from 'react';
import { cn } from '@/lib/utils';
import { formatNumber } from '@/lib/formatNumber';
const finite = (value)=>typeof value === 'number' && Number.isFinite(value);
const recorded = (value)=>finite(value) ? String(value) : 'Not recorded';
const control = 'min-h-[44px] min-w-0 rounded-xl border border-border bg-card px-3 py-2 text-sm font-semibold text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary';
const tabs = [
    'Overview',
    'Regular season'
];
function delta(first, second, money) {
    const a = first.numeric?.raw, b = second.numeric?.raw;
    if (!finite(a) || !finite(b)) return 'Not recorded';
    const digits = second.numeric?.digits ?? first.numeric?.digits;
    const change = Number((b - a).toFixed(digits ?? 6));
    const amount = digits === undefined ? String(Math.abs(change)) : Math.abs(change).toFixed(digits);
    return `${change > 0 ? '+' : change < 0 ? '-' : ''}${money ? '$' : ''}${amount}${money ? 'M' : ''}`;
}
export default function CareerSeasonComparison({ career, sport, onBack }) {
    const [first, setFirst] = useState(career.seasons.length - 2);
    const [second, setSecond] = useState(career.seasons.length - 1);
    const [tab, setTab] = useState('Overview');
    const title = useRef(null);
    useEffect(()=>{
        title.current?.focus({
            preventScroll: true
        });
    }, []);
    const seasons = [
        career.seasons[first],
        career.seasons[second]
    ];
    const details = seasons.map((season)=>sport.reviewStats(season, career.pos));
    const overview = seasons.map((season, index)=>[
            {
                label: 'Season OVR',
                value: recorded(season.ovr),
                numeric: {
                    raw: season.ovr
                }
            },
            {
                label: details[index].gamesLabel,
                value: formatNumber(recorded(season.games)),
                numeric: {
                    raw: season.games
                }
            },
            {
                label: 'Age that season',
                value: recorded(season.age),
                numeric: {
                    raw: season.age
                }
            },
            {
                label: 'Season salary',
                value: finite(season.salary) ? `$${formatNumber(season.salary)}M` : 'Not recorded',
                numeric: {
                    raw: season.salary
                }
            }
        ]);
    const sides = tab === 'Overview' ? overview : details.map((detail)=>detail.regularValues.filter((stat)=>stat.numeric));
    const labels = [
        ...new Set(sides.flat().map((stat)=>stat.label))
    ];
    const choices = career.seasons.map((season, index)=>({
            season,
            index
        })).reverse();
    const suspended = tab === 'Regular season' && seasons.some((season)=>season.teamResult === 'SUSPENDED');
    return /*#__PURE__*/ _jsxDEV("section", {
        "data-career-season-comparison": "",
        className: "space-y-2",
        "aria-labelledby": "career-season-compare-title",
        children: [
            /*#__PURE__*/ _jsxDEV("button", {
                "data-season-compare-back": "",
                onClick: onBack,
                className: control,
                children: "Back to seasons"
            }, void 0, false, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/delta.tsx",
                lineNumber: 43,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                children: [
                    /*#__PURE__*/ _jsxDEV("h2", {
                        ref: title,
                        id: "career-season-compare-title",
                        "data-season-compare-title": "",
                        tabIndex: -1,
                        className: "font-display text-xl font-bold",
                        children: "Compare seasons"
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/delta.tsx",
                        lineNumber: 44,
                        columnNumber: 10
                    }, this),
                    /*#__PURE__*/ _jsxDEV("p", {
                        className: "mt-1 text-sm text-muted-foreground",
                        children: "Change shows the second season minus the first."
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/delta.tsx",
                        lineNumber: 45,
                        columnNumber: 7
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/delta.tsx",
                lineNumber: 44,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "grid grid-cols-2 gap-2",
                children: [
                    {
                        label: 'First season',
                        value: first,
                        other: second,
                        set: setFirst,
                        side: 'first'
                    },
                    {
                        label: 'Second season',
                        value: second,
                        other: first,
                        set: setSecond,
                        side: 'second'
                    }
                ].map(({ label, value, other, set, side })=>/*#__PURE__*/ _jsxDEV("label", {
                        className: "min-w-0 space-y-1 text-xs font-semibold",
                        children: [
                            /*#__PURE__*/ _jsxDEV("span", {
                                children: label
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/delta.tsx",
                                lineNumber: 48,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ _jsxDEV("select", {
                                "aria-label": label,
                                "data-season-compare-first": side === 'first' ? '' : undefined,
                                "data-season-compare-second": side === 'second' ? '' : undefined,
                                value: value,
                                onChange: (event)=>set(Number(event.target.value)),
                                className: cn(control, 'w-full'),
                                children: choices.filter((choice)=>choice.index !== other).map(({ season, index })=>/*#__PURE__*/ _jsxDEV("option", {
                                        value: index,
                                        children: [
                                            recorded(season.year),
                                            " (#",
                                            index + 1,
                                            ")"
                                        ]
                                    }, index, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/delta.tsx",
                                        lineNumber: 51,
                                        columnNumber: 88
                                    }, this))
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/delta.tsx",
                                lineNumber: 49,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ _jsxDEV("span", {
                                className: "block break-words font-normal text-muted-foreground",
                                children: career.seasons[value].team ? sport.teamLabelOf(career.seasons[value].team, career.eraId) : 'Team not recorded'
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/delta.tsx",
                                lineNumber: 53,
                                columnNumber: 9
                            }, this)
                        ]
                    }, side, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/delta.tsx",
                        lineNumber: 47,
                        columnNumber: 228
                    }, this))
            }, void 0, false, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/delta.tsx",
                lineNumber: 46,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                role: "group",
                "aria-label": "Comparison details",
                className: "grid grid-cols-2 gap-2",
                children: tabs.map((value)=>/*#__PURE__*/ _jsxDEV("button", {
                        "data-season-compare-tab": value,
                        "aria-pressed": tab === value,
                        onClick: ()=>setTab(value),
                        className: cn(control, tab === value && 'border-primary bg-primary text-primary-foreground'),
                        children: value
                    }, value, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/delta.tsx",
                        lineNumber: 57,
                        columnNumber: 26
                    }, this))
            }, void 0, false, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/delta.tsx",
                lineNumber: 56,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "rounded-2xl border border-border bg-card p-2",
                children: [
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "grid grid-cols-3 gap-2 pb-2 text-center text-xs text-muted-foreground",
                        children: [
                            /*#__PURE__*/ _jsxDEV("span", {
                                children: "First season"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/delta.tsx",
                                lineNumber: 61,
                                columnNumber: 94
                            }, this),
                            /*#__PURE__*/ _jsxDEV("span", {
                                children: "Second season"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/delta.tsx",
                                lineNumber: 61,
                                columnNumber: 119
                            }, this),
                            /*#__PURE__*/ _jsxDEV("span", {
                                children: "Change"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/delta.tsx",
                                lineNumber: 61,
                                columnNumber: 145
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/delta.tsx",
                        lineNumber: 61,
                        columnNumber: 7
                    }, this),
                    /*#__PURE__*/ _jsxDEV("dl", {
                        className: "space-y-1",
                        children: labels.map((label)=>{
                            const stats = sides.map((side)=>side.find((stat)=>stat.label === label) ?? {
                                    label,
                                    value: 'Not recorded'
                                });
                            return /*#__PURE__*/ _jsxDEV("div", {
                                "data-season-compare-stat": label,
                                className: "rounded-xl bg-secondary/50 px-2 py-1",
                                children: [
                                    /*#__PURE__*/ _jsxDEV("dt", {
                                        className: "mb-1 text-xs text-muted-foreground",
                                        children: label
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/delta.tsx",
                                        lineNumber: 66,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        className: "grid grid-cols-3 gap-2 text-center text-sm font-semibold tabular-nums",
                                        children: [
                                            /*#__PURE__*/ _jsxDEV("dd", {
                                                "data-compare-first": "",
                                                className: "min-w-0 break-words",
                                                children: tab === 'Regular season' && seasons[0].teamResult === 'SUSPENDED' ? 'Not played' : stats[0].value
                                            }, void 0, false, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/delta.tsx",
                                                lineNumber: 68,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ _jsxDEV("dd", {
                                                "data-compare-second": "",
                                                className: "min-w-0 break-words",
                                                children: tab === 'Regular season' && seasons[1].teamResult === 'SUSPENDED' ? 'Not played' : stats[1].value
                                            }, void 0, false, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/delta.tsx",
                                                lineNumber: 69,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ _jsxDEV("dd", {
                                                "data-compare-delta": "",
                                                className: "min-w-0 break-words",
                                                children: suspended ? 'Not played' : delta(stats[0], stats[1], label === 'Season salary')
                                            }, void 0, false, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/delta.tsx",
                                                lineNumber: 70,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/delta.tsx",
                                        lineNumber: 67,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, label, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/delta.tsx",
                                lineNumber: 65,
                                columnNumber: 18
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/delta.tsx",
                        lineNumber: 62,
                        columnNumber: 7
                    }, this),
                    labels.length === 0 && /*#__PURE__*/ _jsxDEV("p", {
                        className: "text-sm text-muted-foreground",
                        children: "No recorded numbers to compare for this position."
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/delta.tsx",
                        lineNumber: 75,
                        columnNumber: 31
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/delta.tsx",
                lineNumber: 60,
                columnNumber: 5
            }, this)
        ]
    }, void 0, true, {
        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/delta.tsx",
        lineNumber: 42,
        columnNumber: 10
    }, this);
}
