/** Group a displayed number without changing its sign or precision. */ export function formatNumber(value) {
    const text = String(value);
    const parts = /^([+-]?)(\d+)(\.\d+)?$/.exec(text);
    if (!parts) return text;
    return '' + parts[2].replace(/\B(?=(\d{3})+(?!\d))/g, ',') + (parts[3] ?? '');
}
