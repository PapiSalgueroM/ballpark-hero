import { jsxDEV as _jsxDEV, Fragment as _Fragment } from "react/jsx-dev-runtime";
import { useEffect, useRef, useState } from 'react';
import { useRevealScroll } from '@/hooks/useRevealScroll';
import { cn } from '@/lib/utils';
import { formatNumber } from '@/lib/formatNumber';
import CareerSeasonComparison from '@/components/us-career/CareerSeasonComparison';
import CareerSeasonHighs from '@/components/us-career/CareerSeasonHighs';
const finite = (value)=>typeof value === 'number' && Number.isFinite(value);
const recorded = (value)=>finite(value) ? String(value) : 'Not recorded';
function difference(value, prior, hasPrior) {
    if (!hasPrior) return 'No earlier season';
    if (!finite(value) || !finite(prior)) return 'Change not recorded';
    const change = value - prior;
    return change === 0 ? 'Unchanged' : `${formatNumber(Math.abs(change))} ${change > 0 ? 'higher' : 'lower'}`;
}
const tabs = [
    'Overview',
    'Regular season',
    'Postseason'
];
export default function CareerSeasonReview({ career, sport, onBack, backLabel }) {
    const [selected, setSelected] = useState(null);
    const [tab, setTab] = useState('Overview');
    const [comparing, setComparing] = useState(false);
    const [highs, setHighs] = useState(false);
    const compareButton = useRef(null);
    const highsButton = useRef(null);
    const returnCompare = useRef(false);
    const returnHighs = useRef(false);
    const lastSelected = useRef(Math.max(0, career.seasons.length - 1));
    const picker = useRef(null);
    const title = useRef(null);
    const back = useRef(null);
    const area = useRevealScroll(`${selected}:${tab}:${comparing}:${highs}`, {
        enabled: comparing || highs || selected !== null || career.seasons.length === 0,
        skipFirst: false
    });
    const pickedTile = useRevealScroll(selected, {
        enabled: selected === null,
        skipFirst: false
    });
    const season = selected === null ? undefined : career.seasons[selected];
    const previous = selected !== null && selected > 0 ? career.seasons[selected - 1] : undefined;
    const detail = season ? sport.reviewStats(season, career.pos) : null;
    useEffect(()=>{
        if (comparing || highs) return;
        if (returnCompare.current) {
            returnCompare.current = false;
            compareButton.current?.focus({
                preventScroll: true
            });
            return;
        }
        if (returnHighs.current) {
            returnHighs.current = false;
            highsButton.current?.focus({
                preventScroll: true
            });
            return;
        }
        if (selected !== null) title.current?.focus({
            preventScroll: true
        });
        else (picker.current?.querySelector(`[data-season-tile="${lastSelected.current}"]`) ?? back.current)?.focus({
            preventScroll: true
        });
    }, [
        selected,
        comparing,
        highs
    ]);
    const choose = (index)=>{
        lastSelected.current = index;
        setTab('Overview');
        setSelected(index);
    };
    const control = 'min-h-[44px] rounded-xl border border-border bg-card px-3 py-2 text-sm font-semibold text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary';
    if (highs) return /*#__PURE__*/ _jsxDEV("div", {
        ref: area,
        "data-career-season-review": "",
        "data-no-prerender": "",
        className: "mx-auto max-w-lg",
        children: /*#__PURE__*/ _jsxDEV(CareerSeasonHighs, {
            career: career,
            sport: sport,
            onBack: ()=>{
                returnHighs.current = true;
                setHighs(false);
            },
            onReview: (index)=>{
                setHighs(false);
                choose(index);
            }
        }, void 0, false, {
            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
            lineNumber: 60,
            columnNumber: 5
        }, this)
    }, void 0, false, {
        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
        lineNumber: 59,
        columnNumber: 21
    }, this);
    if (comparing) return /*#__PURE__*/ _jsxDEV("div", {
        ref: area,
        "data-career-season-review": "",
        "data-no-prerender": "",
        className: "mx-auto max-w-lg",
        children: /*#__PURE__*/ _jsxDEV(CareerSeasonComparison, {
            career: career,
            sport: sport,
            onBack: ()=>{
                returnCompare.current = true;
                setComparing(false);
            }
        }, void 0, false, {
            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
            lineNumber: 64,
            columnNumber: 5
        }, this)
    }, void 0, false, {
        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
        lineNumber: 63,
        columnNumber: 25
    }, this);
    return /*#__PURE__*/ _jsxDEV("div", {
        ref: area,
        "data-career-season-review": "",
        "data-no-prerender": "",
        className: "mx-auto max-w-lg space-y-3",
        children: [
            /*#__PURE__*/ _jsxDEV("button", {
                ref: back,
                onClick: season ? ()=>setSelected(null) : onBack,
                className: control,
                children: season ? 'Back to seasons' : backLabel
            }, void 0, false, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                lineNumber: 68,
                columnNumber: 5
            }, this),
            !season || !detail ? /*#__PURE__*/ _jsxDEV(_Fragment, {
                children: [
                    /*#__PURE__*/ _jsxDEV("div", {
                        children: [
                            /*#__PURE__*/ _jsxDEV("h2", {
                                className: "font-display text-xl font-bold",
                                children: "Career Log"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                lineNumber: 70,
                                columnNumber: 12
                            }, this),
                            /*#__PURE__*/ _jsxDEV("p", {
                                className: "mt-1 text-sm text-muted-foreground",
                                children: "Pick a year to review your saved season. No extra season is played."
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                lineNumber: 70,
                                columnNumber: 74
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                        lineNumber: 70,
                        columnNumber: 7
                    }, this),
                    career.seasons.length >= 1 && /*#__PURE__*/ _jsxDEV("div", {
                        className: "flex flex-wrap gap-2",
                        children: [
                            /*#__PURE__*/ _jsxDEV("button", {
                                ref: highsButton,
                                "data-season-highs-open": "",
                                onClick: ()=>setHighs(true),
                                className: control,
                                children: "Season highs"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                lineNumber: 72,
                                columnNumber: 9
                            }, this),
                            career.seasons.length >= 2 && /*#__PURE__*/ _jsxDEV("button", {
                                ref: compareButton,
                                "data-season-compare-open": "",
                                onClick: ()=>setComparing(true),
                                className: control,
                                children: "Compare seasons"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                lineNumber: 73,
                                columnNumber: 40
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                        lineNumber: 71,
                        columnNumber: 38
                    }, this),
                    career.seasons.length === 0 ? /*#__PURE__*/ _jsxDEV("p", {
                        className: "rounded-xl border border-border bg-card p-4 text-sm text-muted-foreground",
                        children: "No seasons on the books yet. Go play one."
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                        lineNumber: 75,
                        columnNumber: 38
                    }, this) : /*#__PURE__*/ _jsxDEV("div", {
                        ref: picker,
                        role: "group",
                        "aria-label": "Choose a season",
                        className: "grid grid-cols-2 gap-2 sm:grid-cols-3",
                        children: career.seasons.map((saved, index)=>({
                                saved,
                                index
                            })).reverse().map(({ saved, index })=>/*#__PURE__*/ _jsxDEV("button", {
                                ref: index === lastSelected.current ? pickedTile : null,
                                "data-season-tile": index,
                                "aria-label": `Review ${finite(saved.year) ? saved.year : index + 1} season`,
                                onClick: ()=>choose(index),
                                className: cn(control, 'min-w-0 p-3 text-left'),
                                children: [
                                    /*#__PURE__*/ _jsxDEV("span", {
                                        className: "block text-lg font-bold text-primary",
                                        children: recorded(saved.year)
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                        lineNumber: 79,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("span", {
                                        className: "mt-1 block break-words text-xs",
                                        children: saved.team ? sport.teamLabelOf(saved.team, career.eraId) : 'Team not recorded'
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                        lineNumber: 80,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, index, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                lineNumber: 77,
                                columnNumber: 105
                            }, this))
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                        lineNumber: 76,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true) : /*#__PURE__*/ _jsxDEV("section", {
                "data-season-review": selected,
                "aria-labelledby": "career-season-title",
                className: "overflow-hidden rounded-2xl border border-primary/30 bg-card",
                children: [
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "border-b border-border bg-primary/10 p-3",
                        children: [
                            /*#__PURE__*/ _jsxDEV("h2", {
                                ref: title,
                                tabIndex: -1,
                                id: "career-season-title",
                                className: "font-display text-xl font-bold",
                                children: [
                                    formatNumber(recorded(season.year)),
                                    " season"
                                ]
                            }, void 0, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                lineNumber: 85,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ _jsxDEV("p", {
                                className: "mt-1 break-words text-sm",
                                children: [
                                    season.team ? sport.teamLabelOf(season.team, career.eraId) : 'Team not recorded',
                                    " · ",
                                    career.pos
                                ]
                            }, void 0, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                lineNumber: 86,
                                columnNumber: 9
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                        lineNumber: 84,
                        columnNumber: 7
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        role: "group",
                        "aria-label": "Season details",
                        className: "grid grid-cols-3 gap-1 border-b border-border p-2",
                        children: tabs.map((value)=>/*#__PURE__*/ _jsxDEV("button", {
                                "aria-pressed": tab === value,
                                "data-season-tab": value,
                                onClick: ()=>setTab(value),
                                className: cn(control, 'px-1 text-xs', tab === value && 'border-primary bg-primary text-primary-foreground'),
                                children: value
                            }, value, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                lineNumber: 89,
                                columnNumber: 28
                            }, this))
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                        lineNumber: 88,
                        columnNumber: 7
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "space-y-3 p-3",
                        children: tab === 'Overview' ? /*#__PURE__*/ _jsxDEV(_Fragment, {
                            children: [
                                /*#__PURE__*/ _jsxDEV("p", {
                                    className: "text-xs text-muted-foreground",
                                    children: previous ? `Changes compared with your ${recorded(previous.year)} season.` : 'Your first recorded season.'
                                }, void 0, false, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                    lineNumber: 94,
                                    columnNumber: 11
                                }, this),
                                /*#__PURE__*/ _jsxDEV("dl", {
                                    className: "grid grid-cols-2 gap-2",
                                    children: [
                                        /*#__PURE__*/ _jsxDEV("div", {
                                            className: "rounded-xl bg-secondary/50 p-3",
                                            children: [
                                                /*#__PURE__*/ _jsxDEV("dt", {
                                                    className: "text-xs text-muted-foreground",
                                                    children: "Season OVR"
                                                }, void 0, false, {
                                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                                    lineNumber: 96,
                                                    columnNumber: 61
                                                }, this),
                                                /*#__PURE__*/ _jsxDEV("dd", {
                                                    "data-season-ovr": "",
                                                    className: "text-xl font-bold",
                                                    children: recorded(season.ovr)
                                                }, void 0, false, {
                                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                                    lineNumber: 96,
                                                    columnNumber: 122
                                                }, this),
                                                /*#__PURE__*/ _jsxDEV("dd", {
                                                    "data-season-ovr-change": "",
                                                    className: "mt-1 text-xs",
                                                    children: difference(season.ovr, previous?.ovr, !!previous)
                                                }, void 0, false, {
                                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                                    lineNumber: 96,
                                                    columnNumber: 202
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                            lineNumber: 96,
                                            columnNumber: 13
                                        }, this),
                                        /*#__PURE__*/ _jsxDEV("div", {
                                            className: "rounded-xl bg-secondary/50 p-3",
                                            children: [
                                                /*#__PURE__*/ _jsxDEV("dt", {
                                                    className: "text-xs text-muted-foreground",
                                                    children: detail.gamesLabel
                                                }, void 0, false, {
                                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                                    lineNumber: 97,
                                                    columnNumber: 61
                                                }, this),
                                                /*#__PURE__*/ _jsxDEV("dd", {
                                                    "data-season-games": "",
                                                    className: "text-xl font-bold",
                                                    children: formatNumber(recorded(season.games))
                                                }, void 0, false, {
                                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                                    lineNumber: 97,
                                                    columnNumber: 131
                                                }, this),
                                                /*#__PURE__*/ _jsxDEV("dd", {
                                                    "data-season-games-change": "",
                                                    className: "mt-1 text-xs",
                                                    children: difference(season.games, previous?.games, !!previous)
                                                }, void 0, false, {
                                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                                    lineNumber: 97,
                                                    columnNumber: 229
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                            lineNumber: 97,
                                            columnNumber: 13
                                        }, this),
                                        /*#__PURE__*/ _jsxDEV("div", {
                                            className: "rounded-xl bg-secondary/50 p-3",
                                            children: [
                                                /*#__PURE__*/ _jsxDEV("dt", {
                                                    className: "text-xs text-muted-foreground",
                                                    children: "Age that season"
                                                }, void 0, false, {
                                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                                    lineNumber: 98,
                                                    columnNumber: 61
                                                }, this),
                                                /*#__PURE__*/ _jsxDEV("dd", {
                                                    "data-season-age": "",
                                                    className: "font-semibold",
                                                    children: recorded(season.age)
                                                }, void 0, false, {
                                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                                    lineNumber: 98,
                                                    columnNumber: 127
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                            lineNumber: 98,
                                            columnNumber: 13
                                        }, this),
                                        /*#__PURE__*/ _jsxDEV("div", {
                                            className: "rounded-xl bg-secondary/50 p-3",
                                            children: [
                                                /*#__PURE__*/ _jsxDEV("dt", {
                                                    className: "text-xs text-muted-foreground",
                                                    children: "Season salary"
                                                }, void 0, false, {
                                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                                    lineNumber: 99,
                                                    columnNumber: 61
                                                }, this),
                                                /*#__PURE__*/ _jsxDEV("dd", {
                                                    "data-season-pay": "",
                                                    className: "break-words font-semibold",
                                                    children: finite(season.salary) ? `$${formatNumber(season.salary)}M` : 'Not recorded'
                                                }, void 0, false, {
                                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                                    lineNumber: 99,
                                                    columnNumber: 125
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                            lineNumber: 99,
                                            columnNumber: 13
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                    lineNumber: 95,
                                    columnNumber: 11
                                }, this),
                                /*#__PURE__*/ _jsxDEV("div", {
                                    children: [
                                        /*#__PURE__*/ _jsxDEV("h3", {
                                            className: "text-xs font-semibold text-muted-foreground",
                                            children: "Team result"
                                        }, void 0, false, {
                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                            lineNumber: 101,
                                            columnNumber: 16
                                        }, this),
                                        /*#__PURE__*/ _jsxDEV("p", {
                                            "data-season-result": "",
                                            className: "mt-1 break-words text-sm font-semibold",
                                            children: season.teamResult || 'Not recorded'
                                        }, void 0, false, {
                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                            lineNumber: 101,
                                            columnNumber: 92
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                    lineNumber: 101,
                                    columnNumber: 11
                                }, this),
                                /*#__PURE__*/ _jsxDEV("div", {
                                    children: [
                                        /*#__PURE__*/ _jsxDEV("h3", {
                                            className: "text-xs font-semibold text-muted-foreground",
                                            children: "Awards"
                                        }, void 0, false, {
                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                            lineNumber: 102,
                                            columnNumber: 16
                                        }, this),
                                        /*#__PURE__*/ _jsxDEV("p", {
                                            "data-season-awards": "",
                                            className: "mt-1 break-words text-sm",
                                            children: Array.isArray(season.awards) ? season.awards.length ? season.awards.join(', ') : 'No awards that season' : 'Not recorded'
                                        }, void 0, false, {
                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                            lineNumber: 102,
                                            columnNumber: 87
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                    lineNumber: 102,
                                    columnNumber: 11
                                }, this)
                            ]
                        }, void 0, true) : /*#__PURE__*/ _jsxDEV(_Fragment, {
                            children: [
                                /*#__PURE__*/ _jsxDEV("h3", {
                                    className: "text-sm font-semibold",
                                    children: [
                                        tab,
                                        " performance"
                                    ]
                                }, void 0, true, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                    lineNumber: 104,
                                    columnNumber: 11
                                }, this),
                                /*#__PURE__*/ _jsxDEV("dl", {
                                    className: "grid grid-cols-2 gap-2",
                                    children: (tab === 'Regular season' ? detail.regular : detail.postseason).map((stat)=>/*#__PURE__*/ _jsxDEV("div", {
                                            "data-season-stat": stat.label,
                                            className: cn('min-w-0 rounded-xl bg-secondary/50 p-3', stat.label === 'Performance' || stat.label === 'Season' || stat.label === 'Postseason' ? 'col-span-2' : ''),
                                            children: [
                                                /*#__PURE__*/ _jsxDEV("dt", {
                                                    className: "text-xs text-muted-foreground",
                                                    children: stat.label
                                                }, void 0, false, {
                                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                                    lineNumber: 107,
                                                    columnNumber: 15
                                                }, this),
                                                /*#__PURE__*/ _jsxDEV("dd", {
                                                    className: "mt-1 break-words text-sm font-semibold",
                                                    children: stat.value
                                                }, void 0, false, {
                                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                                    lineNumber: 107,
                                                    columnNumber: 78
                                                }, this)
                                            ]
                                        }, stat.label, true, {
                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                            lineNumber: 106,
                                            columnNumber: 90
                                        }, this))
                                }, void 0, false, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                    lineNumber: 105,
                                    columnNumber: 11
                                }, this),
                                /*#__PURE__*/ _jsxDEV("p", {
                                    className: "text-xs text-muted-foreground",
                                    children: "These are the numbers kept in your save. Older saves may not have every field."
                                }, void 0, false, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                                    lineNumber: 110,
                                    columnNumber: 11
                                }, this)
                            ]
                        }, void 0, true)
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                        lineNumber: 92,
                        columnNumber: 7
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
                lineNumber: 83,
                columnNumber: 11
            }, this)
        ]
    }, void 0, true, {
        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/year.tsx",
        lineNumber: 67,
        columnNumber: 10
    }, this);
}
