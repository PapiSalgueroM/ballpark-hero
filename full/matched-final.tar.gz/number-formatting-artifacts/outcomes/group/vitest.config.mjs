import { defineConfig } from "/home/runner/work/ballpark-hero/ballpark-hero/node_modules/vitest/dist/config.js";
import react from "/home/runner/work/ballpark-hero/ballpark-hero/node_modules/@vitejs/plugin-react-swc/index.js";
import fs from 'node:fs'; import path from 'node:path'; import crypto from 'node:crypto';
const seen = new Map(), dir = "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/group", wanted = ["/home/runner/work/ballpark-hero/ballpark-hero/src/test/numberFormatting.test.tsx","/home/runner/work/ballpark-hero/ballpark-hero/src/lib/formatNumber.ts","/home/runner/work/ballpark-hero/ballpark-hero/src/components/game/ResultMoment.tsx","/home/runner/work/ballpark-hero/ballpark-hero/src/components/game/GuestScoreBanner.tsx","/home/runner/work/ballpark-hero/ballpark-hero/src/components/game/PostGameStats.tsx","/home/runner/work/ballpark-hero/ballpark-hero/src/lib/usCareerStatLine.ts","/home/runner/work/ballpark-hero/ballpark-hero/src/lib/usCareerSeasonReview.ts","/home/runner/work/ballpark-hero/ballpark-hero/src/components/us-career/CareerSeasonReview.tsx","/home/runner/work/ballpark-hero/ballpark-hero/src/components/us-career/CareerSeasonComparison.tsx","/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx","/home/runner/work/ballpark-hero/ballpark-hero/src/lib/careerTraining.ts","/home/runner/work/ballpark-hero/ballpark-hero/src/lib/dailyStanding.ts","/home/runner/work/ballpark-hero/ballpark-hero/src/test/fixtures/careerSeasonReview1008.ts","/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/group.ts"];
const hash = value => crypto.createHash('sha256').update(value).digest('hex');
export default defineConfig({ root: "/home/runner/work/ballpark-hero/ballpark-hero", plugins: [react(), {
  name: 'retain-number-transform', enforce: 'post', transform(code, id) {
    const file = id.split('?')[0].replaceAll('\\', '/'); if (!wanted.includes(file)) return null;
    const input = fs.readFileSync(file), output = 'transforms/' + hash(file).slice(0, 16) + '.js';
    fs.mkdirSync(path.join(dir, 'transforms'), { recursive: true }); fs.writeFileSync(path.join(dir, output), code);
    seen.set(file, { file, inputSha256: hash(input), transformedSha256: hash(code), output });
    fs.writeFileSync(path.join(dir, 'transforms.json'), JSON.stringify([...seen.values()], null, 2)); return null;
  }
}], test: { environment: 'jsdom', globals: true, setupFiles: ["/home/runner/work/ballpark-hero/ballpark-hero/src/test/setup.ts"], include: ["src/test/numberFormatting.test.tsx"], maxWorkers: 1, fileParallelism: false },
resolve: { alias: {"@/lib/formatNumber":"/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/group.ts","./formatNumber":"/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/group.ts","@":"/home/runner/work/ballpark-hero/ballpark-hero/src"} } });
