import { jsxDEV as _jsxDEV } from "react/jsx-dev-runtime";
import { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { peekCurrentPlayerName } from '@/lib/completions';
import { formatNumber } from '@/lib/formatNumber';
import { DAILY_STANDING_RPC, bucketEdges, beatPercent, bucketIndexFor, parseStanding } from '@/lib/dailyStanding';
/**
 * Round 716: today's standing, the one shared panel every daily game mounts
 * beside its result. It asks the database for the day's counts
 * (src/lib/dailyStanding.ts has the rules) and shows the players, where you
 * landed, the median and the top score. Fewer than 20 players today, or any
 * failure at all, and it shows nothing: a number about 4 people is not a
 * standing, and a wrong one is worse than none.
 */ const PostGameStats = ({ gameSlug, userScore, isVisible, buckets })=>{
    const [standing, setStanding] = useState(null);
    const [grown, setGrown] = useState(false);
    const bucketKey = JSON.stringify(buckets);
    const rows = useMemo(()=>JSON.parse(bucketKey), [
        bucketKey
    ]);
    useEffect(()=>{
        setStanding(null);
        setGrown(false);
        if (!isVisible || !Number.isFinite(userScore)) return undefined;
        const edges = bucketEdges(rows);
        if (!edges) return undefined;
        let cancelled = false;
        (async ()=>{
            try {
                const { data, error } = await supabase.rpc(DAILY_STANDING_RPC, {
                    p_game: gameSlug,
                    p_edges: edges,
                    p_score: Math.round(userScore),
                    p_player: peekCurrentPlayerName() || null
                });
                if (cancelled || error) return;
                const parsed = parseStanding(data, rows);
                if (!parsed) return;
                setStanding(parsed);
                requestAnimationFrame(()=>{
                    if (!cancelled) setGrown(true);
                });
            } catch  {
            /* the standing is a bonus, never a crash */ }
        })();
        return ()=>{
            cancelled = true;
        };
    }, [
        isVisible,
        gameSlug,
        userScore,
        rows
    ]);
    if (!isVisible || !standing) return null;
    const pct = beatPercent(standing);
    const mostInARow = Math.max(...standing.counts, 1);
    const yourRow = bucketIndexFor(userScore, rows);
    return /*#__PURE__*/ _jsxDEV("div", {
        "data-no-prerender": true,
        "data-testid": "daily-standing",
        className: "bg-card border border-border rounded-xl p-4 mt-2 mb-4 w-full max-w-md mx-auto text-left",
        children: [
            /*#__PURE__*/ _jsxDEV("p", {
                className: "text-xs text-muted-foreground uppercase tracking-wider mb-2 font-semibold",
                children: [
                    "📊 Today's board · ",
                    standing.players.toLocaleString('en-US'),
                    " players"
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/top.tsx",
                lineNumber: 84,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("p", {
                className: "text-sm text-foreground mb-3",
                children: [
                    "You beat ",
                    /*#__PURE__*/ _jsxDEV("span", {
                        className: "text-primary font-bold",
                        children: [
                            pct,
                            "%"
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/top.tsx",
                        lineNumber: 88,
                        columnNumber: 18
                    }, this),
                    " of players today"
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/top.tsx",
                lineNumber: 87,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "space-y-1.5",
                children: rows.map((b, i)=>/*#__PURE__*/ _jsxDEV("div", {
                        className: "flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ _jsxDEV("span", {
                                className: `text-[11px] w-16 shrink-0 text-right font-mono ${i === yourRow ? 'text-primary font-bold' : 'text-muted-foreground'}`,
                                children: b.label
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/top.tsx",
                                lineNumber: 93,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "flex-1 h-5 bg-secondary/50 rounded overflow-hidden relative",
                                children: [
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        className: `h-full rounded transition-[width] duration-700 ease-out motion-reduce:transition-none ${i === yourRow ? 'bg-primary' : 'bg-muted-foreground/30'}`,
                                        style: {
                                            width: grown ? `${standing.counts[i] / mostInARow * 100}%` : '0%'
                                        }
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/top.tsx",
                                        lineNumber: 97,
                                        columnNumber: 15
                                    }, this),
                                    standing.counts[i] > 0 && /*#__PURE__*/ _jsxDEV("span", {
                                        className: "absolute right-1.5 top-0 h-full flex items-center text-[10px] text-muted-foreground",
                                        children: formatNumber(standing.counts[i])
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/top.tsx",
                                        lineNumber: 102,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/top.tsx",
                                lineNumber: 96,
                                columnNumber: 13
                            }, this)
                        ]
                    }, b.label, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/top.tsx",
                        lineNumber: 92,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/top.tsx",
                lineNumber: 90,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "flex items-center justify-center gap-4 mt-3 text-xs text-muted-foreground",
                children: [
                    /*#__PURE__*/ _jsxDEV("span", {
                        children: [
                            "You ",
                            /*#__PURE__*/ _jsxDEV("span", {
                                className: "font-semibold text-foreground",
                                children: formatNumber(Math.round(userScore))
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/top.tsx",
                                lineNumber: 111,
                                columnNumber: 19
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/top.tsx",
                        lineNumber: 111,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("span", {
                        children: [
                            "Median ",
                            /*#__PURE__*/ _jsxDEV("span", {
                                className: "font-semibold text-foreground",
                                children: formatNumber(Math.round(standing.median))
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/top.tsx",
                                lineNumber: 112,
                                columnNumber: 22
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/top.tsx",
                        lineNumber: 112,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("span", {
                        children: [
                            "Top ",
                            /*#__PURE__*/ _jsxDEV("span", {
                                className: "font-semibold text-foreground",
                                children: String(standing.top)
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/top.tsx",
                                lineNumber: 113,
                                columnNumber: 19
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/top.tsx",
                        lineNumber: 113,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/top.tsx",
                lineNumber: 110,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/top.tsx",
        lineNumber: 79,
        columnNumber: 5
    }, this);
};
export default PostGameStats;
