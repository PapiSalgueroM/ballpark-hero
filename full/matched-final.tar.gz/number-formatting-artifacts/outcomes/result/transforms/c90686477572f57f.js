import { jsxDEV as _jsxDEV } from "react/jsx-dev-runtime";
import { cn } from '@/lib/utils';
import { SportGlyph, sportStyle } from '@/components/home/SportGlyph';
import { sportOf, SPORT_NAME } from '@/data/homeFront';
/** The one line each state says, above the score. Plain and true in any game. */ export const RESULT_STATE_COPY = {
    win: 'Nailed it',
    close: 'Good try',
    loss: 'Not this time'
};
const HEADLINE_TONE = {
    win: 'text-correct',
    close: 'text-tile',
    loss: 'text-destructive'
};
/** Bigger for a short score, smaller for a long one, so "9/9" and "$1.25M" both sit in the pill. */ function scoreSize(score) {
    const len = typeof score === 'string' || typeof score === 'number' ? String(score).length : 4;
    if (len <= 3) return 'text-4xl';
    if (len <= 6) return 'text-3xl';
    if (len <= 9) return 'text-2xl';
    return 'text-xl';
}
export function ResultMoment({ outcome, gamePath, score, scoreLabel, headline, badge, children, className }) {
    const sport = sportOf(gamePath);
    const hasScore = score !== undefined && score !== null && score !== '';
    const shownScore = score;
    return /*#__PURE__*/ _jsxDEV("div", {
        "data-result-moment": outcome,
        "data-sport": sport,
        style: sportStyle(sport),
        className: cn('relative isolate overflow-hidden rounded-xl border border-tile/40 bg-tile/10 px-4 pb-4 pt-3 text-center', className),
        children: [
            /*#__PURE__*/ _jsxDEV(SportGlyph, {
                sport: sport,
                className: "rm-mark pointer-events-none absolute -right-6 -top-6 -z-10 h-28 w-28 text-tile opacity-[0.14]"
            }, void 0, false, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/result.tsx",
                lineNumber: 83,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("p", {
                className: "flex items-center justify-center gap-1.5 text-[11px] font-bold uppercase tracking-[0.14em] text-tile",
                children: [
                    /*#__PURE__*/ _jsxDEV(SportGlyph, {
                        sport: sport,
                        className: "h-3.5 w-3.5 shrink-0"
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/result.tsx",
                        lineNumber: 86,
                        columnNumber: 9
                    }, this),
                    sport !== 'world' && /*#__PURE__*/ _jsxDEV("span", {
                        children: SPORT_NAME[sport]
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/result.tsx",
                        lineNumber: 87,
                        columnNumber: 31
                    }, this),
                    sport !== 'world' && /*#__PURE__*/ _jsxDEV("span", {
                        "aria-hidden": "true",
                        children: "·"
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/result.tsx",
                        lineNumber: 88,
                        columnNumber: 31
                    }, this),
                    /*#__PURE__*/ _jsxDEV("span", {
                        "data-result-state": true,
                        children: RESULT_STATE_COPY[outcome]
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/result.tsx",
                        lineNumber: 89,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/result.tsx",
                lineNumber: 85,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "relative mx-auto mt-3 h-20 w-max max-w-full",
                children: [
                    outcome === 'win' && /*#__PURE__*/ _jsxDEV("span", {
                        "aria-hidden": "true",
                        className: "rm-burst pointer-events-none absolute inset-0 rounded-full border-2 border-tile"
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/result.tsx",
                        lineNumber: 94,
                        columnNumber: 31
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: cn('rm-score relative grid h-20 min-w-[5.5rem] max-w-full place-items-center rounded-full border-[3px] bg-surface-1 px-5', outcome === 'loss' ? 'border-tile/50' : 'border-tile', outcome === 'win' && 'shadow-[0_0_28px_hsl(var(--tile)/0.35)]'),
                        children: hasScore ? /*#__PURE__*/ _jsxDEV("span", {
                            "data-result-score": true,
                            className: cn('font-display font-extrabold leading-none tabular-nums text-foreground break-words', scoreSize(shownScore)),
                            children: shownScore
                        }, void 0, false, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/result.tsx",
                            lineNumber: 103,
                            columnNumber: 13
                        }, this) : badge ? /*#__PURE__*/ _jsxDEV("span", {
                            "aria-hidden": "true",
                            className: "text-4xl leading-none",
                            children: badge
                        }, void 0, false, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/result.tsx",
                            lineNumber: 107,
                            columnNumber: 13
                        }, this) : /*#__PURE__*/ _jsxDEV(SportGlyph, {
                            sport: sport,
                            className: "h-10 w-10 text-tile"
                        }, void 0, false, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/result.tsx",
                            lineNumber: 109,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/result.tsx",
                        lineNumber: 95,
                        columnNumber: 9
                    }, this),
                    hasScore && badge && /*#__PURE__*/ _jsxDEV("span", {
                        "aria-hidden": "true",
                        className: "rm-badge pointer-events-none absolute -right-3 -top-2 text-2xl leading-none",
                        children: badge
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/result.tsx",
                        lineNumber: 113,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/result.tsx",
                lineNumber: 93,
                columnNumber: 7
            }, this),
            scoreLabel && /*#__PURE__*/ _jsxDEV("p", {
                className: "mt-1.5 text-xs text-muted-foreground",
                children: scoreLabel
            }, void 0, false, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/result.tsx",
                lineNumber: 116,
                columnNumber: 22
            }, this),
            headline && /*#__PURE__*/ _jsxDEV("h2", {
                className: cn('rm-head mt-2 text-2xl font-display font-bold leading-tight', HEADLINE_TONE[outcome]),
                children: headline
            }, void 0, false, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/result.tsx",
                lineNumber: 119,
                columnNumber: 9
            }, this),
            children,
            /*#__PURE__*/ _jsxDEV("style", {
                children: `
        @keyframes rmPop { 0% { opacity: 0; transform: scale(.6); } 60% { opacity: 1; transform: scale(1.08); } 100% { opacity: 1; transform: none; } }
        @keyframes rmSettle { 0% { opacity: 0; transform: translateY(8px); } 100% { opacity: 1; transform: none; } }
        @keyframes rmRise { 0% { opacity: 0; transform: translateY(6px); } 100% { opacity: 1; transform: none; } }
        @keyframes rmBurst { 0% { opacity: .9; transform: scale(1); } 100% { opacity: 0; transform: scale(1.55); } }
        @keyframes rmMark { 0% { transform: rotate(-24deg) scale(.8); } 100% { transform: none; } }
        .rm-score { animation: rmPop 520ms cubic-bezier(.2,.8,.3,1.2) 80ms both; }
        [data-result-moment="loss"] .rm-score { animation: rmSettle 420ms ease-out 80ms both; }
        .rm-burst { opacity: 0; animation: rmBurst 900ms ease-out 360ms both; }
        .rm-badge { animation: rmPop 460ms cubic-bezier(.2,.8,.3,1.2) 420ms both; }
        .rm-head { animation: rmRise 380ms ease-out 240ms both; }
        .rm-mark { animation: rmMark 800ms ease-out both; }
        @media (prefers-reduced-motion: reduce) {
          .rm-score, .rm-badge, .rm-head, [data-result-moment="loss"] .rm-score { animation: none; opacity: 1; transform: none; }
          .rm-mark { animation: none; transform: none; }
          .rm-burst { display: none; }
        }
      `
            }, void 0, false, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/result.tsx",
                lineNumber: 123,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/number-formatting-artifacts/outcomes/copies/result.tsx",
        lineNumber: 76,
        columnNumber: 5
    }, this);
}
export default ResultMoment;
