import { jsxDEV as _jsxDEV, Fragment as _Fragment } from "react/jsx-dev-runtime";
import { useState } from 'react';
import { formatNumber } from '@/lib/formatNumber';
import { Pencil, UserPlus } from 'lucide-react';
import { FlagImg } from '@/components/FlagImg';
import { MANAGER_BACKGROUNDS, CLUB_IDENTITIES, MANAGER_AGE_BANDS, money, managerLookOf } from '@/lib/clubManager';
import JobHuntCard from '@/components/club-manager/JobHuntCard';
import ManagerAvatar from '@/components/club-manager/ManagerAvatar';
import EditManagerSheet from '@/components/club-manager/EditManagerSheet';
import { huntBusy } from '@/lib/clubManagerJobHunt';
import { BACKGROUND_TREE, TREE_INFO } from '@/lib/clubManagerXp';
import { highestScoringOf, scoringOutcome } from '@/lib/clubManagerRecords';
import CmRetireDoor from '@/components/club-manager/CmRetireDoor';
/* Round 1325: a score printed low number first. The save has kept the worst
   defeat as the other side's goals first since Round 71, so "3-0 vs Manchester
   City" read like a win. A defeat the engine keeps is never a shootout, so our
   goals are always the lower number, whichever order a save holds them in.
   Anything that is not two whole numbers comes back exactly as it was. */ export function lowFirst(score) {
    const parts = score.split('-');
    if (parts.length !== 2 || parts.some((x)=>x.trim() === '')) return score;
    const [a, b] = parts.map(Number);
    if (!Number.isFinite(a) || !Number.isFinite(b)) return score;
    return `${Math.min(a, b)}-${Math.max(a, b)}`;
}
export default function ClubManagerCareerPanel({ c, g, nationOffer, onRetireOpen }) {
    /* Round 965: the Edit manager sheet, and for a Skip career the way to name
     the man in the dugout after all. */ const [editing, setEditing] = useState(false);
    const look = managerLookOf(c.manager?.appearance);
    const bg = c.manager ? MANAGER_BACKGROUNDS[c.manager.background] : undefined;
    /* The +1 line reads the XP block's own record of the point, not the
     background table, so it only shows once the point has been handed over. */ const bgTree = c.manager && c.managerXp?.gift && BACKGROUND_TREE[c.manager.background] === c.managerXp.gift ? c.managerXp.gift : undefined;
    return /*#__PURE__*/ _jsxDEV(_Fragment, {
        children: [
            c.nationJob ? /*#__PURE__*/ _jsxDEV("div", {
                "data-nation-job": true,
                className: "bg-card border border-primary/40 rounded-xl p-3 mb-2",
                children: [
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "text-[10px] text-primary uppercase tracking-wider mb-1.5 font-bold",
                        children: [
                            "🌐 ",
                            c.nationJob.nation,
                            " manager"
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                        lineNumber: 51,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ _jsxDEV("p", {
                        className: "text-xs text-foreground",
                        children: [
                            "In charge since season ",
                            c.nationJob.since,
                            ". ",
                            c.nationJob.played === 0 ? 'Your first tournament summer is still to come.' : `${formatNumber(c.nationJob.played)} tournament${c.nationJob.played === 1 ? '' : 's'} taken charge of, ${formatNumber(c.nationJob.won)} won.`
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                        lineNumber: 52,
                        columnNumber: 21
                    }, this),
                    c.nationJob.lastResult && /*#__PURE__*/ _jsxDEV("p", {
                        className: "text-[11px] text-muted-foreground mt-1",
                        children: [
                            "Last summer (",
                            c.nationJob.lastYear,
                            "): ",
                            c.nationJob.lastResult,
                            "."
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                        lineNumber: 58,
                        columnNumber: 23
                    }, this),
                    /*#__PURE__*/ _jsxDEV("p", {
                        className: "text-[10px] text-muted-foreground mt-1",
                        children: "Tournaments run between club seasons. Miss one your country should have reached and the federation will not wait around."
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                        lineNumber: 62,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ _jsxDEV("button", {
                        onClick: g.resignNation,
                        className: "mt-2 w-full min-h-11 py-2 rounded-lg bg-secondary text-foreground text-xs font-bold hover:opacity-90 transition-opacity",
                        children: "Step down from the national team"
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                        lineNumber: 65,
                        columnNumber: 21
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                lineNumber: 50,
                columnNumber: 19
            }, this) : nationOffer ? /*#__PURE__*/ _jsxDEV("div", {
                "data-nation-offer": true,
                className: "bg-card border border-primary/50 rounded-xl p-3 mb-2",
                children: [
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "text-[10px] text-primary uppercase tracking-wider mb-1.5 font-bold",
                        children: "🌐 Your country is calling"
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                        lineNumber: 74,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ _jsxDEV("p", {
                        className: "text-sm text-foreground font-bold mb-0.5",
                        children: [
                            nationOffer.nation,
                            " want you."
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                        lineNumber: 75,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ _jsxDEV("p", {
                        className: "text-[11px] text-muted-foreground mb-2",
                        children: nationOffer.blurb
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                        lineNumber: 76,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ _jsxDEV("button", {
                        onClick: g.acceptNation,
                        className: "w-full min-h-11 py-2 rounded-lg bg-primary text-primary-foreground text-xs font-bold hover:opacity-90 transition-opacity",
                        children: [
                            "🌐 Take the ",
                            nationOffer.nation,
                            " job as well"
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                        lineNumber: 77,
                        columnNumber: 21
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                lineNumber: 73,
                columnNumber: 19
            }, this) : null,
            c.approach && /*#__PURE__*/ _jsxDEV("div", {
                className: "bg-card border border-primary/50 rounded-xl p-3 mb-2",
                children: [
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "text-[10px] text-primary uppercase tracking-wider mb-1.5 font-bold",
                        children: "📞 An approach has come in"
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                        lineNumber: 88,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ _jsxDEV("p", {
                        className: "text-sm text-foreground font-bold mb-0.5",
                        children: [
                            c.approach.club,
                            " want you as their manager."
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                        lineNumber: 89,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ _jsxDEV("p", {
                        className: "text-[11px] text-muted-foreground mb-2",
                        children: c.approach.blurb
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                        lineNumber: 90,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ _jsxDEV("p", {
                        className: "text-[10px] text-muted-foreground mb-2",
                        children: "Commit and it becomes a summer pre-agreement: the move happens when the season ends, the news breaks today, and your current board will not love it. Ignore it and they move on in a few weeks."
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                        lineNumber: 91,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "flex gap-2",
                        children: [
                            !huntBusy(c) && /*#__PURE__*/ _jsxDEV("button", {
                                onClick: ()=>g.answerApproach(true),
                                className: "flex-1 min-h-11 py-2 rounded-lg bg-primary text-primary-foreground text-xs font-bold hover:opacity-90 transition-opacity",
                                children: "🤝 Shake hands for the summer"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                                lineNumber: 97,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ _jsxDEV("button", {
                                onClick: ()=>g.answerApproach(false),
                                className: "flex-1 min-h-11 py-2 rounded-lg border border-border bg-card text-xs font-bold text-foreground hover:border-primary transition-colors",
                                children: "Turn them down"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                                lineNumber: 104,
                                columnNumber: 23
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                        lineNumber: 92,
                        columnNumber: 21
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                lineNumber: 87,
                columnNumber: 19
            }, this),
            c.pendingMove && /*#__PURE__*/ _jsxDEV("div", {
                className: "bg-card border border-gold/40 rounded-xl p-3 mb-2 text-xs text-foreground",
                children: [
                    "🤝 ",
                    /*#__PURE__*/ _jsxDEV("span", {
                        className: "font-bold",
                        children: "Pre-agreement signed:"
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                        lineNumber: 115,
                        columnNumber: 24
                    }, this),
                    " you take over at ",
                    /*#__PURE__*/ _jsxDEV("span", {
                        className: "font-bold",
                        children: c.pendingMove.club
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                        lineNumber: 115,
                        columnNumber: 98
                    }, this),
                    " when the season ends. Finish the job here first."
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                lineNumber: 114,
                columnNumber: 19
            }, this),
            !c.sacked && !c.wilderness && /*#__PURE__*/ _jsxDEV(JobHuntCard, {
                c: c,
                onApply: g.applyJob,
                onJoinNow: g.joinNow,
                onJoinSummer: g.joinSummer
            }, void 0, false, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                lineNumber: 121,
                columnNumber: 19
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                "data-cm-career-card": true,
                className: "bg-card border border-border rounded-xl p-3",
                children: [
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "text-[10px] text-muted-foreground uppercase tracking-wider mb-1.5",
                        children: "💼 Manager career"
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                        lineNumber: 124,
                        columnNumber: 19
                    }, this),
                    c.manager ? /*#__PURE__*/ _jsxDEV("div", {
                        "data-manager-card": true,
                        className: "flex items-center gap-2.5 mb-2 rounded-lg border border-border bg-background/60 px-2.5 py-2",
                        children: [
                            look && /*#__PURE__*/ _jsxDEV(ManagerAvatar, {
                                look: look,
                                size: 56,
                                className: "rounded-lg bg-secondary/40"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                                lineNumber: 131,
                                columnNumber: 32
                            }, this),
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "min-w-0 flex-1",
                                children: [
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        className: "flex items-center gap-1.5",
                                        children: [
                                            /*#__PURE__*/ _jsxDEV(FlagImg, {
                                                name: c.manager.nationality,
                                                size: 14
                                            }, void 0, false, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                                                lineNumber: 134,
                                                columnNumber: 27
                                            }, this),
                                            /*#__PURE__*/ _jsxDEV("span", {
                                                className: "text-xs font-bold text-foreground truncate",
                                                children: c.manager.name
                                            }, void 0, false, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                                                lineNumber: 135,
                                                columnNumber: 27
                                            }, this),
                                            look && /*#__PURE__*/ _jsxDEV("span", {
                                                className: "text-[9px] text-muted-foreground",
                                                children: MANAGER_AGE_BANDS[look.ageBand].label
                                            }, void 0, false, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                                                lineNumber: 136,
                                                columnNumber: 36
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                                        lineNumber: 133,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        className: "text-[9px] text-muted-foreground truncate",
                                        children: [
                                            bg?.emoji,
                                            " ",
                                            bg?.label,
                                            ' · ',
                                            CLUB_IDENTITIES[c.manager.style]?.emoji,
                                            " ",
                                            CLUB_IDENTITIES[c.manager.style]?.label
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                                        lineNumber: 138,
                                        columnNumber: 25
                                    }, this),
                                    bgTree && /*#__PURE__*/ _jsxDEV("div", {
                                        className: "text-[9px] font-bold text-gold",
                                        children: [
                                            "+1 ",
                                            TREE_INFO[bgTree].label,
                                            " from his background"
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                                        lineNumber: 142,
                                        columnNumber: 36
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                                lineNumber: 132,
                                columnNumber: 23
                            }, this),
                            /*#__PURE__*/ _jsxDEV("button", {
                                type: "button",
                                onClick: ()=>setEditing(true),
                                className: "shrink-0 inline-flex min-h-11 items-center gap-1 rounded-full border border-border px-3 py-1 text-xs font-bold text-muted-foreground hover:text-foreground hover:border-primary transition-colors",
                                children: [
                                    /*#__PURE__*/ _jsxDEV(Pencil, {
                                        className: "w-3 h-3"
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                                        lineNumber: 149,
                                        columnNumber: 25
                                    }, this),
                                    " Edit"
                                ]
                            }, void 0, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                                lineNumber: 144,
                                columnNumber: 23
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                        lineNumber: 128,
                        columnNumber: 21
                    }, this) : /*#__PURE__*/ _jsxDEV("button", {
                        type: "button",
                        "data-name-manager": true,
                        onClick: ()=>setEditing(true),
                        className: "w-full min-h-11 mb-2 inline-flex items-center justify-center gap-1.5 rounded-lg border border-dashed border-border px-2.5 py-2 text-xs font-bold text-muted-foreground hover:text-foreground hover:border-primary transition-colors",
                        children: [
                            /*#__PURE__*/ _jsxDEV(UserPlus, {
                                className: "w-3.5 h-3.5"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                                lineNumber: 159,
                                columnNumber: 23
                            }, this),
                            " Name your manager"
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                        lineNumber: 153,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ _jsxDEV(EditManagerSheet, {
                        career: c,
                        open: editing,
                        onOpenChange: setEditing,
                        onSave: g.updateManager
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                        lineNumber: 162,
                        columnNumber: 19
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "grid grid-cols-3 gap-2 text-center mb-2",
                        children: [
                            /*#__PURE__*/ _jsxDEV("div", {
                                children: [
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        className: "text-sm font-bold font-display text-foreground",
                                        children: [
                                            formatNumber(c.careerStats.wins),
                                            "W ",
                                            formatNumber(c.careerStats.draws),
                                            "D ",
                                            formatNumber(c.careerStats.losses),
                                            "L"
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                                        lineNumber: 165,
                                        columnNumber: 23
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        className: "text-[9px] text-muted-foreground",
                                        children: "Record"
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                                        lineNumber: 166,
                                        columnNumber: 23
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                                lineNumber: 164,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ _jsxDEV("div", {
                                children: [
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        className: "text-sm font-bold font-display text-foreground",
                                        children: [
                                            c.careerStats.played > 0 ? Math.round(c.careerStats.wins / c.careerStats.played * 100) : 0,
                                            "%"
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                                        lineNumber: 169,
                                        columnNumber: 23
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        className: "text-[9px] text-muted-foreground",
                                        children: "Win rate"
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                                        lineNumber: 170,
                                        columnNumber: 23
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                                lineNumber: 168,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ _jsxDEV("div", {
                                children: [
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        className: "text-sm font-bold font-display text-foreground",
                                        children: formatNumber(c.trophies.length)
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                                        lineNumber: 173,
                                        columnNumber: 23
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        className: "text-[9px] text-muted-foreground",
                                        children: "Trophies"
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                                        lineNumber: 174,
                                        columnNumber: 23
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                                lineNumber: 172,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                        lineNumber: 163,
                        columnNumber: 19
                    }, this),
                    /*#__PURE__*/ _jsxDEV(ManagerRecordLines, {
                        c: c
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                        lineNumber: 177,
                        columnNumber: 19
                    }, this),
                    g.retire && !c.retired && !c.live && /*#__PURE__*/ _jsxDEV("div", {
                        className: "mt-3",
                        children: /*#__PURE__*/ _jsxDEV(CmRetireDoor, {
                            c: c,
                            retire: g.retire,
                            onOpen: onRetireOpen
                        }, void 0, false, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                            lineNumber: 179,
                            columnNumber: 43
                        }, this)
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                        lineNumber: 179,
                        columnNumber: 21
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                lineNumber: 123,
                columnNumber: 17
            }, this)
        ]
    }, void 0, true);
}
/* Round 1343: the record lines, one list for the Manager panel and the farewell. Text unchanged from the panel,
   plus the highest scoring game after the worst defeat. */ export function ManagerRecordLines({ c, ended = false }) {
    const high = highestScoringOf(c);
    const counted = high?.missed ? Math.max(0, c.careerStats.played - high.missed) : 0;
    return /*#__PURE__*/ _jsxDEV("div", {
        "data-cm-career-lines": true,
        className: "space-y-0.5 text-xs text-muted-foreground",
        children: [
            c.careerStats.biggestWin && /*#__PURE__*/ _jsxDEV("p", {
                children: [
                    "🎉 Biggest win: ",
                    /*#__PURE__*/ _jsxDEV("span", {
                        className: "text-foreground font-semibold",
                        children: c.careerStats.biggestWin.score
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                        lineNumber: 194,
                        columnNumber: 42
                    }, this),
                    " vs ",
                    c.careerStats.biggestWin.opp
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                lineNumber: 194,
                columnNumber: 23
            }, this),
            c.careerStats.biggestDefeat && /*#__PURE__*/ _jsxDEV("p", {
                "data-cm-worst-defeat": true,
                children: [
                    "💀 Worst defeat: ",
                    /*#__PURE__*/ _jsxDEV("span", {
                        className: "text-foreground font-semibold",
                        children: lowFirst(c.careerStats.biggestDefeat.score)
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                        lineNumber: 197,
                        columnNumber: 64
                    }, this),
                    " vs ",
                    c.careerStats.biggestDefeat.opp
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                lineNumber: 197,
                columnNumber: 23
            }, this),
            high && /*#__PURE__*/ _jsxDEV("p", {
                "data-cm-highest-scoring": true,
                children: [
                    "⚽ Highest scoring game: ",
                    /*#__PURE__*/ _jsxDEV("span", {
                        className: "text-foreground font-semibold",
                        children: high.score
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                        lineNumber: 200,
                        columnNumber: 74
                    }, this),
                    SCORING_WORD[scoringOutcome(high)],
                    " vs ",
                    high.opp,
                    SCORING_AFTER[scoringOutcome(high)],
                    ", ",
                    /*#__PURE__*/ _jsxDEV("span", {
                        className: "whitespace-nowrap",
                        children: [
                            "Season ",
                            formatNumber(high.season)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                        lineNumber: 200,
                        columnNumber: 230
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                lineNumber: 200,
                columnNumber: 23
            }, this),
            high && (high.missed ?? 0) >= 1 && /*#__PURE__*/ _jsxDEV("p", {
                "data-cm-highest-scoring-missed": true,
                children: [
                    "Counted from ",
                    formatNumber(counted),
                    " of your ",
                    formatNumber(c.careerStats.played),
                    " matches. Your save no longer keeps ",
                    high.missed === 1 ? 'the score of the other one' : `the scores of the other ${formatNumber(high.missed)}`,
                    "."
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                lineNumber: 203,
                columnNumber: 23
            }, this),
            c.careerStats.mostExpensiveBuy && /*#__PURE__*/ _jsxDEV("p", {
                children: [
                    "💸 Priciest buy: ",
                    /*#__PURE__*/ _jsxDEV("span", {
                        className: "text-foreground font-semibold",
                        children: c.careerStats.mostExpensiveBuy.name
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                        lineNumber: 206,
                        columnNumber: 43
                    }, this),
                    " (",
                    money(c.careerStats.mostExpensiveBuy.fee, c),
                    ")"
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                lineNumber: 206,
                columnNumber: 23
            }, this),
            c.careerStats.mostExpensiveSale && /*#__PURE__*/ _jsxDEV("p", {
                children: [
                    "🤑 Best sale: ",
                    /*#__PURE__*/ _jsxDEV("span", {
                        className: "text-foreground font-semibold",
                        children: c.careerStats.mostExpensiveSale.name
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                        lineNumber: 209,
                        columnNumber: 40
                    }, this),
                    " (",
                    money(c.careerStats.mostExpensiveSale.fee, c),
                    ")"
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                lineNumber: 209,
                columnNumber: 23
            }, this),
            (c.careerStats.clubsManaged?.length ?? 0) > 1 && /*#__PURE__*/ _jsxDEV("p", {
                children: [
                    "🧳 Clubs managed: ",
                    /*#__PURE__*/ _jsxDEV("span", {
                        className: "text-foreground",
                        children: c.careerStats.clubsManaged.join(', ')
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                        lineNumber: 212,
                        columnNumber: 44
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                lineNumber: 212,
                columnNumber: 23
            }, this),
            c.careerStats.played === 0 && /*#__PURE__*/ _jsxDEV("p", {
                children: ended ? 'You retired before your first match, so there are no numbers to keep.' : 'Take charge of your first match and the numbers start here.'
            }, void 0, false, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
                lineNumber: 214,
                columnNumber: 52
            }, this)
        ]
    }, void 0, true, {
        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/club-manager/ClubManagerCareerPanel.tsx",
        lineNumber: 192,
        columnNumber: 19
    }, this);
}
/* The word after the score comes from the score (a res that contradicts it gets none); res only says who won a
   level shootout. Never "2-5 win". */ const SCORING_WORD = {
    win: ' win',
    loss: ' loss',
    draw: ' draw',
    pensWon: '',
    pensLost: '',
    plain: ''
};
const SCORING_AFTER = {
    win: '',
    loss: '',
    draw: '',
    pensWon: ', won on penalties',
    pensLost: ', lost on penalties',
    plain: ''
};
