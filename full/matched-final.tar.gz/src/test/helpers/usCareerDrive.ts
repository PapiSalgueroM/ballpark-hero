/**
 * Round 1104: one seeded career, driven through a sport's BINDING the way the
 * board drives it (src/components/us-career/UsCareerBoard.tsx), for the two
 * recorded fixtures of the round: the truth digest and the bank's before.
 *
 * Math.random is replaced by a keyed generator for the whole drive and put
 * back in a finally, because the bindings dismiss a rivalry beat with no
 * generator handed in (the engine then falls back to Math.random). Without
 * that a recording differs from run to run. Each test proves the drive is
 * repeatable before it trusts a fixture.
 *
 * What the loop plays, per season: a suspended year when one is owed, the free
 * agency window when the deal has run out (a keyed pick among the offers), the
 * camp, the season, progress, the summer's cards (a keyed option pick each),
 * one unread inbox text, a pending rivalry beat and a pending rival choice.
 * Extension talks are always turned down: the board allows that, and it keeps
 * the loop short.
 */
import { createHash } from 'node:crypto';
import type { UsCareerSport, UsIntlSport } from '@/lib/usCareerSport';
import { applyFaSigning } from '@/lib/usCareerFreeAgency';
import { answerSummerCard, startSummer } from '@/lib/usCareerSummer';

const hashStr = (s: string): number => {
  let h = 0x811c9dc5 >>> 0;
  for (let k = 0; k < s.length; k += 1) { h ^= s.charCodeAt(k); h = Math.imul(h, 0x01000193) >>> 0; }
  return h >>> 0;
};

/** A keyed stream: the same key gives the same draws in any process. */
export function keyedStream(key: string): () => number {
  let a = hashStr(`r1104:${key}`);
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export const sha = (s: string): string => createHash('sha1').update(s).digest('hex').slice(0, 16);

export interface DriveOptions {
  /** Names the career and keys every stream. */
  key: string;
  pos: string;
  /** Which of the position's archetypes, taken modulo the list. */
  arch: number;
  eraId?: string;
  seasons: number;
  /** Round 1541: answer the international call up where the board will
   *  (after the summer is dealt, before card 1 is answered). Absent: the call
   *  is never answered, so the drive is the drive it was before the round. */
  intl?: 'go' | 'rest';
  /** Round 1544: the sport's whole international face, which the binding now
   *  loads on demand (`await sport.intl.load()`), handed in so the drive stays
   *  synchronous. Needed with `intl`; without it the call is never answered. */
  intlFace?: UsIntlSport<AnyCareer>;
  /** Round 1541: shown the career right after each summer is dealt, before
   *  the call is answered (the harness's oracle reads it there). */
  onSummer?: (c: AnyCareer) => void;
}

export interface DriveResult {
  /** The whole final save, as JSON. */
  json: string;
  /** The lowest bank balance seen after any call. */
  lowest: number;
  /** How many calls left the balance below zero. */
  below: number;
  seasons: number;
  /** Round 1541: each call answered, with the summer's dealt cards at that moment
   *  and (Round 1544) the tournament the answer played, as JSON ('null' for rest). */
  intlLog: { year: number; edition: string; dealt: string; played: string }[];
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type AnyCareer = any;

export function driveCareer(sport: UsCareerSport, o: DriveOptions): DriveResult {
  const keep = Math.random;
  Math.random = keyedStream(`math:${sport.slug}:${o.key}`);
  const pick = keyedStream(`pick:${sport.slug}:${o.key}`);
  let lowest = Infinity;
  let below = 0;
  const intlLog: DriveResult['intlLog'] = [];
  const see = (c: AnyCareer) => {
    const n = typeof c.netWorth === 'number' ? c.netWorth : 0;
    if (n < lowest) lowest = n;
    if (n < 0) below += 1;
  };
  try {
    const archs = sport.create.archetypes[o.pos];
    let c: AnyCareer = sport.startCareer(`Drive ${o.key}`, o.pos, archs[o.arch % archs.length], Math.random, null as never, o.eraId as string);
    let tq = sport.rollTeamQuality(null, Math.random);
    sport.assignRole(c, tq, Math.random);
    see(c);
    for (let n = 0; n < o.seasons && !c.retired; n += 1) {
      if ((c.suspendedSeasons ?? 0) > 0) {
        c.suspendedSeasons -= 1;
        c.seasons.push(sport.suspendedLine(c));
        sport.progress(c, Math.random); see(c);
        continue;
      }
      if (c.contractYears <= 0) {
        const fa = sport.buildFaWindow(c, tq, Math.random);
        const open = fa.offers.filter(x => !x.gone);
        if (open.length) {
          const offer = open[Math.floor(pick() * open.length)];
          applyFaSigning(c, offer);
          sport.campBattle(c, offer.quality, Math.random);
          tq = offer.quality;
        }
      }
      sport.campBattle(c, tq, Math.random);
      sport.simSeason(c, tq, Math.random); see(c);
      sport.progress(c, Math.random); see(c);
      if (sport.shouldRetire(c)) { c.retired = true; break; }
      let ev = startSummer(c, sport, Math.random, null);
      o.onSummer?.(c);
      const call = o.intl && o.intlFace ? o.intlFace.pending(c) : null;
      if (call && o.intl && o.intlFace) {
        const dealt = JSON.stringify(c.summer ?? null);
        const res = o.intlFace.answer(c, o.intl); see(c);
        intlLog.push({ year: call.year, edition: call.edition.id, dealt, played: JSON.stringify(res?.tournament ?? null) });
      }
      while (ev) {
        const k = Math.floor(pick() * ev.options.length);
        ev = answerSummerCard(c, sport, ev, k, Math.random, null).next; see(c);
      }
      tq = sport.rollTeamQuality(tq, Math.random);
      const unread = (c.phoneInbox ?? []).find((m: AnyCareer) => m.answered === undefined);
      if (unread) { sport.answerInbox(c, unread.id, Math.floor(pick() * unread.choices.length)); see(c); }
      if (c.pendingRivalryEvent) { c = sport.dismissRivalryEvent(c).state; see(c); }
      if (c.pendingRivalryChoice) {
        const res = sport.resolveRivalryChoice(c, Math.floor(pick() * c.pendingRivalryChoice.choices.length), Math.random);
        if (res) { c = res.state; see(c); }
      }
    }
    return { json: JSON.stringify(c), lowest: lowest === Infinity ? 0 : lowest, below, seasons: c.seasons.length, intlLog };
  } finally {
    Math.random = keep;
  }
}
