import { jsxDEV as _jsxDEV } from "react/jsx-dev-runtime";
import { useRef, useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
const cash = (value)=>`${value.toLocaleString('en-US', {
        minimumFractionDigits: 3,
        maximumFractionDigits: 3
    })}m`;
export default function BoxingShowForecast({ attendance, capacity, gate, guaranteedPurses, rent, money }) {
    const [helpOpen, setHelpOpen] = useState(false);
    const helpTrigger = useRef(null);
    const helpHeading = useRef(null);
    localStorage.setItem('boxing-preview-control', 'spent');
    const guarantees = Math.round(guaranteedPurses * 1000) / 1000;
    const share = Math.round(gate * 0.58 * 1000) / 1000;
    const purses = Math.max(guarantees, share);
    const profit = Math.round((gate - purses - rent) * 1000) / 1000;
    const cashAfter = Math.round((money + profit) * 1000) / 1000;
    const result = `${profit < 0 ? 'Loss' : 'Profit'} ${cash(Math.abs(profit))}`;
    return /*#__PURE__*/ _jsxDEV("section", {
        "data-boxing-forecast": true,
        "aria-label": "Show cash forecast",
        className: "mt-2 border-t pt-2 text-xs",
        children: [
            /*#__PURE__*/ _jsxDEV("div", {
                className: "flex items-center justify-between gap-2",
                children: [
                    /*#__PURE__*/ _jsxDEV("h3", {
                        className: "font-semibold",
                        children: "Show cash forecast"
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                        lineNumber: 29,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV(Dialog, {
                        open: helpOpen,
                        onOpenChange: setHelpOpen,
                        children: [
                            /*#__PURE__*/ _jsxDEV(DialogTrigger, {
                                asChild: true,
                                children: /*#__PURE__*/ _jsxDEV("button", {
                                    ref: helpTrigger,
                                    type: "button",
                                    "aria-label": "Show cash rules",
                                    className: "h-11 w-11 shrink-0 rounded-md border text-sm font-semibold",
                                    children: "?"
                                }, void 0, false, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                                    lineNumber: 32,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                                lineNumber: 31,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ _jsxDEV(DialogContent, {
                                className: "max-h-[calc(100dvh_-_2rem)] w-[calc(100vw_-_2rem)] max-w-md overflow-y-auto rounded-xl p-4 [&>button:last-child]:h-11 [&>button:last-child]:w-11",
                                onOpenAutoFocus: (event)=>{
                                    event.preventDefault();
                                    helpHeading.current?.focus({
                                        preventScroll: true
                                    });
                                },
                                onCloseAutoFocus: (event)=>{
                                    event.preventDefault();
                                    helpTrigger.current?.focus({
                                        preventScroll: true
                                    });
                                },
                                children: [
                                    /*#__PURE__*/ _jsxDEV(DialogTitle, {
                                        ref: helpHeading,
                                        tabIndex: -1,
                                        className: "pr-12 text-base",
                                        children: "How show cash works"
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                                        lineNumber: 37,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV(DialogDescription, {
                                        className: "text-xs",
                                        children: "Check the current card before you put the show on. All money figures are in millions."
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                                        lineNumber: 38,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        className: "space-y-3 text-xs leading-relaxed",
                                        children: [
                                            /*#__PURE__*/ _jsxDEV("p", {
                                                children: "Your card, venue and ticket price set attendance and the gate. Fighters take the larger of their combined guarantees or 58% of the gate. Room hire is paid as well."
                                            }, void 0, false, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                                                lineNumber: 40,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ _jsxDEV("p", {
                                                "data-boxing-cash-example": true,
                                                className: "rounded-md border bg-muted/40 p-3",
                                                children: [
                                                    "For this card: ",
                                                    cash(gate),
                                                    " gate, less ",
                                                    cash(purses),
                                                    " fighter pay and ",
                                                    cash(rent),
                                                    " room hire, gives a ",
                                                    profit < 0 ? 'loss' : 'profit',
                                                    " of ",
                                                    cash(Math.abs(profit)),
                                                    ". Your cash goes from ",
                                                    cash(money),
                                                    " to ",
                                                    cash(cashAfter),
                                                    "."
                                                ]
                                            }, void 0, true, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                                                lineNumber: 41,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ _jsxDEV("p", {
                                                children: "A cash balance below 0 ends the promotion. Exactly 0 keeps it open, with no cash buffer. A loss does not end it if you can still cover it."
                                            }, void 0, false, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                                                lineNumber: 42,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ _jsxDEV("p", {
                                                children: "These figures follow your current choices. Fight results and reputation are decided when the show runs. Opening or closing this help does not run a show."
                                            }, void 0, false, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                                                lineNumber: 43,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                                        lineNumber: 39,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("button", {
                                        type: "button",
                                        onClick: ()=>setHelpOpen(false),
                                        className: "min-h-11 rounded-md border px-3 py-2 text-xs font-semibold",
                                        children: "Back to card"
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                                        lineNumber: 45,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                                lineNumber: 34,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                        lineNumber: 30,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                lineNumber: 28,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("dl", {
                className: "mt-2 grid grid-cols-2 gap-x-3 gap-y-2 tabular-nums",
                children: [
                    /*#__PURE__*/ _jsxDEV("div", {
                        children: [
                            /*#__PURE__*/ _jsxDEV("dt", {
                                className: "text-muted-foreground",
                                children: "Attendance"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                                lineNumber: 50,
                                columnNumber: 14
                            }, this),
                            /*#__PURE__*/ _jsxDEV("dd", {
                                "data-boxing-attendance": true,
                                "data-value": attendance,
                                className: "font-semibold",
                                children: [
                                    attendance.toLocaleString('en-US'),
                                    " of ",
                                    capacity.toLocaleString('en-US')
                                ]
                            }, void 0, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                                lineNumber: 50,
                                columnNumber: 67
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                        lineNumber: 50,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        children: [
                            /*#__PURE__*/ _jsxDEV("dt", {
                                className: "text-muted-foreground",
                                children: "Gate"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                                lineNumber: 51,
                                columnNumber: 14
                            }, this),
                            /*#__PURE__*/ _jsxDEV("dd", {
                                "data-boxing-gate": true,
                                "data-value": gate,
                                className: "font-semibold",
                                children: cash(gate)
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                                lineNumber: 51,
                                columnNumber: 61
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                        lineNumber: 51,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        children: [
                            /*#__PURE__*/ _jsxDEV("dt", {
                                className: "text-muted-foreground",
                                children: "Fighter pay"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                                lineNumber: 52,
                                columnNumber: 14
                            }, this),
                            /*#__PURE__*/ _jsxDEV("dd", {
                                "data-boxing-purses": true,
                                "data-value": purses,
                                className: "font-semibold",
                                children: cash(purses)
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                                lineNumber: 52,
                                columnNumber: 68
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                        lineNumber: 52,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        children: [
                            /*#__PURE__*/ _jsxDEV("dt", {
                                className: "text-muted-foreground",
                                children: "Room hire"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                                lineNumber: 53,
                                columnNumber: 14
                            }, this),
                            /*#__PURE__*/ _jsxDEV("dd", {
                                "data-boxing-rent": true,
                                "data-value": rent,
                                className: "font-semibold",
                                children: cash(rent)
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                                lineNumber: 53,
                                columnNumber: 66
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                        lineNumber: 53,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        children: [
                            /*#__PURE__*/ _jsxDEV("dt", {
                                className: "text-muted-foreground",
                                children: "Show result"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                                lineNumber: 54,
                                columnNumber: 14
                            }, this),
                            /*#__PURE__*/ _jsxDEV("dd", {
                                "data-boxing-profit": true,
                                "data-value": profit,
                                className: `font-semibold ${profit < 0 ? 'text-destructive' : ''}`,
                                children: result
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                                lineNumber: 54,
                                columnNumber: 68
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                        lineNumber: 54,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        children: [
                            /*#__PURE__*/ _jsxDEV("dt", {
                                className: "text-muted-foreground",
                                children: "Cash afterward"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                                lineNumber: 55,
                                columnNumber: 14
                            }, this),
                            /*#__PURE__*/ _jsxDEV("dd", {
                                "data-boxing-cash-after": true,
                                "data-value": cashAfter,
                                className: `font-semibold ${cashAfter < 0 ? 'text-destructive' : ''}`,
                                children: cash(cashAfter)
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                                lineNumber: 55,
                                columnNumber: 71
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                        lineNumber: 55,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                lineNumber: 49,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("p", {
                className: "mt-2 text-muted-foreground",
                children: [
                    "Fighter pay is the larger of ",
                    /*#__PURE__*/ _jsxDEV("span", {
                        "data-boxing-guarantees": true,
                        "data-value": guarantees,
                        children: cash(guarantees)
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                        lineNumber: 57,
                        columnNumber: 78
                    }, this),
                    " in guarantees or ",
                    /*#__PURE__*/ _jsxDEV("span", {
                        "data-boxing-share": true,
                        "data-value": share,
                        children: cash(share)
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                        lineNumber: 57,
                        columnNumber: 174
                    }, this),
                    " from 58% of the gate."
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                lineNumber: 57,
                columnNumber: 7
            }, this),
            cashAfter < 0 && /*#__PURE__*/ _jsxDEV("p", {
                role: "status",
                className: "mt-2 font-semibold text-destructive",
                children: "This show would leave you below 0 and end the promotion."
            }, void 0, false, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                lineNumber: 58,
                columnNumber: 25
            }, this),
            cashAfter === 0 && /*#__PURE__*/ _jsxDEV("p", {
                role: "status",
                className: "mt-2 font-semibold",
                children: "This leaves exactly 0. Your promotion stays open, with no cash buffer."
            }, void 0, false, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
                lineNumber: 59,
                columnNumber: 27
            }, this)
        ]
    }, void 0, true, {
        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/previewWrite.tsx",
        lineNumber: 27,
        columnNumber: 5
    }, this);
}
