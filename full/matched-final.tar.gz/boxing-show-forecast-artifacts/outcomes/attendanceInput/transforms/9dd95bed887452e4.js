/**
 * Round 620: Fight Career, the sport binding on top of `careerEngine.ts`.
 *
 * Contract: `docs/design/round-620-fight-career-contract.md`.
 *
 * TWO DECISIONS TAKEN HERE RATHER THAN DISCOVERED LATE.
 *
 * 1. Every fighter in this game is generated. No real boxer is simulated,
 *    ranked, aged, damaged or beaten anywhere in it. That closes the likeness
 *    question and the invented deeds question in one move (a real name with
 *    factual stats is reporting; a real name with a fictional career is not),
 *    and it is also the only reason a custom roster is possible at all.
 * 2. There are no gambling mechanics. A boxing game drifts toward a betting
 *    screen without anybody deciding to add one. Purses and offers are
 *    contracts, not bets, and there is nothing here to wager on.
 *
 * Titles are generic and invented. No sanctioning body, promotion or real belt
 * is named, and none may be added later.
 */ import { rngFrom, hashLabel, clamp, clampi, genPersonName, declineAt, legacyTier } from '@/lib/careerEngine';
/**
 * koBias scales how often power ends a fight. It rises with the weight, which
 * is the one thing about boxing everybody already knows and the thing a player
 * will immediately call wrong if it is missing.
 */ export const WEIGHT_CLASSES = [
    {
        id: 'fly',
        label: 'Flyweight',
        lbs: 112,
        koBias: 0.62
    },
    {
        id: 'bantam',
        label: 'Bantamweight',
        lbs: 118,
        koBias: 0.7
    },
    {
        id: 'feather',
        label: 'Featherweight',
        lbs: 126,
        koBias: 0.78
    },
    {
        id: 'light',
        label: 'Lightweight',
        lbs: 135,
        koBias: 0.88
    },
    {
        id: 'welter',
        label: 'Welterweight',
        lbs: 147,
        koBias: 1
    },
    {
        id: 'middle',
        label: 'Middleweight',
        lbs: 160,
        koBias: 1.12
    },
    {
        id: 'lightheavy',
        label: 'Light Heavyweight',
        lbs: 175,
        koBias: 1.24
    },
    {
        id: 'heavy',
        label: 'Heavyweight',
        lbs: 200,
        koBias: 1.42
    }
];
export function weightById(id) {
    return WEIGHT_CLASSES.find((w)=>w.id === id) ?? WEIGHT_CLASSES[4];
}
export const STYLES = [
    {
        id: 'outboxer',
        label: 'Out-Boxer',
        blurb: 'Long, busy, and gone before you land. Wins rounds, not highlight reels.'
    },
    {
        id: 'swarmer',
        label: 'Swarmer',
        blurb: 'Lives on your chest and never stops. Drowns you in volume.'
    },
    {
        id: 'slugger',
        label: 'Slugger',
        blurb: 'Slow feet, terrible intentions. One shot ends the night.'
    },
    {
        id: 'counter',
        label: 'Counter-Puncher',
        blurb: 'Waits, reads you, and makes you pay for your own punch.'
    }
];
export const TACTICS = [
    {
        id: 'box',
        label: 'Box',
        blurb: 'Stay long, stick the jab, take the round off the aggressor.'
    },
    {
        id: 'press',
        label: 'Pressure',
        blurb: 'Walk him down and take his room away.'
    },
    {
        id: 'counter',
        label: 'Counter',
        blurb: 'Give him the first shot and punish it.'
    },
    {
        id: 'brawl',
        label: 'Brawl',
        blurb: 'Stop thinking. Throw until one of you stops.'
    }
];
/**
 * The rock paper scissors under the whole game, and the thing that makes a
 * round a decision instead of a dice roll.
 *
 *   Pressure beats an out-boxer, because you take his room.
 *   Boxing beats a swarmer, because he cannot swarm what he cannot reach.
 *   Countering beats a slugger, because he is slow and he commits.
 *   Brawling beats a counter-puncher, because he needs time to read you.
 *
 * And it closes into a cycle, so no tactic is simply the best one:
 *
 *   An out-boxer beats a brawler, a swarmer beats a counter-puncher,
 *   a slugger beats pressure, a counter-puncher beats boxing.
 */ const TACTIC_EDGE = {
    box: {
        outboxer: 0,
        swarmer: 1,
        slugger: 0,
        counter: -1
    },
    press: {
        outboxer: 1,
        swarmer: 0,
        slugger: -1,
        counter: 0
    },
    counter: {
        outboxer: 0,
        swarmer: -1,
        slugger: 1,
        counter: 0
    },
    brawl: {
        outboxer: -1,
        swarmer: 0,
        slugger: 0,
        counter: 1
    }
};
export function tacticEdge(t, against) {
    return TACTIC_EDGE[t][against];
}
/** What a fighter of each style tends to do when it is his turn to choose. */ const STYLE_HABIT = {
    outboxer: [
        'box',
        'box',
        'counter',
        'press'
    ],
    swarmer: [
        'press',
        'press',
        'brawl',
        'box'
    ],
    slugger: [
        'brawl',
        'press',
        'brawl',
        'counter'
    ],
    counter: [
        'counter',
        'counter',
        'box',
        'brawl'
    ]
};
/* Generated names. Deliberately a wide international pool, and deliberately
   ordinary rather than colourful, because a roster of nicknames reads as a
   parody within three fights. Round 876 swapped Lucas and Santiago for Leif
   and Soren: Club Manager's Brazilian rosters brought in a real Lucas Ferreira
   and a real Santiago Moreno, and simInventedNames checks every pairing. */ const FIRST = [
    'Andre',
    'Bakary',
    'Cristian',
    'Dmitri',
    'Eze',
    'Fabio',
    'Gustavo',
    'Hiroshi',
    'Ibrahim',
    'Jonas',
    'Kwame',
    'Leif',
    'Miguel',
    'Nikolai',
    'Omar',
    'Pavel',
    'Quentin',
    'Rashid',
    'Soren',
    'Tomas',
    'Ugo',
    'Viktor',
    'Wesley',
    'Yusuf',
    'Adan',
    'Beniamin',
    'Caleb',
    'Dario',
    'Emeka',
    'Farid',
    'Gideon',
    'Hassan'
];
const LAST = [
    'Abara',
    'Bellini',
    'Costa',
    'Draganov',
    'Eze',
    'Ferreira',
    'Gallo',
    'Haddad',
    'Ibori',
    'Jovanovic',
    'Kowalski',
    'Laurent',
    'Moreno',
    'Nakamura',
    'Oyelaran',
    'Petrov',
    'Quintero',
    'Rivas',
    'Salgado',
    'Toure',
    'Ubaldi',
    'Varga',
    'Wolde',
    'Yilmaz',
    'Zadrozny',
    'Brandao',
    'Cisse',
    'Delgado',
    'Farkas',
    'Guerrero'
];
/**
 * Round 916: one generated name off the two banks above, for everybody in the
 * life layer who is not a fighter (the trainer, the manager) and for the
 * rival, who is. Drawing them here keeps every invented name in this game on
 * the one pair of banks scripts/simInventedNames.mjs already checks.
 */ export function genFighterName(rng) {
    return genPersonName(rng, FIRST, LAST);
}
/*
 * Round 1546: A FIGHTER'S ID NEVER COMES FROM MODULE STATE.
 *
 * Until this round every id was "f" plus a counter that lived in this module.
 * The counter went back to 0 on every page load while the gym's roster and the
 * promoter's pool kept the ids it had handed out before, so after a reload the
 * next man minted wore an id a saved man already had: the man you clicked was
 * not always the man who fought, his training went to the other one, and
 * letting one man go let both go. Round 568's bug (src/lib/entityIds.ts) in
 * the three fight games.
 *
 * Two kinds of caller, two answers, and neither touches the rng, so every draw
 * is the draw it was. Fight Gym and Fight Promoter keep their men for months,
 * so they pass an id minted off their own save (mintFighterId below), unique by
 * construction. Fight Career keys nothing on a fighter id (an opponent belongs
 * to one offer, the daily is two men), so when no id is passed the man is
 * named by what was drawn for him.
 */ function drawnId(f) {
    const a = f.attrs;
    const key = [
        f.name,
        f.style,
        a.power,
        a.chin,
        a.speed,
        a.stamina,
        a.defence,
        a.ringIq,
        f.age,
        f.potential
    ].join('|');
    return `x${hashLabel(key).toString(36)}`;
}
/**
 * Round 1546: the next id off a save's own counter. The counter is written into
 * the save beside the men, so a reload carries on from it rather than from 0,
 * and the save's seed is part of the id, so two saves never mint the same id
 * and the division (read off the id) is not the same first man in every gym.
 * The prefix is never "f", so no id minted here can equal an id minted before
 * this round. It writes the counter on the book it is handed, which is always
 * the fresh state the caller is building, as stream() does with rngTick.
 *
 * Numbers start at 10, so a new promotion's first ten men all carry ids of
 * one length. The division is a hash of the id, and over ten ids of one
 * length it lands on ten classes in a row, which is the spread every new
 * promotion has always opened with: two pairs who can be matched on the first
 * card. Starting at 1 crossed from "-9" to "-10" inside the first ten and left
 * one new promotion in four (measured, 2000 names) with a single legal pair.
 */ export const FIRST_FIGHTER_NO = 10;
export function mintFighterId(book, prefix) {
    const stored = book.nextFighterNo;
    const n = typeof stored === 'number' && Number.isInteger(stored) && stored >= 1 ? stored : FIRST_FIGHTER_NO;
    book.nextFighterNo = n + 1;
    return `${prefix}${(book.seed >>> 0).toString(36)}-${n}`;
}
/**
 * Round 1546: a gym or promotion man's division. It is read off his id, as it
 * always has been (a gym has men at several classes and a Round 620 fighter
 * stores none), except for a man whose id was repaired: he keeps the class he
 * was showing, stored on him at the repair.
 */ export function fighterClass(f) {
    if (f.weight !== undefined && WEIGHT_CLASSES.some((w)=>w.id === f.weight)) return f.weight;
    return WEIGHT_CLASSES[Math.abs(hashLabel(f.id)) % WEIGHT_CLASSES.length].id;
}
/**
 * Round 1546: the repair, for a save written before the fix. FIRST HOLDER WINS,
 * Round 568's rule (ensureUniqueIds in src/lib/entityIds.ts), written out here
 * rather than imported because the fight harnesses bundle these engine files
 * on their own. The earlier man keeps the id, and with it the training and the
 * bookings already written against it; only the man shadowing him moves, to a
 * fresh id off the save's counter, and he keeps the division he was showing.
 * The counter is first lifted above every id the save already minted, so a
 * hand edited or damaged counter cannot mint an id somebody wears. Returns new
 * lists and never edits the men it was handed; the book's counter is updated.
 */ export function repairFighterIds(book, prefix, lists) {
    const head = `${prefix}${(book.seed >>> 0).toString(36)}-`;
    let top = 0;
    for (const list of lists){
        for (const f of list){
            if (!f || typeof f.id !== 'string' || !f.id.startsWith(head)) continue;
            const n = Number(f.id.slice(head.length));
            if (Number.isInteger(n) && n > top) top = n;
        }
    }
    const stored = book.nextFighterNo;
    const storedOk = typeof stored === 'number' && Number.isInteger(stored) && stored > top;
    if (!storedOk && (stored !== undefined || top > 0)) book.nextFighterNo = Math.max(top + 1, FIRST_FIGHTER_NO);
    const seen = new Set();
    let moved = 0;
    const out = lists.map((list)=>list.map((f)=>{
            if (!f) return f;
            const named = typeof f.id === 'string' && f.id !== '';
            if (named && !seen.has(f.id)) {
                seen.add(f.id);
                return f;
            }
            const shown = named ? fighterClass(f) : undefined;
            const fixed = {
                ...f,
                id: mintFighterId(book, prefix)
            };
            if (shown) fixed.weight = shown;
            seen.add(fixed.id);
            moved += 1;
            return fixed;
        }));
    return {
        lists: out,
        moved
    };
}
/**
 * A generated fighter at a quality tier.
 *
 * `tier` runs 0 (club fighter) to 100 (the best in the world). Attributes are
 * drawn around it and then pulled apart by the style, so an out-boxer really
 * is quicker and a slugger really does hit harder at the same tier. Without
 * that the styles would be labels on identical men.
 *
 * Round 1546: `id` is the caller's (a gym or a promotion mints one off its
 * save). Without one the man is named by what was drawn for him, never by a
 * counter in this module.
 */ export function makeFighter(rng, tier, weight, style, id) {
    const st = style ?? STYLES[Math.floor(rng() * STYLES.length)].id;
    const base = clamp(tier, 20, 99);
    const jitter = ()=>(rng() - 0.5) * 10;
    const shape = {
        outboxer: {
            speed: 8,
            defence: 7,
            ringIq: 6,
            power: -10,
            chin: -3
        },
        swarmer: {
            stamina: 10,
            power: 2,
            chin: 5,
            defence: -9,
            ringIq: -3
        },
        slugger: {
            power: 13,
            chin: 4,
            speed: -9,
            stamina: -6,
            defence: -4
        },
        counter: {
            ringIq: 11,
            defence: 8,
            speed: 3,
            stamina: -5,
            power: -2
        }
    };
    const s = shape[st];
    const mk = (k)=>clampi(base + (s[k] ?? 0) + jitter(), 15, 99);
    const drawn = {
        name: genPersonName(rng, FIRST, LAST),
        style: st,
        attrs: {
            power: mk('power'),
            chin: mk('chin'),
            speed: mk('speed'),
            stamina: mk('stamina'),
            defence: mk('defence'),
            ringIq: mk('ringIq')
        },
        age: clampi(21 + rng() * 12, 19, 37),
        wins: 0,
        losses: 0,
        draws: 0,
        kos: 0,
        damage: 0,
        rank: 99,
        potential: clampi(base + 10 + rng() * 16, 30, 99)
    };
    return {
        id: id ?? drawnId(drawn),
        ...drawn
    };
}
/**
 * What a fighter actually brings tonight, once age and accumulated damage are
 * taken out of him.
 *
 * Damage hits the chin hardest, which is the honest version of what happens to
 * a fighter who has been in wars, and it is what makes an early war expensive
 * later rather than immediately. It never touches ring IQ: the one thing a
 * beaten up veteran keeps is knowing what he is doing.
 */ export function effectiveAttrs(f) {
    const age = declineAt(f.age, 28, 31);
    const d = f.damage;
    const chinLoss = Math.min(38, d * 0.55);
    const staminaLoss = Math.min(24, d * 0.3);
    const speedLoss = Math.min(20, d * 0.22);
    return {
        power: clampi(f.attrs.power * clamp(age + 0.04, 0.5, 1), 10, 99),
        chin: clampi(f.attrs.chin * age - chinLoss, 5, 99),
        speed: clampi(f.attrs.speed * age - speedLoss, 8, 99),
        stamina: clampi(f.attrs.stamina * age - staminaLoss, 8, 99),
        defence: clampi(f.attrs.defence * age, 8, 99),
        ringIq: clampi(f.attrs.ringIq * clamp(age + 0.08, 0.6, 1.06), 10, 99)
    };
}
/** One number for "how good is he right now", used for matchmaking and ranking. */ export function ratingOf(f) {
    const a = effectiveAttrs(f);
    return Math.round(a.power * 0.2 + a.chin * 0.14 + a.speed * 0.18 + a.stamina * 0.14 + a.defence * 0.16 + a.ringIq * 0.18);
}
/* ───────────────── what the fight screen shows, Round 628 ─────────────────
   The bout already produced everything a viewer needs: punches landed both
   ways, knockdowns, a scored card. It was rendered as a list of sentences, so
   a twelve round war and a shutout read almost the same. These two bars are
   the fix, and they live HERE rather than in the component for one reason:
   a number computed inside a React render cannot be measured by a harness,
   and an unmeasured bar is decoration that is free to lie. */ /** How much condition one landed punch costs the man who took it. */ export const DRAIN_PER_PUNCH = 0.8;
/** What going down costs on top of the punches, which is most of a round. */ export const DRAIN_PER_KNOCKDOWN = 10;
/** A man still on his feet never reads empty, however wide the fight got. */ export const STANDING_FLOOR = 8;
/** Below this the bar stops draining in a straight line and eases toward the floor. */ export const SOFT_FLOOR_FROM = 40;
/**
 * Round 636: what a man's bar reads after he has soaked up `drain` points of
 * punishment, for a man still on his feet.
 *
 * WHY THIS IS A CURVE AND NOT A CLAMP. Round 628 drained the bar in a straight
 * line and clamped it at the floor. That clamp was the defect. A straight
 * line runs out at 92 points of drain, 115 punches, and the men a good player
 * beats on points soak up far more than that: over eight seed bases of real
 * careers played with three looks that each answer what the opponent will
 * switch to (the game's own hint), the decision loser's drain sits at 77 to 80
 * at the median, 144 to 148 at p90 and 172 to 179 at p99. So 29 to 34 percent
 * of those losers read the floor, the same as a man who barely got through
 * and within a sliver of a man who was stopped. Random tactics, which is all
 * Round 628 measured, pinned 11 to 13 percent.
 *
 * The drain rate was not the lever. The damage behind it is sound: it is the
 * punches the engine landed, and none of this feeds lasting damage, which
 * comes from simBout's damageTaken. A slower straight line would still clip,
 * just later: at 0.6 a punch a good player's losers still pin 19 to 23
 * percent, and holding their p99 off the floor in a straight line takes about
 * 0.4, which lifts a random decision loser's median from 30 to about 64 and
 * erases the gap the bar exists to show.
 *
 * So the bar reads exactly as Round 628 drew it down to SOFT_FLOOR_FROM, and
 * below that it keeps falling for every extra punch but ever more slowly, and
 * it never reaches the floor. The tail has the same slope as the line where
 * they meet, so there is no visible kink. Measured on the same bouts: a
 * decision loser reads the floor in 0 to 0.1 percent of fights for the good
 * player and the weak one, 0 to 0.4 for random tactics and 0.6 to 0.9 for a
 * player who holds one answer all night, and the median random loser reads 31
 * or 32 where it read 29 or 30. Above 40 nothing a Round 628 bar showed has
 * changed, and nothing about the fight has: the bouts, the cards and the
 * damage are the same numbers, only the drawing of them moved.
 *
 * What it costs, said plainly: a good player's worst beaten men now crowd
 * into 9 to 12 rather than sitting on 8. About a fifth of his decision losers
 * read there (18.7 to 22.8 percent over the same eight bases), every one of
 * them a man who took over 120 points of drain, which is about 150 punches,
 * or fewer with a knockdown among them. That is the bar saying he barely made
 * the bell, which is true, and each of those readings is still a visible
 * sliver and a number above 0, which a stopped man never gets.
 */ export function conditionShown(drain) {
    const straight = 100 - drain;
    if (straight >= SOFT_FLOOR_FROM) return straight;
    const span = SOFT_FLOOR_FROM - STANDING_FLOOR;
    return STANDING_FLOOR + span * Math.exp((straight - SOFT_FLOOR_FROM) / span);
}
/**
 * Condition after each round, 100 down to 0, for both men.
 *
 * THE RATE IS MEASURED, NOT CHOSEN, AND IT MUST BE MEASURED ON BOUTS THE GAME
 * ACTUALLY PRODUCES. Over 7,233 bouts played through real careers, real offers
 * and real camps: a man lands 7.4 punches a round on average, a decision
 * winner absorbs 51 across the fight at the median and a decision loser
 * absorbs 82, with the loser's p90 at 108.
 *
 * THE MISTAKE THAT COST THIS TWICE, written down because the harness did not
 * catch it and the browser did. The first calibration sampled fighters built
 * straight from makeFighter at tiers 2 to 4, which gave 2.9 landed a round and
 * a rate of 1.6. Section 6 passed at 89.5 percent agreement because it drew
 * its bouts the same wrong way, so the check and the constant agreed with each
 * other and neither agreed with the game. Opening the page showed both men on
 * 10 and 8 after a ten round decision, every bar pinned, because real rounds
 * land two and a half times as many punches as the sample did. A harness that
 * samples a population the player never meets will confirm anything.
 *
 * The rate is set from the loser's p90: 85 points of drain over 108 punches is
 * 0.787, rounded to 0.8. That puts the median decision winner near 59 and the
 * median loser near 34, a gap you can see across a room.
 *
 * Round 628 said that also kept the floor rare. It did, for random tactics,
 * which is all it sampled, and for nobody who plays well: a player who reads
 * every fight left 29 to 34 percent of his decision losers on the floor. The
 * floor is kept rare by conditionShown now, not by the rate. See it above.
 *
 * The bar is not meant to agree with the cards every time. A man can win on
 * points while taking more punishment than he handed out, and a bar that
 * always matched the card would be drawing the card rather than the fight.
 *
 * The one hard claim, which `simFightCareer` section 6 asserts: a man who was
 * stopped ends at exactly 0 and a man still standing never does. The bar is
 * allowed to be approximate about how worn somebody looks. It is not allowed
 * to be wrong about whether he is still in the fight.
 */ export function conditionTrack(res) {
    const stoppage = res.method === 'KO' || res.method === 'TKO';
    const loser = res.winner === 'player' ? 'opp' : res.winner === 'opp' ? 'player' : null;
    let playerDrain = 0;
    let oppDrain = 0;
    const out = [];
    res.rounds.forEach((r, i)=>{
        /* knockdown: 'player' means the PLAYER scored it, so the OPPONENT went
       down. That reading is the engine's, see simBout where pDrops sets
       knockdown to 'player' and increments oppHurt. Getting it backwards
       would drain the wrong bar on the most visible moment in the fight. */ playerDrain += r.oppLanded * DRAIN_PER_PUNCH + (r.knockdown === 'opp' ? DRAIN_PER_KNOCKDOWN : 0);
        oppDrain += r.playerLanded * DRAIN_PER_PUNCH + (r.knockdown === 'player' ? DRAIN_PER_KNOCKDOWN : 0);
        /* Drain only ever grows and conditionShown only ever falls as it grows,
       so a bar can never climb back up between rounds. */ const player = conditionShown(playerDrain);
        const opp = conditionShown(oppDrain);
        const last = i === res.rounds.length - 1;
        out.push({
            round: r.round,
            player: stoppage && last && loser === 'player' ? 0 : Math.round(player),
            opp: stoppage && last && loser === 'opp' ? 0 : Math.round(opp)
        });
    });
    return out;
}
function habitTactic(style, rng) {
    const list = STYLE_HABIT[style];
    return list[Math.floor(rng() * list.length)];
}
/** The style that punishes a given tactic, which is the cycle read backwards. */ const STYLE_THAT_BEATS = {
    box: 'counter',
    press: 'slugger',
    counter: 'swarmer',
    brawl: 'outboxer'
};
/**
 * What the opponent is actually doing THIS round, which is not always what he
 * is known for.
 *
 * Round 620, and this is the fix that turned the game into a game. In the first
 * draft a fighter's style was fixed for the whole bout, so a player who read it
 * once could pick the answering tactic every round for the rest of his career
 * and never be punished for it. Measured: 98.5 percent of careers won a world
 * title, and the correct strategy was to choose one tactic and never think
 * again. A ring IQ of any worth adjusts to a man who keeps doing the same
 * thing, so a smart opponent switches into the style that punishes whatever you
 * did last round. The counter to that is to vary, which is the decision the
 * round is supposed to contain.
 */ function oppStance(opp, lastPlayerTactic, rng) {
    if (!lastPlayerTactic) return opp.style;
    const iq = effectiveAttrs(opp).ringIq;
    return rng() < 0.1 + iq / 100 * 0.5 ? STYLE_THAT_BEATS[lastPlayerTactic] : opp.style;
}
/** Fatigue late in a fight, scaled by stamina. A gassed fighter stops landing. */ function freshnessAt(round, total, stamina, camp) {
    const through = round / Math.max(1, total);
    const tank = 0.55 + stamina / 100 * 0.45 + camp * 0.1;
    return clamp(1 - Math.max(0, through - tank) * 1.35, 0.45, 1);
}
/**
 * Simulate a bout round by round.
 *
 * Deterministic for a given rng, which is what lets the harness measure policy
 * outcomes over thousands of careers and what lets the daily hand everybody the
 * same fight.
 */ export function simBout(input, rng) {
    const { player, opponent, rounds, weight } = input;
    const camp = clamp(input.campQuality ?? 0.5, 0, 1);
    const pa = effectiveAttrs(player);
    const oa = effectiveAttrs(opponent);
    const koBias = weightById(weight).koBias;
    const log = [];
    let playerCard = 0;
    let oppCard = 0;
    let damageTaken = 0;
    let damageDealt = 0;
    let roundsWon = 0;
    let stopped = null;
    let endedRound = rounds;
    /* Hurt carries between rounds: a man dropped in round 4 is easier to drop in
     round 5. Without this a knockdown is a scoring event and nothing more. */ let playerHurt = 0;
    let oppHurt = 0;
    /* What you did last round is public information to the man in front of you. */ let lastPlayerTactic = null;
    for(let r = 1; r <= rounds; r += 1){
        /* The plan CYCLES rather than holding its last entry, so a three tactic
       game plan is a rotation and not "two rounds then the same thing for the
       next ten". Against an opponent who adjusts to what you did last round,
       holding one tactic is the worst thing a player can do, and a screen that
       asks for three tactics should not quietly turn them into one. */ const tactic = input.tactics.length ? input.tactics[(r - 1) % input.tactics.length] : 'box';
        const stance = oppStance(opponent, lastPlayerTactic, rng);
        const switched = stance !== opponent.style;
        const oppTactic = habitTactic(stance, rng);
        const edge = tacticEdge(tactic, stance) - tacticEdge(oppTactic, player.style);
        const pFresh = freshnessAt(r, rounds, pa.stamina, camp);
        const oFresh = freshnessAt(r, rounds, oa.stamina, 0.5);
        const pOut = (pa.speed * 0.34 + pa.ringIq * 0.33 + pa.power * 0.33) * pFresh;
        const oOut = (oa.speed * 0.34 + oa.ringIq * 0.33 + oa.power * 0.33) * oFresh;
        const pLanded = Math.max(0, Math.round((pOut - oa.defence * 0.45) / 4.2 + edge * 2.6 + oppHurt * 1.8 + (rng() - 0.5) * 5));
        const oLanded = Math.max(0, Math.round((oOut - pa.defence * 0.45) / 4.2 - edge * 2.6 + playerHurt * 1.8 + (rng() - 0.5) * 5));
        /* A knockdown needs power against a chin, and the tactical edge is what
       creates the opening. Scaled by the weight class, because a flyweight
       war and a heavyweight war do not end the same way. */ const pKd = clamp((pa.power - oa.chin + 18 + edge * 9 + oppHurt * 12) / 460, 0, 0.42) * koBias;
        const oKd = clamp((oa.power - pa.chin + 18 - edge * 9 + playerHurt * 12) / 460, 0, 0.42) * koBias;
        const pDrops = rng() < pKd;
        const oDrops = !pDrops && rng() < oKd;
        let ps = 10;
        let os = 10;
        let knockdown = null;
        if (pDrops) {
            knockdown = 'player';
            os = 8;
            oppHurt += 1;
        } else if (oDrops) {
            knockdown = 'opp';
            ps = 8;
            playerHurt += 1;
        }
        if (!knockdown) {
            if (pLanded > oLanded) os = 9;
            else if (oLanded > pLanded) ps = 9;
            else if (rng() < 0.5) os = 9;
            else ps = 9;
        } else if (knockdown === 'player') {
            ps = 10;
        } else {
            os = 10;
        }
        playerCard += ps;
        oppCard += os;
        if (ps > os) roundsWon += 1;
        /* Round 620: these factors are measured, not chosen. The first draft used
       0.16, which put roughly 25 damage on a fighter per bout and retired every
       career of every policy pinned at the damage ceiling inside nine fights.
       That did not make the game hard, it deleted the decision: when every
       road ends in the same place at the same time, the choice between them is
       decoration. At 0.022 a quiet night costs about 2 and a war costs about 6,
       so a ceiling of 82 is a career of roughly 25 to 40 fights and the
       difference between the two roads is visible in the record. */ damageTaken += oLanded * 0.022 + (oDrops ? 1.2 : 0);
        damageDealt += pLanded * 0.022 + (pDrops ? 1.2 : 0);
        log.push({
            round: r,
            tactic,
            oppTactic,
            stance,
            switched,
            playerLanded: pLanded,
            oppLanded: oLanded,
            playerScore: ps,
            oppScore: os,
            knockdown,
            note: knockdown === 'player' ? `${opponent.name} is down.` : knockdown === 'opp' ? 'You are down.' : switched ? 'He has changed how he is fighting.' : edge > 0 ? 'The tactic is working.' : edge < 0 ? 'He has your number this round.' : ''
        });
        lastPlayerTactic = tactic;
        /* A second knockdown in the same fight, against a man already hurt, ends
       it. Three is always over. */ if (oppHurt >= 2 && rng() < 0.55 + oppHurt * 0.12) {
            stopped = 'player';
            endedRound = r;
            break;
        }
        if (playerHurt >= 2 && rng() < 0.55 + playerHurt * 0.12) {
            stopped = 'opp';
            endedRound = r;
            break;
        }
    }
    if (stopped) {
        const hurt = stopped === 'player' ? oppHurt : playerHurt;
        return {
            rounds: log,
            winner: stopped,
            method: hurt >= 3 ? 'KO' : 'TKO',
            endedRound,
            playerCard,
            oppCard,
            damageTaken,
            damageDealt,
            roundsWon
        };
    }
    let winner;
    let method;
    const gap = playerCard - oppCard;
    if (gap === 0) {
        winner = 'draw';
        method = 'D';
    } else {
        winner = gap > 0 ? 'player' : 'opp';
        const margin = Math.abs(gap);
        method = margin >= 5 ? 'UD' : margin >= 3 ? 'MD' : 'SD';
    }
    return {
        rounds: log,
        winner,
        method,
        endedRound,
        playerCard,
        oppCard,
        damageTaken,
        damageDealt,
        roundsWon
    };
}
const CAMP_WEEKS = 6;
/**
 * Round 916: what a camp is worth to one attribute before it is rounded onto
 * the fighter. Lifted out of runCamp unchanged so the life layer can bank the
 * fraction a specialist trainer adds without carrying a second copy of this
 * sum. Growth against headroom, never flat: see runCamp.
 */ export function campGain(cur, potential, weeks) {
    const headroom = clamp((potential - cur) / 22, 0, 1);
    return weeks / CAMP_WEEKS * 2.4 * headroom;
}
/** Round 916: the fighter as he is on one sharpened (or blunted) night. */ function sharpened(f, sharp) {
    const s = Math.round(sharp);
    if (!s) return f;
    const up = (v)=>clampi(v + s, 15, 99);
    return {
        ...f,
        attrs: {
            ...f.attrs,
            power: up(f.attrs.power),
            speed: up(f.attrs.speed),
            stamina: up(f.attrs.stamina),
            defence: up(f.attrs.defence)
        }
    };
}
export function newFightCareer(name, weight, style, seedLabel) {
    const seed = hashLabel(seedLabel ?? `${name}|${weight}|${style}`);
    const rng = rngFrom(seed);
    const me = makeFighter(rng, 52, weight, style);
    me.name = name.trim() || me.name;
    me.age = 21;
    me.rank = 99;
    const st = {
        version: 1,
        fighter: me,
        weight,
        fightNo: 0,
        champion: false,
        titleDefences: 0,
        earnings: 0,
        history: [],
        retired: false,
        offers: [],
        camp: null,
        campQuality: 0.5,
        rngTick: 0,
        seed,
        log: [
            'You turn professional. Nobody is watching yet.'
        ]
    };
    st.offers = offersFor(st);
    return st;
}
/** The generator for this save, advanced past whatever has already happened. */ function streamFor(st) {
    const rng = rngFrom(st.seed + st.rngTick * 7919);
    return {
        rng,
        done: (used)=>{
            st.rngTick += Math.max(1, used);
        }
    };
}
/**
 * Three offers, and they are the central decision of the game.
 *
 * A tune up is safe, pays little and barely moves you. A step up pays and
 * ranks you fast and can take years off the end of your career. The middle one
 * is the honest fight. Damage is permanent, so the player is always choosing
 * between the career he has now and the one he will have at 33.
 */ export function offersFor(st) {
    const { rng, done } = streamFor(st);
    const mine = ratingOf(st.fighter);
    const rank = st.champion ? 0 : st.fighter.rank;
    const out = [];
    /* Round 620: three situations, not two.
     The first draft had only champion and climbing, and pinned the title shot
     to the most dangerous offer slot. A player who climbed patiently reached
     the number one ranking and was then never offered the fight, because his
     policy never picked that slot: 260 careers produced zero titles. Being the
     mandatory challenger is not a fight you go looking for, it is one you have
     earned, so at number one EVERY offer on the table is for the belt and the
     only question left is which champion you take. */ const contender = !st.champion && rank <= 1;
    const shapes = st.champion ? [
        {
            label: 'Voluntary defence',
            delta: -8,
            pay: 1.5,
            gain: 0,
            rounds: 12
        },
        {
            label: 'Mandatory challenger',
            delta: 2,
            pay: 2.4,
            gain: 0,
            rounds: 12
        },
        {
            label: 'Unification',
            delta: 7,
            pay: 4.2,
            gain: 0,
            rounds: 12
        }
    ] : contender ? [
        {
            label: 'Vacant title',
            delta: -2,
            pay: 2,
            gain: 0,
            rounds: 12
        },
        {
            label: 'Champion away from home',
            delta: 4,
            pay: 3,
            gain: 0,
            rounds: 12
        },
        {
            label: 'Undisputed champion',
            delta: 9,
            pay: 4.6,
            gain: 0,
            rounds: 12
        }
    ] : [
        {
            label: 'Tune up',
            delta: -11,
            pay: 0.35,
            gain: 1,
            rounds: 8
        },
        {
            label: 'Even money',
            delta: 1,
            pay: 1,
            gain: 3,
            rounds: 10
        },
        {
            label: 'Step up',
            delta: 9,
            pay: 2.1,
            gain: 6,
            rounds: 10
        }
    ];
    for (const s of shapes){
        /* Round 620: a world champion is one of the best fighters alive, not simply
       a little better than whoever is in front of him. Drawing him relative to
       the challenger made the belt track the player's own level, so climbing to
       number one was the whole difficulty and the title fight itself was a
       formality: 86 percent of patient careers walked in and took it. A title
       opponent is therefore drawn near the top of the sport in absolute terms,
       and the relative figure only applies when it is higher still. */ const titleFight = st.champion || contender;
        const relative = clamp(mine + s.delta, 25, 97);
        const opp = makeFighter(rng, titleFight ? Math.max(relative, 80 + rng() * 15) : relative, st.weight);
        opp.age = clampi(23 + rng() * 12, 20, 38);
        const fame = st.champion ? 5.5 : clamp((16 - Math.min(rank, 16)) / 3.4, 0.35, 4.6);
        const purse = Math.round((0.05 + fame * 0.16) * s.pay * 100) / 100;
        out.push({
            id: `o${st.fightNo}-${out.length}`,
            opponent: opp,
            purse,
            rounds: s.rounds,
            rankGain: s.gain,
            title: st.champion || contender,
            label: s.label
        });
    }
    done(12);
    return out;
}
/**
 * Six camp weeks across four areas. Overloading one area buys a sharp edge in
 * it and a flat fighter everywhere else, which is the tradeoff the screen has
 * to make legible before the player commits.
 */ export function runCamp(st, plan) {
    const total = plan.conditioning + plan.power + plan.defence + plan.speed;
    const weeks = clamp(total, 0, CAMP_WEEKS);
    const spread = weeks === 0 ? 0 : 1 - Math.max(plan.conditioning, plan.power, plan.defence, plan.speed) / Math.max(1, weeks);
    const next = {
        ...st,
        fighter: {
            ...st.fighter,
            attrs: {
                ...st.fighter.attrs
            }
        }
    };
    /* Growth against headroom, never flat. A camp is worth a lot to a raw
     fighter and almost nothing to one already at his ceiling, and it can never
     take him past it. Headroom reaches zero at the ceiling, so this can only
     ever raise an attribute and never lower one a fighter was generated with. */ const pot = next.fighter.potential;
    const grow = (cur, weeks)=>clampi(cur + campGain(cur, pot, weeks), 15, 99);
    next.fighter.attrs.stamina = grow(next.fighter.attrs.stamina, plan.conditioning);
    next.fighter.attrs.power = grow(next.fighter.attrs.power, plan.power);
    next.fighter.attrs.defence = grow(next.fighter.attrs.defence, plan.defence);
    next.fighter.attrs.speed = grow(next.fighter.attrs.speed, plan.speed);
    next.camp = plan;
    /* A balanced camp leaves a fighter ready everywhere; a lopsided one leaves
     him sharp in one thing and short of gas. */ next.campQuality = clamp(0.25 + weeks / CAMP_WEEKS * 0.5 + spread * 0.32, 0, 1);
    return next;
}
export function takeFight(st, offerId, tactics, mods) {
    if (st.retired) return null;
    const offer = st.offers.find((o)=>o.id === offerId);
    if (!offer) return null;
    const { rng, done } = streamFor(st);
    const fought = simBout({
        player: mods?.sharp ? sharpened(st.fighter, mods.sharp) : st.fighter,
        opponent: offer.opponent,
        rounds: offer.rounds,
        weight: st.weight,
        tactics,
        campQuality: st.campQuality
    }, rng);
    /* Round 916: the cut man works on the result, so the number the screen
     shows as taken tonight is the number that is kept. */ const result = mods?.damageMul === undefined ? fought : {
        ...fought,
        damageTaken: Math.round(fought.damageTaken * mods.damageMul * 100) / 100
    };
    done(offer.rounds * 6 + 4);
    return {
        state: applyResult(st, offer, result),
        result,
        offer
    };
}
export function applyResult(st, offer, res) {
    const f = {
        ...st.fighter,
        attrs: {
            ...st.fighter.attrs
        }
    };
    const next = {
        ...st,
        fighter: f,
        history: [
            ...st.history
        ],
        log: [
            ...st.log
        ]
    };
    f.damage = Math.round((f.damage + res.damageTaken) * 10) / 10;
    next.fightNo += 1;
    /* Fighters age on the calendar, not on wins. Roughly three fights a year is
     an active career, so age moves a third of a year per fight. */ f.age = Math.round((f.age + 0.34) * 100) / 100;
    const won = res.winner === 'player';
    const drew = res.winner === 'draw';
    if (won) f.wins += 1;
    else if (drew) f.draws += 1;
    else f.losses += 1;
    if (won && (res.method === 'KO' || res.method === 'TKO')) f.kos += 1;
    if (offer.title) {
        if (won) {
            if (st.champion) next.titleDefences += 1;
            else {
                next.champion = true;
                f.rank = 0;
                next.titleDefences = 0;
            }
        } else if (!drew && st.champion) {
            next.champion = false;
            f.rank = 2;
        }
    } else if (won) {
        /* Round 620: beating a man well below you proves nothing once you are
       ranked, and the game has to say so or the safe road is simply the best
       road. Measured before this existed: a policy of nothing but tune ups ran
       47 fights, climbed to number one on volume alone and took the title, and
       beat every other policy by 81 legacy points. Padding a record is a real
       thing fighters do and it is supposed to stall, not win. */ const gap = ratingOf(offer.opponent) - ratingOf(st.fighter);
        const cur = f.rank === 99 ? 20 : f.rank;
        const earned = cur <= 10 && gap < -6 ? 0 : offer.rankGain;
        f.rank = clampi(Math.min(cur, 20) - earned, 1, 99);
    } else if (!drew) {
        f.rank = clampi((f.rank === 99 ? 20 : f.rank) + 4, 1, 99);
    }
    next.earnings = Math.round((next.earnings + offer.purse) * 100) / 100;
    next.history.push({
        no: next.fightNo,
        opponent: offer.opponent.name,
        result: won ? 'W' : drew ? 'D' : 'L',
        method: res.method,
        round: res.endedRound,
        rounds: offer.rounds,
        purse: offer.purse,
        title: offer.title,
        oppRating: ratingOf(offer.opponent),
        myRating: ratingOf(st.fighter)
    });
    next.log.unshift(`${won ? 'Beat' : drew ? 'Drew with' : 'Lost to'} ${offer.opponent.name} by ${res.method}` + `${res.method === 'KO' || res.method === 'TKO' ? ` in round ${res.endedRound}` : ''}.`);
    next.camp = null;
    next.campQuality = 0.5;
    next.retired = shouldRetire(next);
    next.offers = next.retired ? [] : offersFor(next);
    return next;
}
/**
 * When a fighter is finished.
 *
 * Damage is the first clause and it is the one that matters: a man who took
 * every war is done years before a man who did not, which is the entire point
 * of the tradeoff the offers present.
 */ export function shouldRetire(st) {
    const f = st.fighter;
    if (f.age >= 41) return true;
    if (f.damage >= 82) return true;
    if (f.age >= 35 && f.damage >= 58) return true;
    /* Three straight losses and no ranking left is the end of a career whatever
     the birth certificate says. */ const last3 = st.history.slice(-3);
    if (last3.length === 3 && last3.every((h)=>h.result === 'L') && f.rank > 12) return true;
    return false;
}
/**
 * Round 1546: HANGING THEM UP. Until this round a career ended only when
 * shouldRetire said so, so a champion who wanted to go out on top could not,
 * and the hub's only exit wiped the save with no verdict. This is the
 * family's exit shape (canSellGym and sellGym in fightGym.ts, canHandOver and
 * handOver in fightPromoter.ts): a gate, then the same verdict the body would
 * have given, read off the same record.
 *
 * The gate is a number of fights, as the gym's is weeks and the promoter's is
 * shows. Below it a short perfect record could be banked before anybody good
 * was ever met. scripts/simFightCareerRetire.mjs measures what the gate buys:
 * a walkaway at the gate is a Footnote 95 to 97 percent of the time, and the
 * same careers walked away from ten fights later score 3.8 to 5.2 more, so
 * the earliest door is never the best one and the gate is a door and not a
 * trick. It does NOT score under playing a career out to the end: the decline
 * years cost legacy, so stopping on your own terms is a real choice.
 */ export const RETIRE_MIN_FIGHTS = 10;
export function canRetire(st) {
    return !st.retired && st.fightNo >= RETIRE_MIN_FIGHTS;
}
export function retireByChoice(st) {
    if (!canRetire(st)) return null;
    const f = st.fighter;
    return {
        ...st,
        retired: true,
        retiredBy: 'choice',
        offers: [],
        camp: null,
        campQuality: 0.5,
        log: [
            `You hang them up after ${st.fightNo} fights, ${f.wins} and ${f.losses}${f.draws ? ` and ${f.draws}` : ''}.`,
            ...st.log
        ]
    };
}
export function legacyOf(st) {
    const f = st.fighter;
    const titleWins = st.history.filter((h)=>h.title && h.result === 'W').length;
    /* A win over a man at least as good as you were that night. Judged on rating
     rather than money, for the reason recorded on FightLine.oppRating. */ const bigWins = st.history.filter((h)=>h.result === 'W' && h.oppRating >= h.myRating - 3).length;
    /* Round 620: titles carry this, not volume.
     The first weighting paid 1.5 a win, so a long quiet career of beating
     nobodies scored 94 out of 100 and rated as an all time great while never
     fighting anyone. What a fighter is remembered for is who he beat and what
     he won, so a win is worth little on its own and a world title is worth
     about eighteen of them. */ /* Stoppages of men worth stopping. Counting all knockouts rewarded a padded
     record twice over, once through the win rate and again through the finishes
     it produced, which is how a career of beating nobodies out-scored a career
     of beating contenders. */ const qualityKos = st.history.filter((h)=>h.result === 'W' && (h.method === 'KO' || h.method === 'TKO') && h.oppRating >= h.myRating - 3).length;
    const total = f.wins + f.losses + f.draws;
    const winPct = total ? f.wins / total : 0;
    const score = clampi(/* A clean record counts for something, but only something. An unbeaten
       fighter who never met anybody is a trivia answer, not a great. */ 18 * winPct + /* Who you beat. A win over somebody worth paying for is worth something and
       a win over a late replacement is not, which is why this counts purse
       rather than wins. Counting raw wins paid a long quiet career of beating
       nobodies 94 out of 100, and then subtracting losses at nearly twice a
       win's value scored an honest even record at zero. Both were wrong in the
       same way: they measured how many nights, not what happened on them. */ bigWins * 2.4 + qualityKos * 0.6 + titleWins * 12 + st.titleDefences * 7 - Math.max(0, f.damage - 50) * 0.22, 0, 100);
    const { tier, hof } = legacyTier(score);
    const bullets = [
        `${f.wins} and ${f.losses}${f.draws ? ` and ${f.draws}` : ''}, with ${f.kos} inside the distance.`
    ];
    if (titleWins) bullets.push(`${titleWins} world title win${titleWins > 1 ? 's' : ''} and ${st.titleDefences} defence${st.titleDefences === 1 ? '' : 's'}.`);
    else bullets.push('Never won a world title.');
    bullets.push(`Career purse ${st.earnings.toFixed(2)}m.`);
    bullets.push(f.damage >= 70 ? 'He left it all in there, and it shows.' : f.damage >= 40 ? 'He took his share and walked out on his own feet.' : 'He got out clean, which almost nobody does.');
    /* Round 1546: the score is the record's whatever ended it; this line only says who did. */ if (st.retiredBy === 'choice') bullets.push(`He called time himself after ${st.fightNo} fights.`);
    return {
        score,
        tier,
        hof,
        bullets
    };
}
export const PAST_FIGHTERS_MAX = 8;
export function pastFighterOf(st) {
    const f = st.fighter;
    const v = legacyOf(st);
    return {
        key: `${st.seed >>> 0}:${st.fightNo}:${f.wins}-${f.losses}-${f.draws}:${f.kos}:${st.earnings}`,
        name: f.name,
        weight: st.weight,
        wins: f.wins,
        losses: f.losses,
        draws: f.draws,
        kos: f.kos,
        titles: st.history.filter((h)=>h.title && h.result === 'W').length,
        defences: st.titleDefences,
        tier: v.tier,
        score: v.score,
        chose: st.retiredBy === 'choice'
    };
}
/** Newest first. A career already on the list is left where it is, so a reload of a finished save adds nothing. */ export function archiveCareer(list, st) {
    if (!st.retired) return list;
    const entry = pastFighterOf(st);
    if (list.some((p)=>p.key === entry.key)) return list;
    return [
        entry,
        ...list
    ].slice(0, PAST_FIGHTERS_MAX);
}
/** Whatever storage hands back, as a list the setup screen can draw. Anything malformed is dropped. */ export function sanitizePastFighters(raw) {
    if (!Array.isArray(raw)) return [];
    const num = (v)=>typeof v === 'number' && Number.isFinite(v) ? v : null;
    const out = [];
    for (const r of raw){
        if (!r || typeof r !== 'object') continue;
        const p = r;
        const nums = [
            p.wins,
            p.losses,
            p.draws,
            p.kos,
            p.titles,
            p.defences,
            p.score
        ].map(num);
        if (typeof p.key !== 'string' || typeof p.name !== 'string' || typeof p.tier !== 'string') continue;
        if (!WEIGHT_CLASSES.some((w)=>w.id === p.weight) || nums.some((n)=>n === null)) continue;
        const [wins, losses, draws, kos, titles, defences, score] = nums;
        out.push({
            key: p.key,
            name: p.name,
            weight: p.weight,
            wins,
            losses,
            draws,
            kos,
            titles,
            defences,
            tier: p.tier,
            score,
            chose: p.chose === true
        });
        if (out.length >= PAST_FIGHTERS_MAX) break;
    }
    return out;
}
/**
 * One seeded bout per Eastern day, the same for everybody, three rounds, no
 * career attached. It is a tactics puzzle rather than a career: you are handed
 * a fighter and an opponent whose style is readable, and you choose three
 * tactics.
 *
 * Both fighters are drawn against a FIXED difficulty target rather than freely,
 * so a Tuesday is not harder than a Monday. The harness checks that target
 * holds across a year of seeds, because "the daily is winnable" is exactly the
 * kind of thing that is true on the day somebody checks and false in March.
 */ export function dailyFight(dayKey) {
    const rng = rngFrom(hashLabel(`fight-career-daily|${dayKey}`));
    const weight = WEIGHT_CLASSES[Math.floor(rng() * WEIGHT_CLASSES.length)].id;
    const player = makeFighter(rng, 70, weight);
    const opponent = makeFighter(rng, 70, weight);
    player.age = 27;
    opponent.age = 27;
    player.damage = 0;
    opponent.damage = 0;
    return {
        player,
        opponent,
        weight,
        rounds: 3
    };
}
export const DAILY_MAX = 100;
/**
 * The daily score, on the sitewide 100 scale, written before the UI existed so
 * it could not drift into whatever the screen happened to make easy.
 *
 *   win the bout                                  50
 *   each round won on the cards, capped           8 each, max 24
 *   finish inside the distance                    12
 *   every tactic correct against his style        14
 *   damage taken, scaled                          0 to minus 14
 */ export function scoreDaily(res, tactics, oppStyle) {
    let s = 0;
    if (res.winner === 'player') s += 50;
    s += Math.min(24, res.roundsWon * 8);
    if (res.method === 'KO' || res.method === 'TKO') s += 12;
    const right = tactics.filter((t)=>tacticEdge(t, oppStyle) > 0).length;
    s += Math.round(right / Math.max(1, tactics.length) * 14);
    s -= Math.min(14, Math.round(res.damageTaken * 0.7));
    return clampi(s, 0, DAILY_MAX);
}
