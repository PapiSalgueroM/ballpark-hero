import { jsxDEV as _jsxDEV } from "react/jsx-dev-runtime";
import * as React from "react";
import * as DialogPrimitive from "@radix-ui/react-dialog";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";
const Dialog = DialogPrimitive.Root;
const DialogTrigger = DialogPrimitive.Trigger;
const DialogPortal = DialogPrimitive.Portal;
const DialogClose = DialogPrimitive.Close;
const DialogOverlay = /*#__PURE__*/ React.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ _jsxDEV(DialogPrimitive.Overlay, {
        ref: ref,
        className: cn("fixed inset-0 z-50 bg-black/80 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
        ...props
    }, void 0, false, {
        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/ui/dialog.tsx",
        lineNumber: 19,
        columnNumber: 3
    }, this));
DialogOverlay.displayName = DialogPrimitive.Overlay.displayName;
const DialogContent = /*#__PURE__*/ React.forwardRef(({ className, children, ...props }, ref)=>/*#__PURE__*/ _jsxDEV(DialogPortal, {
        children: [
            /*#__PURE__*/ _jsxDEV(DialogOverlay, {}, void 0, false, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/ui/dialog.tsx",
                lineNumber: 35,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ _jsxDEV(DialogPrimitive.Content, {
                ref: ref,
                className: cn("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] sm:rounded-lg", className),
                ...props,
                children: [
                    children,
                    /*#__PURE__*/ _jsxDEV(DialogPrimitive.Close, {
                        className: "absolute right-2 top-2 p-2 rounded-sm opacity-70 ring-offset-background transition-opacity data-[state=open]:bg-accent data-[state=open]:text-muted-foreground hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none",
                        children: [
                            /*#__PURE__*/ _jsxDEV(X, {
                                className: "h-4 w-4"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/ui/dialog.tsx",
                                lineNumber: 50,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ _jsxDEV("span", {
                                className: "sr-only",
                                children: "Close"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/ui/dialog.tsx",
                                lineNumber: 51,
                                columnNumber: 9
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/ui/dialog.tsx",
                        lineNumber: 49,
                        columnNumber: 7
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/ui/dialog.tsx",
                lineNumber: 36,
                columnNumber: 5
            }, this)
        ]
    }, void 0, true, {
        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/ui/dialog.tsx",
        lineNumber: 34,
        columnNumber: 3
    }, this));
DialogContent.displayName = DialogPrimitive.Content.displayName;
const DialogHeader = ({ className, ...props })=>/*#__PURE__*/ _jsxDEV("div", {
        className: cn("flex flex-col space-y-1.5 text-center sm:text-left", className),
        ...props
    }, void 0, false, {
        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/ui/dialog.tsx",
        lineNumber: 59,
        columnNumber: 3
    }, this);
DialogHeader.displayName = "DialogHeader";
const DialogFooter = ({ className, ...props })=>/*#__PURE__*/ _jsxDEV("div", {
        className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
        ...props
    }, void 0, false, {
        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/ui/dialog.tsx",
        lineNumber: 64,
        columnNumber: 3
    }, this);
DialogFooter.displayName = "DialogFooter";
const DialogTitle = /*#__PURE__*/ React.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ _jsxDEV(DialogPrimitive.Title, {
        ref: ref,
        className: cn("text-lg font-semibold leading-none tracking-tight", className),
        ...props
    }, void 0, false, {
        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/ui/dialog.tsx",
        lineNumber: 72,
        columnNumber: 3
    }, this));
DialogTitle.displayName = DialogPrimitive.Title.displayName;
const DialogDescription = /*#__PURE__*/ React.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ _jsxDEV(DialogPrimitive.Description, {
        ref: ref,
        className: cn("text-sm text-muted-foreground", className),
        ...props
    }, void 0, false, {
        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/components/ui/dialog.tsx",
        lineNumber: 84,
        columnNumber: 3
    }, this));
DialogDescription.displayName = DialogPrimitive.Description.displayName;
export { Dialog, DialogPortal, DialogOverlay, DialogClose, DialogTrigger, DialogContent, DialogHeader, DialogFooter, DialogTitle, DialogDescription };
