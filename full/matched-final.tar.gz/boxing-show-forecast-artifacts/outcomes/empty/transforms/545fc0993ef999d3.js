import { jsxDEV as _jsxDEV, Fragment as _Fragment } from "react/jsx-dev-runtime";
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Ticket, Building2, Trophy, RotateCcw, Plus, X, Flame } from 'lucide-react';
import ShareButtons from '@/components/game/ShareButtons';
import { useGameCompletion } from '@/hooks/useGameCompletion';
import { useRevealScroll } from '@/hooks/useRevealScroll';
import { markRestoredFinish } from '@/lib/restoredFinish';
import { cn } from '@/lib/utils';
import { Confetti } from '@/components/soccer-career/CareerFx';
import { STYLES, weightById, ratingOf } from '@/lib/fightCareer';
import { newPromoter, runShow, promoterVerdict, appealOf, purseFor, legalMatch, drawOf, weightOf, expectedAttendance, houseFill, VENUES, venueById, handOver, canHandOver, handOverPrice, sanitizePromoter, HANDOVER_MIN_SHOWS, BROKE_PENALTY } from '@/lib/fightPromoter';
import { HowToPlayPopover } from '@/components/game/HowToPlayPopover';
import BoxingShowForecast from '@/components/fight-promoter/BoxingShowForecast';
/* Round 955: the new ending, written down where the player can reopen it,
   because the page's guide lives in a file another lane is editing. */ function HandOverRules() {
    return /*#__PURE__*/ _jsxDEV(HowToPlayPopover, {
        title: "Handing it over",
        triggerLabel: "How handing over works",
        floatingTrigger: false,
        children: /*#__PURE__*/ _jsxDEV("div", {
            className: "space-y-3 text-sm",
            children: [
                /*#__PURE__*/ _jsxDEV("p", {
                    children: [
                        "Once you have put on ",
                        HANDOVER_MIN_SHOWS,
                        " shows you can hand the promotion over. A buyer pays for your name and your dates, and the better your name the more they pay. Handing over ends the game and shows how you are remembered, with the price in the bank."
                    ]
                }, void 0, true, {
                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                    lineNumber: 26,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ _jsxDEV("p", {
                    children: [
                        "The other way out is running out of money. That still ends it, but going under takes ",
                        BROKE_PENALTY,
                        " points off the verdict."
                    ]
                }, void 0, true, {
                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                    lineNumber: 31,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ _jsxDEV("p", {
                    className: "rounded-md border bg-muted/40 p-2 text-xs",
                    children: [
                        "Example: after twelve shows your name is 50 and you have 3m in the bank. A buyer offers",
                        ' ',
                        handOverPrice({
                            reputation: 50
                        }).toFixed(3),
                        "m, so you walk away with about",
                        ' ',
                        (3 + handOverPrice({
                            reputation: 50
                        })).toFixed(2),
                        "m and your verdict. Book one show too many in a room you cannot fill and you could be handing over nothing, with ",
                        BROKE_PENALTY,
                        " points off."
                    ]
                }, void 0, true, {
                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                    lineNumber: 35,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
            lineNumber: 25,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
        lineNumber: 24,
        columnNumber: 5
    }, this);
}
const SAVE_KEY = 'fight-promoter-save-v1';
export default function FightPromoterBoard() {
    const [phase, setPhase] = useState('setup');
    const [st, setSt] = useState(null);
    const [name, setName] = useState('');
    const [venueId, setVenueId] = useState('hall');
    const [priceK, setPriceK] = useState(220);
    const [card, setCard] = useState([]);
    const [picking, setPicking] = useState(null);
    const [result, setResult] = useState(null);
    /* Round 955: 'handover' or 'reset' while it waits on a second tap. */ const [confirm, setConfirm] = useState(null);
    const revealRef = useRevealScroll(`${phase}:${st?.show ?? 0}:${card.length}`);
    const verdict = useMemo(()=>st ? promoterVerdict(st) : null, [
        st
    ]);
    useGameCompletion('fight-promoter', !!st?.closed, verdict?.score ?? 0);
    useEffect(()=>{
        try {
            const raw = localStorage.getItem(SAVE_KEY);
            if (!raw) return;
            const s = JSON.parse(raw);
            if (!s?.st?.name) return;
            /* Round 643: a closed promotion read back from storage is not a new
         close. This restore runs after mount, so without the mark every
         reload paid the verdict again. */ if (s.st.closed) markRestoredFinish('fight-promoter');
            const st0 = sanitizePromoter(s.st);
            setSt(st0);
            setPhase(st0.closed ? 'closed' : 'hub');
        } catch  {}
    }, []);
    const persist = useCallback((next, ph)=>{
        setSt(next);
        setPhase(ph);
        try {
            localStorage.setItem(SAVE_KEY, JSON.stringify({
                st: next
            }));
        } catch  {}
    }, []);
    const reset = ()=>{
        try {
            localStorage.removeItem(SAVE_KEY);
        } catch  {}
        setSt(null);
        setPhase('setup');
        setCard([]);
        setResult(null);
        setPicking(null);
        setConfirm(null);
    };
    if (phase === 'setup' || !st) {
        return /*#__PURE__*/ _jsxDEV("div", {
            className: "space-y-4",
            children: [
                /*#__PURE__*/ _jsxDEV("div", {
                    className: "rounded-lg border bg-card p-4",
                    children: [
                        /*#__PURE__*/ _jsxDEV("label", {
                            htmlFor: "fight-promoter-name",
                            className: "mb-1 block text-xs uppercase tracking-wide text-muted-foreground",
                            children: "Name the promotion"
                        }, void 0, false, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                            lineNumber: 97,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV("input", {
                            id: "fight-promoter-name",
                            value: name,
                            onChange: (e)=>setName(e.target.value),
                            maxLength: 28,
                            placeholder: "Leave it blank and it is Small Hall Promotions",
                            className: "w-full rounded-md border bg-background px-3 py-2 text-sm"
                        }, void 0, false, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                            lineNumber: 98,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV("p", {
                            className: "mt-2 text-[11px] leading-snug text-muted-foreground",
                            children: "You book the room, make the fights and pay the purses. Feeding a known man somebody who cannot live with him sells tickets tonight. Making the fight people actually want is what gets your name on a bigger building."
                        }, void 0, false, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                            lineNumber: 101,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV("div", {
                            className: "mt-2 flex items-center gap-2 text-[11px] text-muted-foreground",
                            children: [
                                /*#__PURE__*/ _jsxDEV(HandOverRules, {}, void 0, false, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                    lineNumber: 107,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ _jsxDEV("span", {
                                    children: [
                                        "After ",
                                        HANDOVER_MIN_SHOWS,
                                        " shows you can hand the promotion over and go out on your own terms."
                                    ]
                                }, void 0, true, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                    lineNumber: 108,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                            lineNumber: 106,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                    lineNumber: 96,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ _jsxDEV("button", {
                    onClick: ()=>persist(newPromoter(name), 'hub'),
                    className: "min-h-[48px] w-full rounded-md bg-primary px-4 py-3 font-semibold text-primary-foreground",
                    children: "Book your first room"
                }, void 0, false, {
                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                    lineNumber: 111,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
            lineNumber: 95,
            columnNumber: 7
        }, this);
    }
    const inCard = new Set(card.flatMap((b)=>[
            b.aId,
            b.bId
        ]));
    const price = priceK / 1e6;
    const venue = venueById(venueId);
    /* Release AM: the room stays picked when a bad show drops your name under
     what it needs, and the engine will not run a show there. So no forecast
     for it (it would be the one number the engine never pays) and no live
     button that does nothing: say why and ask for another room. */ const roomLocked = venue.needs > st.reputation;
    const plan = {
        venueId,
        ticketPrice: price,
        bookings: card
    };
    const projected = card.length ? expectedAttendance(st, plan) : 0;
    const projectedGate = Math.round(projected * price * 1000) / 1000;
    const projectedPurses = card.reduce((s, b)=>{
        const a = st.pool.find((f)=>f.id === b.aId);
        const c = st.pool.find((f)=>f.id === b.bId);
        return a && c ? s + purseFor(a, c, b.title) : s;
    }, 0);
    const Header = /*#__PURE__*/ _jsxDEV("div", {
        className: "rounded-lg border bg-card p-4",
        children: /*#__PURE__*/ _jsxDEV("div", {
            className: "flex items-start justify-between gap-3",
            children: [
                /*#__PURE__*/ _jsxDEV("div", {
                    className: "min-w-0",
                    children: [
                        /*#__PURE__*/ _jsxDEV("h2", {
                            className: "truncate text-lg font-bold",
                            children: st.name
                        }, void 0, false, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                            lineNumber: 140,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV("p", {
                            className: "text-xs text-muted-foreground",
                            children: [
                                "Show ",
                                st.show
                            ]
                        }, void 0, true, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                            lineNumber: 141,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                    lineNumber: 139,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ _jsxDEV("div", {
                    className: "shrink-0 text-right",
                    children: [
                        /*#__PURE__*/ _jsxDEV("p", {
                            className: cn('text-sm font-bold tabular-nums', st.money < 0.02 ? 'text-destructive' : 'text-primary'),
                            children: [
                                st.money.toFixed(3),
                                "m"
                            ]
                        }, void 0, true, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                            lineNumber: 144,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV("p", {
                            className: "text-xs text-muted-foreground",
                            children: [
                                "name ",
                                st.reputation.toFixed(0),
                                " of 100"
                            ]
                        }, void 0, true, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                            lineNumber: 147,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                    lineNumber: 143,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
            lineNumber: 138,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
        lineNumber: 137,
        columnNumber: 5
    }, this);
    if (phase === 'closed' && verdict) {
        return /*#__PURE__*/ _jsxDEV("div", {
            className: "space-y-4",
            ref: revealRef,
            children: [
                Header,
                /*#__PURE__*/ _jsxDEV("div", {
                    className: "rounded-lg border bg-card p-4 text-center",
                    children: [
                        /*#__PURE__*/ _jsxDEV(Trophy, {
                            className: cn('mx-auto mb-2 h-7 w-7', st.exit === 'handed' ? 'text-amber-500' : 'text-muted-foreground')
                        }, void 0, false, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                            lineNumber: 158,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV("p", {
                            className: "text-sm font-semibold",
                            children: st.exit === 'handed' ? `Handed over for ${(st.handedFor ?? 0).toFixed(3)}m` : 'Out of the business'
                        }, void 0, false, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                            lineNumber: 159,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV("p", {
                            className: "text-xs uppercase tracking-wide text-muted-foreground",
                            children: "How you are remembered"
                        }, void 0, false, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                            lineNumber: 162,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV("p", {
                            className: "text-2xl font-bold text-primary",
                            children: verdict.tier
                        }, void 0, false, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                            lineNumber: 163,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV("p", {
                            className: "mb-3 text-sm text-muted-foreground",
                            children: [
                                verdict.score,
                                " out of 100"
                            ]
                        }, void 0, true, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                            lineNumber: 164,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV("ul", {
                            className: "space-y-1 text-left text-sm text-muted-foreground",
                            children: verdict.bullets.map((b, i)=>/*#__PURE__*/ _jsxDEV("li", {
                                    children: b
                                }, i, false, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                    lineNumber: 166,
                                    columnNumber: 44
                                }, this))
                        }, void 0, false, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                            lineNumber: 165,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                    lineNumber: 157,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ _jsxDEV(ShareButtons, {
                    gameName: "Fight Promoter",
                    gamePath: "/fight-promoter",
                    score: `${verdict.tier}, ${verdict.score}/100`,
                    customText: st.exit === 'handed' ? `${st.name} put on ${st.history.length} shows, handed it over and went out as ${verdict.tier}.` : `${st.name} put on ${st.history.length} shows and finished as ${verdict.tier}.`
                }, void 0, false, {
                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                    lineNumber: 169,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ _jsxDEV("button", {
                    onClick: reset,
                    className: "min-h-[48px] w-full rounded-md border px-4 py-3 font-semibold",
                    children: [
                        /*#__PURE__*/ _jsxDEV(RotateCcw, {
                            className: "mr-2 inline h-4 w-4"
                        }, void 0, false, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                            lineNumber: 175,
                            columnNumber: 11
                        }, this),
                        "Start again"
                    ]
                }, void 0, true, {
                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                    lineNumber: 174,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
            lineNumber: 155,
            columnNumber: 7
        }, this);
    }
    if (phase === 'result' && result) {
        /* From the lib, not worked out here, so the harness can check that "sold
       out" only ever appears with every seat taken. */ const { percent: full, soldOut } = houseFill(result.attendance, result.venue.capacity);
        return /*#__PURE__*/ _jsxDEV("div", {
            className: "space-y-4",
            ref: revealRef,
            children: [
                Header,
                /*#__PURE__*/ _jsxDEV("div", {
                    className: cn('relative overflow-hidden rounded-lg border p-4 text-center', result.profit >= 0 ? 'border-emerald-500/60 bg-emerald-500/10' : 'border-destructive/60 bg-destructive/10'),
                    children: [
                        result.profit >= 0 && /*#__PURE__*/ _jsxDEV(Confetti, {
                            pieces: soldOut ? 46 : 26,
                            gold: soldOut
                        }, void 0, false, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                            lineNumber: 194,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ _jsxDEV("p", {
                            className: "text-xs uppercase tracking-wide text-muted-foreground",
                            children: result.venue.name
                        }, void 0, false, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                            lineNumber: 196,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV("p", {
                            className: "animate-count-pop text-2xl font-bold",
                            children: [
                                result.attendance.toLocaleString(),
                                " in"
                            ]
                        }, result.attendance, true, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                            lineNumber: 197,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV("div", {
                            className: "mx-auto mt-2 max-w-xs",
                            children: [
                                /*#__PURE__*/ _jsxDEV("div", {
                                    className: "h-2.5 overflow-hidden rounded-full bg-muted",
                                    children: /*#__PURE__*/ _jsxDEV("div", {
                                        className: cn('h-full rounded-full transition-[width] duration-700 ease-out', full >= 90 ? 'bg-amber-500' : full >= 55 ? 'bg-emerald-500' : 'bg-muted-foreground/60'),
                                        style: {
                                            width: `${full}%`
                                        }
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                        lineNumber: 203,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                    lineNumber: 202,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ _jsxDEV("p", {
                                    className: "mt-1 text-[11px] text-muted-foreground",
                                    children: [
                                        full,
                                        "% of ",
                                        result.venue.capacity.toLocaleString(),
                                        soldOut ? ', sold out' : ''
                                    ]
                                }, void 0, true, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                    lineNumber: 207,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                            lineNumber: 201,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV("p", {
                            className: "text-sm text-muted-foreground",
                            children: [
                                "gate ",
                                result.gate.toFixed(3),
                                "m, purses ",
                                result.purses.toFixed(3),
                                "m, room ",
                                result.rent.toFixed(3),
                                "m"
                            ]
                        }, void 0, true, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                            lineNumber: 211,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV("p", {
                            className: cn('mt-1 text-lg font-bold', result.profit >= 0 ? 'text-emerald-500' : 'text-destructive'),
                            children: [
                                result.profit >= 0 ? 'Profit' : 'Loss',
                                " ",
                                Math.abs(result.profit).toFixed(3),
                                "m"
                            ]
                        }, void 0, true, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                            lineNumber: 214,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV("p", {
                            className: cn('mt-1 text-xs', result.repDelta >= 0 ? 'text-amber-500' : 'text-destructive'),
                            children: [
                                result.repDelta >= 0 ? '+' : '',
                                result.repDelta.toFixed(1),
                                " to your name"
                            ]
                        }, void 0, true, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                            lineNumber: 217,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                    lineNumber: 188,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ _jsxDEV("div", {
                    className: "space-y-2",
                    children: result.bouts.map((b, i)=>/*#__PURE__*/ _jsxDEV("div", {
                            className: "rounded-md border bg-card p-3 text-xs",
                            children: [
                                /*#__PURE__*/ _jsxDEV("div", {
                                    className: "flex items-center justify-between font-semibold",
                                    children: [
                                        /*#__PURE__*/ _jsxDEV("span", {
                                            className: "truncate",
                                            children: [
                                                b.a.name,
                                                " vs ",
                                                b.b.name
                                            ]
                                        }, void 0, true, {
                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                            lineNumber: 225,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ _jsxDEV("span", {
                                            className: "shrink-0 pl-2",
                                            children: b.result.method
                                        }, void 0, false, {
                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                            lineNumber: 226,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                    lineNumber: 224,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ _jsxDEV("p", {
                                    className: "text-muted-foreground",
                                    children: [
                                        b.result.winner === 'draw' ? 'Drawn' : `${b.result.winner === 'player' ? b.a.name : b.b.name} wins`,
                                        b.result.method === 'KO' || b.result.method === 'TKO' ? ` in round ${b.result.endedRound}` : '',
                                        ", cards ",
                                        b.result.playerCard,
                                        " to ",
                                        b.result.oppCard
                                    ]
                                }, void 0, true, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                    lineNumber: 228,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ _jsxDEV("p", {
                                    className: cn('font-medium', b.quality >= 70 ? 'text-amber-500' : b.quality < 35 ? 'text-muted-foreground' : ''),
                                    children: b.quality >= 78 ? /*#__PURE__*/ _jsxDEV(_Fragment, {
                                        children: [
                                            /*#__PURE__*/ _jsxDEV(Flame, {
                                                className: "mr-1 inline h-3 w-3"
                                            }, void 0, false, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                                lineNumber: 234,
                                                columnNumber: 38
                                            }, this),
                                            "A fight people will talk about."
                                        ]
                                    }, void 0, true) : b.quality >= 55 ? 'A decent fight.' : b.quality >= 35 ? 'Nobody complained, nobody remembers.' : 'One way traffic. The room went quiet.'
                                }, void 0, false, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                    lineNumber: 233,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, i, true, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                            lineNumber: 223,
                            columnNumber: 13
                        }, this))
                }, void 0, false, {
                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                    lineNumber: 221,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ _jsxDEV("button", {
                    onClick: ()=>{
                        setResult(null);
                        setCard([]);
                        setPhase(st.closed ? 'closed' : 'hub');
                    },
                    className: "min-h-[48px] w-full rounded-md bg-primary px-4 py-3 font-semibold text-primary-foreground",
                    children: st.closed ? 'See how you are remembered' : 'Plan the next show'
                }, void 0, false, {
                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                    lineNumber: 242,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
            lineNumber: 186,
            columnNumber: 7
        }, this);
    }
    /* ── the hub: build the card ── */ const FighterRow = ({ f, onPick, disabled })=>/*#__PURE__*/ _jsxDEV("button", {
            disabled: disabled,
            onClick: onPick,
            className: cn('w-full rounded-md border p-2 text-left text-xs transition', disabled ? 'opacity-35' : 'hover:border-primary'),
            children: [
                /*#__PURE__*/ _jsxDEV("div", {
                    className: "flex items-center justify-between gap-2",
                    children: [
                        /*#__PURE__*/ _jsxDEV("span", {
                            className: "truncate font-semibold",
                            children: f.name
                        }, void 0, false, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                            lineNumber: 256,
                            columnNumber: 9
                        }, this),
                        /*#__PURE__*/ _jsxDEV("span", {
                            className: "shrink-0 text-muted-foreground",
                            children: [
                                "draw ",
                                drawOf(f).toFixed(0)
                            ]
                        }, void 0, true, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                            lineNumber: 257,
                            columnNumber: 9
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                    lineNumber: 255,
                    columnNumber: 7
                }, this),
                /*#__PURE__*/ _jsxDEV("span", {
                    className: "block text-[11px] text-muted-foreground",
                    children: [
                        weightById(weightOf(f)).label,
                        " · ",
                        STYLES.find((s)=>s.id === f.style)?.label,
                        " · ",
                        f.wins,
                        "-",
                        f.losses,
                        " · rating ",
                        ratingOf(f),
                        f.damage >= 40 ? ` · carrying ${f.damage.toFixed(0)} damage` : ''
                    ]
                }, void 0, true, {
                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                    lineNumber: 259,
                    columnNumber: 7
                }, this)
            ]
        }, void 0, true, {
            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
            lineNumber: 252,
            columnNumber: 5
        }, this);
    return /*#__PURE__*/ _jsxDEV("div", {
        className: "space-y-4",
        ref: revealRef,
        children: [
            Header,
            /*#__PURE__*/ _jsxDEV("div", {
                className: "flex items-center justify-end gap-2 text-xs text-muted-foreground",
                children: [
                    /*#__PURE__*/ _jsxDEV("span", {
                        children: "Handing over and going under"
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                        lineNumber: 270,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV(HandOverRules, {}, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                        lineNumber: 271,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                lineNumber: 269,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "rounded-lg border bg-card p-4",
                children: [
                    /*#__PURE__*/ _jsxDEV("p", {
                        className: "mb-2 flex items-center gap-2 text-xs uppercase tracking-wide text-muted-foreground",
                        children: [
                            /*#__PURE__*/ _jsxDEV(Building2, {
                                className: "h-3 w-3"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                lineNumber: 276,
                                columnNumber: 11
                            }, this),
                            "The room"
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                        lineNumber: 275,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "grid grid-cols-2 gap-2 sm:grid-cols-3",
                        children: VENUES.map((v)=>{
                            const locked = v.needs > st.reputation;
                            const tooDear = v.rent > st.money;
                            return /*#__PURE__*/ _jsxDEV("button", {
                                disabled: locked || tooDear,
                                onClick: ()=>setVenueId(v.id),
                                className: cn('min-h-[52px] rounded-md border px-2 py-1.5 text-left text-[11px] transition', venueId === v.id ? 'border-primary bg-primary/10' : 'hover:bg-muted', (locked || tooDear) && 'opacity-40'),
                                children: [
                                    /*#__PURE__*/ _jsxDEV("span", {
                                        className: "block font-semibold",
                                        children: v.name
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                        lineNumber: 287,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("span", {
                                        className: "block text-muted-foreground",
                                        children: [
                                            v.capacity.toLocaleString(),
                                            " · ",
                                            v.rent.toFixed(3),
                                            "m",
                                            locked ? ` · needs ${v.needs}` : tooDear ? ' · cannot afford' : ''
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                        lineNumber: 288,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, v.id, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                lineNumber: 283,
                                columnNumber: 15
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                        lineNumber: 278,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "mt-3",
                        children: [
                            /*#__PURE__*/ _jsxDEV("label", {
                                htmlFor: "fight-promoter-price",
                                className: "flex items-center justify-between text-xs text-muted-foreground",
                                children: [
                                    /*#__PURE__*/ _jsxDEV("span", {
                                        className: "flex items-center gap-1",
                                        children: [
                                            /*#__PURE__*/ _jsxDEV(Ticket, {
                                                className: "h-3 w-3"
                                            }, void 0, false, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                                lineNumber: 298,
                                                columnNumber: 55
                                            }, this),
                                            "Ticket price"
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                        lineNumber: 298,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("span", {
                                        className: "tabular-nums",
                                        children: [
                                            priceK,
                                            " a seat"
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                        lineNumber: 299,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                lineNumber: 297,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ _jsxDEV("input", {
                                id: "fight-promoter-price",
                                type: "range",
                                min: 60,
                                max: 600,
                                step: 10,
                                value: priceK,
                                onChange: (e)=>setPriceK(Number(e.target.value)),
                                className: "mt-1 h-6 w-full"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                lineNumber: 301,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                        lineNumber: 296,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                lineNumber: 274,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "rounded-lg border bg-card p-4",
                children: [
                    /*#__PURE__*/ _jsxDEV("p", {
                        className: "mb-1 text-xs uppercase tracking-wide text-muted-foreground",
                        children: "Tonight's card"
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                        lineNumber: 308,
                        columnNumber: 9
                    }, this),
                    card.length === 0 && /*#__PURE__*/ _jsxDEV("p", {
                        className: "text-sm text-muted-foreground",
                        children: "Nothing booked yet."
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                        lineNumber: 309,
                        columnNumber: 31
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "space-y-1.5",
                        children: card.map((b, i)=>{
                            const a = st.pool.find((f)=>f.id === b.aId);
                            const c = st.pool.find((f)=>f.id === b.bId);
                            if (!a || !c) return null;
                            return /*#__PURE__*/ _jsxDEV("div", {
                                className: "flex items-center justify-between gap-2 rounded-md border p-2 text-xs",
                                children: [
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        className: "min-w-0",
                                        children: [
                                            /*#__PURE__*/ _jsxDEV("p", {
                                                className: "truncate font-semibold",
                                                children: [
                                                    a.name,
                                                    " vs ",
                                                    c.name
                                                ]
                                            }, void 0, true, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                                lineNumber: 318,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ _jsxDEV("p", {
                                                className: "text-[11px] text-muted-foreground",
                                                children: [
                                                    "appeal ",
                                                    appealOf(a, c, false).toFixed(0),
                                                    " · purse ",
                                                    purseFor(a, c, false).toFixed(3),
                                                    "m",
                                                    Math.abs(ratingOf(a) - ratingOf(c)) > 12 ? ' · one sided' : ' · a real fight'
                                                ]
                                            }, void 0, true, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                                lineNumber: 319,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                        lineNumber: 317,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("button", {
                                        onClick: ()=>setCard(card.filter((_, j)=>j !== i)),
                                        className: "h-8 w-8 shrink-0 rounded-md border",
                                        children: /*#__PURE__*/ _jsxDEV(X, {
                                            className: "mx-auto h-3 w-3"
                                        }, void 0, false, {
                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                            lineNumber: 325,
                                            columnNumber: 66
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                        lineNumber: 324,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, i, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                lineNumber: 316,
                                columnNumber: 15
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                        lineNumber: 310,
                        columnNumber: 9
                    }, this),
                    card.length >= 0 && (roomLocked ? /*#__PURE__*/ _jsxDEV("p", {
                        role: "status",
                        "data-boxing-room-locked": true,
                        className: "mt-2 border-t pt-2 text-xs font-semibold text-destructive",
                        children: [
                            venue.name,
                            " needs a name of ",
                            venue.needs,
                            " and yours is ",
                            st.reputation.toFixed(1),
                            ". Pick a room that will have you to see the cash forecast and put the show on."
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                        lineNumber: 331,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ _jsxDEV(BoxingShowForecast, {
                        attendance: projected,
                        capacity: venue.capacity,
                        gate: projectedGate,
                        guaranteedPurses: projectedPurses,
                        rent: venue.rent,
                        money: st.money
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                        lineNumber: 335,
                        columnNumber: 11
                    }, this)),
                    /*#__PURE__*/ _jsxDEV("button", {
                        disabled: !card.length || roomLocked,
                        onClick: ()=>{
                            const r = runShow(st, plan);
                            if (!r) return;
                            setResult(r.result);
                            setConfirm(null);
                            persist(r.state, 'result');
                        },
                        className: "mt-3 min-h-[48px] w-full rounded-md bg-primary px-4 py-3 font-semibold text-primary-foreground disabled:opacity-40",
                        children: "Put the show on"
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                        lineNumber: 338,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                lineNumber: 307,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "rounded-lg border bg-card p-4",
                children: [
                    /*#__PURE__*/ _jsxDEV("p", {
                        className: "mb-2 text-xs uppercase tracking-wide text-muted-foreground",
                        children: "Who will work for you"
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                        lineNumber: 353,
                        columnNumber: 9
                    }, this),
                    !picking && /*#__PURE__*/ _jsxDEV("div", {
                        className: "space-y-1.5",
                        children: st.pool.map((f)=>/*#__PURE__*/ _jsxDEV(FighterRow, {
                                f: f,
                                disabled: inCard.has(f.id),
                                onPick: ()=>setPicking(f.id)
                            }, f.id, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                lineNumber: 357,
                                columnNumber: 15
                            }, this))
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                        lineNumber: 355,
                        columnNumber: 11
                    }, this),
                    picking && (()=>{
                        const a = st.pool.find((f)=>f.id === picking);
                        if (!a) return null;
                        const foes = st.pool.filter((f)=>!inCard.has(f.id) && legalMatch(a, f));
                        return /*#__PURE__*/ _jsxDEV("div", {
                            className: "space-y-2",
                            children: [
                                /*#__PURE__*/ _jsxDEV("p", {
                                    className: "text-sm font-semibold",
                                    children: [
                                        "Who do you put in with ",
                                        a.name,
                                        "?"
                                    ]
                                }, void 0, true, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                    lineNumber: 367,
                                    columnNumber: 15
                                }, this),
                                foes.length === 0 && /*#__PURE__*/ _jsxDEV("p", {
                                    className: "text-xs text-muted-foreground",
                                    children: "Nobody at his weight is free. Everyone has to make the weight, and nobody carrying 80 damage gets a licence."
                                }, void 0, false, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                    lineNumber: 369,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ _jsxDEV("div", {
                                    className: "space-y-1.5",
                                    children: foes.map((f)=>/*#__PURE__*/ _jsxDEV("button", {
                                            onClick: ()=>{
                                                setCard([
                                                    ...card,
                                                    {
                                                        aId: a.id,
                                                        bId: f.id,
                                                        rounds: 8,
                                                        title: false
                                                    }
                                                ]);
                                                setPicking(null);
                                            },
                                            className: "w-full rounded-md border p-2 text-left text-xs hover:border-primary",
                                            children: [
                                                /*#__PURE__*/ _jsxDEV("div", {
                                                    className: "flex items-center justify-between gap-2",
                                                    children: [
                                                        /*#__PURE__*/ _jsxDEV("span", {
                                                            className: "truncate font-semibold",
                                                            children: f.name
                                                        }, void 0, false, {
                                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                                            lineNumber: 379,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ _jsxDEV("span", {
                                                            className: "shrink-0 text-primary",
                                                            children: [
                                                                "appeal ",
                                                                appealOf(a, f, false).toFixed(0)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                                            lineNumber: 380,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                                    lineNumber: 378,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ _jsxDEV("span", {
                                                    className: "block text-[11px] text-muted-foreground",
                                                    children: [
                                                        "rating ",
                                                        ratingOf(f),
                                                        " against his ",
                                                        ratingOf(a),
                                                        " ·",
                                                        Math.abs(ratingOf(a) - ratingOf(f)) > 12 ? ' he cannot live with him' : ' nobody could split them',
                                                        ' ',
                                                        "· purse ",
                                                        purseFor(a, f, false).toFixed(3),
                                                        "m"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                                    lineNumber: 382,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, f.id, true, {
                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                            lineNumber: 375,
                                            columnNumber: 19
                                        }, this))
                                }, void 0, false, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                    lineNumber: 373,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ _jsxDEV("button", {
                                    onClick: ()=>setPicking(null),
                                    className: "min-h-[40px] w-full rounded-md border px-3 py-1.5 text-xs text-muted-foreground",
                                    children: [
                                        /*#__PURE__*/ _jsxDEV(Plus, {
                                            className: "mr-1 inline h-3 w-3 rotate-45"
                                        }, void 0, false, {
                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                            lineNumber: 392,
                                            columnNumber: 17
                                        }, this),
                                        "Pick somebody else"
                                    ]
                                }, void 0, true, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                    lineNumber: 390,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                            lineNumber: 366,
                            columnNumber: 13
                        }, this);
                    })()
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                lineNumber: 352,
                columnNumber: 7
            }, this),
            st.log.length > 0 && /*#__PURE__*/ _jsxDEV("div", {
                className: "rounded-lg border bg-card p-3",
                children: [
                    /*#__PURE__*/ _jsxDEV("p", {
                        className: "mb-1 text-xs uppercase tracking-wide text-muted-foreground",
                        children: "The book"
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                        lineNumber: 401,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "max-h-36 space-y-1 overflow-y-auto text-[11px] text-muted-foreground",
                        children: st.log.slice(0, 16).map((l, i)=>/*#__PURE__*/ _jsxDEV("p", {
                                children: l
                            }, i, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                lineNumber: 403,
                                columnNumber: 48
                            }, this))
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                        lineNumber: 402,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                lineNumber: 400,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "rounded-lg border bg-card p-3",
                children: [
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "flex items-start justify-between gap-2",
                        children: [
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "min-w-0",
                                children: [
                                    /*#__PURE__*/ _jsxDEV("p", {
                                        className: "text-sm font-semibold",
                                        children: "Hand it over"
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                        lineNumber: 411,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("p", {
                                        className: "text-[11px] text-muted-foreground",
                                        children: canHandOver(st) ? `A buyer will pay ${handOverPrice(st).toFixed(3)}m for your name and your dates. Handing over ends it here and shows the verdict.` : `Nobody buys a promotion with no history. Offers start after ${HANDOVER_MIN_SHOWS} shows (${st.history.length} so far).`
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                        lineNumber: 412,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                lineNumber: 410,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ _jsxDEV("button", {
                                disabled: !canHandOver(st),
                                onClick: ()=>setConfirm(confirm === 'handover' ? null : 'handover'),
                                className: "min-h-[36px] shrink-0 rounded-md border px-3 py-1.5 text-xs font-medium disabled:opacity-40",
                                children: "Hand over"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                lineNumber: 418,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                        lineNumber: 409,
                        columnNumber: 9
                    }, this),
                    confirm === 'handover' && canHandOver(st) && /*#__PURE__*/ _jsxDEV("div", {
                        className: "mt-2 flex gap-2 border-t pt-2",
                        children: [
                            /*#__PURE__*/ _jsxDEV("button", {
                                onClick: ()=>{
                                    const h = handOver(st);
                                    setConfirm(null);
                                    setCard([]);
                                    setPicking(null);
                                    if (h) persist(h, 'closed');
                                },
                                className: "min-h-[40px] flex-1 rounded-md bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground",
                                children: [
                                    "Yes, hand over for ",
                                    handOverPrice(st).toFixed(3),
                                    "m"
                                ]
                            }, void 0, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                lineNumber: 427,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ _jsxDEV("button", {
                                onClick: ()=>setConfirm(null),
                                className: "min-h-[40px] flex-1 rounded-md border px-3 py-1.5 text-xs",
                                children: "Not yet"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                lineNumber: 436,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                        lineNumber: 426,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                lineNumber: 408,
                columnNumber: 7
            }, this),
            confirm === 'reset' ? /*#__PURE__*/ _jsxDEV("div", {
                className: "rounded-lg border border-destructive/50 p-3",
                children: [
                    /*#__PURE__*/ _jsxDEV("p", {
                        className: "mb-2 text-xs text-muted-foreground",
                        children: "Walk away and start a new promotion? This one is gone for good, with no verdict."
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                        lineNumber: 446,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "flex gap-2",
                        children: [
                            /*#__PURE__*/ _jsxDEV("button", {
                                onClick: reset,
                                className: "min-h-[44px] flex-1 rounded-md border border-destructive/60 px-3 py-2 text-sm text-destructive",
                                children: "Yes, start again"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                lineNumber: 450,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ _jsxDEV("button", {
                                onClick: ()=>setConfirm(null),
                                className: "min-h-[44px] flex-1 rounded-md border px-3 py-2 text-sm",
                                children: "Keep this promotion"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                                lineNumber: 454,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                        lineNumber: 449,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                lineNumber: 445,
                columnNumber: 9
            }, this) : /*#__PURE__*/ _jsxDEV("button", {
                onClick: ()=>setConfirm('reset'),
                className: "min-h-[44px] w-full rounded-md border px-4 py-2 text-sm text-muted-foreground",
                children: "Close the promotion and start again"
            }, void 0, false, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
                lineNumber: 461,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/empty.tsx",
        lineNumber: 267,
        columnNumber: 5
    }, this);
}
