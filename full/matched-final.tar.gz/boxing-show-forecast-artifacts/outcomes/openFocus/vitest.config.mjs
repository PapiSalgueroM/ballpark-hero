import { defineConfig } from "/home/runner/work/ballpark-hero/ballpark-hero/node_modules/vitest/dist/config.js";
import react from "/home/runner/work/ballpark-hero/ballpark-hero/node_modules/@vitejs/plugin-react-swc/index.js";
import fs from 'node:fs'; import path from 'node:path'; import crypto from 'node:crypto';
const seen = new Map(), dir = "/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/openFocus", wanted = ["/home/runner/work/ballpark-hero/ballpark-hero/src/test/boxingShowForecast.test.tsx","/home/runner/work/ballpark-hero/ballpark-hero/src/components/fight-promoter/FightPromoterBoard.tsx","/home/runner/work/ballpark-hero/ballpark-hero/src/components/fight-promoter/BoxingShowForecast.tsx","/home/runner/work/ballpark-hero/ballpark-hero/src/lib/fightPromoter.ts","/home/runner/work/ballpark-hero/ballpark-hero/src/lib/fightCareer.ts","/home/runner/work/ballpark-hero/ballpark-hero/src/lib/careerEngine.ts","/home/runner/work/ballpark-hero/ballpark-hero/src/hooks/useGameCompletion.ts","/home/runner/work/ballpark-hero/ballpark-hero/src/lib/restoredFinish.ts","/home/runner/work/ballpark-hero/ballpark-hero/src/components/ui/dialog.tsx","/home/runner/work/ballpark-hero/ballpark-hero/boxing-show-forecast-artifacts/outcomes/copies/openFocus.tsx"];
const hash = value => crypto.createHash('sha256').update(value).digest('hex');
export default defineConfig({ root: "/home/runner/work/ballpark-hero/ballpark-hero", plugins: [react(), {
  name: 'retain-boxing-transform', enforce: 'post', transform(code, id) {
    const file = id.split('?')[0].replaceAll('\\', '/'); if (!wanted.includes(file)) return null;
    const input = fs.readFileSync(file), output = 'transforms/' + hash(file).slice(0, 16) + '.js';
    fs.mkdirSync(path.join(dir, 'transforms'), { recursive: true }); fs.writeFileSync(path.join(dir, output), code);
    seen.set(file, { file, inputSha256: hash(input), transformedSha256: hash(code), output });
    fs.writeFileSync(path.join(dir, 'transforms.json'), JSON.stringify([...seen.values()], null, 2)); return null;
  }
}], test: { environment: 'jsdom', globals: true, setupFiles: ["/home/runner/work/ballpark-hero/ballpark-hero/src/test/setup.ts"], include: ["src/test/boxingShowForecast.test.tsx"], maxWorkers: 1, fileParallelism: false, testTimeout: 60000 },
resolve: { alias: { ...JSON.parse(process.env.NO_DOUBLE_SWAP || '{}'), '@': "/home/runner/work/ballpark-hero/ballpark-hero/src" } } });
