/**
 * Stadium Tycoon (Round 146): the idle game, animation first. The owner's
 * ask: an idle sports tycoon of our own, "add more animation especially to
 * the idle game. Suprise me." The surprises are all motion: a live toy match
 * with player dots that actually chase the ball, a crowd that fills the
 * stands seat by seat as the real attendance number grows, money that
 * physically floats off everything, confetti on goals, pulse rings on every
 * purchase, and a streak flame that grows with the run. The balance itself
 * never counts up: it is the engine's number, always (Round 147).
 *
 * No scroll on the core loop (pitch + upgrades fit a phone screen), tiles
 * per the house style, "?" rules modal, everything original.
 *
 * Round 580: two tabs, one tycoon. The page holds the h1 and a Stadium and
 * Academy tab strip; the ground itself is StadiumRoom below, moved here
 * unchanged, and the Academy tab is Wonderkid Factory's academy panel on its
 * own save (docs/design/round-580-tycoon-merge.md). The stadium hook lives on
 * the PAGE, not in the room, so the match clock never stops while you are in
 * the Academy, and the academy panel stays mounted once opened so its clock
 * never stops while you are at the ground. scripts/simTycoonRooms.mjs holds
 * both to it, and its controls rewrite the exact lines marked below.
 */ import { jsxDEV as _jsxDEV, Fragment as _Fragment } from "react/jsx-dev-runtime";
import { lazy, Suspense, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { focusDialogOnMount, escapeCloses } from '@/lib/dialogA11y';
import { cn } from '@/lib/utils';
import { formatNumber } from '@/lib/formatNumber';
import { HelpCircle, Star, X } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { GameNavbar } from '@/components/game/GameNavbar';
import PageSeo from '@/components/seo/PageSeo';
import GameSeoContent from '@/components/seo/GameSeoContent';
import { TRACKS, levelOf, costOf, canBuy, capacity, attendance, incomePerSec, ticketPolicyOf, TICKET_POLICIES, tapValue, repMult, streakMult, prestigeThreshold, canPrestige, fmtMoney as tycoonMoney, boostReady, boostActive, boostChargeSecOf, MILESTONES, opponentName, DIVISIONS, divisionOf, divisionIndex, leagueShape, leagueStandings, leaguePosition, clubNameOptions, ordinal, SINGLE_LEG_BELOW, YOUR_CLUB, newTycoon, newLeague, goalBonus, winBonus, BOOST_CHARGE_SEC, BOOST_DURATION_SEC, WINDFALL_SEC, GOLDEN_CATCH_SEC, offlineRateOf, offlineCapHoursOf, TYCOON_SAVE_KEY, swayMult, STAFF, staffLevelOf, staffCostOf, canHire, totalStaffLevels, ACHIEVEMENTS, ACH_BONUS, goldenActive, GOLDEN_INFO, LEGACY_PERKS, perkLevelOf, perkCostOf, canBuyPerk, legacyPointsOf, totalPerkLevels, pointsForSale, HYPE_MULT, AWAY_MATCHDAY_SEC, SET_PIECE_WINDOW_SEC, GOAL_BONUS_SEC, WIN_BONUS_SEC, PROMOTION_BONUS_SEC, scoringFacts } from '@/lib/stadiumTycoon';
import { useStadiumTycoon } from '@/hooks/useStadiumTycoon';
import { ConfettiBurst, CelebrationStyles } from '@/components/club-manager/Celebration';
import VictoryMoment from '@/components/tycoon/TycoonVictoryMoment';
import { LeagueTableCard } from '@/components/club-manager/LeagueTableCard';
import TycoonPitch from '@/components/tycoon/TycoonPitch';
import TicketPolicyCard from '@/components/tycoon/TicketPolicyCard';
import TycoonSaleReview from '@/components/tycoon/TycoonSaleReview';
import { useTycoonRewards } from '@/hooks/useTycoonRewards';
import { balance, GEM_PAY, loadLedger } from '@/lib/tycoonRewards';
import { deserialize as deserializeAcademy, applyOffline as applyAcademyOffline, SAVE_KEY as ACADEMY_SAVE_KEY, squadEdge } from '@/lib/wonderkidFactory';
import { OVERLAY_ABOVE_BANNER, boxInsideOverlay } from '@/components/game/aboveConsentBanner';
const AcademyPanel = /*#__PURE__*/ lazy(()=>import('@/components/tycoon/AcademyPanel'));
const SetPieceBoard = /*#__PURE__*/ lazy(()=>import('@/components/tycoon/SetPieceBoard').then((module)=>({
            default: module.WatchedSetPieceBoard
        })));
/* ---------- tiny animation helpers ---------- */ /* Round 530 review: the balance used to ease toward s.money by 18 percent a
   frame, so the printed number walked through amounts the club never held,
   most visibly after a purchase and after an away settle. Round 147's rule is
   that emphasis animates and a number never does. The balance is the engine's
   own now, and the arrival still has all its theatre: the money floats off
   the pitch, the pulse rings fire and the confetti lands. */ /** Deterministic pseudo-random for stable crowd seat positions. */ function seatRand(i) {
    const x = Math.sin(i * 127.1 + 311.7) * 43758.5453;
    return x - Math.floor(x);
}
function fmtMoney(n) {
    return formatMoneyText(tycoonMoney(n));
}
function formatMoneyText(text) {
    return text.replace(/\$(-?\d+(?:\.\d+)?)([KMBTQ]?)/g, (_text, amount, unit)=>`$${formatNumber(amount)}${unit}`);
}
/** Round 583: a rate under ten dollars a second keeps its cents, so a new club
 *  reads $4.50 a second as the rules say, and a Turnstile Steward $0.60, not $0. */ function fmtRate(n) {
    return n < 10 ? `$${n.toFixed(2)}` : fmtMoney(n);
}
const CONFETTI_COLORS = [
    '#22c55e',
    '#eab308',
    '#3b82f6',
    '#ef4444',
    '#a855f7',
    '#f97316'
];
export default function StadiumTycoon() {
    const [savedAcademy] = useState(()=>{
        try {
            const now = Date.now();
            const snapshot = deserializeAcademy(localStorage.getItem(ACADEMY_SAVE_KEY), now, loadLedger().gearLevel);
            if (snapshot) applyAcademyOffline(snapshot, now);
            return snapshot;
        } catch  {
            return null;
        }
    });
    const academyRef = useRef(savedAcademy);
    const getEdge = useCallback(()=>academyRef.current ? squadEdge(academyRef.current, loadLedger().gearLevel) : 0, []);
    const onAcademySnapshot = useCallback((snapshot)=>{
        academyRef.current = snapshot;
    }, []);
    const g = useStadiumTycoon(getEdge);
    const [room, setRoom] = useState('stadium');
    /* A returning first team keeps its clock even before the Academy tab opens. */ const [academyOpened, setAcademyOpened] = useState(()=>Boolean(savedAcademy?.firstTeam?.length));
    const [academyStatus, setAcademyStatus] = useState(null);
    const [stadiumNeedsYou, setStadiumNeedsYou] = useState(false);
    const openRoom = (next)=>{
        if (next === 'academy') setAcademyOpened(true);
        setRoom(next);
    };
    /* A tab lights when the room behind it needs you. Never the room you are in. */ const academyAccent = room !== 'academy' && academyStatus !== null && (academyStatus.deadline || academyStatus.bedsFull || academyStatus.moveUp || academyStatus.leavingSoon);
    const stadiumAccent = room !== 'stadium' && stadiumNeedsYou;
    const tabs = [
        {
            id: 'stadium',
            label: 'Stadium',
            emoji: '🏟️',
            accent: stadiumAccent
        },
        {
            id: 'academy',
            label: 'Academy',
            emoji: '🎓',
            accent: academyAccent
        },
        {
            id: 'league',
            label: 'League',
            emoji: '🏆',
            accent: false
        }
    ];
    return /*#__PURE__*/ _jsxDEV("div", {
        id: "dukb-main",
        tabIndex: -1,
        className: "min-h-screen bg-background",
        children: [
            /*#__PURE__*/ _jsxDEV(GameNavbar, {}, void 0, false, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                lineNumber: 136,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV(PageSeo, {
                title: "Stadium Tycoon: Free Idle Soccer Club Game | DoUKnowBall",
                description: "Grow a tiny football club into an empire. Live toy matches, ten divisions, a staff payroll, golden whistles, 47 badges, reputation stars and a legacy boardroom of permanent perks. Free idle game, no sign-up.",
                path: "/stadium-tycoon"
            }, void 0, false, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                lineNumber: 137,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "max-w-2xl mx-auto px-4 py-4 md:py-8",
                children: [
                    /*#__PURE__*/ _jsxDEV(CelebrationStyles, {}, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 143,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("header", {
                        className: "text-center mb-2",
                        children: /*#__PURE__*/ _jsxDEV("h1", {
                            className: "text-3xl md:text-5xl font-bold tracking-[0.08em] text-primary font-display",
                            children: "STADIUM TYCOON"
                        }, void 0, false, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                            lineNumber: 145,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 144,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "grid grid-cols-3 gap-2 mb-2",
                        role: "group",
                        "aria-label": "Tycoon rooms",
                        children: tabs.map((t)=>/*#__PURE__*/ _jsxDEV("button", {
                                type: "button",
                                "data-room": t.id,
                                "data-accent": t.accent ? 'true' : 'false',
                                "aria-pressed": room === t.id,
                                onClick: ()=>openRoom(t.id),
                                className: cn('relative min-h-[40px] rounded-xl border text-sm font-bold transition-all', room === t.id ? 'bg-primary text-primary-foreground border-primary' : 'bg-card border-border text-foreground hover:border-primary'),
                                children: [
                                    t.emoji,
                                    " ",
                                    t.label,
                                    t.accent && /*#__PURE__*/ _jsxDEV(_Fragment, {
                                        children: [
                                            /*#__PURE__*/ _jsxDEV("span", {
                                                "aria-hidden": "true",
                                                className: "absolute top-1.5 right-2 h-2.5 w-2.5 rounded-full bg-yellow-400 motion-safe:animate-pulse"
                                            }, void 0, false, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                lineNumber: 166,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ _jsxDEV("span", {
                                                className: "sr-only",
                                                children: " (needs you)"
                                            }, void 0, false, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                lineNumber: 167,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true)
                                ]
                            }, t.id, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 151,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 149,
                        columnNumber: 9
                    }, this),
                    g.gearSaveBlocked && /*#__PURE__*/ _jsxDEV("p", {
                        role: "alert",
                        "data-no-prerender": true,
                        className: "mb-3 rounded-xl border border-destructive/40 bg-destructive/10 p-3 text-xs",
                        children: "Title equipment could not be saved, so no new equipment was added. Your existing pairs are safe. Allow device storage before earning another title."
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 174,
                        columnNumber: 31
                    }, this),
                    /*#__PURE__*/ _jsxDEV(StadiumRoom, {
                        g: g,
                        visible: room === 'stadium',
                        onNeedsYou: setStadiumNeedsYou
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 175,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV(LeagueRoom, {
                        g: g,
                        visible: room === 'league'
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 176,
                        columnNumber: 9
                    }, this),
                    academyOpened && /*#__PURE__*/ _jsxDEV(Suspense, {
                        fallback: /*#__PURE__*/ _jsxDEV("div", {
                            className: "h-40"
                        }, void 0, false, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                            lineNumber: 178,
                            columnNumber: 31
                        }, void 0),
                        children: /*#__PURE__*/ _jsxDEV(AcademyPanel, {
                            stylesReady: true,
                            visible: room === 'academy',
                            onStatus: setAcademyStatus,
                            onSnapshot: onAcademySnapshot
                        }, void 0, false, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                            lineNumber: 179,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 178,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ _jsxDEV(GameSeoContent, {
                        pageHasOwnH1: true,
                        title: "Stadium Tycoon",
                        description: "Grow a tiny football club into an empire: live toy matches, ten divisions to climb, a staff payroll, golden whistles, 47 badges, reputation stars and a legacy boardroom of permanent perks."
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 183,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                lineNumber: 142,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("style", {
                children: `
        @keyframes stFloat { 0% { opacity: 0; transform: translateY(6px) scale(0.9); } 12% { opacity: 1; transform: translateY(0) scale(1.06); } 100% { opacity: 0; transform: translateY(-46px) scale(1); } }
        .st-float { animation: stFloat 1.8s ease-out forwards; }
        @keyframes stConfetti { 0% { opacity: 1; transform: translateY(-8px) rotate(0deg); } 100% { opacity: 0; transform: translateY(190px) rotate(540deg); } }
        .st-confetti { animation-name: stConfetti; animation-timing-function: ease-in; animation-fill-mode: forwards; }
        @keyframes stGlow { 0%, 100% { box-shadow: 0 0 6px rgba(234,179,8,0.5); } 50% { box-shadow: 0 0 22px rgba(234,179,8,0.9); } }
        .st-glow { animation: stGlow 1.6s ease-in-out infinite; }
        @keyframes stGoldwob { 0%, 100% { transform: rotate(-14deg) scale(1); filter: brightness(1); } 25% { transform: rotate(10deg) scale(1.22); filter: brightness(1.35); } 50% { transform: rotate(-8deg) scale(1.05); filter: brightness(1.1); } 75% { transform: rotate(12deg) scale(1.18); filter: brightness(1.3); } }
        .st-goldwob { animation: stGoldwob 0.9s ease-in-out infinite; }
        /* Round 530: the setting the visitor already made. The two loops stop
           looping, the floaters land as plain text until they are cleared, and
           the confetti (decoration, nothing to read) does not run at all. */
        @media (prefers-reduced-motion: reduce) {
          .st-glow, .st-goldwob { animation: none; }
          .st-float { animation: none; opacity: 1; transform: none; }
          .st-confetti { display: none; }
        }
      `
            }, void 0, false, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                lineNumber: 191,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
        lineNumber: 135,
        columnNumber: 5
    }, this);
}
/** Round 583: every number the rules modal states, read off the engine when the
 *  modal opens. Called at render, never at module scope (the import cycle rule). */ function helpFacts() {
    const fresh = newTycoon(0);
    const full = {
        ...fresh,
        fanbase: 400,
        levels: {
            ...fresh.levels,
            stands: 7
        }
    };
    const maxed = {
        ...fresh,
        legacyPerks: Object.fromEntries(LEGACY_PERKS.map((p)=>[
                p.id,
                p.costs.length
            ]))
    };
    const byId = (id)=>MILESTONES.find((m)=>m.id === id)?.label.toLowerCase() ?? '';
    const perk = (id)=>LEGACY_PERKS.find((p)=>p.id === id);
    const scoring = scoringFacts();
    return {
        chargeMin: BOOST_CHARGE_SEC / 60,
        voltage1: boostChargeSecOf({
            ...fresh,
            legacyPerks: {
                voltage: 1
            }
        }) / 60,
        voltage2: boostChargeSecOf({
            ...fresh,
            legacyPerks: {
                voltage: 2
            }
        }) / 60,
        hypeSec: BOOST_DURATION_SEC,
        divisions: DIVISIONS.length,
        firstDivision: DIVISIONS[0].name,
        lastDivision: DIVISIONS[DIVISIONS.length - 1].name,
        topMult: DIVISIONS[DIVISIONS.length - 1].incomeMult,
        staff: STAFF.length,
        firstStaff: STAFF[0].name,
        lastStaff: STAFF[STAFF.length - 1].name,
        catchSec: GOLDEN_CATCH_SEC,
        prizes: Object.keys(GOLDEN_INFO).length,
        windfallMin: WINDFALL_SEC / 60,
        milestoneExamples: `${byId('win1')}, ${byId('full')}, ${byId('fans10k')} and ${byId('streak5')}`,
        milestones: MILESTONES.length,
        badges: ACHIEVEMENTS.length,
        firstBadge: ACHIEVEMENTS[0].label,
        lastBadge: ACHIEVEMENTS[ACHIEVEMENTS.length - 1].label,
        badgePct: Math.round(ACH_BONUS * 100),
        starPct: Math.round((repMult({
            ...fresh,
            rep: 1
        }) - 1) * 100),
        saleBase: pointsForSale(fresh),
        summitPoints: pointsForSale({
            ...fresh,
            league: newLeague(0, DIVISIONS.length - 1, 0)
        }),
        perks: LEGACY_PERKS.length,
        firstPerk: perk('sway')?.name ?? '',
        swayPct: Math.round((swayMult({
            ...fresh,
            legacyPerks: {
                sway: 1
            }
        }) - 1) * 100),
        perDivision: pointsForSale({
            ...fresh,
            league: newLeague(0, 1, 0)
        }) - pointsForSale(fresh),
        shieldPerk: perk('shield')?.name ?? '',
        boardCost: LEGACY_PERKS.reduce((a, p)=>a + p.costs.reduce((x, y)=>x + y, 0), 0),
        awayPct: Math.round(offlineRateOf(fresh) * 100),
        awayHours: offlineCapHoursOf(fresh),
        awayPerk: perk('away')?.name ?? '',
        awayMaxPct: Math.round(offlineRateOf(maxed) * 100),
        awayMaxHours: offlineCapHoursOf(maxed),
        awayMatchMin: AWAY_MATCHDAY_SEC / 60,
        freshFans: fresh.fanbase,
        perFan: (incomePerSec(fresh) / attendance(fresh)).toFixed(2),
        freshRate: incomePerSec(fresh).toFixed(2),
        standsCost: costOf(fresh, 'stands'),
        seatsPerStand: capacity({
            ...fresh,
            levels: {
                ...fresh.levels,
                stands: 1
            }
        }) - capacity(fresh),
        exampleFans: attendance(full),
        /* Release AL: the ticket offers (Round 1080), read off the engine's own
       table so the rules can never quote a rate the game does not use. */ ticketCommunityCut: Math.round((1 - (TICKET_POLICIES.find((p)=>p.id === 'community')?.gate ?? 1)) * 100),
        ticketCommunityGrowth: Math.round(((TICKET_POLICIES.find((p)=>p.id === 'community')?.growth ?? 1) - 1) * 100),
        ticketPremiumGate: Math.round(((TICKET_POLICIES.find((p)=>p.id === 'premium')?.gate ?? 1) - 1) * 100),
        ticketPremiumDemand: Math.round((TICKET_POLICIES.find((p)=>p.id === 'premium')?.demand ?? 1) * 100),
        ticketPremiumGrowth: Math.round((1 - (TICKET_POLICIES.find((p)=>p.id === 'premium')?.growth ?? 1)) * 100),
        freshSeats: capacity(fresh),
        freshPremiumCrowd: attendance({
            ...fresh,
            ticketPolicy: 'premium'
        }),
        rate400: incomePerSec(full),
        goal400: goalBonus(full),
        win400: winBonus(full),
        /* Round 1532: the scoring law and the bonuses in seconds, read off the engine. */ evenFor: scoring.evenFor,
        evenAgainst: scoring.evenAgainst,
        levelGoals: scoring.levelGoals,
        goalSec: GOAL_BONUS_SEC,
        winSec: WIN_BONUS_SEC,
        promotionMin: PROMOTION_BONUS_SEC / 60
    };
}
/* Release AP: exported so src/test/tycoonLatestSeason.test.tsx can read the dialog's numbers on any tree
   (Round 1095's own driver only runs on its own branch). */ export function LatestSeasonReview({ last, league }) {
    const [open, setOpen] = useState(false);
    const [snapshot, setSnapshot] = useState(last);
    const trigger = useRef(null);
    const heading = useRef(null);
    const changeOpen = (next)=>{
        if (next) setSnapshot({
            ...last,
            table: last.table.map((club)=>({
                    ...club
                }))
        });
        setOpen(next);
    };
    const formatSeasonCount = (value)=>value.toLocaleString('en-US');
    const own = snapshot.table[0];
    const rows = leagueStandings({
        ...league,
        clubs: snapshot.table
    });
    return /*#__PURE__*/ _jsxDEV(Dialog, {
        open: open,
        onOpenChange: changeOpen,
        children: [
            /*#__PURE__*/ _jsxDEV(DialogTrigger, {
                asChild: true,
                children: /*#__PURE__*/ _jsxDEV("button", {
                    ref: trigger,
                    type: "button",
                    "data-last-season": true,
                    className: "min-h-11 min-w-11 w-full rounded-xl border border-border bg-card px-3 py-2 text-left text-xs hover:border-primary focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary",
                    children: [
                        /*#__PURE__*/ _jsxDEV("span", {
                            className: "block font-bold",
                            children: "Latest season"
                        }, void 0, false, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                            lineNumber: 304,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV("span", {
                            className: "text-muted-foreground",
                            children: [
                                ordinal(last.position),
                                " of ",
                                formatSeasonCount(last.table.length),
                                " · Review this visit's result"
                            ]
                        }, void 0, true, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                            lineNumber: 305,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                    lineNumber: 303,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                lineNumber: 302,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV(DialogContent, {
                "data-latest-season-review": true,
                className: "flex max-h-[calc(100dvh_-_2rem)] w-[calc(100vw_-_2rem)] max-w-md flex-col gap-3 rounded-xl p-4 text-xs [&>button:last-child]:h-11 [&>button:last-child]:w-11",
                onOpenAutoFocus: (event)=>{
                    event.preventDefault();
                    heading.current?.focus({
                        preventScroll: true
                    });
                },
                onCloseAutoFocus: (event)=>{
                    event.preventDefault();
                    trigger.current?.focus({
                        preventScroll: true
                    });
                },
                children: [
                    /*#__PURE__*/ _jsxDEV(DialogTitle, {
                        ref: heading,
                        tabIndex: -1,
                        className: "pr-12 text-base",
                        children: "Latest season"
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 311,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV(DialogDescription, {
                        className: "text-xs",
                        children: "Available for this visit only. The match keeps running while you read."
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 312,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "min-h-0 space-y-3 overflow-y-auto text-xs",
                        children: [
                            /*#__PURE__*/ _jsxDEV("p", {
                                "data-season-headline": true,
                                className: "break-words font-bold text-primary",
                                children: snapshot.label
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 314,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ _jsxDEV("dl", {
                                className: "grid grid-cols-2 gap-3 rounded-lg border border-border p-3",
                                children: [
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        children: [
                                            /*#__PURE__*/ _jsxDEV("dt", {
                                                className: "text-muted-foreground",
                                                children: "Finished"
                                            }, void 0, false, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                lineNumber: 316,
                                                columnNumber: 18
                                            }, this),
                                            /*#__PURE__*/ _jsxDEV("dd", {
                                                "data-season-position": true,
                                                className: "font-bold",
                                                children: [
                                                    ordinal(snapshot.position),
                                                    " of ",
                                                    formatSeasonCount(snapshot.table.length)
                                                ]
                                            }, void 0, true, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                lineNumber: 316,
                                                columnNumber: 69
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 316,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        children: [
                                            /*#__PURE__*/ _jsxDEV("dt", {
                                                className: "text-muted-foreground",
                                                children: "Points"
                                            }, void 0, false, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                lineNumber: 317,
                                                columnNumber: 18
                                            }, this),
                                            /*#__PURE__*/ _jsxDEV("dd", {
                                                "data-season-points": true,
                                                className: "break-words font-bold",
                                                children: formatSeasonCount(own.pts)
                                            }, void 0, false, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                lineNumber: 317,
                                                columnNumber: 67
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 317,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        children: [
                                            /*#__PURE__*/ _jsxDEV("dt", {
                                                className: "text-muted-foreground",
                                                children: "Wins / draws / losses"
                                            }, void 0, false, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                lineNumber: 318,
                                                columnNumber: 18
                                            }, this),
                                            /*#__PURE__*/ _jsxDEV("dd", {
                                                "data-season-record": true,
                                                className: "break-words font-bold",
                                                children: [
                                                    formatSeasonCount(own.w),
                                                    " / ",
                                                    formatSeasonCount(own.d),
                                                    " / ",
                                                    formatSeasonCount(own.l)
                                                ]
                                            }, void 0, true, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                lineNumber: 318,
                                                columnNumber: 82
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 318,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        children: [
                                            /*#__PURE__*/ _jsxDEV("dt", {
                                                className: "text-muted-foreground",
                                                children: "Goals for / against"
                                            }, void 0, false, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                lineNumber: 319,
                                                columnNumber: 18
                                            }, this),
                                            /*#__PURE__*/ _jsxDEV("dd", {
                                                "data-season-goals": true,
                                                className: "break-words font-bold",
                                                children: [
                                                    formatSeasonCount(own.gf),
                                                    " / ",
                                                    formatSeasonCount(own.ga)
                                                ]
                                            }, void 0, true, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                lineNumber: 319,
                                                columnNumber: 80
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 319,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 315,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ _jsxDEV("table", {
                                "data-latest-season-table": true,
                                className: "w-full table-fixed text-left text-xs",
                                children: [
                                    /*#__PURE__*/ _jsxDEV("caption", {
                                        className: "pb-2 text-left font-bold",
                                        children: "Final table"
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 322,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("thead", {
                                        children: /*#__PURE__*/ _jsxDEV("tr", {
                                            className: "border-b border-border text-muted-foreground",
                                            children: [
                                                /*#__PURE__*/ _jsxDEV("th", {
                                                    scope: "col",
                                                    className: "w-1/2 pb-2 font-normal",
                                                    children: "Club"
                                                }, void 0, false, {
                                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                    lineNumber: 323,
                                                    columnNumber: 81
                                                }, this),
                                                /*#__PURE__*/ _jsxDEV("th", {
                                                    scope: "col",
                                                    className: "w-1/3 pb-2 font-normal",
                                                    children: "W / D / L"
                                                }, void 0, false, {
                                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                    lineNumber: 323,
                                                    columnNumber: 141
                                                }, this),
                                                /*#__PURE__*/ _jsxDEV("th", {
                                                    scope: "col",
                                                    className: "pb-2 text-right font-normal",
                                                    children: "Pts"
                                                }, void 0, false, {
                                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                    lineNumber: 323,
                                                    columnNumber: 206
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                            lineNumber: 323,
                                            columnNumber: 20
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 323,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("tbody", {
                                        children: rows.map((club, index)=>/*#__PURE__*/ _jsxDEV("tr", {
                                                "data-season-club": club.name,
                                                className: cn('border-b border-border/40 align-top', club === own && 'bg-primary/10'),
                                                children: [
                                                    /*#__PURE__*/ _jsxDEV("th", {
                                                        scope: "row",
                                                        className: "py-2 pr-2 text-left font-normal",
                                                        children: /*#__PURE__*/ _jsxDEV("div", {
                                                            className: "flex gap-2",
                                                            children: [
                                                                /*#__PURE__*/ _jsxDEV("span", {
                                                                    className: "shrink-0 font-bold",
                                                                    children: formatSeasonCount(index + 1)
                                                                }, void 0, false, {
                                                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                                    lineNumber: 326,
                                                                    columnNumber: 105
                                                                }, this),
                                                                /*#__PURE__*/ _jsxDEV("span", {
                                                                    className: "min-w-0 break-words",
                                                                    children: club.name
                                                                }, void 0, false, {
                                                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                                    lineNumber: 326,
                                                                    columnNumber: 179
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                            lineNumber: 326,
                                                            columnNumber: 77
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                        lineNumber: 326,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV("td", {
                                                        className: "break-words py-2 pr-2",
                                                        children: [
                                                            /*#__PURE__*/ _jsxDEV("div", {
                                                                children: [
                                                                    formatSeasonCount(club.w),
                                                                    " / ",
                                                                    formatSeasonCount(club.d),
                                                                    " / ",
                                                                    formatSeasonCount(club.l)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                                lineNumber: 327,
                                                                columnNumber: 55
                                                            }, this),
                                                            /*#__PURE__*/ _jsxDEV("div", {
                                                                className: "text-muted-foreground",
                                                                children: [
                                                                    "GF ",
                                                                    formatSeasonCount(club.gf),
                                                                    /*#__PURE__*/ _jsxDEV("br", {}, void 0, false, {
                                                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                                        lineNumber: 327,
                                                                        columnNumber: 223
                                                                    }, this),
                                                                    "GA ",
                                                                    formatSeasonCount(club.ga)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                                lineNumber: 327,
                                                                columnNumber: 153
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                        lineNumber: 327,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV("td", {
                                                        className: "break-words py-2 text-right font-bold",
                                                        children: formatSeasonCount(club.pts)
                                                    }, void 0, false, {
                                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                        lineNumber: 328,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, club.name, true, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                lineNumber: 325,
                                                columnNumber: 15
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 324,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 321,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 313,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("button", {
                        type: "button",
                        onClick: ()=>changeOpen(false),
                        className: "min-h-11 min-w-11 w-full shrink-0 rounded-lg border border-border px-3 text-xs font-bold hover:bg-secondary focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary",
                        children: "Back"
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 333,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                lineNumber: 308,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
        lineNumber: 301,
        columnNumber: 5
    }, this);
}
/* Round 582: the league. The table through Club Manager's own card, today's
   fixture, and the club name picked from the generated banks. Never the
   default tab, so none of it reaches a snapshot. */ function LeagueRoom({ g, visible }) {
    if (!visible) return null;
    const s = g.state;
    const lg = s.league;
    if (!lg) return null;
    const shape = leagueShape(lg.division);
    const div = DIVISIONS[lg.division];
    const rows = leagueStandings(lg).map((c)=>({
            club: c.name,
            w: c.w,
            d: c.d,
            l: c.l,
            gf: c.gf,
            ga: c.ga,
            pts: c.pts
        }));
    const preseason = lg.matchday === 0;
    const options = s.clubName ? [] : clubNameOptions(s);
    const atSummit = lg.division >= DIVISIONS.length - 1;
    const last = g.lastSeason;
    return /*#__PURE__*/ _jsxDEV("div", {
        "data-league-room": true,
        className: "space-y-3 mb-3",
        children: [
            /*#__PURE__*/ _jsxDEV("div", {
                className: "rounded-xl border border-border bg-card px-3 py-2 text-xs text-muted-foreground",
                children: [
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "font-bold text-foreground",
                        children: [
                            div.emoji,
                            " ",
                            div.name
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 357,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "mt-0.5",
                        children: [
                            lg.carryover ? `Finishing a friendly against ${opponentName(s)}, then matchday 1 of ${shape.matchdays}.` : `Matchday ${lg.matchday + 1} of ${shape.matchdays}: ${opponentName(s)} at your ground.`,
                            ' ',
                            atSummit ? 'This is the top: win the title and it pays the bonus again.' : 'Only the champion goes up.'
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 358,
                        columnNumber: 9
                    }, this),
                    (s.leagueTitles ?? 0) > 0 && /*#__PURE__*/ _jsxDEV("div", {
                        className: "mt-0.5 text-gold font-bold",
                        children: [
                            "🏆 ",
                            s.leagueTitles,
                            " league title",
                            s.leagueTitles === 1 ? '' : 's',
                            " in your career"
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 364,
                        columnNumber: 39
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                lineNumber: 356,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV(LeagueTableCard, {
                rows: rows,
                myClub: lg.clubs[0].name,
                title: `Season ${lg.season + 1} at this ground`,
                preseason: preseason,
                zoneTop: 1
            }, void 0, false, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                lineNumber: 366,
                columnNumber: 7
            }, this),
            last && /*#__PURE__*/ _jsxDEV(LatestSeasonReview, {
                last: last,
                league: lg
            }, void 0, false, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                lineNumber: 367,
                columnNumber: 16
            }, this),
            options.length > 0 && /*#__PURE__*/ _jsxDEV("div", {
                "data-club-name-pick": true,
                className: "rounded-xl border border-border bg-card p-3",
                children: [
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "text-xs font-bold text-foreground mb-2",
                        children: "Name your club"
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 370,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "grid grid-cols-1 gap-2",
                        children: [
                            options.map((name)=>/*#__PURE__*/ _jsxDEV("button", {
                                    type: "button",
                                    onClick: ()=>g.doSetClubName(name),
                                    className: "min-h-[40px] rounded-lg border border-border bg-background/40 text-sm font-bold text-foreground hover:border-primary",
                                    children: name
                                }, name, false, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                    lineNumber: 373,
                                    columnNumber: 15
                                }, this)),
                            /*#__PURE__*/ _jsxDEV("button", {
                                type: "button",
                                onClick: ()=>g.doSetClubName(YOUR_CLUB),
                                className: "min-h-[40px] rounded-lg text-xs text-muted-foreground hover:text-foreground",
                                children: [
                                    'Keep "',
                                    YOUR_CLUB,
                                    '"'
                                ]
                            }, void 0, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 377,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 371,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                lineNumber: 369,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
        lineNumber: 355,
        columnNumber: 5
    }, this);
}
/* The ground. Everything the page used to render, unchanged, except that it
   renders nothing while the Academy tab is showing and holds its two cards'
   timers until you are looking again. Its hooks keep running either way. */ function StadiumRoom({ g, visible, onNeedsYou }) {
    const s = g.state;
    const kickClosed = !g.activeSetPiece || s.rep !== g.activeSetPiece.rep || (s.totalMatches ?? 0) !== g.activeSetPiece.match || s.minute >= 90;
    /* Round 585: the gems this club's results have earned. */ const gems = balance(useTycoonRewards());
    const [showHelp, setShowHelp] = useState(false);
    /* Round 583: the rules open themselves once, before first play, the way the
     academy's always have. A save on this device means somebody has played. */ useEffect(()=>{
        try {
            if (!localStorage.getItem(TYCOON_SAVE_KEY)) setShowHelp(true);
        } catch  {}
    }, []);
    /* Round 162: the drawers (Round 196 added the boardroom). Round 583: all five
     rooms of the office are tiles now, one panel open at a time, Upgrades first
     because buying is the loop. */ const [panel, setPanel] = useState('upgrades');
    const [burst, setBurst] = useState(null);
    const pitchRef = useRef(null);
    /* Round 583: floaters are positioned inside the pitch, so the tap is measured
     on the pitch too. It was measured on the stand-plus-pitch wrapper, which put
     every tap floater below where the finger landed. */ const pitchAreaRef = useRef(null);
    /* Round 583: a tap's pop and sparks, and the taps chip. Display only: the tap
     is the hook's, and the chip counts taps, it never multiplies them. */ const [tapFx, setTapFx] = useState(null);
    const [tapRun, setTapRun] = useState(0);
    const tapRunTimer = useRef(undefined);
    useEffect(()=>()=>window.clearTimeout(tapRunTimer.current), []);
    const tapAt = (x, y)=>{
        g.doTap(x, y);
        setTapFx((f)=>({
                seq: (f?.seq ?? 0) + 1,
                x,
                y
            }));
        setTapRun((r)=>r + 1);
        window.clearTimeout(tapRunTimer.current);
        tapRunTimer.current = window.setTimeout(()=>setTapRun(0), 1500);
    };
    /* Round 583: goals are replayed only while the pitch is on screen. */ const { watchReplays } = g;
    useEffect(()=>{
        watchReplays(visible);
    }, [
        visible,
        watchReplays
    ]);
    const fans = attendance(s);
    const cap = capacity(s);
    const rate = incomePerSec(s);
    const div = divisionOf(s);
    /* Round 582: where this ground stands in its league. */ const lg = s.league;
    const lgShape = lg ? leagueShape(lg.division) : null;
    const lgPos = lg ? leaguePosition(lg) : 0;
    /* Round 584: where the table stood when you came back, from the hook's snapshot. */ const standing = g.awayTrip?.standing ?? null;
    const awayTableLine = !standing ? '' : standing.left <= 1 ? `You are ${ordinal(standing.position)} of ${standing.clubs}, and the final matchday is waiting for you.` : `You are ${ordinal(standing.position)} of ${standing.clubs} with ${standing.left} matchdays to go.`;
    const atSummit = divisionIndex(s) >= DIVISIONS.length - 1;
    const achCount = (s.ach ?? []).length;
    const pts = legacyPointsOf(s);
    const affordable = TRACKS.filter((t)=>canBuy(s, t.id)).length;
    const officeTiles = [
        {
            key: 'upgrades',
            icon: '🏗️',
            title: 'Upgrades',
            value: affordable > 0 ? `${affordable} ready` : 'saving up',
            accent: false
        },
        {
            key: 'tickets',
            icon: '🎟️',
            title: 'Ticket offer',
            value: TICKET_POLICIES.find((p)=>p.id === ticketPolicyOf(s))?.label ?? 'Standard',
            accent: false
        },
        {
            key: 'payroll',
            icon: '🧑‍🤝‍🧑',
            title: 'Payroll',
            value: `${totalStaffLevels(s)} hired`,
            accent: false
        },
        {
            key: 'ach',
            icon: '🏅',
            title: 'Badges',
            value: `${achCount}/${ACHIEVEMENTS.length}`,
            accent: false
        },
        {
            key: 'legacy',
            icon: '🏛️',
            title: 'Legacy',
            value: pts > 0 ? `${pts} pts` : 'boardroom',
            accent: pts > 0
        },
        {
            key: 'stats',
            icon: '📊',
            title: 'Records',
            value: `${s.totalWins.toLocaleString('en-US')} wins`,
            accent: false
        }
    ];
    /* What a sale pays once this league is won: the engine's answer one division up. */ const saleAfterTitle = lg ? pointsForSale({
        ...s,
        league: {
            ...lg,
            division: Math.min(lg.division + 1, DIVISIONS.length - 1)
        }
    }) : pointsForSale(s);
    // Goal confetti: a fresh burst every time the hook's counter moves.
    useEffect(()=>{
        if (g.confetti === 0) return;
        const pieces = Array.from({
            length: 26
        }, (_, i)=>({
                x: 8 + seatRand(i + g.confetti * 31) * 84,
                d: 0.5 + seatRand(i * 7 + g.confetti) * 0.9,
                c: CONFETTI_COLORS[i % CONFETTI_COLORS.length],
                r: Math.floor(seatRand(i * 13 + g.confetti * 3) * 360)
            }));
        setBurst({
            id: g.confetti,
            pieces
        });
        const t = setTimeout(()=>setBurst(null), 1700);
        return ()=>clearTimeout(t);
    }, [
        g.confetti
    ]);
    /* Round 583: the toy match used to reshuffle ten dots and a ball on a 1900ms
     timer that knew nothing about the goals. The pitch is TycoonPitch now, and
     everything on it moves with the engine's match. */ const standBays = useMemo(()=>Array.from({
            length: Math.min(203, Math.floor(cap / 40))
        }, (_, i)=>{
            const column = i % 20;
            const centered = column % 2 === 0 ? 9 - Math.floor(column / 2) : 10 + Math.floor(column / 2);
            return {
                x: 8 + centered * 15,
                y: 56 - Math.floor(i / 20) * 5
            };
        }), [
        cap
    ]);
    /* The crowd: one dot per ~14 fans, placed deterministically so the stand
     fills seat by seat as attendance really grows. Capped for perf. */ const crowdDots = useMemo(()=>{
        const n = Math.min(220, Math.floor(fans / 14));
        return Array.from({
            length: n
        }, (_, i)=>({
                x: 2 + seatRand(i * 11) * 96,
                y: seatRand(i * 23) * 78,
                c: seatRand(i * 5) < 0.5 ? 'bg-primary/70' : 'bg-yellow-500/70'
            }));
    }, [
        fans
    ]);
    /* Round 530: the promotion card sits on the pitch for four seconds or until
     Continue, and a badge line above the drawers for four seconds. Both are
     the hook's own event fields; the timers only take them down. */ useEffect(()=>{
        if (!g.promotion || !visible) return;
        const t = window.setTimeout(g.dismissPromotion, 4000);
        return ()=>window.clearTimeout(t);
    }, [
        g.promotion,
        g.dismissPromotion,
        visible
    ]);
    useEffect(()=>{
        if (!g.badge || !visible) return;
        const t = window.setTimeout(g.dismissBadge, 4000);
        return ()=>window.clearTimeout(t);
    }, [
        g.badge,
        g.dismissBadge,
        visible
    ]);
    /* Round 580: the Stadium tab lights while a card or the away total is waiting. */ useEffect(()=>{
        onNeedsYou(Boolean(g.promotion || g.badge || g.awayPay !== null));
    }, [
        g.promotion,
        g.badge,
        g.awayPay,
        onNeedsYou
    ]);
    const onPitchClick = (e)=>{
        const el = pitchAreaRef.current ?? pitchRef.current;
        if (!el) return;
        const r = el.getBoundingClientRect();
        const pct = (v)=>Number.isFinite(v) ? Math.min(100, Math.max(0, v)) : 50;
        tapAt(pct((e.clientX - r.left) / r.width * 100), pct((e.clientY - r.top) / r.height * 100));
    };
    if (!visible) return null;
    return /*#__PURE__*/ _jsxDEV(_Fragment, {
        children: [
            /*#__PURE__*/ _jsxDEV("div", {
                className: "text-center mb-3",
                children: [
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "inline-flex items-center gap-1.5 mt-1 text-xs font-bold text-foreground bg-secondary rounded-full px-3 py-0.5",
                        children: [
                            div.emoji,
                            " ",
                            div.name,
                            /*#__PURE__*/ _jsxDEV("span", {
                                className: "text-[10px] text-muted-foreground font-normal",
                                children: lg && lgShape ? lg.carryover ? `· a friendly first, then matchday 1 of ${lgShape.matchdays}` : lg.matchday === 0 ? `· matchday 1 of ${lgShape.matchdays}` : `· ${ordinal(lgPos)} of ${lg.clubs.length} · matchday ${Math.min(lg.matchday + 1, lgShape.matchdays)} of ${lgShape.matchdays}` : ''
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 527,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 525,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "flex items-center justify-center gap-3 mt-1 text-xs text-muted-foreground",
                        children: [
                            /*#__PURE__*/ _jsxDEV("span", {
                                className: "inline-flex items-center gap-1",
                                children: [
                                    Array.from({
                                        length: Math.min(s.rep, 6)
                                    }, (_, i)=>/*#__PURE__*/ _jsxDEV(Star, {
                                            className: "w-3 h-3 fill-yellow-500 text-yellow-500"
                                        }, i, false, {
                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                            lineNumber: 539,
                                            columnNumber: 116
                                        }, this)),
                                    s.rep > 6 && /*#__PURE__*/ _jsxDEV("span", {
                                        className: "font-bold text-yellow-500",
                                        children: [
                                            "x",
                                            s.rep
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 539,
                                        columnNumber: 200
                                    }, this),
                                    s.rep > 0 && /*#__PURE__*/ _jsxDEV("span", {
                                        className: "text-yellow-500 font-bold",
                                        children: [
                                            "rep ",
                                            Math.round((repMult(s) - 1) * 100),
                                            "%"
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 539,
                                        columnNumber: 274
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 539,
                                columnNumber: 13
                            }, this),
                            achCount > 0 && /*#__PURE__*/ _jsxDEV("span", {
                                className: "text-emerald-400 font-bold",
                                children: [
                                    "badges +",
                                    Math.round(achCount * ACH_BONUS * 100),
                                    "%"
                                ]
                            }, void 0, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 540,
                                columnNumber: 30
                            }, this),
                            /*#__PURE__*/ _jsxDEV("span", {
                                "data-gem-chip": true,
                                className: "font-bold text-sky-300",
                                children: [
                                    "💎 ",
                                    gems,
                                    " gem",
                                    gems === 1 ? '' : 's'
                                ]
                            }, void 0, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 541,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ _jsxDEV("button", {
                                onClick: ()=>setShowHelp(true),
                                className: "inline-flex items-center gap-1 px-2 py-2 transition-colors hover:text-foreground",
                                children: [
                                    /*#__PURE__*/ _jsxDEV(HelpCircle, {
                                        className: "w-3.5 h-3.5"
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 542,
                                        columnNumber: 148
                                    }, this),
                                    " How it works"
                                ]
                            }, void 0, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 542,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 538,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                lineNumber: 522,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "flex items-end justify-between mb-2 px-1",
                children: [
                    /*#__PURE__*/ _jsxDEV("div", {
                        children: [
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "text-3xl md:text-4xl font-bold font-display text-gold tabular-nums",
                                children: fmtMoney(s.money)
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 549,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "text-[11px] text-muted-foreground",
                                children: [
                                    "+",
                                    fmtRate(rate),
                                    "/s",
                                    boostActive(s) && /*#__PURE__*/ _jsxDEV("span", {
                                        className: "text-yellow-400 font-bold",
                                        children: [
                                            " · HYPE x",
                                            HYPE_MULT,
                                            " (",
                                            Math.ceil(s.boostLeftSec),
                                            "s)"
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 552,
                                        columnNumber: 34
                                    }, this),
                                    goldenActive(s) && s.goldenKind && /*#__PURE__*/ _jsxDEV("span", {
                                        className: "text-amber-300 font-bold",
                                        children: [
                                            " · ",
                                            GOLDEN_INFO[s.goldenKind].label,
                                            " (",
                                            Math.ceil(s.goldenLeftSec ?? 0),
                                            "s)"
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 554,
                                        columnNumber: 17
                                    }, this),
                                    s.streak >= 2 && /*#__PURE__*/ _jsxDEV("span", {
                                        className: "text-orange-400 font-bold",
                                        children: [
                                            " · streak x",
                                            streakMult(s).toFixed(2)
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 556,
                                        columnNumber: 33
                                    }, this),
                                    divisionIndex(s) > 0 && /*#__PURE__*/ _jsxDEV("span", {
                                        className: "text-sky-400 font-bold",
                                        children: [
                                            " · stage x",
                                            div.incomeMult.toFixed(2)
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 557,
                                        columnNumber: 40
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 550,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 548,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "text-right",
                        children: [
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "text-sm font-bold text-foreground tabular-nums",
                                children: [
                                    fans.toLocaleString('en-US'),
                                    " ",
                                    /*#__PURE__*/ _jsxDEV("span", {
                                        className: "text-[10px] text-muted-foreground font-normal",
                                        children: [
                                            "/ ",
                                            cap.toLocaleString('en-US'),
                                            " seats"
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 561,
                                        columnNumber: 108
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 561,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "text-[11px] text-muted-foreground",
                                children: [
                                    Math.floor(s.fanbase).toLocaleString('en-US'),
                                    " fans follow you"
                                ]
                            }, void 0, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 562,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 560,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                lineNumber: 547,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ _jsxDEV("button", {
                onClick: g.doBoost,
                disabled: !boostReady(s),
                className: cn('relative w-full mb-2 py-2 rounded-xl font-bold text-sm overflow-hidden border transition-all', boostActive(s) ? 'border-yellow-500 bg-yellow-500/15 text-yellow-400' : boostReady(s) ? 'border-yellow-500 bg-yellow-500 text-black st-glow' : 'border-border bg-card text-muted-foreground'),
                children: [
                    !boostActive(s) && !boostReady(s) && /*#__PURE__*/ _jsxDEV("span", {
                        className: "absolute inset-y-0 left-0 bg-yellow-500/15 transition-all duration-700",
                        style: {
                            width: `${Math.min(100, (s.boostChargeSec ?? 0) / boostChargeSecOf(s) * 100)}%`
                        }
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 580,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ _jsxDEV("span", {
                        className: "relative",
                        children: boostActive(s) ? `🔥 HYPE IS LIVE: income pays x${HYPE_MULT} (${Math.ceil(s.boostLeftSec)}s)` : boostReady(s) ? `📣 MATCHDAY HYPE READY: press for x${HYPE_MULT}` : `📣 Matchday Hype charging: ${Math.floor((s.boostChargeSec ?? 0) / boostChargeSecOf(s) * 100)}%`
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 582,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                lineNumber: 569,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ _jsxDEV("button", {
                type: "button",
                "data-tap-key": true,
                onClick: ()=>tapAt(50, 50),
                className: "sr-only focus:not-sr-only focus:mb-2 focus:block focus:w-full focus:rounded-xl focus:border focus:border-primary focus:py-2 focus:text-sm focus:font-bold",
                children: [
                    "Tap the stadium for ",
                    fmtMoney(tapValue(s))
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                lineNumber: 594,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                ref: pitchRef,
                onClick: onPitchClick,
                className: "relative rounded-2xl overflow-hidden border border-border cursor-pointer select-none mb-3 group",
                children: [
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "relative h-16 md:h-20 bg-gradient-to-b from-secondary to-secondary/40 border-b border-border overflow-hidden",
                        children: [
                            /*#__PURE__*/ _jsxDEV("svg", {
                                "data-tycoon-terraces": true,
                                "aria-hidden": "true",
                                viewBox: "0 0 320 64",
                                preserveAspectRatio: "none",
                                className: "absolute inset-0 h-full w-full pointer-events-none text-muted-foreground/50",
                                children: standBays.map((bay, i)=>/*#__PURE__*/ _jsxDEV("rect", {
                                        x: bay.x,
                                        y: bay.y,
                                        width: "13",
                                        height: "3",
                                        rx: "1",
                                        fill: "currentColor"
                                    }, i, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 602,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 600,
                                columnNumber: 13
                            }, this),
                            crowdDots.map((d, i)=>/*#__PURE__*/ _jsxDEV("span", {
                                    className: cn('absolute w-1.5 h-1.5 rounded-full transition-opacity duration-700', d.c),
                                    style: {
                                        left: `${d.x}%`,
                                        top: `${d.y}%`
                                    }
                                }, i, false, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                    lineNumber: 606,
                                    columnNumber: 15
                                }, this)),
                            fans < 30 && /*#__PURE__*/ _jsxDEV("span", {
                                className: "absolute inset-0 flex items-center justify-center text-[10px] text-muted-foreground",
                                children: "the stand is nearly empty. build something worth watching"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 608,
                                columnNumber: 27
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 599,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ _jsxDEV(TycoonPitch, {
                        areaRef: pitchAreaRef,
                        goalsFor: s.goalsFor,
                        goalsAgainst: s.goalsAgainst,
                        minute: s.minute,
                        totalMatches: s.totalMatches ?? 0,
                        streak: s.streak,
                        opponent: opponentName(s),
                        replays: g.replays,
                        onReplayEnd: g.endReplay,
                        tapFx: tapFx,
                        tapRun: tapRun,
                        children: [
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "absolute bottom-1.5 right-2 text-[10px] text-white/90 group-hover:text-white transition-colors",
                                children: [
                                    "tap anywhere: +",
                                    fmtMoney(tapValue(s))
                                ]
                            }, void 0, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 625,
                                columnNumber: 13
                            }, this),
                            g.floaters.map((f)=>/*#__PURE__*/ _jsxDEV("span", {
                                    className: cn('absolute pointer-events-none font-bold st-float whitespace-nowrap', f.kind === 'goal' && 'text-yellow-300 text-lg', f.kind === 'win' && 'text-emerald-300 text-lg', f.kind === 'tap' && 'text-white text-sm', f.kind === 'money' && 'text-emerald-200 text-sm', f.kind === 'bad' && 'text-red-300 text-xs'),
                                    style: {
                                        left: `${f.x}%`,
                                        top: `${f.y}%`
                                    },
                                    children: formatMoneyText(f.text)
                                }, f.id, false, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                    lineNumber: 628,
                                    columnNumber: 15
                                }, this)),
                            burst && burst.pieces.map((p, i)=>/*#__PURE__*/ _jsxDEV("span", {
                                    className: "absolute top-0 w-1.5 h-2.5 st-confetti",
                                    style: {
                                        left: `${p.x}%`,
                                        backgroundColor: p.c,
                                        animationDuration: `${p.d + 0.7}s`,
                                        transform: `rotate(${p.r}deg)`
                                    }
                                }, `${burst.id}-${i}`, false, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                    lineNumber: 645,
                                    columnNumber: 15
                                }, this)),
                            g.golden && /*#__PURE__*/ _jsxDEV("button", {
                                onClick: (e)=>{
                                    e.stopPropagation();
                                    g.doCatchGolden();
                                },
                                "aria-label": "Catch the golden whistle",
                                className: "absolute z-10 text-2xl st-goldwob drop-shadow-[0_0_10px_rgba(251,191,36,0.95)]",
                                style: {
                                    left: `${g.golden.x}%`,
                                    top: `${g.golden.y}%`
                                },
                                children: "🪙"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 649,
                                columnNumber: 15
                            }, this),
                            g.setPiece && /*#__PURE__*/ _jsxDEV("button", {
                                type: "button",
                                "data-set-piece-offer": true,
                                className: "absolute right-3 top-3 z-20 min-h-11 rounded-xl border border-amber-200/60 bg-amber-300 px-3 py-2 text-xs font-bold text-slate-950",
                                onClick: (event)=>{
                                    event.stopPropagation();
                                    g.doBeginSetPiece(g.setPiece);
                                },
                                children: [
                                    "⚽ ",
                                    g.setPiece.kind === 'penalty' ? 'Penalty' : 'Free kick',
                                    " · ",
                                    Math.ceil(g.setPiece.remainingSec),
                                    "s"
                                ]
                            }, void 0, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 658,
                                columnNumber: 28
                            }, this),
                            g.setPieceError && /*#__PURE__*/ _jsxDEV("p", {
                                role: "alert",
                                className: "pointer-events-none absolute inset-x-3 top-16 z-20 rounded-xl bg-card p-2 text-xs text-foreground",
                                children: g.setPieceError
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 663,
                                columnNumber: 33
                            }, this),
                            g.badge && /*#__PURE__*/ _jsxDEV("p", {
                                className: "cm-slam pointer-events-none absolute inset-x-2 bottom-7 z-10 rounded-xl border border-emerald-500/40 bg-card px-3 py-2 text-center text-xs font-bold text-emerald-400",
                                children: [
                                    "🏅 Badge earned: ",
                                    g.badge.label,
                                    ", +",
                                    Math.round(ACH_BONUS * 100),
                                    "% income forever"
                                ]
                            }, g.badge.seq, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 672,
                                columnNumber: 15
                            }, this),
                            g.promotion && /*#__PURE__*/ _jsxDEV("div", {
                                "data-promotion-card": true,
                                onClick: (e)=>e.stopPropagation(),
                                className: "absolute inset-0 z-20 flex items-center justify-center bg-black/60 p-3 cursor-default",
                                children: [
                                    /*#__PURE__*/ _jsxDEV(ConfettiBurst, {
                                        seed: g.promotion.seq,
                                        count: 30
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 689,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        className: "relative max-w-full rounded-2xl border border-yellow-500/70 bg-card px-3 py-2 text-center text-yellow-400 shadow-lg",
                                        children: [
                                            /*#__PURE__*/ _jsxDEV(VictoryMoment, {
                                                compact: true,
                                                children: /*#__PURE__*/ _jsxDEV("p", {
                                                    className: "font-display text-base font-black leading-tight text-yellow-400",
                                                    children: g.promotion.label
                                                }, void 0, false, {
                                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                    lineNumber: 692,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                lineNumber: 691,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ _jsxDEV("p", {
                                                className: "cm-rise mt-1 text-xs text-muted-foreground",
                                                style: {
                                                    animationDelay: '0.45s'
                                                },
                                                children: [
                                                    "+",
                                                    fmtMoney(g.promotion.amount),
                                                    " promotion bonus, every payout scaled up from here"
                                                ]
                                            }, void 0, true, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                lineNumber: 696,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ _jsxDEV("button", {
                                                onClick: g.dismissPromotion,
                                                className: "mt-1 inline-flex min-h-[36px] items-center rounded-full bg-primary px-5 py-1.5 text-sm font-bold text-primary-foreground hover:brightness-110",
                                                children: "Continue"
                                            }, void 0, false, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                lineNumber: 699,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 690,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, g.promotion.seq, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 683,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 611,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                lineNumber: 597,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "mb-3",
                children: [
                    canPrestige(s) ? /*#__PURE__*/ _jsxDEV(TycoonSaleReview, {
                        state: s,
                        onSell: g.doPrestige
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 714,
                        columnNumber: 13
                    }, this) : /*#__PURE__*/ _jsxDEV("div", {
                        className: "relative h-2 rounded-full bg-secondary overflow-hidden",
                        title: "Progress to your next reputation star",
                        children: /*#__PURE__*/ _jsxDEV("div", {
                            className: "absolute inset-y-0 left-0 bg-yellow-500/80 transition-all duration-700",
                            style: {
                                width: `${Math.min(100, s.lifetime / prestigeThreshold(s) * 100)}%`
                            }
                        }, void 0, false, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                            lineNumber: 717,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 716,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "text-[10px] text-muted-foreground text-center mt-1",
                        children: canPrestige(s) ? `the club has outgrown this ground${!atSummit ? `. Win this league first and the sale pays ${saleAfterTitle} legacy points instead` : ''}` : `next star at ${fmtMoney(prestigeThreshold(s))} lifetime earnings (${fmtMoney(s.lifetime)} so far)`
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 720,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                lineNumber: 712,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "grid grid-cols-3 sm:grid-cols-6 gap-1.5 mb-2",
                role: "group",
                "aria-label": "The club office",
                children: officeTiles.map((t)=>/*#__PURE__*/ _jsxDEV("button", {
                        type: "button",
                        "data-tile": t.key,
                        "data-office-panel": t.key,
                        ...t.key === 'legacy' ? {
                            'data-legacy-drawer': ''
                        } : {},
                        "aria-pressed": panel === t.key,
                        onClick: ()=>setPanel(t.key),
                        className: cn('min-h-[52px] min-w-0 rounded-xl border px-1 py-1.5 text-center transition-all', panel === t.key ? 'bg-primary text-primary-foreground border-primary' : 'bg-card border-border text-foreground hover:border-primary', t.accent && panel !== t.key && 'border-gold text-gold'),
                        children: [
                            /*#__PURE__*/ _jsxDEV("span", {
                                className: "block text-sm leading-none",
                                "aria-hidden": "true",
                                children: t.icon
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 745,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ _jsxDEV("span", {
                                className: "mt-1 block text-xs font-bold leading-tight",
                                children: t.title
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 746,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ _jsxDEV("span", {
                                className: cn('block text-xs leading-tight tabular-nums', panel === t.key ? 'text-primary-foreground/80' : 'text-muted-foreground'),
                                children: t.value
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 747,
                                columnNumber: 15
                            }, this)
                        ]
                    }, t.key, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 731,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                lineNumber: 729,
                columnNumber: 9
            }, this),
            panel === 'upgrades' && /*#__PURE__*/ _jsxDEV("div", {
                className: "grid grid-cols-2 sm:grid-cols-3 gap-2 pb-4",
                children: TRACKS.map((t)=>{
                    const lvl = levelOf(s, t.id);
                    const cost = costOf(s, t.id);
                    const ok = canBuy(s, t.id);
                    return /*#__PURE__*/ _jsxDEV("button", {
                        onClick: ()=>g.doBuy(t.id),
                        disabled: !ok,
                        className: cn('relative rounded-xl border p-2.5 text-left transition-all active:scale-[0.97]', ok ? 'bg-card border-border hover:border-primary' : 'bg-card/50 border-border/50 opacity-70'),
                        children: [
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "flex items-center gap-1.5",
                                children: [
                                    /*#__PURE__*/ _jsxDEV("span", {
                                        className: "text-base leading-none",
                                        children: t.emoji
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 769,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("span", {
                                        className: "text-xs font-bold text-foreground truncate",
                                        children: t.name
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 770,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("span", {
                                        className: "ml-auto text-[9px] font-bold text-muted-foreground bg-secondary rounded px-1 py-0.5",
                                        children: [
                                            "Lv ",
                                            lvl
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 771,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 768,
                                columnNumber: 17
                            }, this),
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "text-[9px] text-muted-foreground mt-1 leading-snug min-h-[22px]",
                                children: t.blurb
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 773,
                                columnNumber: 17
                            }, this),
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: cn('text-[11px] font-bold mt-1 tabular-nums', ok ? 'text-gold' : 'text-muted-foreground'),
                                children: fmtMoney(cost)
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 774,
                                columnNumber: 17
                            }, this)
                        ]
                    }, t.id, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 759,
                        columnNumber: 15
                    }, this);
                })
            }, void 0, false, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                lineNumber: 753,
                columnNumber: 9
            }, this),
            panel === 'tickets' && /*#__PURE__*/ _jsxDEV(TicketPolicyCard, {
                state: s,
                onSelect: g.doSetTicketPolicy,
                saveFailed: g.ticketSaveFailed,
                onRetrySave: g.retryTicketSave
            }, void 0, false, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                lineNumber: 781,
                columnNumber: 33
            }, this),
            panel === 'payroll' && /*#__PURE__*/ _jsxDEV(_Fragment, {
                children: [
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "mb-1 flex items-center justify-between px-1",
                        children: [
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "text-xs font-bold text-foreground",
                                children: "🧑‍🤝‍🧑 The payroll"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 788,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "text-[10px] text-muted-foreground",
                                children: [
                                    totalStaffLevels(s),
                                    " hired · earning ",
                                    fmtRate(STAFF.reduce((sum, t)=>sum + staffLevelOf(s, t.id) * t.rate, 0)),
                                    "/s base"
                                ]
                            }, void 0, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 789,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 787,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "grid grid-cols-2 sm:grid-cols-4 gap-2 pb-4",
                        children: STAFF.map((t)=>{
                            const lvl = staffLevelOf(s, t.id);
                            const cost = staffCostOf(s, t.id);
                            const ok = canHire(s, t.id);
                            return /*#__PURE__*/ _jsxDEV("button", {
                                onClick: ()=>g.doHire(t.id),
                                disabled: !ok,
                                className: cn('relative rounded-xl border p-2.5 text-left transition-all active:scale-[0.97]', ok ? 'bg-card border-border hover:border-primary' : 'bg-card/50 border-border/50 opacity-70'),
                                children: [
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        className: "flex items-center gap-1.5",
                                        children: [
                                            /*#__PURE__*/ _jsxDEV("span", {
                                                className: "text-base leading-none",
                                                children: t.emoji
                                            }, void 0, false, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                lineNumber: 807,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ _jsxDEV("span", {
                                                className: "text-[11px] font-bold text-foreground truncate",
                                                children: t.name
                                            }, void 0, false, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                lineNumber: 808,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ _jsxDEV("span", {
                                                className: "ml-auto text-[9px] font-bold text-muted-foreground bg-secondary rounded px-1 py-0.5",
                                                children: lvl
                                            }, void 0, false, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                lineNumber: 809,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 806,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        className: "text-[9px] text-muted-foreground mt-1 leading-snug min-h-[22px]",
                                        children: t.blurb
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 811,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        className: "flex items-center justify-between mt-1",
                                        children: [
                                            /*#__PURE__*/ _jsxDEV("span", {
                                                className: cn('text-[11px] font-bold tabular-nums', ok ? 'text-gold' : 'text-muted-foreground'),
                                                children: fmtMoney(cost)
                                            }, void 0, false, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                lineNumber: 813,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ _jsxDEV("span", {
                                                className: "text-[9px] text-emerald-400 tabular-nums",
                                                children: [
                                                    "+",
                                                    fmtRate(t.rate),
                                                    "/s"
                                                ]
                                            }, void 0, true, {
                                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                lineNumber: 814,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 812,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, t.id, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 797,
                                columnNumber: 15
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 791,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true),
            panel === 'ach' && /*#__PURE__*/ _jsxDEV("div", {
                className: "bg-card border border-border rounded-xl p-3 mb-3",
                children: [
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "text-[10px] text-muted-foreground mb-2",
                        children: [
                            "Every badge is a permanent +",
                            Math.round(ACH_BONUS * 100),
                            "% income, on every ground, forever. ",
                            achCount,
                            " of ",
                            ACHIEVEMENTS.length,
                            " earned."
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 824,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "grid grid-cols-2 sm:grid-cols-3 gap-1.5 max-h-72 overflow-y-auto pr-1",
                        children: ACHIEVEMENTS.map((a)=>{
                            const got = (s.ach ?? []).includes(a.id);
                            return /*#__PURE__*/ _jsxDEV("div", {
                                className: cn('rounded-lg border px-2 py-1.5 text-[10px] flex items-center gap-1.5', got ? 'border-emerald-500/40 bg-emerald-500/10 text-foreground' : 'border-border/60 bg-background/40 text-muted-foreground'),
                                children: [
                                    /*#__PURE__*/ _jsxDEV("span", {
                                        className: "text-sm leading-none",
                                        children: got ? a.emoji : '🔒'
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 834,
                                        columnNumber: 21
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("span", {
                                        className: "truncate",
                                        children: a.label
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 835,
                                        columnNumber: 21
                                    }, this)
                                ]
                            }, a.id, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 829,
                                columnNumber: 19
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 825,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                lineNumber: 823,
                columnNumber: 11
            }, this),
            panel === 'legacy' && (()=>{
                const hf = helpFacts();
                return /*#__PURE__*/ _jsxDEV("div", {
                    "data-legacy-board": true,
                    className: "bg-card border border-border rounded-xl p-3 mb-3",
                    children: [
                        /*#__PURE__*/ _jsxDEV("div", {
                            className: "text-[10px] text-muted-foreground mb-2",
                            children: [
                                "Selling up pays legacy points: ",
                                hf.saleBase,
                                " for the sale plus ",
                                hf.perDivision,
                                " per division that ground climbed, so a sale from ",
                                hf.lastDivision,
                                " pays ",
                                hf.summitPoints,
                                ". Every perk bought here is permanent, on every future ground, forever. You have ",
                                /*#__PURE__*/ _jsxDEV("b", {
                                    className: "text-gold",
                                    children: [
                                        legacyPointsOf(s),
                                        " point",
                                        legacyPointsOf(s) === 1 ? '' : 's'
                                    ]
                                }, void 0, true, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                    lineNumber: 851,
                                    columnNumber: 24
                                }, this),
                                " to spend."
                            ]
                        }, void 0, true, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                            lineNumber: 848,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ _jsxDEV("div", {
                            className: "grid grid-cols-1 sm:grid-cols-2 gap-1.5",
                            children: LEGACY_PERKS.map((p)=>{
                                const lvl = perkLevelOf(s, p.id);
                                const cost = perkCostOf(s, p.id);
                                const ok = canBuyPerk(s, p.id);
                                return /*#__PURE__*/ _jsxDEV("div", {
                                    "data-perk": p.id,
                                    className: cn('rounded-lg border px-2 py-1.5 text-[10px] flex items-center gap-2', lvl > 0 ? 'border-gold/40 bg-gold/5' : 'border-border/60 bg-background/40'),
                                    children: [
                                        /*#__PURE__*/ _jsxDEV("span", {
                                            className: "text-base leading-none shrink-0",
                                            children: p.emoji
                                        }, void 0, false, {
                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                            lineNumber: 861,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ _jsxDEV("span", {
                                            className: "min-w-0 flex-1",
                                            children: [
                                                /*#__PURE__*/ _jsxDEV("span", {
                                                    className: "font-bold text-foreground",
                                                    children: p.name
                                                }, void 0, false, {
                                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                    lineNumber: 863,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ _jsxDEV("span", {
                                                    className: "ml-1 text-muted-foreground",
                                                    children: [
                                                        "Lv ",
                                                        lvl,
                                                        "/",
                                                        p.costs.length
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                    lineNumber: 864,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ _jsxDEV("span", {
                                                    className: "block text-muted-foreground leading-snug",
                                                    children: p.blurb
                                                }, void 0, false, {
                                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                                    lineNumber: 865,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                            lineNumber: 862,
                                            columnNumber: 21
                                        }, this),
                                        cost === null ? /*#__PURE__*/ _jsxDEV("span", {
                                            className: "shrink-0 text-[9px] font-bold text-gold",
                                            children: "MAXED"
                                        }, void 0, false, {
                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                            lineNumber: 868,
                                            columnNumber: 23
                                        }, this) : /*#__PURE__*/ _jsxDEV("button", {
                                            onClick: ()=>g.doLegacyPerk(p.id),
                                            "aria-label": `Buy ${p.name}, level ${lvl + 1}, ${cost} pt${cost === 1 ? '' : 's'}`,
                                            disabled: !ok,
                                            className: cn('shrink-0 min-h-[30px] rounded-full px-2.5 py-1 text-[9px] font-bold transition-all active:scale-95', ok ? 'bg-gold text-black hover:opacity-90' : 'bg-secondary text-muted-foreground'),
                                            children: [
                                                cost,
                                                " pt",
                                                cost === 1 ? '' : 's'
                                            ]
                                        }, void 0, true, {
                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                            lineNumber: 870,
                                            columnNumber: 23
                                        }, this)
                                    ]
                                }, p.id, true, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                    lineNumber: 859,
                                    columnNumber: 19
                                }, this);
                            })
                        }, void 0, false, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                            lineNumber: 853,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                    lineNumber: 847,
                    columnNumber: 11
                }, this);
            })(),
            panel === 'stats' && /*#__PURE__*/ _jsxDEV("div", {
                className: "bg-card border border-border rounded-xl p-3 mb-3",
                children: /*#__PURE__*/ _jsxDEV("div", {
                    className: "grid grid-cols-2 sm:grid-cols-3 gap-2 text-center",
                    children: [
                        [
                            'Lifetime, this ground',
                            fmtMoney(s.lifetime)
                        ],
                        [
                            'Career wins',
                            s.totalWins.toLocaleString('en-US')
                        ],
                        [
                            'Career goals',
                            s.totalGoals.toLocaleString('en-US')
                        ],
                        [
                            'Matches played',
                            (s.totalMatches ?? 0).toLocaleString('en-US')
                        ],
                        [
                            'Taps',
                            s.totalTaps.toLocaleString('en-US')
                        ],
                        [
                            'Best division',
                            `${DIVISIONS[Math.min(s.bestDivision ?? 0, DIVISIONS.length - 1)].emoji} ${DIVISIONS[Math.min(s.bestDivision ?? 0, DIVISIONS.length - 1)].name}`
                        ],
                        [
                            'Golden whistles caught',
                            (s.goldenCaught ?? 0).toLocaleString('en-US')
                        ],
                        [
                            'Hype boosts pressed',
                            (s.boostsUsed ?? 0).toLocaleString('en-US')
                        ],
                        [
                            'Reputation stars',
                            s.rep.toLocaleString('en-US')
                        ],
                        [
                            'Legacy points unspent',
                            legacyPointsOf(s).toLocaleString('en-US')
                        ],
                        [
                            'Legacy perk levels',
                            totalPerkLevels(s).toLocaleString('en-US')
                        ]
                    ].map(([label, value])=>/*#__PURE__*/ _jsxDEV("div", {
                            className: "rounded-lg bg-secondary/50 px-2 py-2",
                            children: [
                                /*#__PURE__*/ _jsxDEV("div", {
                                    className: "text-xs font-bold font-display text-foreground truncate",
                                    children: value
                                }, void 0, false, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                    lineNumber: 905,
                                    columnNumber: 19
                                }, this),
                                /*#__PURE__*/ _jsxDEV("div", {
                                    className: "text-[9px] text-muted-foreground",
                                    children: label
                                }, void 0, false, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                    lineNumber: 906,
                                    columnNumber: 19
                                }, this)
                            ]
                        }, label, true, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                            lineNumber: 904,
                            columnNumber: 17
                        }, this))
                }, void 0, false, {
                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                    lineNumber: 890,
                    columnNumber: 13
                }, this)
            }, void 0, false, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                lineNumber: 889,
                columnNumber: 11
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "text-xs text-muted-foreground text-center pb-4",
                children: [
                    "lifetime ",
                    fmtMoney(s.lifetime),
                    " · ",
                    formatNumber(s.totalWins),
                    " wins · ",
                    formatNumber(s.totalGoals),
                    " goals · ",
                    formatNumber(s.totalTaps),
                    " taps · match #",
                    s.matchNo + 1,
                    " · milestones ",
                    (s.claimed ?? []).length,
                    "/",
                    MILESTONES.length,
                    " · badges ",
                    achCount,
                    "/",
                    ACHIEVEMENTS.length
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                lineNumber: 914,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ _jsxDEV(Dialog, {
                open: Boolean(g.activeSetPiece),
                onOpenChange: (open)=>{
                    if (!open) g.closeSetPiece();
                },
                children: /*#__PURE__*/ _jsxDEV(DialogContent, {
                    className: "max-h-[90dvh] w-[calc(100%-1rem)] max-w-lg overflow-y-auto rounded-2xl p-4",
                    children: [
                        /*#__PURE__*/ _jsxDEV(DialogTitle, {
                            className: "sr-only",
                            children: "Watched match kick"
                        }, void 0, false, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                            lineNumber: 920,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV(DialogDescription, {
                            "data-set-piece-match": true,
                            className: "text-xs tabular-nums text-muted-foreground",
                            children: kickClosed ? 'Kick closed' : `Match ${s.minute}' · ${s.goalsFor} - ${s.goalsAgainst}`
                        }, void 0, false, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                            lineNumber: 921,
                            columnNumber: 11
                        }, this),
                        g.activeSetPiece && /*#__PURE__*/ _jsxDEV(Suspense, {
                            fallback: /*#__PURE__*/ _jsxDEV("p", {
                                "data-no-prerender": true,
                                className: "text-sm",
                                children: "Getting the kick ready..."
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 924,
                                columnNumber: 52
                            }, void 0),
                            children: /*#__PURE__*/ _jsxDEV(SetPieceBoard, {
                                kickIndex: g.activeSetPiece.kickIndex,
                                seed: g.activeSetPiece.seed,
                                expired: kickClosed,
                                onResult: (scored)=>g.doSetPieceResult(g.activeSetPiece, scored),
                                onBack: g.closeSetPiece
                            }, `${g.activeSetPiece.rep}:${g.activeSetPiece.match}`, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 925,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                            lineNumber: 924,
                            columnNumber: 32
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                    lineNumber: 919,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                lineNumber: 918,
                columnNumber: 7
            }, this),
            g.awayPay !== null && /*#__PURE__*/ _jsxDEV("div", {
                className: "fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4",
                style: OVERLAY_ABOVE_BANNER,
                onClick: g.dismissAway,
                children: /*#__PURE__*/ _jsxDEV("div", {
                    role: "dialog",
                    "aria-modal": "true",
                    "aria-label": "While you were away",
                    tabIndex: -1,
                    ref: focusDialogOnMount,
                    onKeyDown: escapeCloses(g.dismissAway),
                    className: "bg-card border border-border rounded-2xl p-6 max-w-sm w-full text-center overflow-y-auto",
                    style: boxInsideOverlay('100%'),
                    onClick: (e)=>e.stopPropagation(),
                    children: [
                        /*#__PURE__*/ _jsxDEV("div", {
                            className: "text-4xl mb-2",
                            children: "🏟️"
                        }, void 0, false, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                            lineNumber: 936,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ _jsxDEV("div", {
                            className: "text-lg font-bold font-display text-foreground",
                            children: "While you were away"
                        }, void 0, false, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                            lineNumber: 937,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ _jsxDEV("p", {
                            className: "text-sm text-muted-foreground mt-1",
                            children: [
                                "The turnstiles kept spinning at ",
                                Math.round(offlineRateOf(s) * 100),
                                "% speed."
                            ]
                        }, void 0, true, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                            lineNumber: 938,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ _jsxDEV("div", {
                            className: "text-3xl font-bold font-display text-gold mt-3",
                            children: [
                                "+",
                                fmtMoney(g.awayPay)
                            ]
                        }, void 0, true, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                            lineNumber: 939,
                            columnNumber: 13
                        }, this),
                        g.awayTrip && /*#__PURE__*/ _jsxDEV("div", {
                            "data-away-results": true,
                            className: "mt-3",
                            children: [
                                /*#__PURE__*/ _jsxDEV("p", {
                                    className: "text-xs text-muted-foreground",
                                    children: "Your club kept playing while you were away, with no goal or win bonuses:"
                                }, void 0, false, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                    lineNumber: 942,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ _jsxDEV("div", {
                                    className: "mt-1.5 flex flex-wrap justify-center gap-1",
                                    children: g.awayTrip.results.map((m, i)=>/*#__PURE__*/ _jsxDEV("span", {
                                            role: "img",
                                            "aria-label": `${m.result === 'W' ? 'won' : m.result === 'L' ? 'lost' : 'drew'}${m.friendly ? ' a friendly' : ''}`,
                                            className: cn('inline-flex h-6 w-6 items-center justify-center rounded-md text-xs font-bold', m.result === 'W' ? 'bg-emerald-500/20 text-emerald-400' : m.result === 'L' ? 'bg-red-500/20 text-red-400' : 'bg-secondary text-muted-foreground', m.friendly && 'opacity-60 ring-1 ring-border'),
                                            children: m.result
                                        }, i, false, {
                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                            lineNumber: 945,
                                            columnNumber: 21
                                        }, this))
                                }, void 0, false, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                    lineNumber: 943,
                                    columnNumber: 17
                                }, this),
                                g.awayTrip.results[0]?.friendly && /*#__PURE__*/ _jsxDEV("p", {
                                    className: "mt-1 text-[11px] text-muted-foreground",
                                    children: "The faded result was a friendly, played outside the table."
                                }, void 0, false, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                    lineNumber: 957,
                                    columnNumber: 53
                                }, this),
                                g.awayTrip.milestonePay > 0 && /*#__PURE__*/ _jsxDEV("p", {
                                    className: "mt-2 text-xs font-bold text-gold",
                                    children: [
                                        "Milestones reached on the road: +",
                                        fmtMoney(g.awayTrip.milestonePay)
                                    ]
                                }, void 0, true, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                    lineNumber: 958,
                                    columnNumber: 49
                                }, this),
                                g.awayTrip.gems > 0 && /*#__PURE__*/ _jsxDEV("p", {
                                    className: "mt-1 text-xs font-bold text-sky-300",
                                    children: [
                                        "Away wins earned 💎 ",
                                        g.awayTrip.gems,
                                        " gem",
                                        g.awayTrip.gems === 1 ? '' : 's'
                                    ]
                                }, void 0, true, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                    lineNumber: 959,
                                    columnNumber: 41
                                }, this),
                                awayTableLine && /*#__PURE__*/ _jsxDEV("p", {
                                    className: "mt-2 text-xs text-muted-foreground",
                                    children: awayTableLine
                                }, void 0, false, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                    lineNumber: 960,
                                    columnNumber: 35
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                            lineNumber: 941,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ _jsxDEV("button", {
                            onClick: g.dismissAway,
                            className: "mt-4 w-full py-2.5 rounded-xl font-bold bg-primary text-primary-foreground hover:opacity-90 transition-opacity",
                            children: "Back to work"
                        }, void 0, false, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                            lineNumber: 963,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                    lineNumber: 935,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                lineNumber: 934,
                columnNumber: 9
            }, this),
            showHelp && (()=>{
                const h = helpFacts();
                return /*#__PURE__*/ _jsxDEV("div", {
                    className: "fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4",
                    style: OVERLAY_ABOVE_BANNER,
                    onClick: ()=>setShowHelp(false),
                    children: /*#__PURE__*/ _jsxDEV("div", {
                        role: "dialog",
                        "aria-modal": "true",
                        "aria-label": "How Stadium Tycoon works",
                        tabIndex: -1,
                        ref: focusDialogOnMount,
                        onKeyDown: escapeCloses(()=>setShowHelp(false)),
                        className: "bg-card border border-border rounded-2xl p-5 max-w-md w-full overflow-y-auto",
                        style: boxInsideOverlay('80vh'),
                        onClick: (e)=>e.stopPropagation(),
                        children: [
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "flex items-center justify-between mb-2",
                                children: [
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        className: "text-lg font-bold font-display text-foreground",
                                        children: "How Stadium Tycoon works"
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 978,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("button", {
                                        onClick: ()=>setShowHelp(false),
                                        "aria-label": "Close the rules",
                                        children: /*#__PURE__*/ _jsxDEV(X, {
                                            className: "w-4 h-4 text-muted-foreground"
                                        }, void 0, false, {
                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                            lineNumber: 979,
                                            columnNumber: 87
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 979,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 977,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ _jsxDEV("div", {
                                "data-tycoon-rules": true,
                                className: "text-sm text-muted-foreground space-y-2",
                                children: [
                                    /*#__PURE__*/ _jsxDEV("p", {
                                        children: "You run a tiny club's matchday money machine. Fans show up if there are seats and things to spend on; every fan pays you every second."
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 982,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("p", {
                                        children: [
                                            "The match on screen is real and plays like football: your Squad against today's rival decides who is favourite, but favourites drop points and plenty of matches end level. Against a rival as strong as you, you expect about ",
                                            h.evenFor,
                                            " goals to their ",
                                            h.evenAgainst,
                                            ", and each Squad level adds about ",
                                            h.levelGoals,
                                            " of a goal a match to your side and takes up to as much off theirs. A goal pays ",
                                            h.goalSec,
                                            " seconds of your income, a win ",
                                            h.winSec,
                                            " seconds and going up a division ",
                                            h.promotionMin,
                                            " minutes, and wins extend a streak that multiplies everything and pulls in new fans. Every division up sends stronger rivals, and they stay that strong until you win the league."
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 983,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("p", {
                                        children: "Tap the stadium for instant cash (Megaphone makes taps stronger). Buy Stands when the ground is full, spending tracks when it is not."
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 984,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("p", {
                                        children: [
                                            "The Ticket offer tile sets your matchday price, and switching is free at any time. Standard is the regular game. Community takes ",
                                            h.ticketCommunityCut,
                                            "% off the gate money each fan pays and your supporters grow ",
                                            h.ticketCommunityGrowth,
                                            "% faster. Premium adds ",
                                            h.ticketPremiumGate,
                                            "% to the gate money each fan pays, but only ",
                                            h.ticketPremiumDemand,
                                            "% of your supporters turn up and they grow ",
                                            h.ticketPremiumGrowth,
                                            "% slower. Only the ticket price moves: snacks, the shop, parking and the payroll keep their own rates. Example: a new ",
                                            h.freshSeats,
                                            " seat ground with ",
                                            h.freshFans,
                                            " supporters draws ",
                                            h.freshPremiumCrowd,
                                            " on Premium, so Premium pays less there, and it pays more once ",
                                            h.ticketPremiumDemand,
                                            "% of your supporters still fill the ground. Selling up puts the offer back to Standard."
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 985,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("p", {
                                        children: [
                                            "Matchday Hype charges over ",
                                            h.chargeMin,
                                            " minutes of play (Stadium Voltage in the boardroom trims that to ",
                                            h.voltage1,
                                            ", then ",
                                            h.voltage2,
                                            "). Press it and your income pays double for ",
                                            h.hypeSec,
                                            " seconds, and your taps rise with it; goal and win bonuses are not doubled. It does not charge or burn while you are away."
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 986,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("p", {
                                        children: [
                                            "Your ground plays in a league, ",
                                            h.divisions,
                                            " divisions from the ",
                                            h.firstDivision,
                                            " to ",
                                            h.lastDivision,
                                            ". Each division is a small league of named rivals: ",
                                            leagueShape(0).clubs,
                                            " clubs playing each other once in the bottom ",
                                            SINGLE_LEG_BELOW,
                                            " divisions, then ",
                                            leagueShape(3).clubs,
                                            " and ",
                                            leagueShape(6).clubs,
                                            " clubs home and away. Only the champion goes up, and nobody ever goes down. Every division multiplies all income, up to x",
                                            h.topMult,
                                            " at the top, going up pays a promotion bonus on the spot, and a title at ",
                                            h.lastDivision,
                                            " pays it again. Higher divisions send tougher opponents. The League tab shows the table, and when a season ends its Latest season button opens that season's final table and your own line of it while the next match runs. That review is for this visit only: reload and it is gone until your next season ends."
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 987,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("p", {
                                        children: [
                                            "The payroll hires ",
                                            h.staff,
                                            " staff, from a ",
                                            h.firstStaff,
                                            " to a ",
                                            h.lastStaff,
                                            ". Every staff level adds steady income of its own before the multipliers touch it, so a deep payroll compounds hard."
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 988,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("p", {
                                        children: [
                                            "While you play, a golden whistle drifts onto the pitch every couple of minutes. You get about ",
                                            h.catchSec,
                                            " seconds to catch it, for one of ",
                                            h.prizes,
                                            " prizes: ",
                                            GOLDEN_INFO.frenzy.label,
                                            " (",
                                            GOLDEN_INFO.frenzy.blurb,
                                            " for ",
                                            GOLDEN_INFO.frenzy.duration,
                                            " seconds), ",
                                            GOLDEN_INFO.tapRush.label,
                                            " (",
                                            GOLDEN_INFO.tapRush.blurb,
                                            " for ",
                                            GOLDEN_INFO.tapRush.duration,
                                            " seconds), ",
                                            GOLDEN_INFO.windfall.label,
                                            " (",
                                            h.windfallMin,
                                            " minutes of income, instantly), ",
                                            GOLDEN_INFO.fanWave.label,
                                            " (",
                                            GOLDEN_INFO.fanWave.blurb,
                                            ") or ",
                                            GOLDEN_INFO.freeLevel.label,
                                            " (",
                                            GOLDEN_INFO.freeLevel.blurb,
                                            ")."
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 989,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("p", {
                                        children: [
                                            "A penalty or free-kick offer appears once per watched match. You have ",
                                            SET_PIECE_WINDOW_SEC,
                                            " seconds to open it. Pick your aim, power and curve for one shot while the match clock keeps running. Opening uses that match's attempt, including if you leave or reload. A goal before full time adds one goal and the usual goal bonus; a miss costs nothing. Away matches have no kick offers, and kicks have no daily score or direct gem reward."
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 990,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("p", {
                                        children: [
                                            "Milestones pay once each for the club's firsts, like ",
                                            h.milestoneExamples,
                                            ". ",
                                            h.milestones,
                                            " in all, and they stay earned even after you sell up."
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 991,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("p", {
                                        children: [
                                            "Badges are the long game: ",
                                            h.badges,
                                            " of them, from ",
                                            h.firstBadge,
                                            " to ",
                                            h.lastBadge,
                                            ", and each one earned is +",
                                            h.badgePct,
                                            "% income forever. Check them on the Badges tile, and your career numbers on Records."
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 992,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("p", {
                                        children: [
                                            "When lifetime earnings hit the bar, sell up: fans, ground, staff and division reset, but you keep a permanent Reputation star worth +",
                                            h.starPct,
                                            "% income each, every badge, and your club records. The ladder is faster every run."
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 993,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("p", {
                                        children: [
                                            "Selling up also pays legacy points: ",
                                            h.saleBase,
                                            " for the sale plus ",
                                            h.perDivision,
                                            " per division that ground climbed, so cashing out early pays ",
                                            h.saleBase,
                                            " and a sale from ",
                                            h.lastDivision,
                                            " pays ",
                                            h.summitPoints,
                                            ". Spend them in the Legacy boardroom on ",
                                            h.perks,
                                            " permanent perks, from ",
                                            h.firstPerk,
                                            " (+",
                                            h.swayPct,
                                            "% income per level, forever) to ",
                                            h.shieldPerk,
                                            ", which keeps half your streak through a loss. The whole board costs exactly ",
                                            h.boardCost,
                                            " points. Perks survive every future sale."
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 994,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("p", {
                                        children: [
                                            "Away from the game, you earn at ",
                                            h.awayPct,
                                            "% speed for up to ",
                                            h.awayHours,
                                            " hours (the ",
                                            h.awayPerk,
                                            " perk raises both, up to ",
                                            h.awayMaxPct,
                                            "% for ",
                                            h.awayMaxHours,
                                            " hours). Matchdays keep playing while you are away, one every ",
                                            h.awayMatchMin,
                                            " minutes with no goal or win bonuses, and the final matchday of a season always waits for you. Progress saves on this device."
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 995,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("p", {
                                        children: [
                                            "Gems come only from results: a watched win earns ",
                                            GEM_PAY.win,
                                            ", a watched draw ",
                                            GEM_PAY.draw,
                                            ", and a win played while you were away ",
                                            GEM_PAY.awayWin,
                                            ". Winning a league adds ",
                                            GEM_PAY.title,
                                            " and finishing second adds ",
                                            GEM_PAY.runnerUp,
                                            ". They open packs of generated kids in the Academy tab, where every pack prints its odds before you open it, and gems are never for sale."
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 996,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("p", {
                                        children: "The Academy tab runs your youth academy inside this game, on its own save, with its own How it works button."
                                    }, void 0, false, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 997,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("p", {
                                        children: [
                                            "Worked example: a new club has ",
                                            h.freshFans,
                                            " fans paying $",
                                            h.perFan,
                                            " each, $",
                                            h.freshRate,
                                            " a second. The first Stands level costs $",
                                            h.standsCost,
                                            " and adds ",
                                            h.seatsPerStand,
                                            " seats you cannot fill yet, so the Ticket Office pays first. Later, a full ground of ",
                                            h.exampleFans,
                                            " fans pays ",
                                            fmtMoney(h.rate400),
                                            " a second, a goal pays ",
                                            fmtMoney(h.goal400),
                                            " before any streak, and a win pays ",
                                            fmtMoney(h.win400),
                                            "."
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                        lineNumber: 998,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 981,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ _jsxDEV("button", {
                                type: "button",
                                onClick: ()=>setShowHelp(false),
                                className: "mt-4 w-full py-3 rounded-xl font-bold bg-primary text-primary-foreground hover:opacity-90 transition-opacity",
                                children: "Let's go"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                                lineNumber: 1000,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                        lineNumber: 976,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx",
                    lineNumber: 975,
                    columnNumber: 9
                }, this);
            })()
        ]
    }, void 0, true);
}
