import { jsxDEV as _jsxDEV, Fragment as _Fragment } from "react/jsx-dev-runtime";
import { useMemo, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { canPrestige, DIVISIONS, fmtMoney, legacyPointsOf, newTycoon, pointsForSale, repMult, startingMoneyOf, TICKET_POLICIES } from '@/lib/stadiumTycoon';
import { formatNumber } from '@/lib/formatNumber';
/* Release AM: the page groups its money since Round 1085 ($2,540), and the
   engine's own fmtMoney does not under 10,000 ($2540), so the review said one
   and the new ground's header said the other a second later. Same grouping
   here as the page's own wrapper. */ const money = (n)=>fmtMoney(n).replace(/^\$(-?\d+(?:\.\d+)?)([KMBTQ]?)$/, (_text, amount, unit)=>`$${formatNumber(amount)}${unit}`);
export default function TycoonSaleReview({ state, onSell }) {
    const [open, setOpen] = useState(false);
    const [help, setHelp] = useState(false);
    const [saveFailed, setSaveFailed] = useState(false);
    const trigger = useRef(null);
    const heading = useRef(null);
    const selling = useRef(false);
    const fresh = useMemo(()=>newTycoon(0), []);
    const award = pointsForSale(state);
    const startingCash = startingMoneyOf(state);
    const currentRep = repMult(state);
    const nextRep = repMult({
        ...state,
        rep: state.rep + 1
    });
    const currentPoints = legacyPointsOf(state);
    const changeOpen = (next)=>{
        if (next) {
            selling.current = false;
            setHelp(false);
            setSaveFailed(false);
        }
        setOpen(next);
    };
    const sell = ()=>{
        if (selling.current || !canPrestige(state)) return;
        selling.current = true;
        if (onSell()) {
            localStorage.removeItem('wonderkidFactoryV1');
            setOpen(false);
        } else {
            setSaveFailed(true);
            selling.current = false;
        }
    };
    return /*#__PURE__*/ _jsxDEV(Dialog, {
        open: open,
        onOpenChange: changeOpen,
        children: [
            /*#__PURE__*/ _jsxDEV(DialogTrigger, {
                asChild: true,
                children: /*#__PURE__*/ _jsxDEV(Button, {
                    ref: trigger,
                    "data-sell-up": true,
                    "aria-label": "Review selling up",
                    className: "min-h-11 h-auto w-full whitespace-normal rounded-xl bg-yellow-500 py-2.5 text-sm font-bold text-black hover:bg-yellow-400 st-glow",
                    children: [
                        "⭐ Sell up: +1 star, +",
                        award,
                        " legacy point",
                        award === 1 ? '' : 's'
                    ]
                }, void 0, true, {
                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                    lineNumber: 45,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                lineNumber: 44,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV(DialogContent, {
                "data-tycoon-sale-review": true,
                className: "flex max-h-[calc(100dvh_-_2rem)] w-[calc(100vw_-_2rem)] max-w-md flex-col gap-3 rounded-xl p-4 [&>button:last-child]:h-11 [&>button:last-child]:w-11",
                onOpenAutoFocus: (event)=>{
                    event.preventDefault();
                    heading.current?.focus({
                        preventScroll: true
                    });
                },
                onCloseAutoFocus: (event)=>{
                    event.preventDefault();
                    trigger.current?.focus({
                        preventScroll: true
                    });
                },
                children: [
                    /*#__PURE__*/ _jsxDEV(DialogTitle, {
                        ref: heading,
                        tabIndex: -1,
                        className: "pr-12 text-base",
                        children: "Sell up review"
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                        lineNumber: 52,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV(DialogDescription, {
                        className: "text-xs",
                        children: "Restart this ground with permanent rewards. The match keeps running while you decide."
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                        lineNumber: 53,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "min-h-0 space-y-3 overflow-y-auto text-xs leading-relaxed",
                        children: help ? /*#__PURE__*/ _jsxDEV("div", {
                            "data-sale-help": true,
                            className: "space-y-3",
                            children: [
                                /*#__PURE__*/ _jsxDEV("p", {
                                    children: "Selling up trades this ground's progress for one reputation star and legacy points. Your reputation multiplier is permanent, but today's income also depends on the ground, crowd and staff you are resetting."
                                }, void 0, false, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                                    lineNumber: 56,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ _jsxDEV("p", {
                                    children: [
                                        "Example: selling now adds ",
                                        award,
                                        " legacy point",
                                        award === 1 ? '' : 's',
                                        ", taking your balance from ",
                                        currentPoints,
                                        " to ",
                                        currentPoints + award,
                                        ". Your new ground opens with ",
                                        money(startingCash),
                                        ". Rolling Investment is already included."
                                    ]
                                }, void 0, true, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                                    lineNumber: 57,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ _jsxDEV("p", {
                                    children: "These terms follow the live game. A promotion while this is open can increase the legacy points. Back leaves the sale untouched. Only Sell and restart sells the ground."
                                }, void 0, false, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                                    lineNumber: 58,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                            lineNumber: 55,
                            columnNumber: 19
                        }, this) : /*#__PURE__*/ _jsxDEV(_Fragment, {
                            children: [
                                /*#__PURE__*/ _jsxDEV("dl", {
                                    className: "grid grid-cols-2 gap-3 rounded-lg border border-border p-3",
                                    children: [
                                        /*#__PURE__*/ _jsxDEV("div", {
                                            children: [
                                                /*#__PURE__*/ _jsxDEV("dt", {
                                                    className: "text-muted-foreground",
                                                    children: "Legacy points earned"
                                                }, void 0, false, {
                                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                                                    lineNumber: 61,
                                                    columnNumber: 20
                                                }, this),
                                                /*#__PURE__*/ _jsxDEV("dd", {
                                                    "data-sale-award": award,
                                                    className: "font-bold text-sm",
                                                    children: [
                                                        "+",
                                                        award
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                                                    lineNumber: 61,
                                                    columnNumber: 83
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                                            lineNumber: 61,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ _jsxDEV("div", {
                                            children: [
                                                /*#__PURE__*/ _jsxDEV("dt", {
                                                    className: "text-muted-foreground",
                                                    children: "New ground cash"
                                                }, void 0, false, {
                                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                                                    lineNumber: 62,
                                                    columnNumber: 20
                                                }, this),
                                                /*#__PURE__*/ _jsxDEV("dd", {
                                                    "data-sale-starting-cash": startingCash,
                                                    className: "font-bold text-sm",
                                                    children: money(startingCash)
                                                }, void 0, false, {
                                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                                                    lineNumber: 62,
                                                    columnNumber: 78
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                                            lineNumber: 62,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ _jsxDEV("div", {
                                            className: "col-span-2",
                                            children: [
                                                /*#__PURE__*/ _jsxDEV("dt", {
                                                    className: "text-muted-foreground",
                                                    children: "Reputation multiplier"
                                                }, void 0, false, {
                                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                                                    lineNumber: 63,
                                                    columnNumber: 43
                                                }, this),
                                                /*#__PURE__*/ _jsxDEV("dd", {
                                                    className: "font-bold text-sm",
                                                    children: [
                                                        /*#__PURE__*/ _jsxDEV("span", {
                                                            "data-sale-rep-current": currentRep,
                                                            children: [
                                                                "x",
                                                                currentRep.toFixed(2)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                                                            lineNumber: 63,
                                                            columnNumber: 141
                                                        }, this),
                                                        " to ",
                                                        /*#__PURE__*/ _jsxDEV("span", {
                                                            "data-sale-rep-next": nextRep,
                                                            children: [
                                                                "x",
                                                                nextRep.toFixed(2)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                                                            lineNumber: 63,
                                                            columnNumber: 217
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                                                    lineNumber: 63,
                                                    columnNumber: 107
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                                            lineNumber: 63,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                                    lineNumber: 60,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ _jsxDEV("div", {
                                    "data-sale-resets": true,
                                    className: "space-y-1 rounded-lg bg-muted/40 p-3",
                                    children: [
                                        /*#__PURE__*/ _jsxDEV("p", {
                                            className: "font-semibold",
                                            children: "This ground resets"
                                        }, void 0, false, {
                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                                            lineNumber: 66,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ _jsxDEV("p", {
                                            children: [
                                                "Current cash becomes ",
                                                money(startingCash),
                                                ". This ground's earnings reset to 0. Fans return to ",
                                                fresh.fanbase,
                                                ". Ground upgrades and staff start at level 0."
                                            ]
                                        }, void 0, true, {
                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                                            lineNumber: 67,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ _jsxDEV("p", {
                                            children: [
                                                "You restart in ",
                                                DIVISIONS[0].name,
                                                ". The current match, table, win streak and temporary boosts reset."
                                            ]
                                        }, void 0, true, {
                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                                            lineNumber: 68,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ _jsxDEV("p", {
                                            children: [
                                                "Ticket offer returns to ",
                                                TICKET_POLICIES.find((policy)=>policy.id === 'standard').label,
                                                "."
                                            ]
                                        }, void 0, true, {
                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                                            lineNumber: 69,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                                    lineNumber: 65,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ _jsxDEV("div", {
                                    "data-sale-keeps": true,
                                    className: "space-y-1",
                                    children: [
                                        /*#__PURE__*/ _jsxDEV("p", {
                                            className: "font-semibold",
                                            children: "You keep"
                                        }, void 0, false, {
                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                                            lineNumber: 72,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ _jsxDEV("p", {
                                            children: "Your club name, reputation, legacy points and perks, badges, league titles and career records."
                                        }, void 0, false, {
                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                                            lineNumber: 73,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ _jsxDEV("p", {
                                            children: "Your Academy players, first team, gems and gear stay as they are."
                                        }, void 0, false, {
                                            fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                                            lineNumber: 74,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                                    lineNumber: 71,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true)
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                        lineNumber: 54,
                        columnNumber: 9
                    }, this),
                    saveFailed && /*#__PURE__*/ _jsxDEV("p", {
                        role: "alert",
                        "data-sale-save-error": true,
                        className: "shrink-0 rounded-lg border border-destructive p-2 text-xs",
                        children: "The sale could not be saved. Your ground is still running. Keep this page open and try Sell and restart again."
                    }, void 0, false, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                        lineNumber: 78,
                        columnNumber: 24
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "flex shrink-0 gap-2",
                        children: [
                            /*#__PURE__*/ _jsxDEV(Button, {
                                variant: "outline",
                                className: `h-11 px-3 text-xs ${help ? 'flex-1' : 'w-16 shrink-0'}`,
                                onClick: ()=>help ? setHelp(false) : changeOpen(false),
                                children: help ? 'Back to sale review' : 'Back'
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                                lineNumber: 80,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ _jsxDEV(Button, {
                                variant: "outline",
                                className: "h-11 w-11 shrink-0 p-0",
                                "aria-label": help ? 'Close sell up help' : 'Sell up help',
                                "aria-expanded": help,
                                onClick: ()=>setHelp((value)=>!value),
                                children: "?"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                                lineNumber: 81,
                                columnNumber: 11
                            }, this),
                            !help && /*#__PURE__*/ _jsxDEV(Button, {
                                className: "h-11 min-w-0 flex-1 px-2 text-xs",
                                disabled: !canPrestige(state),
                                onClick: sell,
                                children: "Sell and restart"
                            }, void 0, false, {
                                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                                lineNumber: 82,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                        lineNumber: 79,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
                lineNumber: 49,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/protected.tsx",
        lineNumber: 43,
        columnNumber: 5
    }, this);
}
