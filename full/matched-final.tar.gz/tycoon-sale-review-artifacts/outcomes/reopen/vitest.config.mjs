import { defineConfig } from "/home/runner/work/ballpark-hero/ballpark-hero/node_modules/vitest/dist/config.js";
import react from "/home/runner/work/ballpark-hero/ballpark-hero/node_modules/@vitejs/plugin-react-swc/index.js";
import fs from 'node:fs'; import path from 'node:path'; import crypto from 'node:crypto';
const seen = new Map(); const dir = "/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/reopen"; const wanted = ["/home/runner/work/ballpark-hero/ballpark-hero/src/test/tycoonSaleReview.test.tsx","/home/runner/work/ballpark-hero/ballpark-hero/src/pages/StadiumTycoon.tsx","/home/runner/work/ballpark-hero/ballpark-hero/src/hooks/useStadiumTycoon.ts","/home/runner/work/ballpark-hero/ballpark-hero/src/components/tycoon/TycoonSaleReview.tsx","/home/runner/work/ballpark-hero/ballpark-hero/src/lib/stadiumTycoon.ts","/home/runner/work/ballpark-hero/ballpark-hero/scripts/fixtures/tycoon1080Baseline/stadiumTycoon.ts","/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/reopen.tsx"];
const hash = value => crypto.createHash('sha256').update(value).digest('hex');
export default defineConfig({ root: "/home/runner/work/ballpark-hero/ballpark-hero", plugins: [react(), {
  name: 'retain-sale-transform', enforce: 'post', transform(code, id) {
    const file = id.split('?')[0].replaceAll('\\', '/'); if (!wanted.includes(file)) return null;
    const input = fs.readFileSync(file); const output = 'transforms/' + hash(file).slice(0, 16) + '.js';
    fs.mkdirSync(path.join(dir, 'transforms'), { recursive: true }); fs.writeFileSync(path.join(dir, output), code);
    seen.set(file, { file, inputSha256: hash(input), transformedSha256: hash(code), output });
    fs.writeFileSync(path.join(dir, 'transforms.json'), JSON.stringify([...seen.values()], null, 2)); return null;
  }
}], test: { environment: 'jsdom', globals: true, setupFiles: ["/home/runner/work/ballpark-hero/ballpark-hero/src/test/setup.ts"], include: ["src/test/tycoonSaleReview.test.tsx"], testTimeout: 60000 },
resolve: { alias: {"@/components/tycoon/TycoonSaleReview":"/home/runner/work/ballpark-hero/ballpark-hero/tycoon-sale-review-artifacts/outcomes/copies/reopen.tsx","@":"/home/runner/work/ballpark-hero/ballpark-hero/src"} } });
