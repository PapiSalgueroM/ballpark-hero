const _dukbDiscovery = await import('node:fs');
_dukbDiscovery.appendFileSync(process.env.DISCOVERY_MARKER, JSON.stringify({file:"simGuardedImport.mjs",only:process.env.ONLY??null,browser:process.env.BROWSER??null,base:process.env.BASE??null,sweep:process.env.SWEEP_BASE??null})+'\n');
console.log("simGuardedImport.mjs\nOwned child selected\nNo game or browser executed\nSelection receipt complete");
process.exit(0);
let chromium = null; try { ({ chromium } = await import('playwright')); } catch { /* it skips its one browser section */ }