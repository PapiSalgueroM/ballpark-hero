const _dukbDiscovery = await import('node:fs');
_dukbDiscovery.appendFileSync(process.env.DISCOVERY_MARKER, JSON.stringify({file:"simTryFinally.mjs",only:process.env.ONLY??null,browser:process.env.BROWSER??null,base:process.env.BASE??null,sweep:process.env.SWEEP_BASE??null})+'\n');
console.log("simTryFinally.mjs\nOwned child selected\nNo game or browser executed\nSelection receipt complete");
process.exit(0);
try { await import('./lib/playwrightLoader.mjs'); } finally { /* no catch: nothing handles a missing browser */ }