const _dukbDiscovery = await import('node:fs');
_dukbDiscovery.appendFileSync(process.env.DISCOVERY_MARKER, JSON.stringify({file:"simWrappedDriver.mjs",only:process.env.ONLY??null,browser:process.env.BROWSER??null,base:process.env.BASE??null,sweep:process.env.SWEEP_BASE??null})+'\n');
console.log("simWrappedDriver.mjs\nOwned child selected\nNo game or browser executed\nSelection receipt complete");
process.exit(0);
try { const { chromium } = await import('./lib/playwrightLoader.mjs'); await chromium.launch(); } catch (error) { throw error; }