# Round 1079: saved Club Manager match plans

Third preparation run37609334335 passed all remote steps at
5bd61605cae9cd472b0030d946ad514e3c998d51,
tree4e54264404f145ee9232005531feae52c2f5932e, job112752481030.
Artifact11477492748 ZIP SHA256
2f86aa9e1ccfad9b6c03ab2250a53fbffad7ca1a851ba938684d043b70e21fa3
was downloaded and independently inspected.13/34 outcomes/faults,4 original
regressions,36 scene cases, complete three-suite baseline comparisons,20 readers
and3 native profiles/9 restored DOM controls passed. All30 screenshots were
reviewed, with14 source holds and12 exact save records. The action margin has
at least11.34375px observed clearance in these profiles.

Visual review still found that expanding kickoff details left the new lineup
below the phone screen. This is corrected with a dedicated reveal target that
keeps Apply/Hide and the first row visible. Final native now requires first-row
visibility before any driver navigation and adds one effective restored offscreen
lineup fault per profile, for12 controls total. The final PR run and its artifact
must verify this amendment. Original assertions and three known legacy reds
remain intact. No final-ready, release or live claim yet.

Second preparation run37606817122 at410f6d588e0d67e6546d5f18bc70dbc686427dce
passed13 mounted outcomes/34 effective faults, four original regressions,
36 rendered set-piece outcomes and20readers.
Complete legacy comparisons retained three identical old red outcomes and a
changed executable control, without rewriting their original assertions.
Artifact11475976070 ZIP SHA256
9fb97bd65e931db4878a235f02cba925f4baa909c8b4e87ba81402e00d6e63e0.
Native reached only320px, rejecting Apply/View at bottom780.15625 against780.
Three DOM faults, actual fonts,14 source holds and storage isolation passed;
later journeys and other profiles remain unverified. Action and empty-slot
reveal rows now have12px bottom scroll margin. Native assertions are unchanged.
No ready or live claim is made from this failed preparation.

Preparation, October 7, 2026. Base main 2fff5e044160b70bd58b64d931793ee4e443cedd.
Branch codex/manager-match-plans-1079. No live claim, merge or publish.

Three named slots store formation, mentality, requested XI, duties, captain,
set piece assignments and shootout order. Apply updates tactics atomically and
clears pending pitch selections. Preview resolves the actual current squad with
the existing engine, including unavailable players, replacements and fitness.
Club and era metadata, phase, live match and active save-slot guards prevent
foreign or stale plans from changing a career. Old saves need no migration.

The new compact Tactics tile has Back, Escape, help and a worked example.
Its next action is revealed through the existing scroll hook. No league, player,
match model, result probability or random stream is added or changed.

Remote acceptance is pending. Authored checks: 13 mounted outcomes, 34 copied
source faults with mapped assertion failures and an independent engine baseline,
13 source holds; three native profiles and12 restored DOM geometry controls.
Native runs use the actual career hook and TacticsScreen in an offline fixture,
not the full app or a live service. Availability and club transitions are explicit
fixture inputs. Fonts and flags use actual cached dependencies. Existing tactics
controls retain their original sizing; new plan controls must be at least 44px
and new copy at least 12px.

Workflow also runs real app types/build, existing manager regressions,
all 20 built/source readers, and source/data holds. All runtime is remote CI.
No production traffic, database changes, scored games or local runtime.
Final hashes, runs, artifacts and independent inspection will be recorded after
remote evidence is available. This document does not yet credit passing runtime.

Static peer review found and fixed stale-tab false success notices. New callbacks
return acceptance; refused actions show an alert and hold pending selections.
The added mounted case clicks Save, Apply and Delete after switching slots.
Runtime verification of this amendment is pending the next preparation run.

First preparation run37603633795 at1706b8fd completed with failure. Artifact
11474616431 was independently inspected, ZIP SHA256
037359fa401dd4ccf6c5996ed39525ec1a312e72d1f99c8ae49488bd461e6eba.
Types/build and all20readers passed. Older mounted12/12 and32 effective faults
passed, each with its named unchanged engine baseline; all33 integrity reports
hold13files. This run does not verify the new13/34stale-tab amendment.
Native ran zero journeys because the independent Node engine import lacked
localStorage. Its14held sources were unchanged. Fixed in the driver only with
an isolated import-time storage adapter and exact global restoration.

Existing tactics checks themselves printed pass, but the offline wrapper caught
flagcdn route continues. Optional verified local asset fulfillment now keeps the
same gestures/assertions offline. Uncached asset appearance is explicitly
unverified. The set-piece scene reported36 rendered passes but the wrapper
classified its one-line report EMPTY; subsequent workflows run it directly and
retain the36-case report. Three old engine checks also remain red: player-career
captaincy0 handovers versusfloor2, shootout150dated-fixture mismatches, manager
slots3decision mismatches and442389bytes versus440000. A pinned complete-tree
remote comparison is being added; no original assertion or fixture is rewritten.
No final acceptance, integration or live claim is based on this failed run.
