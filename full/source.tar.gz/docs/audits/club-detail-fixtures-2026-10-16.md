# Club detail league fixtures, 2026-10-16

Base: `a758fcec4392c57c639aa54cda840810c8e44663`. Branch: `codex/manager-club-fixtures`.

Status: corrected baseline and fixed remote verification qualified. PR285 is ready for Claude I's integration review. No runtime has run locally and no release or live-site claim is made.

First remote run `38880595650` at `2fbdcbf6` was blocked by four test-only type errors: Testing Library role options do not accept `exact: true`. No test ran and no baseline credit is claimed. Removing only those four unsupported options keeps exact string-name matching, all ten case identities and every outcome expectation. The type step now prints its retained diagnostics and preserves the compiler exit status. Retained artifact `12038135044` has ZIP SHA256 `5c7c409fe347880896ca75fdafa37eb53687374de72843de34d15ff818e8cf17`.

Corrected baseline `ce8b644b`, run `38881328433`, job `116908498375`, passed the real application type gate. Root reviewed the complete report: exactly seven named missing-action Boolean faults and three preservation passes, plus all eleven old roster outcomes. No setup fault received credit. The product was unchanged through this baseline.

The requested view is a plain Fixtures action inside the existing club header, opening a separate league fixture view with Back. The initial squad structure, values, player rows and outer navigation stay intact. No extra default `.bg-card` wrapper or sibling between club header and squad is permitted, because retained roster unit and browser consumers use those seams.

The reader uses the save's own `leagueClubs` for the managed league, or another league's saved `world[id].table` membership, following WorldTablesCard. It calls the existing `careerRoundPairs` with that membership and league id. Own progress counts league entries in `calendar.slice(0, week)`; world progress uses that league's `world[id].round`. A calendar index is not a league round. Odd-league byes are omitted. Clubs without saved league membership get an unavailable message, never an invented cup or Champions League schedule.

`pairResults[leagueId]['home|away']` is a single `[homeGoals, awayGoals]` tuple. Its reverse is a separate match. Only completed rounds can expose valid nonnegative integer scores. Missing legacy results are labelled `Result not recorded`; unplayed matches say `Upcoming`. Table totals cannot reconstruct a score. Repeated occurrences of one directed pairing cannot be assigned a single ledger tuple unambiguously and must remain unrecorded. No core, calendar, save schema, sport data, roster or RNG changes are in scope.

Ten actual component cases are declared: seven feature cases and three preservation cases. Feature cases also call the actual pure reader after the Fixtures action succeeds. A Vite glob keeps the absent new reader from causing a baseline import error. Baseline must have exactly the seven named Boolean missing-action faults and three passes, with zero pending cases, setup failures or transport attempts. Fixed requires all ten, whole original-component control reproducing the same seven faults, then restored ten plus all eleven existing roster unit outcomes. The save test uses the actual `loadCareer`, rather than claiming JSON parsing proves a loader.

The remote workflow retains source archive, installed package versions, real app types, JSON reports and complete logs, then fixed build and all fifteen rebuilt-site readers. Source and package bytes are held after controls. Production database, AI validators, app browser and local runtime are unused.

## Existing roster source fences

`scripts/simClubDetailCurrentRoster.mjs` reconstructs the complete component from `082fc277` and its four roster substitutions. Its core-ref environment option does not admit additive UI. The shared `scripts/lib/clubDetailFixturesSourceJoin.mjs` inverts exactly four additive import/state/view/button spans, requires each exact anchor once and restores current source forwards. Partial or duplicate joins fail. Both old consumers compare that explicit inverse to the unchanged historical full plan. The historical `plannedSha256`, `.fixed-plan`, `.inverse`, original parent, roster spans, eight named cases and three-fault/five-preserve original control are retained. The full current component stays bound by existing source receipts; reader/helper have separate committed-HEAD bindings and before/after receipts. The new workflow runs the old sim normally and with its original control using `CM_OWN_ROSTER_CORE_REF=HEAD`.

The old workflow is frozen and unchanged. Its browser consumer is adapted at source only and receives a remote syntax check; this packet claims no executed Club Manager browser journey or pixel review. Actual outcome coverage is the new ten, the original seven-fault control, restored twenty-one, and the two old source-proof methods. The default squad DOM is unchanged after the explicit inverse, including both `.bg-card` wrappers and direct player rows.

## Fixed remote result

Tested source `71b4e158e6b5279d951e4cfd27fad26f1303a670`, tree `307917e2c5ad6701df031505001a6def4f4aaf9c`, run `38882205996`, job `116911371960`, succeeded. Actual app types, ten current component cases, whole original-component control (seven exact missing-action faults and three passes), and twenty-one restored/related cases passed. The old roster proof retained all eight normal outcomes and exactly three original-control faults plus five preserves. The actual production build and all fifteen rebuilt-site readers passed, with source and package holds.

Artifact `12037814003`, 37,847,032 bytes, SHA256 `597e20356f0cc859325ff78c2690853c8504a70d5ee041d29d38b198ed24aa48`, is retained under `C:/Users/antho/dukb-handoff/2026-10-16/club-fixtures-fixed`. The corrected baseline artifact `12037482659` has SHA256 `e181bf9ce0b15cf35ac68d36d7665e62bf506040057e2e18f5f89f573a1ae2ef` and is retained separately. No full-suite, executed Manager browser, new tournament or live-site claim is made. Final documentation leaves tested application, test and workflow bytes unchanged.
