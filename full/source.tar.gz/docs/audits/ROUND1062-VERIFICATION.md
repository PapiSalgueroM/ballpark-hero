# Round 1062: MMA Fight Promoter

2026-10-06. Anthony requested running a fictional MMA organization and booking
its fights. Existing /fight-promoter now offers separate MMA and Boxing saves.
MMA has24 original fighters, three divisions, contracts, recovery, rankings,
championship belts, three-bout cards, venue/ticket decisions and saved receipts.
Twelve events or a deliberate early close produce a score out of100.

The deterministic engine applies actual fight results, records, contracts,
recovery, belts and finances exactly once. Action replay reconstructs a save
from its original seed and rejects impossible edited state. Existing boxing
engine and save bytes are unchanged. Help labels each mode's distinct rules.

## Preparation acceptance

Accepted source36ca20f4c507c92662cff106b104af3eff829f92.
Run37427099437, job112149131714, passed all17 steps with no skips.
Actual reports show20 mounted outcomes, zero failed/pending tests; normal
plus23 effective copied-source controls all passed. Real engine distributions
cover72 campaigns,864 events and480 attribute/method bouts. All15 existing
fight/career/save/scoring/name regressions and16 built readers passed.

Allfour native profiles passed:320px touch/dark/reduced motion,390px touch/light,
1280px mouse/dark and1280px keyboard/light/reduced motion. All66 measured screens
kept44px actions inside the viewport, without automatic scroll or overflow.
The390px journey signed eight fighters, checked roster/ranking pagination,
ran a full three-bout card and verified its actual receipt. Saved boxing played
through its unchanged engine, with exact saved-state comparison. Page, console,
font and local-request failures were zero, as were outbound writes.
Four effective controls changed actual action size, clipping, overflow and
keyboard focus, and each failed for the promised outcome.

Artifact11395895934 ZIP SHA256:
53ebf8734e46b7c6f277709a9f8c9e5c6a0e695e84c36d33ca229ac1696dd780.
Extracted at C:/Users/antho/.codex/artifact-inspection/mma-11395895934/.
Source-head and all seven generated SHA256 values were checked; every value
matched again after copy. Phone dashboard, full card and receipt were inspected.
Only the promoter's frozen guide entry changed. The sitemap re-dates only
/fight-promoter; Whats New keeps its existing October6 date with a new hash.
Temporary push/generation steps are removed before final committed-source CI.

## Measured repairs

First preparation37423283681 passed engine/controls/built readers, but found
a scoring import traversal gap, an unregistered name bank and controls below
the phone/short-desktop viewport. Alias imports, bank registration and compact
layout repaired those without weakening any checks or reducing44px controls.
Second preparation37425219806 passed all MMA native geometry, but the name
bank could emit a shipped real name and the boxing comparison reused mutable
state and an advanced module-local ID counter. Two new surnames changed, and
the expected boxing event now uses fresh saved bytes and a fresh unchanged
engine instance for each browser lifecycle. Exact whole-state equality stays.
No generated files from either failed run were copied.

## Final source status

Final committed-source CI is pending. No1062 merge or live claim yet.
No local runtime, install/build, production database, paid host AI, AdSense
submission or indexing request. Root held drafts and seven stashes are safe.
Claude retains his product lanes and the1062 publication handoff.1061 is live.

## Integrated source preparation

Prior final source4a31748b93149ef34fc034c86d7bfd2a40a153b1 passed allthree
workflows and44steps, no skips: MMA37428894527, Career entry37428894500
and Sport hub37428894526. That acceptance predates Release AE integration.

Main2f81e797 and its docs-only receipt af468ebd are preserved. MMA engine,
hook, UI and test bytes are unchanged. WhatsNew keeps both lanes' entries.
Auxiliary source0a0be051f38f5e7435f1de175b315f75ed1d86d1 contains only a
temporary generation workflow beyond integration74761c0e. It is excluded
from PR144. Run37430395602, job112159680583 passed all13 steps, no skips.
Both real builds and scoped search/prerender/sitemap generation passed.
Artifact11396812113 SHA256:
420388ed71ea916e709041946d48d29ed8ea29fd896f10df35f03aef7aa338fe.
Source and seven manifest values matched before and after copy. Only the
updates snapshot, lastmod ledger and search differ from integrated source.
Integrated final committed-source CI remains pending; no1062 live claim.


## Integrated final acceptance

Exact source11f6675d8cf73d28756f7faf40db3d4ae38391da passed allthree
workflows and44steps with zero skips. MMA37431245658 passed outcomes and
effective controls, all15 fight/career/scoring regressions,16 built readers,
four native MMA/saved-boxing journeys andfour geometry/focus controls.
Career entry37431245665 passed mounted controls,18 readers/guide harnesses,
all six guide mutations in their intended sections and native journeys.
Sport hub37431245640 independently passed all14steps,7 mounted outcomes,
eight controls,17 readers,18 native journeys andlight/overflow checks.
Actual closing logs were inspected. Independent integration acceptance
confirms boxing unchanged, MMA source/tests unchanged from4a31748b,
AE receipt preserved, combined update entries and helper workflow excluded.
No blocker. This final receipt changes documentation only. PR144 may land
without repeating runtime gates. Claude holds publication after landing.
No1062 live claim until independently verified.

