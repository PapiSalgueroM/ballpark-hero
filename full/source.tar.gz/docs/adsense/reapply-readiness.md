# AdSense re-application readiness

## Current status, September 30: Needs attention, Low value content

Codex directly read the Sites row and policy card in the owner's browser. Ads.txt
is Authorized; the displayed last status update is September 25, 2026 at 4:59 AM
EDT. The policy card asks for original useful content or tools, ongoing curation
and real user interest. It names no individual page. No new review was requested.
The prior pending status below is historical. Current live checks, the reproduced
trailing-slash guide defect assigned to Claude, and the audit repair are recorded
in [the September 30 receipt](../audits/GOOGLE-READINESS-2026-09-30.md).

## Historical status: review requested September 15, 2026

**18:47 EDT publication follow-up:** the factual corrections to all five
format guides, their phone-table improvements and the three save/account
claims are now independently verified live. All seven affected pages match
the reviewed content, links and metadata. The current observed entry is
`index-jZ501OVb.js`. See [the public proof](guide-publication-proof-2026-09-15.json)
and [the full correction evidence](guide-correction-release-checks-2026-09-15.md).
The last direct AdSense observation remains **Getting ready, Review requested**
at 12:37 EDT. The account has not been checked again successfully since then,
and no further request was submitted. This publication check does not prove
a new Google crawl, indexing or approval.

**AdSense accepted the new request at 4:19 AM EDT.** After confirming the
improvements were live, Codex checked the fixed-issues box and selected Request
review. The site detail page changed from Needs attention to **Getting ready**
and displayed **Review requested**. Google has not approved the site yet. This
status supersedes the historical rejection and waiting recommendations below.

At the original 4:18 AM check, Rounds 585 and 600 to 602 were live from source `d5aa1b15`, with public entry
`index-Cq-NK7oX.js`. Claude's desktop lane published them; Codex independently
verified all eleven affected guide/navigation pages and the actual animation
module graphs at 4:18 AM EDT. The five guides contain 61 contextual citation
groups and 235 ordered source links. The four US manager pages and Record Books
link to the guides, and Footle describes its game rules without the broad
tracking claim. Trophy animations are present in Soccer Career, Club Manager
and Stadium Tycoon, with pack and gem code still present on the tycoon route.

The combined build, affected browser checks, all five format-history harnesses
and exact saved-page inspections passed before release. The artifact was
verified against its recorded inputs and outputs. Live evidence is recorded in
`docs/PROJECT-STATE.md`; the console action is in
[the direct console record](console-check-2026-09-15.md).

All five Google URL Inspection live tests passed earlier in this session, and
Google accepted one indexing request per guide. Those requests were not
repeated. The sitemap reports Success and 148 discovered pages. IndexNow also
accepted the 15 changed routes with HTTP 200 at 4:20 AM EDT after live checks.
Neither crawl-request acceptance nor these site improvements guarantee approval.

Next: let Google process the submitted review and inspect its actual decision.
Do not submit again while Review requested is shown. No particular wait length,
word count or number of indexed pages is a published approval guarantee.

## Historical investigation before this request

**Status update, 2026-09-15: the owner confirms another rejection.** Anthony
supplied a new screenshot and confirmed this is a new rejection since the last
submission. Ownership is verified, the policy card says **Low value content**, and
Request review is available. No individual URL or decision date is shown, so this
is the date reported, not an asserted Google decision date. Earlier submitted or
pending statuses are superseded.

**Fresh console evidence on September 15:** the Sites row gives September 9,
2026 at 4:47 PM EDT as the last approval-status update. The help popup confirms
that meaning. This predates the September 12 guide additions. Ads.txt is
Authorized, the payment profile is complete, and a European regulations message
for this domain is Published. See [the direct console check](console-check-2026-09-15.md).
No settings or review status were changed during that check.

The live site already has readable saved pages, guides, About and Privacy content.
Round 600 was claimed to place the existing verified source links beside the format
periods and exceptions they support in the five explainers. This improves
verifiability for readers; it does not establish the cause of rejection or promise
approval. Fresh Search Console inspection is now complete: all five guides show
discovered with no recorded crawl. All five live tests passed, and Google accepted
all five indexing requests. The sitemap reports Success, 148 discovered pages,
and September 15 as its last read. The aggregate indexing report is still dated
September 3, so its 58 indexed / 91 not indexed totals predate the newest guides.
Full evidence is in [the September 15 inspection](../seo/gsc-indexing-2026-09-15.md).

The live audit found no accidental noindex, missing canonical or empty snapshot
among the ten active games in the older crawled examples. Intentional retired and
hidden routes keep their existing controls. Round 602 corrects Footle's broad
"No tracking" claim and improves links to the existing guides. The next useful
evidence is a recorded crawl after these requests and the next publish. Indexing
is not a guarantee or a published AdSense approval prerequisite. No new AdSense
review request has been sent from this session.

Before publication, Rounds 600 and 602 were built and reviewed in the combined release branch:
61 source groups make the five guides' existing evidence easier to follow;
the four US manager games and Record Books link back to those guides; Footle's
subtitle describes its actual rules without the broad tracking claim. Publishing
is pending full integration gates. Once live, verify the saved HTML and the
actual game pages before another AdSense request. The older recommendation below
to wait for a particular indexing state was a project judgment, not a published
Google approval requirement. No fixed waiting period or indexing count is a
guarantee of approval.

**Status update, 2026-09-12: two of the verdict's three conditions are now met, and the
third is Anthony's to produce.** The verdict below, written after the second rejection, said
not to request another review until three things were true. Where they stand after the
2026-09-12 publish:

1. **"the explainers cover more than one competition": MET.** The reference layer covers five
   now, not one. `/champions-league-format-history` (Round 520) and `/nfl-playoff-format-history`
   (Round 522) were live already. Rounds 532, 533 and 534 add `/nba-playoff-format-history`
   (fifteen format periods from the 1946-47 BAA bracket, plus the draft lottery's own history
   from the coin flip era), `/mlb-postseason-format-history` (eight periods from the 1903 World
   Series to the twelve club bracket, with the 1904 and 1994 Octobers that were never played)
   and `/nhl-playoff-format-history` (ten periods from 1917-18, with 1919 and 2004-05 when the
   Cup was not awarded). Each is two source verified per period, prints its sources and its
   verification date on the page, leaves out anything only one publisher carries, and names the
   fetches that were blocked rather than citing them.
2. **"the hubs link into them": MET.** Round 528 gave every sport hub a reference block: the
   Record Books section for that sport by anchor, the grid archive where one exists, and the
   format explainer where one exists. Verified live on 2026-09-12: `records#cup` on `/hockey`,
   `records#ws` on `/baseball`, `records#nba` on `/pro-basketball`, `records#cbb` on `/college`.
3. **"a Page Indexing report taken after those pages ship showing them crawled": NOT MET, AND
   ONLY ANTHONY CAN PRODUCE IT.** Search Console is his login. The three new pages went live on
   2026-09-12, so the report is not worth taking yet: Google needs to find and crawl them first.

**What the reference layer looks like as a whole now**, which is the thing a reviewer would be
judging: five format explainers, the Record Books over twelve audited champion tables (1,068
rows), four grid archives (56 past boards, 4,032 published answers, every one recomputed by the
game's own matcher), and the Hall of Champions. All of it is either derived from the site's own
audited tables or two source verified with the sources printed.

**The verdict is therefore unchanged in form but not in substance: still do not click yet, and
the reason is now waiting rather than building.** Give Google roughly a week from 2026-09-12,
then Anthony opens Search Console, takes the Page Indexing report, and sends it. If the five
explainers and the hubs show as crawled and indexed, that is the moment the review request is
worth his click. If they show as "Crawled, currently not indexed", the reference layer is not
the lever and this file should say so plainly rather than asking for a sixth explainer.

**What is NOT recommended, and why it is worth writing down.** The addendum's list also names
salary cap explainers, transfer window explainers and draft history. Round 531 has just put the
four real salary cap figures into `src/lib/leagueCaps.ts` with a date and two publishers each,
so a cap explainer is now cheap to build honestly. Do not build it yet. Three of the five
existing explainers have never been crawled, so another one adds pages nobody has read rather
than evidence about what Google objects to. Build the sixth only if the Page Indexing report
comes back showing the first five indexed and the site still rejected.

Asked for by the owner's directive of 2026-08-30, section 19. Written 2026-08-30
after Rounds 348 to 359. Every number here was measured, and the script that
measured it is named so it can be re-run. Nothing in this file is an estimate.

**Status update, 2026-09-10: the review did not clear the site.** The owner
sent the AdSense console again on 2026-09-10. It shows the same "Low value
content" policy card, with the minimum content and thin content guidelines
linked and the "I confirm I have fixed the issues" box and Request review
button available again, which is the state the console returns to after a
rejection. As before, no page and no reason is named. The date Google decided
is not visible in the screenshot, so this file records the day the owner
reported it, not the day it happened. Round 520 is the first response: the
first reference explainer the 2026-08-30 addendum asked for
(`/champions-league-format-history`, section 4 and section 9), two source
verified per season with its sources and verification date printed on the page.
One page is a start and not a layer; see the verdict.

**Status update, 2026-09-02: Round 400 is live and the AdSense review is
submitted.** The complete local matrix passed before ship, followed by live
route-boundary checks and a fresh 29-route Google-render audit. Search Console
accepted the 137-page sitemap and queued all ten priority URLs. AdSense now
shows Getting ready and Review requested. Google has not decided whether to
approve the site.

**The verdict is at the bottom. Read the evidence first, because the verdict is
only worth what the evidence is worth.**

---

## What the rejection said, and what it did not say

The review came back as a policy violation, "Low value content". That is a
site-level judgement, not a list of URLs. Google names no page, gives no
threshold, and offers no diff. So the honest starting position is that we do not
know what a reviewer looked at, and any plan built on guessing that is a plan
built on nothing.

The directive's instruction was "find evidence, do not guess", so the first
response was measurement rather than writing.

## What was measured, and what it ruled out

`scripts/auditGoogleRender.mjs` fetches the live site three ways: raw HTML with
no JavaScript, the page after the app boots, and the page rendered with the
database refused outright. Full output in `docs/seo/google-render-audit.md`.
This table preserves the detailed 2026-08-30 live baseline. A fresh live run on
2026-09-02 after Round 400 was published again audited 29 routes. All returned
HTTP 200, all raw responses exceeded 300 words, and no route lost more than half
its words when database access was blocked. `/soccer-career` carried 1,878 raw
words and 1,935 after render; `/leaderboard`, the closest database-blocked case,
carried 591 raw words, 1,211 normally rendered and 621 with data blocked.

| Hypothesis for "low value" | Measurement | Result |
|---|---|---|
| Crawler sees an empty shell | 29 pages, raw HTML, no JS | **0** under 300 words, **0** without an H1 |
| Page collapses when the API fails | Same 29 with the database refused | **0** lost even half their words |
| Pages are thin | Unique words across all 153 shipped documents | median **584**, 90th percentile **970**, home **923** |
| Copy is templated | Five-word shingle overlap, all 137 substantive pages | **no pair above 50%**, only 8 pages have a twin above 30% |
| Sentences repeat sitewide | Sentence frequency across all pages | only **5** sentences appear on more than half |

Every page under 200 unique words in that baseline was inspected individually.
All of them fell into three groups: eleven retired-game signposts that
canonicalise to their replacements, private pages that are noindexed, and four
games the owner pulled from the menus himself.

**That live snapshot had no measured thin-content defect.** That is the single
most useful thing the content audit produced, because it means the fix is not
"generate more pages", and mass-produced copy would make the judgement worse
rather than better. Round 400 later found a separate ad-delivery defect that the
content audit did not test.

## The one weakness the measurements did surface, and what was done about it

The six sport hubs were simultaneously the thinnest indexable pages and the most
similar to each other. That was deliberate once: `sportHub.ts` said in its own
comment that the copy was kept alike so a new hub would obviously be a copy of an
existing one. Convenient for a developer, and exactly the profile of a page that
lists links without saying anything.

| | Before (Round 356) | After (Round 357) |
|---|---|---|
| Words per hub, raw HTML | 521 to 614 | **1,362 to 1,935** |
| Worst similarity between two hubs | 36% | **11%** |

Written by one researcher per sport from the real registry, then put through
three adversarial passes: 44 problems found, then 21, then 2. The middle pass is
the instructive one, because the checkers were reading this repo's own source and
database and catching false claims about our own games. `simHubDepth` now fences
depth and difference together, with a clone control, because a padded hub is
worse than a short one.

## What else has landed since the rejection

- **Four archive pages** (`/nba-grid/archive`, `/mlb-grid/archive`,
  `/hockey-grid/archive`, `/cbb-grid/archive`): 56 past boards, 504 cells,
  4,032 published answers, every one recomputed by `simGridArchive` against
  that game's own matcher and live data. These are unique by construction. The
  boards are ours and the answers are derived from our own database, so the
  content cannot exist anywhere else. The fourth archive went live in Round
  369 on 2026-08-31.
- **Layout stability**, which is a ranking and quality signal a reviewer can feel
  even without naming it. Cumulative Layout Shift on the six grid pages at 375px
  went from as bad as 0.60 to zero (Rounds 348 and 351). Google calls anything
  above 0.25 poor.
- **Two production bugs that made games unplayable**, both found by building
  tools on the games' own code rather than copies of it. Round 358: the three
  franchise grids returned nothing if any single page of their data fetch
  errored, and the database does cancel those under load. Round 359: the same
  fragility in the shared paging helper, which nine more libs depend on.

## Round 400: the ad-placement boundary, live and submitted

The 2026-08-30 audit measured content. It did not ask which routes could load
the AdSense account script. With stored accepted consent, `index.html` loaded
that script globally even when a page rendered no deliberate `AdBanner`. That
left Auto Ads able to inspect private, legal, retired, low-content and fallback
screens that were never intended to carry ads.

The concrete pre-fix surface included six noindexed snapshots:
`/football-timeline`, `/guess-nfl-team`, `/higher-lower-transfers`,
`/pack-battle`, `/reset-password`, and `/shirt-number`. The bare fallback shell
also loaded the account script before its pre-boot noindex marker ran. Three of
the retired pages, Football Timeline, Higher or Lower Transfers, and Pack
Battle, additionally rendered a manual ad slot.

Round 400 keeps the publisher verification meta tag global, removes the global
AdSense script loader, and makes the accepted-consent path load AdSense only
beside a deliberate manual slot in a document that does not declare noindex.
The three retired manual slots are removed. A same-tab consent event lets a
newly accepted game page start its eligible slot without waiting for a reload.
Cross-tab acceptance now preserves an active game, while withdrawing consent
still reloads to remove vendor code that already ran. A short head-settle retry
also lets a valid game initialize after leaving a noindexed route without ever
loading an ad while the noindex remains.

The final browser run passed. It measured a 358 pixel manual slot on a 390 pixel
phone and 864 pixels at desktop width. Stored and fresh Accept produced exactly
one deliberate request; 16 private, legal, retired, redirect and fallback routes
produced zero; Essential only produced zero. Game-to-noindex,
fallback-to-game, private-noindex-to-game, cross-tab Accept and cross-tab
withdrawal all passed. Five negative controls independently reproduced the old
global loader, zero-width slots, fallback noindex poisoning, an acceptance
reload and a persistent noindex. Every control produced only its owned failure.

Round 400 also closed the manual-unit dependency. AdSense now lists one
responsive Display unit named `DoUKnowBall Game Banner`, slot `7540487748`.
All 75 source `AdBanner` callers across 75 files were changed from 26
placeholder values to that slot. Four callers are legacy unrouted pages, so the
reachable inventory is 71 pages. The final source scan reports zero mismatches.

The final `build:seo` prerendered 142 routes with zero failures and correctly
refused three account-only routes. All 137 sitemap documents are crawler
readable and none carries noindex. The exact TypeScript gate passed. All 13
built-site fences, the AdSense harness with 14 negative controls, the legal
harness with four controls, and the brand harness with two controls passed.

After publish, the live audit confirmed one publisher meta and zero global
AdSense loaders in raw HTML. Accepted `/footle` produced exactly one ad request,
one loader, one manual slot and one queue entry. Home, Privacy, Terms, password
reset and an unknown fallback route produced none. Moving in the live app from
password reset to `/footle` removed the saved noindex and initialized exactly
one eligible slot. `ads.txt` exactly matched publisher `pub-2929318086316376`,
and the sitemap contained 137 unique HTTPS URLs.

A deliberate decision worth recording: the Record Books were **not** split into
twelve champion pages. A list of past champions sits on a thousand other sites
and adds nothing by existing here again, which is the exact profile the rejection
describes. Rejecting easy page count is part of the recovery, not a gap in it.

## What the Google consoles establish, 2026-09-02

The account used for both checks was `anacatu2025@gmail.com`. The evidence was
first inspected without changes. Round 400 then created the ad unit, changed
the two site settings recorded below, submitted the Search Console requests and
submitted the AdSense review.

**AdSense.** Before submission, publisher `pub-2929318086316376` showed the site
as **Needs attention**, with **Low value content** last updated 2026-08-30 at
3:52 AM EDT. Ownership is verified and ads.txt is **Authorized**. Policy Center
shows no current issues. Google CMP has two active European regulation messages
across the account: one targets `douknowball.com`, and the other targets
`footyfein.com`. Only the first applies to this site.

The `douknowball.com` message was published on 2026-02-11. It is available in
English plus 31 other languages. The Consent, Do not consent and Manage options
choices are all ON; Close as do not consent is OFF. Consent message
optimization is ON. Consent mode for advertising and special feature 2 are
OFF. Legitimate-interest controls are ON, and Enabled by default is ON. The
account-level partner selection lists 198 common ad partners. These CMP
settings were inspected read-only, and no CMP setting was changed.

The account now lists one responsive Display unit, `DoUKnowBall Game Banner`,
with slot `7540487748`.

The verified final site settings are Auto Ads **OFF** and Auto optimize **OFF**.
Both values were confirmed false after reopening the site settings. After the
live checks passed, the confirmation was checked and Request review was
submitted. The authoritative page state changed to **Getting ready** and
**Review requested**. The older details row still displayed the prior Needs
attention result immediately afterward; the new review state is the current
submission signal. Google says review usually takes a few days and can take two
to four weeks.

**Search Console.** The sitemap was resubmitted on 2026-09-02. Google accepted
it, read it the same day, reports status **Success**, and reports 137 discovered
pages. The Page Indexing report, dated 2026-08-27, shows 44 indexed and 89 not
indexed. Those figures and the sitemap count have different report dates, so
this document does not force them to reconcile. Manual Actions shows none and
Security Issues shows none. `/soccer-career` is indexed and its inspected page
was last crawled on 2026-09-01.

The ten-route recrawl batch was inspected before submission and every route was
unindexed. After Round 400 was live and its route checks passed, every URL below
returned **Indexing requested** and **URL was added to a priority crawl queue**:

- `/soccer`: Unknown to Google.
- `/pro-football`: Discovered, currently not indexed.
- `/pro-basketball`: Discovered, currently not indexed.
- `/baseball`: Discovered, currently not indexed.
- `/hockey`: Discovered, currently not indexed.
- `/college`: Unknown to Google.
- `/nba-grid/archive`: Discovered, currently not indexed.
- `/mlb-grid/archive`: Discovered, currently not indexed.
- `/hockey-grid/archive`: Unknown to Google.
- `/cbb-grid/archive`: Discovered, currently not indexed.

## The 2026-08-30 waiting recommendation, superseded as a work priority

On 2026-08-30, everything measured in the original audit was true of the live
site. It was not yet true of the site as Google had it stored.

The hubs were rewritten on 2026-08-30. The first three archives went live that
day, and the CBB archive followed on 2026-08-31. A
reviewer works from a fresh fetch, but the surrounding signals, the index, the
ranking, and the sample of pages a reviewer is shown came from crawl data that
mostly predated all of it. At that point, submitting would have spent the
re-review on a snapshot that did not include the work done in response to the
rejection.

At that time, the owner's operating contract also treated waiting as low cost
because the site was growing from about 1,800 clicks a month. On 2026-09-02 he
superseded that work order, put AdSense readiness first and authorized the
submission after live verification. Those gates passed and the review was
submitted the same day.

## Readiness gates completed

1. Round 400 was deployed and the live route-boundary checks passed.
2. A fresh live `scripts/auditGoogleRender.mjs` run passed across 29 routes.
3. The sitemap was resubmitted, all ten priority URLs were queued, and the
   authorized AdSense review was submitted.
4. After Google recrawls the pages, capture the next Page Indexing report and
   recheck the old 44 indexed and 89 not indexed split. The current report is
   dated 2026-08-27 and predates Round 400.

More traffic may strengthen the case, but the owner no longer treats another
month of growth as a prerequisite to doing the readiness work.

---

## Verdict

# REJECTED AGAIN, REPORTED 2026-09-10. NOT READY TO REQUEST

The 2026-09-02 request came back as the same "Low value content" finding, per
the owner's console screenshot of 2026-09-10. Everything below this line is the
state as it stood at that submission and is kept as the record of what was
tried. What the second rejection changes: the site side audit (render, thin
copy, ad delivery, canonical, noindex) has now been clean through two reviews,
so the remaining lever is the one the addendum named first and the site has
built least, the reference layer. As of Round 520 that layer is the Record
Books, the four grid archives, Hall of Champions and one format explainer. Do
not request another review until the explainers cover more than one competition
(the addendum lists league formats, playoff systems, draft history, salary caps
and transfer windows), the hubs link into them, and a Page Indexing report
taken after those pages ship shows them crawled. The owner submits; this file
only says when it is worth his click.

## The verdict as it stood at the 2026-09-02 submission

SUBMITTED, GOOGLE REVIEW PENDING

The 2026-08-30 live audit found no measurable thin-content defect, the hub
weakness it surfaced was fixed and measured, and four genuinely unique archive
pages now exist. Round 400 also found and fixed a separate site-side ad-placement
defect. Its local and live checks passed, the sitemap and priority crawl batch
were submitted, and the authorized AdSense review was requested. The real
manual unit is configured, and Auto Ads and Auto optimize are off.

**This is not an approval claim. Google is reviewing the live site and controls
the decision. AdSense currently shows Getting ready and Review requested.**
