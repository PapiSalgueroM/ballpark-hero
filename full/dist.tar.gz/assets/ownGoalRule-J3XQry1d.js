import{k as e}from"./keyedRng-BKZQ2UGv.js";const n=64;function a(o,r=n){return!(e(`${o}|tag`)()>=1/r)}function f(o,r){return Math.floor(e(`${o}|role`)()*r)}export{f as a,a as o};
