import{r as l,j as n}from"./index-5CQUiURY.js";function o(e,s,t=""){const[r,i]=l.useState(null);return l.useEffect(()=>{t===null?r!==null&&i(null):e&&!s&&r!==t&&i(t)},[e,s,t,r]),s&&t!==null&&r===t}const a=`
  [data-result-settled] > *,
  [data-result-settled] :is(.rm-score, .rm-badge, .rm-head, .rm-mark, .cm-rise, .cm-slam, .cm-tick-in, .cm-rise-gated, .cm-win-pulse, .cm-loss-shake) { animation: none !important; }
  [data-result-settled] :is(.rm-score, .rm-badge, .rm-head, .cm-rise, .cm-slam, .cm-tick-in, .cm-rise-gated) { opacity: 1 !important; transform: none !important; visibility: visible !important; }
  [data-result-settled] :is(.rm-burst, .cm-confetti) { display: none !important; }
`;function c({restored:e,children:s}){return n.jsxs("div",{"data-result-settled":e?"":void 0,children:[n.jsx("style",{children:a}),s]})}export{c as R,o as u};
