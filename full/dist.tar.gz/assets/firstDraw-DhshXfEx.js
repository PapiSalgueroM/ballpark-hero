function l(t){let r,e=!1;return{get:()=>(e||(r=t(),e=!0),r),release:()=>{e=!1}}}export{l as m};
