function n(i,e){return Number.isFinite(i)&&Number.isFinite(e)&&e>0&&i/e>=1.04}export{n as c};
