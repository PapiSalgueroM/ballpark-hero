function s(r){const i=e=>{if(e.status!=="correct")return"⬛";const n=e.rarity;return n==null?"🟩":n<2?"🟪":n<5?"🟦":n<10?"🟩":n<20?"🟥":n<35?"🟨":"🟫"},t=r.map(i);return[t.slice(0,3).join(""),t.slice(3,6).join(""),t.slice(6,9).join("")].join(`
`)}const o={easy:"🟨",medium:"🟩",hard:"🟦",insane:"🟪"};function u(r){return r.map(i=>(o[i.difficulty]??"⬛").repeat(4)).join(`
`)}export{u as c,s as g};
